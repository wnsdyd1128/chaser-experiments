; ModuleID = '/workspace/experiments/chaser/.cache/periodic-pilot-v1/pilot-04/source/workload.c'
source_filename = "/workspace/experiments/chaser/.cache/periodic-pilot-v1/pilot-04/source/workload.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

@.str = private unnamed_addr constant [12 x i8] c"ape.analyze\00", section "llvm.metadata"
@.str.1 = private unnamed_addr constant [82 x i8] c"/workspace/experiments/chaser/.cache/periodic-pilot-v1/pilot-04/source/workload.c\00", section "llvm.metadata"
@data_t0 = dso_local global [128 x i8] zeroinitializer, section ".chaser_data.00", align 4096, !dbg !0
@data_t1 = dso_local global [32768 x i8] zeroinitializer, section ".chaser_data.01", align 4096, !dbg !24
@data_t2 = dso_local global [16 x i8] zeroinitializer, section ".chaser_data.02", align 4096, !dbg !33
@data_t3 = dso_local global [2048 x i8] zeroinitializer, section ".chaser_data.03", align 4096, !dbg !38
@data_t4 = dso_local global [16384 x i8] zeroinitializer, section ".chaser_data.04", align 4096, !dbg !43
@workload_jobs = dso_local constant [5 x i32 ()*] [i32 ()* @task_job_t0, i32 ()* @task_job_t1, i32 ()* @task_job_t2, i32 ()* @task_job_t3, i32 ()* @task_job_t4], align 16, !dbg !5
@workload_expected = dso_local constant [5 x i32] [i32 9600, i32 9600, i32 9600, i32 9600, i32 9600], align 16, !dbg !20
@.str.2 = private unnamed_addr constant [11 x i8] c"ape.inline\00", section "llvm.metadata"
@llvm.global.annotations = appending global [10 x { i8*, i8*, i8*, i32, i8* }] [{ i8*, i8*, i8*, i32, i8* } { i8* bitcast (i32 ()* @task_job_t0 to i8*), i8* getelementptr inbounds ([12 x i8], [12 x i8]* @.str, i32 0, i32 0), i8* getelementptr inbounds ([82 x i8], [82 x i8]* @.str.1, i32 0, i32 0), i32 18, i8* null }, { i8*, i8*, i8*, i32, i8* } { i8* bitcast (i32 ()* @task_job_t1 to i8*), i8* getelementptr inbounds ([12 x i8], [12 x i8]* @.str, i32 0, i32 0), i8* getelementptr inbounds ([82 x i8], [82 x i8]* @.str.1, i32 0, i32 0), i32 33, i8* null }, { i8*, i8*, i8*, i32, i8* } { i8* bitcast (i32 ()* @task_job_t2 to i8*), i8* getelementptr inbounds ([12 x i8], [12 x i8]* @.str, i32 0, i32 0), i8* getelementptr inbounds ([82 x i8], [82 x i8]* @.str.1, i32 0, i32 0), i32 48, i8* null }, { i8*, i8*, i8*, i32, i8* } { i8* bitcast (i32 ()* @task_job_t3 to i8*), i8* getelementptr inbounds ([12 x i8], [12 x i8]* @.str, i32 0, i32 0), i8* getelementptr inbounds ([82 x i8], [82 x i8]* @.str.1, i32 0, i32 0), i32 63, i8* null }, { i8*, i8*, i8*, i32, i8* } { i8* bitcast (i32 ()* @task_job_t4 to i8*), i8* getelementptr inbounds ([12 x i8], [12 x i8]* @.str, i32 0, i32 0), i8* getelementptr inbounds ([82 x i8], [82 x i8]* @.str.1, i32 0, i32 0), i32 78, i8* null }, { i8*, i8*, i8*, i32, i8* } { i8* bitcast (i32 ()* @kernel_t0 to i8*), i8* getelementptr inbounds ([11 x i8], [11 x i8]* @.str.2, i32 0, i32 0), i8* getelementptr inbounds ([82 x i8], [82 x i8]* @.str.1, i32 0, i32 0), i32 10, i8* null }, { i8*, i8*, i8*, i32, i8* } { i8* bitcast (i32 ()* @kernel_t1 to i8*), i8* getelementptr inbounds ([11 x i8], [11 x i8]* @.str.2, i32 0, i32 0), i8* getelementptr inbounds ([82 x i8], [82 x i8]* @.str.1, i32 0, i32 0), i32 25, i8* null }, { i8*, i8*, i8*, i32, i8* } { i8* bitcast (i32 ()* @kernel_t2 to i8*), i8* getelementptr inbounds ([11 x i8], [11 x i8]* @.str.2, i32 0, i32 0), i8* getelementptr inbounds ([82 x i8], [82 x i8]* @.str.1, i32 0, i32 0), i32 40, i8* null }, { i8*, i8*, i8*, i32, i8* } { i8* bitcast (i32 ()* @kernel_t3 to i8*), i8* getelementptr inbounds ([11 x i8], [11 x i8]* @.str.2, i32 0, i32 0), i8* getelementptr inbounds ([82 x i8], [82 x i8]* @.str.1, i32 0, i32 0), i32 55, i8* null }, { i8*, i8*, i8*, i32, i8* } { i8* bitcast (i32 ()* @kernel_t4 to i8*), i8* getelementptr inbounds ([11 x i8], [11 x i8]* @.str.2, i32 0, i32 0), i8* getelementptr inbounds ([82 x i8], [82 x i8]* @.str.1, i32 0, i32 0), i32 70, i8* null }], section "llvm.metadata"

; Function Attrs: noinline nounwind uwtable
define dso_local i32 @task_job_t0() #0 !dbg !59 {
  %1 = alloca i32, align 4
  %2 = alloca i32, align 4
  call void @llvm.dbg.declare(metadata i32* %1, metadata !61, metadata !DIExpression()), !dbg !62
  store i32 0, i32* %1, align 4, !dbg !62
  call void @llvm.dbg.declare(metadata i32* %2, metadata !63, metadata !DIExpression()), !dbg !66
  store i32 0, i32* %2, align 4, !dbg !66
  br label %3, !dbg !67

3:                                                ; preds = %10, %0
  %4 = load i32, i32* %2, align 4, !dbg !68
  %5 = icmp slt i32 %4, 2400, !dbg !70
  br i1 %5, label %6, label %13, !dbg !71

6:                                                ; preds = %3
  %7 = call i32 @kernel_t0(), !dbg !72
  %8 = load i32, i32* %1, align 4, !dbg !73
  %9 = add i32 %8, %7, !dbg !73
  store i32 %9, i32* %1, align 4, !dbg !73
  br label %10, !dbg !74

10:                                               ; preds = %6
  %11 = load i32, i32* %2, align 4, !dbg !75
  %12 = add nsw i32 %11, 1, !dbg !75
  store i32 %12, i32* %2, align 4, !dbg !75
  br label %3, !dbg !76, !llvm.loop !77

13:                                               ; preds = %3
  %14 = load i32, i32* %1, align 4, !dbg !80
  ret i32 %14, !dbg !81
}

; Function Attrs: nofree nosync nounwind readnone speculatable willreturn
declare void @llvm.dbg.declare(metadata, metadata, metadata) #1

; Function Attrs: noinline nounwind uwtable
define internal i32 @kernel_t0() #0 !dbg !82 {
  %1 = alloca i32, align 4
  %2 = alloca i32, align 4
  call void @llvm.dbg.declare(metadata i32* %1, metadata !83, metadata !DIExpression()), !dbg !84
  store i32 0, i32* %1, align 4, !dbg !84
  call void @llvm.dbg.declare(metadata i32* %2, metadata !85, metadata !DIExpression()), !dbg !87
  store i32 0, i32* %2, align 4, !dbg !87
  br label %3, !dbg !88

3:                                                ; preds = %14, %0
  %4 = load i32, i32* %2, align 4, !dbg !89
  %5 = icmp slt i32 %4, 128, !dbg !91
  br i1 %5, label %6, label %17, !dbg !92

6:                                                ; preds = %3
  %7 = load i32, i32* %2, align 4, !dbg !93
  %8 = sext i32 %7 to i64, !dbg !94
  %9 = getelementptr inbounds [128 x i8], [128 x i8]* @data_t0, i64 0, i64 %8, !dbg !94
  %10 = load volatile i8, i8* %9, align 1, !dbg !94
  %11 = zext i8 %10 to i32, !dbg !94
  %12 = load i32, i32* %1, align 4, !dbg !95
  %13 = add i32 %12, %11, !dbg !95
  store i32 %13, i32* %1, align 4, !dbg !95
  br label %14, !dbg !96

14:                                               ; preds = %6
  %15 = load i32, i32* %2, align 4, !dbg !97
  %16 = add nsw i32 %15, 32, !dbg !97
  store i32 %16, i32* %2, align 4, !dbg !97
  br label %3, !dbg !98, !llvm.loop !99

17:                                               ; preds = %3
  %18 = load i32, i32* %1, align 4, !dbg !101
  ret i32 %18, !dbg !102
}

; Function Attrs: noinline nounwind uwtable
define dso_local i32 @task_job_t1() #0 !dbg !103 {
  %1 = alloca i32, align 4
  %2 = alloca i32, align 4
  call void @llvm.dbg.declare(metadata i32* %1, metadata !104, metadata !DIExpression()), !dbg !105
  store i32 0, i32* %1, align 4, !dbg !105
  call void @llvm.dbg.declare(metadata i32* %2, metadata !106, metadata !DIExpression()), !dbg !108
  store i32 0, i32* %2, align 4, !dbg !108
  br label %3, !dbg !109

3:                                                ; preds = %10, %0
  %4 = load i32, i32* %2, align 4, !dbg !110
  %5 = icmp slt i32 %4, 1200, !dbg !112
  br i1 %5, label %6, label %13, !dbg !113

6:                                                ; preds = %3
  %7 = call i32 @kernel_t1(), !dbg !114
  %8 = load i32, i32* %1, align 4, !dbg !115
  %9 = add i32 %8, %7, !dbg !115
  store i32 %9, i32* %1, align 4, !dbg !115
  br label %10, !dbg !116

10:                                               ; preds = %6
  %11 = load i32, i32* %2, align 4, !dbg !117
  %12 = add nsw i32 %11, 1, !dbg !117
  store i32 %12, i32* %2, align 4, !dbg !117
  br label %3, !dbg !118, !llvm.loop !119

13:                                               ; preds = %3
  %14 = load i32, i32* %1, align 4, !dbg !121
  ret i32 %14, !dbg !122
}

; Function Attrs: noinline nounwind uwtable
define internal i32 @kernel_t1() #0 !dbg !123 {
  %1 = alloca i32, align 4
  %2 = alloca i32, align 4
  call void @llvm.dbg.declare(metadata i32* %1, metadata !124, metadata !DIExpression()), !dbg !125
  store i32 0, i32* %1, align 4, !dbg !125
  call void @llvm.dbg.declare(metadata i32* %2, metadata !126, metadata !DIExpression()), !dbg !128
  store i32 0, i32* %2, align 4, !dbg !128
  br label %3, !dbg !129

3:                                                ; preds = %14, %0
  %4 = load i32, i32* %2, align 4, !dbg !130
  %5 = icmp slt i32 %4, 32768, !dbg !132
  br i1 %5, label %6, label %17, !dbg !133

6:                                                ; preds = %3
  %7 = load i32, i32* %2, align 4, !dbg !134
  %8 = sext i32 %7 to i64, !dbg !135
  %9 = getelementptr inbounds [32768 x i8], [32768 x i8]* @data_t1, i64 0, i64 %8, !dbg !135
  %10 = load volatile i8, i8* %9, align 1, !dbg !135
  %11 = zext i8 %10 to i32, !dbg !135
  %12 = load i32, i32* %1, align 4, !dbg !136
  %13 = add i32 %12, %11, !dbg !136
  store i32 %13, i32* %1, align 4, !dbg !136
  br label %14, !dbg !137

14:                                               ; preds = %6
  %15 = load i32, i32* %2, align 4, !dbg !138
  %16 = add nsw i32 %15, 4096, !dbg !138
  store i32 %16, i32* %2, align 4, !dbg !138
  br label %3, !dbg !139, !llvm.loop !140

17:                                               ; preds = %3
  %18 = load i32, i32* %1, align 4, !dbg !142
  ret i32 %18, !dbg !143
}

; Function Attrs: noinline nounwind uwtable
define dso_local i32 @task_job_t2() #0 !dbg !144 {
  %1 = alloca i32, align 4
  %2 = alloca i32, align 4
  call void @llvm.dbg.declare(metadata i32* %1, metadata !145, metadata !DIExpression()), !dbg !146
  store i32 0, i32* %1, align 4, !dbg !146
  call void @llvm.dbg.declare(metadata i32* %2, metadata !147, metadata !DIExpression()), !dbg !149
  store i32 0, i32* %2, align 4, !dbg !149
  br label %3, !dbg !150

3:                                                ; preds = %10, %0
  %4 = load i32, i32* %2, align 4, !dbg !151
  %5 = icmp slt i32 %4, 600, !dbg !153
  br i1 %5, label %6, label %13, !dbg !154

6:                                                ; preds = %3
  %7 = call i32 @kernel_t2(), !dbg !155
  %8 = load i32, i32* %1, align 4, !dbg !156
  %9 = add i32 %8, %7, !dbg !156
  store i32 %9, i32* %1, align 4, !dbg !156
  br label %10, !dbg !157

10:                                               ; preds = %6
  %11 = load i32, i32* %2, align 4, !dbg !158
  %12 = add nsw i32 %11, 1, !dbg !158
  store i32 %12, i32* %2, align 4, !dbg !158
  br label %3, !dbg !159, !llvm.loop !160

13:                                               ; preds = %3
  %14 = load i32, i32* %1, align 4, !dbg !162
  ret i32 %14, !dbg !163
}

; Function Attrs: noinline nounwind uwtable
define internal i32 @kernel_t2() #0 !dbg !164 {
  %1 = alloca i32, align 4
  %2 = alloca i32, align 4
  call void @llvm.dbg.declare(metadata i32* %1, metadata !165, metadata !DIExpression()), !dbg !166
  store i32 0, i32* %1, align 4, !dbg !166
  call void @llvm.dbg.declare(metadata i32* %2, metadata !167, metadata !DIExpression()), !dbg !169
  store i32 0, i32* %2, align 4, !dbg !169
  br label %3, !dbg !170

3:                                                ; preds = %14, %0
  %4 = load i32, i32* %2, align 4, !dbg !171
  %5 = icmp slt i32 %4, 16, !dbg !173
  br i1 %5, label %6, label %17, !dbg !174

6:                                                ; preds = %3
  %7 = load i32, i32* %2, align 4, !dbg !175
  %8 = sext i32 %7 to i64, !dbg !176
  %9 = getelementptr inbounds [16 x i8], [16 x i8]* @data_t2, i64 0, i64 %8, !dbg !176
  %10 = load volatile i8, i8* %9, align 1, !dbg !176
  %11 = zext i8 %10 to i32, !dbg !176
  %12 = load i32, i32* %1, align 4, !dbg !177
  %13 = add i32 %12, %11, !dbg !177
  store i32 %13, i32* %1, align 4, !dbg !177
  br label %14, !dbg !178

14:                                               ; preds = %6
  %15 = load i32, i32* %2, align 4, !dbg !179
  %16 = add nsw i32 %15, 1, !dbg !179
  store i32 %16, i32* %2, align 4, !dbg !179
  br label %3, !dbg !180, !llvm.loop !181

17:                                               ; preds = %3
  %18 = load i32, i32* %1, align 4, !dbg !183
  ret i32 %18, !dbg !184
}

; Function Attrs: noinline nounwind uwtable
define dso_local i32 @task_job_t3() #0 !dbg !185 {
  %1 = alloca i32, align 4
  %2 = alloca i32, align 4
  call void @llvm.dbg.declare(metadata i32* %1, metadata !186, metadata !DIExpression()), !dbg !187
  store i32 0, i32* %1, align 4, !dbg !187
  call void @llvm.dbg.declare(metadata i32* %2, metadata !188, metadata !DIExpression()), !dbg !190
  store i32 0, i32* %2, align 4, !dbg !190
  br label %3, !dbg !191

3:                                                ; preds = %10, %0
  %4 = load i32, i32* %2, align 4, !dbg !192
  %5 = icmp slt i32 %4, 150, !dbg !194
  br i1 %5, label %6, label %13, !dbg !195

6:                                                ; preds = %3
  %7 = call i32 @kernel_t3(), !dbg !196
  %8 = load i32, i32* %1, align 4, !dbg !197
  %9 = add i32 %8, %7, !dbg !197
  store i32 %9, i32* %1, align 4, !dbg !197
  br label %10, !dbg !198

10:                                               ; preds = %6
  %11 = load i32, i32* %2, align 4, !dbg !199
  %12 = add nsw i32 %11, 1, !dbg !199
  store i32 %12, i32* %2, align 4, !dbg !199
  br label %3, !dbg !200, !llvm.loop !201

13:                                               ; preds = %3
  %14 = load i32, i32* %1, align 4, !dbg !203
  ret i32 %14, !dbg !204
}

; Function Attrs: noinline nounwind uwtable
define internal i32 @kernel_t3() #0 !dbg !205 {
  %1 = alloca i32, align 4
  %2 = alloca i32, align 4
  call void @llvm.dbg.declare(metadata i32* %1, metadata !206, metadata !DIExpression()), !dbg !207
  store i32 0, i32* %1, align 4, !dbg !207
  call void @llvm.dbg.declare(metadata i32* %2, metadata !208, metadata !DIExpression()), !dbg !210
  store i32 0, i32* %2, align 4, !dbg !210
  br label %3, !dbg !211

3:                                                ; preds = %14, %0
  %4 = load i32, i32* %2, align 4, !dbg !212
  %5 = icmp slt i32 %4, 2048, !dbg !214
  br i1 %5, label %6, label %17, !dbg !215

6:                                                ; preds = %3
  %7 = load i32, i32* %2, align 4, !dbg !216
  %8 = sext i32 %7 to i64, !dbg !217
  %9 = getelementptr inbounds [2048 x i8], [2048 x i8]* @data_t3, i64 0, i64 %8, !dbg !217
  %10 = load volatile i8, i8* %9, align 1, !dbg !217
  %11 = zext i8 %10 to i32, !dbg !217
  %12 = load i32, i32* %1, align 4, !dbg !218
  %13 = add i32 %12, %11, !dbg !218
  store i32 %13, i32* %1, align 4, !dbg !218
  br label %14, !dbg !219

14:                                               ; preds = %6
  %15 = load i32, i32* %2, align 4, !dbg !220
  %16 = add nsw i32 %15, 32, !dbg !220
  store i32 %16, i32* %2, align 4, !dbg !220
  br label %3, !dbg !221, !llvm.loop !222

17:                                               ; preds = %3
  %18 = load i32, i32* %1, align 4, !dbg !224
  ret i32 %18, !dbg !225
}

; Function Attrs: noinline nounwind uwtable
define dso_local i32 @task_job_t4() #0 !dbg !226 {
  %1 = alloca i32, align 4
  %2 = alloca i32, align 4
  call void @llvm.dbg.declare(metadata i32* %1, metadata !227, metadata !DIExpression()), !dbg !228
  store i32 0, i32* %1, align 4, !dbg !228
  call void @llvm.dbg.declare(metadata i32* %2, metadata !229, metadata !DIExpression()), !dbg !231
  store i32 0, i32* %2, align 4, !dbg !231
  br label %3, !dbg !232

3:                                                ; preds = %10, %0
  %4 = load i32, i32* %2, align 4, !dbg !233
  %5 = icmp slt i32 %4, 2400, !dbg !235
  br i1 %5, label %6, label %13, !dbg !236

6:                                                ; preds = %3
  %7 = call i32 @kernel_t4(), !dbg !237
  %8 = load i32, i32* %1, align 4, !dbg !238
  %9 = add i32 %8, %7, !dbg !238
  store i32 %9, i32* %1, align 4, !dbg !238
  br label %10, !dbg !239

10:                                               ; preds = %6
  %11 = load i32, i32* %2, align 4, !dbg !240
  %12 = add nsw i32 %11, 1, !dbg !240
  store i32 %12, i32* %2, align 4, !dbg !240
  br label %3, !dbg !241, !llvm.loop !242

13:                                               ; preds = %3
  %14 = load i32, i32* %1, align 4, !dbg !244
  ret i32 %14, !dbg !245
}

; Function Attrs: noinline nounwind uwtable
define internal i32 @kernel_t4() #0 !dbg !246 {
  %1 = alloca i32, align 4
  %2 = alloca i32, align 4
  call void @llvm.dbg.declare(metadata i32* %1, metadata !247, metadata !DIExpression()), !dbg !248
  store i32 0, i32* %1, align 4, !dbg !248
  call void @llvm.dbg.declare(metadata i32* %2, metadata !249, metadata !DIExpression()), !dbg !251
  store i32 0, i32* %2, align 4, !dbg !251
  br label %3, !dbg !252

3:                                                ; preds = %14, %0
  %4 = load i32, i32* %2, align 4, !dbg !253
  %5 = icmp slt i32 %4, 16384, !dbg !255
  br i1 %5, label %6, label %17, !dbg !256

6:                                                ; preds = %3
  %7 = load i32, i32* %2, align 4, !dbg !257
  %8 = sext i32 %7 to i64, !dbg !258
  %9 = getelementptr inbounds [16384 x i8], [16384 x i8]* @data_t4, i64 0, i64 %8, !dbg !258
  %10 = load volatile i8, i8* %9, align 1, !dbg !258
  %11 = zext i8 %10 to i32, !dbg !258
  %12 = load i32, i32* %1, align 4, !dbg !259
  %13 = add i32 %12, %11, !dbg !259
  store i32 %13, i32* %1, align 4, !dbg !259
  br label %14, !dbg !260

14:                                               ; preds = %6
  %15 = load i32, i32* %2, align 4, !dbg !261
  %16 = add nsw i32 %15, 4096, !dbg !261
  store i32 %16, i32* %2, align 4, !dbg !261
  br label %3, !dbg !262, !llvm.loop !263

17:                                               ; preds = %3
  %18 = load i32, i32* %1, align 4, !dbg !265
  ret i32 %18, !dbg !266
}

; Function Attrs: noinline nounwind uwtable
define dso_local void @workload_prepare() #0 !dbg !267 {
  %1 = alloca i32, align 4
  %2 = alloca i32, align 4
  %3 = alloca i32, align 4
  %4 = alloca i32, align 4
  %5 = alloca i32, align 4
  call void @llvm.dbg.declare(metadata i32* %1, metadata !270, metadata !DIExpression()), !dbg !272
  store i32 0, i32* %1, align 4, !dbg !272
  br label %6, !dbg !273

6:                                                ; preds = %13, %0
  %7 = load i32, i32* %1, align 4, !dbg !274
  %8 = icmp slt i32 %7, 128, !dbg !276
  br i1 %8, label %9, label %16, !dbg !277

9:                                                ; preds = %6
  %10 = load i32, i32* %1, align 4, !dbg !278
  %11 = sext i32 %10 to i64, !dbg !279
  %12 = getelementptr inbounds [128 x i8], [128 x i8]* @data_t0, i64 0, i64 %11, !dbg !279
  store volatile i8 1, i8* %12, align 1, !dbg !280
  br label %13, !dbg !279

13:                                               ; preds = %9
  %14 = load i32, i32* %1, align 4, !dbg !281
  %15 = add nsw i32 %14, 1, !dbg !281
  store i32 %15, i32* %1, align 4, !dbg !281
  br label %6, !dbg !282, !llvm.loop !283

16:                                               ; preds = %6
  call void @llvm.dbg.declare(metadata i32* %2, metadata !285, metadata !DIExpression()), !dbg !287
  store i32 0, i32* %2, align 4, !dbg !287
  br label %17, !dbg !288

17:                                               ; preds = %24, %16
  %18 = load i32, i32* %2, align 4, !dbg !289
  %19 = icmp slt i32 %18, 32768, !dbg !291
  br i1 %19, label %20, label %27, !dbg !292

20:                                               ; preds = %17
  %21 = load i32, i32* %2, align 4, !dbg !293
  %22 = sext i32 %21 to i64, !dbg !294
  %23 = getelementptr inbounds [32768 x i8], [32768 x i8]* @data_t1, i64 0, i64 %22, !dbg !294
  store volatile i8 1, i8* %23, align 1, !dbg !295
  br label %24, !dbg !294

24:                                               ; preds = %20
  %25 = load i32, i32* %2, align 4, !dbg !296
  %26 = add nsw i32 %25, 1, !dbg !296
  store i32 %26, i32* %2, align 4, !dbg !296
  br label %17, !dbg !297, !llvm.loop !298

27:                                               ; preds = %17
  call void @llvm.dbg.declare(metadata i32* %3, metadata !300, metadata !DIExpression()), !dbg !302
  store i32 0, i32* %3, align 4, !dbg !302
  br label %28, !dbg !303

28:                                               ; preds = %35, %27
  %29 = load i32, i32* %3, align 4, !dbg !304
  %30 = icmp slt i32 %29, 16, !dbg !306
  br i1 %30, label %31, label %38, !dbg !307

31:                                               ; preds = %28
  %32 = load i32, i32* %3, align 4, !dbg !308
  %33 = sext i32 %32 to i64, !dbg !309
  %34 = getelementptr inbounds [16 x i8], [16 x i8]* @data_t2, i64 0, i64 %33, !dbg !309
  store volatile i8 1, i8* %34, align 1, !dbg !310
  br label %35, !dbg !309

35:                                               ; preds = %31
  %36 = load i32, i32* %3, align 4, !dbg !311
  %37 = add nsw i32 %36, 1, !dbg !311
  store i32 %37, i32* %3, align 4, !dbg !311
  br label %28, !dbg !312, !llvm.loop !313

38:                                               ; preds = %28
  call void @llvm.dbg.declare(metadata i32* %4, metadata !315, metadata !DIExpression()), !dbg !317
  store i32 0, i32* %4, align 4, !dbg !317
  br label %39, !dbg !318

39:                                               ; preds = %46, %38
  %40 = load i32, i32* %4, align 4, !dbg !319
  %41 = icmp slt i32 %40, 2048, !dbg !321
  br i1 %41, label %42, label %49, !dbg !322

42:                                               ; preds = %39
  %43 = load i32, i32* %4, align 4, !dbg !323
  %44 = sext i32 %43 to i64, !dbg !324
  %45 = getelementptr inbounds [2048 x i8], [2048 x i8]* @data_t3, i64 0, i64 %44, !dbg !324
  store volatile i8 1, i8* %45, align 1, !dbg !325
  br label %46, !dbg !324

46:                                               ; preds = %42
  %47 = load i32, i32* %4, align 4, !dbg !326
  %48 = add nsw i32 %47, 1, !dbg !326
  store i32 %48, i32* %4, align 4, !dbg !326
  br label %39, !dbg !327, !llvm.loop !328

49:                                               ; preds = %39
  call void @llvm.dbg.declare(metadata i32* %5, metadata !330, metadata !DIExpression()), !dbg !332
  store i32 0, i32* %5, align 4, !dbg !332
  br label %50, !dbg !333

50:                                               ; preds = %57, %49
  %51 = load i32, i32* %5, align 4, !dbg !334
  %52 = icmp slt i32 %51, 16384, !dbg !336
  br i1 %52, label %53, label %60, !dbg !337

53:                                               ; preds = %50
  %54 = load i32, i32* %5, align 4, !dbg !338
  %55 = sext i32 %54 to i64, !dbg !339
  %56 = getelementptr inbounds [16384 x i8], [16384 x i8]* @data_t4, i64 0, i64 %55, !dbg !339
  store volatile i8 1, i8* %56, align 1, !dbg !340
  br label %57, !dbg !339

57:                                               ; preds = %53
  %58 = load i32, i32* %5, align 4, !dbg !341
  %59 = add nsw i32 %58, 1, !dbg !341
  store i32 %59, i32* %5, align 4, !dbg !341
  br label %50, !dbg !342, !llvm.loop !343

60:                                               ; preds = %50
  ret void, !dbg !345
}

attributes #0 = { noinline nounwind uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { nofree nosync nounwind readnone speculatable willreturn }

!llvm.dbg.cu = !{!2}
!llvm.module.flags = !{!51, !52, !53, !54, !55, !56, !57}
!llvm.ident = !{!58}

!0 = !DIGlobalVariableExpression(var: !1, expr: !DIExpression())
!1 = distinct !DIGlobalVariable(name: "data_t0", scope: !2, file: !7, line: 9, type: !48, isLocal: false, isDefinition: true, align: 32768)
!2 = distinct !DICompileUnit(language: DW_LANG_C99, file: !3, producer: "Ubuntu clang version 14.0.0-1ubuntu1.1", isOptimized: false, runtimeVersion: 0, emissionKind: FullDebug, globals: !4, splitDebugInlining: false, nameTableKind: None)
!3 = !DIFile(filename: "/workspace/experiments/chaser/.cache/periodic-pilot-v1/pilot-04/source/workload.c", directory: "/workspace/experiments/chaser/.cache/periodic-pilot-v1/pilot-04/analysis", checksumkind: CSK_MD5, checksum: "93a683d9cec3434582227ce6afa50a18")
!4 = !{!5, !20, !0, !24, !33, !38, !43}
!5 = !DIGlobalVariableExpression(var: !6, expr: !DIExpression())
!6 = distinct !DIGlobalVariable(name: "workload_jobs", scope: !2, file: !7, line: 91, type: !8, isLocal: false, isDefinition: true)
!7 = !DIFile(filename: "source/workload.c", directory: "/workspace/experiments/chaser/.cache/periodic-pilot-v1/pilot-04", checksumkind: CSK_MD5, checksum: "93a683d9cec3434582227ce6afa50a18")
!8 = !DICompositeType(tag: DW_TAG_array_type, baseType: !9, size: 320, elements: !18)
!9 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !10)
!10 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !11, size: 64)
!11 = !DISubroutineType(types: !12)
!12 = !{!13}
!13 = !DIDerivedType(tag: DW_TAG_typedef, name: "uint32_t", file: !14, line: 26, baseType: !15)
!14 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/stdint-uintn.h", directory: "", checksumkind: CSK_MD5, checksum: "2bf2ae53c58c01b1a1b9383b5195125c")
!15 = !DIDerivedType(tag: DW_TAG_typedef, name: "__uint32_t", file: !16, line: 42, baseType: !17)
!16 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/types.h", directory: "", checksumkind: CSK_MD5, checksum: "d108b5f93a74c50510d7d9bc0ab36df9")
!17 = !DIBasicType(name: "unsigned int", size: 32, encoding: DW_ATE_unsigned)
!18 = !{!19}
!19 = !DISubrange(count: 5)
!20 = !DIGlobalVariableExpression(var: !21, expr: !DIExpression())
!21 = distinct !DIGlobalVariable(name: "workload_expected", scope: !2, file: !7, line: 98, type: !22, isLocal: false, isDefinition: true)
!22 = !DICompositeType(tag: DW_TAG_array_type, baseType: !23, size: 160, elements: !18)
!23 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !13)
!24 = !DIGlobalVariableExpression(var: !25, expr: !DIExpression())
!25 = distinct !DIGlobalVariable(name: "data_t1", scope: !2, file: !7, line: 24, type: !26, isLocal: false, isDefinition: true, align: 32768)
!26 = !DICompositeType(tag: DW_TAG_array_type, baseType: !27, size: 262144, elements: !31)
!27 = !DIDerivedType(tag: DW_TAG_volatile_type, baseType: !28)
!28 = !DIDerivedType(tag: DW_TAG_typedef, name: "uint8_t", file: !14, line: 24, baseType: !29)
!29 = !DIDerivedType(tag: DW_TAG_typedef, name: "__uint8_t", file: !16, line: 38, baseType: !30)
!30 = !DIBasicType(name: "unsigned char", size: 8, encoding: DW_ATE_unsigned_char)
!31 = !{!32}
!32 = !DISubrange(count: 32768)
!33 = !DIGlobalVariableExpression(var: !34, expr: !DIExpression())
!34 = distinct !DIGlobalVariable(name: "data_t2", scope: !2, file: !7, line: 39, type: !35, isLocal: false, isDefinition: true, align: 32768)
!35 = !DICompositeType(tag: DW_TAG_array_type, baseType: !27, size: 128, elements: !36)
!36 = !{!37}
!37 = !DISubrange(count: 16)
!38 = !DIGlobalVariableExpression(var: !39, expr: !DIExpression())
!39 = distinct !DIGlobalVariable(name: "data_t3", scope: !2, file: !7, line: 54, type: !40, isLocal: false, isDefinition: true, align: 32768)
!40 = !DICompositeType(tag: DW_TAG_array_type, baseType: !27, size: 16384, elements: !41)
!41 = !{!42}
!42 = !DISubrange(count: 2048)
!43 = !DIGlobalVariableExpression(var: !44, expr: !DIExpression())
!44 = distinct !DIGlobalVariable(name: "data_t4", scope: !2, file: !7, line: 69, type: !45, isLocal: false, isDefinition: true, align: 32768)
!45 = !DICompositeType(tag: DW_TAG_array_type, baseType: !27, size: 131072, elements: !46)
!46 = !{!47}
!47 = !DISubrange(count: 16384)
!48 = !DICompositeType(tag: DW_TAG_array_type, baseType: !27, size: 1024, elements: !49)
!49 = !{!50}
!50 = !DISubrange(count: 128)
!51 = !{i32 7, !"Dwarf Version", i32 5}
!52 = !{i32 2, !"Debug Info Version", i32 3}
!53 = !{i32 1, !"wchar_size", i32 4}
!54 = !{i32 7, !"PIC Level", i32 2}
!55 = !{i32 7, !"PIE Level", i32 2}
!56 = !{i32 7, !"uwtable", i32 1}
!57 = !{i32 7, !"frame-pointer", i32 2}
!58 = !{!"Ubuntu clang version 14.0.0-1ubuntu1.1"}
!59 = distinct !DISubprogram(name: "task_job_t0", scope: !7, file: !7, line: 18, type: !11, scopeLine: 18, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !2, retainedNodes: !60)
!60 = !{}
!61 = !DILocalVariable(name: "sum", scope: !59, file: !7, line: 19, type: !13)
!62 = !DILocation(line: 19, column: 14, scope: !59)
!63 = !DILocalVariable(name: "s", scope: !64, file: !7, line: 20, type: !65)
!64 = distinct !DILexicalBlock(scope: !59, file: !7, line: 20, column: 5)
!65 = !DIBasicType(name: "int", size: 32, encoding: DW_ATE_signed)
!66 = !DILocation(line: 20, column: 14, scope: !64)
!67 = !DILocation(line: 20, column: 10, scope: !64)
!68 = !DILocation(line: 20, column: 21, scope: !69)
!69 = distinct !DILexicalBlock(scope: !64, file: !7, line: 20, column: 5)
!70 = !DILocation(line: 20, column: 23, scope: !69)
!71 = !DILocation(line: 20, column: 5, scope: !64)
!72 = !DILocation(line: 21, column: 16, scope: !69)
!73 = !DILocation(line: 21, column: 13, scope: !69)
!74 = !DILocation(line: 21, column: 9, scope: !69)
!75 = !DILocation(line: 20, column: 31, scope: !69)
!76 = !DILocation(line: 20, column: 5, scope: !69)
!77 = distinct !{!77, !71, !78, !79}
!78 = !DILocation(line: 21, column: 26, scope: !64)
!79 = !{!"llvm.loop.mustprogress"}
!80 = !DILocation(line: 22, column: 12, scope: !59)
!81 = !DILocation(line: 22, column: 5, scope: !59)
!82 = distinct !DISubprogram(name: "kernel_t0", scope: !7, file: !7, line: 10, type: !11, scopeLine: 10, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition, unit: !2, retainedNodes: !60)
!83 = !DILocalVariable(name: "sum", scope: !82, file: !7, line: 11, type: !13)
!84 = !DILocation(line: 11, column: 14, scope: !82)
!85 = !DILocalVariable(name: "i", scope: !86, file: !7, line: 12, type: !65)
!86 = distinct !DILexicalBlock(scope: !82, file: !7, line: 12, column: 5)
!87 = !DILocation(line: 12, column: 14, scope: !86)
!88 = !DILocation(line: 12, column: 10, scope: !86)
!89 = !DILocation(line: 12, column: 21, scope: !90)
!90 = distinct !DILexicalBlock(scope: !86, file: !7, line: 12, column: 5)
!91 = !DILocation(line: 12, column: 23, scope: !90)
!92 = !DILocation(line: 12, column: 5, scope: !86)
!93 = !DILocation(line: 13, column: 24, scope: !90)
!94 = !DILocation(line: 13, column: 16, scope: !90)
!95 = !DILocation(line: 13, column: 13, scope: !90)
!96 = !DILocation(line: 13, column: 9, scope: !90)
!97 = !DILocation(line: 12, column: 32, scope: !90)
!98 = !DILocation(line: 12, column: 5, scope: !90)
!99 = distinct !{!99, !92, !100, !79}
!100 = !DILocation(line: 13, column: 25, scope: !86)
!101 = !DILocation(line: 14, column: 12, scope: !82)
!102 = !DILocation(line: 14, column: 5, scope: !82)
!103 = distinct !DISubprogram(name: "task_job_t1", scope: !7, file: !7, line: 33, type: !11, scopeLine: 33, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !2, retainedNodes: !60)
!104 = !DILocalVariable(name: "sum", scope: !103, file: !7, line: 34, type: !13)
!105 = !DILocation(line: 34, column: 14, scope: !103)
!106 = !DILocalVariable(name: "s", scope: !107, file: !7, line: 35, type: !65)
!107 = distinct !DILexicalBlock(scope: !103, file: !7, line: 35, column: 5)
!108 = !DILocation(line: 35, column: 14, scope: !107)
!109 = !DILocation(line: 35, column: 10, scope: !107)
!110 = !DILocation(line: 35, column: 21, scope: !111)
!111 = distinct !DILexicalBlock(scope: !107, file: !7, line: 35, column: 5)
!112 = !DILocation(line: 35, column: 23, scope: !111)
!113 = !DILocation(line: 35, column: 5, scope: !107)
!114 = !DILocation(line: 36, column: 16, scope: !111)
!115 = !DILocation(line: 36, column: 13, scope: !111)
!116 = !DILocation(line: 36, column: 9, scope: !111)
!117 = !DILocation(line: 35, column: 31, scope: !111)
!118 = !DILocation(line: 35, column: 5, scope: !111)
!119 = distinct !{!119, !113, !120, !79}
!120 = !DILocation(line: 36, column: 26, scope: !107)
!121 = !DILocation(line: 37, column: 12, scope: !103)
!122 = !DILocation(line: 37, column: 5, scope: !103)
!123 = distinct !DISubprogram(name: "kernel_t1", scope: !7, file: !7, line: 25, type: !11, scopeLine: 25, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition, unit: !2, retainedNodes: !60)
!124 = !DILocalVariable(name: "sum", scope: !123, file: !7, line: 26, type: !13)
!125 = !DILocation(line: 26, column: 14, scope: !123)
!126 = !DILocalVariable(name: "i", scope: !127, file: !7, line: 27, type: !65)
!127 = distinct !DILexicalBlock(scope: !123, file: !7, line: 27, column: 5)
!128 = !DILocation(line: 27, column: 14, scope: !127)
!129 = !DILocation(line: 27, column: 10, scope: !127)
!130 = !DILocation(line: 27, column: 21, scope: !131)
!131 = distinct !DILexicalBlock(scope: !127, file: !7, line: 27, column: 5)
!132 = !DILocation(line: 27, column: 23, scope: !131)
!133 = !DILocation(line: 27, column: 5, scope: !127)
!134 = !DILocation(line: 28, column: 24, scope: !131)
!135 = !DILocation(line: 28, column: 16, scope: !131)
!136 = !DILocation(line: 28, column: 13, scope: !131)
!137 = !DILocation(line: 28, column: 9, scope: !131)
!138 = !DILocation(line: 27, column: 34, scope: !131)
!139 = !DILocation(line: 27, column: 5, scope: !131)
!140 = distinct !{!140, !133, !141, !79}
!141 = !DILocation(line: 28, column: 25, scope: !127)
!142 = !DILocation(line: 29, column: 12, scope: !123)
!143 = !DILocation(line: 29, column: 5, scope: !123)
!144 = distinct !DISubprogram(name: "task_job_t2", scope: !7, file: !7, line: 48, type: !11, scopeLine: 48, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !2, retainedNodes: !60)
!145 = !DILocalVariable(name: "sum", scope: !144, file: !7, line: 49, type: !13)
!146 = !DILocation(line: 49, column: 14, scope: !144)
!147 = !DILocalVariable(name: "s", scope: !148, file: !7, line: 50, type: !65)
!148 = distinct !DILexicalBlock(scope: !144, file: !7, line: 50, column: 5)
!149 = !DILocation(line: 50, column: 14, scope: !148)
!150 = !DILocation(line: 50, column: 10, scope: !148)
!151 = !DILocation(line: 50, column: 21, scope: !152)
!152 = distinct !DILexicalBlock(scope: !148, file: !7, line: 50, column: 5)
!153 = !DILocation(line: 50, column: 23, scope: !152)
!154 = !DILocation(line: 50, column: 5, scope: !148)
!155 = !DILocation(line: 51, column: 16, scope: !152)
!156 = !DILocation(line: 51, column: 13, scope: !152)
!157 = !DILocation(line: 51, column: 9, scope: !152)
!158 = !DILocation(line: 50, column: 30, scope: !152)
!159 = !DILocation(line: 50, column: 5, scope: !152)
!160 = distinct !{!160, !154, !161, !79}
!161 = !DILocation(line: 51, column: 26, scope: !148)
!162 = !DILocation(line: 52, column: 12, scope: !144)
!163 = !DILocation(line: 52, column: 5, scope: !144)
!164 = distinct !DISubprogram(name: "kernel_t2", scope: !7, file: !7, line: 40, type: !11, scopeLine: 40, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition, unit: !2, retainedNodes: !60)
!165 = !DILocalVariable(name: "sum", scope: !164, file: !7, line: 41, type: !13)
!166 = !DILocation(line: 41, column: 14, scope: !164)
!167 = !DILocalVariable(name: "i", scope: !168, file: !7, line: 42, type: !65)
!168 = distinct !DILexicalBlock(scope: !164, file: !7, line: 42, column: 5)
!169 = !DILocation(line: 42, column: 14, scope: !168)
!170 = !DILocation(line: 42, column: 10, scope: !168)
!171 = !DILocation(line: 42, column: 21, scope: !172)
!172 = distinct !DILexicalBlock(scope: !168, file: !7, line: 42, column: 5)
!173 = !DILocation(line: 42, column: 23, scope: !172)
!174 = !DILocation(line: 42, column: 5, scope: !168)
!175 = !DILocation(line: 43, column: 24, scope: !172)
!176 = !DILocation(line: 43, column: 16, scope: !172)
!177 = !DILocation(line: 43, column: 13, scope: !172)
!178 = !DILocation(line: 43, column: 9, scope: !172)
!179 = !DILocation(line: 42, column: 31, scope: !172)
!180 = !DILocation(line: 42, column: 5, scope: !172)
!181 = distinct !{!181, !174, !182, !79}
!182 = !DILocation(line: 43, column: 25, scope: !168)
!183 = !DILocation(line: 44, column: 12, scope: !164)
!184 = !DILocation(line: 44, column: 5, scope: !164)
!185 = distinct !DISubprogram(name: "task_job_t3", scope: !7, file: !7, line: 63, type: !11, scopeLine: 63, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !2, retainedNodes: !60)
!186 = !DILocalVariable(name: "sum", scope: !185, file: !7, line: 64, type: !13)
!187 = !DILocation(line: 64, column: 14, scope: !185)
!188 = !DILocalVariable(name: "s", scope: !189, file: !7, line: 65, type: !65)
!189 = distinct !DILexicalBlock(scope: !185, file: !7, line: 65, column: 5)
!190 = !DILocation(line: 65, column: 14, scope: !189)
!191 = !DILocation(line: 65, column: 10, scope: !189)
!192 = !DILocation(line: 65, column: 21, scope: !193)
!193 = distinct !DILexicalBlock(scope: !189, file: !7, line: 65, column: 5)
!194 = !DILocation(line: 65, column: 23, scope: !193)
!195 = !DILocation(line: 65, column: 5, scope: !189)
!196 = !DILocation(line: 66, column: 16, scope: !193)
!197 = !DILocation(line: 66, column: 13, scope: !193)
!198 = !DILocation(line: 66, column: 9, scope: !193)
!199 = !DILocation(line: 65, column: 30, scope: !193)
!200 = !DILocation(line: 65, column: 5, scope: !193)
!201 = distinct !{!201, !195, !202, !79}
!202 = !DILocation(line: 66, column: 26, scope: !189)
!203 = !DILocation(line: 67, column: 12, scope: !185)
!204 = !DILocation(line: 67, column: 5, scope: !185)
!205 = distinct !DISubprogram(name: "kernel_t3", scope: !7, file: !7, line: 55, type: !11, scopeLine: 55, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition, unit: !2, retainedNodes: !60)
!206 = !DILocalVariable(name: "sum", scope: !205, file: !7, line: 56, type: !13)
!207 = !DILocation(line: 56, column: 14, scope: !205)
!208 = !DILocalVariable(name: "i", scope: !209, file: !7, line: 57, type: !65)
!209 = distinct !DILexicalBlock(scope: !205, file: !7, line: 57, column: 5)
!210 = !DILocation(line: 57, column: 14, scope: !209)
!211 = !DILocation(line: 57, column: 10, scope: !209)
!212 = !DILocation(line: 57, column: 21, scope: !213)
!213 = distinct !DILexicalBlock(scope: !209, file: !7, line: 57, column: 5)
!214 = !DILocation(line: 57, column: 23, scope: !213)
!215 = !DILocation(line: 57, column: 5, scope: !209)
!216 = !DILocation(line: 58, column: 24, scope: !213)
!217 = !DILocation(line: 58, column: 16, scope: !213)
!218 = !DILocation(line: 58, column: 13, scope: !213)
!219 = !DILocation(line: 58, column: 9, scope: !213)
!220 = !DILocation(line: 57, column: 33, scope: !213)
!221 = !DILocation(line: 57, column: 5, scope: !213)
!222 = distinct !{!222, !215, !223, !79}
!223 = !DILocation(line: 58, column: 25, scope: !209)
!224 = !DILocation(line: 59, column: 12, scope: !205)
!225 = !DILocation(line: 59, column: 5, scope: !205)
!226 = distinct !DISubprogram(name: "task_job_t4", scope: !7, file: !7, line: 78, type: !11, scopeLine: 78, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !2, retainedNodes: !60)
!227 = !DILocalVariable(name: "sum", scope: !226, file: !7, line: 79, type: !13)
!228 = !DILocation(line: 79, column: 14, scope: !226)
!229 = !DILocalVariable(name: "s", scope: !230, file: !7, line: 80, type: !65)
!230 = distinct !DILexicalBlock(scope: !226, file: !7, line: 80, column: 5)
!231 = !DILocation(line: 80, column: 14, scope: !230)
!232 = !DILocation(line: 80, column: 10, scope: !230)
!233 = !DILocation(line: 80, column: 21, scope: !234)
!234 = distinct !DILexicalBlock(scope: !230, file: !7, line: 80, column: 5)
!235 = !DILocation(line: 80, column: 23, scope: !234)
!236 = !DILocation(line: 80, column: 5, scope: !230)
!237 = !DILocation(line: 81, column: 16, scope: !234)
!238 = !DILocation(line: 81, column: 13, scope: !234)
!239 = !DILocation(line: 81, column: 9, scope: !234)
!240 = !DILocation(line: 80, column: 31, scope: !234)
!241 = !DILocation(line: 80, column: 5, scope: !234)
!242 = distinct !{!242, !236, !243, !79}
!243 = !DILocation(line: 81, column: 26, scope: !230)
!244 = !DILocation(line: 82, column: 12, scope: !226)
!245 = !DILocation(line: 82, column: 5, scope: !226)
!246 = distinct !DISubprogram(name: "kernel_t4", scope: !7, file: !7, line: 70, type: !11, scopeLine: 70, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition, unit: !2, retainedNodes: !60)
!247 = !DILocalVariable(name: "sum", scope: !246, file: !7, line: 71, type: !13)
!248 = !DILocation(line: 71, column: 14, scope: !246)
!249 = !DILocalVariable(name: "i", scope: !250, file: !7, line: 72, type: !65)
!250 = distinct !DILexicalBlock(scope: !246, file: !7, line: 72, column: 5)
!251 = !DILocation(line: 72, column: 14, scope: !250)
!252 = !DILocation(line: 72, column: 10, scope: !250)
!253 = !DILocation(line: 72, column: 21, scope: !254)
!254 = distinct !DILexicalBlock(scope: !250, file: !7, line: 72, column: 5)
!255 = !DILocation(line: 72, column: 23, scope: !254)
!256 = !DILocation(line: 72, column: 5, scope: !250)
!257 = !DILocation(line: 73, column: 24, scope: !254)
!258 = !DILocation(line: 73, column: 16, scope: !254)
!259 = !DILocation(line: 73, column: 13, scope: !254)
!260 = !DILocation(line: 73, column: 9, scope: !254)
!261 = !DILocation(line: 72, column: 34, scope: !254)
!262 = !DILocation(line: 72, column: 5, scope: !254)
!263 = distinct !{!263, !256, !264, !79}
!264 = !DILocation(line: 73, column: 25, scope: !250)
!265 = !DILocation(line: 74, column: 12, scope: !246)
!266 = !DILocation(line: 74, column: 5, scope: !246)
!267 = distinct !DISubprogram(name: "workload_prepare", scope: !7, file: !7, line: 84, type: !268, scopeLine: 84, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !2, retainedNodes: !60)
!268 = !DISubroutineType(types: !269)
!269 = !{null}
!270 = !DILocalVariable(name: "i", scope: !271, file: !7, line: 85, type: !65)
!271 = distinct !DILexicalBlock(scope: !267, file: !7, line: 85, column: 5)
!272 = !DILocation(line: 85, column: 14, scope: !271)
!273 = !DILocation(line: 85, column: 10, scope: !271)
!274 = !DILocation(line: 85, column: 21, scope: !275)
!275 = distinct !DILexicalBlock(scope: !271, file: !7, line: 85, column: 5)
!276 = !DILocation(line: 85, column: 23, scope: !275)
!277 = !DILocation(line: 85, column: 5, scope: !271)
!278 = !DILocation(line: 85, column: 43, scope: !275)
!279 = !DILocation(line: 85, column: 35, scope: !275)
!280 = !DILocation(line: 85, column: 46, scope: !275)
!281 = !DILocation(line: 85, column: 30, scope: !275)
!282 = !DILocation(line: 85, column: 5, scope: !275)
!283 = distinct !{!283, !277, !284, !79}
!284 = !DILocation(line: 85, column: 48, scope: !271)
!285 = !DILocalVariable(name: "i", scope: !286, file: !7, line: 86, type: !65)
!286 = distinct !DILexicalBlock(scope: !267, file: !7, line: 86, column: 5)
!287 = !DILocation(line: 86, column: 14, scope: !286)
!288 = !DILocation(line: 86, column: 10, scope: !286)
!289 = !DILocation(line: 86, column: 21, scope: !290)
!290 = distinct !DILexicalBlock(scope: !286, file: !7, line: 86, column: 5)
!291 = !DILocation(line: 86, column: 23, scope: !290)
!292 = !DILocation(line: 86, column: 5, scope: !286)
!293 = !DILocation(line: 86, column: 45, scope: !290)
!294 = !DILocation(line: 86, column: 37, scope: !290)
!295 = !DILocation(line: 86, column: 48, scope: !290)
!296 = !DILocation(line: 86, column: 32, scope: !290)
!297 = !DILocation(line: 86, column: 5, scope: !290)
!298 = distinct !{!298, !292, !299, !79}
!299 = !DILocation(line: 86, column: 50, scope: !286)
!300 = !DILocalVariable(name: "i", scope: !301, file: !7, line: 87, type: !65)
!301 = distinct !DILexicalBlock(scope: !267, file: !7, line: 87, column: 5)
!302 = !DILocation(line: 87, column: 14, scope: !301)
!303 = !DILocation(line: 87, column: 10, scope: !301)
!304 = !DILocation(line: 87, column: 21, scope: !305)
!305 = distinct !DILexicalBlock(scope: !301, file: !7, line: 87, column: 5)
!306 = !DILocation(line: 87, column: 23, scope: !305)
!307 = !DILocation(line: 87, column: 5, scope: !301)
!308 = !DILocation(line: 87, column: 42, scope: !305)
!309 = !DILocation(line: 87, column: 34, scope: !305)
!310 = !DILocation(line: 87, column: 45, scope: !305)
!311 = !DILocation(line: 87, column: 29, scope: !305)
!312 = !DILocation(line: 87, column: 5, scope: !305)
!313 = distinct !{!313, !307, !314, !79}
!314 = !DILocation(line: 87, column: 47, scope: !301)
!315 = !DILocalVariable(name: "i", scope: !316, file: !7, line: 88, type: !65)
!316 = distinct !DILexicalBlock(scope: !267, file: !7, line: 88, column: 5)
!317 = !DILocation(line: 88, column: 14, scope: !316)
!318 = !DILocation(line: 88, column: 10, scope: !316)
!319 = !DILocation(line: 88, column: 21, scope: !320)
!320 = distinct !DILexicalBlock(scope: !316, file: !7, line: 88, column: 5)
!321 = !DILocation(line: 88, column: 23, scope: !320)
!322 = !DILocation(line: 88, column: 5, scope: !316)
!323 = !DILocation(line: 88, column: 44, scope: !320)
!324 = !DILocation(line: 88, column: 36, scope: !320)
!325 = !DILocation(line: 88, column: 47, scope: !320)
!326 = !DILocation(line: 88, column: 31, scope: !320)
!327 = !DILocation(line: 88, column: 5, scope: !320)
!328 = distinct !{!328, !322, !329, !79}
!329 = !DILocation(line: 88, column: 49, scope: !316)
!330 = !DILocalVariable(name: "i", scope: !331, file: !7, line: 89, type: !65)
!331 = distinct !DILexicalBlock(scope: !267, file: !7, line: 89, column: 5)
!332 = !DILocation(line: 89, column: 14, scope: !331)
!333 = !DILocation(line: 89, column: 10, scope: !331)
!334 = !DILocation(line: 89, column: 21, scope: !335)
!335 = distinct !DILexicalBlock(scope: !331, file: !7, line: 89, column: 5)
!336 = !DILocation(line: 89, column: 23, scope: !335)
!337 = !DILocation(line: 89, column: 5, scope: !331)
!338 = !DILocation(line: 89, column: 45, scope: !335)
!339 = !DILocation(line: 89, column: 37, scope: !335)
!340 = !DILocation(line: 89, column: 48, scope: !335)
!341 = !DILocation(line: 89, column: 32, scope: !335)
!342 = !DILocation(line: 89, column: 5, scope: !335)
!343 = distinct !{!343, !337, !344, !79}
!344 = !DILocation(line: 89, column: 50, scope: !331)
!345 = !DILocation(line: 90, column: 1, scope: !267)
