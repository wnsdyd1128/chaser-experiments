#include <stdint.h>
/** @brief Initialize all arrays once before workers start. @return None. */
void workload_prepare(void);
extern uint32_t (*const workload_jobs[])(void);
extern const uint32_t workload_expected[];
