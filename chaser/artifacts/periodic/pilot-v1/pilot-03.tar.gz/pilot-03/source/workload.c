#include "workload.h"
#ifdef __clang__
#define ANALYZE __attribute__((annotate("ape.analyze")))
#define INLINE __attribute__((annotate("ape.inline")))
#else
#define ANALYZE
#define INLINE
#endif
volatile uint8_t data_t0[64] __attribute__((aligned(4096), section(".chaser_data.00")));
INLINE static uint32_t kernel_t0(void) {
    uint32_t sum = 0;
    for (int i = 0; i < 64; i += 1)
        sum += data_t0[i];
    return sum;
}
/** @brief Execute one fixed job without resetting data or cache.
 * @return Load-count checksum, modulo 2^32. */
ANALYZE uint32_t task_job_t0(void) {
    uint32_t sum = 0;
    for (int s = 0; s < 150; ++s)
        sum += kernel_t0();
    return sum;
}
volatile uint8_t data_t1[128] __attribute__((aligned(4096), section(".chaser_data.01")));
INLINE static uint32_t kernel_t1(void) {
    uint32_t sum = 0;
    for (int i = 0; i < 128; i += 32)
        sum += data_t1[i];
    return sum;
}
/** @brief Execute one fixed job without resetting data or cache.
 * @return Load-count checksum, modulo 2^32. */
ANALYZE uint32_t task_job_t1(void) {
    uint32_t sum = 0;
    for (int s = 0; s < 2400; ++s)
        sum += kernel_t1();
    return sum;
}
volatile uint8_t data_t2[32768] __attribute__((aligned(4096), section(".chaser_data.02")));
INLINE static uint32_t kernel_t2(void) {
    uint32_t sum = 0;
    for (int i = 0; i < 32768; i += 4096)
        sum += data_t2[i];
    return sum;
}
/** @brief Execute one fixed job without resetting data or cache.
 * @return Load-count checksum, modulo 2^32. */
ANALYZE uint32_t task_job_t2(void) {
    uint32_t sum = 0;
    for (int s = 0; s < 1200; ++s)
        sum += kernel_t2();
    return sum;
}
volatile uint8_t data_t3[16] __attribute__((aligned(4096), section(".chaser_data.03")));
INLINE static uint32_t kernel_t3(void) {
    uint32_t sum = 0;
    for (int i = 0; i < 16; i += 1)
        sum += data_t3[i];
    return sum;
}
/** @brief Execute one fixed job without resetting data or cache.
 * @return Load-count checksum, modulo 2^32. */
ANALYZE uint32_t task_job_t3(void) {
    uint32_t sum = 0;
    for (int s = 0; s < 600; ++s)
        sum += kernel_t3();
    return sum;
}
void workload_prepare(void) {
    for (int i = 0; i < 64; ++i) data_t0[i] = 1;
    for (int i = 0; i < 128; ++i) data_t1[i] = 1;
    for (int i = 0; i < 32768; ++i) data_t2[i] = 1;
    for (int i = 0; i < 16; ++i) data_t3[i] = 1;
}
uint32_t (*const workload_jobs[])(void) = {
    task_job_t0,
    task_job_t1,
    task_job_t2,
    task_job_t3,
};
const uint32_t workload_expected[] = {
9600U, 9600U, 9600U, 9600U
};
