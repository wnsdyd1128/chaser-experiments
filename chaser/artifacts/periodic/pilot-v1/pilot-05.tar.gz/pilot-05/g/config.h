#define TASK_COUNT 6
#define MAX_JOBS 4
#define ARCHITECTURE 0
#define CHASER_PLAN_HASH "894457915384408fab0c14f7ca6f9c78a6cbfa9e3acacb065d3dad82677abe7c"
#define CHASER_PERIODS {20, 10, 20, 10, 20, 10}
#define CHASER_JOB_COUNTS {2, 4, 2, 4, 2, 4}
#define CHASER_CORES {0, 1, 2, 3, 0, 1}
