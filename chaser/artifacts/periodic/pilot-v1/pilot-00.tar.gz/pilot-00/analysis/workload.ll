; ModuleID = '/workspace/experiments/chaser/.cache/periodic-pilot-v1/pilot-00/source/workload.c'
source_filename = "/workspace/experiments/chaser/.cache/periodic-pilot-v1/pilot-00/source/workload.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

@.str = private unnamed_addr constant [12 x i8] c"ape.analyze\00", section "llvm.metadata"
@.str.1 = private unnamed_addr constant [82 x i8] c"/workspace/experiments/chaser/.cache/periodic-pilot-v1/pilot-00/source/workload.c\00", section "llvm.metadata"
@data_t0 = dso_local global [4 x i8] zeroinitializer, section ".chaser_data.00", align 4096, !dbg !0
@data_t1 = dso_local global [256 x i8] zeroinitializer, section ".chaser_data.01", align 4096, !dbg !24
@data_t2 = dso_local global [65536 x i8] zeroinitializer, section ".chaser_data.02", align 4096, !dbg !33
@data_t3 = dso_local global [64 x i8] zeroinitializer, section ".chaser_data.03", align 4096, !dbg !38
@workload_jobs = dso_local constant [4 x i32 ()*] [i32 ()* @task_job_t0, i32 ()* @task_job_t1, i32 ()* @task_job_t2, i32 ()* @task_job_t3], align 16, !dbg !5
@workload_expected = dso_local constant [4 x i32] [i32 9600, i32 9600, i32 9600, i32 9600], align 16, !dbg !20
@.str.2 = private unnamed_addr constant [11 x i8] c"ape.inline\00", section "llvm.metadata"
@llvm.global.annotations = appending global [8 x { i8*, i8*, i8*, i32, i8* }] [{ i8*, i8*, i8*, i32, i8* } { i8* bitcast (i32 ()* @task_job_t0 to i8*), i8* getelementptr inbounds ([12 x i8], [12 x i8]* @.str, i32 0, i32 0), i8* getelementptr inbounds ([82 x i8], [82 x i8]* @.str.1, i32 0, i32 0), i32 18, i8* null }, { i8*, i8*, i8*, i32, i8* } { i8* bitcast (i32 ()* @task_job_t1 to i8*), i8* getelementptr inbounds ([12 x i8], [12 x i8]* @.str, i32 0, i32 0), i8* getelementptr inbounds ([82 x i8], [82 x i8]* @.str.1, i32 0, i32 0), i32 33, i8* null }, { i8*, i8*, i8*, i32, i8* } { i8* bitcast (i32 ()* @task_job_t2 to i8*), i8* getelementptr inbounds ([12 x i8], [12 x i8]* @.str, i32 0, i32 0), i8* getelementptr inbounds ([82 x i8], [82 x i8]* @.str.1, i32 0, i32 0), i32 48, i8* null }, { i8*, i8*, i8*, i32, i8* } { i8* bitcast (i32 ()* @task_job_t3 to i8*), i8* getelementptr inbounds ([12 x i8], [12 x i8]* @.str, i32 0, i32 0), i8* getelementptr inbounds ([82 x i8], [82 x i8]* @.str.1, i32 0, i32 0), i32 63, i8* null }, { i8*, i8*, i8*, i32, i8* } { i8* bitcast (i32 ()* @kernel_t0 to i8*), i8* getelementptr inbounds ([11 x i8], [11 x i8]* @.str.2, i32 0, i32 0), i8* getelementptr inbounds ([82 x i8], [82 x i8]* @.str.1, i32 0, i32 0), i32 10, i8* null }, { i8*, i8*, i8*, i32, i8* } { i8* bitcast (i32 ()* @kernel_t1 to i8*), i8* getelementptr inbounds ([11 x i8], [11 x i8]* @.str.2, i32 0, i32 0), i8* getelementptr inbounds ([82 x i8], [82 x i8]* @.str.1, i32 0, i32 0), i32 25, i8* null }, { i8*, i8*, i8*, i32, i8* } { i8* bitcast (i32 ()* @kernel_t2 to i8*), i8* getelementptr inbounds ([11 x i8], [11 x i8]* @.str.2, i32 0, i32 0), i8* getelementptr inbounds ([82 x i8], [82 x i8]* @.str.1, i32 0, i32 0), i32 40, i8* null }, { i8*, i8*, i8*, i32, i8* } { i8* bitcast (i32 ()* @kernel_t3 to i8*), i8* getelementptr inbounds ([11 x i8], [11 x i8]* @.str.2, i32 0, i32 0), i8* getelementptr inbounds ([82 x i8], [82 x i8]* @.str.1, i32 0, i32 0), i32 55, i8* null }], section "llvm.metadata"

; Function Attrs: noinline nounwind uwtable
define dso_local i32 @task_job_t0() #0 !dbg !52 {
  %1 = alloca i32, align 4
  %2 = alloca i32, align 4
  call void @llvm.dbg.declare(metadata i32* %1, metadata !54, metadata !DIExpression()), !dbg !55
  store i32 0, i32* %1, align 4, !dbg !55
  call void @llvm.dbg.declare(metadata i32* %2, metadata !56, metadata !DIExpression()), !dbg !59
  store i32 0, i32* %2, align 4, !dbg !59
  br label %3, !dbg !60

3:                                                ; preds = %10, %0
  %4 = load i32, i32* %2, align 4, !dbg !61
  %5 = icmp slt i32 %4, 2400, !dbg !63
  br i1 %5, label %6, label %13, !dbg !64

6:                                                ; preds = %3
  %7 = call i32 @kernel_t0(), !dbg !65
  %8 = load i32, i32* %1, align 4, !dbg !66
  %9 = add i32 %8, %7, !dbg !66
  store i32 %9, i32* %1, align 4, !dbg !66
  br label %10, !dbg !67

10:                                               ; preds = %6
  %11 = load i32, i32* %2, align 4, !dbg !68
  %12 = add nsw i32 %11, 1, !dbg !68
  store i32 %12, i32* %2, align 4, !dbg !68
  br label %3, !dbg !69, !llvm.loop !70

13:                                               ; preds = %3
  %14 = load i32, i32* %1, align 4, !dbg !73
  ret i32 %14, !dbg !74
}

; Function Attrs: nofree nosync nounwind readnone speculatable willreturn
declare void @llvm.dbg.declare(metadata, metadata, metadata) #1

; Function Attrs: noinline nounwind uwtable
define internal i32 @kernel_t0() #0 !dbg !75 {
  %1 = alloca i32, align 4
  %2 = alloca i32, align 4
  call void @llvm.dbg.declare(metadata i32* %1, metadata !76, metadata !DIExpression()), !dbg !77
  store i32 0, i32* %1, align 4, !dbg !77
  call void @llvm.dbg.declare(metadata i32* %2, metadata !78, metadata !DIExpression()), !dbg !80
  store i32 0, i32* %2, align 4, !dbg !80
  br label %3, !dbg !81

3:                                                ; preds = %14, %0
  %4 = load i32, i32* %2, align 4, !dbg !82
  %5 = icmp slt i32 %4, 4, !dbg !84
  br i1 %5, label %6, label %17, !dbg !85

6:                                                ; preds = %3
  %7 = load i32, i32* %2, align 4, !dbg !86
  %8 = sext i32 %7 to i64, !dbg !87
  %9 = getelementptr inbounds [4 x i8], [4 x i8]* @data_t0, i64 0, i64 %8, !dbg !87
  %10 = load volatile i8, i8* %9, align 1, !dbg !87
  %11 = zext i8 %10 to i32, !dbg !87
  %12 = load i32, i32* %1, align 4, !dbg !88
  %13 = add i32 %12, %11, !dbg !88
  store i32 %13, i32* %1, align 4, !dbg !88
  br label %14, !dbg !89

14:                                               ; preds = %6
  %15 = load i32, i32* %2, align 4, !dbg !90
  %16 = add nsw i32 %15, 1, !dbg !90
  store i32 %16, i32* %2, align 4, !dbg !90
  br label %3, !dbg !91, !llvm.loop !92

17:                                               ; preds = %3
  %18 = load i32, i32* %1, align 4, !dbg !94
  ret i32 %18, !dbg !95
}

; Function Attrs: noinline nounwind uwtable
define dso_local i32 @task_job_t1() #0 !dbg !96 {
  %1 = alloca i32, align 4
  %2 = alloca i32, align 4
  call void @llvm.dbg.declare(metadata i32* %1, metadata !97, metadata !DIExpression()), !dbg !98
  store i32 0, i32* %1, align 4, !dbg !98
  call void @llvm.dbg.declare(metadata i32* %2, metadata !99, metadata !DIExpression()), !dbg !101
  store i32 0, i32* %2, align 4, !dbg !101
  br label %3, !dbg !102

3:                                                ; preds = %10, %0
  %4 = load i32, i32* %2, align 4, !dbg !103
  %5 = icmp slt i32 %4, 1200, !dbg !105
  br i1 %5, label %6, label %13, !dbg !106

6:                                                ; preds = %3
  %7 = call i32 @kernel_t1(), !dbg !107
  %8 = load i32, i32* %1, align 4, !dbg !108
  %9 = add i32 %8, %7, !dbg !108
  store i32 %9, i32* %1, align 4, !dbg !108
  br label %10, !dbg !109

10:                                               ; preds = %6
  %11 = load i32, i32* %2, align 4, !dbg !110
  %12 = add nsw i32 %11, 1, !dbg !110
  store i32 %12, i32* %2, align 4, !dbg !110
  br label %3, !dbg !111, !llvm.loop !112

13:                                               ; preds = %3
  %14 = load i32, i32* %1, align 4, !dbg !114
  ret i32 %14, !dbg !115
}

; Function Attrs: noinline nounwind uwtable
define internal i32 @kernel_t1() #0 !dbg !116 {
  %1 = alloca i32, align 4
  %2 = alloca i32, align 4
  call void @llvm.dbg.declare(metadata i32* %1, metadata !117, metadata !DIExpression()), !dbg !118
  store i32 0, i32* %1, align 4, !dbg !118
  call void @llvm.dbg.declare(metadata i32* %2, metadata !119, metadata !DIExpression()), !dbg !121
  store i32 0, i32* %2, align 4, !dbg !121
  br label %3, !dbg !122

3:                                                ; preds = %14, %0
  %4 = load i32, i32* %2, align 4, !dbg !123
  %5 = icmp slt i32 %4, 256, !dbg !125
  br i1 %5, label %6, label %17, !dbg !126

6:                                                ; preds = %3
  %7 = load i32, i32* %2, align 4, !dbg !127
  %8 = sext i32 %7 to i64, !dbg !128
  %9 = getelementptr inbounds [256 x i8], [256 x i8]* @data_t1, i64 0, i64 %8, !dbg !128
  %10 = load volatile i8, i8* %9, align 1, !dbg !128
  %11 = zext i8 %10 to i32, !dbg !128
  %12 = load i32, i32* %1, align 4, !dbg !129
  %13 = add i32 %12, %11, !dbg !129
  store i32 %13, i32* %1, align 4, !dbg !129
  br label %14, !dbg !130

14:                                               ; preds = %6
  %15 = load i32, i32* %2, align 4, !dbg !131
  %16 = add nsw i32 %15, 32, !dbg !131
  store i32 %16, i32* %2, align 4, !dbg !131
  br label %3, !dbg !132, !llvm.loop !133

17:                                               ; preds = %3
  %18 = load i32, i32* %1, align 4, !dbg !135
  ret i32 %18, !dbg !136
}

; Function Attrs: noinline nounwind uwtable
define dso_local i32 @task_job_t2() #0 !dbg !137 {
  %1 = alloca i32, align 4
  %2 = alloca i32, align 4
  call void @llvm.dbg.declare(metadata i32* %1, metadata !138, metadata !DIExpression()), !dbg !139
  store i32 0, i32* %1, align 4, !dbg !139
  call void @llvm.dbg.declare(metadata i32* %2, metadata !140, metadata !DIExpression()), !dbg !142
  store i32 0, i32* %2, align 4, !dbg !142
  br label %3, !dbg !143

3:                                                ; preds = %10, %0
  %4 = load i32, i32* %2, align 4, !dbg !144
  %5 = icmp slt i32 %4, 600, !dbg !146
  br i1 %5, label %6, label %13, !dbg !147

6:                                                ; preds = %3
  %7 = call i32 @kernel_t2(), !dbg !148
  %8 = load i32, i32* %1, align 4, !dbg !149
  %9 = add i32 %8, %7, !dbg !149
  store i32 %9, i32* %1, align 4, !dbg !149
  br label %10, !dbg !150

10:                                               ; preds = %6
  %11 = load i32, i32* %2, align 4, !dbg !151
  %12 = add nsw i32 %11, 1, !dbg !151
  store i32 %12, i32* %2, align 4, !dbg !151
  br label %3, !dbg !152, !llvm.loop !153

13:                                               ; preds = %3
  %14 = load i32, i32* %1, align 4, !dbg !155
  ret i32 %14, !dbg !156
}

; Function Attrs: noinline nounwind uwtable
define internal i32 @kernel_t2() #0 !dbg !157 {
  %1 = alloca i32, align 4
  %2 = alloca i32, align 4
  call void @llvm.dbg.declare(metadata i32* %1, metadata !158, metadata !DIExpression()), !dbg !159
  store i32 0, i32* %1, align 4, !dbg !159
  call void @llvm.dbg.declare(metadata i32* %2, metadata !160, metadata !DIExpression()), !dbg !162
  store i32 0, i32* %2, align 4, !dbg !162
  br label %3, !dbg !163

3:                                                ; preds = %14, %0
  %4 = load i32, i32* %2, align 4, !dbg !164
  %5 = icmp slt i32 %4, 65536, !dbg !166
  br i1 %5, label %6, label %17, !dbg !167

6:                                                ; preds = %3
  %7 = load i32, i32* %2, align 4, !dbg !168
  %8 = sext i32 %7 to i64, !dbg !169
  %9 = getelementptr inbounds [65536 x i8], [65536 x i8]* @data_t2, i64 0, i64 %8, !dbg !169
  %10 = load volatile i8, i8* %9, align 1, !dbg !169
  %11 = zext i8 %10 to i32, !dbg !169
  %12 = load i32, i32* %1, align 4, !dbg !170
  %13 = add i32 %12, %11, !dbg !170
  store i32 %13, i32* %1, align 4, !dbg !170
  br label %14, !dbg !171

14:                                               ; preds = %6
  %15 = load i32, i32* %2, align 4, !dbg !172
  %16 = add nsw i32 %15, 4096, !dbg !172
  store i32 %16, i32* %2, align 4, !dbg !172
  br label %3, !dbg !173, !llvm.loop !174

17:                                               ; preds = %3
  %18 = load i32, i32* %1, align 4, !dbg !176
  ret i32 %18, !dbg !177
}

; Function Attrs: noinline nounwind uwtable
define dso_local i32 @task_job_t3() #0 !dbg !178 {
  %1 = alloca i32, align 4
  %2 = alloca i32, align 4
  call void @llvm.dbg.declare(metadata i32* %1, metadata !179, metadata !DIExpression()), !dbg !180
  store i32 0, i32* %1, align 4, !dbg !180
  call void @llvm.dbg.declare(metadata i32* %2, metadata !181, metadata !DIExpression()), !dbg !183
  store i32 0, i32* %2, align 4, !dbg !183
  br label %3, !dbg !184

3:                                                ; preds = %10, %0
  %4 = load i32, i32* %2, align 4, !dbg !185
  %5 = icmp slt i32 %4, 150, !dbg !187
  br i1 %5, label %6, label %13, !dbg !188

6:                                                ; preds = %3
  %7 = call i32 @kernel_t3(), !dbg !189
  %8 = load i32, i32* %1, align 4, !dbg !190
  %9 = add i32 %8, %7, !dbg !190
  store i32 %9, i32* %1, align 4, !dbg !190
  br label %10, !dbg !191

10:                                               ; preds = %6
  %11 = load i32, i32* %2, align 4, !dbg !192
  %12 = add nsw i32 %11, 1, !dbg !192
  store i32 %12, i32* %2, align 4, !dbg !192
  br label %3, !dbg !193, !llvm.loop !194

13:                                               ; preds = %3
  %14 = load i32, i32* %1, align 4, !dbg !196
  ret i32 %14, !dbg !197
}

; Function Attrs: noinline nounwind uwtable
define internal i32 @kernel_t3() #0 !dbg !198 {
  %1 = alloca i32, align 4
  %2 = alloca i32, align 4
  call void @llvm.dbg.declare(metadata i32* %1, metadata !199, metadata !DIExpression()), !dbg !200
  store i32 0, i32* %1, align 4, !dbg !200
  call void @llvm.dbg.declare(metadata i32* %2, metadata !201, metadata !DIExpression()), !dbg !203
  store i32 0, i32* %2, align 4, !dbg !203
  br label %3, !dbg !204

3:                                                ; preds = %14, %0
  %4 = load i32, i32* %2, align 4, !dbg !205
  %5 = icmp slt i32 %4, 64, !dbg !207
  br i1 %5, label %6, label %17, !dbg !208

6:                                                ; preds = %3
  %7 = load i32, i32* %2, align 4, !dbg !209
  %8 = sext i32 %7 to i64, !dbg !210
  %9 = getelementptr inbounds [64 x i8], [64 x i8]* @data_t3, i64 0, i64 %8, !dbg !210
  %10 = load volatile i8, i8* %9, align 1, !dbg !210
  %11 = zext i8 %10 to i32, !dbg !210
  %12 = load i32, i32* %1, align 4, !dbg !211
  %13 = add i32 %12, %11, !dbg !211
  store i32 %13, i32* %1, align 4, !dbg !211
  br label %14, !dbg !212

14:                                               ; preds = %6
  %15 = load i32, i32* %2, align 4, !dbg !213
  %16 = add nsw i32 %15, 1, !dbg !213
  store i32 %16, i32* %2, align 4, !dbg !213
  br label %3, !dbg !214, !llvm.loop !215

17:                                               ; preds = %3
  %18 = load i32, i32* %1, align 4, !dbg !217
  ret i32 %18, !dbg !218
}

; Function Attrs: noinline nounwind uwtable
define dso_local void @workload_prepare() #0 !dbg !219 {
  %1 = alloca i32, align 4
  %2 = alloca i32, align 4
  %3 = alloca i32, align 4
  %4 = alloca i32, align 4
  call void @llvm.dbg.declare(metadata i32* %1, metadata !222, metadata !DIExpression()), !dbg !224
  store i32 0, i32* %1, align 4, !dbg !224
  br label %5, !dbg !225

5:                                                ; preds = %12, %0
  %6 = load i32, i32* %1, align 4, !dbg !226
  %7 = icmp slt i32 %6, 4, !dbg !228
  br i1 %7, label %8, label %15, !dbg !229

8:                                                ; preds = %5
  %9 = load i32, i32* %1, align 4, !dbg !230
  %10 = sext i32 %9 to i64, !dbg !231
  %11 = getelementptr inbounds [4 x i8], [4 x i8]* @data_t0, i64 0, i64 %10, !dbg !231
  store volatile i8 1, i8* %11, align 1, !dbg !232
  br label %12, !dbg !231

12:                                               ; preds = %8
  %13 = load i32, i32* %1, align 4, !dbg !233
  %14 = add nsw i32 %13, 1, !dbg !233
  store i32 %14, i32* %1, align 4, !dbg !233
  br label %5, !dbg !234, !llvm.loop !235

15:                                               ; preds = %5
  call void @llvm.dbg.declare(metadata i32* %2, metadata !237, metadata !DIExpression()), !dbg !239
  store i32 0, i32* %2, align 4, !dbg !239
  br label %16, !dbg !240

16:                                               ; preds = %23, %15
  %17 = load i32, i32* %2, align 4, !dbg !241
  %18 = icmp slt i32 %17, 256, !dbg !243
  br i1 %18, label %19, label %26, !dbg !244

19:                                               ; preds = %16
  %20 = load i32, i32* %2, align 4, !dbg !245
  %21 = sext i32 %20 to i64, !dbg !246
  %22 = getelementptr inbounds [256 x i8], [256 x i8]* @data_t1, i64 0, i64 %21, !dbg !246
  store volatile i8 1, i8* %22, align 1, !dbg !247
  br label %23, !dbg !246

23:                                               ; preds = %19
  %24 = load i32, i32* %2, align 4, !dbg !248
  %25 = add nsw i32 %24, 1, !dbg !248
  store i32 %25, i32* %2, align 4, !dbg !248
  br label %16, !dbg !249, !llvm.loop !250

26:                                               ; preds = %16
  call void @llvm.dbg.declare(metadata i32* %3, metadata !252, metadata !DIExpression()), !dbg !254
  store i32 0, i32* %3, align 4, !dbg !254
  br label %27, !dbg !255

27:                                               ; preds = %34, %26
  %28 = load i32, i32* %3, align 4, !dbg !256
  %29 = icmp slt i32 %28, 65536, !dbg !258
  br i1 %29, label %30, label %37, !dbg !259

30:                                               ; preds = %27
  %31 = load i32, i32* %3, align 4, !dbg !260
  %32 = sext i32 %31 to i64, !dbg !261
  %33 = getelementptr inbounds [65536 x i8], [65536 x i8]* @data_t2, i64 0, i64 %32, !dbg !261
  store volatile i8 1, i8* %33, align 1, !dbg !262
  br label %34, !dbg !261

34:                                               ; preds = %30
  %35 = load i32, i32* %3, align 4, !dbg !263
  %36 = add nsw i32 %35, 1, !dbg !263
  store i32 %36, i32* %3, align 4, !dbg !263
  br label %27, !dbg !264, !llvm.loop !265

37:                                               ; preds = %27
  call void @llvm.dbg.declare(metadata i32* %4, metadata !267, metadata !DIExpression()), !dbg !269
  store i32 0, i32* %4, align 4, !dbg !269
  br label %38, !dbg !270

38:                                               ; preds = %45, %37
  %39 = load i32, i32* %4, align 4, !dbg !271
  %40 = icmp slt i32 %39, 64, !dbg !273
  br i1 %40, label %41, label %48, !dbg !274

41:                                               ; preds = %38
  %42 = load i32, i32* %4, align 4, !dbg !275
  %43 = sext i32 %42 to i64, !dbg !276
  %44 = getelementptr inbounds [64 x i8], [64 x i8]* @data_t3, i64 0, i64 %43, !dbg !276
  store volatile i8 1, i8* %44, align 1, !dbg !277
  br label %45, !dbg !276

45:                                               ; preds = %41
  %46 = load i32, i32* %4, align 4, !dbg !278
  %47 = add nsw i32 %46, 1, !dbg !278
  store i32 %47, i32* %4, align 4, !dbg !278
  br label %38, !dbg !279, !llvm.loop !280

48:                                               ; preds = %38
  ret void, !dbg !282
}

attributes #0 = { noinline nounwind uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { nofree nosync nounwind readnone speculatable willreturn }

!llvm.dbg.cu = !{!2}
!llvm.module.flags = !{!44, !45, !46, !47, !48, !49, !50}
!llvm.ident = !{!51}

!0 = !DIGlobalVariableExpression(var: !1, expr: !DIExpression())
!1 = distinct !DIGlobalVariable(name: "data_t0", scope: !2, file: !7, line: 9, type: !43, isLocal: false, isDefinition: true, align: 32768)
!2 = distinct !DICompileUnit(language: DW_LANG_C99, file: !3, producer: "Ubuntu clang version 14.0.0-1ubuntu1.1", isOptimized: false, runtimeVersion: 0, emissionKind: FullDebug, globals: !4, splitDebugInlining: false, nameTableKind: None)
!3 = !DIFile(filename: "/workspace/experiments/chaser/.cache/periodic-pilot-v1/pilot-00/source/workload.c", directory: "/workspace/experiments/chaser/.cache/periodic-pilot-v1/pilot-00/analysis", checksumkind: CSK_MD5, checksum: "d4409047b93443ea1f3812d8e87c3a1b")
!4 = !{!5, !20, !0, !24, !33, !38}
!5 = !DIGlobalVariableExpression(var: !6, expr: !DIExpression())
!6 = distinct !DIGlobalVariable(name: "workload_jobs", scope: !2, file: !7, line: 75, type: !8, isLocal: false, isDefinition: true)
!7 = !DIFile(filename: "source/workload.c", directory: "/workspace/experiments/chaser/.cache/periodic-pilot-v1/pilot-00", checksumkind: CSK_MD5, checksum: "d4409047b93443ea1f3812d8e87c3a1b")
!8 = !DICompositeType(tag: DW_TAG_array_type, baseType: !9, size: 256, elements: !18)
!9 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !10)
!10 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !11, size: 64)
!11 = !DISubroutineType(types: !12)
!12 = !{!13}
!13 = !DIDerivedType(tag: DW_TAG_typedef, name: "uint32_t", file: !14, line: 26, baseType: !15)
!14 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/stdint-uintn.h", directory: "", checksumkind: CSK_MD5, checksum: "2bf2ae53c58c01b1a1b9383b5195125c")
!15 = !DIDerivedType(tag: DW_TAG_typedef, name: "__uint32_t", file: !16, line: 42, baseType: !17)
!16 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/types.h", directory: "", checksumkind: CSK_MD5, checksum: "d108b5f93a74c50510d7d9bc0ab36df9")
!17 = !DIBasicType(name: "unsigned int", size: 32, encoding: DW_ATE_unsigned)
!18 = !{!19}
!19 = !DISubrange(count: 4)
!20 = !DIGlobalVariableExpression(var: !21, expr: !DIExpression())
!21 = distinct !DIGlobalVariable(name: "workload_expected", scope: !2, file: !7, line: 81, type: !22, isLocal: false, isDefinition: true)
!22 = !DICompositeType(tag: DW_TAG_array_type, baseType: !23, size: 128, elements: !18)
!23 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !13)
!24 = !DIGlobalVariableExpression(var: !25, expr: !DIExpression())
!25 = distinct !DIGlobalVariable(name: "data_t1", scope: !2, file: !7, line: 24, type: !26, isLocal: false, isDefinition: true, align: 32768)
!26 = !DICompositeType(tag: DW_TAG_array_type, baseType: !27, size: 2048, elements: !31)
!27 = !DIDerivedType(tag: DW_TAG_volatile_type, baseType: !28)
!28 = !DIDerivedType(tag: DW_TAG_typedef, name: "uint8_t", file: !14, line: 24, baseType: !29)
!29 = !DIDerivedType(tag: DW_TAG_typedef, name: "__uint8_t", file: !16, line: 38, baseType: !30)
!30 = !DIBasicType(name: "unsigned char", size: 8, encoding: DW_ATE_unsigned_char)
!31 = !{!32}
!32 = !DISubrange(count: 256)
!33 = !DIGlobalVariableExpression(var: !34, expr: !DIExpression())
!34 = distinct !DIGlobalVariable(name: "data_t2", scope: !2, file: !7, line: 39, type: !35, isLocal: false, isDefinition: true, align: 32768)
!35 = !DICompositeType(tag: DW_TAG_array_type, baseType: !27, size: 524288, elements: !36)
!36 = !{!37}
!37 = !DISubrange(count: 65536)
!38 = !DIGlobalVariableExpression(var: !39, expr: !DIExpression())
!39 = distinct !DIGlobalVariable(name: "data_t3", scope: !2, file: !7, line: 54, type: !40, isLocal: false, isDefinition: true, align: 32768)
!40 = !DICompositeType(tag: DW_TAG_array_type, baseType: !27, size: 512, elements: !41)
!41 = !{!42}
!42 = !DISubrange(count: 64)
!43 = !DICompositeType(tag: DW_TAG_array_type, baseType: !27, size: 32, elements: !18)
!44 = !{i32 7, !"Dwarf Version", i32 5}
!45 = !{i32 2, !"Debug Info Version", i32 3}
!46 = !{i32 1, !"wchar_size", i32 4}
!47 = !{i32 7, !"PIC Level", i32 2}
!48 = !{i32 7, !"PIE Level", i32 2}
!49 = !{i32 7, !"uwtable", i32 1}
!50 = !{i32 7, !"frame-pointer", i32 2}
!51 = !{!"Ubuntu clang version 14.0.0-1ubuntu1.1"}
!52 = distinct !DISubprogram(name: "task_job_t0", scope: !7, file: !7, line: 18, type: !11, scopeLine: 18, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !2, retainedNodes: !53)
!53 = !{}
!54 = !DILocalVariable(name: "sum", scope: !52, file: !7, line: 19, type: !13)
!55 = !DILocation(line: 19, column: 14, scope: !52)
!56 = !DILocalVariable(name: "s", scope: !57, file: !7, line: 20, type: !58)
!57 = distinct !DILexicalBlock(scope: !52, file: !7, line: 20, column: 5)
!58 = !DIBasicType(name: "int", size: 32, encoding: DW_ATE_signed)
!59 = !DILocation(line: 20, column: 14, scope: !57)
!60 = !DILocation(line: 20, column: 10, scope: !57)
!61 = !DILocation(line: 20, column: 21, scope: !62)
!62 = distinct !DILexicalBlock(scope: !57, file: !7, line: 20, column: 5)
!63 = !DILocation(line: 20, column: 23, scope: !62)
!64 = !DILocation(line: 20, column: 5, scope: !57)
!65 = !DILocation(line: 21, column: 16, scope: !62)
!66 = !DILocation(line: 21, column: 13, scope: !62)
!67 = !DILocation(line: 21, column: 9, scope: !62)
!68 = !DILocation(line: 20, column: 31, scope: !62)
!69 = !DILocation(line: 20, column: 5, scope: !62)
!70 = distinct !{!70, !64, !71, !72}
!71 = !DILocation(line: 21, column: 26, scope: !57)
!72 = !{!"llvm.loop.mustprogress"}
!73 = !DILocation(line: 22, column: 12, scope: !52)
!74 = !DILocation(line: 22, column: 5, scope: !52)
!75 = distinct !DISubprogram(name: "kernel_t0", scope: !7, file: !7, line: 10, type: !11, scopeLine: 10, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition, unit: !2, retainedNodes: !53)
!76 = !DILocalVariable(name: "sum", scope: !75, file: !7, line: 11, type: !13)
!77 = !DILocation(line: 11, column: 14, scope: !75)
!78 = !DILocalVariable(name: "i", scope: !79, file: !7, line: 12, type: !58)
!79 = distinct !DILexicalBlock(scope: !75, file: !7, line: 12, column: 5)
!80 = !DILocation(line: 12, column: 14, scope: !79)
!81 = !DILocation(line: 12, column: 10, scope: !79)
!82 = !DILocation(line: 12, column: 21, scope: !83)
!83 = distinct !DILexicalBlock(scope: !79, file: !7, line: 12, column: 5)
!84 = !DILocation(line: 12, column: 23, scope: !83)
!85 = !DILocation(line: 12, column: 5, scope: !79)
!86 = !DILocation(line: 13, column: 24, scope: !83)
!87 = !DILocation(line: 13, column: 16, scope: !83)
!88 = !DILocation(line: 13, column: 13, scope: !83)
!89 = !DILocation(line: 13, column: 9, scope: !83)
!90 = !DILocation(line: 12, column: 30, scope: !83)
!91 = !DILocation(line: 12, column: 5, scope: !83)
!92 = distinct !{!92, !85, !93, !72}
!93 = !DILocation(line: 13, column: 25, scope: !79)
!94 = !DILocation(line: 14, column: 12, scope: !75)
!95 = !DILocation(line: 14, column: 5, scope: !75)
!96 = distinct !DISubprogram(name: "task_job_t1", scope: !7, file: !7, line: 33, type: !11, scopeLine: 33, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !2, retainedNodes: !53)
!97 = !DILocalVariable(name: "sum", scope: !96, file: !7, line: 34, type: !13)
!98 = !DILocation(line: 34, column: 14, scope: !96)
!99 = !DILocalVariable(name: "s", scope: !100, file: !7, line: 35, type: !58)
!100 = distinct !DILexicalBlock(scope: !96, file: !7, line: 35, column: 5)
!101 = !DILocation(line: 35, column: 14, scope: !100)
!102 = !DILocation(line: 35, column: 10, scope: !100)
!103 = !DILocation(line: 35, column: 21, scope: !104)
!104 = distinct !DILexicalBlock(scope: !100, file: !7, line: 35, column: 5)
!105 = !DILocation(line: 35, column: 23, scope: !104)
!106 = !DILocation(line: 35, column: 5, scope: !100)
!107 = !DILocation(line: 36, column: 16, scope: !104)
!108 = !DILocation(line: 36, column: 13, scope: !104)
!109 = !DILocation(line: 36, column: 9, scope: !104)
!110 = !DILocation(line: 35, column: 31, scope: !104)
!111 = !DILocation(line: 35, column: 5, scope: !104)
!112 = distinct !{!112, !106, !113, !72}
!113 = !DILocation(line: 36, column: 26, scope: !100)
!114 = !DILocation(line: 37, column: 12, scope: !96)
!115 = !DILocation(line: 37, column: 5, scope: !96)
!116 = distinct !DISubprogram(name: "kernel_t1", scope: !7, file: !7, line: 25, type: !11, scopeLine: 25, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition, unit: !2, retainedNodes: !53)
!117 = !DILocalVariable(name: "sum", scope: !116, file: !7, line: 26, type: !13)
!118 = !DILocation(line: 26, column: 14, scope: !116)
!119 = !DILocalVariable(name: "i", scope: !120, file: !7, line: 27, type: !58)
!120 = distinct !DILexicalBlock(scope: !116, file: !7, line: 27, column: 5)
!121 = !DILocation(line: 27, column: 14, scope: !120)
!122 = !DILocation(line: 27, column: 10, scope: !120)
!123 = !DILocation(line: 27, column: 21, scope: !124)
!124 = distinct !DILexicalBlock(scope: !120, file: !7, line: 27, column: 5)
!125 = !DILocation(line: 27, column: 23, scope: !124)
!126 = !DILocation(line: 27, column: 5, scope: !120)
!127 = !DILocation(line: 28, column: 24, scope: !124)
!128 = !DILocation(line: 28, column: 16, scope: !124)
!129 = !DILocation(line: 28, column: 13, scope: !124)
!130 = !DILocation(line: 28, column: 9, scope: !124)
!131 = !DILocation(line: 27, column: 32, scope: !124)
!132 = !DILocation(line: 27, column: 5, scope: !124)
!133 = distinct !{!133, !126, !134, !72}
!134 = !DILocation(line: 28, column: 25, scope: !120)
!135 = !DILocation(line: 29, column: 12, scope: !116)
!136 = !DILocation(line: 29, column: 5, scope: !116)
!137 = distinct !DISubprogram(name: "task_job_t2", scope: !7, file: !7, line: 48, type: !11, scopeLine: 48, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !2, retainedNodes: !53)
!138 = !DILocalVariable(name: "sum", scope: !137, file: !7, line: 49, type: !13)
!139 = !DILocation(line: 49, column: 14, scope: !137)
!140 = !DILocalVariable(name: "s", scope: !141, file: !7, line: 50, type: !58)
!141 = distinct !DILexicalBlock(scope: !137, file: !7, line: 50, column: 5)
!142 = !DILocation(line: 50, column: 14, scope: !141)
!143 = !DILocation(line: 50, column: 10, scope: !141)
!144 = !DILocation(line: 50, column: 21, scope: !145)
!145 = distinct !DILexicalBlock(scope: !141, file: !7, line: 50, column: 5)
!146 = !DILocation(line: 50, column: 23, scope: !145)
!147 = !DILocation(line: 50, column: 5, scope: !141)
!148 = !DILocation(line: 51, column: 16, scope: !145)
!149 = !DILocation(line: 51, column: 13, scope: !145)
!150 = !DILocation(line: 51, column: 9, scope: !145)
!151 = !DILocation(line: 50, column: 30, scope: !145)
!152 = !DILocation(line: 50, column: 5, scope: !145)
!153 = distinct !{!153, !147, !154, !72}
!154 = !DILocation(line: 51, column: 26, scope: !141)
!155 = !DILocation(line: 52, column: 12, scope: !137)
!156 = !DILocation(line: 52, column: 5, scope: !137)
!157 = distinct !DISubprogram(name: "kernel_t2", scope: !7, file: !7, line: 40, type: !11, scopeLine: 40, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition, unit: !2, retainedNodes: !53)
!158 = !DILocalVariable(name: "sum", scope: !157, file: !7, line: 41, type: !13)
!159 = !DILocation(line: 41, column: 14, scope: !157)
!160 = !DILocalVariable(name: "i", scope: !161, file: !7, line: 42, type: !58)
!161 = distinct !DILexicalBlock(scope: !157, file: !7, line: 42, column: 5)
!162 = !DILocation(line: 42, column: 14, scope: !161)
!163 = !DILocation(line: 42, column: 10, scope: !161)
!164 = !DILocation(line: 42, column: 21, scope: !165)
!165 = distinct !DILexicalBlock(scope: !161, file: !7, line: 42, column: 5)
!166 = !DILocation(line: 42, column: 23, scope: !165)
!167 = !DILocation(line: 42, column: 5, scope: !161)
!168 = !DILocation(line: 43, column: 24, scope: !165)
!169 = !DILocation(line: 43, column: 16, scope: !165)
!170 = !DILocation(line: 43, column: 13, scope: !165)
!171 = !DILocation(line: 43, column: 9, scope: !165)
!172 = !DILocation(line: 42, column: 34, scope: !165)
!173 = !DILocation(line: 42, column: 5, scope: !165)
!174 = distinct !{!174, !167, !175, !72}
!175 = !DILocation(line: 43, column: 25, scope: !161)
!176 = !DILocation(line: 44, column: 12, scope: !157)
!177 = !DILocation(line: 44, column: 5, scope: !157)
!178 = distinct !DISubprogram(name: "task_job_t3", scope: !7, file: !7, line: 63, type: !11, scopeLine: 63, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !2, retainedNodes: !53)
!179 = !DILocalVariable(name: "sum", scope: !178, file: !7, line: 64, type: !13)
!180 = !DILocation(line: 64, column: 14, scope: !178)
!181 = !DILocalVariable(name: "s", scope: !182, file: !7, line: 65, type: !58)
!182 = distinct !DILexicalBlock(scope: !178, file: !7, line: 65, column: 5)
!183 = !DILocation(line: 65, column: 14, scope: !182)
!184 = !DILocation(line: 65, column: 10, scope: !182)
!185 = !DILocation(line: 65, column: 21, scope: !186)
!186 = distinct !DILexicalBlock(scope: !182, file: !7, line: 65, column: 5)
!187 = !DILocation(line: 65, column: 23, scope: !186)
!188 = !DILocation(line: 65, column: 5, scope: !182)
!189 = !DILocation(line: 66, column: 16, scope: !186)
!190 = !DILocation(line: 66, column: 13, scope: !186)
!191 = !DILocation(line: 66, column: 9, scope: !186)
!192 = !DILocation(line: 65, column: 30, scope: !186)
!193 = !DILocation(line: 65, column: 5, scope: !186)
!194 = distinct !{!194, !188, !195, !72}
!195 = !DILocation(line: 66, column: 26, scope: !182)
!196 = !DILocation(line: 67, column: 12, scope: !178)
!197 = !DILocation(line: 67, column: 5, scope: !178)
!198 = distinct !DISubprogram(name: "kernel_t3", scope: !7, file: !7, line: 55, type: !11, scopeLine: 55, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition, unit: !2, retainedNodes: !53)
!199 = !DILocalVariable(name: "sum", scope: !198, file: !7, line: 56, type: !13)
!200 = !DILocation(line: 56, column: 14, scope: !198)
!201 = !DILocalVariable(name: "i", scope: !202, file: !7, line: 57, type: !58)
!202 = distinct !DILexicalBlock(scope: !198, file: !7, line: 57, column: 5)
!203 = !DILocation(line: 57, column: 14, scope: !202)
!204 = !DILocation(line: 57, column: 10, scope: !202)
!205 = !DILocation(line: 57, column: 21, scope: !206)
!206 = distinct !DILexicalBlock(scope: !202, file: !7, line: 57, column: 5)
!207 = !DILocation(line: 57, column: 23, scope: !206)
!208 = !DILocation(line: 57, column: 5, scope: !202)
!209 = !DILocation(line: 58, column: 24, scope: !206)
!210 = !DILocation(line: 58, column: 16, scope: !206)
!211 = !DILocation(line: 58, column: 13, scope: !206)
!212 = !DILocation(line: 58, column: 9, scope: !206)
!213 = !DILocation(line: 57, column: 31, scope: !206)
!214 = !DILocation(line: 57, column: 5, scope: !206)
!215 = distinct !{!215, !208, !216, !72}
!216 = !DILocation(line: 58, column: 25, scope: !202)
!217 = !DILocation(line: 59, column: 12, scope: !198)
!218 = !DILocation(line: 59, column: 5, scope: !198)
!219 = distinct !DISubprogram(name: "workload_prepare", scope: !7, file: !7, line: 69, type: !220, scopeLine: 69, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !2, retainedNodes: !53)
!220 = !DISubroutineType(types: !221)
!221 = !{null}
!222 = !DILocalVariable(name: "i", scope: !223, file: !7, line: 70, type: !58)
!223 = distinct !DILexicalBlock(scope: !219, file: !7, line: 70, column: 5)
!224 = !DILocation(line: 70, column: 14, scope: !223)
!225 = !DILocation(line: 70, column: 10, scope: !223)
!226 = !DILocation(line: 70, column: 21, scope: !227)
!227 = distinct !DILexicalBlock(scope: !223, file: !7, line: 70, column: 5)
!228 = !DILocation(line: 70, column: 23, scope: !227)
!229 = !DILocation(line: 70, column: 5, scope: !223)
!230 = !DILocation(line: 70, column: 41, scope: !227)
!231 = !DILocation(line: 70, column: 33, scope: !227)
!232 = !DILocation(line: 70, column: 44, scope: !227)
!233 = !DILocation(line: 70, column: 28, scope: !227)
!234 = !DILocation(line: 70, column: 5, scope: !227)
!235 = distinct !{!235, !229, !236, !72}
!236 = !DILocation(line: 70, column: 46, scope: !223)
!237 = !DILocalVariable(name: "i", scope: !238, file: !7, line: 71, type: !58)
!238 = distinct !DILexicalBlock(scope: !219, file: !7, line: 71, column: 5)
!239 = !DILocation(line: 71, column: 14, scope: !238)
!240 = !DILocation(line: 71, column: 10, scope: !238)
!241 = !DILocation(line: 71, column: 21, scope: !242)
!242 = distinct !DILexicalBlock(scope: !238, file: !7, line: 71, column: 5)
!243 = !DILocation(line: 71, column: 23, scope: !242)
!244 = !DILocation(line: 71, column: 5, scope: !238)
!245 = !DILocation(line: 71, column: 43, scope: !242)
!246 = !DILocation(line: 71, column: 35, scope: !242)
!247 = !DILocation(line: 71, column: 46, scope: !242)
!248 = !DILocation(line: 71, column: 30, scope: !242)
!249 = !DILocation(line: 71, column: 5, scope: !242)
!250 = distinct !{!250, !244, !251, !72}
!251 = !DILocation(line: 71, column: 48, scope: !238)
!252 = !DILocalVariable(name: "i", scope: !253, file: !7, line: 72, type: !58)
!253 = distinct !DILexicalBlock(scope: !219, file: !7, line: 72, column: 5)
!254 = !DILocation(line: 72, column: 14, scope: !253)
!255 = !DILocation(line: 72, column: 10, scope: !253)
!256 = !DILocation(line: 72, column: 21, scope: !257)
!257 = distinct !DILexicalBlock(scope: !253, file: !7, line: 72, column: 5)
!258 = !DILocation(line: 72, column: 23, scope: !257)
!259 = !DILocation(line: 72, column: 5, scope: !253)
!260 = !DILocation(line: 72, column: 45, scope: !257)
!261 = !DILocation(line: 72, column: 37, scope: !257)
!262 = !DILocation(line: 72, column: 48, scope: !257)
!263 = !DILocation(line: 72, column: 32, scope: !257)
!264 = !DILocation(line: 72, column: 5, scope: !257)
!265 = distinct !{!265, !259, !266, !72}
!266 = !DILocation(line: 72, column: 50, scope: !253)
!267 = !DILocalVariable(name: "i", scope: !268, file: !7, line: 73, type: !58)
!268 = distinct !DILexicalBlock(scope: !219, file: !7, line: 73, column: 5)
!269 = !DILocation(line: 73, column: 14, scope: !268)
!270 = !DILocation(line: 73, column: 10, scope: !268)
!271 = !DILocation(line: 73, column: 21, scope: !272)
!272 = distinct !DILexicalBlock(scope: !268, file: !7, line: 73, column: 5)
!273 = !DILocation(line: 73, column: 23, scope: !272)
!274 = !DILocation(line: 73, column: 5, scope: !268)
!275 = !DILocation(line: 73, column: 42, scope: !272)
!276 = !DILocation(line: 73, column: 34, scope: !272)
!277 = !DILocation(line: 73, column: 45, scope: !272)
!278 = !DILocation(line: 73, column: 29, scope: !272)
!279 = !DILocation(line: 73, column: 5, scope: !272)
!280 = distinct !{!280, !274, !281, !72}
!281 = !DILocation(line: 73, column: 47, scope: !268)
!282 = !DILocation(line: 74, column: 1, scope: !219)
