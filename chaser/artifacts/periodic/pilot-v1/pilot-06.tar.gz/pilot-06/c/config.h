#define TASK_COUNT 4
#define MAX_JOBS 4
#define ARCHITECTURE 1
#define CHASER_PLAN_HASH "1afa4d659aab7111ebae2a8abd34b69688a5bff1eaf5d308f66f29fcdcd77c33"
#define CHASER_PERIODS {10, 20, 10, 20}
#define CHASER_JOB_COUNTS {4, 2, 4, 2}
#define CHASER_CORES {0, 1, 2, 3}
