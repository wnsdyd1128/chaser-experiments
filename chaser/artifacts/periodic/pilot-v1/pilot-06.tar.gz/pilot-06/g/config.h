#define TASK_COUNT 4
#define MAX_JOBS 4
#define ARCHITECTURE 0
#define CHASER_PLAN_HASH "c75ef4fca3a28fbd3655f12566e6dfafae4e83638b7a05b2bfe2ad0d772fe774"
#define CHASER_PERIODS {10, 20, 10, 20}
#define CHASER_JOB_COUNTS {4, 2, 4, 2}
#define CHASER_CORES {0, 1, 2, 3}
