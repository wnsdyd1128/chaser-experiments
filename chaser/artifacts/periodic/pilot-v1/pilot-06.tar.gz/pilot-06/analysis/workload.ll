; ModuleID = '/workspace/experiments/chaser/.cache/periodic-pilot-v1/pilot-06/source/workload.c'
source_filename = "/workspace/experiments/chaser/.cache/periodic-pilot-v1/pilot-06/source/workload.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

@.str = private unnamed_addr constant [12 x i8] c"ape.analyze\00", section "llvm.metadata"
@.str.1 = private unnamed_addr constant [82 x i8] c"/workspace/experiments/chaser/.cache/periodic-pilot-v1/pilot-06/source/workload.c\00", section "llvm.metadata"
@data_t0 = dso_local global [16 x i8] zeroinitializer, section ".chaser_data.00", align 4096, !dbg !0
@data_t1 = dso_local global [2048 x i8] zeroinitializer, section ".chaser_data.01", align 4096, !dbg !24
@data_t2 = dso_local global [16384 x i8] zeroinitializer, section ".chaser_data.02", align 4096, !dbg !33
@data_t3 = dso_local global [8 x i8] zeroinitializer, section ".chaser_data.03", align 4096, !dbg !38
@workload_jobs = dso_local constant [4 x i32 ()*] [i32 ()* @task_job_t0, i32 ()* @task_job_t1, i32 ()* @task_job_t2, i32 ()* @task_job_t3], align 16, !dbg !5
@workload_expected = dso_local constant [4 x i32] [i32 9600, i32 9600, i32 9600, i32 9600], align 16, !dbg !20
@.str.2 = private unnamed_addr constant [11 x i8] c"ape.inline\00", section "llvm.metadata"
@llvm.global.annotations = appending global [8 x { i8*, i8*, i8*, i32, i8* }] [{ i8*, i8*, i8*, i32, i8* } { i8* bitcast (i32 ()* @task_job_t0 to i8*), i8* getelementptr inbounds ([12 x i8], [12 x i8]* @.str, i32 0, i32 0), i8* getelementptr inbounds ([82 x i8], [82 x i8]* @.str.1, i32 0, i32 0), i32 18, i8* null }, { i8*, i8*, i8*, i32, i8* } { i8* bitcast (i32 ()* @task_job_t1 to i8*), i8* getelementptr inbounds ([12 x i8], [12 x i8]* @.str, i32 0, i32 0), i8* getelementptr inbounds ([82 x i8], [82 x i8]* @.str.1, i32 0, i32 0), i32 33, i8* null }, { i8*, i8*, i8*, i32, i8* } { i8* bitcast (i32 ()* @task_job_t2 to i8*), i8* getelementptr inbounds ([12 x i8], [12 x i8]* @.str, i32 0, i32 0), i8* getelementptr inbounds ([82 x i8], [82 x i8]* @.str.1, i32 0, i32 0), i32 48, i8* null }, { i8*, i8*, i8*, i32, i8* } { i8* bitcast (i32 ()* @task_job_t3 to i8*), i8* getelementptr inbounds ([12 x i8], [12 x i8]* @.str, i32 0, i32 0), i8* getelementptr inbounds ([82 x i8], [82 x i8]* @.str.1, i32 0, i32 0), i32 63, i8* null }, { i8*, i8*, i8*, i32, i8* } { i8* bitcast (i32 ()* @kernel_t0 to i8*), i8* getelementptr inbounds ([11 x i8], [11 x i8]* @.str.2, i32 0, i32 0), i8* getelementptr inbounds ([82 x i8], [82 x i8]* @.str.1, i32 0, i32 0), i32 10, i8* null }, { i8*, i8*, i8*, i32, i8* } { i8* bitcast (i32 ()* @kernel_t1 to i8*), i8* getelementptr inbounds ([11 x i8], [11 x i8]* @.str.2, i32 0, i32 0), i8* getelementptr inbounds ([82 x i8], [82 x i8]* @.str.1, i32 0, i32 0), i32 25, i8* null }, { i8*, i8*, i8*, i32, i8* } { i8* bitcast (i32 ()* @kernel_t2 to i8*), i8* getelementptr inbounds ([11 x i8], [11 x i8]* @.str.2, i32 0, i32 0), i8* getelementptr inbounds ([82 x i8], [82 x i8]* @.str.1, i32 0, i32 0), i32 40, i8* null }, { i8*, i8*, i8*, i32, i8* } { i8* bitcast (i32 ()* @kernel_t3 to i8*), i8* getelementptr inbounds ([11 x i8], [11 x i8]* @.str.2, i32 0, i32 0), i8* getelementptr inbounds ([82 x i8], [82 x i8]* @.str.1, i32 0, i32 0), i32 55, i8* null }], section "llvm.metadata"

; Function Attrs: noinline nounwind uwtable
define dso_local i32 @task_job_t0() #0 !dbg !54 {
  %1 = alloca i32, align 4
  %2 = alloca i32, align 4
  call void @llvm.dbg.declare(metadata i32* %1, metadata !56, metadata !DIExpression()), !dbg !57
  store i32 0, i32* %1, align 4, !dbg !57
  call void @llvm.dbg.declare(metadata i32* %2, metadata !58, metadata !DIExpression()), !dbg !61
  store i32 0, i32* %2, align 4, !dbg !61
  br label %3, !dbg !62

3:                                                ; preds = %10, %0
  %4 = load i32, i32* %2, align 4, !dbg !63
  %5 = icmp slt i32 %4, 600, !dbg !65
  br i1 %5, label %6, label %13, !dbg !66

6:                                                ; preds = %3
  %7 = call i32 @kernel_t0(), !dbg !67
  %8 = load i32, i32* %1, align 4, !dbg !68
  %9 = add i32 %8, %7, !dbg !68
  store i32 %9, i32* %1, align 4, !dbg !68
  br label %10, !dbg !69

10:                                               ; preds = %6
  %11 = load i32, i32* %2, align 4, !dbg !70
  %12 = add nsw i32 %11, 1, !dbg !70
  store i32 %12, i32* %2, align 4, !dbg !70
  br label %3, !dbg !71, !llvm.loop !72

13:                                               ; preds = %3
  %14 = load i32, i32* %1, align 4, !dbg !75
  ret i32 %14, !dbg !76
}

; Function Attrs: nofree nosync nounwind readnone speculatable willreturn
declare void @llvm.dbg.declare(metadata, metadata, metadata) #1

; Function Attrs: noinline nounwind uwtable
define internal i32 @kernel_t0() #0 !dbg !77 {
  %1 = alloca i32, align 4
  %2 = alloca i32, align 4
  call void @llvm.dbg.declare(metadata i32* %1, metadata !78, metadata !DIExpression()), !dbg !79
  store i32 0, i32* %1, align 4, !dbg !79
  call void @llvm.dbg.declare(metadata i32* %2, metadata !80, metadata !DIExpression()), !dbg !82
  store i32 0, i32* %2, align 4, !dbg !82
  br label %3, !dbg !83

3:                                                ; preds = %14, %0
  %4 = load i32, i32* %2, align 4, !dbg !84
  %5 = icmp slt i32 %4, 16, !dbg !86
  br i1 %5, label %6, label %17, !dbg !87

6:                                                ; preds = %3
  %7 = load i32, i32* %2, align 4, !dbg !88
  %8 = sext i32 %7 to i64, !dbg !89
  %9 = getelementptr inbounds [16 x i8], [16 x i8]* @data_t0, i64 0, i64 %8, !dbg !89
  %10 = load volatile i8, i8* %9, align 1, !dbg !89
  %11 = zext i8 %10 to i32, !dbg !89
  %12 = load i32, i32* %1, align 4, !dbg !90
  %13 = add i32 %12, %11, !dbg !90
  store i32 %13, i32* %1, align 4, !dbg !90
  br label %14, !dbg !91

14:                                               ; preds = %6
  %15 = load i32, i32* %2, align 4, !dbg !92
  %16 = add nsw i32 %15, 1, !dbg !92
  store i32 %16, i32* %2, align 4, !dbg !92
  br label %3, !dbg !93, !llvm.loop !94

17:                                               ; preds = %3
  %18 = load i32, i32* %1, align 4, !dbg !96
  ret i32 %18, !dbg !97
}

; Function Attrs: noinline nounwind uwtable
define dso_local i32 @task_job_t1() #0 !dbg !98 {
  %1 = alloca i32, align 4
  %2 = alloca i32, align 4
  call void @llvm.dbg.declare(metadata i32* %1, metadata !99, metadata !DIExpression()), !dbg !100
  store i32 0, i32* %1, align 4, !dbg !100
  call void @llvm.dbg.declare(metadata i32* %2, metadata !101, metadata !DIExpression()), !dbg !103
  store i32 0, i32* %2, align 4, !dbg !103
  br label %3, !dbg !104

3:                                                ; preds = %10, %0
  %4 = load i32, i32* %2, align 4, !dbg !105
  %5 = icmp slt i32 %4, 150, !dbg !107
  br i1 %5, label %6, label %13, !dbg !108

6:                                                ; preds = %3
  %7 = call i32 @kernel_t1(), !dbg !109
  %8 = load i32, i32* %1, align 4, !dbg !110
  %9 = add i32 %8, %7, !dbg !110
  store i32 %9, i32* %1, align 4, !dbg !110
  br label %10, !dbg !111

10:                                               ; preds = %6
  %11 = load i32, i32* %2, align 4, !dbg !112
  %12 = add nsw i32 %11, 1, !dbg !112
  store i32 %12, i32* %2, align 4, !dbg !112
  br label %3, !dbg !113, !llvm.loop !114

13:                                               ; preds = %3
  %14 = load i32, i32* %1, align 4, !dbg !116
  ret i32 %14, !dbg !117
}

; Function Attrs: noinline nounwind uwtable
define internal i32 @kernel_t1() #0 !dbg !118 {
  %1 = alloca i32, align 4
  %2 = alloca i32, align 4
  call void @llvm.dbg.declare(metadata i32* %1, metadata !119, metadata !DIExpression()), !dbg !120
  store i32 0, i32* %1, align 4, !dbg !120
  call void @llvm.dbg.declare(metadata i32* %2, metadata !121, metadata !DIExpression()), !dbg !123
  store i32 0, i32* %2, align 4, !dbg !123
  br label %3, !dbg !124

3:                                                ; preds = %14, %0
  %4 = load i32, i32* %2, align 4, !dbg !125
  %5 = icmp slt i32 %4, 2048, !dbg !127
  br i1 %5, label %6, label %17, !dbg !128

6:                                                ; preds = %3
  %7 = load i32, i32* %2, align 4, !dbg !129
  %8 = sext i32 %7 to i64, !dbg !130
  %9 = getelementptr inbounds [2048 x i8], [2048 x i8]* @data_t1, i64 0, i64 %8, !dbg !130
  %10 = load volatile i8, i8* %9, align 1, !dbg !130
  %11 = zext i8 %10 to i32, !dbg !130
  %12 = load i32, i32* %1, align 4, !dbg !131
  %13 = add i32 %12, %11, !dbg !131
  store i32 %13, i32* %1, align 4, !dbg !131
  br label %14, !dbg !132

14:                                               ; preds = %6
  %15 = load i32, i32* %2, align 4, !dbg !133
  %16 = add nsw i32 %15, 32, !dbg !133
  store i32 %16, i32* %2, align 4, !dbg !133
  br label %3, !dbg !134, !llvm.loop !135

17:                                               ; preds = %3
  %18 = load i32, i32* %1, align 4, !dbg !137
  ret i32 %18, !dbg !138
}

; Function Attrs: noinline nounwind uwtable
define dso_local i32 @task_job_t2() #0 !dbg !139 {
  %1 = alloca i32, align 4
  %2 = alloca i32, align 4
  call void @llvm.dbg.declare(metadata i32* %1, metadata !140, metadata !DIExpression()), !dbg !141
  store i32 0, i32* %1, align 4, !dbg !141
  call void @llvm.dbg.declare(metadata i32* %2, metadata !142, metadata !DIExpression()), !dbg !144
  store i32 0, i32* %2, align 4, !dbg !144
  br label %3, !dbg !145

3:                                                ; preds = %10, %0
  %4 = load i32, i32* %2, align 4, !dbg !146
  %5 = icmp slt i32 %4, 2400, !dbg !148
  br i1 %5, label %6, label %13, !dbg !149

6:                                                ; preds = %3
  %7 = call i32 @kernel_t2(), !dbg !150
  %8 = load i32, i32* %1, align 4, !dbg !151
  %9 = add i32 %8, %7, !dbg !151
  store i32 %9, i32* %1, align 4, !dbg !151
  br label %10, !dbg !152

10:                                               ; preds = %6
  %11 = load i32, i32* %2, align 4, !dbg !153
  %12 = add nsw i32 %11, 1, !dbg !153
  store i32 %12, i32* %2, align 4, !dbg !153
  br label %3, !dbg !154, !llvm.loop !155

13:                                               ; preds = %3
  %14 = load i32, i32* %1, align 4, !dbg !157
  ret i32 %14, !dbg !158
}

; Function Attrs: noinline nounwind uwtable
define internal i32 @kernel_t2() #0 !dbg !159 {
  %1 = alloca i32, align 4
  %2 = alloca i32, align 4
  call void @llvm.dbg.declare(metadata i32* %1, metadata !160, metadata !DIExpression()), !dbg !161
  store i32 0, i32* %1, align 4, !dbg !161
  call void @llvm.dbg.declare(metadata i32* %2, metadata !162, metadata !DIExpression()), !dbg !164
  store i32 0, i32* %2, align 4, !dbg !164
  br label %3, !dbg !165

3:                                                ; preds = %14, %0
  %4 = load i32, i32* %2, align 4, !dbg !166
  %5 = icmp slt i32 %4, 16384, !dbg !168
  br i1 %5, label %6, label %17, !dbg !169

6:                                                ; preds = %3
  %7 = load i32, i32* %2, align 4, !dbg !170
  %8 = sext i32 %7 to i64, !dbg !171
  %9 = getelementptr inbounds [16384 x i8], [16384 x i8]* @data_t2, i64 0, i64 %8, !dbg !171
  %10 = load volatile i8, i8* %9, align 1, !dbg !171
  %11 = zext i8 %10 to i32, !dbg !171
  %12 = load i32, i32* %1, align 4, !dbg !172
  %13 = add i32 %12, %11, !dbg !172
  store i32 %13, i32* %1, align 4, !dbg !172
  br label %14, !dbg !173

14:                                               ; preds = %6
  %15 = load i32, i32* %2, align 4, !dbg !174
  %16 = add nsw i32 %15, 4096, !dbg !174
  store i32 %16, i32* %2, align 4, !dbg !174
  br label %3, !dbg !175, !llvm.loop !176

17:                                               ; preds = %3
  %18 = load i32, i32* %1, align 4, !dbg !178
  ret i32 %18, !dbg !179
}

; Function Attrs: noinline nounwind uwtable
define dso_local i32 @task_job_t3() #0 !dbg !180 {
  %1 = alloca i32, align 4
  %2 = alloca i32, align 4
  call void @llvm.dbg.declare(metadata i32* %1, metadata !181, metadata !DIExpression()), !dbg !182
  store i32 0, i32* %1, align 4, !dbg !182
  call void @llvm.dbg.declare(metadata i32* %2, metadata !183, metadata !DIExpression()), !dbg !185
  store i32 0, i32* %2, align 4, !dbg !185
  br label %3, !dbg !186

3:                                                ; preds = %10, %0
  %4 = load i32, i32* %2, align 4, !dbg !187
  %5 = icmp slt i32 %4, 1200, !dbg !189
  br i1 %5, label %6, label %13, !dbg !190

6:                                                ; preds = %3
  %7 = call i32 @kernel_t3(), !dbg !191
  %8 = load i32, i32* %1, align 4, !dbg !192
  %9 = add i32 %8, %7, !dbg !192
  store i32 %9, i32* %1, align 4, !dbg !192
  br label %10, !dbg !193

10:                                               ; preds = %6
  %11 = load i32, i32* %2, align 4, !dbg !194
  %12 = add nsw i32 %11, 1, !dbg !194
  store i32 %12, i32* %2, align 4, !dbg !194
  br label %3, !dbg !195, !llvm.loop !196

13:                                               ; preds = %3
  %14 = load i32, i32* %1, align 4, !dbg !198
  ret i32 %14, !dbg !199
}

; Function Attrs: noinline nounwind uwtable
define internal i32 @kernel_t3() #0 !dbg !200 {
  %1 = alloca i32, align 4
  %2 = alloca i32, align 4
  call void @llvm.dbg.declare(metadata i32* %1, metadata !201, metadata !DIExpression()), !dbg !202
  store i32 0, i32* %1, align 4, !dbg !202
  call void @llvm.dbg.declare(metadata i32* %2, metadata !203, metadata !DIExpression()), !dbg !205
  store i32 0, i32* %2, align 4, !dbg !205
  br label %3, !dbg !206

3:                                                ; preds = %14, %0
  %4 = load i32, i32* %2, align 4, !dbg !207
  %5 = icmp slt i32 %4, 8, !dbg !209
  br i1 %5, label %6, label %17, !dbg !210

6:                                                ; preds = %3
  %7 = load i32, i32* %2, align 4, !dbg !211
  %8 = sext i32 %7 to i64, !dbg !212
  %9 = getelementptr inbounds [8 x i8], [8 x i8]* @data_t3, i64 0, i64 %8, !dbg !212
  %10 = load volatile i8, i8* %9, align 1, !dbg !212
  %11 = zext i8 %10 to i32, !dbg !212
  %12 = load i32, i32* %1, align 4, !dbg !213
  %13 = add i32 %12, %11, !dbg !213
  store i32 %13, i32* %1, align 4, !dbg !213
  br label %14, !dbg !214

14:                                               ; preds = %6
  %15 = load i32, i32* %2, align 4, !dbg !215
  %16 = add nsw i32 %15, 1, !dbg !215
  store i32 %16, i32* %2, align 4, !dbg !215
  br label %3, !dbg !216, !llvm.loop !217

17:                                               ; preds = %3
  %18 = load i32, i32* %1, align 4, !dbg !219
  ret i32 %18, !dbg !220
}

; Function Attrs: noinline nounwind uwtable
define dso_local void @workload_prepare() #0 !dbg !221 {
  %1 = alloca i32, align 4
  %2 = alloca i32, align 4
  %3 = alloca i32, align 4
  %4 = alloca i32, align 4
  call void @llvm.dbg.declare(metadata i32* %1, metadata !224, metadata !DIExpression()), !dbg !226
  store i32 0, i32* %1, align 4, !dbg !226
  br label %5, !dbg !227

5:                                                ; preds = %12, %0
  %6 = load i32, i32* %1, align 4, !dbg !228
  %7 = icmp slt i32 %6, 16, !dbg !230
  br i1 %7, label %8, label %15, !dbg !231

8:                                                ; preds = %5
  %9 = load i32, i32* %1, align 4, !dbg !232
  %10 = sext i32 %9 to i64, !dbg !233
  %11 = getelementptr inbounds [16 x i8], [16 x i8]* @data_t0, i64 0, i64 %10, !dbg !233
  store volatile i8 1, i8* %11, align 1, !dbg !234
  br label %12, !dbg !233

12:                                               ; preds = %8
  %13 = load i32, i32* %1, align 4, !dbg !235
  %14 = add nsw i32 %13, 1, !dbg !235
  store i32 %14, i32* %1, align 4, !dbg !235
  br label %5, !dbg !236, !llvm.loop !237

15:                                               ; preds = %5
  call void @llvm.dbg.declare(metadata i32* %2, metadata !239, metadata !DIExpression()), !dbg !241
  store i32 0, i32* %2, align 4, !dbg !241
  br label %16, !dbg !242

16:                                               ; preds = %23, %15
  %17 = load i32, i32* %2, align 4, !dbg !243
  %18 = icmp slt i32 %17, 2048, !dbg !245
  br i1 %18, label %19, label %26, !dbg !246

19:                                               ; preds = %16
  %20 = load i32, i32* %2, align 4, !dbg !247
  %21 = sext i32 %20 to i64, !dbg !248
  %22 = getelementptr inbounds [2048 x i8], [2048 x i8]* @data_t1, i64 0, i64 %21, !dbg !248
  store volatile i8 1, i8* %22, align 1, !dbg !249
  br label %23, !dbg !248

23:                                               ; preds = %19
  %24 = load i32, i32* %2, align 4, !dbg !250
  %25 = add nsw i32 %24, 1, !dbg !250
  store i32 %25, i32* %2, align 4, !dbg !250
  br label %16, !dbg !251, !llvm.loop !252

26:                                               ; preds = %16
  call void @llvm.dbg.declare(metadata i32* %3, metadata !254, metadata !DIExpression()), !dbg !256
  store i32 0, i32* %3, align 4, !dbg !256
  br label %27, !dbg !257

27:                                               ; preds = %34, %26
  %28 = load i32, i32* %3, align 4, !dbg !258
  %29 = icmp slt i32 %28, 16384, !dbg !260
  br i1 %29, label %30, label %37, !dbg !261

30:                                               ; preds = %27
  %31 = load i32, i32* %3, align 4, !dbg !262
  %32 = sext i32 %31 to i64, !dbg !263
  %33 = getelementptr inbounds [16384 x i8], [16384 x i8]* @data_t2, i64 0, i64 %32, !dbg !263
  store volatile i8 1, i8* %33, align 1, !dbg !264
  br label %34, !dbg !263

34:                                               ; preds = %30
  %35 = load i32, i32* %3, align 4, !dbg !265
  %36 = add nsw i32 %35, 1, !dbg !265
  store i32 %36, i32* %3, align 4, !dbg !265
  br label %27, !dbg !266, !llvm.loop !267

37:                                               ; preds = %27
  call void @llvm.dbg.declare(metadata i32* %4, metadata !269, metadata !DIExpression()), !dbg !271
  store i32 0, i32* %4, align 4, !dbg !271
  br label %38, !dbg !272

38:                                               ; preds = %45, %37
  %39 = load i32, i32* %4, align 4, !dbg !273
  %40 = icmp slt i32 %39, 8, !dbg !275
  br i1 %40, label %41, label %48, !dbg !276

41:                                               ; preds = %38
  %42 = load i32, i32* %4, align 4, !dbg !277
  %43 = sext i32 %42 to i64, !dbg !278
  %44 = getelementptr inbounds [8 x i8], [8 x i8]* @data_t3, i64 0, i64 %43, !dbg !278
  store volatile i8 1, i8* %44, align 1, !dbg !279
  br label %45, !dbg !278

45:                                               ; preds = %41
  %46 = load i32, i32* %4, align 4, !dbg !280
  %47 = add nsw i32 %46, 1, !dbg !280
  store i32 %47, i32* %4, align 4, !dbg !280
  br label %38, !dbg !281, !llvm.loop !282

48:                                               ; preds = %38
  ret void, !dbg !284
}

attributes #0 = { noinline nounwind uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { nofree nosync nounwind readnone speculatable willreturn }

!llvm.dbg.cu = !{!2}
!llvm.module.flags = !{!46, !47, !48, !49, !50, !51, !52}
!llvm.ident = !{!53}

!0 = !DIGlobalVariableExpression(var: !1, expr: !DIExpression())
!1 = distinct !DIGlobalVariable(name: "data_t0", scope: !2, file: !7, line: 9, type: !43, isLocal: false, isDefinition: true, align: 32768)
!2 = distinct !DICompileUnit(language: DW_LANG_C99, file: !3, producer: "Ubuntu clang version 14.0.0-1ubuntu1.1", isOptimized: false, runtimeVersion: 0, emissionKind: FullDebug, globals: !4, splitDebugInlining: false, nameTableKind: None)
!3 = !DIFile(filename: "/workspace/experiments/chaser/.cache/periodic-pilot-v1/pilot-06/source/workload.c", directory: "/workspace/experiments/chaser/.cache/periodic-pilot-v1/pilot-06/analysis", checksumkind: CSK_MD5, checksum: "ec1b7f11857da01be39d21cc724edd70")
!4 = !{!5, !20, !0, !24, !33, !38}
!5 = !DIGlobalVariableExpression(var: !6, expr: !DIExpression())
!6 = distinct !DIGlobalVariable(name: "workload_jobs", scope: !2, file: !7, line: 75, type: !8, isLocal: false, isDefinition: true)
!7 = !DIFile(filename: "source/workload.c", directory: "/workspace/experiments/chaser/.cache/periodic-pilot-v1/pilot-06", checksumkind: CSK_MD5, checksum: "ec1b7f11857da01be39d21cc724edd70")
!8 = !DICompositeType(tag: DW_TAG_array_type, baseType: !9, size: 256, elements: !18)
!9 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !10)
!10 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !11, size: 64)
!11 = !DISubroutineType(types: !12)
!12 = !{!13}
!13 = !DIDerivedType(tag: DW_TAG_typedef, name: "uint32_t", file: !14, line: 26, baseType: !15)
!14 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/stdint-uintn.h", directory: "", checksumkind: CSK_MD5, checksum: "2bf2ae53c58c01b1a1b9383b5195125c")
!15 = !DIDerivedType(tag: DW_TAG_typedef, name: "__uint32_t", file: !16, line: 42, baseType: !17)
!16 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/types.h", directory: "", checksumkind: CSK_MD5, checksum: "d108b5f93a74c50510d7d9bc0ab36df9")
!17 = !DIBasicType(name: "unsigned int", size: 32, encoding: DW_ATE_unsigned)
!18 = !{!19}
!19 = !DISubrange(count: 4)
!20 = !DIGlobalVariableExpression(var: !21, expr: !DIExpression())
!21 = distinct !DIGlobalVariable(name: "workload_expected", scope: !2, file: !7, line: 81, type: !22, isLocal: false, isDefinition: true)
!22 = !DICompositeType(tag: DW_TAG_array_type, baseType: !23, size: 128, elements: !18)
!23 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !13)
!24 = !DIGlobalVariableExpression(var: !25, expr: !DIExpression())
!25 = distinct !DIGlobalVariable(name: "data_t1", scope: !2, file: !7, line: 24, type: !26, isLocal: false, isDefinition: true, align: 32768)
!26 = !DICompositeType(tag: DW_TAG_array_type, baseType: !27, size: 16384, elements: !31)
!27 = !DIDerivedType(tag: DW_TAG_volatile_type, baseType: !28)
!28 = !DIDerivedType(tag: DW_TAG_typedef, name: "uint8_t", file: !14, line: 24, baseType: !29)
!29 = !DIDerivedType(tag: DW_TAG_typedef, name: "__uint8_t", file: !16, line: 38, baseType: !30)
!30 = !DIBasicType(name: "unsigned char", size: 8, encoding: DW_ATE_unsigned_char)
!31 = !{!32}
!32 = !DISubrange(count: 2048)
!33 = !DIGlobalVariableExpression(var: !34, expr: !DIExpression())
!34 = distinct !DIGlobalVariable(name: "data_t2", scope: !2, file: !7, line: 39, type: !35, isLocal: false, isDefinition: true, align: 32768)
!35 = !DICompositeType(tag: DW_TAG_array_type, baseType: !27, size: 131072, elements: !36)
!36 = !{!37}
!37 = !DISubrange(count: 16384)
!38 = !DIGlobalVariableExpression(var: !39, expr: !DIExpression())
!39 = distinct !DIGlobalVariable(name: "data_t3", scope: !2, file: !7, line: 54, type: !40, isLocal: false, isDefinition: true, align: 32768)
!40 = !DICompositeType(tag: DW_TAG_array_type, baseType: !27, size: 64, elements: !41)
!41 = !{!42}
!42 = !DISubrange(count: 8)
!43 = !DICompositeType(tag: DW_TAG_array_type, baseType: !27, size: 128, elements: !44)
!44 = !{!45}
!45 = !DISubrange(count: 16)
!46 = !{i32 7, !"Dwarf Version", i32 5}
!47 = !{i32 2, !"Debug Info Version", i32 3}
!48 = !{i32 1, !"wchar_size", i32 4}
!49 = !{i32 7, !"PIC Level", i32 2}
!50 = !{i32 7, !"PIE Level", i32 2}
!51 = !{i32 7, !"uwtable", i32 1}
!52 = !{i32 7, !"frame-pointer", i32 2}
!53 = !{!"Ubuntu clang version 14.0.0-1ubuntu1.1"}
!54 = distinct !DISubprogram(name: "task_job_t0", scope: !7, file: !7, line: 18, type: !11, scopeLine: 18, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !2, retainedNodes: !55)
!55 = !{}
!56 = !DILocalVariable(name: "sum", scope: !54, file: !7, line: 19, type: !13)
!57 = !DILocation(line: 19, column: 14, scope: !54)
!58 = !DILocalVariable(name: "s", scope: !59, file: !7, line: 20, type: !60)
!59 = distinct !DILexicalBlock(scope: !54, file: !7, line: 20, column: 5)
!60 = !DIBasicType(name: "int", size: 32, encoding: DW_ATE_signed)
!61 = !DILocation(line: 20, column: 14, scope: !59)
!62 = !DILocation(line: 20, column: 10, scope: !59)
!63 = !DILocation(line: 20, column: 21, scope: !64)
!64 = distinct !DILexicalBlock(scope: !59, file: !7, line: 20, column: 5)
!65 = !DILocation(line: 20, column: 23, scope: !64)
!66 = !DILocation(line: 20, column: 5, scope: !59)
!67 = !DILocation(line: 21, column: 16, scope: !64)
!68 = !DILocation(line: 21, column: 13, scope: !64)
!69 = !DILocation(line: 21, column: 9, scope: !64)
!70 = !DILocation(line: 20, column: 30, scope: !64)
!71 = !DILocation(line: 20, column: 5, scope: !64)
!72 = distinct !{!72, !66, !73, !74}
!73 = !DILocation(line: 21, column: 26, scope: !59)
!74 = !{!"llvm.loop.mustprogress"}
!75 = !DILocation(line: 22, column: 12, scope: !54)
!76 = !DILocation(line: 22, column: 5, scope: !54)
!77 = distinct !DISubprogram(name: "kernel_t0", scope: !7, file: !7, line: 10, type: !11, scopeLine: 10, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition, unit: !2, retainedNodes: !55)
!78 = !DILocalVariable(name: "sum", scope: !77, file: !7, line: 11, type: !13)
!79 = !DILocation(line: 11, column: 14, scope: !77)
!80 = !DILocalVariable(name: "i", scope: !81, file: !7, line: 12, type: !60)
!81 = distinct !DILexicalBlock(scope: !77, file: !7, line: 12, column: 5)
!82 = !DILocation(line: 12, column: 14, scope: !81)
!83 = !DILocation(line: 12, column: 10, scope: !81)
!84 = !DILocation(line: 12, column: 21, scope: !85)
!85 = distinct !DILexicalBlock(scope: !81, file: !7, line: 12, column: 5)
!86 = !DILocation(line: 12, column: 23, scope: !85)
!87 = !DILocation(line: 12, column: 5, scope: !81)
!88 = !DILocation(line: 13, column: 24, scope: !85)
!89 = !DILocation(line: 13, column: 16, scope: !85)
!90 = !DILocation(line: 13, column: 13, scope: !85)
!91 = !DILocation(line: 13, column: 9, scope: !85)
!92 = !DILocation(line: 12, column: 31, scope: !85)
!93 = !DILocation(line: 12, column: 5, scope: !85)
!94 = distinct !{!94, !87, !95, !74}
!95 = !DILocation(line: 13, column: 25, scope: !81)
!96 = !DILocation(line: 14, column: 12, scope: !77)
!97 = !DILocation(line: 14, column: 5, scope: !77)
!98 = distinct !DISubprogram(name: "task_job_t1", scope: !7, file: !7, line: 33, type: !11, scopeLine: 33, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !2, retainedNodes: !55)
!99 = !DILocalVariable(name: "sum", scope: !98, file: !7, line: 34, type: !13)
!100 = !DILocation(line: 34, column: 14, scope: !98)
!101 = !DILocalVariable(name: "s", scope: !102, file: !7, line: 35, type: !60)
!102 = distinct !DILexicalBlock(scope: !98, file: !7, line: 35, column: 5)
!103 = !DILocation(line: 35, column: 14, scope: !102)
!104 = !DILocation(line: 35, column: 10, scope: !102)
!105 = !DILocation(line: 35, column: 21, scope: !106)
!106 = distinct !DILexicalBlock(scope: !102, file: !7, line: 35, column: 5)
!107 = !DILocation(line: 35, column: 23, scope: !106)
!108 = !DILocation(line: 35, column: 5, scope: !102)
!109 = !DILocation(line: 36, column: 16, scope: !106)
!110 = !DILocation(line: 36, column: 13, scope: !106)
!111 = !DILocation(line: 36, column: 9, scope: !106)
!112 = !DILocation(line: 35, column: 30, scope: !106)
!113 = !DILocation(line: 35, column: 5, scope: !106)
!114 = distinct !{!114, !108, !115, !74}
!115 = !DILocation(line: 36, column: 26, scope: !102)
!116 = !DILocation(line: 37, column: 12, scope: !98)
!117 = !DILocation(line: 37, column: 5, scope: !98)
!118 = distinct !DISubprogram(name: "kernel_t1", scope: !7, file: !7, line: 25, type: !11, scopeLine: 25, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition, unit: !2, retainedNodes: !55)
!119 = !DILocalVariable(name: "sum", scope: !118, file: !7, line: 26, type: !13)
!120 = !DILocation(line: 26, column: 14, scope: !118)
!121 = !DILocalVariable(name: "i", scope: !122, file: !7, line: 27, type: !60)
!122 = distinct !DILexicalBlock(scope: !118, file: !7, line: 27, column: 5)
!123 = !DILocation(line: 27, column: 14, scope: !122)
!124 = !DILocation(line: 27, column: 10, scope: !122)
!125 = !DILocation(line: 27, column: 21, scope: !126)
!126 = distinct !DILexicalBlock(scope: !122, file: !7, line: 27, column: 5)
!127 = !DILocation(line: 27, column: 23, scope: !126)
!128 = !DILocation(line: 27, column: 5, scope: !122)
!129 = !DILocation(line: 28, column: 24, scope: !126)
!130 = !DILocation(line: 28, column: 16, scope: !126)
!131 = !DILocation(line: 28, column: 13, scope: !126)
!132 = !DILocation(line: 28, column: 9, scope: !126)
!133 = !DILocation(line: 27, column: 33, scope: !126)
!134 = !DILocation(line: 27, column: 5, scope: !126)
!135 = distinct !{!135, !128, !136, !74}
!136 = !DILocation(line: 28, column: 25, scope: !122)
!137 = !DILocation(line: 29, column: 12, scope: !118)
!138 = !DILocation(line: 29, column: 5, scope: !118)
!139 = distinct !DISubprogram(name: "task_job_t2", scope: !7, file: !7, line: 48, type: !11, scopeLine: 48, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !2, retainedNodes: !55)
!140 = !DILocalVariable(name: "sum", scope: !139, file: !7, line: 49, type: !13)
!141 = !DILocation(line: 49, column: 14, scope: !139)
!142 = !DILocalVariable(name: "s", scope: !143, file: !7, line: 50, type: !60)
!143 = distinct !DILexicalBlock(scope: !139, file: !7, line: 50, column: 5)
!144 = !DILocation(line: 50, column: 14, scope: !143)
!145 = !DILocation(line: 50, column: 10, scope: !143)
!146 = !DILocation(line: 50, column: 21, scope: !147)
!147 = distinct !DILexicalBlock(scope: !143, file: !7, line: 50, column: 5)
!148 = !DILocation(line: 50, column: 23, scope: !147)
!149 = !DILocation(line: 50, column: 5, scope: !143)
!150 = !DILocation(line: 51, column: 16, scope: !147)
!151 = !DILocation(line: 51, column: 13, scope: !147)
!152 = !DILocation(line: 51, column: 9, scope: !147)
!153 = !DILocation(line: 50, column: 31, scope: !147)
!154 = !DILocation(line: 50, column: 5, scope: !147)
!155 = distinct !{!155, !149, !156, !74}
!156 = !DILocation(line: 51, column: 26, scope: !143)
!157 = !DILocation(line: 52, column: 12, scope: !139)
!158 = !DILocation(line: 52, column: 5, scope: !139)
!159 = distinct !DISubprogram(name: "kernel_t2", scope: !7, file: !7, line: 40, type: !11, scopeLine: 40, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition, unit: !2, retainedNodes: !55)
!160 = !DILocalVariable(name: "sum", scope: !159, file: !7, line: 41, type: !13)
!161 = !DILocation(line: 41, column: 14, scope: !159)
!162 = !DILocalVariable(name: "i", scope: !163, file: !7, line: 42, type: !60)
!163 = distinct !DILexicalBlock(scope: !159, file: !7, line: 42, column: 5)
!164 = !DILocation(line: 42, column: 14, scope: !163)
!165 = !DILocation(line: 42, column: 10, scope: !163)
!166 = !DILocation(line: 42, column: 21, scope: !167)
!167 = distinct !DILexicalBlock(scope: !163, file: !7, line: 42, column: 5)
!168 = !DILocation(line: 42, column: 23, scope: !167)
!169 = !DILocation(line: 42, column: 5, scope: !163)
!170 = !DILocation(line: 43, column: 24, scope: !167)
!171 = !DILocation(line: 43, column: 16, scope: !167)
!172 = !DILocation(line: 43, column: 13, scope: !167)
!173 = !DILocation(line: 43, column: 9, scope: !167)
!174 = !DILocation(line: 42, column: 34, scope: !167)
!175 = !DILocation(line: 42, column: 5, scope: !167)
!176 = distinct !{!176, !169, !177, !74}
!177 = !DILocation(line: 43, column: 25, scope: !163)
!178 = !DILocation(line: 44, column: 12, scope: !159)
!179 = !DILocation(line: 44, column: 5, scope: !159)
!180 = distinct !DISubprogram(name: "task_job_t3", scope: !7, file: !7, line: 63, type: !11, scopeLine: 63, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !2, retainedNodes: !55)
!181 = !DILocalVariable(name: "sum", scope: !180, file: !7, line: 64, type: !13)
!182 = !DILocation(line: 64, column: 14, scope: !180)
!183 = !DILocalVariable(name: "s", scope: !184, file: !7, line: 65, type: !60)
!184 = distinct !DILexicalBlock(scope: !180, file: !7, line: 65, column: 5)
!185 = !DILocation(line: 65, column: 14, scope: !184)
!186 = !DILocation(line: 65, column: 10, scope: !184)
!187 = !DILocation(line: 65, column: 21, scope: !188)
!188 = distinct !DILexicalBlock(scope: !184, file: !7, line: 65, column: 5)
!189 = !DILocation(line: 65, column: 23, scope: !188)
!190 = !DILocation(line: 65, column: 5, scope: !184)
!191 = !DILocation(line: 66, column: 16, scope: !188)
!192 = !DILocation(line: 66, column: 13, scope: !188)
!193 = !DILocation(line: 66, column: 9, scope: !188)
!194 = !DILocation(line: 65, column: 31, scope: !188)
!195 = !DILocation(line: 65, column: 5, scope: !188)
!196 = distinct !{!196, !190, !197, !74}
!197 = !DILocation(line: 66, column: 26, scope: !184)
!198 = !DILocation(line: 67, column: 12, scope: !180)
!199 = !DILocation(line: 67, column: 5, scope: !180)
!200 = distinct !DISubprogram(name: "kernel_t3", scope: !7, file: !7, line: 55, type: !11, scopeLine: 55, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition, unit: !2, retainedNodes: !55)
!201 = !DILocalVariable(name: "sum", scope: !200, file: !7, line: 56, type: !13)
!202 = !DILocation(line: 56, column: 14, scope: !200)
!203 = !DILocalVariable(name: "i", scope: !204, file: !7, line: 57, type: !60)
!204 = distinct !DILexicalBlock(scope: !200, file: !7, line: 57, column: 5)
!205 = !DILocation(line: 57, column: 14, scope: !204)
!206 = !DILocation(line: 57, column: 10, scope: !204)
!207 = !DILocation(line: 57, column: 21, scope: !208)
!208 = distinct !DILexicalBlock(scope: !204, file: !7, line: 57, column: 5)
!209 = !DILocation(line: 57, column: 23, scope: !208)
!210 = !DILocation(line: 57, column: 5, scope: !204)
!211 = !DILocation(line: 58, column: 24, scope: !208)
!212 = !DILocation(line: 58, column: 16, scope: !208)
!213 = !DILocation(line: 58, column: 13, scope: !208)
!214 = !DILocation(line: 58, column: 9, scope: !208)
!215 = !DILocation(line: 57, column: 30, scope: !208)
!216 = !DILocation(line: 57, column: 5, scope: !208)
!217 = distinct !{!217, !210, !218, !74}
!218 = !DILocation(line: 58, column: 25, scope: !204)
!219 = !DILocation(line: 59, column: 12, scope: !200)
!220 = !DILocation(line: 59, column: 5, scope: !200)
!221 = distinct !DISubprogram(name: "workload_prepare", scope: !7, file: !7, line: 69, type: !222, scopeLine: 69, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !2, retainedNodes: !55)
!222 = !DISubroutineType(types: !223)
!223 = !{null}
!224 = !DILocalVariable(name: "i", scope: !225, file: !7, line: 70, type: !60)
!225 = distinct !DILexicalBlock(scope: !221, file: !7, line: 70, column: 5)
!226 = !DILocation(line: 70, column: 14, scope: !225)
!227 = !DILocation(line: 70, column: 10, scope: !225)
!228 = !DILocation(line: 70, column: 21, scope: !229)
!229 = distinct !DILexicalBlock(scope: !225, file: !7, line: 70, column: 5)
!230 = !DILocation(line: 70, column: 23, scope: !229)
!231 = !DILocation(line: 70, column: 5, scope: !225)
!232 = !DILocation(line: 70, column: 42, scope: !229)
!233 = !DILocation(line: 70, column: 34, scope: !229)
!234 = !DILocation(line: 70, column: 45, scope: !229)
!235 = !DILocation(line: 70, column: 29, scope: !229)
!236 = !DILocation(line: 70, column: 5, scope: !229)
!237 = distinct !{!237, !231, !238, !74}
!238 = !DILocation(line: 70, column: 47, scope: !225)
!239 = !DILocalVariable(name: "i", scope: !240, file: !7, line: 71, type: !60)
!240 = distinct !DILexicalBlock(scope: !221, file: !7, line: 71, column: 5)
!241 = !DILocation(line: 71, column: 14, scope: !240)
!242 = !DILocation(line: 71, column: 10, scope: !240)
!243 = !DILocation(line: 71, column: 21, scope: !244)
!244 = distinct !DILexicalBlock(scope: !240, file: !7, line: 71, column: 5)
!245 = !DILocation(line: 71, column: 23, scope: !244)
!246 = !DILocation(line: 71, column: 5, scope: !240)
!247 = !DILocation(line: 71, column: 44, scope: !244)
!248 = !DILocation(line: 71, column: 36, scope: !244)
!249 = !DILocation(line: 71, column: 47, scope: !244)
!250 = !DILocation(line: 71, column: 31, scope: !244)
!251 = !DILocation(line: 71, column: 5, scope: !244)
!252 = distinct !{!252, !246, !253, !74}
!253 = !DILocation(line: 71, column: 49, scope: !240)
!254 = !DILocalVariable(name: "i", scope: !255, file: !7, line: 72, type: !60)
!255 = distinct !DILexicalBlock(scope: !221, file: !7, line: 72, column: 5)
!256 = !DILocation(line: 72, column: 14, scope: !255)
!257 = !DILocation(line: 72, column: 10, scope: !255)
!258 = !DILocation(line: 72, column: 21, scope: !259)
!259 = distinct !DILexicalBlock(scope: !255, file: !7, line: 72, column: 5)
!260 = !DILocation(line: 72, column: 23, scope: !259)
!261 = !DILocation(line: 72, column: 5, scope: !255)
!262 = !DILocation(line: 72, column: 45, scope: !259)
!263 = !DILocation(line: 72, column: 37, scope: !259)
!264 = !DILocation(line: 72, column: 48, scope: !259)
!265 = !DILocation(line: 72, column: 32, scope: !259)
!266 = !DILocation(line: 72, column: 5, scope: !259)
!267 = distinct !{!267, !261, !268, !74}
!268 = !DILocation(line: 72, column: 50, scope: !255)
!269 = !DILocalVariable(name: "i", scope: !270, file: !7, line: 73, type: !60)
!270 = distinct !DILexicalBlock(scope: !221, file: !7, line: 73, column: 5)
!271 = !DILocation(line: 73, column: 14, scope: !270)
!272 = !DILocation(line: 73, column: 10, scope: !270)
!273 = !DILocation(line: 73, column: 21, scope: !274)
!274 = distinct !DILexicalBlock(scope: !270, file: !7, line: 73, column: 5)
!275 = !DILocation(line: 73, column: 23, scope: !274)
!276 = !DILocation(line: 73, column: 5, scope: !270)
!277 = !DILocation(line: 73, column: 41, scope: !274)
!278 = !DILocation(line: 73, column: 33, scope: !274)
!279 = !DILocation(line: 73, column: 44, scope: !274)
!280 = !DILocation(line: 73, column: 28, scope: !274)
!281 = !DILocation(line: 73, column: 5, scope: !274)
!282 = distinct !{!282, !276, !283, !74}
!283 = !DILocation(line: 73, column: 46, scope: !270)
!284 = !DILocation(line: 74, column: 1, scope: !221)
