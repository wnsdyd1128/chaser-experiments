#define TASK_COUNT 16
#define MAX_JOBS 2
#define ARCHITECTURE 2
#define CHASER_PLAN_HASH "77c1316b1dd860654334c4b156e365dcc3a7f17c1d24c7a6deaaf5426a6ede39"
#define CHASER_PERIODS {20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20}
#define CHASER_JOB_COUNTS {2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2}
#define CHASER_CORES {0, 1, 2, 3, 0, 1, 2, 3, 0, 1, 2, 3, 0, 1, 2, 3}
