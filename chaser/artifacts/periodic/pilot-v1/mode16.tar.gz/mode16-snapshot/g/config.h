#define TASK_COUNT 16
#define MAX_JOBS 2
#define ARCHITECTURE 0
#define CHASER_PLAN_HASH "d61fba8f5373a17410b9138851e7f184cb589f5adc79e8fee61638257b7fcb5d"
#define CHASER_PERIODS {20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20}
#define CHASER_JOB_COUNTS {2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2}
#define CHASER_CORES {0, 1, 2, 3, 0, 1, 2, 3, 0, 1, 2, 3, 0, 1, 2, 3}
