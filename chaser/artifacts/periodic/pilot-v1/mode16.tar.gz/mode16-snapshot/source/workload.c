#include "workload.h"
#ifdef __clang__
#define ANALYZE __attribute__((annotate("ape.analyze")))
#define INLINE __attribute__((annotate("ape.inline")))
#else
#define ANALYZE
#define INLINE
#endif
volatile uint8_t data_t0[8] __attribute__((aligned(4096), section(".chaser_data.00")));
INLINE static uint32_t kernel_t0(void) {
    uint32_t sum = 0;
    for (int i = 0; i < 8; i += 1)
        sum += data_t0[i];
    return sum;
}
/** @brief Execute one fixed job without resetting data or cache.
 * @return Load-count checksum, modulo 2^32. */
ANALYZE uint32_t task_job_t0(void) {
    uint32_t sum = 0;
    for (int s = 0; s < 1200; ++s)
        sum += kernel_t0();
    return sum;
}
volatile uint8_t data_t1[8] __attribute__((aligned(4096), section(".chaser_data.01")));
INLINE static uint32_t kernel_t1(void) {
    uint32_t sum = 0;
    for (int i = 0; i < 8; i += 1)
        sum += data_t1[i];
    return sum;
}
/** @brief Execute one fixed job without resetting data or cache.
 * @return Load-count checksum, modulo 2^32. */
ANALYZE uint32_t task_job_t1(void) {
    uint32_t sum = 0;
    for (int s = 0; s < 1200; ++s)
        sum += kernel_t1();
    return sum;
}
volatile uint8_t data_t2[8] __attribute__((aligned(4096), section(".chaser_data.02")));
INLINE static uint32_t kernel_t2(void) {
    uint32_t sum = 0;
    for (int i = 0; i < 8; i += 1)
        sum += data_t2[i];
    return sum;
}
/** @brief Execute one fixed job without resetting data or cache.
 * @return Load-count checksum, modulo 2^32. */
ANALYZE uint32_t task_job_t2(void) {
    uint32_t sum = 0;
    for (int s = 0; s < 1200; ++s)
        sum += kernel_t2();
    return sum;
}
volatile uint8_t data_t3[8] __attribute__((aligned(4096), section(".chaser_data.03")));
INLINE static uint32_t kernel_t3(void) {
    uint32_t sum = 0;
    for (int i = 0; i < 8; i += 1)
        sum += data_t3[i];
    return sum;
}
/** @brief Execute one fixed job without resetting data or cache.
 * @return Load-count checksum, modulo 2^32. */
ANALYZE uint32_t task_job_t3(void) {
    uint32_t sum = 0;
    for (int s = 0; s < 1200; ++s)
        sum += kernel_t3();
    return sum;
}
volatile uint8_t data_t4[8] __attribute__((aligned(4096), section(".chaser_data.04")));
INLINE static uint32_t kernel_t4(void) {
    uint32_t sum = 0;
    for (int i = 0; i < 8; i += 1)
        sum += data_t4[i];
    return sum;
}
/** @brief Execute one fixed job without resetting data or cache.
 * @return Load-count checksum, modulo 2^32. */
ANALYZE uint32_t task_job_t4(void) {
    uint32_t sum = 0;
    for (int s = 0; s < 1200; ++s)
        sum += kernel_t4();
    return sum;
}
volatile uint8_t data_t5[8] __attribute__((aligned(4096), section(".chaser_data.05")));
INLINE static uint32_t kernel_t5(void) {
    uint32_t sum = 0;
    for (int i = 0; i < 8; i += 1)
        sum += data_t5[i];
    return sum;
}
/** @brief Execute one fixed job without resetting data or cache.
 * @return Load-count checksum, modulo 2^32. */
ANALYZE uint32_t task_job_t5(void) {
    uint32_t sum = 0;
    for (int s = 0; s < 1200; ++s)
        sum += kernel_t5();
    return sum;
}
volatile uint8_t data_t6[8] __attribute__((aligned(4096), section(".chaser_data.06")));
INLINE static uint32_t kernel_t6(void) {
    uint32_t sum = 0;
    for (int i = 0; i < 8; i += 1)
        sum += data_t6[i];
    return sum;
}
/** @brief Execute one fixed job without resetting data or cache.
 * @return Load-count checksum, modulo 2^32. */
ANALYZE uint32_t task_job_t6(void) {
    uint32_t sum = 0;
    for (int s = 0; s < 1200; ++s)
        sum += kernel_t6();
    return sum;
}
volatile uint8_t data_t7[8] __attribute__((aligned(4096), section(".chaser_data.07")));
INLINE static uint32_t kernel_t7(void) {
    uint32_t sum = 0;
    for (int i = 0; i < 8; i += 1)
        sum += data_t7[i];
    return sum;
}
/** @brief Execute one fixed job without resetting data or cache.
 * @return Load-count checksum, modulo 2^32. */
ANALYZE uint32_t task_job_t7(void) {
    uint32_t sum = 0;
    for (int s = 0; s < 1200; ++s)
        sum += kernel_t7();
    return sum;
}
volatile uint8_t data_t8[8] __attribute__((aligned(4096), section(".chaser_data.08")));
INLINE static uint32_t kernel_t8(void) {
    uint32_t sum = 0;
    for (int i = 0; i < 8; i += 1)
        sum += data_t8[i];
    return sum;
}
/** @brief Execute one fixed job without resetting data or cache.
 * @return Load-count checksum, modulo 2^32. */
ANALYZE uint32_t task_job_t8(void) {
    uint32_t sum = 0;
    for (int s = 0; s < 1200; ++s)
        sum += kernel_t8();
    return sum;
}
volatile uint8_t data_t9[8] __attribute__((aligned(4096), section(".chaser_data.09")));
INLINE static uint32_t kernel_t9(void) {
    uint32_t sum = 0;
    for (int i = 0; i < 8; i += 1)
        sum += data_t9[i];
    return sum;
}
/** @brief Execute one fixed job without resetting data or cache.
 * @return Load-count checksum, modulo 2^32. */
ANALYZE uint32_t task_job_t9(void) {
    uint32_t sum = 0;
    for (int s = 0; s < 1200; ++s)
        sum += kernel_t9();
    return sum;
}
volatile uint8_t data_t10[8] __attribute__((aligned(4096), section(".chaser_data.10")));
INLINE static uint32_t kernel_t10(void) {
    uint32_t sum = 0;
    for (int i = 0; i < 8; i += 1)
        sum += data_t10[i];
    return sum;
}
/** @brief Execute one fixed job without resetting data or cache.
 * @return Load-count checksum, modulo 2^32. */
ANALYZE uint32_t task_job_t10(void) {
    uint32_t sum = 0;
    for (int s = 0; s < 1200; ++s)
        sum += kernel_t10();
    return sum;
}
volatile uint8_t data_t11[8] __attribute__((aligned(4096), section(".chaser_data.11")));
INLINE static uint32_t kernel_t11(void) {
    uint32_t sum = 0;
    for (int i = 0; i < 8; i += 1)
        sum += data_t11[i];
    return sum;
}
/** @brief Execute one fixed job without resetting data or cache.
 * @return Load-count checksum, modulo 2^32. */
ANALYZE uint32_t task_job_t11(void) {
    uint32_t sum = 0;
    for (int s = 0; s < 1200; ++s)
        sum += kernel_t11();
    return sum;
}
volatile uint8_t data_t12[8] __attribute__((aligned(4096), section(".chaser_data.12")));
INLINE static uint32_t kernel_t12(void) {
    uint32_t sum = 0;
    for (int i = 0; i < 8; i += 1)
        sum += data_t12[i];
    return sum;
}
/** @brief Execute one fixed job without resetting data or cache.
 * @return Load-count checksum, modulo 2^32. */
ANALYZE uint32_t task_job_t12(void) {
    uint32_t sum = 0;
    for (int s = 0; s < 1200; ++s)
        sum += kernel_t12();
    return sum;
}
volatile uint8_t data_t13[8] __attribute__((aligned(4096), section(".chaser_data.13")));
INLINE static uint32_t kernel_t13(void) {
    uint32_t sum = 0;
    for (int i = 0; i < 8; i += 1)
        sum += data_t13[i];
    return sum;
}
/** @brief Execute one fixed job without resetting data or cache.
 * @return Load-count checksum, modulo 2^32. */
ANALYZE uint32_t task_job_t13(void) {
    uint32_t sum = 0;
    for (int s = 0; s < 1200; ++s)
        sum += kernel_t13();
    return sum;
}
volatile uint8_t data_t14[8] __attribute__((aligned(4096), section(".chaser_data.14")));
INLINE static uint32_t kernel_t14(void) {
    uint32_t sum = 0;
    for (int i = 0; i < 8; i += 1)
        sum += data_t14[i];
    return sum;
}
/** @brief Execute one fixed job without resetting data or cache.
 * @return Load-count checksum, modulo 2^32. */
ANALYZE uint32_t task_job_t14(void) {
    uint32_t sum = 0;
    for (int s = 0; s < 1200; ++s)
        sum += kernel_t14();
    return sum;
}
volatile uint8_t data_t15[8] __attribute__((aligned(4096), section(".chaser_data.15")));
INLINE static uint32_t kernel_t15(void) {
    uint32_t sum = 0;
    for (int i = 0; i < 8; i += 1)
        sum += data_t15[i];
    return sum;
}
/** @brief Execute one fixed job without resetting data or cache.
 * @return Load-count checksum, modulo 2^32. */
ANALYZE uint32_t task_job_t15(void) {
    uint32_t sum = 0;
    for (int s = 0; s < 1200; ++s)
        sum += kernel_t15();
    return sum;
}
void workload_prepare(void) {
    for (int i = 0; i < 8; ++i) data_t0[i] = 1;
    for (int i = 0; i < 8; ++i) data_t1[i] = 1;
    for (int i = 0; i < 8; ++i) data_t2[i] = 1;
    for (int i = 0; i < 8; ++i) data_t3[i] = 1;
    for (int i = 0; i < 8; ++i) data_t4[i] = 1;
    for (int i = 0; i < 8; ++i) data_t5[i] = 1;
    for (int i = 0; i < 8; ++i) data_t6[i] = 1;
    for (int i = 0; i < 8; ++i) data_t7[i] = 1;
    for (int i = 0; i < 8; ++i) data_t8[i] = 1;
    for (int i = 0; i < 8; ++i) data_t9[i] = 1;
    for (int i = 0; i < 8; ++i) data_t10[i] = 1;
    for (int i = 0; i < 8; ++i) data_t11[i] = 1;
    for (int i = 0; i < 8; ++i) data_t12[i] = 1;
    for (int i = 0; i < 8; ++i) data_t13[i] = 1;
    for (int i = 0; i < 8; ++i) data_t14[i] = 1;
    for (int i = 0; i < 8; ++i) data_t15[i] = 1;
}
uint32_t (*const workload_jobs[])(void) = {
    task_job_t0,
    task_job_t1,
    task_job_t2,
    task_job_t3,
    task_job_t4,
    task_job_t5,
    task_job_t6,
    task_job_t7,
    task_job_t8,
    task_job_t9,
    task_job_t10,
    task_job_t11,
    task_job_t12,
    task_job_t13,
    task_job_t14,
    task_job_t15,
};
const uint32_t workload_expected[] = {
9600U, 9600U, 9600U, 9600U, 9600U, 9600U, 9600U, 9600U, 9600U, 9600U, 9600U, 9600U, 9600U, 9600U, 9600U, 9600U
};
