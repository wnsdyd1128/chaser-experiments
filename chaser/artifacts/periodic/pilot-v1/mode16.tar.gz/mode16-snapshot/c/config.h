#define TASK_COUNT 16
#define MAX_JOBS 2
#define ARCHITECTURE 1
#define CHASER_PLAN_HASH "ffdd57f62cdd1c3e9dd9f2f35c524bfe2d792c33ac1ef182ec2b336acf5fa157"
#define CHASER_PERIODS {20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20}
#define CHASER_JOB_COUNTS {2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2}
#define CHASER_CORES {0, 1, 2, 3, 0, 1, 2, 3, 0, 1, 2, 3, 0, 1, 2, 3}
