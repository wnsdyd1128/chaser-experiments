#include "workload.h"
#ifdef __clang__
#define ANALYZE __attribute__((annotate("ape.analyze")))
#define INLINE __attribute__((annotate("ape.inline")))
#else
#define ANALYZE
#define INLINE
#endif
volatile uint8_t data_packed[8] __attribute__((aligned(4096), section(".chaser_data.00")));
INLINE static uint32_t kernel_packed(void) {
    uint32_t sum = 0;
    for (int i = 0; i < 8; i += 1)
        sum += data_packed[i];
    return sum;
}
/** @brief Execute one fixed job without resetting data or cache.
 * @return Load-count checksum, modulo 2^32. */
ANALYZE uint32_t task_job_packed(void) {
    uint32_t sum = 0;
    for (int s = 0; s < 1200; ++s)
        sum += kernel_packed();
    return sum;
}
volatile uint8_t data_spread[256] __attribute__((aligned(4096), section(".chaser_data.01")));
INLINE static uint32_t kernel_spread(void) {
    uint32_t sum = 0;
    for (int i = 0; i < 256; i += 32)
        sum += data_spread[i];
    return sum;
}
/** @brief Execute one fixed job without resetting data or cache.
 * @return Load-count checksum, modulo 2^32. */
ANALYZE uint32_t task_job_spread(void) {
    uint32_t sum = 0;
    for (int s = 0; s < 1200; ++s)
        sum += kernel_spread();
    return sum;
}
volatile uint8_t data_conflict[32768] __attribute__((aligned(4096), section(".chaser_data.02")));
INLINE static uint32_t kernel_conflict(void) {
    uint32_t sum = 0;
    for (int i = 0; i < 32768; i += 4096)
        sum += data_conflict[i];
    return sum;
}
/** @brief Execute one fixed job without resetting data or cache.
 * @return Load-count checksum, modulo 2^32. */
ANALYZE uint32_t task_job_conflict(void) {
    uint32_t sum = 0;
    for (int s = 0; s < 1200; ++s)
        sum += kernel_conflict();
    return sum;
}
void workload_prepare(void) {
    for (int i = 0; i < 8; ++i) data_packed[i] = 1;
    for (int i = 0; i < 256; ++i) data_spread[i] = 1;
    for (int i = 0; i < 32768; ++i) data_conflict[i] = 1;
}
uint32_t (*const workload_jobs[])(void) = {
    task_job_packed,
    task_job_spread,
    task_job_conflict,
};
const uint32_t workload_expected[] = {
9600U, 9600U, 9600U
};
