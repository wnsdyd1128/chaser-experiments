; ModuleID = '/tmp/chaser-periodic-ms/source/workload.c'
source_filename = "/tmp/chaser-periodic-ms/source/workload.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

@.str = private unnamed_addr constant [12 x i8] c"ape.analyze\00", section "llvm.metadata"
@.str.1 = private unnamed_addr constant [42 x i8] c"/tmp/chaser-periodic-ms/source/workload.c\00", section "llvm.metadata"
@data_packed = dso_local global [8 x i8] zeroinitializer, section ".chaser_data.00", align 4096, !dbg !0
@data_spread = dso_local global [256 x i8] zeroinitializer, section ".chaser_data.01", align 4096, !dbg !24
@data_conflict = dso_local global [32768 x i8] zeroinitializer, section ".chaser_data.02", align 4096, !dbg !33
@workload_jobs = dso_local constant [3 x i32 ()*] [i32 ()* @task_job_packed, i32 ()* @task_job_spread, i32 ()* @task_job_conflict], align 16, !dbg !5
@workload_expected = dso_local constant [3 x i32] [i32 9600, i32 9600, i32 9600], align 4, !dbg !20
@.str.2 = private unnamed_addr constant [11 x i8] c"ape.inline\00", section "llvm.metadata"
@llvm.global.annotations = appending global [6 x { i8*, i8*, i8*, i32, i8* }] [{ i8*, i8*, i8*, i32, i8* } { i8* bitcast (i32 ()* @task_job_packed to i8*), i8* getelementptr inbounds ([12 x i8], [12 x i8]* @.str, i32 0, i32 0), i8* getelementptr inbounds ([42 x i8], [42 x i8]* @.str.1, i32 0, i32 0), i32 18, i8* null }, { i8*, i8*, i8*, i32, i8* } { i8* bitcast (i32 ()* @task_job_spread to i8*), i8* getelementptr inbounds ([12 x i8], [12 x i8]* @.str, i32 0, i32 0), i8* getelementptr inbounds ([42 x i8], [42 x i8]* @.str.1, i32 0, i32 0), i32 33, i8* null }, { i8*, i8*, i8*, i32, i8* } { i8* bitcast (i32 ()* @task_job_conflict to i8*), i8* getelementptr inbounds ([12 x i8], [12 x i8]* @.str, i32 0, i32 0), i8* getelementptr inbounds ([42 x i8], [42 x i8]* @.str.1, i32 0, i32 0), i32 48, i8* null }, { i8*, i8*, i8*, i32, i8* } { i8* bitcast (i32 ()* @kernel_packed to i8*), i8* getelementptr inbounds ([11 x i8], [11 x i8]* @.str.2, i32 0, i32 0), i8* getelementptr inbounds ([42 x i8], [42 x i8]* @.str.1, i32 0, i32 0), i32 10, i8* null }, { i8*, i8*, i8*, i32, i8* } { i8* bitcast (i32 ()* @kernel_spread to i8*), i8* getelementptr inbounds ([11 x i8], [11 x i8]* @.str.2, i32 0, i32 0), i8* getelementptr inbounds ([42 x i8], [42 x i8]* @.str.1, i32 0, i32 0), i32 25, i8* null }, { i8*, i8*, i8*, i32, i8* } { i8* bitcast (i32 ()* @kernel_conflict to i8*), i8* getelementptr inbounds ([11 x i8], [11 x i8]* @.str.2, i32 0, i32 0), i8* getelementptr inbounds ([42 x i8], [42 x i8]* @.str.1, i32 0, i32 0), i32 40, i8* null }], section "llvm.metadata"

; Function Attrs: noinline nounwind uwtable
define dso_local i32 @task_job_packed() #0 !dbg !49 {
  %1 = alloca i32, align 4
  %2 = alloca i32, align 4
  call void @llvm.dbg.declare(metadata i32* %1, metadata !51, metadata !DIExpression()), !dbg !52
  store i32 0, i32* %1, align 4, !dbg !52
  call void @llvm.dbg.declare(metadata i32* %2, metadata !53, metadata !DIExpression()), !dbg !56
  store i32 0, i32* %2, align 4, !dbg !56
  br label %3, !dbg !57

3:                                                ; preds = %10, %0
  %4 = load i32, i32* %2, align 4, !dbg !58
  %5 = icmp slt i32 %4, 1200, !dbg !60
  br i1 %5, label %6, label %13, !dbg !61

6:                                                ; preds = %3
  %7 = call i32 @kernel_packed(), !dbg !62
  %8 = load i32, i32* %1, align 4, !dbg !63
  %9 = add i32 %8, %7, !dbg !63
  store i32 %9, i32* %1, align 4, !dbg !63
  br label %10, !dbg !64

10:                                               ; preds = %6
  %11 = load i32, i32* %2, align 4, !dbg !65
  %12 = add nsw i32 %11, 1, !dbg !65
  store i32 %12, i32* %2, align 4, !dbg !65
  br label %3, !dbg !66, !llvm.loop !67

13:                                               ; preds = %3
  %14 = load i32, i32* %1, align 4, !dbg !70
  ret i32 %14, !dbg !71
}

; Function Attrs: nofree nosync nounwind readnone speculatable willreturn
declare void @llvm.dbg.declare(metadata, metadata, metadata) #1

; Function Attrs: noinline nounwind uwtable
define internal i32 @kernel_packed() #0 !dbg !72 {
  %1 = alloca i32, align 4
  %2 = alloca i32, align 4
  call void @llvm.dbg.declare(metadata i32* %1, metadata !73, metadata !DIExpression()), !dbg !74
  store i32 0, i32* %1, align 4, !dbg !74
  call void @llvm.dbg.declare(metadata i32* %2, metadata !75, metadata !DIExpression()), !dbg !77
  store i32 0, i32* %2, align 4, !dbg !77
  br label %3, !dbg !78

3:                                                ; preds = %14, %0
  %4 = load i32, i32* %2, align 4, !dbg !79
  %5 = icmp slt i32 %4, 8, !dbg !81
  br i1 %5, label %6, label %17, !dbg !82

6:                                                ; preds = %3
  %7 = load i32, i32* %2, align 4, !dbg !83
  %8 = sext i32 %7 to i64, !dbg !84
  %9 = getelementptr inbounds [8 x i8], [8 x i8]* @data_packed, i64 0, i64 %8, !dbg !84
  %10 = load volatile i8, i8* %9, align 1, !dbg !84
  %11 = zext i8 %10 to i32, !dbg !84
  %12 = load i32, i32* %1, align 4, !dbg !85
  %13 = add i32 %12, %11, !dbg !85
  store i32 %13, i32* %1, align 4, !dbg !85
  br label %14, !dbg !86

14:                                               ; preds = %6
  %15 = load i32, i32* %2, align 4, !dbg !87
  %16 = add nsw i32 %15, 1, !dbg !87
  store i32 %16, i32* %2, align 4, !dbg !87
  br label %3, !dbg !88, !llvm.loop !89

17:                                               ; preds = %3
  %18 = load i32, i32* %1, align 4, !dbg !91
  ret i32 %18, !dbg !92
}

; Function Attrs: noinline nounwind uwtable
define dso_local i32 @task_job_spread() #0 !dbg !93 {
  %1 = alloca i32, align 4
  %2 = alloca i32, align 4
  call void @llvm.dbg.declare(metadata i32* %1, metadata !94, metadata !DIExpression()), !dbg !95
  store i32 0, i32* %1, align 4, !dbg !95
  call void @llvm.dbg.declare(metadata i32* %2, metadata !96, metadata !DIExpression()), !dbg !98
  store i32 0, i32* %2, align 4, !dbg !98
  br label %3, !dbg !99

3:                                                ; preds = %10, %0
  %4 = load i32, i32* %2, align 4, !dbg !100
  %5 = icmp slt i32 %4, 1200, !dbg !102
  br i1 %5, label %6, label %13, !dbg !103

6:                                                ; preds = %3
  %7 = call i32 @kernel_spread(), !dbg !104
  %8 = load i32, i32* %1, align 4, !dbg !105
  %9 = add i32 %8, %7, !dbg !105
  store i32 %9, i32* %1, align 4, !dbg !105
  br label %10, !dbg !106

10:                                               ; preds = %6
  %11 = load i32, i32* %2, align 4, !dbg !107
  %12 = add nsw i32 %11, 1, !dbg !107
  store i32 %12, i32* %2, align 4, !dbg !107
  br label %3, !dbg !108, !llvm.loop !109

13:                                               ; preds = %3
  %14 = load i32, i32* %1, align 4, !dbg !111
  ret i32 %14, !dbg !112
}

; Function Attrs: noinline nounwind uwtable
define internal i32 @kernel_spread() #0 !dbg !113 {
  %1 = alloca i32, align 4
  %2 = alloca i32, align 4
  call void @llvm.dbg.declare(metadata i32* %1, metadata !114, metadata !DIExpression()), !dbg !115
  store i32 0, i32* %1, align 4, !dbg !115
  call void @llvm.dbg.declare(metadata i32* %2, metadata !116, metadata !DIExpression()), !dbg !118
  store i32 0, i32* %2, align 4, !dbg !118
  br label %3, !dbg !119

3:                                                ; preds = %14, %0
  %4 = load i32, i32* %2, align 4, !dbg !120
  %5 = icmp slt i32 %4, 256, !dbg !122
  br i1 %5, label %6, label %17, !dbg !123

6:                                                ; preds = %3
  %7 = load i32, i32* %2, align 4, !dbg !124
  %8 = sext i32 %7 to i64, !dbg !125
  %9 = getelementptr inbounds [256 x i8], [256 x i8]* @data_spread, i64 0, i64 %8, !dbg !125
  %10 = load volatile i8, i8* %9, align 1, !dbg !125
  %11 = zext i8 %10 to i32, !dbg !125
  %12 = load i32, i32* %1, align 4, !dbg !126
  %13 = add i32 %12, %11, !dbg !126
  store i32 %13, i32* %1, align 4, !dbg !126
  br label %14, !dbg !127

14:                                               ; preds = %6
  %15 = load i32, i32* %2, align 4, !dbg !128
  %16 = add nsw i32 %15, 32, !dbg !128
  store i32 %16, i32* %2, align 4, !dbg !128
  br label %3, !dbg !129, !llvm.loop !130

17:                                               ; preds = %3
  %18 = load i32, i32* %1, align 4, !dbg !132
  ret i32 %18, !dbg !133
}

; Function Attrs: noinline nounwind uwtable
define dso_local i32 @task_job_conflict() #0 !dbg !134 {
  %1 = alloca i32, align 4
  %2 = alloca i32, align 4
  call void @llvm.dbg.declare(metadata i32* %1, metadata !135, metadata !DIExpression()), !dbg !136
  store i32 0, i32* %1, align 4, !dbg !136
  call void @llvm.dbg.declare(metadata i32* %2, metadata !137, metadata !DIExpression()), !dbg !139
  store i32 0, i32* %2, align 4, !dbg !139
  br label %3, !dbg !140

3:                                                ; preds = %10, %0
  %4 = load i32, i32* %2, align 4, !dbg !141
  %5 = icmp slt i32 %4, 1200, !dbg !143
  br i1 %5, label %6, label %13, !dbg !144

6:                                                ; preds = %3
  %7 = call i32 @kernel_conflict(), !dbg !145
  %8 = load i32, i32* %1, align 4, !dbg !146
  %9 = add i32 %8, %7, !dbg !146
  store i32 %9, i32* %1, align 4, !dbg !146
  br label %10, !dbg !147

10:                                               ; preds = %6
  %11 = load i32, i32* %2, align 4, !dbg !148
  %12 = add nsw i32 %11, 1, !dbg !148
  store i32 %12, i32* %2, align 4, !dbg !148
  br label %3, !dbg !149, !llvm.loop !150

13:                                               ; preds = %3
  %14 = load i32, i32* %1, align 4, !dbg !152
  ret i32 %14, !dbg !153
}

; Function Attrs: noinline nounwind uwtable
define internal i32 @kernel_conflict() #0 !dbg !154 {
  %1 = alloca i32, align 4
  %2 = alloca i32, align 4
  call void @llvm.dbg.declare(metadata i32* %1, metadata !155, metadata !DIExpression()), !dbg !156
  store i32 0, i32* %1, align 4, !dbg !156
  call void @llvm.dbg.declare(metadata i32* %2, metadata !157, metadata !DIExpression()), !dbg !159
  store i32 0, i32* %2, align 4, !dbg !159
  br label %3, !dbg !160

3:                                                ; preds = %14, %0
  %4 = load i32, i32* %2, align 4, !dbg !161
  %5 = icmp slt i32 %4, 32768, !dbg !163
  br i1 %5, label %6, label %17, !dbg !164

6:                                                ; preds = %3
  %7 = load i32, i32* %2, align 4, !dbg !165
  %8 = sext i32 %7 to i64, !dbg !166
  %9 = getelementptr inbounds [32768 x i8], [32768 x i8]* @data_conflict, i64 0, i64 %8, !dbg !166
  %10 = load volatile i8, i8* %9, align 1, !dbg !166
  %11 = zext i8 %10 to i32, !dbg !166
  %12 = load i32, i32* %1, align 4, !dbg !167
  %13 = add i32 %12, %11, !dbg !167
  store i32 %13, i32* %1, align 4, !dbg !167
  br label %14, !dbg !168

14:                                               ; preds = %6
  %15 = load i32, i32* %2, align 4, !dbg !169
  %16 = add nsw i32 %15, 4096, !dbg !169
  store i32 %16, i32* %2, align 4, !dbg !169
  br label %3, !dbg !170, !llvm.loop !171

17:                                               ; preds = %3
  %18 = load i32, i32* %1, align 4, !dbg !173
  ret i32 %18, !dbg !174
}

; Function Attrs: noinline nounwind uwtable
define dso_local void @workload_prepare() #0 !dbg !175 {
  %1 = alloca i32, align 4
  %2 = alloca i32, align 4
  %3 = alloca i32, align 4
  call void @llvm.dbg.declare(metadata i32* %1, metadata !178, metadata !DIExpression()), !dbg !180
  store i32 0, i32* %1, align 4, !dbg !180
  br label %4, !dbg !181

4:                                                ; preds = %11, %0
  %5 = load i32, i32* %1, align 4, !dbg !182
  %6 = icmp slt i32 %5, 8, !dbg !184
  br i1 %6, label %7, label %14, !dbg !185

7:                                                ; preds = %4
  %8 = load i32, i32* %1, align 4, !dbg !186
  %9 = sext i32 %8 to i64, !dbg !187
  %10 = getelementptr inbounds [8 x i8], [8 x i8]* @data_packed, i64 0, i64 %9, !dbg !187
  store volatile i8 1, i8* %10, align 1, !dbg !188
  br label %11, !dbg !187

11:                                               ; preds = %7
  %12 = load i32, i32* %1, align 4, !dbg !189
  %13 = add nsw i32 %12, 1, !dbg !189
  store i32 %13, i32* %1, align 4, !dbg !189
  br label %4, !dbg !190, !llvm.loop !191

14:                                               ; preds = %4
  call void @llvm.dbg.declare(metadata i32* %2, metadata !193, metadata !DIExpression()), !dbg !195
  store i32 0, i32* %2, align 4, !dbg !195
  br label %15, !dbg !196

15:                                               ; preds = %22, %14
  %16 = load i32, i32* %2, align 4, !dbg !197
  %17 = icmp slt i32 %16, 256, !dbg !199
  br i1 %17, label %18, label %25, !dbg !200

18:                                               ; preds = %15
  %19 = load i32, i32* %2, align 4, !dbg !201
  %20 = sext i32 %19 to i64, !dbg !202
  %21 = getelementptr inbounds [256 x i8], [256 x i8]* @data_spread, i64 0, i64 %20, !dbg !202
  store volatile i8 1, i8* %21, align 1, !dbg !203
  br label %22, !dbg !202

22:                                               ; preds = %18
  %23 = load i32, i32* %2, align 4, !dbg !204
  %24 = add nsw i32 %23, 1, !dbg !204
  store i32 %24, i32* %2, align 4, !dbg !204
  br label %15, !dbg !205, !llvm.loop !206

25:                                               ; preds = %15
  call void @llvm.dbg.declare(metadata i32* %3, metadata !208, metadata !DIExpression()), !dbg !210
  store i32 0, i32* %3, align 4, !dbg !210
  br label %26, !dbg !211

26:                                               ; preds = %33, %25
  %27 = load i32, i32* %3, align 4, !dbg !212
  %28 = icmp slt i32 %27, 32768, !dbg !214
  br i1 %28, label %29, label %36, !dbg !215

29:                                               ; preds = %26
  %30 = load i32, i32* %3, align 4, !dbg !216
  %31 = sext i32 %30 to i64, !dbg !217
  %32 = getelementptr inbounds [32768 x i8], [32768 x i8]* @data_conflict, i64 0, i64 %31, !dbg !217
  store volatile i8 1, i8* %32, align 1, !dbg !218
  br label %33, !dbg !217

33:                                               ; preds = %29
  %34 = load i32, i32* %3, align 4, !dbg !219
  %35 = add nsw i32 %34, 1, !dbg !219
  store i32 %35, i32* %3, align 4, !dbg !219
  br label %26, !dbg !220, !llvm.loop !221

36:                                               ; preds = %26
  ret void, !dbg !223
}

attributes #0 = { noinline nounwind uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { nofree nosync nounwind readnone speculatable willreturn }

!llvm.dbg.cu = !{!2}
!llvm.module.flags = !{!41, !42, !43, !44, !45, !46, !47}
!llvm.ident = !{!48}

!0 = !DIGlobalVariableExpression(var: !1, expr: !DIExpression())
!1 = distinct !DIGlobalVariable(name: "data_packed", scope: !2, file: !7, line: 9, type: !38, isLocal: false, isDefinition: true, align: 32768)
!2 = distinct !DICompileUnit(language: DW_LANG_C99, file: !3, producer: "Ubuntu clang version 14.0.0-1ubuntu1.1", isOptimized: false, runtimeVersion: 0, emissionKind: FullDebug, globals: !4, splitDebugInlining: false, nameTableKind: None)
!3 = !DIFile(filename: "/tmp/chaser-periodic-ms/source/workload.c", directory: "/tmp/chaser-periodic-ms/analysis", checksumkind: CSK_MD5, checksum: "1183fd7409f67692481377362f8a4942")
!4 = !{!5, !20, !0, !24, !33}
!5 = !DIGlobalVariableExpression(var: !6, expr: !DIExpression())
!6 = distinct !DIGlobalVariable(name: "workload_jobs", scope: !2, file: !7, line: 59, type: !8, isLocal: false, isDefinition: true)
!7 = !DIFile(filename: "source/workload.c", directory: "/tmp/chaser-periodic-ms", checksumkind: CSK_MD5, checksum: "1183fd7409f67692481377362f8a4942")
!8 = !DICompositeType(tag: DW_TAG_array_type, baseType: !9, size: 192, elements: !18)
!9 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !10)
!10 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !11, size: 64)
!11 = !DISubroutineType(types: !12)
!12 = !{!13}
!13 = !DIDerivedType(tag: DW_TAG_typedef, name: "uint32_t", file: !14, line: 26, baseType: !15)
!14 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/stdint-uintn.h", directory: "", checksumkind: CSK_MD5, checksum: "2bf2ae53c58c01b1a1b9383b5195125c")
!15 = !DIDerivedType(tag: DW_TAG_typedef, name: "__uint32_t", file: !16, line: 42, baseType: !17)
!16 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/types.h", directory: "", checksumkind: CSK_MD5, checksum: "d108b5f93a74c50510d7d9bc0ab36df9")
!17 = !DIBasicType(name: "unsigned int", size: 32, encoding: DW_ATE_unsigned)
!18 = !{!19}
!19 = !DISubrange(count: 3)
!20 = !DIGlobalVariableExpression(var: !21, expr: !DIExpression())
!21 = distinct !DIGlobalVariable(name: "workload_expected", scope: !2, file: !7, line: 64, type: !22, isLocal: false, isDefinition: true)
!22 = !DICompositeType(tag: DW_TAG_array_type, baseType: !23, size: 96, elements: !18)
!23 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !13)
!24 = !DIGlobalVariableExpression(var: !25, expr: !DIExpression())
!25 = distinct !DIGlobalVariable(name: "data_spread", scope: !2, file: !7, line: 24, type: !26, isLocal: false, isDefinition: true, align: 32768)
!26 = !DICompositeType(tag: DW_TAG_array_type, baseType: !27, size: 2048, elements: !31)
!27 = !DIDerivedType(tag: DW_TAG_volatile_type, baseType: !28)
!28 = !DIDerivedType(tag: DW_TAG_typedef, name: "uint8_t", file: !14, line: 24, baseType: !29)
!29 = !DIDerivedType(tag: DW_TAG_typedef, name: "__uint8_t", file: !16, line: 38, baseType: !30)
!30 = !DIBasicType(name: "unsigned char", size: 8, encoding: DW_ATE_unsigned_char)
!31 = !{!32}
!32 = !DISubrange(count: 256)
!33 = !DIGlobalVariableExpression(var: !34, expr: !DIExpression())
!34 = distinct !DIGlobalVariable(name: "data_conflict", scope: !2, file: !7, line: 39, type: !35, isLocal: false, isDefinition: true, align: 32768)
!35 = !DICompositeType(tag: DW_TAG_array_type, baseType: !27, size: 262144, elements: !36)
!36 = !{!37}
!37 = !DISubrange(count: 32768)
!38 = !DICompositeType(tag: DW_TAG_array_type, baseType: !27, size: 64, elements: !39)
!39 = !{!40}
!40 = !DISubrange(count: 8)
!41 = !{i32 7, !"Dwarf Version", i32 5}
!42 = !{i32 2, !"Debug Info Version", i32 3}
!43 = !{i32 1, !"wchar_size", i32 4}
!44 = !{i32 7, !"PIC Level", i32 2}
!45 = !{i32 7, !"PIE Level", i32 2}
!46 = !{i32 7, !"uwtable", i32 1}
!47 = !{i32 7, !"frame-pointer", i32 2}
!48 = !{!"Ubuntu clang version 14.0.0-1ubuntu1.1"}
!49 = distinct !DISubprogram(name: "task_job_packed", scope: !7, file: !7, line: 18, type: !11, scopeLine: 18, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !2, retainedNodes: !50)
!50 = !{}
!51 = !DILocalVariable(name: "sum", scope: !49, file: !7, line: 19, type: !13)
!52 = !DILocation(line: 19, column: 14, scope: !49)
!53 = !DILocalVariable(name: "s", scope: !54, file: !7, line: 20, type: !55)
!54 = distinct !DILexicalBlock(scope: !49, file: !7, line: 20, column: 5)
!55 = !DIBasicType(name: "int", size: 32, encoding: DW_ATE_signed)
!56 = !DILocation(line: 20, column: 14, scope: !54)
!57 = !DILocation(line: 20, column: 10, scope: !54)
!58 = !DILocation(line: 20, column: 21, scope: !59)
!59 = distinct !DILexicalBlock(scope: !54, file: !7, line: 20, column: 5)
!60 = !DILocation(line: 20, column: 23, scope: !59)
!61 = !DILocation(line: 20, column: 5, scope: !54)
!62 = !DILocation(line: 21, column: 16, scope: !59)
!63 = !DILocation(line: 21, column: 13, scope: !59)
!64 = !DILocation(line: 21, column: 9, scope: !59)
!65 = !DILocation(line: 20, column: 31, scope: !59)
!66 = !DILocation(line: 20, column: 5, scope: !59)
!67 = distinct !{!67, !61, !68, !69}
!68 = !DILocation(line: 21, column: 30, scope: !54)
!69 = !{!"llvm.loop.mustprogress"}
!70 = !DILocation(line: 22, column: 12, scope: !49)
!71 = !DILocation(line: 22, column: 5, scope: !49)
!72 = distinct !DISubprogram(name: "kernel_packed", scope: !7, file: !7, line: 10, type: !11, scopeLine: 10, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition, unit: !2, retainedNodes: !50)
!73 = !DILocalVariable(name: "sum", scope: !72, file: !7, line: 11, type: !13)
!74 = !DILocation(line: 11, column: 14, scope: !72)
!75 = !DILocalVariable(name: "i", scope: !76, file: !7, line: 12, type: !55)
!76 = distinct !DILexicalBlock(scope: !72, file: !7, line: 12, column: 5)
!77 = !DILocation(line: 12, column: 14, scope: !76)
!78 = !DILocation(line: 12, column: 10, scope: !76)
!79 = !DILocation(line: 12, column: 21, scope: !80)
!80 = distinct !DILexicalBlock(scope: !76, file: !7, line: 12, column: 5)
!81 = !DILocation(line: 12, column: 23, scope: !80)
!82 = !DILocation(line: 12, column: 5, scope: !76)
!83 = !DILocation(line: 13, column: 28, scope: !80)
!84 = !DILocation(line: 13, column: 16, scope: !80)
!85 = !DILocation(line: 13, column: 13, scope: !80)
!86 = !DILocation(line: 13, column: 9, scope: !80)
!87 = !DILocation(line: 12, column: 30, scope: !80)
!88 = !DILocation(line: 12, column: 5, scope: !80)
!89 = distinct !{!89, !82, !90, !69}
!90 = !DILocation(line: 13, column: 29, scope: !76)
!91 = !DILocation(line: 14, column: 12, scope: !72)
!92 = !DILocation(line: 14, column: 5, scope: !72)
!93 = distinct !DISubprogram(name: "task_job_spread", scope: !7, file: !7, line: 33, type: !11, scopeLine: 33, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !2, retainedNodes: !50)
!94 = !DILocalVariable(name: "sum", scope: !93, file: !7, line: 34, type: !13)
!95 = !DILocation(line: 34, column: 14, scope: !93)
!96 = !DILocalVariable(name: "s", scope: !97, file: !7, line: 35, type: !55)
!97 = distinct !DILexicalBlock(scope: !93, file: !7, line: 35, column: 5)
!98 = !DILocation(line: 35, column: 14, scope: !97)
!99 = !DILocation(line: 35, column: 10, scope: !97)
!100 = !DILocation(line: 35, column: 21, scope: !101)
!101 = distinct !DILexicalBlock(scope: !97, file: !7, line: 35, column: 5)
!102 = !DILocation(line: 35, column: 23, scope: !101)
!103 = !DILocation(line: 35, column: 5, scope: !97)
!104 = !DILocation(line: 36, column: 16, scope: !101)
!105 = !DILocation(line: 36, column: 13, scope: !101)
!106 = !DILocation(line: 36, column: 9, scope: !101)
!107 = !DILocation(line: 35, column: 31, scope: !101)
!108 = !DILocation(line: 35, column: 5, scope: !101)
!109 = distinct !{!109, !103, !110, !69}
!110 = !DILocation(line: 36, column: 30, scope: !97)
!111 = !DILocation(line: 37, column: 12, scope: !93)
!112 = !DILocation(line: 37, column: 5, scope: !93)
!113 = distinct !DISubprogram(name: "kernel_spread", scope: !7, file: !7, line: 25, type: !11, scopeLine: 25, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition, unit: !2, retainedNodes: !50)
!114 = !DILocalVariable(name: "sum", scope: !113, file: !7, line: 26, type: !13)
!115 = !DILocation(line: 26, column: 14, scope: !113)
!116 = !DILocalVariable(name: "i", scope: !117, file: !7, line: 27, type: !55)
!117 = distinct !DILexicalBlock(scope: !113, file: !7, line: 27, column: 5)
!118 = !DILocation(line: 27, column: 14, scope: !117)
!119 = !DILocation(line: 27, column: 10, scope: !117)
!120 = !DILocation(line: 27, column: 21, scope: !121)
!121 = distinct !DILexicalBlock(scope: !117, file: !7, line: 27, column: 5)
!122 = !DILocation(line: 27, column: 23, scope: !121)
!123 = !DILocation(line: 27, column: 5, scope: !117)
!124 = !DILocation(line: 28, column: 28, scope: !121)
!125 = !DILocation(line: 28, column: 16, scope: !121)
!126 = !DILocation(line: 28, column: 13, scope: !121)
!127 = !DILocation(line: 28, column: 9, scope: !121)
!128 = !DILocation(line: 27, column: 32, scope: !121)
!129 = !DILocation(line: 27, column: 5, scope: !121)
!130 = distinct !{!130, !123, !131, !69}
!131 = !DILocation(line: 28, column: 29, scope: !117)
!132 = !DILocation(line: 29, column: 12, scope: !113)
!133 = !DILocation(line: 29, column: 5, scope: !113)
!134 = distinct !DISubprogram(name: "task_job_conflict", scope: !7, file: !7, line: 48, type: !11, scopeLine: 48, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !2, retainedNodes: !50)
!135 = !DILocalVariable(name: "sum", scope: !134, file: !7, line: 49, type: !13)
!136 = !DILocation(line: 49, column: 14, scope: !134)
!137 = !DILocalVariable(name: "s", scope: !138, file: !7, line: 50, type: !55)
!138 = distinct !DILexicalBlock(scope: !134, file: !7, line: 50, column: 5)
!139 = !DILocation(line: 50, column: 14, scope: !138)
!140 = !DILocation(line: 50, column: 10, scope: !138)
!141 = !DILocation(line: 50, column: 21, scope: !142)
!142 = distinct !DILexicalBlock(scope: !138, file: !7, line: 50, column: 5)
!143 = !DILocation(line: 50, column: 23, scope: !142)
!144 = !DILocation(line: 50, column: 5, scope: !138)
!145 = !DILocation(line: 51, column: 16, scope: !142)
!146 = !DILocation(line: 51, column: 13, scope: !142)
!147 = !DILocation(line: 51, column: 9, scope: !142)
!148 = !DILocation(line: 50, column: 31, scope: !142)
!149 = !DILocation(line: 50, column: 5, scope: !142)
!150 = distinct !{!150, !144, !151, !69}
!151 = !DILocation(line: 51, column: 32, scope: !138)
!152 = !DILocation(line: 52, column: 12, scope: !134)
!153 = !DILocation(line: 52, column: 5, scope: !134)
!154 = distinct !DISubprogram(name: "kernel_conflict", scope: !7, file: !7, line: 40, type: !11, scopeLine: 40, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition, unit: !2, retainedNodes: !50)
!155 = !DILocalVariable(name: "sum", scope: !154, file: !7, line: 41, type: !13)
!156 = !DILocation(line: 41, column: 14, scope: !154)
!157 = !DILocalVariable(name: "i", scope: !158, file: !7, line: 42, type: !55)
!158 = distinct !DILexicalBlock(scope: !154, file: !7, line: 42, column: 5)
!159 = !DILocation(line: 42, column: 14, scope: !158)
!160 = !DILocation(line: 42, column: 10, scope: !158)
!161 = !DILocation(line: 42, column: 21, scope: !162)
!162 = distinct !DILexicalBlock(scope: !158, file: !7, line: 42, column: 5)
!163 = !DILocation(line: 42, column: 23, scope: !162)
!164 = !DILocation(line: 42, column: 5, scope: !158)
!165 = !DILocation(line: 43, column: 30, scope: !162)
!166 = !DILocation(line: 43, column: 16, scope: !162)
!167 = !DILocation(line: 43, column: 13, scope: !162)
!168 = !DILocation(line: 43, column: 9, scope: !162)
!169 = !DILocation(line: 42, column: 34, scope: !162)
!170 = !DILocation(line: 42, column: 5, scope: !162)
!171 = distinct !{!171, !164, !172, !69}
!172 = !DILocation(line: 43, column: 31, scope: !158)
!173 = !DILocation(line: 44, column: 12, scope: !154)
!174 = !DILocation(line: 44, column: 5, scope: !154)
!175 = distinct !DISubprogram(name: "workload_prepare", scope: !7, file: !7, line: 54, type: !176, scopeLine: 54, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !2, retainedNodes: !50)
!176 = !DISubroutineType(types: !177)
!177 = !{null}
!178 = !DILocalVariable(name: "i", scope: !179, file: !7, line: 55, type: !55)
!179 = distinct !DILexicalBlock(scope: !175, file: !7, line: 55, column: 5)
!180 = !DILocation(line: 55, column: 14, scope: !179)
!181 = !DILocation(line: 55, column: 10, scope: !179)
!182 = !DILocation(line: 55, column: 21, scope: !183)
!183 = distinct !DILexicalBlock(scope: !179, file: !7, line: 55, column: 5)
!184 = !DILocation(line: 55, column: 23, scope: !183)
!185 = !DILocation(line: 55, column: 5, scope: !179)
!186 = !DILocation(line: 55, column: 45, scope: !183)
!187 = !DILocation(line: 55, column: 33, scope: !183)
!188 = !DILocation(line: 55, column: 48, scope: !183)
!189 = !DILocation(line: 55, column: 28, scope: !183)
!190 = !DILocation(line: 55, column: 5, scope: !183)
!191 = distinct !{!191, !185, !192, !69}
!192 = !DILocation(line: 55, column: 50, scope: !179)
!193 = !DILocalVariable(name: "i", scope: !194, file: !7, line: 56, type: !55)
!194 = distinct !DILexicalBlock(scope: !175, file: !7, line: 56, column: 5)
!195 = !DILocation(line: 56, column: 14, scope: !194)
!196 = !DILocation(line: 56, column: 10, scope: !194)
!197 = !DILocation(line: 56, column: 21, scope: !198)
!198 = distinct !DILexicalBlock(scope: !194, file: !7, line: 56, column: 5)
!199 = !DILocation(line: 56, column: 23, scope: !198)
!200 = !DILocation(line: 56, column: 5, scope: !194)
!201 = !DILocation(line: 56, column: 47, scope: !198)
!202 = !DILocation(line: 56, column: 35, scope: !198)
!203 = !DILocation(line: 56, column: 50, scope: !198)
!204 = !DILocation(line: 56, column: 30, scope: !198)
!205 = !DILocation(line: 56, column: 5, scope: !198)
!206 = distinct !{!206, !200, !207, !69}
!207 = !DILocation(line: 56, column: 52, scope: !194)
!208 = !DILocalVariable(name: "i", scope: !209, file: !7, line: 57, type: !55)
!209 = distinct !DILexicalBlock(scope: !175, file: !7, line: 57, column: 5)
!210 = !DILocation(line: 57, column: 14, scope: !209)
!211 = !DILocation(line: 57, column: 10, scope: !209)
!212 = !DILocation(line: 57, column: 21, scope: !213)
!213 = distinct !DILexicalBlock(scope: !209, file: !7, line: 57, column: 5)
!214 = !DILocation(line: 57, column: 23, scope: !213)
!215 = !DILocation(line: 57, column: 5, scope: !209)
!216 = !DILocation(line: 57, column: 51, scope: !213)
!217 = !DILocation(line: 57, column: 37, scope: !213)
!218 = !DILocation(line: 57, column: 54, scope: !213)
!219 = !DILocation(line: 57, column: 32, scope: !213)
!220 = !DILocation(line: 57, column: 5, scope: !213)
!221 = distinct !{!221, !215, !222, !69}
!222 = !DILocation(line: 57, column: 56, scope: !209)
!223 = !DILocation(line: 58, column: 1, scope: !175)
