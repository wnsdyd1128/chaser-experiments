/* Generated driver; original functions follow unchanged except storage. */
#define MEDIUM_DATASET
#define POLYBENCH_USE_SCALAR_LB
#define POLYBENCH_STACK_ARRAYS
#define POLYBENCH_DUMP_ARRAYS
#include "adapter.h"
/**
 * This version is stamped on May 10, 2016
 *
 * Contact:
 *   Louis-Noel Pouchet <pouchet.ohio-state.edu>
 *   Tomofumi Yuki <tomofumi.yuki.fr>
 *
 * Web address: http://polybench.sourceforge.net
 */
/* correlation.c: this file is part of PolyBench/C */

#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <math.h>

/* Include polybench common header. */
#include <polybench.h>

/* Include benchmark-specific header. */
#include "correlation.h"


/* Array initialization. */

#define y1 pb_y1
DATA_TYPE data[N][M] PB_STORAGE(data);
DATA_TYPE corr[M][M] PB_STORAGE(corr);
DATA_TYPE mean[M] PB_STORAGE(mean);
DATA_TYPE stddev[M] PB_STORAGE(stddev);
static
void init_array (int m,
		 int n,
		 DATA_TYPE *float_n,
		 DATA_TYPE POLYBENCH_2D(data,N,M,n,m))
{
  int i, j;

  *float_n = (DATA_TYPE)N;

  for (i = 0; i < N; i++)
    for (j = 0; j < M; j++)
      data[i][j] = (DATA_TYPE)(i*j)/M + i;

}


/* DCE code. Must scan the entire live-out data.
   Can be used also to check the correctness of the output. */
static
void print_array(int m,
		 DATA_TYPE POLYBENCH_2D(corr,M,M,m,m))

{
  int i, j;

  POLYBENCH_DUMP_START;
  POLYBENCH_DUMP_BEGIN("corr");
  for (i = 0; i < m; i++)
    for (j = 0; j < m; j++) {
      if ((i * m + j) % 20 == 0) fprintf (POLYBENCH_DUMP_TARGET, "\n");
      fprintf (POLYBENCH_DUMP_TARGET, DATA_PRINTF_MODIFIER, corr[i][j]);
    }
  POLYBENCH_DUMP_END("corr");
  POLYBENCH_DUMP_FINISH;
}


/* Main computational kernel. The whole function will be timed,
   including the call and return. */
static
__attribute__((always_inline)) inline void kernel_correlation(int m, int n,
			DATA_TYPE float_n,
			DATA_TYPE POLYBENCH_2D(data,N,M,n,m),
			DATA_TYPE POLYBENCH_2D(corr,M,M,m,m),
			DATA_TYPE POLYBENCH_1D(mean,M,m),
			DATA_TYPE POLYBENCH_1D(stddev,M,m))
{
  int i, j, k;

  DATA_TYPE eps = SCALAR_VAL(0.1);


#pragma scop
  for (j = 0; j < _PB_M; j++)
    {
      mean[j] = SCALAR_VAL(0.0);
      for (i = 0; i < _PB_N; i++)
	mean[j] += data[i][j];
      mean[j] /= float_n;
    }


   for (j = 0; j < _PB_M; j++)
    {
      stddev[j] = SCALAR_VAL(0.0);
      for (i = 0; i < _PB_N; i++)
        stddev[j] += (data[i][j] - mean[j]) * (data[i][j] - mean[j]);
      stddev[j] /= float_n;
      stddev[j] = SQRT_FUN(stddev[j]);
      /* The following in an inelegant but usual way to handle
         near-zero std. dev. values, which below would cause a zero-
         divide. */
      stddev[j] = stddev[j] <= eps ? SCALAR_VAL(1.0) : stddev[j];
    }

  /* Center and reduce the column vectors. */
  for (i = 0; i < _PB_N; i++)
    for (j = 0; j < _PB_M; j++)
      {
        data[i][j] -= mean[j];
        data[i][j] /= SQRT_FUN(float_n) * stddev[j];
      }

  /* Calculate the m * m correlation matrix. */
  for (i = 0; i < _PB_M-1; i++)
    {
      corr[i][i] = SCALAR_VAL(1.0);
      for (j = i+1; j < _PB_M; j++)
        {
          corr[i][j] = SCALAR_VAL(0.0);
          for (k = 0; k < _PB_N; k++)
            corr[i][j] += (data[k][i] * data[k][j]);
          corr[j][i] = corr[i][j];
        }
    }
  corr[_PB_M-1][_PB_M-1] = SCALAR_VAL(1.0);
#pragma endscop

}



int n = N;
  int m = M;

  
  DATA_TYPE float_n;
void workload_prepare(void) {}
void workload_reset(unsigned task) {
  (void)task;
  memset(data, 0, sizeof(data));
  memset(corr, 0, sizeof(corr));
  memset(mean, 0, sizeof(mean));
  memset(stddev, 0, sizeof(stddev));
  init_array (m, n, &float_n, POLYBENCH_ARRAY(data));
}
PB_ANALYZE uint32_t task_job_polybench(void) {
  kernel_correlation (m, n, float_n,
		      POLYBENCH_ARRAY(data),
		      POLYBENCH_ARRAY(corr),
		      POLYBENCH_ARRAY(mean),
		      POLYBENCH_ARRAY(stddev));
  return 0;
}
uint32_t workload_checksum(unsigned task) {
  (void)task;
  pb_hash = 2166136261u;
  print_array(m, POLYBENCH_ARRAY(corr));
  return pb_hash;
}
uint32_t (*const workload_jobs[])(void) = {task_job_polybench};
#ifndef CHASER_EXPECTED
#define CHASER_EXPECTED 0u
#endif
const uint32_t workload_expected[] = {CHASER_EXPECTED};
#ifdef CHASER_NATIVE
int main(void) { workload_reset(0); task_job_polybench();
  uint32_t first = workload_checksum(0); pb_emit = 0;
  workload_reset(0); task_job_polybench();
  if (first != workload_checksum(0)) return 1;
  printf("%u\n", first); return 0; }
#endif
