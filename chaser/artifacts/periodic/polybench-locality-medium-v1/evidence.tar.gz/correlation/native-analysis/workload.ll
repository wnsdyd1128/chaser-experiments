; ModuleID = '/workspace/experiments/chaser/.cache/periodic-polybench/locality-medium-20260929/correlation/source/workload.c'
source_filename = "/workspace/experiments/chaser/.cache/periodic-polybench/locality-medium-20260929/correlation/source/workload.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

%struct._IO_FILE = type { i32, i8*, i8*, i8*, i8*, i8*, i8*, i8*, i8*, i8*, i8*, i8*, %struct._IO_marker*, %struct._IO_FILE*, i32, i32, i64, i16, i8, [1 x i8], i8*, i64, %struct._IO_codecvt*, %struct._IO_wide_data*, %struct._IO_FILE*, i8*, i64, i32, [20 x i8] }
%struct._IO_marker = type opaque
%struct._IO_codecvt = type opaque
%struct._IO_wide_data = type opaque
%struct.__va_list_tag = type { i32, i32, i8*, i8* }

@n = dso_local global i32 260, align 4, !dbg !0
@m = dso_local global i32 240, align 4, !dbg !9
@data = dso_local global [260 x [240 x double]] zeroinitializer, section ".chaser_data.data", align 64, !dbg !33
@corr = dso_local global [240 x [240 x double]] zeroinitializer, section ".chaser_data.corr", align 64, !dbg !39
@mean = dso_local global [240 x double] zeroinitializer, section ".chaser_data.mean", align 64, !dbg !43
@stddev = dso_local global [240 x double] zeroinitializer, section ".chaser_data.stddev", align 64, !dbg !47
@float_n = dso_local global double 0.000000e+00, align 8, !dbg !49
@.str = private unnamed_addr constant [12 x i8] c"ape.analyze\00", section "llvm.metadata"
@.str.1 = private unnamed_addr constant [111 x i8] c"/workspace/experiments/chaser/.cache/periodic-polybench/locality-medium-20260929/correlation/source/workload.c\00", section "llvm.metadata"
@pb_hash = internal global i32 0, align 4, !dbg !30
@workload_jobs = dso_local constant [1 x i32 ()*] [i32 ()* @task_job_polybench], align 8, !dbg !13
@workload_expected = dso_local constant [1 x i32] zeroinitializer, align 4, !dbg !26
@stderr = external global %struct._IO_FILE*, align 8
@.str.2 = private unnamed_addr constant [23 x i8] c"==BEGIN DUMP_ARRAYS==\0A\00", align 1
@.str.3 = private unnamed_addr constant [15 x i8] c"begin dump: %s\00", align 1
@.str.4 = private unnamed_addr constant [5 x i8] c"corr\00", align 1
@.str.5 = private unnamed_addr constant [2 x i8] c"\0A\00", align 1
@.str.6 = private unnamed_addr constant [8 x i8] c"%0.2lf \00", align 1
@.str.7 = private unnamed_addr constant [17 x i8] c"\0Aend   dump: %s\0A\00", align 1
@.str.8 = private unnamed_addr constant [23 x i8] c"==END   DUMP_ARRAYS==\0A\00", align 1
@pb_emit = internal global i32 1, align 4, !dbg !51
@llvm.global.annotations = appending global [1 x { i8*, i8*, i8*, i32, i8* }] [{ i8*, i8*, i8*, i32, i8* } { i8* bitcast (i32 ()* @task_job_polybench to i8*), i8* getelementptr inbounds ([12 x i8], [12 x i8]* @.str, i32 0, i32 0), i8* getelementptr inbounds ([111 x i8], [111 x i8]* @.str.1, i32 0, i32 0), i32 154, i8* null }], section "llvm.metadata"

; Function Attrs: noinline nounwind uwtable
define dso_local void @workload_prepare() #0 !dbg !61 {
  ret void, !dbg !65
}

; Function Attrs: noinline nounwind uwtable
define dso_local void @workload_reset(i32 noundef %0) #0 !dbg !66 {
  %2 = alloca i32, align 4
  store i32 %0, i32* %2, align 4
  call void @llvm.dbg.declare(metadata i32* %2, metadata !69, metadata !DIExpression()), !dbg !70
  %3 = load i32, i32* %2, align 4, !dbg !71
  call void @llvm.memset.p0i8.i64(i8* align 64 bitcast ([260 x [240 x double]]* @data to i8*), i8 0, i64 499200, i1 false), !dbg !72
  call void @llvm.memset.p0i8.i64(i8* align 64 bitcast ([240 x [240 x double]]* @corr to i8*), i8 0, i64 460800, i1 false), !dbg !73
  call void @llvm.memset.p0i8.i64(i8* align 64 bitcast ([240 x double]* @mean to i8*), i8 0, i64 1920, i1 false), !dbg !74
  call void @llvm.memset.p0i8.i64(i8* align 64 bitcast ([240 x double]* @stddev to i8*), i8 0, i64 1920, i1 false), !dbg !75
  %4 = load i32, i32* @m, align 4, !dbg !76
  %5 = load i32, i32* @n, align 4, !dbg !77
  call void @init_array(i32 noundef %4, i32 noundef %5, double* noundef @float_n, [240 x double]* noundef getelementptr inbounds ([260 x [240 x double]], [260 x [240 x double]]* @data, i64 0, i64 0)), !dbg !78
  ret void, !dbg !79
}

; Function Attrs: nofree nosync nounwind readnone speculatable willreturn
declare void @llvm.dbg.declare(metadata, metadata, metadata) #1

; Function Attrs: argmemonly nofree nounwind willreturn writeonly
declare void @llvm.memset.p0i8.i64(i8* nocapture writeonly, i8, i64, i1 immarg) #2

; Function Attrs: noinline nounwind uwtable
define internal void @init_array(i32 noundef %0, i32 noundef %1, double* noundef %2, [240 x double]* noundef %3) #0 !dbg !80 {
  %5 = alloca i32, align 4
  %6 = alloca i32, align 4
  %7 = alloca double*, align 8
  %8 = alloca [240 x double]*, align 8
  %9 = alloca i32, align 4
  %10 = alloca i32, align 4
  store i32 %0, i32* %5, align 4
  call void @llvm.dbg.declare(metadata i32* %5, metadata !85, metadata !DIExpression()), !dbg !86
  store i32 %1, i32* %6, align 4
  call void @llvm.dbg.declare(metadata i32* %6, metadata !87, metadata !DIExpression()), !dbg !88
  store double* %2, double** %7, align 8
  call void @llvm.dbg.declare(metadata double** %7, metadata !89, metadata !DIExpression()), !dbg !90
  store [240 x double]* %3, [240 x double]** %8, align 8
  call void @llvm.dbg.declare(metadata [240 x double]** %8, metadata !91, metadata !DIExpression()), !dbg !92
  call void @llvm.dbg.declare(metadata i32* %9, metadata !93, metadata !DIExpression()), !dbg !94
  call void @llvm.dbg.declare(metadata i32* %10, metadata !95, metadata !DIExpression()), !dbg !96
  %11 = load double*, double** %7, align 8, !dbg !97
  store double 2.600000e+02, double* %11, align 8, !dbg !98
  store i32 0, i32* %9, align 4, !dbg !99
  br label %12, !dbg !101

12:                                               ; preds = %39, %4
  %13 = load i32, i32* %9, align 4, !dbg !102
  %14 = icmp slt i32 %13, 260, !dbg !104
  br i1 %14, label %15, label %42, !dbg !105

15:                                               ; preds = %12
  store i32 0, i32* %10, align 4, !dbg !106
  br label %16, !dbg !108

16:                                               ; preds = %35, %15
  %17 = load i32, i32* %10, align 4, !dbg !109
  %18 = icmp slt i32 %17, 240, !dbg !111
  br i1 %18, label %19, label %38, !dbg !112

19:                                               ; preds = %16
  %20 = load i32, i32* %9, align 4, !dbg !113
  %21 = load i32, i32* %10, align 4, !dbg !114
  %22 = mul nsw i32 %20, %21, !dbg !115
  %23 = sitofp i32 %22 to double, !dbg !116
  %24 = fdiv double %23, 2.400000e+02, !dbg !117
  %25 = load i32, i32* %9, align 4, !dbg !118
  %26 = sitofp i32 %25 to double, !dbg !118
  %27 = fadd double %24, %26, !dbg !119
  %28 = load [240 x double]*, [240 x double]** %8, align 8, !dbg !120
  %29 = load i32, i32* %9, align 4, !dbg !121
  %30 = sext i32 %29 to i64, !dbg !120
  %31 = getelementptr inbounds [240 x double], [240 x double]* %28, i64 %30, !dbg !120
  %32 = load i32, i32* %10, align 4, !dbg !122
  %33 = sext i32 %32 to i64, !dbg !120
  %34 = getelementptr inbounds [240 x double], [240 x double]* %31, i64 0, i64 %33, !dbg !120
  store double %27, double* %34, align 8, !dbg !123
  br label %35, !dbg !120

35:                                               ; preds = %19
  %36 = load i32, i32* %10, align 4, !dbg !124
  %37 = add nsw i32 %36, 1, !dbg !124
  store i32 %37, i32* %10, align 4, !dbg !124
  br label %16, !dbg !125, !llvm.loop !126

38:                                               ; preds = %16
  br label %39, !dbg !127

39:                                               ; preds = %38
  %40 = load i32, i32* %9, align 4, !dbg !129
  %41 = add nsw i32 %40, 1, !dbg !129
  store i32 %41, i32* %9, align 4, !dbg !129
  br label %12, !dbg !130, !llvm.loop !131

42:                                               ; preds = %12
  ret void, !dbg !133
}

; Function Attrs: noinline nounwind uwtable
define dso_local i32 @task_job_polybench() #0 !dbg !134 {
  %1 = alloca i32, align 4
  %2 = alloca i32, align 4
  %3 = alloca double, align 8
  %4 = alloca [240 x double]*, align 8
  %5 = alloca [240 x double]*, align 8
  %6 = alloca double*, align 8
  %7 = alloca double*, align 8
  %8 = alloca i32, align 4
  %9 = alloca i32, align 4
  %10 = alloca i32, align 4
  %11 = alloca double, align 8
  %12 = load i32, i32* @m, align 4, !dbg !135
  %13 = load i32, i32* @n, align 4, !dbg !136
  %14 = load double, double* @float_n, align 8, !dbg !137
  store i32 %12, i32* %1, align 4
  call void @llvm.dbg.declare(metadata i32* %1, metadata !138, metadata !DIExpression()) #6, !dbg !142
  store i32 %13, i32* %2, align 4
  call void @llvm.dbg.declare(metadata i32* %2, metadata !144, metadata !DIExpression()) #6, !dbg !145
  store double %14, double* %3, align 8
  call void @llvm.dbg.declare(metadata double* %3, metadata !146, metadata !DIExpression()) #6, !dbg !147
  store [240 x double]* getelementptr inbounds ([260 x [240 x double]], [260 x [240 x double]]* @data, i64 0, i64 0), [240 x double]** %4, align 8
  call void @llvm.dbg.declare(metadata [240 x double]** %4, metadata !148, metadata !DIExpression()) #6, !dbg !149
  store [240 x double]* getelementptr inbounds ([240 x [240 x double]], [240 x [240 x double]]* @corr, i64 0, i64 0), [240 x double]** %5, align 8
  call void @llvm.dbg.declare(metadata [240 x double]** %5, metadata !150, metadata !DIExpression()) #6, !dbg !151
  store double* getelementptr inbounds ([240 x double], [240 x double]* @mean, i64 0, i64 0), double** %6, align 8
  call void @llvm.dbg.declare(metadata double** %6, metadata !152, metadata !DIExpression()) #6, !dbg !153
  store double* getelementptr inbounds ([240 x double], [240 x double]* @stddev, i64 0, i64 0), double** %7, align 8
  call void @llvm.dbg.declare(metadata double** %7, metadata !154, metadata !DIExpression()) #6, !dbg !155
  call void @llvm.dbg.declare(metadata i32* %8, metadata !156, metadata !DIExpression()) #6, !dbg !157
  call void @llvm.dbg.declare(metadata i32* %9, metadata !158, metadata !DIExpression()) #6, !dbg !159
  call void @llvm.dbg.declare(metadata i32* %10, metadata !160, metadata !DIExpression()) #6, !dbg !161
  call void @llvm.dbg.declare(metadata double* %11, metadata !162, metadata !DIExpression()) #6, !dbg !163
  store double 1.000000e-01, double* %11, align 8, !dbg !163
  store i32 0, i32* %9, align 4, !dbg !164
  br label %15, !dbg !166

15:                                               ; preds = %43, %0
  %16 = load i32, i32* %9, align 4, !dbg !167
  %17 = icmp slt i32 %16, 240, !dbg !169
  br i1 %17, label %18, label %53, !dbg !170

18:                                               ; preds = %15
  %19 = load double*, double** %6, align 8, !dbg !171
  %20 = load i32, i32* %9, align 4, !dbg !173
  %21 = sext i32 %20 to i64, !dbg !171
  %22 = getelementptr inbounds double, double* %19, i64 %21, !dbg !171
  store double 0.000000e+00, double* %22, align 8, !dbg !174
  store i32 0, i32* %8, align 4, !dbg !175
  br label %23, !dbg !177

23:                                               ; preds = %26, %18
  %24 = load i32, i32* %8, align 4, !dbg !178
  %25 = icmp slt i32 %24, 260, !dbg !180
  br i1 %25, label %26, label %43, !dbg !181

26:                                               ; preds = %23
  %27 = load [240 x double]*, [240 x double]** %4, align 8, !dbg !182
  %28 = load i32, i32* %8, align 4, !dbg !183
  %29 = sext i32 %28 to i64, !dbg !182
  %30 = getelementptr inbounds [240 x double], [240 x double]* %27, i64 %29, !dbg !182
  %31 = load i32, i32* %9, align 4, !dbg !184
  %32 = sext i32 %31 to i64, !dbg !182
  %33 = getelementptr inbounds [240 x double], [240 x double]* %30, i64 0, i64 %32, !dbg !182
  %34 = load double, double* %33, align 8, !dbg !182
  %35 = load double*, double** %6, align 8, !dbg !185
  %36 = load i32, i32* %9, align 4, !dbg !186
  %37 = sext i32 %36 to i64, !dbg !185
  %38 = getelementptr inbounds double, double* %35, i64 %37, !dbg !185
  %39 = load double, double* %38, align 8, !dbg !187
  %40 = fadd double %39, %34, !dbg !187
  store double %40, double* %38, align 8, !dbg !187
  %41 = load i32, i32* %8, align 4, !dbg !188
  %42 = add nsw i32 %41, 1, !dbg !188
  store i32 %42, i32* %8, align 4, !dbg !188
  br label %23, !dbg !189, !llvm.loop !190

43:                                               ; preds = %23
  %44 = load double, double* %3, align 8, !dbg !192
  %45 = load double*, double** %6, align 8, !dbg !193
  %46 = load i32, i32* %9, align 4, !dbg !194
  %47 = sext i32 %46 to i64, !dbg !193
  %48 = getelementptr inbounds double, double* %45, i64 %47, !dbg !193
  %49 = load double, double* %48, align 8, !dbg !195
  %50 = fdiv double %49, %44, !dbg !195
  store double %50, double* %48, align 8, !dbg !195
  %51 = load i32, i32* %9, align 4, !dbg !196
  %52 = add nsw i32 %51, 1, !dbg !196
  store i32 %52, i32* %9, align 4, !dbg !196
  br label %15, !dbg !197, !llvm.loop !198

53:                                               ; preds = %15
  store i32 0, i32* %9, align 4, !dbg !200
  br label %54, !dbg !202

54:                                               ; preds = %135, %53
  %55 = load i32, i32* %9, align 4, !dbg !203
  %56 = icmp slt i32 %55, 240, !dbg !205
  br i1 %56, label %57, label %143, !dbg !206

57:                                               ; preds = %54
  %58 = load double*, double** %7, align 8, !dbg !207
  %59 = load i32, i32* %9, align 4, !dbg !209
  %60 = sext i32 %59 to i64, !dbg !207
  %61 = getelementptr inbounds double, double* %58, i64 %60, !dbg !207
  store double 0.000000e+00, double* %61, align 8, !dbg !210
  store i32 0, i32* %8, align 4, !dbg !211
  br label %62, !dbg !213

62:                                               ; preds = %65, %57
  %63 = load i32, i32* %8, align 4, !dbg !214
  %64 = icmp slt i32 %63, 260, !dbg !216
  br i1 %64, label %65, label %103, !dbg !217

65:                                               ; preds = %62
  %66 = load [240 x double]*, [240 x double]** %4, align 8, !dbg !218
  %67 = load i32, i32* %8, align 4, !dbg !219
  %68 = sext i32 %67 to i64, !dbg !218
  %69 = getelementptr inbounds [240 x double], [240 x double]* %66, i64 %68, !dbg !218
  %70 = load i32, i32* %9, align 4, !dbg !220
  %71 = sext i32 %70 to i64, !dbg !218
  %72 = getelementptr inbounds [240 x double], [240 x double]* %69, i64 0, i64 %71, !dbg !218
  %73 = load double, double* %72, align 8, !dbg !218
  %74 = load double*, double** %6, align 8, !dbg !221
  %75 = load i32, i32* %9, align 4, !dbg !222
  %76 = sext i32 %75 to i64, !dbg !221
  %77 = getelementptr inbounds double, double* %74, i64 %76, !dbg !221
  %78 = load double, double* %77, align 8, !dbg !221
  %79 = fsub double %73, %78, !dbg !223
  %80 = load [240 x double]*, [240 x double]** %4, align 8, !dbg !224
  %81 = load i32, i32* %8, align 4, !dbg !225
  %82 = sext i32 %81 to i64, !dbg !224
  %83 = getelementptr inbounds [240 x double], [240 x double]* %80, i64 %82, !dbg !224
  %84 = load i32, i32* %9, align 4, !dbg !226
  %85 = sext i32 %84 to i64, !dbg !224
  %86 = getelementptr inbounds [240 x double], [240 x double]* %83, i64 0, i64 %85, !dbg !224
  %87 = load double, double* %86, align 8, !dbg !224
  %88 = load double*, double** %6, align 8, !dbg !227
  %89 = load i32, i32* %9, align 4, !dbg !228
  %90 = sext i32 %89 to i64, !dbg !227
  %91 = getelementptr inbounds double, double* %88, i64 %90, !dbg !227
  %92 = load double, double* %91, align 8, !dbg !227
  %93 = fsub double %87, %92, !dbg !229
  %94 = fmul double %79, %93, !dbg !230
  %95 = load double*, double** %7, align 8, !dbg !231
  %96 = load i32, i32* %9, align 4, !dbg !232
  %97 = sext i32 %96 to i64, !dbg !231
  %98 = getelementptr inbounds double, double* %95, i64 %97, !dbg !231
  %99 = load double, double* %98, align 8, !dbg !233
  %100 = fadd double %99, %94, !dbg !233
  store double %100, double* %98, align 8, !dbg !233
  %101 = load i32, i32* %8, align 4, !dbg !234
  %102 = add nsw i32 %101, 1, !dbg !234
  store i32 %102, i32* %8, align 4, !dbg !234
  br label %62, !dbg !235, !llvm.loop !236

103:                                              ; preds = %62
  %104 = load double, double* %3, align 8, !dbg !238
  %105 = load double*, double** %7, align 8, !dbg !239
  %106 = load i32, i32* %9, align 4, !dbg !240
  %107 = sext i32 %106 to i64, !dbg !239
  %108 = getelementptr inbounds double, double* %105, i64 %107, !dbg !239
  %109 = load double, double* %108, align 8, !dbg !241
  %110 = fdiv double %109, %104, !dbg !241
  store double %110, double* %108, align 8, !dbg !241
  %111 = load double*, double** %7, align 8, !dbg !242
  %112 = load i32, i32* %9, align 4, !dbg !242
  %113 = sext i32 %112 to i64, !dbg !242
  %114 = getelementptr inbounds double, double* %111, i64 %113, !dbg !242
  %115 = load double, double* %114, align 8, !dbg !242
  %116 = call double @sqrt(double noundef %115) #6, !dbg !242
  %117 = load double*, double** %7, align 8, !dbg !243
  %118 = load i32, i32* %9, align 4, !dbg !244
  %119 = sext i32 %118 to i64, !dbg !243
  %120 = getelementptr inbounds double, double* %117, i64 %119, !dbg !243
  store double %116, double* %120, align 8, !dbg !245
  %121 = load double*, double** %7, align 8, !dbg !246
  %122 = load i32, i32* %9, align 4, !dbg !247
  %123 = sext i32 %122 to i64, !dbg !246
  %124 = getelementptr inbounds double, double* %121, i64 %123, !dbg !246
  %125 = load double, double* %124, align 8, !dbg !246
  %126 = load double, double* %11, align 8, !dbg !248
  %127 = fcmp ole double %125, %126, !dbg !249
  br i1 %127, label %128, label %129, !dbg !246

128:                                              ; preds = %103
  br label %135, !dbg !246

129:                                              ; preds = %103
  %130 = load double*, double** %7, align 8, !dbg !250
  %131 = load i32, i32* %9, align 4, !dbg !251
  %132 = sext i32 %131 to i64, !dbg !250
  %133 = getelementptr inbounds double, double* %130, i64 %132, !dbg !250
  %134 = load double, double* %133, align 8, !dbg !250
  br label %135, !dbg !246

135:                                              ; preds = %129, %128
  %136 = phi double [ 1.000000e+00, %128 ], [ %134, %129 ], !dbg !246
  %137 = load double*, double** %7, align 8, !dbg !252
  %138 = load i32, i32* %9, align 4, !dbg !253
  %139 = sext i32 %138 to i64, !dbg !252
  %140 = getelementptr inbounds double, double* %137, i64 %139, !dbg !252
  store double %136, double* %140, align 8, !dbg !254
  %141 = load i32, i32* %9, align 4, !dbg !255
  %142 = add nsw i32 %141, 1, !dbg !255
  store i32 %142, i32* %9, align 4, !dbg !255
  br label %54, !dbg !256, !llvm.loop !257

143:                                              ; preds = %54
  store i32 0, i32* %8, align 4, !dbg !259
  br label %144, !dbg !261

144:                                              ; preds = %185, %143
  %145 = load i32, i32* %8, align 4, !dbg !262
  %146 = icmp slt i32 %145, 260, !dbg !264
  br i1 %146, label %147, label %188, !dbg !265

147:                                              ; preds = %144
  store i32 0, i32* %9, align 4, !dbg !266
  br label %148, !dbg !268

148:                                              ; preds = %151, %147
  %149 = load i32, i32* %9, align 4, !dbg !269
  %150 = icmp slt i32 %149, 240, !dbg !271
  br i1 %150, label %151, label %185, !dbg !272

151:                                              ; preds = %148
  %152 = load double*, double** %6, align 8, !dbg !273
  %153 = load i32, i32* %9, align 4, !dbg !275
  %154 = sext i32 %153 to i64, !dbg !273
  %155 = getelementptr inbounds double, double* %152, i64 %154, !dbg !273
  %156 = load double, double* %155, align 8, !dbg !273
  %157 = load [240 x double]*, [240 x double]** %4, align 8, !dbg !276
  %158 = load i32, i32* %8, align 4, !dbg !277
  %159 = sext i32 %158 to i64, !dbg !276
  %160 = getelementptr inbounds [240 x double], [240 x double]* %157, i64 %159, !dbg !276
  %161 = load i32, i32* %9, align 4, !dbg !278
  %162 = sext i32 %161 to i64, !dbg !276
  %163 = getelementptr inbounds [240 x double], [240 x double]* %160, i64 0, i64 %162, !dbg !276
  %164 = load double, double* %163, align 8, !dbg !279
  %165 = fsub double %164, %156, !dbg !279
  store double %165, double* %163, align 8, !dbg !279
  %166 = load double, double* %3, align 8, !dbg !280
  %167 = call double @sqrt(double noundef %166) #6, !dbg !280
  %168 = load double*, double** %7, align 8, !dbg !281
  %169 = load i32, i32* %9, align 4, !dbg !282
  %170 = sext i32 %169 to i64, !dbg !281
  %171 = getelementptr inbounds double, double* %168, i64 %170, !dbg !281
  %172 = load double, double* %171, align 8, !dbg !281
  %173 = fmul double %167, %172, !dbg !283
  %174 = load [240 x double]*, [240 x double]** %4, align 8, !dbg !284
  %175 = load i32, i32* %8, align 4, !dbg !285
  %176 = sext i32 %175 to i64, !dbg !284
  %177 = getelementptr inbounds [240 x double], [240 x double]* %174, i64 %176, !dbg !284
  %178 = load i32, i32* %9, align 4, !dbg !286
  %179 = sext i32 %178 to i64, !dbg !284
  %180 = getelementptr inbounds [240 x double], [240 x double]* %177, i64 0, i64 %179, !dbg !284
  %181 = load double, double* %180, align 8, !dbg !287
  %182 = fdiv double %181, %173, !dbg !287
  store double %182, double* %180, align 8, !dbg !287
  %183 = load i32, i32* %9, align 4, !dbg !288
  %184 = add nsw i32 %183, 1, !dbg !288
  store i32 %184, i32* %9, align 4, !dbg !288
  br label %148, !dbg !289, !llvm.loop !290

185:                                              ; preds = %148
  %186 = load i32, i32* %8, align 4, !dbg !292
  %187 = add nsw i32 %186, 1, !dbg !292
  store i32 %187, i32* %8, align 4, !dbg !292
  br label %144, !dbg !293, !llvm.loop !294

188:                                              ; preds = %144
  store i32 0, i32* %8, align 4, !dbg !296
  br label %189, !dbg !298

189:                                              ; preds = %263, %188
  %190 = load i32, i32* %8, align 4, !dbg !299
  %191 = icmp slt i32 %190, 239, !dbg !301
  br i1 %191, label %192, label %266, !dbg !302

192:                                              ; preds = %189
  %193 = load [240 x double]*, [240 x double]** %5, align 8, !dbg !303
  %194 = load i32, i32* %8, align 4, !dbg !305
  %195 = sext i32 %194 to i64, !dbg !303
  %196 = getelementptr inbounds [240 x double], [240 x double]* %193, i64 %195, !dbg !303
  %197 = load i32, i32* %8, align 4, !dbg !306
  %198 = sext i32 %197 to i64, !dbg !303
  %199 = getelementptr inbounds [240 x double], [240 x double]* %196, i64 0, i64 %198, !dbg !303
  store double 1.000000e+00, double* %199, align 8, !dbg !307
  %200 = load i32, i32* %8, align 4, !dbg !308
  %201 = add nsw i32 %200, 1, !dbg !310
  store i32 %201, i32* %9, align 4, !dbg !311
  br label %202, !dbg !312

202:                                              ; preds = %245, %192
  %203 = load i32, i32* %9, align 4, !dbg !313
  %204 = icmp slt i32 %203, 240, !dbg !315
  br i1 %204, label %205, label %263, !dbg !316

205:                                              ; preds = %202
  %206 = load [240 x double]*, [240 x double]** %5, align 8, !dbg !317
  %207 = load i32, i32* %8, align 4, !dbg !319
  %208 = sext i32 %207 to i64, !dbg !317
  %209 = getelementptr inbounds [240 x double], [240 x double]* %206, i64 %208, !dbg !317
  %210 = load i32, i32* %9, align 4, !dbg !320
  %211 = sext i32 %210 to i64, !dbg !317
  %212 = getelementptr inbounds [240 x double], [240 x double]* %209, i64 0, i64 %211, !dbg !317
  store double 0.000000e+00, double* %212, align 8, !dbg !321
  store i32 0, i32* %10, align 4, !dbg !322
  br label %213, !dbg !324

213:                                              ; preds = %216, %205
  %214 = load i32, i32* %10, align 4, !dbg !325
  %215 = icmp slt i32 %214, 260, !dbg !327
  br i1 %215, label %216, label %245, !dbg !328

216:                                              ; preds = %213
  %217 = load [240 x double]*, [240 x double]** %4, align 8, !dbg !329
  %218 = load i32, i32* %10, align 4, !dbg !330
  %219 = sext i32 %218 to i64, !dbg !329
  %220 = getelementptr inbounds [240 x double], [240 x double]* %217, i64 %219, !dbg !329
  %221 = load i32, i32* %8, align 4, !dbg !331
  %222 = sext i32 %221 to i64, !dbg !329
  %223 = getelementptr inbounds [240 x double], [240 x double]* %220, i64 0, i64 %222, !dbg !329
  %224 = load double, double* %223, align 8, !dbg !329
  %225 = load [240 x double]*, [240 x double]** %4, align 8, !dbg !332
  %226 = load i32, i32* %10, align 4, !dbg !333
  %227 = sext i32 %226 to i64, !dbg !332
  %228 = getelementptr inbounds [240 x double], [240 x double]* %225, i64 %227, !dbg !332
  %229 = load i32, i32* %9, align 4, !dbg !334
  %230 = sext i32 %229 to i64, !dbg !332
  %231 = getelementptr inbounds [240 x double], [240 x double]* %228, i64 0, i64 %230, !dbg !332
  %232 = load double, double* %231, align 8, !dbg !332
  %233 = fmul double %224, %232, !dbg !335
  %234 = load [240 x double]*, [240 x double]** %5, align 8, !dbg !336
  %235 = load i32, i32* %8, align 4, !dbg !337
  %236 = sext i32 %235 to i64, !dbg !336
  %237 = getelementptr inbounds [240 x double], [240 x double]* %234, i64 %236, !dbg !336
  %238 = load i32, i32* %9, align 4, !dbg !338
  %239 = sext i32 %238 to i64, !dbg !336
  %240 = getelementptr inbounds [240 x double], [240 x double]* %237, i64 0, i64 %239, !dbg !336
  %241 = load double, double* %240, align 8, !dbg !339
  %242 = fadd double %241, %233, !dbg !339
  store double %242, double* %240, align 8, !dbg !339
  %243 = load i32, i32* %10, align 4, !dbg !340
  %244 = add nsw i32 %243, 1, !dbg !340
  store i32 %244, i32* %10, align 4, !dbg !340
  br label %213, !dbg !341, !llvm.loop !342

245:                                              ; preds = %213
  %246 = load [240 x double]*, [240 x double]** %5, align 8, !dbg !344
  %247 = load i32, i32* %8, align 4, !dbg !345
  %248 = sext i32 %247 to i64, !dbg !344
  %249 = getelementptr inbounds [240 x double], [240 x double]* %246, i64 %248, !dbg !344
  %250 = load i32, i32* %9, align 4, !dbg !346
  %251 = sext i32 %250 to i64, !dbg !344
  %252 = getelementptr inbounds [240 x double], [240 x double]* %249, i64 0, i64 %251, !dbg !344
  %253 = load double, double* %252, align 8, !dbg !344
  %254 = load [240 x double]*, [240 x double]** %5, align 8, !dbg !347
  %255 = load i32, i32* %9, align 4, !dbg !348
  %256 = sext i32 %255 to i64, !dbg !347
  %257 = getelementptr inbounds [240 x double], [240 x double]* %254, i64 %256, !dbg !347
  %258 = load i32, i32* %8, align 4, !dbg !349
  %259 = sext i32 %258 to i64, !dbg !347
  %260 = getelementptr inbounds [240 x double], [240 x double]* %257, i64 0, i64 %259, !dbg !347
  store double %253, double* %260, align 8, !dbg !350
  %261 = load i32, i32* %9, align 4, !dbg !351
  %262 = add nsw i32 %261, 1, !dbg !351
  store i32 %262, i32* %9, align 4, !dbg !351
  br label %202, !dbg !352, !llvm.loop !353

263:                                              ; preds = %202
  %264 = load i32, i32* %8, align 4, !dbg !355
  %265 = add nsw i32 %264, 1, !dbg !355
  store i32 %265, i32* %8, align 4, !dbg !355
  br label %189, !dbg !356, !llvm.loop !357

266:                                              ; preds = %189
  %267 = load [240 x double]*, [240 x double]** %5, align 8, !dbg !359
  %268 = getelementptr inbounds [240 x double], [240 x double]* %267, i64 239, !dbg !359
  %269 = getelementptr inbounds [240 x double], [240 x double]* %268, i64 0, i64 239, !dbg !359
  store double 1.000000e+00, double* %269, align 8, !dbg !360
  ret i32 0, !dbg !361
}

; Function Attrs: noinline nounwind uwtable
define dso_local i32 @workload_checksum(i32 noundef %0) #0 !dbg !362 {
  %2 = alloca i32, align 4
  store i32 %0, i32* %2, align 4
  call void @llvm.dbg.declare(metadata i32* %2, metadata !365, metadata !DIExpression()), !dbg !366
  %3 = load i32, i32* %2, align 4, !dbg !367
  store i32 -2128831035, i32* @pb_hash, align 4, !dbg !368
  %4 = load i32, i32* @m, align 4, !dbg !369
  call void @print_array(i32 noundef %4, [240 x double]* noundef getelementptr inbounds ([240 x [240 x double]], [240 x [240 x double]]* @corr, i64 0, i64 0)), !dbg !370
  %5 = load i32, i32* @pb_hash, align 4, !dbg !371
  ret i32 %5, !dbg !372
}

; Function Attrs: noinline nounwind uwtable
define internal void @print_array(i32 noundef %0, [240 x double]* noundef %1) #0 !dbg !373 {
  %3 = alloca i32, align 4
  %4 = alloca [240 x double]*, align 8
  %5 = alloca i32, align 4
  %6 = alloca i32, align 4
  store i32 %0, i32* %3, align 4
  call void @llvm.dbg.declare(metadata i32* %3, metadata !376, metadata !DIExpression()), !dbg !377
  store [240 x double]* %1, [240 x double]** %4, align 8
  call void @llvm.dbg.declare(metadata [240 x double]** %4, metadata !378, metadata !DIExpression()), !dbg !379
  call void @llvm.dbg.declare(metadata i32* %5, metadata !380, metadata !DIExpression()), !dbg !381
  call void @llvm.dbg.declare(metadata i32* %6, metadata !382, metadata !DIExpression()), !dbg !383
  %7 = load %struct._IO_FILE*, %struct._IO_FILE** @stderr, align 8, !dbg !384
  %8 = call i32 (%struct._IO_FILE*, i8*, ...) @pb_fprintf(%struct._IO_FILE* noundef %7, i8* noundef getelementptr inbounds ([23 x i8], [23 x i8]* @.str.2, i64 0, i64 0)), !dbg !384
  %9 = load %struct._IO_FILE*, %struct._IO_FILE** @stderr, align 8, !dbg !385
  %10 = call i32 (%struct._IO_FILE*, i8*, ...) @pb_fprintf(%struct._IO_FILE* noundef %9, i8* noundef getelementptr inbounds ([15 x i8], [15 x i8]* @.str.3, i64 0, i64 0), i8* noundef getelementptr inbounds ([5 x i8], [5 x i8]* @.str.4, i64 0, i64 0)), !dbg !385
  store i32 0, i32* %5, align 4, !dbg !386
  br label %11, !dbg !388

11:                                               ; preds = %46, %2
  %12 = load i32, i32* %5, align 4, !dbg !389
  %13 = load i32, i32* %3, align 4, !dbg !391
  %14 = icmp slt i32 %12, %13, !dbg !392
  br i1 %14, label %15, label %49, !dbg !393

15:                                               ; preds = %11
  store i32 0, i32* %6, align 4, !dbg !394
  br label %16, !dbg !396

16:                                               ; preds = %42, %15
  %17 = load i32, i32* %6, align 4, !dbg !397
  %18 = load i32, i32* %3, align 4, !dbg !399
  %19 = icmp slt i32 %17, %18, !dbg !400
  br i1 %19, label %20, label %45, !dbg !401

20:                                               ; preds = %16
  %21 = load i32, i32* %5, align 4, !dbg !402
  %22 = load i32, i32* %3, align 4, !dbg !405
  %23 = mul nsw i32 %21, %22, !dbg !406
  %24 = load i32, i32* %6, align 4, !dbg !407
  %25 = add nsw i32 %23, %24, !dbg !408
  %26 = srem i32 %25, 20, !dbg !409
  %27 = icmp eq i32 %26, 0, !dbg !410
  br i1 %27, label %28, label %31, !dbg !411

28:                                               ; preds = %20
  %29 = load %struct._IO_FILE*, %struct._IO_FILE** @stderr, align 8, !dbg !412
  %30 = call i32 (%struct._IO_FILE*, i8*, ...) @pb_fprintf(%struct._IO_FILE* noundef %29, i8* noundef getelementptr inbounds ([2 x i8], [2 x i8]* @.str.5, i64 0, i64 0)), !dbg !413
  br label %31, !dbg !413

31:                                               ; preds = %28, %20
  %32 = load %struct._IO_FILE*, %struct._IO_FILE** @stderr, align 8, !dbg !414
  %33 = load [240 x double]*, [240 x double]** %4, align 8, !dbg !415
  %34 = load i32, i32* %5, align 4, !dbg !416
  %35 = sext i32 %34 to i64, !dbg !415
  %36 = getelementptr inbounds [240 x double], [240 x double]* %33, i64 %35, !dbg !415
  %37 = load i32, i32* %6, align 4, !dbg !417
  %38 = sext i32 %37 to i64, !dbg !415
  %39 = getelementptr inbounds [240 x double], [240 x double]* %36, i64 0, i64 %38, !dbg !415
  %40 = load double, double* %39, align 8, !dbg !415
  %41 = call i32 (%struct._IO_FILE*, i8*, ...) @pb_fprintf(%struct._IO_FILE* noundef %32, i8* noundef getelementptr inbounds ([8 x i8], [8 x i8]* @.str.6, i64 0, i64 0), double noundef %40), !dbg !418
  br label %42, !dbg !419

42:                                               ; preds = %31
  %43 = load i32, i32* %6, align 4, !dbg !420
  %44 = add nsw i32 %43, 1, !dbg !420
  store i32 %44, i32* %6, align 4, !dbg !420
  br label %16, !dbg !421, !llvm.loop !422

45:                                               ; preds = %16
  br label %46, !dbg !423

46:                                               ; preds = %45
  %47 = load i32, i32* %5, align 4, !dbg !424
  %48 = add nsw i32 %47, 1, !dbg !424
  store i32 %48, i32* %5, align 4, !dbg !424
  br label %11, !dbg !425, !llvm.loop !426

49:                                               ; preds = %11
  %50 = load %struct._IO_FILE*, %struct._IO_FILE** @stderr, align 8, !dbg !428
  %51 = call i32 (%struct._IO_FILE*, i8*, ...) @pb_fprintf(%struct._IO_FILE* noundef %50, i8* noundef getelementptr inbounds ([17 x i8], [17 x i8]* @.str.7, i64 0, i64 0), i8* noundef getelementptr inbounds ([5 x i8], [5 x i8]* @.str.4, i64 0, i64 0)), !dbg !428
  %52 = load %struct._IO_FILE*, %struct._IO_FILE** @stderr, align 8, !dbg !429
  %53 = call i32 (%struct._IO_FILE*, i8*, ...) @pb_fprintf(%struct._IO_FILE* noundef %52, i8* noundef getelementptr inbounds ([23 x i8], [23 x i8]* @.str.8, i64 0, i64 0)), !dbg !429
  ret void, !dbg !430
}

; Function Attrs: nounwind
declare double @sqrt(double noundef) #3

; Function Attrs: noinline nounwind uwtable
define internal i32 @pb_fprintf(%struct._IO_FILE* noundef %0, i8* noundef %1, ...) #0 !dbg !431 {
  %3 = alloca %struct._IO_FILE*, align 8
  %4 = alloca i8*, align 8
  %5 = alloca [768 x i8], align 16
  %6 = alloca [1 x %struct.__va_list_tag], align 16
  %7 = alloca i32, align 4
  %8 = alloca i32, align 4
  store %struct._IO_FILE* %0, %struct._IO_FILE** %3, align 8
  call void @llvm.dbg.declare(metadata %struct._IO_FILE** %3, metadata !495, metadata !DIExpression()), !dbg !496
  store i8* %1, i8** %4, align 8
  call void @llvm.dbg.declare(metadata i8** %4, metadata !497, metadata !DIExpression()), !dbg !498
  call void @llvm.dbg.declare(metadata [768 x i8]* %5, metadata !499, metadata !DIExpression()), !dbg !503
  call void @llvm.dbg.declare(metadata [1 x %struct.__va_list_tag]* %6, metadata !504, metadata !DIExpression()), !dbg !518
  %9 = getelementptr inbounds [1 x %struct.__va_list_tag], [1 x %struct.__va_list_tag]* %6, i64 0, i64 0, !dbg !519
  %10 = bitcast %struct.__va_list_tag* %9 to i8*, !dbg !519
  call void @llvm.va_start(i8* %10), !dbg !519
  call void @llvm.dbg.declare(metadata i32* %7, metadata !520, metadata !DIExpression()), !dbg !521
  %11 = getelementptr inbounds [768 x i8], [768 x i8]* %5, i64 0, i64 0, !dbg !522
  %12 = load i8*, i8** %4, align 8, !dbg !523
  %13 = getelementptr inbounds [1 x %struct.__va_list_tag], [1 x %struct.__va_list_tag]* %6, i64 0, i64 0, !dbg !524
  %14 = call i32 @vsnprintf(i8* noundef %11, i64 noundef 768, i8* noundef %12, %struct.__va_list_tag* noundef %13) #6, !dbg !525
  store i32 %14, i32* %7, align 4, !dbg !521
  %15 = getelementptr inbounds [1 x %struct.__va_list_tag], [1 x %struct.__va_list_tag]* %6, i64 0, i64 0, !dbg !526
  %16 = bitcast %struct.__va_list_tag* %15 to i8*, !dbg !526
  call void @llvm.va_end(i8* %16), !dbg !526
  %17 = load i32, i32* %7, align 4, !dbg !527
  %18 = icmp slt i32 %17, 0, !dbg !529
  br i1 %18, label %23, label %19, !dbg !530

19:                                               ; preds = %2
  %20 = load i32, i32* %7, align 4, !dbg !531
  %21 = zext i32 %20 to i64, !dbg !532
  %22 = icmp uge i64 %21, 768, !dbg !533
  br i1 %22, label %23, label %24, !dbg !534

23:                                               ; preds = %19, %2
  call void @abort() #7, !dbg !535
  unreachable, !dbg !535

24:                                               ; preds = %19
  call void @llvm.dbg.declare(metadata i32* %8, metadata !536, metadata !DIExpression()), !dbg !538
  store i32 0, i32* %8, align 4, !dbg !538
  br label %25, !dbg !539

25:                                               ; preds = %39, %24
  %26 = load i32, i32* %8, align 4, !dbg !540
  %27 = load i32, i32* %7, align 4, !dbg !542
  %28 = icmp slt i32 %26, %27, !dbg !543
  br i1 %28, label %29, label %42, !dbg !544

29:                                               ; preds = %25
  %30 = load i32, i32* %8, align 4, !dbg !545
  %31 = sext i32 %30 to i64, !dbg !547
  %32 = getelementptr inbounds [768 x i8], [768 x i8]* %5, i64 0, i64 %31, !dbg !547
  %33 = load i8, i8* %32, align 1, !dbg !547
  %34 = zext i8 %33 to i32, !dbg !548
  %35 = load i32, i32* @pb_hash, align 4, !dbg !549
  %36 = xor i32 %35, %34, !dbg !549
  store i32 %36, i32* @pb_hash, align 4, !dbg !549
  %37 = load i32, i32* @pb_hash, align 4, !dbg !550
  %38 = mul i32 %37, 16777619, !dbg !550
  store i32 %38, i32* @pb_hash, align 4, !dbg !550
  br label %39, !dbg !551

39:                                               ; preds = %29
  %40 = load i32, i32* %8, align 4, !dbg !552
  %41 = add nsw i32 %40, 1, !dbg !552
  store i32 %41, i32* %8, align 4, !dbg !552
  br label %25, !dbg !553, !llvm.loop !554

42:                                               ; preds = %25
  %43 = load %struct._IO_FILE*, %struct._IO_FILE** %3, align 8, !dbg !556
  %44 = load i32, i32* @pb_emit, align 4, !dbg !557
  %45 = load i32, i32* %7, align 4, !dbg !558
  ret i32 %45, !dbg !559
}

; Function Attrs: nofree nosync nounwind willreturn
declare void @llvm.va_start(i8*) #4

; Function Attrs: nounwind
declare i32 @vsnprintf(i8* noundef, i64 noundef, i8* noundef, %struct.__va_list_tag* noundef) #3

; Function Attrs: nofree nosync nounwind willreturn
declare void @llvm.va_end(i8*) #4

; Function Attrs: noreturn nounwind
declare void @abort() #5

attributes #0 = { noinline nounwind uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { nofree nosync nounwind readnone speculatable willreturn }
attributes #2 = { argmemonly nofree nounwind willreturn writeonly }
attributes #3 = { nounwind "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #4 = { nofree nosync nounwind willreturn }
attributes #5 = { noreturn nounwind "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #6 = { nounwind }
attributes #7 = { noreturn nounwind }

!llvm.dbg.cu = !{!2}
!llvm.module.flags = !{!53, !54, !55, !56, !57, !58, !59}
!llvm.ident = !{!60}

!0 = !DIGlobalVariableExpression(var: !1, expr: !DIExpression())
!1 = distinct !DIGlobalVariable(name: "n", scope: !2, file: !11, line: 140, type: !12, isLocal: false, isDefinition: true)
!2 = distinct !DICompileUnit(language: DW_LANG_C99, file: !3, producer: "Ubuntu clang version 14.0.0-1ubuntu1.1", isOptimized: false, runtimeVersion: 0, emissionKind: FullDebug, retainedTypes: !4, globals: !8, splitDebugInlining: false, nameTableKind: None)
!3 = !DIFile(filename: "/workspace/experiments/chaser/.cache/periodic-polybench/locality-medium-20260929/correlation/source/workload.c", directory: "/workspace/experiments/chaser/.cache/periodic-polybench/locality-medium-20260929/correlation/native-analysis", checksumkind: CSK_MD5, checksum: "70aeadc916d878c9ba36dd4e6a67c2f2")
!4 = !{!5, !6, !7}
!5 = !DIBasicType(name: "double", size: 64, encoding: DW_ATE_float)
!6 = !DIBasicType(name: "unsigned int", size: 32, encoding: DW_ATE_unsigned)
!7 = !DIBasicType(name: "unsigned char", size: 8, encoding: DW_ATE_unsigned_char)
!8 = !{!0, !9, !13, !26, !30, !33, !39, !43, !47, !49, !51}
!9 = !DIGlobalVariableExpression(var: !10, expr: !DIExpression())
!10 = distinct !DIGlobalVariable(name: "m", scope: !2, file: !11, line: 141, type: !12, isLocal: false, isDefinition: true)
!11 = !DIFile(filename: "source/workload.c", directory: "/workspace/experiments/chaser/.cache/periodic-polybench/locality-medium-20260929/correlation", checksumkind: CSK_MD5, checksum: "70aeadc916d878c9ba36dd4e6a67c2f2")
!12 = !DIBasicType(name: "int", size: 32, encoding: DW_ATE_signed)
!13 = !DIGlobalVariableExpression(var: !14, expr: !DIExpression())
!14 = distinct !DIGlobalVariable(name: "workload_jobs", scope: !2, file: !11, line: 168, type: !15, isLocal: false, isDefinition: true)
!15 = !DICompositeType(tag: DW_TAG_array_type, baseType: !16, size: 64, elements: !24)
!16 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !17)
!17 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !18, size: 64)
!18 = !DISubroutineType(types: !19)
!19 = !{!20}
!20 = !DIDerivedType(tag: DW_TAG_typedef, name: "uint32_t", file: !21, line: 26, baseType: !22)
!21 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/stdint-uintn.h", directory: "", checksumkind: CSK_MD5, checksum: "2bf2ae53c58c01b1a1b9383b5195125c")
!22 = !DIDerivedType(tag: DW_TAG_typedef, name: "__uint32_t", file: !23, line: 42, baseType: !6)
!23 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/types.h", directory: "", checksumkind: CSK_MD5, checksum: "d108b5f93a74c50510d7d9bc0ab36df9")
!24 = !{!25}
!25 = !DISubrange(count: 1)
!26 = !DIGlobalVariableExpression(var: !27, expr: !DIExpression())
!27 = distinct !DIGlobalVariable(name: "workload_expected", scope: !2, file: !11, line: 172, type: !28, isLocal: false, isDefinition: true)
!28 = !DICompositeType(tag: DW_TAG_array_type, baseType: !29, size: 32, elements: !24)
!29 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !20)
!30 = !DIGlobalVariableExpression(var: !31, expr: !DIExpression())
!31 = distinct !DIGlobalVariable(name: "pb_hash", scope: !2, file: !32, line: 9, type: !20, isLocal: true, isDefinition: true)
!32 = !DIFile(filename: "source/adapter.h", directory: "/workspace/experiments/chaser/.cache/periodic-polybench/locality-medium-20260929/correlation", checksumkind: CSK_MD5, checksum: "26a6068928b2092758f244a9d00163d7")
!33 = !DIGlobalVariableExpression(var: !34, expr: !DIExpression())
!34 = distinct !DIGlobalVariable(name: "data", scope: !2, file: !11, line: 33, type: !35, isLocal: false, isDefinition: true, align: 512)
!35 = !DICompositeType(tag: DW_TAG_array_type, baseType: !5, size: 3993600, elements: !36)
!36 = !{!37, !38}
!37 = !DISubrange(count: 260)
!38 = !DISubrange(count: 240)
!39 = !DIGlobalVariableExpression(var: !40, expr: !DIExpression())
!40 = distinct !DIGlobalVariable(name: "corr", scope: !2, file: !11, line: 34, type: !41, isLocal: false, isDefinition: true, align: 512)
!41 = !DICompositeType(tag: DW_TAG_array_type, baseType: !5, size: 3686400, elements: !42)
!42 = !{!38, !38}
!43 = !DIGlobalVariableExpression(var: !44, expr: !DIExpression())
!44 = distinct !DIGlobalVariable(name: "mean", scope: !2, file: !11, line: 35, type: !45, isLocal: false, isDefinition: true, align: 512)
!45 = !DICompositeType(tag: DW_TAG_array_type, baseType: !5, size: 15360, elements: !46)
!46 = !{!38}
!47 = !DIGlobalVariableExpression(var: !48, expr: !DIExpression())
!48 = distinct !DIGlobalVariable(name: "stddev", scope: !2, file: !11, line: 36, type: !45, isLocal: false, isDefinition: true, align: 512)
!49 = !DIGlobalVariableExpression(var: !50, expr: !DIExpression())
!50 = distinct !DIGlobalVariable(name: "float_n", scope: !2, file: !11, line: 144, type: !5, isLocal: false, isDefinition: true)
!51 = !DIGlobalVariableExpression(var: !52, expr: !DIExpression())
!52 = distinct !DIGlobalVariable(name: "pb_emit", scope: !2, file: !32, line: 10, type: !12, isLocal: true, isDefinition: true)
!53 = !{i32 7, !"Dwarf Version", i32 5}
!54 = !{i32 2, !"Debug Info Version", i32 3}
!55 = !{i32 1, !"wchar_size", i32 4}
!56 = !{i32 7, !"PIC Level", i32 2}
!57 = !{i32 7, !"PIE Level", i32 2}
!58 = !{i32 7, !"uwtable", i32 1}
!59 = !{i32 7, !"frame-pointer", i32 2}
!60 = !{!"Ubuntu clang version 14.0.0-1ubuntu1.1"}
!61 = distinct !DISubprogram(name: "workload_prepare", scope: !11, file: !11, line: 145, type: !62, scopeLine: 145, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !2, retainedNodes: !64)
!62 = !DISubroutineType(types: !63)
!63 = !{null}
!64 = !{}
!65 = !DILocation(line: 145, column: 30, scope: !61)
!66 = distinct !DISubprogram(name: "workload_reset", scope: !11, file: !11, line: 146, type: !67, scopeLine: 146, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !2, retainedNodes: !64)
!67 = !DISubroutineType(types: !68)
!68 = !{null, !6}
!69 = !DILocalVariable(name: "task", arg: 1, scope: !66, file: !11, line: 146, type: !6)
!70 = !DILocation(line: 146, column: 30, scope: !66)
!71 = !DILocation(line: 147, column: 9, scope: !66)
!72 = !DILocation(line: 148, column: 3, scope: !66)
!73 = !DILocation(line: 149, column: 3, scope: !66)
!74 = !DILocation(line: 150, column: 3, scope: !66)
!75 = !DILocation(line: 151, column: 3, scope: !66)
!76 = !DILocation(line: 152, column: 15, scope: !66)
!77 = !DILocation(line: 152, column: 18, scope: !66)
!78 = !DILocation(line: 152, column: 3, scope: !66)
!79 = !DILocation(line: 153, column: 1, scope: !66)
!80 = distinct !DISubprogram(name: "init_array", scope: !11, file: !11, line: 38, type: !81, scopeLine: 42, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition, unit: !2, retainedNodes: !64)
!81 = !DISubroutineType(types: !82)
!82 = !{null, !12, !12, !83, !84}
!83 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !5, size: 64)
!84 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !45, size: 64)
!85 = !DILocalVariable(name: "m", arg: 1, scope: !80, file: !11, line: 38, type: !12)
!86 = !DILocation(line: 38, column: 22, scope: !80)
!87 = !DILocalVariable(name: "n", arg: 2, scope: !80, file: !11, line: 39, type: !12)
!88 = !DILocation(line: 39, column: 8, scope: !80)
!89 = !DILocalVariable(name: "float_n", arg: 3, scope: !80, file: !11, line: 40, type: !83)
!90 = !DILocation(line: 40, column: 15, scope: !80)
!91 = !DILocalVariable(name: "data", arg: 4, scope: !80, file: !11, line: 41, type: !84)
!92 = !DILocation(line: 41, column: 14, scope: !80)
!93 = !DILocalVariable(name: "i", scope: !80, file: !11, line: 43, type: !12)
!94 = !DILocation(line: 43, column: 7, scope: !80)
!95 = !DILocalVariable(name: "j", scope: !80, file: !11, line: 43, type: !12)
!96 = !DILocation(line: 43, column: 10, scope: !80)
!97 = !DILocation(line: 45, column: 4, scope: !80)
!98 = !DILocation(line: 45, column: 12, scope: !80)
!99 = !DILocation(line: 47, column: 10, scope: !100)
!100 = distinct !DILexicalBlock(scope: !80, file: !11, line: 47, column: 3)
!101 = !DILocation(line: 47, column: 8, scope: !100)
!102 = !DILocation(line: 47, column: 15, scope: !103)
!103 = distinct !DILexicalBlock(scope: !100, file: !11, line: 47, column: 3)
!104 = !DILocation(line: 47, column: 17, scope: !103)
!105 = !DILocation(line: 47, column: 3, scope: !100)
!106 = !DILocation(line: 48, column: 12, scope: !107)
!107 = distinct !DILexicalBlock(scope: !103, file: !11, line: 48, column: 5)
!108 = !DILocation(line: 48, column: 10, scope: !107)
!109 = !DILocation(line: 48, column: 17, scope: !110)
!110 = distinct !DILexicalBlock(scope: !107, file: !11, line: 48, column: 5)
!111 = !DILocation(line: 48, column: 19, scope: !110)
!112 = !DILocation(line: 48, column: 5, scope: !107)
!113 = !DILocation(line: 49, column: 32, scope: !110)
!114 = !DILocation(line: 49, column: 34, scope: !110)
!115 = !DILocation(line: 49, column: 33, scope: !110)
!116 = !DILocation(line: 49, column: 20, scope: !110)
!117 = !DILocation(line: 49, column: 36, scope: !110)
!118 = !DILocation(line: 49, column: 41, scope: !110)
!119 = !DILocation(line: 49, column: 39, scope: !110)
!120 = !DILocation(line: 49, column: 7, scope: !110)
!121 = !DILocation(line: 49, column: 12, scope: !110)
!122 = !DILocation(line: 49, column: 15, scope: !110)
!123 = !DILocation(line: 49, column: 18, scope: !110)
!124 = !DILocation(line: 48, column: 25, scope: !110)
!125 = !DILocation(line: 48, column: 5, scope: !110)
!126 = distinct !{!126, !112, !127, !128}
!127 = !DILocation(line: 49, column: 41, scope: !107)
!128 = !{!"llvm.loop.mustprogress"}
!129 = !DILocation(line: 47, column: 23, scope: !103)
!130 = !DILocation(line: 47, column: 3, scope: !103)
!131 = distinct !{!131, !105, !132, !128}
!132 = !DILocation(line: 49, column: 41, scope: !100)
!133 = !DILocation(line: 51, column: 1, scope: !80)
!134 = distinct !DISubprogram(name: "task_job_polybench", scope: !11, file: !11, line: 154, type: !18, scopeLine: 154, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !2, retainedNodes: !64)
!135 = !DILocation(line: 155, column: 23, scope: !134)
!136 = !DILocation(line: 155, column: 26, scope: !134)
!137 = !DILocation(line: 155, column: 29, scope: !134)
!138 = !DILocalVariable(name: "m", arg: 1, scope: !139, file: !11, line: 78, type: !12)
!139 = distinct !DISubprogram(name: "kernel_correlation", scope: !11, file: !11, line: 78, type: !140, scopeLine: 84, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition, unit: !2, retainedNodes: !64)
!140 = !DISubroutineType(types: !141)
!141 = !{null, !12, !12, !5, !84, !84, !83, !83}
!142 = !DILocation(line: 78, column: 67, scope: !139, inlinedAt: !143)
!143 = distinct !DILocation(line: 155, column: 3, scope: !134)
!144 = !DILocalVariable(name: "n", arg: 2, scope: !139, file: !11, line: 78, type: !12)
!145 = !DILocation(line: 78, column: 74, scope: !139, inlinedAt: !143)
!146 = !DILocalVariable(name: "float_n", arg: 3, scope: !139, file: !11, line: 79, type: !5)
!147 = !DILocation(line: 79, column: 14, scope: !139, inlinedAt: !143)
!148 = !DILocalVariable(name: "data", arg: 4, scope: !139, file: !11, line: 80, type: !84)
!149 = !DILocation(line: 80, column: 14, scope: !139, inlinedAt: !143)
!150 = !DILocalVariable(name: "corr", arg: 5, scope: !139, file: !11, line: 81, type: !84)
!151 = !DILocation(line: 81, column: 14, scope: !139, inlinedAt: !143)
!152 = !DILocalVariable(name: "mean", arg: 6, scope: !139, file: !11, line: 82, type: !83)
!153 = !DILocation(line: 82, column: 14, scope: !139, inlinedAt: !143)
!154 = !DILocalVariable(name: "stddev", arg: 7, scope: !139, file: !11, line: 83, type: !83)
!155 = !DILocation(line: 83, column: 14, scope: !139, inlinedAt: !143)
!156 = !DILocalVariable(name: "i", scope: !139, file: !11, line: 85, type: !12)
!157 = !DILocation(line: 85, column: 7, scope: !139, inlinedAt: !143)
!158 = !DILocalVariable(name: "j", scope: !139, file: !11, line: 85, type: !12)
!159 = !DILocation(line: 85, column: 10, scope: !139, inlinedAt: !143)
!160 = !DILocalVariable(name: "k", scope: !139, file: !11, line: 85, type: !12)
!161 = !DILocation(line: 85, column: 13, scope: !139, inlinedAt: !143)
!162 = !DILocalVariable(name: "eps", scope: !139, file: !11, line: 87, type: !5)
!163 = !DILocation(line: 87, column: 13, scope: !139, inlinedAt: !143)
!164 = !DILocation(line: 91, column: 10, scope: !165, inlinedAt: !143)
!165 = distinct !DILexicalBlock(scope: !139, file: !11, line: 91, column: 3)
!166 = !DILocation(line: 91, column: 8, scope: !165, inlinedAt: !143)
!167 = !DILocation(line: 91, column: 15, scope: !168, inlinedAt: !143)
!168 = distinct !DILexicalBlock(scope: !165, file: !11, line: 91, column: 3)
!169 = !DILocation(line: 91, column: 17, scope: !168, inlinedAt: !143)
!170 = !DILocation(line: 91, column: 3, scope: !165, inlinedAt: !143)
!171 = !DILocation(line: 93, column: 7, scope: !172, inlinedAt: !143)
!172 = distinct !DILexicalBlock(scope: !168, file: !11, line: 92, column: 5)
!173 = !DILocation(line: 93, column: 12, scope: !172, inlinedAt: !143)
!174 = !DILocation(line: 93, column: 15, scope: !172, inlinedAt: !143)
!175 = !DILocation(line: 94, column: 14, scope: !176, inlinedAt: !143)
!176 = distinct !DILexicalBlock(scope: !172, file: !11, line: 94, column: 7)
!177 = !DILocation(line: 94, column: 12, scope: !176, inlinedAt: !143)
!178 = !DILocation(line: 94, column: 19, scope: !179, inlinedAt: !143)
!179 = distinct !DILexicalBlock(scope: !176, file: !11, line: 94, column: 7)
!180 = !DILocation(line: 94, column: 21, scope: !179, inlinedAt: !143)
!181 = !DILocation(line: 94, column: 7, scope: !176, inlinedAt: !143)
!182 = !DILocation(line: 95, column: 13, scope: !179, inlinedAt: !143)
!183 = !DILocation(line: 95, column: 18, scope: !179, inlinedAt: !143)
!184 = !DILocation(line: 95, column: 21, scope: !179, inlinedAt: !143)
!185 = !DILocation(line: 95, column: 2, scope: !179, inlinedAt: !143)
!186 = !DILocation(line: 95, column: 7, scope: !179, inlinedAt: !143)
!187 = !DILocation(line: 95, column: 10, scope: !179, inlinedAt: !143)
!188 = !DILocation(line: 94, column: 31, scope: !179, inlinedAt: !143)
!189 = !DILocation(line: 94, column: 7, scope: !179, inlinedAt: !143)
!190 = distinct !{!190, !181, !191, !128}
!191 = !DILocation(line: 95, column: 22, scope: !176, inlinedAt: !143)
!192 = !DILocation(line: 96, column: 18, scope: !172, inlinedAt: !143)
!193 = !DILocation(line: 96, column: 7, scope: !172, inlinedAt: !143)
!194 = !DILocation(line: 96, column: 12, scope: !172, inlinedAt: !143)
!195 = !DILocation(line: 96, column: 15, scope: !172, inlinedAt: !143)
!196 = !DILocation(line: 91, column: 27, scope: !168, inlinedAt: !143)
!197 = !DILocation(line: 91, column: 3, scope: !168, inlinedAt: !143)
!198 = distinct !{!198, !170, !199, !128}
!199 = !DILocation(line: 97, column: 5, scope: !165, inlinedAt: !143)
!200 = !DILocation(line: 100, column: 11, scope: !201, inlinedAt: !143)
!201 = distinct !DILexicalBlock(scope: !139, file: !11, line: 100, column: 4)
!202 = !DILocation(line: 100, column: 9, scope: !201, inlinedAt: !143)
!203 = !DILocation(line: 100, column: 16, scope: !204, inlinedAt: !143)
!204 = distinct !DILexicalBlock(scope: !201, file: !11, line: 100, column: 4)
!205 = !DILocation(line: 100, column: 18, scope: !204, inlinedAt: !143)
!206 = !DILocation(line: 100, column: 4, scope: !201, inlinedAt: !143)
!207 = !DILocation(line: 102, column: 7, scope: !208, inlinedAt: !143)
!208 = distinct !DILexicalBlock(scope: !204, file: !11, line: 101, column: 5)
!209 = !DILocation(line: 102, column: 14, scope: !208, inlinedAt: !143)
!210 = !DILocation(line: 102, column: 17, scope: !208, inlinedAt: !143)
!211 = !DILocation(line: 103, column: 14, scope: !212, inlinedAt: !143)
!212 = distinct !DILexicalBlock(scope: !208, file: !11, line: 103, column: 7)
!213 = !DILocation(line: 103, column: 12, scope: !212, inlinedAt: !143)
!214 = !DILocation(line: 103, column: 19, scope: !215, inlinedAt: !143)
!215 = distinct !DILexicalBlock(scope: !212, file: !11, line: 103, column: 7)
!216 = !DILocation(line: 103, column: 21, scope: !215, inlinedAt: !143)
!217 = !DILocation(line: 103, column: 7, scope: !212, inlinedAt: !143)
!218 = !DILocation(line: 104, column: 23, scope: !215, inlinedAt: !143)
!219 = !DILocation(line: 104, column: 28, scope: !215, inlinedAt: !143)
!220 = !DILocation(line: 104, column: 31, scope: !215, inlinedAt: !143)
!221 = !DILocation(line: 104, column: 36, scope: !215, inlinedAt: !143)
!222 = !DILocation(line: 104, column: 41, scope: !215, inlinedAt: !143)
!223 = !DILocation(line: 104, column: 34, scope: !215, inlinedAt: !143)
!224 = !DILocation(line: 104, column: 48, scope: !215, inlinedAt: !143)
!225 = !DILocation(line: 104, column: 53, scope: !215, inlinedAt: !143)
!226 = !DILocation(line: 104, column: 56, scope: !215, inlinedAt: !143)
!227 = !DILocation(line: 104, column: 61, scope: !215, inlinedAt: !143)
!228 = !DILocation(line: 104, column: 66, scope: !215, inlinedAt: !143)
!229 = !DILocation(line: 104, column: 59, scope: !215, inlinedAt: !143)
!230 = !DILocation(line: 104, column: 45, scope: !215, inlinedAt: !143)
!231 = !DILocation(line: 104, column: 9, scope: !215, inlinedAt: !143)
!232 = !DILocation(line: 104, column: 16, scope: !215, inlinedAt: !143)
!233 = !DILocation(line: 104, column: 19, scope: !215, inlinedAt: !143)
!234 = !DILocation(line: 103, column: 31, scope: !215, inlinedAt: !143)
!235 = !DILocation(line: 103, column: 7, scope: !215, inlinedAt: !143)
!236 = distinct !{!236, !217, !237, !128}
!237 = !DILocation(line: 104, column: 68, scope: !212, inlinedAt: !143)
!238 = !DILocation(line: 105, column: 20, scope: !208, inlinedAt: !143)
!239 = !DILocation(line: 105, column: 7, scope: !208, inlinedAt: !143)
!240 = !DILocation(line: 105, column: 14, scope: !208, inlinedAt: !143)
!241 = !DILocation(line: 105, column: 17, scope: !208, inlinedAt: !143)
!242 = !DILocation(line: 106, column: 19, scope: !208, inlinedAt: !143)
!243 = !DILocation(line: 106, column: 7, scope: !208, inlinedAt: !143)
!244 = !DILocation(line: 106, column: 14, scope: !208, inlinedAt: !143)
!245 = !DILocation(line: 106, column: 17, scope: !208, inlinedAt: !143)
!246 = !DILocation(line: 110, column: 19, scope: !208, inlinedAt: !143)
!247 = !DILocation(line: 110, column: 26, scope: !208, inlinedAt: !143)
!248 = !DILocation(line: 110, column: 32, scope: !208, inlinedAt: !143)
!249 = !DILocation(line: 110, column: 29, scope: !208, inlinedAt: !143)
!250 = !DILocation(line: 110, column: 56, scope: !208, inlinedAt: !143)
!251 = !DILocation(line: 110, column: 63, scope: !208, inlinedAt: !143)
!252 = !DILocation(line: 110, column: 7, scope: !208, inlinedAt: !143)
!253 = !DILocation(line: 110, column: 14, scope: !208, inlinedAt: !143)
!254 = !DILocation(line: 110, column: 17, scope: !208, inlinedAt: !143)
!255 = !DILocation(line: 100, column: 28, scope: !204, inlinedAt: !143)
!256 = !DILocation(line: 100, column: 4, scope: !204, inlinedAt: !143)
!257 = distinct !{!257, !206, !258, !128}
!258 = !DILocation(line: 111, column: 5, scope: !201, inlinedAt: !143)
!259 = !DILocation(line: 114, column: 10, scope: !260, inlinedAt: !143)
!260 = distinct !DILexicalBlock(scope: !139, file: !11, line: 114, column: 3)
!261 = !DILocation(line: 114, column: 8, scope: !260, inlinedAt: !143)
!262 = !DILocation(line: 114, column: 15, scope: !263, inlinedAt: !143)
!263 = distinct !DILexicalBlock(scope: !260, file: !11, line: 114, column: 3)
!264 = !DILocation(line: 114, column: 17, scope: !263, inlinedAt: !143)
!265 = !DILocation(line: 114, column: 3, scope: !260, inlinedAt: !143)
!266 = !DILocation(line: 115, column: 12, scope: !267, inlinedAt: !143)
!267 = distinct !DILexicalBlock(scope: !263, file: !11, line: 115, column: 5)
!268 = !DILocation(line: 115, column: 10, scope: !267, inlinedAt: !143)
!269 = !DILocation(line: 115, column: 17, scope: !270, inlinedAt: !143)
!270 = distinct !DILexicalBlock(scope: !267, file: !11, line: 115, column: 5)
!271 = !DILocation(line: 115, column: 19, scope: !270, inlinedAt: !143)
!272 = !DILocation(line: 115, column: 5, scope: !267, inlinedAt: !143)
!273 = !DILocation(line: 117, column: 23, scope: !274, inlinedAt: !143)
!274 = distinct !DILexicalBlock(scope: !270, file: !11, line: 116, column: 7)
!275 = !DILocation(line: 117, column: 28, scope: !274, inlinedAt: !143)
!276 = !DILocation(line: 117, column: 9, scope: !274, inlinedAt: !143)
!277 = !DILocation(line: 117, column: 14, scope: !274, inlinedAt: !143)
!278 = !DILocation(line: 117, column: 17, scope: !274, inlinedAt: !143)
!279 = !DILocation(line: 117, column: 20, scope: !274, inlinedAt: !143)
!280 = !DILocation(line: 118, column: 23, scope: !274, inlinedAt: !143)
!281 = !DILocation(line: 118, column: 43, scope: !274, inlinedAt: !143)
!282 = !DILocation(line: 118, column: 50, scope: !274, inlinedAt: !143)
!283 = !DILocation(line: 118, column: 41, scope: !274, inlinedAt: !143)
!284 = !DILocation(line: 118, column: 9, scope: !274, inlinedAt: !143)
!285 = !DILocation(line: 118, column: 14, scope: !274, inlinedAt: !143)
!286 = !DILocation(line: 118, column: 17, scope: !274, inlinedAt: !143)
!287 = !DILocation(line: 118, column: 20, scope: !274, inlinedAt: !143)
!288 = !DILocation(line: 115, column: 29, scope: !270, inlinedAt: !143)
!289 = !DILocation(line: 115, column: 5, scope: !270, inlinedAt: !143)
!290 = distinct !{!290, !272, !291, !128}
!291 = !DILocation(line: 119, column: 7, scope: !267, inlinedAt: !143)
!292 = !DILocation(line: 114, column: 27, scope: !263, inlinedAt: !143)
!293 = !DILocation(line: 114, column: 3, scope: !263, inlinedAt: !143)
!294 = distinct !{!294, !265, !295, !128}
!295 = !DILocation(line: 119, column: 7, scope: !260, inlinedAt: !143)
!296 = !DILocation(line: 122, column: 10, scope: !297, inlinedAt: !143)
!297 = distinct !DILexicalBlock(scope: !139, file: !11, line: 122, column: 3)
!298 = !DILocation(line: 122, column: 8, scope: !297, inlinedAt: !143)
!299 = !DILocation(line: 122, column: 15, scope: !300, inlinedAt: !143)
!300 = distinct !DILexicalBlock(scope: !297, file: !11, line: 122, column: 3)
!301 = !DILocation(line: 122, column: 17, scope: !300, inlinedAt: !143)
!302 = !DILocation(line: 122, column: 3, scope: !297, inlinedAt: !143)
!303 = !DILocation(line: 124, column: 7, scope: !304, inlinedAt: !143)
!304 = distinct !DILexicalBlock(scope: !300, file: !11, line: 123, column: 5)
!305 = !DILocation(line: 124, column: 12, scope: !304, inlinedAt: !143)
!306 = !DILocation(line: 124, column: 15, scope: !304, inlinedAt: !143)
!307 = !DILocation(line: 124, column: 18, scope: !304, inlinedAt: !143)
!308 = !DILocation(line: 125, column: 16, scope: !309, inlinedAt: !143)
!309 = distinct !DILexicalBlock(scope: !304, file: !11, line: 125, column: 7)
!310 = !DILocation(line: 125, column: 17, scope: !309, inlinedAt: !143)
!311 = !DILocation(line: 125, column: 14, scope: !309, inlinedAt: !143)
!312 = !DILocation(line: 125, column: 12, scope: !309, inlinedAt: !143)
!313 = !DILocation(line: 125, column: 21, scope: !314, inlinedAt: !143)
!314 = distinct !DILexicalBlock(scope: !309, file: !11, line: 125, column: 7)
!315 = !DILocation(line: 125, column: 23, scope: !314, inlinedAt: !143)
!316 = !DILocation(line: 125, column: 7, scope: !309, inlinedAt: !143)
!317 = !DILocation(line: 127, column: 11, scope: !318, inlinedAt: !143)
!318 = distinct !DILexicalBlock(scope: !314, file: !11, line: 126, column: 9)
!319 = !DILocation(line: 127, column: 16, scope: !318, inlinedAt: !143)
!320 = !DILocation(line: 127, column: 19, scope: !318, inlinedAt: !143)
!321 = !DILocation(line: 127, column: 22, scope: !318, inlinedAt: !143)
!322 = !DILocation(line: 128, column: 18, scope: !323, inlinedAt: !143)
!323 = distinct !DILexicalBlock(scope: !318, file: !11, line: 128, column: 11)
!324 = !DILocation(line: 128, column: 16, scope: !323, inlinedAt: !143)
!325 = !DILocation(line: 128, column: 23, scope: !326, inlinedAt: !143)
!326 = distinct !DILexicalBlock(scope: !323, file: !11, line: 128, column: 11)
!327 = !DILocation(line: 128, column: 25, scope: !326, inlinedAt: !143)
!328 = !DILocation(line: 128, column: 11, scope: !323, inlinedAt: !143)
!329 = !DILocation(line: 129, column: 28, scope: !326, inlinedAt: !143)
!330 = !DILocation(line: 129, column: 33, scope: !326, inlinedAt: !143)
!331 = !DILocation(line: 129, column: 36, scope: !326, inlinedAt: !143)
!332 = !DILocation(line: 129, column: 41, scope: !326, inlinedAt: !143)
!333 = !DILocation(line: 129, column: 46, scope: !326, inlinedAt: !143)
!334 = !DILocation(line: 129, column: 49, scope: !326, inlinedAt: !143)
!335 = !DILocation(line: 129, column: 39, scope: !326, inlinedAt: !143)
!336 = !DILocation(line: 129, column: 13, scope: !326, inlinedAt: !143)
!337 = !DILocation(line: 129, column: 18, scope: !326, inlinedAt: !143)
!338 = !DILocation(line: 129, column: 21, scope: !326, inlinedAt: !143)
!339 = !DILocation(line: 129, column: 24, scope: !326, inlinedAt: !143)
!340 = !DILocation(line: 128, column: 35, scope: !326, inlinedAt: !143)
!341 = !DILocation(line: 128, column: 11, scope: !326, inlinedAt: !143)
!342 = distinct !{!342, !328, !343, !128}
!343 = !DILocation(line: 129, column: 51, scope: !323, inlinedAt: !143)
!344 = !DILocation(line: 130, column: 24, scope: !318, inlinedAt: !143)
!345 = !DILocation(line: 130, column: 29, scope: !318, inlinedAt: !143)
!346 = !DILocation(line: 130, column: 32, scope: !318, inlinedAt: !143)
!347 = !DILocation(line: 130, column: 11, scope: !318, inlinedAt: !143)
!348 = !DILocation(line: 130, column: 16, scope: !318, inlinedAt: !143)
!349 = !DILocation(line: 130, column: 19, scope: !318, inlinedAt: !143)
!350 = !DILocation(line: 130, column: 22, scope: !318, inlinedAt: !143)
!351 = !DILocation(line: 125, column: 33, scope: !314, inlinedAt: !143)
!352 = !DILocation(line: 125, column: 7, scope: !314, inlinedAt: !143)
!353 = distinct !{!353, !316, !354, !128}
!354 = !DILocation(line: 131, column: 9, scope: !309, inlinedAt: !143)
!355 = !DILocation(line: 122, column: 29, scope: !300, inlinedAt: !143)
!356 = !DILocation(line: 122, column: 3, scope: !300, inlinedAt: !143)
!357 = distinct !{!357, !302, !358, !128}
!358 = !DILocation(line: 132, column: 5, scope: !297, inlinedAt: !143)
!359 = !DILocation(line: 133, column: 3, scope: !139, inlinedAt: !143)
!360 = !DILocation(line: 133, column: 26, scope: !139, inlinedAt: !143)
!361 = !DILocation(line: 160, column: 3, scope: !134)
!362 = distinct !DISubprogram(name: "workload_checksum", scope: !11, file: !11, line: 162, type: !363, scopeLine: 162, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !2, retainedNodes: !64)
!363 = !DISubroutineType(types: !364)
!364 = !{!20, !6}
!365 = !DILocalVariable(name: "task", arg: 1, scope: !362, file: !11, line: 162, type: !6)
!366 = !DILocation(line: 162, column: 37, scope: !362)
!367 = !DILocation(line: 163, column: 9, scope: !362)
!368 = !DILocation(line: 164, column: 11, scope: !362)
!369 = !DILocation(line: 165, column: 15, scope: !362)
!370 = !DILocation(line: 165, column: 3, scope: !362)
!371 = !DILocation(line: 166, column: 10, scope: !362)
!372 = !DILocation(line: 166, column: 3, scope: !362)
!373 = distinct !DISubprogram(name: "print_array", scope: !11, file: !11, line: 57, type: !374, scopeLine: 60, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition, unit: !2, retainedNodes: !64)
!374 = !DISubroutineType(types: !375)
!375 = !{null, !12, !84}
!376 = !DILocalVariable(name: "m", arg: 1, scope: !373, file: !11, line: 57, type: !12)
!377 = !DILocation(line: 57, column: 22, scope: !373)
!378 = !DILocalVariable(name: "corr", arg: 2, scope: !373, file: !11, line: 58, type: !84)
!379 = !DILocation(line: 58, column: 14, scope: !373)
!380 = !DILocalVariable(name: "i", scope: !373, file: !11, line: 61, type: !12)
!381 = !DILocation(line: 61, column: 7, scope: !373)
!382 = !DILocalVariable(name: "j", scope: !373, file: !11, line: 61, type: !12)
!383 = !DILocation(line: 61, column: 10, scope: !373)
!384 = !DILocation(line: 63, column: 3, scope: !373)
!385 = !DILocation(line: 64, column: 3, scope: !373)
!386 = !DILocation(line: 65, column: 10, scope: !387)
!387 = distinct !DILexicalBlock(scope: !373, file: !11, line: 65, column: 3)
!388 = !DILocation(line: 65, column: 8, scope: !387)
!389 = !DILocation(line: 65, column: 15, scope: !390)
!390 = distinct !DILexicalBlock(scope: !387, file: !11, line: 65, column: 3)
!391 = !DILocation(line: 65, column: 19, scope: !390)
!392 = !DILocation(line: 65, column: 17, scope: !390)
!393 = !DILocation(line: 65, column: 3, scope: !387)
!394 = !DILocation(line: 66, column: 12, scope: !395)
!395 = distinct !DILexicalBlock(scope: !390, file: !11, line: 66, column: 5)
!396 = !DILocation(line: 66, column: 10, scope: !395)
!397 = !DILocation(line: 66, column: 17, scope: !398)
!398 = distinct !DILexicalBlock(scope: !395, file: !11, line: 66, column: 5)
!399 = !DILocation(line: 66, column: 21, scope: !398)
!400 = !DILocation(line: 66, column: 19, scope: !398)
!401 = !DILocation(line: 66, column: 5, scope: !395)
!402 = !DILocation(line: 67, column: 12, scope: !403)
!403 = distinct !DILexicalBlock(scope: !404, file: !11, line: 67, column: 11)
!404 = distinct !DILexicalBlock(scope: !398, file: !11, line: 66, column: 29)
!405 = !DILocation(line: 67, column: 16, scope: !403)
!406 = !DILocation(line: 67, column: 14, scope: !403)
!407 = !DILocation(line: 67, column: 20, scope: !403)
!408 = !DILocation(line: 67, column: 18, scope: !403)
!409 = !DILocation(line: 67, column: 23, scope: !403)
!410 = !DILocation(line: 67, column: 28, scope: !403)
!411 = !DILocation(line: 67, column: 11, scope: !404)
!412 = !DILocation(line: 67, column: 43, scope: !403)
!413 = !DILocation(line: 67, column: 34, scope: !403)
!414 = !DILocation(line: 68, column: 16, scope: !404)
!415 = !DILocation(line: 68, column: 61, scope: !404)
!416 = !DILocation(line: 68, column: 66, scope: !404)
!417 = !DILocation(line: 68, column: 69, scope: !404)
!418 = !DILocation(line: 68, column: 7, scope: !404)
!419 = !DILocation(line: 69, column: 5, scope: !404)
!420 = !DILocation(line: 66, column: 25, scope: !398)
!421 = !DILocation(line: 66, column: 5, scope: !398)
!422 = distinct !{!422, !401, !423, !128}
!423 = !DILocation(line: 69, column: 5, scope: !395)
!424 = !DILocation(line: 65, column: 23, scope: !390)
!425 = !DILocation(line: 65, column: 3, scope: !390)
!426 = distinct !{!426, !393, !427, !128}
!427 = !DILocation(line: 69, column: 5, scope: !387)
!428 = !DILocation(line: 70, column: 3, scope: !373)
!429 = !DILocation(line: 71, column: 3, scope: !373)
!430 = !DILocation(line: 72, column: 1, scope: !373)
!431 = distinct !DISubprogram(name: "pb_fprintf", scope: !32, file: !32, line: 13, type: !432, scopeLine: 14, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition, unit: !2, retainedNodes: !64)
!432 = !DISubroutineType(types: !433)
!433 = !{!12, !434, !493, null}
!434 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !435, size: 64)
!435 = !DIDerivedType(tag: DW_TAG_typedef, name: "FILE", file: !436, line: 7, baseType: !437)
!436 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/types/FILE.h", directory: "", checksumkind: CSK_MD5, checksum: "571f9fb6223c42439075fdde11a0de5d")
!437 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "_IO_FILE", file: !438, line: 49, size: 1728, elements: !439)
!438 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/types/struct_FILE.h", directory: "", checksumkind: CSK_MD5, checksum: "1bad07471b7974df4ecc1d1c2ca207e6")
!439 = !{!440, !441, !444, !445, !446, !447, !448, !449, !450, !451, !452, !453, !454, !457, !459, !460, !461, !464, !466, !468, !470, !473, !475, !478, !481, !482, !484, !488, !489}
!440 = !DIDerivedType(tag: DW_TAG_member, name: "_flags", scope: !437, file: !438, line: 51, baseType: !12, size: 32)
!441 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_read_ptr", scope: !437, file: !438, line: 54, baseType: !442, size: 64, offset: 64)
!442 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !443, size: 64)
!443 = !DIBasicType(name: "char", size: 8, encoding: DW_ATE_signed_char)
!444 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_read_end", scope: !437, file: !438, line: 55, baseType: !442, size: 64, offset: 128)
!445 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_read_base", scope: !437, file: !438, line: 56, baseType: !442, size: 64, offset: 192)
!446 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_write_base", scope: !437, file: !438, line: 57, baseType: !442, size: 64, offset: 256)
!447 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_write_ptr", scope: !437, file: !438, line: 58, baseType: !442, size: 64, offset: 320)
!448 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_write_end", scope: !437, file: !438, line: 59, baseType: !442, size: 64, offset: 384)
!449 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_buf_base", scope: !437, file: !438, line: 60, baseType: !442, size: 64, offset: 448)
!450 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_buf_end", scope: !437, file: !438, line: 61, baseType: !442, size: 64, offset: 512)
!451 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_save_base", scope: !437, file: !438, line: 64, baseType: !442, size: 64, offset: 576)
!452 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_backup_base", scope: !437, file: !438, line: 65, baseType: !442, size: 64, offset: 640)
!453 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_save_end", scope: !437, file: !438, line: 66, baseType: !442, size: 64, offset: 704)
!454 = !DIDerivedType(tag: DW_TAG_member, name: "_markers", scope: !437, file: !438, line: 68, baseType: !455, size: 64, offset: 768)
!455 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !456, size: 64)
!456 = !DICompositeType(tag: DW_TAG_structure_type, name: "_IO_marker", file: !438, line: 36, flags: DIFlagFwdDecl)
!457 = !DIDerivedType(tag: DW_TAG_member, name: "_chain", scope: !437, file: !438, line: 70, baseType: !458, size: 64, offset: 832)
!458 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !437, size: 64)
!459 = !DIDerivedType(tag: DW_TAG_member, name: "_fileno", scope: !437, file: !438, line: 72, baseType: !12, size: 32, offset: 896)
!460 = !DIDerivedType(tag: DW_TAG_member, name: "_flags2", scope: !437, file: !438, line: 73, baseType: !12, size: 32, offset: 928)
!461 = !DIDerivedType(tag: DW_TAG_member, name: "_old_offset", scope: !437, file: !438, line: 74, baseType: !462, size: 64, offset: 960)
!462 = !DIDerivedType(tag: DW_TAG_typedef, name: "__off_t", file: !23, line: 152, baseType: !463)
!463 = !DIBasicType(name: "long", size: 64, encoding: DW_ATE_signed)
!464 = !DIDerivedType(tag: DW_TAG_member, name: "_cur_column", scope: !437, file: !438, line: 77, baseType: !465, size: 16, offset: 1024)
!465 = !DIBasicType(name: "unsigned short", size: 16, encoding: DW_ATE_unsigned)
!466 = !DIDerivedType(tag: DW_TAG_member, name: "_vtable_offset", scope: !437, file: !438, line: 78, baseType: !467, size: 8, offset: 1040)
!467 = !DIBasicType(name: "signed char", size: 8, encoding: DW_ATE_signed_char)
!468 = !DIDerivedType(tag: DW_TAG_member, name: "_shortbuf", scope: !437, file: !438, line: 79, baseType: !469, size: 8, offset: 1048)
!469 = !DICompositeType(tag: DW_TAG_array_type, baseType: !443, size: 8, elements: !24)
!470 = !DIDerivedType(tag: DW_TAG_member, name: "_lock", scope: !437, file: !438, line: 81, baseType: !471, size: 64, offset: 1088)
!471 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !472, size: 64)
!472 = !DIDerivedType(tag: DW_TAG_typedef, name: "_IO_lock_t", file: !438, line: 43, baseType: null)
!473 = !DIDerivedType(tag: DW_TAG_member, name: "_offset", scope: !437, file: !438, line: 89, baseType: !474, size: 64, offset: 1152)
!474 = !DIDerivedType(tag: DW_TAG_typedef, name: "__off64_t", file: !23, line: 153, baseType: !463)
!475 = !DIDerivedType(tag: DW_TAG_member, name: "_codecvt", scope: !437, file: !438, line: 91, baseType: !476, size: 64, offset: 1216)
!476 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !477, size: 64)
!477 = !DICompositeType(tag: DW_TAG_structure_type, name: "_IO_codecvt", file: !438, line: 37, flags: DIFlagFwdDecl)
!478 = !DIDerivedType(tag: DW_TAG_member, name: "_wide_data", scope: !437, file: !438, line: 92, baseType: !479, size: 64, offset: 1280)
!479 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !480, size: 64)
!480 = !DICompositeType(tag: DW_TAG_structure_type, name: "_IO_wide_data", file: !438, line: 38, flags: DIFlagFwdDecl)
!481 = !DIDerivedType(tag: DW_TAG_member, name: "_freeres_list", scope: !437, file: !438, line: 93, baseType: !458, size: 64, offset: 1344)
!482 = !DIDerivedType(tag: DW_TAG_member, name: "_freeres_buf", scope: !437, file: !438, line: 94, baseType: !483, size: 64, offset: 1408)
!483 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: null, size: 64)
!484 = !DIDerivedType(tag: DW_TAG_member, name: "__pad5", scope: !437, file: !438, line: 95, baseType: !485, size: 64, offset: 1472)
!485 = !DIDerivedType(tag: DW_TAG_typedef, name: "size_t", file: !486, line: 46, baseType: !487)
!486 = !DIFile(filename: "/usr/lib/llvm-14/lib/clang/14.0.0/include/stddef.h", directory: "", checksumkind: CSK_MD5, checksum: "2499dd2361b915724b073282bea3a7bc")
!487 = !DIBasicType(name: "unsigned long", size: 64, encoding: DW_ATE_unsigned)
!488 = !DIDerivedType(tag: DW_TAG_member, name: "_mode", scope: !437, file: !438, line: 96, baseType: !12, size: 32, offset: 1536)
!489 = !DIDerivedType(tag: DW_TAG_member, name: "_unused2", scope: !437, file: !438, line: 98, baseType: !490, size: 160, offset: 1568)
!490 = !DICompositeType(tag: DW_TAG_array_type, baseType: !443, size: 160, elements: !491)
!491 = !{!492}
!492 = !DISubrange(count: 20)
!493 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !494, size: 64)
!494 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !443)
!495 = !DILocalVariable(name: "stream", arg: 1, scope: !431, file: !32, line: 13, type: !434)
!496 = !DILocation(line: 13, column: 29, scope: !431)
!497 = !DILocalVariable(name: "format", arg: 2, scope: !431, file: !32, line: 13, type: !493)
!498 = !DILocation(line: 13, column: 49, scope: !431)
!499 = !DILocalVariable(name: "buffer", scope: !431, file: !32, line: 15, type: !500)
!500 = !DICompositeType(tag: DW_TAG_array_type, baseType: !443, size: 6144, elements: !501)
!501 = !{!502}
!502 = !DISubrange(count: 768)
!503 = !DILocation(line: 15, column: 10, scope: !431)
!504 = !DILocalVariable(name: "args", scope: !431, file: !32, line: 16, type: !505)
!505 = !DIDerivedType(tag: DW_TAG_typedef, name: "va_list", file: !506, line: 52, baseType: !507)
!506 = !DIFile(filename: "/usr/include/stdio.h", directory: "", checksumkind: CSK_MD5, checksum: "f31eefcc3f15835fc5a4023a625cf609")
!507 = !DIDerivedType(tag: DW_TAG_typedef, name: "__gnuc_va_list", file: !508, line: 32, baseType: !509)
!508 = !DIFile(filename: "/usr/lib/llvm-14/lib/clang/14.0.0/include/stdarg.h", directory: "", checksumkind: CSK_MD5, checksum: "4de3cbd931b589d291e5c39387aecf82")
!509 = !DIDerivedType(tag: DW_TAG_typedef, name: "__builtin_va_list", file: !510, baseType: !511)
!510 = !DIFile(filename: "source/workload.c", directory: "/workspace/experiments/chaser/.cache/periodic-polybench/locality-medium-20260929/correlation")
!511 = !DICompositeType(tag: DW_TAG_array_type, baseType: !512, size: 192, elements: !24)
!512 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "__va_list_tag", size: 192, elements: !513)
!513 = !{!514, !515, !516, !517}
!514 = !DIDerivedType(tag: DW_TAG_member, name: "gp_offset", scope: !512, file: !510, line: 16, baseType: !6, size: 32)
!515 = !DIDerivedType(tag: DW_TAG_member, name: "fp_offset", scope: !512, file: !510, line: 16, baseType: !6, size: 32, offset: 32)
!516 = !DIDerivedType(tag: DW_TAG_member, name: "overflow_arg_area", scope: !512, file: !510, line: 16, baseType: !483, size: 64, offset: 64)
!517 = !DIDerivedType(tag: DW_TAG_member, name: "reg_save_area", scope: !512, file: !510, line: 16, baseType: !483, size: 64, offset: 128)
!518 = !DILocation(line: 16, column: 13, scope: !431)
!519 = !DILocation(line: 17, column: 5, scope: !431)
!520 = !DILocalVariable(name: "count", scope: !431, file: !32, line: 18, type: !12)
!521 = !DILocation(line: 18, column: 9, scope: !431)
!522 = !DILocation(line: 18, column: 27, scope: !431)
!523 = !DILocation(line: 18, column: 51, scope: !431)
!524 = !DILocation(line: 18, column: 59, scope: !431)
!525 = !DILocation(line: 18, column: 17, scope: !431)
!526 = !DILocation(line: 19, column: 5, scope: !431)
!527 = !DILocation(line: 20, column: 9, scope: !528)
!528 = distinct !DILexicalBlock(scope: !431, file: !32, line: 20, column: 9)
!529 = !DILocation(line: 20, column: 15, scope: !528)
!530 = !DILocation(line: 20, column: 19, scope: !528)
!531 = !DILocation(line: 20, column: 32, scope: !528)
!532 = !DILocation(line: 20, column: 22, scope: !528)
!533 = !DILocation(line: 20, column: 38, scope: !528)
!534 = !DILocation(line: 20, column: 9, scope: !431)
!535 = !DILocation(line: 20, column: 57, scope: !528)
!536 = !DILocalVariable(name: "i", scope: !537, file: !32, line: 21, type: !12)
!537 = distinct !DILexicalBlock(scope: !431, file: !32, line: 21, column: 5)
!538 = !DILocation(line: 21, column: 14, scope: !537)
!539 = !DILocation(line: 21, column: 10, scope: !537)
!540 = !DILocation(line: 21, column: 21, scope: !541)
!541 = distinct !DILexicalBlock(scope: !537, file: !32, line: 21, column: 5)
!542 = !DILocation(line: 21, column: 25, scope: !541)
!543 = !DILocation(line: 21, column: 23, scope: !541)
!544 = !DILocation(line: 21, column: 5, scope: !537)
!545 = !DILocation(line: 22, column: 42, scope: !546)
!546 = distinct !DILexicalBlock(scope: !541, file: !32, line: 21, column: 37)
!547 = !DILocation(line: 22, column: 35, scope: !546)
!548 = !DILocation(line: 22, column: 20, scope: !546)
!549 = !DILocation(line: 22, column: 17, scope: !546)
!550 = !DILocation(line: 23, column: 17, scope: !546)
!551 = !DILocation(line: 24, column: 5, scope: !546)
!552 = !DILocation(line: 21, column: 32, scope: !541)
!553 = !DILocation(line: 21, column: 5, scope: !541)
!554 = distinct !{!554, !544, !555, !128}
!555 = !DILocation(line: 24, column: 5, scope: !537)
!556 = !DILocation(line: 28, column: 11, scope: !431)
!557 = !DILocation(line: 29, column: 11, scope: !431)
!558 = !DILocation(line: 31, column: 12, scope: !431)
!559 = !DILocation(line: 31, column: 5, scope: !431)
