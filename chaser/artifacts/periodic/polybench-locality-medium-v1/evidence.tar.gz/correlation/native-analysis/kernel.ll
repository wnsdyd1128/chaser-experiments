; ModuleID = 'inlined.ll'
source_filename = "/workspace/experiments/chaser/.cache/periodic-polybench/locality-medium-20260929/correlation/source/workload.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

@n = external dso_local global i32, align 4, !dbg !0
@m = external dso_local global i32, align 4, !dbg !9
@data = external dso_local global [260 x [240 x double]], section ".chaser_data.data", align 64, !dbg !13
@corr = external dso_local global [240 x [240 x double]], section ".chaser_data.corr", align 64, !dbg !19
@mean = external dso_local global [240 x double], section ".chaser_data.mean", align 64, !dbg !23
@stddev = external dso_local global [240 x double], section ".chaser_data.stddev", align 64, !dbg !27
@float_n = external dso_local global double, align 8, !dbg !29
@.str = hidden unnamed_addr constant [12 x i8] c"ape.analyze\00", section "llvm.metadata"
@.str.1 = hidden unnamed_addr constant [111 x i8] c"/workspace/experiments/chaser/.cache/periodic-polybench/locality-medium-20260929/correlation/source/workload.c\00", section "llvm.metadata"
@.str.2 = hidden unnamed_addr constant [23 x i8] c"==BEGIN DUMP_ARRAYS==\0A\00", align 1
@.str.3 = hidden unnamed_addr constant [15 x i8] c"begin dump: %s\00", align 1
@.str.4 = hidden unnamed_addr constant [5 x i8] c"corr\00", align 1
@.str.5 = hidden unnamed_addr constant [2 x i8] c"\0A\00", align 1
@.str.6 = hidden unnamed_addr constant [8 x i8] c"%0.2lf \00", align 1
@.str.7 = hidden unnamed_addr constant [17 x i8] c"\0Aend   dump: %s\0A\00", align 1
@.str.8 = hidden unnamed_addr constant [23 x i8] c"==END   DUMP_ARRAYS==\0A\00", align 1
@llvm.global.annotations = appending global [1 x { i8*, i8*, i8*, i32, i8* }] [{ i8*, i8*, i8*, i32, i8* } { i8* bitcast (i32 ()* @task_job_polybench to i8*), i8* getelementptr inbounds ([12 x i8], [12 x i8]* @.str, i32 0, i32 0), i8* getelementptr inbounds ([111 x i8], [111 x i8]* @.str.1, i32 0, i32 0), i32 154, i8* null }], section "llvm.metadata"

; Function Attrs: noinline nounwind uwtable
define dso_local i32 @task_job_polybench() #0 !dbg !39 {
  %1 = load i32, i32* @m, align 4, !dbg !47
  %2 = load i32, i32* @n, align 4, !dbg !48
  %3 = load double, double* @float_n, align 8, !dbg !49
  call void @llvm.dbg.value(metadata i32 %1, metadata !50, metadata !DIExpression()), !dbg !56
  call void @llvm.dbg.value(metadata i32 %2, metadata !58, metadata !DIExpression()), !dbg !56
  call void @llvm.dbg.value(metadata double %3, metadata !59, metadata !DIExpression()), !dbg !56
  call void @llvm.dbg.value(metadata [240 x double]* getelementptr inbounds ([260 x [240 x double]], [260 x [240 x double]]* @data, i64 0, i64 0), metadata !60, metadata !DIExpression()), !dbg !56
  call void @llvm.dbg.value(metadata [240 x double]* getelementptr inbounds ([240 x [240 x double]], [240 x [240 x double]]* @corr, i64 0, i64 0), metadata !61, metadata !DIExpression()), !dbg !56
  call void @llvm.dbg.value(metadata double* getelementptr inbounds ([240 x double], [240 x double]* @mean, i64 0, i64 0), metadata !62, metadata !DIExpression()), !dbg !56
  call void @llvm.dbg.value(metadata double* getelementptr inbounds ([240 x double], [240 x double]* @stddev, i64 0, i64 0), metadata !63, metadata !DIExpression()), !dbg !56
  call void @llvm.dbg.value(metadata double 1.000000e-01, metadata !64, metadata !DIExpression()), !dbg !56
  call void @llvm.dbg.value(metadata i32 0, metadata !65, metadata !DIExpression()), !dbg !56
  br label %4, !dbg !66

4:                                                ; preds = %22, %0
  %.01 = phi i32 [ 0, %0 ], [ %27, %22 ], !dbg !68
  call void @llvm.dbg.value(metadata i32 %.01, metadata !65, metadata !DIExpression()), !dbg !56
  %5 = icmp slt i32 %.01, 240, !dbg !69
  br i1 %5, label %6, label %28, !dbg !71

6:                                                ; preds = %4
  %7 = sext i32 %.01 to i64, !dbg !72
  %8 = getelementptr inbounds double, double* getelementptr inbounds ([240 x double], [240 x double]* @mean, i64 0, i64 0), i64 %7, !dbg !72
  store double 0.000000e+00, double* %8, align 8, !dbg !74
  call void @llvm.dbg.value(metadata i32 0, metadata !75, metadata !DIExpression()), !dbg !56
  br label %9, !dbg !76

9:                                                ; preds = %11, %6
  %.02 = phi i32 [ 0, %6 ], [ %21, %11 ], !dbg !78
  call void @llvm.dbg.value(metadata i32 %.02, metadata !75, metadata !DIExpression()), !dbg !56
  %10 = icmp slt i32 %.02, 260, !dbg !79
  br i1 %10, label %11, label %22, !dbg !81

11:                                               ; preds = %9
  %12 = sext i32 %.02 to i64, !dbg !82
  %13 = getelementptr inbounds [240 x double], [240 x double]* getelementptr inbounds ([260 x [240 x double]], [260 x [240 x double]]* @data, i64 0, i64 0), i64 %12, !dbg !82
  %14 = sext i32 %.01 to i64, !dbg !82
  %15 = getelementptr inbounds [240 x double], [240 x double]* %13, i64 0, i64 %14, !dbg !82
  %16 = load double, double* %15, align 8, !dbg !82
  %17 = sext i32 %.01 to i64, !dbg !83
  %18 = getelementptr inbounds double, double* getelementptr inbounds ([240 x double], [240 x double]* @mean, i64 0, i64 0), i64 %17, !dbg !83
  %19 = load double, double* %18, align 8, !dbg !84
  %20 = fadd double %19, %16, !dbg !84
  store double %20, double* %18, align 8, !dbg !84
  %21 = add nsw i32 %.02, 1, !dbg !85
  call void @llvm.dbg.value(metadata i32 %21, metadata !75, metadata !DIExpression()), !dbg !56
  br label %9, !dbg !86, !llvm.loop !87

22:                                               ; preds = %9
  %23 = sext i32 %.01 to i64, !dbg !90
  %24 = getelementptr inbounds double, double* getelementptr inbounds ([240 x double], [240 x double]* @mean, i64 0, i64 0), i64 %23, !dbg !90
  %25 = load double, double* %24, align 8, !dbg !91
  %26 = fdiv double %25, %3, !dbg !91
  store double %26, double* %24, align 8, !dbg !91
  %27 = add nsw i32 %.01, 1, !dbg !92
  call void @llvm.dbg.value(metadata i32 %27, metadata !65, metadata !DIExpression()), !dbg !56
  br label %4, !dbg !93, !llvm.loop !94

28:                                               ; preds = %4
  call void @llvm.dbg.value(metadata i32 0, metadata !65, metadata !DIExpression()), !dbg !56
  br label %29, !dbg !96

29:                                               ; preds = %81, %28
  %.1 = phi i32 [ 0, %28 ], [ %85, %81 ], !dbg !98
  call void @llvm.dbg.value(metadata i32 %.1, metadata !65, metadata !DIExpression()), !dbg !56
  %30 = icmp slt i32 %.1, 240, !dbg !99
  br i1 %30, label %31, label %86, !dbg !101

31:                                               ; preds = %29
  %32 = sext i32 %.1 to i64, !dbg !102
  %33 = getelementptr inbounds double, double* getelementptr inbounds ([240 x double], [240 x double]* @stddev, i64 0, i64 0), i64 %32, !dbg !102
  store double 0.000000e+00, double* %33, align 8, !dbg !104
  call void @llvm.dbg.value(metadata i32 0, metadata !75, metadata !DIExpression()), !dbg !56
  br label %34, !dbg !105

34:                                               ; preds = %36, %31
  %.13 = phi i32 [ 0, %31 ], [ %60, %36 ], !dbg !107
  call void @llvm.dbg.value(metadata i32 %.13, metadata !75, metadata !DIExpression()), !dbg !56
  %35 = icmp slt i32 %.13, 260, !dbg !108
  br i1 %35, label %36, label %61, !dbg !110

36:                                               ; preds = %34
  %37 = sext i32 %.13 to i64, !dbg !111
  %38 = getelementptr inbounds [240 x double], [240 x double]* getelementptr inbounds ([260 x [240 x double]], [260 x [240 x double]]* @data, i64 0, i64 0), i64 %37, !dbg !111
  %39 = sext i32 %.1 to i64, !dbg !111
  %40 = getelementptr inbounds [240 x double], [240 x double]* %38, i64 0, i64 %39, !dbg !111
  %41 = load double, double* %40, align 8, !dbg !111
  %42 = sext i32 %.1 to i64, !dbg !112
  %43 = getelementptr inbounds double, double* getelementptr inbounds ([240 x double], [240 x double]* @mean, i64 0, i64 0), i64 %42, !dbg !112
  %44 = load double, double* %43, align 8, !dbg !112
  %45 = fsub double %41, %44, !dbg !113
  %46 = sext i32 %.13 to i64, !dbg !114
  %47 = getelementptr inbounds [240 x double], [240 x double]* getelementptr inbounds ([260 x [240 x double]], [260 x [240 x double]]* @data, i64 0, i64 0), i64 %46, !dbg !114
  %48 = sext i32 %.1 to i64, !dbg !114
  %49 = getelementptr inbounds [240 x double], [240 x double]* %47, i64 0, i64 %48, !dbg !114
  %50 = load double, double* %49, align 8, !dbg !114
  %51 = sext i32 %.1 to i64, !dbg !115
  %52 = getelementptr inbounds double, double* getelementptr inbounds ([240 x double], [240 x double]* @mean, i64 0, i64 0), i64 %51, !dbg !115
  %53 = load double, double* %52, align 8, !dbg !115
  %54 = fsub double %50, %53, !dbg !116
  %55 = fmul double %45, %54, !dbg !117
  %56 = sext i32 %.1 to i64, !dbg !118
  %57 = getelementptr inbounds double, double* getelementptr inbounds ([240 x double], [240 x double]* @stddev, i64 0, i64 0), i64 %56, !dbg !118
  %58 = load double, double* %57, align 8, !dbg !119
  %59 = fadd double %58, %55, !dbg !119
  store double %59, double* %57, align 8, !dbg !119
  %60 = add nsw i32 %.13, 1, !dbg !120
  call void @llvm.dbg.value(metadata i32 %60, metadata !75, metadata !DIExpression()), !dbg !56
  br label %34, !dbg !121, !llvm.loop !122

61:                                               ; preds = %34
  %62 = sext i32 %.1 to i64, !dbg !124
  %63 = getelementptr inbounds double, double* getelementptr inbounds ([240 x double], [240 x double]* @stddev, i64 0, i64 0), i64 %62, !dbg !124
  %64 = load double, double* %63, align 8, !dbg !125
  %65 = fdiv double %64, %3, !dbg !125
  store double %65, double* %63, align 8, !dbg !125
  %66 = sext i32 %.1 to i64, !dbg !126
  %67 = getelementptr inbounds double, double* getelementptr inbounds ([240 x double], [240 x double]* @stddev, i64 0, i64 0), i64 %66, !dbg !126
  %68 = load double, double* %67, align 8, !dbg !126
  %69 = call double @sqrt(double noundef %68) #3, !dbg !126
  %70 = sext i32 %.1 to i64, !dbg !127
  %71 = getelementptr inbounds double, double* getelementptr inbounds ([240 x double], [240 x double]* @stddev, i64 0, i64 0), i64 %70, !dbg !127
  store double %69, double* %71, align 8, !dbg !128
  %72 = sext i32 %.1 to i64, !dbg !129
  %73 = getelementptr inbounds double, double* getelementptr inbounds ([240 x double], [240 x double]* @stddev, i64 0, i64 0), i64 %72, !dbg !129
  %74 = load double, double* %73, align 8, !dbg !129
  %75 = fcmp ole double %74, 1.000000e-01, !dbg !130
  br i1 %75, label %76, label %77, !dbg !129

76:                                               ; preds = %61
  br label %81, !dbg !129

77:                                               ; preds = %61
  %78 = sext i32 %.1 to i64, !dbg !131
  %79 = getelementptr inbounds double, double* getelementptr inbounds ([240 x double], [240 x double]* @stddev, i64 0, i64 0), i64 %78, !dbg !131
  %80 = load double, double* %79, align 8, !dbg !131
  br label %81, !dbg !129

81:                                               ; preds = %77, %76
  %82 = phi double [ 1.000000e+00, %76 ], [ %80, %77 ], !dbg !129
  %83 = sext i32 %.1 to i64, !dbg !132
  %84 = getelementptr inbounds double, double* getelementptr inbounds ([240 x double], [240 x double]* @stddev, i64 0, i64 0), i64 %83, !dbg !132
  store double %82, double* %84, align 8, !dbg !133
  %85 = add nsw i32 %.1, 1, !dbg !134
  call void @llvm.dbg.value(metadata i32 %85, metadata !65, metadata !DIExpression()), !dbg !56
  br label %29, !dbg !135, !llvm.loop !136

86:                                               ; preds = %29
  call void @llvm.dbg.value(metadata i32 0, metadata !75, metadata !DIExpression()), !dbg !56
  br label %87, !dbg !138

87:                                               ; preds = %114, %86
  %.24 = phi i32 [ 0, %86 ], [ %115, %114 ], !dbg !140
  call void @llvm.dbg.value(metadata i32 %.24, metadata !75, metadata !DIExpression()), !dbg !56
  %88 = icmp slt i32 %.24, 260, !dbg !141
  br i1 %88, label %89, label %116, !dbg !143

89:                                               ; preds = %87
  call void @llvm.dbg.value(metadata i32 0, metadata !65, metadata !DIExpression()), !dbg !56
  br label %90, !dbg !144

90:                                               ; preds = %92, %89
  %.2 = phi i32 [ 0, %89 ], [ %113, %92 ], !dbg !146
  call void @llvm.dbg.value(metadata i32 %.2, metadata !65, metadata !DIExpression()), !dbg !56
  %91 = icmp slt i32 %.2, 240, !dbg !147
  br i1 %91, label %92, label %114, !dbg !149

92:                                               ; preds = %90
  %93 = sext i32 %.2 to i64, !dbg !150
  %94 = getelementptr inbounds double, double* getelementptr inbounds ([240 x double], [240 x double]* @mean, i64 0, i64 0), i64 %93, !dbg !150
  %95 = load double, double* %94, align 8, !dbg !150
  %96 = sext i32 %.24 to i64, !dbg !152
  %97 = getelementptr inbounds [240 x double], [240 x double]* getelementptr inbounds ([260 x [240 x double]], [260 x [240 x double]]* @data, i64 0, i64 0), i64 %96, !dbg !152
  %98 = sext i32 %.2 to i64, !dbg !152
  %99 = getelementptr inbounds [240 x double], [240 x double]* %97, i64 0, i64 %98, !dbg !152
  %100 = load double, double* %99, align 8, !dbg !153
  %101 = fsub double %100, %95, !dbg !153
  store double %101, double* %99, align 8, !dbg !153
  %102 = call double @sqrt(double noundef %3) #3, !dbg !154
  %103 = sext i32 %.2 to i64, !dbg !155
  %104 = getelementptr inbounds double, double* getelementptr inbounds ([240 x double], [240 x double]* @stddev, i64 0, i64 0), i64 %103, !dbg !155
  %105 = load double, double* %104, align 8, !dbg !155
  %106 = fmul double %102, %105, !dbg !156
  %107 = sext i32 %.24 to i64, !dbg !157
  %108 = getelementptr inbounds [240 x double], [240 x double]* getelementptr inbounds ([260 x [240 x double]], [260 x [240 x double]]* @data, i64 0, i64 0), i64 %107, !dbg !157
  %109 = sext i32 %.2 to i64, !dbg !157
  %110 = getelementptr inbounds [240 x double], [240 x double]* %108, i64 0, i64 %109, !dbg !157
  %111 = load double, double* %110, align 8, !dbg !158
  %112 = fdiv double %111, %106, !dbg !158
  store double %112, double* %110, align 8, !dbg !158
  %113 = add nsw i32 %.2, 1, !dbg !159
  call void @llvm.dbg.value(metadata i32 %113, metadata !65, metadata !DIExpression()), !dbg !56
  br label %90, !dbg !160, !llvm.loop !161

114:                                              ; preds = %90
  %115 = add nsw i32 %.24, 1, !dbg !163
  call void @llvm.dbg.value(metadata i32 %115, metadata !75, metadata !DIExpression()), !dbg !56
  br label %87, !dbg !164, !llvm.loop !165

116:                                              ; preds = %87
  call void @llvm.dbg.value(metadata i32 0, metadata !75, metadata !DIExpression()), !dbg !56
  br label %117, !dbg !167

117:                                              ; preds = %164, %116
  %.35 = phi i32 [ 0, %116 ], [ %165, %164 ], !dbg !169
  call void @llvm.dbg.value(metadata i32 %.35, metadata !75, metadata !DIExpression()), !dbg !56
  %118 = icmp slt i32 %.35, 239, !dbg !170
  br i1 %118, label %119, label %166, !dbg !172

119:                                              ; preds = %117
  %120 = sext i32 %.35 to i64, !dbg !173
  %121 = getelementptr inbounds [240 x double], [240 x double]* getelementptr inbounds ([240 x [240 x double]], [240 x [240 x double]]* @corr, i64 0, i64 0), i64 %120, !dbg !173
  %122 = sext i32 %.35 to i64, !dbg !173
  %123 = getelementptr inbounds [240 x double], [240 x double]* %121, i64 0, i64 %122, !dbg !173
  store double 1.000000e+00, double* %123, align 8, !dbg !175
  %124 = add nsw i32 %.35, 1, !dbg !176
  call void @llvm.dbg.value(metadata i32 %124, metadata !65, metadata !DIExpression()), !dbg !56
  br label %125, !dbg !178

125:                                              ; preds = %153, %119
  %.3 = phi i32 [ %124, %119 ], [ %163, %153 ], !dbg !179
  call void @llvm.dbg.value(metadata i32 %.3, metadata !65, metadata !DIExpression()), !dbg !56
  %126 = icmp slt i32 %.3, 240, !dbg !180
  br i1 %126, label %127, label %164, !dbg !182

127:                                              ; preds = %125
  %128 = sext i32 %.35 to i64, !dbg !183
  %129 = getelementptr inbounds [240 x double], [240 x double]* getelementptr inbounds ([240 x [240 x double]], [240 x [240 x double]]* @corr, i64 0, i64 0), i64 %128, !dbg !183
  %130 = sext i32 %.3 to i64, !dbg !183
  %131 = getelementptr inbounds [240 x double], [240 x double]* %129, i64 0, i64 %130, !dbg !183
  store double 0.000000e+00, double* %131, align 8, !dbg !185
  call void @llvm.dbg.value(metadata i32 0, metadata !186, metadata !DIExpression()), !dbg !56
  br label %132, !dbg !187

132:                                              ; preds = %134, %127
  %.0 = phi i32 [ 0, %127 ], [ %152, %134 ], !dbg !189
  call void @llvm.dbg.value(metadata i32 %.0, metadata !186, metadata !DIExpression()), !dbg !56
  %133 = icmp slt i32 %.0, 260, !dbg !190
  br i1 %133, label %134, label %153, !dbg !192

134:                                              ; preds = %132
  %135 = sext i32 %.0 to i64, !dbg !193
  %136 = getelementptr inbounds [240 x double], [240 x double]* getelementptr inbounds ([260 x [240 x double]], [260 x [240 x double]]* @data, i64 0, i64 0), i64 %135, !dbg !193
  %137 = sext i32 %.35 to i64, !dbg !193
  %138 = getelementptr inbounds [240 x double], [240 x double]* %136, i64 0, i64 %137, !dbg !193
  %139 = load double, double* %138, align 8, !dbg !193
  %140 = sext i32 %.0 to i64, !dbg !194
  %141 = getelementptr inbounds [240 x double], [240 x double]* getelementptr inbounds ([260 x [240 x double]], [260 x [240 x double]]* @data, i64 0, i64 0), i64 %140, !dbg !194
  %142 = sext i32 %.3 to i64, !dbg !194
  %143 = getelementptr inbounds [240 x double], [240 x double]* %141, i64 0, i64 %142, !dbg !194
  %144 = load double, double* %143, align 8, !dbg !194
  %145 = fmul double %139, %144, !dbg !195
  %146 = sext i32 %.35 to i64, !dbg !196
  %147 = getelementptr inbounds [240 x double], [240 x double]* getelementptr inbounds ([240 x [240 x double]], [240 x [240 x double]]* @corr, i64 0, i64 0), i64 %146, !dbg !196
  %148 = sext i32 %.3 to i64, !dbg !196
  %149 = getelementptr inbounds [240 x double], [240 x double]* %147, i64 0, i64 %148, !dbg !196
  %150 = load double, double* %149, align 8, !dbg !197
  %151 = fadd double %150, %145, !dbg !197
  store double %151, double* %149, align 8, !dbg !197
  %152 = add nsw i32 %.0, 1, !dbg !198
  call void @llvm.dbg.value(metadata i32 %152, metadata !186, metadata !DIExpression()), !dbg !56
  br label %132, !dbg !199, !llvm.loop !200

153:                                              ; preds = %132
  %154 = sext i32 %.35 to i64, !dbg !202
  %155 = getelementptr inbounds [240 x double], [240 x double]* getelementptr inbounds ([240 x [240 x double]], [240 x [240 x double]]* @corr, i64 0, i64 0), i64 %154, !dbg !202
  %156 = sext i32 %.3 to i64, !dbg !202
  %157 = getelementptr inbounds [240 x double], [240 x double]* %155, i64 0, i64 %156, !dbg !202
  %158 = load double, double* %157, align 8, !dbg !202
  %159 = sext i32 %.3 to i64, !dbg !203
  %160 = getelementptr inbounds [240 x double], [240 x double]* getelementptr inbounds ([240 x [240 x double]], [240 x [240 x double]]* @corr, i64 0, i64 0), i64 %159, !dbg !203
  %161 = sext i32 %.35 to i64, !dbg !203
  %162 = getelementptr inbounds [240 x double], [240 x double]* %160, i64 0, i64 %161, !dbg !203
  store double %158, double* %162, align 8, !dbg !204
  %163 = add nsw i32 %.3, 1, !dbg !205
  call void @llvm.dbg.value(metadata i32 %163, metadata !65, metadata !DIExpression()), !dbg !56
  br label %125, !dbg !206, !llvm.loop !207

164:                                              ; preds = %125
  %165 = add nsw i32 %.35, 1, !dbg !209
  call void @llvm.dbg.value(metadata i32 %165, metadata !75, metadata !DIExpression()), !dbg !56
  br label %117, !dbg !210, !llvm.loop !211

166:                                              ; preds = %117
  %167 = getelementptr inbounds [240 x double], [240 x double]* getelementptr inbounds ([240 x [240 x double]], [240 x [240 x double]]* @corr, i64 0, i64 0), i64 239, !dbg !213
  %168 = getelementptr inbounds [240 x double], [240 x double]* %167, i64 0, i64 239, !dbg !213
  store double 1.000000e+00, double* %168, align 8, !dbg !214
  ret i32 0, !dbg !215
}

; Function Attrs: nounwind
declare double @sqrt(double noundef) #1

; Function Attrs: nofree nosync nounwind readnone speculatable willreturn
declare void @llvm.dbg.value(metadata, metadata, metadata) #2

attributes #0 = { noinline nounwind uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { nounwind "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #2 = { nofree nosync nounwind readnone speculatable willreturn }
attributes #3 = { nounwind }

!llvm.dbg.cu = !{!2}
!llvm.module.flags = !{!31, !32, !33, !34, !35, !36, !37}
!llvm.ident = !{!38}

!0 = !DIGlobalVariableExpression(var: !1, expr: !DIExpression())
!1 = distinct !DIGlobalVariable(name: "n", scope: !2, file: !11, line: 140, type: !12, isLocal: false, isDefinition: true)
!2 = distinct !DICompileUnit(language: DW_LANG_C99, file: !3, producer: "Ubuntu clang version 14.0.0-1ubuntu1.1", isOptimized: false, runtimeVersion: 0, emissionKind: FullDebug, retainedTypes: !4, globals: !8, splitDebugInlining: false, nameTableKind: None)
!3 = !DIFile(filename: "/workspace/experiments/chaser/.cache/periodic-polybench/locality-medium-20260929/correlation/source/workload.c", directory: "/workspace/experiments/chaser/.cache/periodic-polybench/locality-medium-20260929/correlation/native-analysis", checksumkind: CSK_MD5, checksum: "70aeadc916d878c9ba36dd4e6a67c2f2")
!4 = !{!5, !6, !7}
!5 = !DIBasicType(name: "double", size: 64, encoding: DW_ATE_float)
!6 = !DIBasicType(name: "unsigned int", size: 32, encoding: DW_ATE_unsigned)
!7 = !DIBasicType(name: "unsigned char", size: 8, encoding: DW_ATE_unsigned_char)
!8 = !{!0, !9, !13, !19, !23, !27, !29}
!9 = !DIGlobalVariableExpression(var: !10, expr: !DIExpression())
!10 = distinct !DIGlobalVariable(name: "m", scope: !2, file: !11, line: 141, type: !12, isLocal: false, isDefinition: true)
!11 = !DIFile(filename: "source/workload.c", directory: "/workspace/experiments/chaser/.cache/periodic-polybench/locality-medium-20260929/correlation", checksumkind: CSK_MD5, checksum: "70aeadc916d878c9ba36dd4e6a67c2f2")
!12 = !DIBasicType(name: "int", size: 32, encoding: DW_ATE_signed)
!13 = !DIGlobalVariableExpression(var: !14, expr: !DIExpression())
!14 = distinct !DIGlobalVariable(name: "data", scope: !2, file: !11, line: 33, type: !15, isLocal: false, isDefinition: true, align: 512)
!15 = !DICompositeType(tag: DW_TAG_array_type, baseType: !5, size: 3993600, elements: !16)
!16 = !{!17, !18}
!17 = !DISubrange(count: 260)
!18 = !DISubrange(count: 240)
!19 = !DIGlobalVariableExpression(var: !20, expr: !DIExpression())
!20 = distinct !DIGlobalVariable(name: "corr", scope: !2, file: !11, line: 34, type: !21, isLocal: false, isDefinition: true, align: 512)
!21 = !DICompositeType(tag: DW_TAG_array_type, baseType: !5, size: 3686400, elements: !22)
!22 = !{!18, !18}
!23 = !DIGlobalVariableExpression(var: !24, expr: !DIExpression())
!24 = distinct !DIGlobalVariable(name: "mean", scope: !2, file: !11, line: 35, type: !25, isLocal: false, isDefinition: true, align: 512)
!25 = !DICompositeType(tag: DW_TAG_array_type, baseType: !5, size: 15360, elements: !26)
!26 = !{!18}
!27 = !DIGlobalVariableExpression(var: !28, expr: !DIExpression())
!28 = distinct !DIGlobalVariable(name: "stddev", scope: !2, file: !11, line: 36, type: !25, isLocal: false, isDefinition: true, align: 512)
!29 = !DIGlobalVariableExpression(var: !30, expr: !DIExpression())
!30 = distinct !DIGlobalVariable(name: "float_n", scope: !2, file: !11, line: 144, type: !5, isLocal: false, isDefinition: true)
!31 = !{i32 7, !"Dwarf Version", i32 5}
!32 = !{i32 2, !"Debug Info Version", i32 3}
!33 = !{i32 1, !"wchar_size", i32 4}
!34 = !{i32 7, !"PIC Level", i32 2}
!35 = !{i32 7, !"PIE Level", i32 2}
!36 = !{i32 7, !"uwtable", i32 1}
!37 = !{i32 7, !"frame-pointer", i32 2}
!38 = !{!"Ubuntu clang version 14.0.0-1ubuntu1.1"}
!39 = distinct !DISubprogram(name: "task_job_polybench", scope: !11, file: !11, line: 154, type: !40, scopeLine: 154, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !2, retainedNodes: !46)
!40 = !DISubroutineType(types: !41)
!41 = !{!42}
!42 = !DIDerivedType(tag: DW_TAG_typedef, name: "uint32_t", file: !43, line: 26, baseType: !44)
!43 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/stdint-uintn.h", directory: "", checksumkind: CSK_MD5, checksum: "2bf2ae53c58c01b1a1b9383b5195125c")
!44 = !DIDerivedType(tag: DW_TAG_typedef, name: "__uint32_t", file: !45, line: 42, baseType: !6)
!45 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/types.h", directory: "", checksumkind: CSK_MD5, checksum: "d108b5f93a74c50510d7d9bc0ab36df9")
!46 = !{}
!47 = !DILocation(line: 155, column: 23, scope: !39)
!48 = !DILocation(line: 155, column: 26, scope: !39)
!49 = !DILocation(line: 155, column: 29, scope: !39)
!50 = !DILocalVariable(name: "m", arg: 1, scope: !51, file: !11, line: 78, type: !12)
!51 = distinct !DISubprogram(name: "kernel_correlation", scope: !11, file: !11, line: 78, type: !52, scopeLine: 84, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition, unit: !2, retainedNodes: !46)
!52 = !DISubroutineType(types: !53)
!53 = !{null, !12, !12, !5, !54, !54, !55, !55}
!54 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !25, size: 64)
!55 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !5, size: 64)
!56 = !DILocation(line: 0, scope: !51, inlinedAt: !57)
!57 = distinct !DILocation(line: 155, column: 3, scope: !39)
!58 = !DILocalVariable(name: "n", arg: 2, scope: !51, file: !11, line: 78, type: !12)
!59 = !DILocalVariable(name: "float_n", arg: 3, scope: !51, file: !11, line: 79, type: !5)
!60 = !DILocalVariable(name: "data", arg: 4, scope: !51, file: !11, line: 80, type: !54)
!61 = !DILocalVariable(name: "corr", arg: 5, scope: !51, file: !11, line: 81, type: !54)
!62 = !DILocalVariable(name: "mean", arg: 6, scope: !51, file: !11, line: 82, type: !55)
!63 = !DILocalVariable(name: "stddev", arg: 7, scope: !51, file: !11, line: 83, type: !55)
!64 = !DILocalVariable(name: "eps", scope: !51, file: !11, line: 87, type: !5)
!65 = !DILocalVariable(name: "j", scope: !51, file: !11, line: 85, type: !12)
!66 = !DILocation(line: 91, column: 8, scope: !67, inlinedAt: !57)
!67 = distinct !DILexicalBlock(scope: !51, file: !11, line: 91, column: 3)
!68 = !DILocation(line: 0, scope: !67, inlinedAt: !57)
!69 = !DILocation(line: 91, column: 17, scope: !70, inlinedAt: !57)
!70 = distinct !DILexicalBlock(scope: !67, file: !11, line: 91, column: 3)
!71 = !DILocation(line: 91, column: 3, scope: !67, inlinedAt: !57)
!72 = !DILocation(line: 93, column: 7, scope: !73, inlinedAt: !57)
!73 = distinct !DILexicalBlock(scope: !70, file: !11, line: 92, column: 5)
!74 = !DILocation(line: 93, column: 15, scope: !73, inlinedAt: !57)
!75 = !DILocalVariable(name: "i", scope: !51, file: !11, line: 85, type: !12)
!76 = !DILocation(line: 94, column: 12, scope: !77, inlinedAt: !57)
!77 = distinct !DILexicalBlock(scope: !73, file: !11, line: 94, column: 7)
!78 = !DILocation(line: 0, scope: !77, inlinedAt: !57)
!79 = !DILocation(line: 94, column: 21, scope: !80, inlinedAt: !57)
!80 = distinct !DILexicalBlock(scope: !77, file: !11, line: 94, column: 7)
!81 = !DILocation(line: 94, column: 7, scope: !77, inlinedAt: !57)
!82 = !DILocation(line: 95, column: 13, scope: !80, inlinedAt: !57)
!83 = !DILocation(line: 95, column: 2, scope: !80, inlinedAt: !57)
!84 = !DILocation(line: 95, column: 10, scope: !80, inlinedAt: !57)
!85 = !DILocation(line: 94, column: 31, scope: !80, inlinedAt: !57)
!86 = !DILocation(line: 94, column: 7, scope: !80, inlinedAt: !57)
!87 = distinct !{!87, !81, !88, !89}
!88 = !DILocation(line: 95, column: 22, scope: !77, inlinedAt: !57)
!89 = !{!"llvm.loop.mustprogress"}
!90 = !DILocation(line: 96, column: 7, scope: !73, inlinedAt: !57)
!91 = !DILocation(line: 96, column: 15, scope: !73, inlinedAt: !57)
!92 = !DILocation(line: 91, column: 27, scope: !70, inlinedAt: !57)
!93 = !DILocation(line: 91, column: 3, scope: !70, inlinedAt: !57)
!94 = distinct !{!94, !71, !95, !89}
!95 = !DILocation(line: 97, column: 5, scope: !67, inlinedAt: !57)
!96 = !DILocation(line: 100, column: 9, scope: !97, inlinedAt: !57)
!97 = distinct !DILexicalBlock(scope: !51, file: !11, line: 100, column: 4)
!98 = !DILocation(line: 0, scope: !97, inlinedAt: !57)
!99 = !DILocation(line: 100, column: 18, scope: !100, inlinedAt: !57)
!100 = distinct !DILexicalBlock(scope: !97, file: !11, line: 100, column: 4)
!101 = !DILocation(line: 100, column: 4, scope: !97, inlinedAt: !57)
!102 = !DILocation(line: 102, column: 7, scope: !103, inlinedAt: !57)
!103 = distinct !DILexicalBlock(scope: !100, file: !11, line: 101, column: 5)
!104 = !DILocation(line: 102, column: 17, scope: !103, inlinedAt: !57)
!105 = !DILocation(line: 103, column: 12, scope: !106, inlinedAt: !57)
!106 = distinct !DILexicalBlock(scope: !103, file: !11, line: 103, column: 7)
!107 = !DILocation(line: 0, scope: !106, inlinedAt: !57)
!108 = !DILocation(line: 103, column: 21, scope: !109, inlinedAt: !57)
!109 = distinct !DILexicalBlock(scope: !106, file: !11, line: 103, column: 7)
!110 = !DILocation(line: 103, column: 7, scope: !106, inlinedAt: !57)
!111 = !DILocation(line: 104, column: 23, scope: !109, inlinedAt: !57)
!112 = !DILocation(line: 104, column: 36, scope: !109, inlinedAt: !57)
!113 = !DILocation(line: 104, column: 34, scope: !109, inlinedAt: !57)
!114 = !DILocation(line: 104, column: 48, scope: !109, inlinedAt: !57)
!115 = !DILocation(line: 104, column: 61, scope: !109, inlinedAt: !57)
!116 = !DILocation(line: 104, column: 59, scope: !109, inlinedAt: !57)
!117 = !DILocation(line: 104, column: 45, scope: !109, inlinedAt: !57)
!118 = !DILocation(line: 104, column: 9, scope: !109, inlinedAt: !57)
!119 = !DILocation(line: 104, column: 19, scope: !109, inlinedAt: !57)
!120 = !DILocation(line: 103, column: 31, scope: !109, inlinedAt: !57)
!121 = !DILocation(line: 103, column: 7, scope: !109, inlinedAt: !57)
!122 = distinct !{!122, !110, !123, !89}
!123 = !DILocation(line: 104, column: 68, scope: !106, inlinedAt: !57)
!124 = !DILocation(line: 105, column: 7, scope: !103, inlinedAt: !57)
!125 = !DILocation(line: 105, column: 17, scope: !103, inlinedAt: !57)
!126 = !DILocation(line: 106, column: 19, scope: !103, inlinedAt: !57)
!127 = !DILocation(line: 106, column: 7, scope: !103, inlinedAt: !57)
!128 = !DILocation(line: 106, column: 17, scope: !103, inlinedAt: !57)
!129 = !DILocation(line: 110, column: 19, scope: !103, inlinedAt: !57)
!130 = !DILocation(line: 110, column: 29, scope: !103, inlinedAt: !57)
!131 = !DILocation(line: 110, column: 56, scope: !103, inlinedAt: !57)
!132 = !DILocation(line: 110, column: 7, scope: !103, inlinedAt: !57)
!133 = !DILocation(line: 110, column: 17, scope: !103, inlinedAt: !57)
!134 = !DILocation(line: 100, column: 28, scope: !100, inlinedAt: !57)
!135 = !DILocation(line: 100, column: 4, scope: !100, inlinedAt: !57)
!136 = distinct !{!136, !101, !137, !89}
!137 = !DILocation(line: 111, column: 5, scope: !97, inlinedAt: !57)
!138 = !DILocation(line: 114, column: 8, scope: !139, inlinedAt: !57)
!139 = distinct !DILexicalBlock(scope: !51, file: !11, line: 114, column: 3)
!140 = !DILocation(line: 0, scope: !139, inlinedAt: !57)
!141 = !DILocation(line: 114, column: 17, scope: !142, inlinedAt: !57)
!142 = distinct !DILexicalBlock(scope: !139, file: !11, line: 114, column: 3)
!143 = !DILocation(line: 114, column: 3, scope: !139, inlinedAt: !57)
!144 = !DILocation(line: 115, column: 10, scope: !145, inlinedAt: !57)
!145 = distinct !DILexicalBlock(scope: !142, file: !11, line: 115, column: 5)
!146 = !DILocation(line: 0, scope: !145, inlinedAt: !57)
!147 = !DILocation(line: 115, column: 19, scope: !148, inlinedAt: !57)
!148 = distinct !DILexicalBlock(scope: !145, file: !11, line: 115, column: 5)
!149 = !DILocation(line: 115, column: 5, scope: !145, inlinedAt: !57)
!150 = !DILocation(line: 117, column: 23, scope: !151, inlinedAt: !57)
!151 = distinct !DILexicalBlock(scope: !148, file: !11, line: 116, column: 7)
!152 = !DILocation(line: 117, column: 9, scope: !151, inlinedAt: !57)
!153 = !DILocation(line: 117, column: 20, scope: !151, inlinedAt: !57)
!154 = !DILocation(line: 118, column: 23, scope: !151, inlinedAt: !57)
!155 = !DILocation(line: 118, column: 43, scope: !151, inlinedAt: !57)
!156 = !DILocation(line: 118, column: 41, scope: !151, inlinedAt: !57)
!157 = !DILocation(line: 118, column: 9, scope: !151, inlinedAt: !57)
!158 = !DILocation(line: 118, column: 20, scope: !151, inlinedAt: !57)
!159 = !DILocation(line: 115, column: 29, scope: !148, inlinedAt: !57)
!160 = !DILocation(line: 115, column: 5, scope: !148, inlinedAt: !57)
!161 = distinct !{!161, !149, !162, !89}
!162 = !DILocation(line: 119, column: 7, scope: !145, inlinedAt: !57)
!163 = !DILocation(line: 114, column: 27, scope: !142, inlinedAt: !57)
!164 = !DILocation(line: 114, column: 3, scope: !142, inlinedAt: !57)
!165 = distinct !{!165, !143, !166, !89}
!166 = !DILocation(line: 119, column: 7, scope: !139, inlinedAt: !57)
!167 = !DILocation(line: 122, column: 8, scope: !168, inlinedAt: !57)
!168 = distinct !DILexicalBlock(scope: !51, file: !11, line: 122, column: 3)
!169 = !DILocation(line: 0, scope: !168, inlinedAt: !57)
!170 = !DILocation(line: 122, column: 17, scope: !171, inlinedAt: !57)
!171 = distinct !DILexicalBlock(scope: !168, file: !11, line: 122, column: 3)
!172 = !DILocation(line: 122, column: 3, scope: !168, inlinedAt: !57)
!173 = !DILocation(line: 124, column: 7, scope: !174, inlinedAt: !57)
!174 = distinct !DILexicalBlock(scope: !171, file: !11, line: 123, column: 5)
!175 = !DILocation(line: 124, column: 18, scope: !174, inlinedAt: !57)
!176 = !DILocation(line: 125, column: 17, scope: !177, inlinedAt: !57)
!177 = distinct !DILexicalBlock(scope: !174, file: !11, line: 125, column: 7)
!178 = !DILocation(line: 125, column: 12, scope: !177, inlinedAt: !57)
!179 = !DILocation(line: 0, scope: !177, inlinedAt: !57)
!180 = !DILocation(line: 125, column: 23, scope: !181, inlinedAt: !57)
!181 = distinct !DILexicalBlock(scope: !177, file: !11, line: 125, column: 7)
!182 = !DILocation(line: 125, column: 7, scope: !177, inlinedAt: !57)
!183 = !DILocation(line: 127, column: 11, scope: !184, inlinedAt: !57)
!184 = distinct !DILexicalBlock(scope: !181, file: !11, line: 126, column: 9)
!185 = !DILocation(line: 127, column: 22, scope: !184, inlinedAt: !57)
!186 = !DILocalVariable(name: "k", scope: !51, file: !11, line: 85, type: !12)
!187 = !DILocation(line: 128, column: 16, scope: !188, inlinedAt: !57)
!188 = distinct !DILexicalBlock(scope: !184, file: !11, line: 128, column: 11)
!189 = !DILocation(line: 0, scope: !188, inlinedAt: !57)
!190 = !DILocation(line: 128, column: 25, scope: !191, inlinedAt: !57)
!191 = distinct !DILexicalBlock(scope: !188, file: !11, line: 128, column: 11)
!192 = !DILocation(line: 128, column: 11, scope: !188, inlinedAt: !57)
!193 = !DILocation(line: 129, column: 28, scope: !191, inlinedAt: !57)
!194 = !DILocation(line: 129, column: 41, scope: !191, inlinedAt: !57)
!195 = !DILocation(line: 129, column: 39, scope: !191, inlinedAt: !57)
!196 = !DILocation(line: 129, column: 13, scope: !191, inlinedAt: !57)
!197 = !DILocation(line: 129, column: 24, scope: !191, inlinedAt: !57)
!198 = !DILocation(line: 128, column: 35, scope: !191, inlinedAt: !57)
!199 = !DILocation(line: 128, column: 11, scope: !191, inlinedAt: !57)
!200 = distinct !{!200, !192, !201, !89}
!201 = !DILocation(line: 129, column: 51, scope: !188, inlinedAt: !57)
!202 = !DILocation(line: 130, column: 24, scope: !184, inlinedAt: !57)
!203 = !DILocation(line: 130, column: 11, scope: !184, inlinedAt: !57)
!204 = !DILocation(line: 130, column: 22, scope: !184, inlinedAt: !57)
!205 = !DILocation(line: 125, column: 33, scope: !181, inlinedAt: !57)
!206 = !DILocation(line: 125, column: 7, scope: !181, inlinedAt: !57)
!207 = distinct !{!207, !182, !208, !89}
!208 = !DILocation(line: 131, column: 9, scope: !177, inlinedAt: !57)
!209 = !DILocation(line: 122, column: 29, scope: !171, inlinedAt: !57)
!210 = !DILocation(line: 122, column: 3, scope: !171, inlinedAt: !57)
!211 = distinct !{!211, !172, !212, !89}
!212 = !DILocation(line: 132, column: 5, scope: !168, inlinedAt: !57)
!213 = !DILocation(line: 133, column: 3, scope: !51, inlinedAt: !57)
!214 = !DILocation(line: 133, column: 26, scope: !51, inlinedAt: !57)
!215 = !DILocation(line: 160, column: 3, scope: !39)
