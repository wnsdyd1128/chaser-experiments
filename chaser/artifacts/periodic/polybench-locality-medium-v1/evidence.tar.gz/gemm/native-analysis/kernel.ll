; ModuleID = 'inlined.ll'
source_filename = "/workspace/experiments/chaser/.cache/periodic-polybench/locality-medium-20260929/gemm/source/workload.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

@ni = external dso_local global i32, align 4, !dbg !0
@nj = external dso_local global i32, align 4, !dbg !9
@nk = external dso_local global i32, align 4, !dbg !13
@C = external dso_local global [200 x [220 x double]], section ".chaser_data.C", align 64, !dbg !15
@A = external dso_local global [200 x [240 x double]], section ".chaser_data.A", align 64, !dbg !21
@B = external dso_local global [240 x [220 x double]], section ".chaser_data.B", align 64, !dbg !26
@alpha = external dso_local global double, align 8, !dbg !30
@beta = external dso_local global double, align 8, !dbg !32
@.str = hidden unnamed_addr constant [12 x i8] c"ape.analyze\00", section "llvm.metadata"
@.str.1 = hidden unnamed_addr constant [104 x i8] c"/workspace/experiments/chaser/.cache/periodic-polybench/locality-medium-20260929/gemm/source/workload.c\00", section "llvm.metadata"
@.str.2 = hidden unnamed_addr constant [23 x i8] c"==BEGIN DUMP_ARRAYS==\0A\00", align 1
@.str.3 = hidden unnamed_addr constant [15 x i8] c"begin dump: %s\00", align 1
@.str.4 = hidden unnamed_addr constant [2 x i8] c"C\00", align 1
@.str.5 = hidden unnamed_addr constant [2 x i8] c"\0A\00", align 1
@.str.6 = hidden unnamed_addr constant [8 x i8] c"%0.2lf \00", align 1
@.str.7 = hidden unnamed_addr constant [17 x i8] c"\0Aend   dump: %s\0A\00", align 1
@.str.8 = hidden unnamed_addr constant [23 x i8] c"==END   DUMP_ARRAYS==\0A\00", align 1
@llvm.global.annotations = appending global [1 x { i8*, i8*, i8*, i32, i8* }] [{ i8*, i8*, i8*, i32, i8* } { i8* bitcast (i32 ()* @task_job_polybench to i8*), i8* getelementptr inbounds ([12 x i8], [12 x i8]* @.str, i32 0, i32 0), i8* getelementptr inbounds ([104 x i8], [104 x i8]* @.str.1, i32 0, i32 0), i32 132, i8* null }], section "llvm.metadata"

; Function Attrs: noinline nounwind uwtable
define dso_local i32 @task_job_polybench() #0 !dbg !42 {
  %1 = load i32, i32* @ni, align 4, !dbg !50
  %2 = load i32, i32* @nj, align 4, !dbg !51
  %3 = load i32, i32* @nk, align 4, !dbg !52
  %4 = load double, double* @alpha, align 8, !dbg !53
  %5 = load double, double* @beta, align 8, !dbg !54
  call void @llvm.dbg.value(metadata i32 %1, metadata !55, metadata !DIExpression()), !dbg !65
  call void @llvm.dbg.value(metadata i32 %2, metadata !67, metadata !DIExpression()), !dbg !65
  call void @llvm.dbg.value(metadata i32 %3, metadata !68, metadata !DIExpression()), !dbg !65
  call void @llvm.dbg.value(metadata double %4, metadata !69, metadata !DIExpression()), !dbg !65
  call void @llvm.dbg.value(metadata double %5, metadata !70, metadata !DIExpression()), !dbg !65
  call void @llvm.dbg.value(metadata [220 x double]* getelementptr inbounds ([200 x [220 x double]], [200 x [220 x double]]* @C, i64 0, i64 0), metadata !71, metadata !DIExpression()), !dbg !65
  call void @llvm.dbg.value(metadata [240 x double]* getelementptr inbounds ([200 x [240 x double]], [200 x [240 x double]]* @A, i64 0, i64 0), metadata !72, metadata !DIExpression()), !dbg !65
  call void @llvm.dbg.value(metadata [220 x double]* getelementptr inbounds ([240 x [220 x double]], [240 x [220 x double]]* @B, i64 0, i64 0), metadata !73, metadata !DIExpression()), !dbg !65
  call void @llvm.dbg.value(metadata i32 0, metadata !74, metadata !DIExpression()), !dbg !65
  br label %6, !dbg !75

6:                                                ; preds = %47, %0
  %.02 = phi i32 [ 0, %0 ], [ %48, %47 ], !dbg !77
  call void @llvm.dbg.value(metadata i32 %.02, metadata !74, metadata !DIExpression()), !dbg !65
  %7 = icmp slt i32 %.02, 200, !dbg !78
  br i1 %7, label %8, label %49, !dbg !80

8:                                                ; preds = %6
  call void @llvm.dbg.value(metadata i32 0, metadata !81, metadata !DIExpression()), !dbg !65
  br label %9, !dbg !82

9:                                                ; preds = %11, %8
  %.01 = phi i32 [ 0, %8 ], [ %18, %11 ], !dbg !85
  call void @llvm.dbg.value(metadata i32 %.01, metadata !81, metadata !DIExpression()), !dbg !65
  %10 = icmp slt i32 %.01, 220, !dbg !86
  br i1 %10, label %11, label %19, !dbg !88

11:                                               ; preds = %9
  %12 = sext i32 %.02 to i64, !dbg !89
  %13 = getelementptr inbounds [220 x double], [220 x double]* getelementptr inbounds ([200 x [220 x double]], [200 x [220 x double]]* @C, i64 0, i64 0), i64 %12, !dbg !89
  %14 = sext i32 %.01 to i64, !dbg !89
  %15 = getelementptr inbounds [220 x double], [220 x double]* %13, i64 0, i64 %14, !dbg !89
  %16 = load double, double* %15, align 8, !dbg !90
  %17 = fmul double %16, %5, !dbg !90
  store double %17, double* %15, align 8, !dbg !90
  %18 = add nsw i32 %.01, 1, !dbg !91
  call void @llvm.dbg.value(metadata i32 %18, metadata !81, metadata !DIExpression()), !dbg !65
  br label %9, !dbg !92, !llvm.loop !93

19:                                               ; preds = %9
  call void @llvm.dbg.value(metadata i32 0, metadata !96, metadata !DIExpression()), !dbg !65
  br label %20, !dbg !97

20:                                               ; preds = %45, %19
  %.0 = phi i32 [ 0, %19 ], [ %46, %45 ], !dbg !99
  call void @llvm.dbg.value(metadata i32 %.0, metadata !96, metadata !DIExpression()), !dbg !65
  %21 = icmp slt i32 %.0, 240, !dbg !100
  br i1 %21, label %22, label %47, !dbg !102

22:                                               ; preds = %20
  call void @llvm.dbg.value(metadata i32 0, metadata !81, metadata !DIExpression()), !dbg !65
  br label %23, !dbg !103

23:                                               ; preds = %25, %22
  %.1 = phi i32 [ 0, %22 ], [ %44, %25 ], !dbg !106
  call void @llvm.dbg.value(metadata i32 %.1, metadata !81, metadata !DIExpression()), !dbg !65
  %24 = icmp slt i32 %.1, 220, !dbg !107
  br i1 %24, label %25, label %45, !dbg !109

25:                                               ; preds = %23
  %26 = sext i32 %.02 to i64, !dbg !110
  %27 = getelementptr inbounds [240 x double], [240 x double]* getelementptr inbounds ([200 x [240 x double]], [200 x [240 x double]]* @A, i64 0, i64 0), i64 %26, !dbg !110
  %28 = sext i32 %.0 to i64, !dbg !110
  %29 = getelementptr inbounds [240 x double], [240 x double]* %27, i64 0, i64 %28, !dbg !110
  %30 = load double, double* %29, align 8, !dbg !110
  %31 = fmul double %4, %30, !dbg !111
  %32 = sext i32 %.0 to i64, !dbg !112
  %33 = getelementptr inbounds [220 x double], [220 x double]* getelementptr inbounds ([240 x [220 x double]], [240 x [220 x double]]* @B, i64 0, i64 0), i64 %32, !dbg !112
  %34 = sext i32 %.1 to i64, !dbg !112
  %35 = getelementptr inbounds [220 x double], [220 x double]* %33, i64 0, i64 %34, !dbg !112
  %36 = load double, double* %35, align 8, !dbg !112
  %37 = fmul double %31, %36, !dbg !113
  %38 = sext i32 %.02 to i64, !dbg !114
  %39 = getelementptr inbounds [220 x double], [220 x double]* getelementptr inbounds ([200 x [220 x double]], [200 x [220 x double]]* @C, i64 0, i64 0), i64 %38, !dbg !114
  %40 = sext i32 %.1 to i64, !dbg !114
  %41 = getelementptr inbounds [220 x double], [220 x double]* %39, i64 0, i64 %40, !dbg !114
  %42 = load double, double* %41, align 8, !dbg !115
  %43 = fadd double %42, %37, !dbg !115
  store double %43, double* %41, align 8, !dbg !115
  %44 = add nsw i32 %.1, 1, !dbg !116
  call void @llvm.dbg.value(metadata i32 %44, metadata !81, metadata !DIExpression()), !dbg !65
  br label %23, !dbg !117, !llvm.loop !118

45:                                               ; preds = %23
  %46 = add nsw i32 %.0, 1, !dbg !120
  call void @llvm.dbg.value(metadata i32 %46, metadata !96, metadata !DIExpression()), !dbg !65
  br label %20, !dbg !121, !llvm.loop !122

47:                                               ; preds = %20
  %48 = add nsw i32 %.02, 1, !dbg !124
  call void @llvm.dbg.value(metadata i32 %48, metadata !74, metadata !DIExpression()), !dbg !65
  br label %6, !dbg !125, !llvm.loop !126

49:                                               ; preds = %6
  ret i32 0, !dbg !128
}

; Function Attrs: nofree nosync nounwind readnone speculatable willreturn
declare void @llvm.dbg.value(metadata, metadata, metadata) #1

attributes #0 = { noinline nounwind uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { nofree nosync nounwind readnone speculatable willreturn }

!llvm.dbg.cu = !{!2}
!llvm.module.flags = !{!34, !35, !36, !37, !38, !39, !40}
!llvm.ident = !{!41}

!0 = !DIGlobalVariableExpression(var: !1, expr: !DIExpression())
!1 = distinct !DIGlobalVariable(name: "ni", scope: !2, file: !11, line: 114, type: !12, isLocal: false, isDefinition: true)
!2 = distinct !DICompileUnit(language: DW_LANG_C99, file: !3, producer: "Ubuntu clang version 14.0.0-1ubuntu1.1", isOptimized: false, runtimeVersion: 0, emissionKind: FullDebug, retainedTypes: !4, globals: !8, splitDebugInlining: false, nameTableKind: None)
!3 = !DIFile(filename: "/workspace/experiments/chaser/.cache/periodic-polybench/locality-medium-20260929/gemm/source/workload.c", directory: "/workspace/experiments/chaser/.cache/periodic-polybench/locality-medium-20260929/gemm/native-analysis", checksumkind: CSK_MD5, checksum: "f13046e26f531cae43d5f92b60ce0909")
!4 = !{!5, !6, !7}
!5 = !DIBasicType(name: "double", size: 64, encoding: DW_ATE_float)
!6 = !DIBasicType(name: "unsigned int", size: 32, encoding: DW_ATE_unsigned)
!7 = !DIBasicType(name: "unsigned char", size: 8, encoding: DW_ATE_unsigned_char)
!8 = !{!0, !9, !13, !15, !21, !26, !30, !32}
!9 = !DIGlobalVariableExpression(var: !10, expr: !DIExpression())
!10 = distinct !DIGlobalVariable(name: "nj", scope: !2, file: !11, line: 115, type: !12, isLocal: false, isDefinition: true)
!11 = !DIFile(filename: "source/workload.c", directory: "/workspace/experiments/chaser/.cache/periodic-polybench/locality-medium-20260929/gemm", checksumkind: CSK_MD5, checksum: "f13046e26f531cae43d5f92b60ce0909")
!12 = !DIBasicType(name: "int", size: 32, encoding: DW_ATE_signed)
!13 = !DIGlobalVariableExpression(var: !14, expr: !DIExpression())
!14 = distinct !DIGlobalVariable(name: "nk", scope: !2, file: !11, line: 116, type: !12, isLocal: false, isDefinition: true)
!15 = !DIGlobalVariableExpression(var: !16, expr: !DIExpression())
!16 = distinct !DIGlobalVariable(name: "C", scope: !2, file: !11, line: 33, type: !17, isLocal: false, isDefinition: true, align: 512)
!17 = !DICompositeType(tag: DW_TAG_array_type, baseType: !5, size: 2816000, elements: !18)
!18 = !{!19, !20}
!19 = !DISubrange(count: 200)
!20 = !DISubrange(count: 220)
!21 = !DIGlobalVariableExpression(var: !22, expr: !DIExpression())
!22 = distinct !DIGlobalVariable(name: "A", scope: !2, file: !11, line: 34, type: !23, isLocal: false, isDefinition: true, align: 512)
!23 = !DICompositeType(tag: DW_TAG_array_type, baseType: !5, size: 3072000, elements: !24)
!24 = !{!19, !25}
!25 = !DISubrange(count: 240)
!26 = !DIGlobalVariableExpression(var: !27, expr: !DIExpression())
!27 = distinct !DIGlobalVariable(name: "B", scope: !2, file: !11, line: 35, type: !28, isLocal: false, isDefinition: true, align: 512)
!28 = !DICompositeType(tag: DW_TAG_array_type, baseType: !5, size: 3379200, elements: !29)
!29 = !{!25, !20}
!30 = !DIGlobalVariableExpression(var: !31, expr: !DIExpression())
!31 = distinct !DIGlobalVariable(name: "alpha", scope: !2, file: !11, line: 119, type: !5, isLocal: false, isDefinition: true)
!32 = !DIGlobalVariableExpression(var: !33, expr: !DIExpression())
!33 = distinct !DIGlobalVariable(name: "beta", scope: !2, file: !11, line: 120, type: !5, isLocal: false, isDefinition: true)
!34 = !{i32 7, !"Dwarf Version", i32 5}
!35 = !{i32 2, !"Debug Info Version", i32 3}
!36 = !{i32 1, !"wchar_size", i32 4}
!37 = !{i32 7, !"PIC Level", i32 2}
!38 = !{i32 7, !"PIE Level", i32 2}
!39 = !{i32 7, !"uwtable", i32 1}
!40 = !{i32 7, !"frame-pointer", i32 2}
!41 = !{!"Ubuntu clang version 14.0.0-1ubuntu1.1"}
!42 = distinct !DISubprogram(name: "task_job_polybench", scope: !11, file: !11, line: 132, type: !43, scopeLine: 132, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !2, retainedNodes: !49)
!43 = !DISubroutineType(types: !44)
!44 = !{!45}
!45 = !DIDerivedType(tag: DW_TAG_typedef, name: "uint32_t", file: !46, line: 26, baseType: !47)
!46 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/stdint-uintn.h", directory: "", checksumkind: CSK_MD5, checksum: "2bf2ae53c58c01b1a1b9383b5195125c")
!47 = !DIDerivedType(tag: DW_TAG_typedef, name: "__uint32_t", file: !48, line: 42, baseType: !6)
!48 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/types.h", directory: "", checksumkind: CSK_MD5, checksum: "d108b5f93a74c50510d7d9bc0ab36df9")
!49 = !{}
!50 = !DILocation(line: 133, column: 16, scope: !42)
!51 = !DILocation(line: 133, column: 20, scope: !42)
!52 = !DILocation(line: 133, column: 24, scope: !42)
!53 = !DILocation(line: 134, column: 9, scope: !42)
!54 = !DILocation(line: 134, column: 16, scope: !42)
!55 = !DILocalVariable(name: "ni", arg: 1, scope: !56, file: !11, line: 83, type: !12)
!56 = distinct !DISubprogram(name: "kernel_gemm", scope: !11, file: !11, line: 83, type: !57, scopeLine: 89, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition, unit: !2, retainedNodes: !49)
!57 = !DISubroutineType(types: !58)
!58 = !{null, !12, !12, !12, !5, !5, !59, !62, !59}
!59 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !60, size: 64)
!60 = !DICompositeType(tag: DW_TAG_array_type, baseType: !5, size: 14080, elements: !61)
!61 = !{!20}
!62 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !63, size: 64)
!63 = !DICompositeType(tag: DW_TAG_array_type, baseType: !5, size: 15360, elements: !64)
!64 = !{!25}
!65 = !DILocation(line: 0, scope: !56, inlinedAt: !66)
!66 = distinct !DILocation(line: 133, column: 3, scope: !42)
!67 = !DILocalVariable(name: "nj", arg: 2, scope: !56, file: !11, line: 83, type: !12)
!68 = !DILocalVariable(name: "nk", arg: 3, scope: !56, file: !11, line: 83, type: !12)
!69 = !DILocalVariable(name: "alpha", arg: 4, scope: !56, file: !11, line: 84, type: !5)
!70 = !DILocalVariable(name: "beta", arg: 5, scope: !56, file: !11, line: 85, type: !5)
!71 = !DILocalVariable(name: "C", arg: 6, scope: !56, file: !11, line: 86, type: !59)
!72 = !DILocalVariable(name: "A", arg: 7, scope: !56, file: !11, line: 87, type: !62)
!73 = !DILocalVariable(name: "B", arg: 8, scope: !56, file: !11, line: 88, type: !59)
!74 = !DILocalVariable(name: "i", scope: !56, file: !11, line: 90, type: !12)
!75 = !DILocation(line: 100, column: 8, scope: !76, inlinedAt: !66)
!76 = distinct !DILexicalBlock(scope: !56, file: !11, line: 100, column: 3)
!77 = !DILocation(line: 0, scope: !76, inlinedAt: !66)
!78 = !DILocation(line: 100, column: 17, scope: !79, inlinedAt: !66)
!79 = distinct !DILexicalBlock(scope: !76, file: !11, line: 100, column: 3)
!80 = !DILocation(line: 100, column: 3, scope: !76, inlinedAt: !66)
!81 = !DILocalVariable(name: "j", scope: !56, file: !11, line: 90, type: !12)
!82 = !DILocation(line: 101, column: 10, scope: !83, inlinedAt: !66)
!83 = distinct !DILexicalBlock(scope: !84, file: !11, line: 101, column: 5)
!84 = distinct !DILexicalBlock(scope: !79, file: !11, line: 100, column: 32)
!85 = !DILocation(line: 0, scope: !83, inlinedAt: !66)
!86 = !DILocation(line: 101, column: 19, scope: !87, inlinedAt: !66)
!87 = distinct !DILexicalBlock(scope: !83, file: !11, line: 101, column: 5)
!88 = !DILocation(line: 101, column: 5, scope: !83, inlinedAt: !66)
!89 = !DILocation(line: 102, column: 2, scope: !87, inlinedAt: !66)
!90 = !DILocation(line: 102, column: 10, scope: !87, inlinedAt: !66)
!91 = !DILocation(line: 101, column: 30, scope: !87, inlinedAt: !66)
!92 = !DILocation(line: 101, column: 5, scope: !87, inlinedAt: !66)
!93 = distinct !{!93, !88, !94, !95}
!94 = !DILocation(line: 102, column: 13, scope: !83, inlinedAt: !66)
!95 = !{!"llvm.loop.mustprogress"}
!96 = !DILocalVariable(name: "k", scope: !56, file: !11, line: 90, type: !12)
!97 = !DILocation(line: 103, column: 10, scope: !98, inlinedAt: !66)
!98 = distinct !DILexicalBlock(scope: !84, file: !11, line: 103, column: 5)
!99 = !DILocation(line: 0, scope: !98, inlinedAt: !66)
!100 = !DILocation(line: 103, column: 19, scope: !101, inlinedAt: !66)
!101 = distinct !DILexicalBlock(scope: !98, file: !11, line: 103, column: 5)
!102 = !DILocation(line: 103, column: 5, scope: !98, inlinedAt: !66)
!103 = !DILocation(line: 104, column: 13, scope: !104, inlinedAt: !66)
!104 = distinct !DILexicalBlock(scope: !105, file: !11, line: 104, column: 8)
!105 = distinct !DILexicalBlock(scope: !101, file: !11, line: 103, column: 34)
!106 = !DILocation(line: 0, scope: !104, inlinedAt: !66)
!107 = !DILocation(line: 104, column: 22, scope: !108, inlinedAt: !66)
!108 = distinct !DILexicalBlock(scope: !104, file: !11, line: 104, column: 8)
!109 = !DILocation(line: 104, column: 8, scope: !104, inlinedAt: !66)
!110 = !DILocation(line: 105, column: 23, scope: !108, inlinedAt: !66)
!111 = !DILocation(line: 105, column: 21, scope: !108, inlinedAt: !66)
!112 = !DILocation(line: 105, column: 33, scope: !108, inlinedAt: !66)
!113 = !DILocation(line: 105, column: 31, scope: !108, inlinedAt: !66)
!114 = !DILocation(line: 105, column: 4, scope: !108, inlinedAt: !66)
!115 = !DILocation(line: 105, column: 12, scope: !108, inlinedAt: !66)
!116 = !DILocation(line: 104, column: 33, scope: !108, inlinedAt: !66)
!117 = !DILocation(line: 104, column: 8, scope: !108, inlinedAt: !66)
!118 = distinct !{!118, !109, !119, !95}
!119 = !DILocation(line: 105, column: 39, scope: !104, inlinedAt: !66)
!120 = !DILocation(line: 103, column: 30, scope: !101, inlinedAt: !66)
!121 = !DILocation(line: 103, column: 5, scope: !101, inlinedAt: !66)
!122 = distinct !{!122, !102, !123, !95}
!123 = !DILocation(line: 106, column: 5, scope: !98, inlinedAt: !66)
!124 = !DILocation(line: 100, column: 28, scope: !79, inlinedAt: !66)
!125 = !DILocation(line: 100, column: 3, scope: !79, inlinedAt: !66)
!126 = distinct !{!126, !80, !127, !95}
!127 = !DILocation(line: 107, column: 3, scope: !76, inlinedAt: !66)
!128 = !DILocation(line: 138, column: 3, scope: !42)
