"""Exploratory check after experiments 29 and 30: the request-limited CLS grouping on experiment 24's sets.

Experiment 30 found the CLS grouping's cores overloaded in effective terms (memory tasks run longer
than planned) and, at period CV 0.2, the release-aware search moving other tasks onto them; experiment
29 found a single isolated core better when the group fits on it. placement_lib's cgk sizes the group
cores by CORE_CAP / request_inflation and keeps the others off them; ra-cgk keeps that during the
release-aware search. Same tasks, sets and seeds as loadmem_set; P runs on cgk and ra-cgk, to pair
with experiment 24's results; wfd is built (not run) for hl_run's isolated gate and pm_run's yarda pass.
Exploratory: experiment 24's results were read before this design.
"""
from loadmem_set import *  # noqa: F401,F403  the base design's constants, sets, seeds and configuration

PLACEMENTS = ('wfd', 'cgk', 'ra-cgk')
