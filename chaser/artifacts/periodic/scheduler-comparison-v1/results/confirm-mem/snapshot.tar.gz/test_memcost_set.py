"""Specification tests for experiment 41's memory-cost design (run from the c3 copy, PYTHONPATH set)."""
from pathlib import Path
import sys

import pytest

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))

import deadline_big_set
import deadline_set
import memcost_set as mc
import period_swap_set

L2, MEM = mc.HEAVINESS


def config(load, heaviness, set_id, placement='wfd'):
    return mc.configuration(load, heaviness, set_id, placement)


def test_grid_is_the_pre_registered_one():
    assert mc.LOADS == (0.45, 0.5, 0.55, 0.6) and mc.SETS == 24 and mc.SEED_BASE == 20264101
    assert mc.HEAVINESS == ('l2-low25', 'mem-low25') and mc.PLACEMENTS == ('wfd', 'cgb') and mc.MAX_MEMORY == 4


def test_seeds_are_fresh():
    mine = set(range(mc.SEED_BASE, mc.SEED_BASE + mc.SETS))
    for other in (deadline_set, deadline_big_set, period_swap_set):
        assert not mine & set(range(other.SEED_BASE, other.SEED_BASE + other.SETS))


@pytest.mark.parametrize('load', mc.LOADS)
def test_cells_share_tasks_periods_targets_and_cores_and_differ_only_in_the_memory_shape(load):
    for set_id in range(mc.SETS):
        for placement in mc.PLACEMENTS:
            a, b = config(load, L2, set_id, placement)['tasks'], config(load, MEM, set_id, placement)['tasks']
            for key in ('role', 'period_ticks', 'u_target', 'core'):
                assert [t[key] for t in a] == [t[key] for t in b]
        memory = [i for i, t in enumerate(a) if t['role'] == mc.MEMORY_ROLE]
        assert 1 <= len(memory) <= mc.MAX_MEMORY
        assert all(a[i]['stride'] == 32 and b[i]['stride'] == mc.MEM_STRIDE for i in memory)
        others = [i for i in range(len(a)) if i not in memory]
        assert all(a[i] == dict(b[i]) for i in others)


@pytest.mark.parametrize('load', mc.LOADS)
def test_memory_tasks_match_cls_and_u_while_the_mem_shape_issues_fewer_l1_misses(load):
    for set_id in range(mc.SETS):
        a, b = config(load, L2, set_id)['tasks'], config(load, MEM, set_id)['tasks']
        for x, y in zip(a, b):
            if x['role'] != mc.MEMORY_ROLE:
                continue
            assert abs(x['cls_planned'] - y['cls_planned']) <= 0.005
            assert y['cls_planned'] == pytest.approx(mc.mem_cls(y['hot_distinct'], y['hot_repeats'], y['distinct'] - y['hot_distinct']))
            assert abs(x['u_planned'] - y['u_planned']) / x['u_target'] <= 0.03
            assert y['traffic_planned'] < x['traffic_planned']


def test_workload_data_stays_under_the_16_mib_limit_and_budgets_in_the_model_ranges():
    for set_id in range(mc.SETS):
        for load in mc.LOADS:
            tasks = config(load, MEM, set_id)['tasks']
            assert sum(-(-int(t['data_kib'] * 1024) // 4096) * 4096 for t in tasks) <= mc.DATA_LIMIT
            for t in tasks:
                budget = t['u_target'] * t['period_ticks'] * 1e6
                low, high = mc.MODEL_CHECK_NS['mem' if t['shape'] == 'mem' else t['role']]
                assert low <= budget <= high
