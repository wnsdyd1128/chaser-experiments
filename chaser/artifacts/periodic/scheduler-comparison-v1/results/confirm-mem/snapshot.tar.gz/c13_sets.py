"""C1+3 runs on earlier designs' sets, for the RF configuration recommender (experiment 33, development data).

Experiments 17-28 ran G and C1+1+2 but not C1+3, which the recommender must score. Each design here
is a base design (same tasks, sets, seeds and wfd build) whose only run is C1+3 on the wfd build
(hl_run's 'c' architecture: core 0's tasks in a one-core domain, cores 1-3's in a three-core domain,
as C1+1+2 used the wfd build). The tasks are identical to the base runs', which passed the isolated gate.
"""
from types import SimpleNamespace

import clsspread_set
import deadline_big_set
import deadline_set
import loadmem_set
import taskcount_set


def _wfd_only(base):
    names = {k: getattr(base, k) for k in dir(base) if not k.startswith('__')}
    return SimpleNamespace(**dict(names, PLACEMENTS=('wfd',)))


loadmem_c13 = _wfd_only(loadmem_set)
taskcount_c13 = _wfd_only(taskcount_set)
clsspread_c13 = _wfd_only(clsspread_set)
deadline_c13 = _wfd_only(deadline_set)
deadline_big_c13 = _wfd_only(deadline_big_set)
DESIGNS = {'small-memory-load-c13': loadmem_c13, 'task-count-c13': taskcount_c13, 'cls-spread-c13': clsspread_c13,
           'deadline-small-c13': deadline_c13, 'deadline-big-c13': deadline_big_c13}
