"""Specification tests for the exploratory request-limited grouping runs on experiments 24 and 20 (run from the c3 copy)."""
from pathlib import Path
import sys

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))

import loadmem_k_set
import loadmem_set
import taskcount_k_set
import taskcount_set


def strip(tasks):
    return [{k: v for k, v in t.items() if k != 'core'} for t in tasks]


def test_designs_reuse_the_base_sets_and_add_the_request_limited_placements():
    assert loadmem_k_set.HEAVINESS == loadmem_set.HEAVINESS and loadmem_k_set.SEED_BASE == loadmem_set.SEED_BASE
    assert taskcount_k_set.HEAVINESS == ('mem25',) and taskcount_k_set.SEED_BASE == taskcount_set.SEED_BASE
    assert loadmem_k_set.PLACEMENTS == taskcount_k_set.PLACEMENTS == ('wfd', 'cgk', 'ra-cgk')


def test_new_placements_change_only_the_cores():
    for mod, base, cell, load in ((loadmem_k_set, loadmem_set, 'cv20-low50', 0.5), (taskcount_k_set, taskcount_set, 'mem25', 0.45)):
        reference = strip(base.configuration(load, cell, 4, 'wfd')['tasks'])
        for p in ('cgk', 'ra-cgk'):
            assert strip(mod.configuration(load, cell, 4, p)['tasks']) == reference
