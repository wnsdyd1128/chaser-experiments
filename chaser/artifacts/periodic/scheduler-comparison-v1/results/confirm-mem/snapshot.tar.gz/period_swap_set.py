"""Experiment 38 (pre-registered): memory tasks holding the shortest or the longest periods, all else equal.

Each set draws one period multiset, MU x exp(PERIOD_SPREAD z) rounded to PERIOD_MENU (lcm 240 ms), and
the same tasks (U shares, CLS draws, memory tasks) as experiment 27's 32 KiB design rules on fresh seeds.
The two cells ('heaviness' in hl_run) differ only in which tasks get which periods: in memshort the
memory-bound low-CLS tasks take the k shortest periods of the multiset, in memlong the k longest
(k = number of memory tasks); within each group the assignment order is fixed per set. Budgets are the
task's target U x its period, so every task keeps its target U; placements use the target U (wfd, cgb
read neither periods nor budgets), so both cells place every task on the same core. Memory tasks are a
prefix, in set order, of the tasks whose budget stays inside the low-as-is model check at every load
and any menu period, ending where their U share comes nearest MEMORY_SHARE. Warm-up 1 hyperperiod,
measured 3. hl_run labels 0.49, 0.51, 0.53, 0.55 as u049, u051, u053, u055.
"""

from functools import cache
import math
import random
import statistics
from pathlib import Path
import sys

import numpy as np

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
sys.path.insert(0, str(HERE.parent / 'high-load'))
sys.path.insert(0, str(HERE.parent / 'cls-bimodal'))

import bimodal
import deadline_set
from hl_set import CONTRACT
import mem_set
import mix_set
from placement_lib import CORE_CAP, CORES, Item, place

STUDY = 'period-swap'
TASK_RANGE = deadline_set.TASK_RANGE
TASKS = TASK_RANGE
MU = 40
PERIOD_SPREAD = 0.4
PERIOD_MENU = (20, 24, 30, 40, 48, 60, 80)
PERIODS = PERIOD_MENU
HYPERPERIOD = 240
WARMUP_HYPERPERIODS, MEASURED_HYPERPERIODS = 1, 3
MEMORY_ROLE, MEMORY_SHARE = 'low', 0.5
ARMS = ('memshort', 'memlong')
HEAVINESS = tuple(f'{arm}-low{round(MEMORY_SHARE * 100):02d}' for arm in ARMS)
LOADS = (0.49, 0.51, 0.53, 0.55)
SETS = 24
SEED_BASE = 20263801
ALPHA = 8.0
LIGHT_CAP = 0.35
U_MIN = 0.0125
HEAVY, HEAVY_RANGE = 0, None
TRENDS = True
OPTIMIZATION = 'O2'
PLACEMENTS = ('wfd', 'cgb')
MODEL_CHECK_NS = deadline_set.MODEL_CHECK_NS


def arm(heaviness: str) -> str:
    return heaviness.split('-')[0]


@cache
def _counts() -> tuple[int, ...]:
    values = list(range(TASK_RANGE[0], TASK_RANGE[1] + 1))
    column = [values[i % len(values)] for i in range(SETS)]
    random.Random(f'{SEED_BASE}-tasks').shuffle(column)
    return tuple(column)


def task_count(set_id: int) -> int:
    return _counts()[set_id]


@cache
def _draws(set_id: int):
    n = task_count(set_id)
    rng = np.random.default_rng([SEED_BASE, set_id])
    order = rng.permutation(n).tolist()
    z_cls, z_period = deadline_set.truncated_normals(rng, n), deadline_set.truncated_normals(rng, n)
    slots = rng.permutation(n).tolist()  # fixed order of assignment within the memory and the other group
    while True:
        w = rng.dirichlet(np.full(n, ALPHA))
        if w.max() * max(LOADS) * CORES <= LIGHT_CAP and w.min() * min(LOADS) * CORES >= U_MIN:
            return order, z_cls, z_period, slots, [float(x) for x in w]


def menu_period(raw: float) -> int:
    return min(PERIOD_MENU, key=lambda p: (abs(math.log(p / raw)), p))


@cache
def period_multiset(set_id: int) -> tuple[int, ...]:
    return tuple(sorted(menu_period(MU * math.exp(PERIOD_SPREAD * z)) for z in _draws(set_id)[2]))


@cache
def memory_tasks(set_id: int) -> tuple[int, ...]:
    """A prefix of the eligible tasks in set order, ending nearest MEMORY_SHARE of the U."""
    order, _, _, _, shares = _draws(set_id)
    low, high = MODEL_CHECK_NS[MEMORY_ROLE]
    chosen, held = [], 0.0
    for i in order:
        if not (low <= shares[i] * min(LOADS) * CORES * min(PERIOD_MENU) * 1e6
                and shares[i] * max(LOADS) * CORES * max(PERIOD_MENU) * 1e6 <= high):
            continue
        if held + shares[i] / 2 > MEMORY_SHARE:
            break
        chosen.append(i)
        held += shares[i]
    return tuple(chosen)


def roles(set_id: int) -> list[str]:
    memory = set(memory_tasks(set_id))
    return [MEMORY_ROLE if i in memory else 'high' for i in range(task_count(set_id))]


def periods(heaviness: str, set_id: int) -> list[int]:
    multiset, memory = period_multiset(set_id), set(memory_tasks(set_id))
    slots = _draws(set_id)[3]
    k, n = len(memory), len(multiset)
    memory_periods, other_periods = (multiset[:k], multiset[k:]) if arm(heaviness) == 'memshort' else \
        (multiset[n - k:], multiset[:n - k])
    out = [0] * n
    for group, values in ((sorted(memory, key=slots.index), memory_periods),
                          (sorted(set(range(n)) - memory, key=slots.index), other_periods)):
        for i, p in zip(group, values):
            out[i] = p
    return out


def target_u(load: float, set_id: int) -> list[float]:
    return [w * load * CORES for w in _draws(set_id)[4]]


def configuration(load: float, heaviness: str, set_id: int, placement: str) -> dict:
    task_periods, task_roles = periods(heaviness, set_id), roles(set_id)
    targets, z = target_u(load, set_id), _draws(set_id)[1]
    step = mix_set.BUDGET_STEP_NS
    task_budgets = [max(step, round(u * p * 1e6 / step) * step) for u, p in zip(targets, task_periods)]
    levels = [dict(bimodal.level(mem_set.tables(budget), role, 'as-is', mix_set.cls_target(role, value)),
                   cold=bimodal.COLD_LINES) for role, budget, value in zip(task_roles, task_budgets, z)]
    job = [b * (1 + lv['u_error']) for b, lv in zip(task_budgets, levels)]
    us = [j / (p * 1e6) for j, p in zip(job, task_periods)]
    misses = [lv['sweeps'] * (lv['hot'] + lv['cold']) for lv in levels]
    traffic = [m / (j / 1e3) for m, j in zip(misses, job)]
    cores = place(placement, [Item(u=u, period=p, traffic=r, cls=lv['cls'])
                              for u, p, r, lv in zip(targets, task_periods, traffic, levels)], seed=SEED_BASE + set_id)
    tasks = []
    for i, (role, lv) in enumerate(zip(task_roles, levels)):
        task = dict(task_id=f't{i:02d}', pattern='hot-cold', distinct=lv['hot'] + lv['cold'],
                    hot_distinct=lv['hot'], hot_repeats=lv['repeats'], cold_repeats=1, stride=bimodal.STRIDE,
                    sweeps=lv['sweeps'], core=cores[i], period_ticks=task_periods[i], role=role, mode=role,
                    cls_target=mix_set.cls_target(role, z[i]), cls_planned=lv['cls'], u_target=targets[i],
                    u_planned=us[i], l1_misses_planned=misses[i], traffic_planned=traffic[i],
                    footprint_kib=(lv['hot'] + lv['cold']) * bimodal.STRIDE / 1024)
        if lv['pad']:
            task['pad_rounds'] = lv['pad']
        if lv['tail']:
            task['pad_tail'] = lv['tail']
        tasks.append(task)
    memory_u = sum(u for u, r in zip(us, task_roles) if r == MEMORY_ROLE)
    return dict(workload_id=f'{STUDY}-u{round(load * 1000):04d}-{heaviness}-s{set_id:02d}-{placement}-v1',
                family_id=f'{STUDY}-hot-cold-v1', policy_id=f'{STUDY}-{placement}-v1',
                measurement_contract_id=CONTRACT, array_alignment_bytes=32, workload_optimization=OPTIMIZATION,
                horizon_ticks=(WARMUP_HYPERPERIODS + MEASURED_HYPERPERIODS) * HYPERPERIOD,
                warmup_ticks=WARMUP_HYPERPERIODS * HYPERPERIOD, u_repeats=1, diagnostic_only=True, tasks=tasks,
                high_load=dict(load=load, heaviness=heaviness, arm=arm(heaviness), set_id=set_id, seed=SEED_BASE + set_id,
                               placement=placement, total_u=sum(us),
                               core_u=[sum(u for u, k in zip(us, cores) if k == core) for core in range(CORES)],
                               core_cap=CORE_CAP, tasks=len(tasks), memory_share=memory_u / sum(us),
                               realized_period_cv=statistics.pstdev(task_periods) / statistics.mean(task_periods)))


def protocol_extra() -> dict:
    return dict(arms=ARMS, period_menu=PERIOD_MENU, mu=MU, period_spread=PERIOD_SPREAD, seed_base=SEED_BASE,
                task_counts=[task_count(k) for k in range(SETS)], model_check_ns=MODEL_CHECK_NS,
                memory_role=MEMORY_ROLE, memory_tasks={f'{k}': memory_tasks(k) for k in range(SETS)},
                period_multisets={f'{k}': period_multiset(k) for k in range(SETS)})
