"""Specification tests for experiment 38's pre-registered analysis (synthetic data)."""
from pathlib import Path
import sys

import pytest

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))

import period_swap_analysis as pa

SHORT, LONG = 'memshort-low50', 'memlong-low50'


def row(h, load, k, wfd, cgb):
    return dict(heaviness=h, load=load, set_id=k, p=dict(state=wfd), p_cgb=dict(state=cgb))


def test_pairs_join_the_two_arms_by_load_and_set_and_drop_failed_runs():
    rows = [row(SHORT, 0.49, 0, 'ok', 'ok'), row(LONG, 0.49, 0, 'deadline', 'ok'),
            row(SHORT, 0.49, 1, 'startup', 'ok'), row(LONG, 0.49, 1, 'ok', 'deadline')]
    assert pa.paired(rows, 'p') == [dict(load=0.49, set_id=0, short=True, long=False)]
    assert len(pa.paired(rows, 'p_cgb')) == 2


def test_exact_mcnemar_counts_the_discordant_pairs_both_ways():
    pairs = [dict(short=True, long=False)] * 5 + [dict(short=False, long=True)] + [dict(short=True, long=True)] * 3 \
        + [dict(short=False, long=False)] * 2
    m = pa.mcnemar(pairs)
    assert (m['pairs'], m['only_short_met'], m['only_long_met'], m['both_met'], m['neither_met']) == (11, 5, 1, 3, 2)
    assert m['p'] == pytest.approx(0.21875)
    assert pa.mcnemar([dict(short=True, long=True)])['p'] == 1.0


def test_sign_test_compares_late_jobs_per_pair():
    pairs = [dict(short=0, long=3)] * 6 + [dict(short=2, long=1)] + [dict(short=4, long=4)] * 2
    s = pa.sign_test(pairs)
    assert (s['fewer_in_short'], s['fewer_in_long'], s['ties']) == (6, 1, 2)
    assert s['p'] == pytest.approx(0.125) and s['late_short'] == 10 and s['late_long'] == 27


def test_primary_tests_are_holm_corrected_over_the_two_placements():
    tests = pa.primary({'wfd': dict(p=0.01), 'cgb': dict(p=0.04)})
    assert tests['wfd']['holm_p'] == pytest.approx(0.02) and tests['wfd']['significant']
    assert tests['cgb']['holm_p'] == pytest.approx(0.04) and tests['cgb']['significant']
    assert not pa.primary({'wfd': dict(p=0.03), 'cgb': dict(p=0.2)})['wfd']['significant']
