"""Exploratory check after experiments 29 and 30: the request-limited CLS grouping on experiment 20's 25 % cell.

As loadmem_k_set, on experiment 20's sets where 768 KiB tasks hold 25 % of U (periods 20/40/80 ms, the
cell where the CLS placements met more deadlines; the 50 % cell failed under every configuration).
P runs on cgk and ra-cgk, to pair with experiment 20's results. Exploratory.
"""
from taskcount_set import *  # noqa: F401,F403  the base design's constants, sets, seeds and configuration

HEAVINESS = ('mem25',)
PLACEMENTS = ('wfd', 'cgk', 'ra-cgk')
