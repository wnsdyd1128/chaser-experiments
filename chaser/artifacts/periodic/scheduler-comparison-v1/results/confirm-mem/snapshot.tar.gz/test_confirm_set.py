"""Specification tests for experiment 44's confirmatory designs (run from the c3 copy, PYTHONPATH set)."""
from pathlib import Path
import sys

import pytest

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))

import confirm_set as cs
import deadline_big_set
import deadline_set
import memcost_set
import period_swap_set

DESIGNS = list(cs.DESIGNS.values())
EARLIER = (deadline_set, deadline_big_set, memcost_set, period_swap_set)


def seeds(d):
    return set(range(d.SEED_BASE, d.SEED_BASE + d.SETS))


def test_grids_are_the_pre_registered_ones():
    assert cs.DESIGNS['confirm-small'].LOADS == (0.45, 0.4875, 0.525, 0.5625, 0.6)
    assert cs.DESIGNS['confirm-big'].LOADS == (0.30, 0.3375, 0.375, 0.4125, 0.45)
    assert cs.DESIGNS['confirm-mem'].LOADS == (0.45, 0.4875, 0.525, 0.5625, 0.6)
    assert all(d.SETS == 24 and d.PLACEMENTS == ('wfd', 'ra-cgb') and len(d.HEAVINESS) == 1 for d in DESIGNS)


def test_seeds_are_fresh_and_disjoint():
    for i, d in enumerate(DESIGNS):
        for other in DESIGNS[i + 1:]:
            assert not seeds(d) & seeds(other)
        for module in EARLIER:
            assert not seeds(d) & set(range(module.SEED_BASE, module.SEED_BASE + module.SETS))


def test_case_labels_are_distinct_across_loads():
    for d in DESIGNS:
        assert len({round(load * 100) for load in d.LOADS}) == len(d.LOADS)


@pytest.mark.parametrize('name', list(cs.DESIGNS))
def test_every_set_has_memory_tasks_of_its_type_near_the_share(name):
    d = cs.DESIGNS[name]
    for k in range(d.SETS):
        config = d.configuration(d.LOADS[2], d.HEAVINESS[0], k, 'wfd')
        roles = {t['role'] for t in config['tasks']}
        assert roles == {'high', d.role}
        assert abs(config['high_load']['memory_share'] - d.share) <= 0.12
        if d.max_memory:
            assert sum(t['role'] != 'high' for t in config['tasks']) <= d.max_memory


@pytest.mark.parametrize('name', list(cs.DESIGNS))
def test_budgets_stay_inside_the_model_checks_and_data_under_16_mib(name):
    d = cs.DESIGNS[name]
    for k in range(d.SETS):
        for load in d.LOADS:
            config = d.configuration(load, d.HEAVINESS[0], k, 'ra-cgb')
            for t in config['tasks']:
                shape = 'mem' if t['stride'] == 4096 else t['role']
                low, high = d.MODEL_CHECK_NS[shape]
                assert low <= t['u_target'] * t['period_ticks'] * 1e6 <= high
            assert sum((t['data_kib'] * 1024 + 4095) // 4096 * 4096 for t in config['tasks']) <= 16 * 1024 ** 2
            assert max(config['high_load']['core_u']) <= cs.CORE_CAP


def test_memory_shape_matches_the_l2_shape_cls_and_misses_memory():
    d = cs.DESIGNS['confirm-mem']
    mem = [t for t in d.configuration(0.525, d.HEAVINESS[0], 0, 'wfd')['tasks'] if t['role'] == 'low']
    assert mem and all(t['stride'] == 4096 and t['distinct'] - t['hot_distinct'] >= 640 for t in mem)
    assert all(t['cls_planned'] < 0.2 for t in mem)


def test_measured_window_is_three_hyperperiods_after_one_of_warm_up():
    config = DESIGNS[0].configuration(0.45, DESIGNS[0].HEAVINESS[0], 0, 'wfd')
    assert config['warmup_ticks'] == 240 and config['horizon_ticks'] == 960
