"""Specification tests for the exploratory CLS + Algorithm 1 run on experiment 24's sets (run from the c3 copy)."""
from pathlib import Path
import sys

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))

import loadmem_a1_set as a1set
import loadmem_set


def strip(tasks):
    return [{k: v for k, v in t.items() if k != 'core'} for t in tasks]


def test_covers_every_cell_and_load_of_experiment_24_with_wfd_and_cls_a1():
    assert a1set.HEAVINESS == loadmem_set.HEAVINESS and a1set.LOADS == loadmem_set.LOADS
    assert a1set.SEED_BASE == loadmem_set.SEED_BASE and a1set.PLACEMENTS == ('wfd', 'cls-a1')


def test_wfd_build_is_experiment_24s_configuration():
    for cell in loadmem_set.HEAVINESS:
        assert a1set.configuration(0.5, cell, 3, 'wfd') == loadmem_set.configuration(0.5, cell, 3, 'wfd')


def test_cls_a1_isolates_the_low_tasks_on_core_0_when_placeable_and_changes_only_cores():
    for cell in loadmem_set.HEAVINESS:
        for load in loadmem_set.LOADS:
            config = a1set.configuration(load, cell, 6, 'cls-a1')
            assert strip(config['tasks']) == strip(loadmem_set.configuration(load, cell, 6, 'wfd')['tasks'])
            if config['high_load']['placeable']:
                assert all((t['core'] == 0) == (t['role'] == 'low') for t in config['tasks'])


def test_the_25_percent_cells_are_placeable_at_every_load():
    for cell in ('cv00-low25', 'cv20-low25'):
        for load in loadmem_set.LOADS:
            assert all(a1set.configuration(load, cell, k, 'cls-a1')['high_load']['placeable'] for k in range(loadmem_set.SETS))
