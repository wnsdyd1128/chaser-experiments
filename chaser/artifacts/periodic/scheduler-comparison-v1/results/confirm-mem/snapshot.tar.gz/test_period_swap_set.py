"""Specification tests for experiment 38's period-swap design (run from the c3 copy, PYTHONPATH set)."""
from pathlib import Path
import sys

import pytest

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))

import deadline_big_set
import deadline_set
import period_swap_set as ps

SHORT, LONG = ps.HEAVINESS


def tasks(load, heaviness, set_id, placement='wfd'):
    return ps.configuration(load, heaviness, set_id, placement)['tasks']


def test_grid_is_the_pre_registered_one():
    assert ps.LOADS == (0.49, 0.51, 0.53, 0.55) and ps.SETS == 24 and ps.SEED_BASE == 20263801
    assert ps.HEAVINESS == ('memshort-low50', 'memlong-low50') and ps.PLACEMENTS == ('wfd', 'cgb')
    assert ps.PERIOD_MENU == (20, 24, 30, 40, 48, 60, 80) and ps.HYPERPERIOD == 240


def test_seeds_are_fresh():
    mine = set(range(ps.SEED_BASE, ps.SEED_BASE + ps.SETS))
    for other in (deadline_set, deadline_big_set):
        assert not mine & set(range(other.SEED_BASE, other.SEED_BASE + other.SETS))


@pytest.mark.parametrize('set_id', range(ps.SETS))
def test_both_arms_share_the_period_multiset_and_memory_tasks_take_its_short_or_long_end(set_id):
    short, long_ = tasks(0.51, SHORT, set_id), tasks(0.51, LONG, set_id)
    assert sorted(t['period_ticks'] for t in short) == sorted(t['period_ticks'] for t in long_)
    memory = [i for i, t in enumerate(short) if t['role'] == ps.MEMORY_ROLE]
    assert memory == [i for i, t in enumerate(long_) if t['role'] == ps.MEMORY_ROLE]
    periods = sorted(t['period_ticks'] for t in short)
    assert sorted(short[i]['period_ticks'] for i in memory) == periods[:len(memory)]
    assert sorted(long_[i]['period_ticks'] for i in memory) == periods[len(periods) - len(memory):]
    mean = lambda ts: sum(ts[i]['period_ticks'] for i in memory) / len(memory)
    assert mean(short) < mean(long_)


@pytest.mark.parametrize('placement', ps.PLACEMENTS)
@pytest.mark.parametrize('load', ps.LOADS)
def test_core_assignment_is_the_same_in_both_arms(load, placement):
    for set_id in range(ps.SETS):
        assert [t['core'] for t in tasks(load, SHORT, set_id, placement)] == \
            [t['core'] for t in tasks(load, LONG, set_id, placement)]


def test_memory_tasks_hold_about_half_of_the_utilization_and_keep_their_target_u():
    for set_id in range(ps.SETS):
        for h in ps.HEAVINESS:
            config = ps.configuration(0.53, h, set_id, 'wfd')
            assert 0.4 <= config['high_load']['memory_share'] <= 0.6
        assert [t['u_target'] for t in tasks(0.53, SHORT, set_id)] == pytest.approx([t['u_target'] for t in tasks(0.53, LONG, set_id)])


def test_budgets_stay_inside_the_model_check_ranges():
    for set_id in range(ps.SETS):
        for load in ps.LOADS:
            for h in ps.HEAVINESS:
                for t in tasks(load, h, set_id):
                    low, high = ps.MODEL_CHECK_NS[t['role']]
                    assert low <= t['u_target'] * t['period_ticks'] * 1e6 <= high


def test_measured_window_is_three_hyperperiods_after_one_of_warm_up():
    config = ps.configuration(ps.LOADS[0], SHORT, 0, 'wfd')
    assert config['warmup_ticks'] == 240 and config['horizon_ticks'] == 4 * 240
