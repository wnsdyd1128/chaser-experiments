"""Exploratory check after experiment 28: CLS + Algorithm 1 on experiment 24's sets.

Experiment 28 found a single isolated core (CLS + Algorithm 1) as good as the balanced CLS grouping
when the low-affinity tasks held 25 % of U (768 KiB tasks) and far worse at 50 % (32 KiB tasks), so
share and task type were confounded. Experiment 24's 32 KiB cells hold 25 % or 50 % of U on the same
sets (the 25 % tasks are among the 50 % tasks), so on its sets only the share changes. P runs on
algorithm1's cls-a1 and, as a reproducibility check against experiment 24, on wfd. CA-CSRD table
(needed by algorithm1, unused by cls-a1) from ca_table.py over experiment 24's yarda analyses.
Exploratory: experiment 24's results were read before this design.
"""
from loadmem_set import *  # noqa: F401,F403  the base design's constants, sets and seeds
import loadmem_set as _base

import algorithm1

CA_TABLE = HERE.parent / 'results/ca-csrd/small-memory-load.json'  # noqa: F405
PLACEMENTS = ('wfd', 'cls-a1')


def configuration(load: float, heaviness: str, set_id: int, placement: str) -> dict:
    return algorithm1.configuration(_base, CA_TABLE, load, heaviness, set_id, placement)


def protocol_extra() -> dict:
    return dict(_base.protocol_extra(), algorithm1_policies={'cls-a1': algorithm1.POLICIES['cls-a1']},
                ca_table=str(CA_TABLE.name))
