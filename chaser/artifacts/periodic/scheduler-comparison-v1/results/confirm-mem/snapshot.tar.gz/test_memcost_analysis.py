"""Specification tests for experiment 41's pre-registered analysis (synthetic data)."""
from pathlib import Path
import sys

import pytest

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))

import memcost_analysis as ma

L2, MEM = 'l2-low25', 'mem-low25'


def row(h, load, k, wfd, cgb):
    return dict(heaviness=h, load=load, set_id=k, p=dict(state=wfd), p_cgb=dict(state=cgb))


def test_pairs_join_the_two_shapes_by_load_and_set_and_drop_failed_runs():
    rows = [row(L2, 0.5, 0, 'ok', 'ok'), row(MEM, 0.5, 0, 'deadline', 'ok'),
            row(L2, 0.5, 1, 'other', 'ok'), row(MEM, 0.5, 1, 'ok', 'deadline')]
    assert ma.paired(rows, 'p') == [dict(load=0.5, set_id=0, l2=True, mem=False)]
    assert len(ma.paired(rows, 'p_cgb')) == 2


def test_mcnemar_counts_discordant_pairs_by_shape():
    pairs = [dict(l2=True, mem=False)] * 7 + [dict(l2=False, mem=True)] + [dict(l2=True, mem=True)] * 4
    m = ma.mcnemar(pairs)
    assert (m['pairs'], m['only_l2_met'], m['only_mem_met'], m['both_met'], m['neither_met']) == (12, 7, 1, 4, 0)
    assert m['p'] == pytest.approx(0.0703125)


def test_memory_demand_counts_memory_accesses_per_microsecond_against_the_memory_service_rate():
    tasks = [dict(u_planned=0.2, traffic_planned=4.0, p_l1=0.2, p_mem=0.8),   # 4 misses/us, all to memory: 4 acc/us
             dict(u_planned=0.5, traffic_planned=10.0, p_l1=0.5, p_llc=0.45, p_mem=0.05)]  # 20 acc/us, 1 to memory
    assert ma.memory_demand(tasks) == pytest.approx((0.2 * 4.0 * 0.8 / 0.8 + 0.5 * 10.0 * 0.05 / 0.5) / (1000 / 220))
