"""Specification tests for experiment 44's decisions and pre-registered analysis (synthetic data).

They need the main chaser package (chaser.policy.pfirst), which the c3 code copy lacks; under the copy they are
skipped. Run them with PYTHONPATH=<workspace>:policy-mix:period-distribution.
"""
import hashlib
import json
from pathlib import Path
import sys

import joblib
import numpy as np
import pytest
from sklearn.ensemble import RandomForestClassifier

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
sys.path.insert(0, str(HERE.parents[3]))  # the main chaser package (pfirst)

pytest.importorskip('chaser.policy.pfirst', reason='needs the main chaser package')
import confirm_analysis as ca  # noqa: E402
import confirm_decide as cd  # noqa: E402
from chaser.policy.pfirst import placement  # noqa: E402


def record(met, status='P', choice='ra-cgb', static='P'):
    met = dict(zip(('ra-cgb', 'g', 'c13', 'c112'), met))
    rf_accept = status in ('P', 'fallback_gc')
    return dict(met=met, status=status, choice=choice, rf=ca.outcome(rf_accept, choice, met),
                static=ca.outcome(static == 'P', 'ra-cgb', met), always=ca.outcome(True, 'ra-cgb', met))


def test_outcomes_separate_success_false_accept_false_reject_and_true_reject():
    met = {'ra-cgb': False, 'g': True}
    assert ca.outcome(True, 'g', met) == 'success' and ca.outcome(True, 'ra-cgb', met) == 'false_accept'
    assert ca.outcome(False, None, met) == 'false_reject' and ca.outcome(False, None, {'ra-cgb': False}) == 'true_reject'


def test_false_accept_check_needs_a_low_rate_and_a_tight_upper_bound():
    assert ca.false_accept_check(300, 1)['holds']
    assert not ca.false_accept_check(300, 9)['holds']
    assert not ca.false_accept_check(40, 0)['holds']  # bound (7.2 %) too wide with few accepted sets


def test_mcnemar_counts_sets_successful_with_only_one_method():
    records = [record((True, True, True, True))] * 3 + [record((True, False, False, False), static='rejected')] * 6 \
        + [record((True, False, False, False), status='rejected', choice=None)]
    m = ca.mcnemar_success(records)
    assert (m['only_a'], m['only_b'], m['direction_holds']) == (6, 1, True) and m['p'] == pytest.approx(0.125)


def test_switch_counts_saved_and_wrong_switches():
    records = [record((False, True, False, False), status='fallback_gc', choice='g'),
               record((True, False, False, False), status='fallback_gc', choice='g'),
               record((False, False, True, False), status='fallback_gc', choice='c13')]
    s = ca.gc_switches(records)
    assert (s['switched'], s['saved'], s['wrong_switch']) == (3, 2, 1)


def test_auc_difference_is_reproducible_and_positive_when_a_separates_better():
    rng = np.random.default_rng(1)
    y = rng.integers(0, 2, 200)
    a, b = y + rng.normal(0, 0.3, 200), y + rng.normal(0, 1.5, 200)
    r1, r2 = ca.auc_difference(y, a, b, reps=300), ca.auc_difference(y, a, b, reps=300)
    assert r1 == r2 and r1['difference'] > 0 and r1['low'] > 0 and r1['p'] < 0.05


def _case(root, tasks, seed):
    from chaser.policy.pfirst import inputs  # noqa: F401  (the decision reads the same files)
    case = root / 'cv20-small50/u045/s00'
    plan = [dict(task_id=f't{i:02d}', u_planned=t['u'], period_ticks=t['period'], core=0) for i, t in enumerate(tasks)]
    for build, mapping in (('wfd', placement.wfd(tasks)), ('ra-cgb', placement.release_aware_grouped(tasks, seed))):
        (case / build).mkdir(parents=True)
        (case / build / 'configuration.json').write_text(json.dumps(dict(
            tasks=[dict(p, core=c) for p, c in zip(plan, mapping)], high_load=dict(seed=seed))))
    (case / 'yarda').mkdir()
    (case / 'locality.json').write_text(json.dumps(dict(tasks=[dict(task_id=p['task_id'], cls=t['cls']) for p, t in zip(plan, tasks)])))
    for p, t in zip(plan, tasks):
        (case / 'yarda' / f"{p['task_id']}.json").write_text(json.dumps(dict(tasks=[dict(
            l1_first_hit_ratio=0.9 if t['cls'] > 0.5 else 0.13, all_cache_miss_ratio=0.01,
            l1=dict(misses=20000, unique_lines=1048))])))
    return case


def _policy(root, names):
    x = np.random.default_rng(0).uniform(0, 1, (50, len(names)))
    model = RandomForestClassifier(n_estimators=5, random_state=0).fit(x, (x[:, 0] < 0.5).astype(int))
    joblib.dump(model, root / 'model.joblib')
    digest = hashlib.sha256((root / 'model.joblib').read_bytes()).hexdigest()
    (root / 'model-spec.json').write_text(json.dumps(dict(model_sha256=digest, tau=0.8, features=names,
                                                          prediction_fingerprint='x')))
    return root


def test_decisions_are_written_before_runs_and_refused_after(tmp_path, monkeypatch):
    tasks = [dict(u=0.2, period=40 if i % 2 else 24, cls=0.13 if i < 3 else 0.9) for i in range(10)]
    out = tmp_path / 'out'
    _case(out, tasks, seed=7)
    policy = _policy(tmp_path, ['occupancy', 'total_u', 'is_ra-cgb'])
    monkeypatch.setattr(sys, 'argv', ['x', '--output', str(out), '--policy', str(policy)])
    cd.main()
    decisions = json.loads((out / 'decisions.json').read_text())
    assert list(decisions['cases']) == ['cv20-small50/u045/s00']
    assert (out / 'decisions.sha256').read_text().strip() == hashlib.sha256((out / 'decisions.json').read_bytes()).hexdigest()
    (out / 'cv20-small50/u045/s00/isolated/t00').mkdir(parents=True)
    (out / 'cv20-small50/u045/s00/isolated/t00/measurements.jsonl').write_text('{}')
    assert cd.measured_runs(out) == []
    (out / 'cv20-small50/u045/s00/wfd/g').mkdir()
    (out / 'cv20-small50/u045/s00/wfd/g/measurements.jsonl').write_text('{}')
    with pytest.raises(SystemExit):
        cd.main()
