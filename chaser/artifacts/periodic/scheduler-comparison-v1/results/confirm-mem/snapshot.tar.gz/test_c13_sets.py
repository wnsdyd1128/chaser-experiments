"""Specification tests for the C1+3 runs added to earlier designs' sets (run from the c3 copy)."""
from pathlib import Path
import sys

import pytest

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))

import c13_sets
import clsspread_set
import deadline_big_set
import deadline_set
import loadmem_set
import taskcount_set

BASES = {'loadmem_c13': loadmem_set, 'taskcount_c13': taskcount_set, 'clsspread_c13': clsspread_set,
         'deadline_c13': deadline_set, 'deadline_big_c13': deadline_big_set}


@pytest.mark.parametrize('name', BASES)
def test_each_c13_design_keeps_the_base_sets_and_builds_only_wfd(name):
    module, base = getattr(c13_sets, name), BASES[name]
    assert module.PLACEMENTS == ('wfd',)
    assert module.HEAVINESS == base.HEAVINESS and module.LOADS == base.LOADS and module.SETS == base.SETS
    assert module.SEED_BASE == base.SEED_BASE


@pytest.mark.parametrize('name', BASES)
def test_wfd_configuration_is_the_base_designs(name):
    module, base = getattr(c13_sets, name), BASES[name]
    load, cell = base.LOADS[0], base.HEAVINESS[-1]
    assert module.configuration(load, cell, 2, 'wfd') == base.configuration(load, cell, 2, 'wfd')
