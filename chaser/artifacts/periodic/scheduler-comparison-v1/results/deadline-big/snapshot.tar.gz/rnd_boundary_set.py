"""Random baseline on experiment 19's sets: the cells with low-CLS or 768 KiB tasks.

Same tasks, sets and seeds as boundary_set; P runs on placement_lib's RANDOM_POLICIES (each task on
a uniformly drawn core, redrawn until every core is under CORE_CAP, drawn from the set's seed),
so every run pairs with experiment 19's results on the same set. wfd is built (not run) for
hl_run's isolated gate and pm_run's yarda pass. protocol_extra is the base design's.
"""
from boundary_set import *  # noqa: F401,F403  the base design's constants, sets and configuration
from boundary_set import HEAVINESS as _BASE_HEAVINESS
from placement_lib import RANDOM_POLICIES

HEAVINESS = tuple(h for h in _BASE_HEAVINESS if not h.endswith('-low0-big0'))
PLACEMENTS = ('wfd',) + RANDOM_POLICIES
