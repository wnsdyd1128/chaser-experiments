#define TASK_COUNT 12
#define MAX_JOBS 2
#define ARCHITECTURE 2
#define CHASER_CONTRACT_ID "chaser-periodic-measurement-v2"
#define CHASER_PLAN_HASH "00ee2e188f1df99ce522e6136a3ccb0be761667269f7d94b18fd2dab625885d2"
#define CHASER_PERIODS {20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20}
#define CHASER_JOB_COUNTS {2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2}
#define CHASER_CORES {0, 1, 2, 3, 0, 1, 2, 3, 0, 1, 2, 3}
