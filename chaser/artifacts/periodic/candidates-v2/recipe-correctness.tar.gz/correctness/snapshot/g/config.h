#define TASK_COUNT 12
#define MAX_JOBS 2
#define ARCHITECTURE 0
#define CHASER_CONTRACT_ID "chaser-periodic-measurement-v2"
#define CHASER_PLAN_HASH "ad4c032824cfabb2f877ea2c14e09361cb02e1c629b776b5a7532f7d633f58a6"
#define CHASER_PERIODS {20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20}
#define CHASER_JOB_COUNTS {2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2}
#define CHASER_CORES {0, 1, 2, 3, 0, 1, 2, 3, 0, 1, 2, 3}
