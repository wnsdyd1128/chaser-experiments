#include "workload.h"
#ifdef __clang__
#define ANALYZE __attribute__((annotate("ape.analyze")))
#define INLINE __attribute__((annotate("ape.inline")))
#else
#define ANALYZE
#define INLINE
#endif
volatile uint8_t data_n2_window_coeff[384] __attribute__((aligned(4096), section(".chaser_data.00")));
INLINE static uint32_t kernel_n2_window_coeff(void) {
    uint32_t sum = 0;
    for (int b = 0; b < 2; ++b) {
        for (int w = 0; w < 3; ++w)
            for (int i = 0; i < 2; ++i) {
                sum += data_n2_window_coeff[(b * 6 + w + i) * 32];
                sum += data_n2_window_coeff[(b * 6 + 4 + i) * 32];
            }
    }
    return sum;
}
/** @brief Execute one fixed job without resetting data or cache.
 * @return Load-count checksum, modulo 2^32. */
ANALYZE uint32_t task_job_n2_window_coeff(void) {
    uint32_t sum = 0;
    for (int s = 0; s < 2; ++s)
        sum += kernel_n2_window_coeff();
    return sum;
}
volatile uint8_t data_n2_window_bank[512] __attribute__((aligned(4096), section(".chaser_data.01")));
INLINE static uint32_t kernel_n2_window_bank(void) {
    uint32_t sum = 0;
    for (int b = 0; b < 2; ++b) {
        for (int w = 0; w < 3; ++w)
            for (int bank = 0; bank < 2; ++bank)
                for (int i = 0; i < 2; ++i) {
                    sum += data_n2_window_bank[(b * 8 + w + i) * 32];
                    sum += data_n2_window_bank[(b * 8 + 4 + bank * 2 + i) * 32];
                }
    }
    return sum;
}
/** @brief Execute one fixed job without resetting data or cache.
 * @return Load-count checksum, modulo 2^32. */
ANALYZE uint32_t task_job_n2_window_bank(void) {
    uint32_t sum = 0;
    for (int s = 0; s < 2; ++s)
        sum += kernel_n2_window_bank();
    return sum;
}
volatile uint8_t data_n2_paired_pass[256] __attribute__((aligned(4096), section(".chaser_data.02")));
INLINE static uint32_t kernel_n2_paired_pass(void) {
    uint32_t sum = 0;
    for (int b = 0; b < 2; ++b) {
        for (int r = 0; r < 2; ++r)
            for (int i = 0; i < 2; ++i)
                sum += data_n2_paired_pass[(b * 4 + 0 + i) * 32];
        for (int r = 0; r < 2; ++r)
            for (int i = 0; i < 2; ++i)
                sum += data_n2_paired_pass[(b * 4 + 2 + i) * 32];
        for (int i = 0; i < 2; ++i) {
            sum += data_n2_paired_pass[(b * 4 + i) * 32];
            sum += data_n2_paired_pass[(b * 4 + 2 + i) * 32];
        }
    }
    return sum;
}
/** @brief Execute one fixed job without resetting data or cache.
 * @return Load-count checksum, modulo 2^32. */
ANALYZE uint32_t task_job_n2_paired_pass(void) {
    uint32_t sum = 0;
    for (int s = 0; s < 2; ++s)
        sum += kernel_n2_paired_pass();
    return sum;
}
volatile uint8_t data_n2_matrix_reuse[512] __attribute__((aligned(4096), section(".chaser_data.03")));
INLINE static uint32_t kernel_n2_matrix_reuse(void) {
    uint32_t sum = 0;
    for (int b = 0; b < 2; ++b) {
        for (int c = 0; c < 2; ++c)
            for (int r = 0; r < 2; ++r)
                for (int i = 0; i < 2; ++i) {
                    sum += data_n2_matrix_reuse[(b * 8 + r * 2 + i) * 32];
                    sum += data_n2_matrix_reuse[(b * 8 + 4 + c * 2 + i) * 32];
                }
    }
    return sum;
}
/** @brief Execute one fixed job without resetting data or cache.
 * @return Load-count checksum, modulo 2^32. */
ANALYZE uint32_t task_job_n2_matrix_reuse(void) {
    uint32_t sum = 0;
    for (int s = 0; s < 2; ++s)
        sum += kernel_n2_matrix_reuse();
    return sum;
}
volatile uint8_t data_n2_row_column[256] __attribute__((aligned(4096), section(".chaser_data.04")));
INLINE static uint32_t kernel_n2_row_column(void) {
    uint32_t sum = 0;
    for (int b = 0; b < 2; ++b) {
        for (int r = 0; r < 2; ++r)
            for (int c = 0; c < 2; ++c)
                sum += data_n2_row_column[(b * 4 + r * 2 + c) * 32];
        for (int c = 0; c < 2; ++c)
            for (int r = 0; r < 2; ++r)
                sum += data_n2_row_column[(b * 4 + r * 2 + c) * 32];
    }
    return sum;
}
/** @brief Execute one fixed job without resetting data or cache.
 * @return Load-count checksum, modulo 2^32. */
ANALYZE uint32_t task_job_n2_row_column(void) {
    uint32_t sum = 0;
    for (int s = 0; s < 2; ++s)
        sum += kernel_n2_row_column();
    return sum;
}
volatile uint8_t data_n2_row_column_mirrored[256] __attribute__((aligned(4096), section(".chaser_data.05")));
INLINE static uint32_t kernel_n2_row_column_mirrored(void) {
    uint32_t sum = 0;
    for (int b = 0; b < 2; ++b) {
        for (int r = 0; r < 2; ++r)
            for (int i = 0; i < 1; ++i) {
                sum += data_n2_row_column_mirrored[(b * 4 + r * 2 + i) * 32];
                sum += data_n2_row_column_mirrored[(b * 4 + r * 2 + 1 - i) * 32];
            }
        for (int c = 0; c < 2; ++c)
            for (int i = 0; i < 1; ++i) {
                sum += data_n2_row_column_mirrored[(b * 4 + i * 2 + c) * 32];
                sum += data_n2_row_column_mirrored[(b * 4 + (1 - i) * 2 + c) * 32];
            }
    }
    return sum;
}
/** @brief Execute one fixed job without resetting data or cache.
 * @return Load-count checksum, modulo 2^32. */
ANALYZE uint32_t task_job_n2_row_column_mirrored(void) {
    uint32_t sum = 0;
    for (int s = 0; s < 2; ++s)
        sum += kernel_n2_row_column_mirrored();
    return sum;
}
volatile uint8_t data_n8_window_coeff[1536] __attribute__((aligned(4096), section(".chaser_data.06")));
INLINE static uint32_t kernel_n8_window_coeff(void) {
    uint32_t sum = 0;
    for (int b = 0; b < 2; ++b) {
        for (int w = 0; w < 9; ++w)
            for (int i = 0; i < 8; ++i) {
                sum += data_n8_window_coeff[(b * 24 + w + i) * 32];
                sum += data_n8_window_coeff[(b * 24 + 16 + i) * 32];
            }
    }
    return sum;
}
/** @brief Execute one fixed job without resetting data or cache.
 * @return Load-count checksum, modulo 2^32. */
ANALYZE uint32_t task_job_n8_window_coeff(void) {
    uint32_t sum = 0;
    for (int s = 0; s < 2; ++s)
        sum += kernel_n8_window_coeff();
    return sum;
}
volatile uint8_t data_n8_window_bank[2048] __attribute__((aligned(4096), section(".chaser_data.07")));
INLINE static uint32_t kernel_n8_window_bank(void) {
    uint32_t sum = 0;
    for (int b = 0; b < 2; ++b) {
        for (int w = 0; w < 9; ++w)
            for (int bank = 0; bank < 2; ++bank)
                for (int i = 0; i < 8; ++i) {
                    sum += data_n8_window_bank[(b * 32 + w + i) * 32];
                    sum += data_n8_window_bank[(b * 32 + 16 + bank * 8 + i) * 32];
                }
    }
    return sum;
}
/** @brief Execute one fixed job without resetting data or cache.
 * @return Load-count checksum, modulo 2^32. */
ANALYZE uint32_t task_job_n8_window_bank(void) {
    uint32_t sum = 0;
    for (int s = 0; s < 2; ++s)
        sum += kernel_n8_window_bank();
    return sum;
}
volatile uint8_t data_n8_paired_pass[1024] __attribute__((aligned(4096), section(".chaser_data.08")));
INLINE static uint32_t kernel_n8_paired_pass(void) {
    uint32_t sum = 0;
    for (int b = 0; b < 2; ++b) {
        for (int r = 0; r < 2; ++r)
            for (int i = 0; i < 8; ++i)
                sum += data_n8_paired_pass[(b * 16 + 0 + i) * 32];
        for (int r = 0; r < 2; ++r)
            for (int i = 0; i < 8; ++i)
                sum += data_n8_paired_pass[(b * 16 + 8 + i) * 32];
        for (int i = 0; i < 8; ++i) {
            sum += data_n8_paired_pass[(b * 16 + i) * 32];
            sum += data_n8_paired_pass[(b * 16 + 8 + i) * 32];
        }
    }
    return sum;
}
/** @brief Execute one fixed job without resetting data or cache.
 * @return Load-count checksum, modulo 2^32. */
ANALYZE uint32_t task_job_n8_paired_pass(void) {
    uint32_t sum = 0;
    for (int s = 0; s < 2; ++s)
        sum += kernel_n8_paired_pass();
    return sum;
}
volatile uint8_t data_n8_matrix_reuse[8192] __attribute__((aligned(4096), section(".chaser_data.09")));
INLINE static uint32_t kernel_n8_matrix_reuse(void) {
    uint32_t sum = 0;
    for (int b = 0; b < 2; ++b) {
        for (int c = 0; c < 8; ++c)
            for (int r = 0; r < 8; ++r)
                for (int i = 0; i < 8; ++i) {
                    sum += data_n8_matrix_reuse[(b * 128 + r * 8 + i) * 32];
                    sum += data_n8_matrix_reuse[(b * 128 + 64 + c * 8 + i) * 32];
                }
    }
    return sum;
}
/** @brief Execute one fixed job without resetting data or cache.
 * @return Load-count checksum, modulo 2^32. */
ANALYZE uint32_t task_job_n8_matrix_reuse(void) {
    uint32_t sum = 0;
    for (int s = 0; s < 2; ++s)
        sum += kernel_n8_matrix_reuse();
    return sum;
}
volatile uint8_t data_n8_row_column[4096] __attribute__((aligned(4096), section(".chaser_data.10")));
INLINE static uint32_t kernel_n8_row_column(void) {
    uint32_t sum = 0;
    for (int b = 0; b < 2; ++b) {
        for (int r = 0; r < 8; ++r)
            for (int c = 0; c < 8; ++c)
                sum += data_n8_row_column[(b * 64 + r * 8 + c) * 32];
        for (int c = 0; c < 8; ++c)
            for (int r = 0; r < 8; ++r)
                sum += data_n8_row_column[(b * 64 + r * 8 + c) * 32];
    }
    return sum;
}
/** @brief Execute one fixed job without resetting data or cache.
 * @return Load-count checksum, modulo 2^32. */
ANALYZE uint32_t task_job_n8_row_column(void) {
    uint32_t sum = 0;
    for (int s = 0; s < 2; ++s)
        sum += kernel_n8_row_column();
    return sum;
}
volatile uint8_t data_n8_row_column_mirrored[4096] __attribute__((aligned(4096), section(".chaser_data.11")));
INLINE static uint32_t kernel_n8_row_column_mirrored(void) {
    uint32_t sum = 0;
    for (int b = 0; b < 2; ++b) {
        for (int r = 0; r < 8; ++r)
            for (int i = 0; i < 4; ++i) {
                sum += data_n8_row_column_mirrored[(b * 64 + r * 8 + i) * 32];
                sum += data_n8_row_column_mirrored[(b * 64 + r * 8 + 7 - i) * 32];
            }
        for (int c = 0; c < 8; ++c)
            for (int i = 0; i < 4; ++i) {
                sum += data_n8_row_column_mirrored[(b * 64 + i * 8 + c) * 32];
                sum += data_n8_row_column_mirrored[(b * 64 + (7 - i) * 8 + c) * 32];
            }
    }
    return sum;
}
/** @brief Execute one fixed job without resetting data or cache.
 * @return Load-count checksum, modulo 2^32. */
ANALYZE uint32_t task_job_n8_row_column_mirrored(void) {
    uint32_t sum = 0;
    for (int s = 0; s < 2; ++s)
        sum += kernel_n8_row_column_mirrored();
    return sum;
}
void workload_prepare(void) {
    for (int i = 0; i < 384; ++i) data_n2_window_coeff[i] = 1;
    for (int i = 0; i < 512; ++i) data_n2_window_bank[i] = 1;
    for (int i = 0; i < 256; ++i) data_n2_paired_pass[i] = 1;
    for (int i = 0; i < 512; ++i) data_n2_matrix_reuse[i] = 1;
    for (int i = 0; i < 256; ++i) data_n2_row_column[i] = 1;
    for (int i = 0; i < 256; ++i) data_n2_row_column_mirrored[i] = 1;
    for (int i = 0; i < 1536; ++i) data_n8_window_coeff[i] = 1;
    for (int i = 0; i < 2048; ++i) data_n8_window_bank[i] = 1;
    for (int i = 0; i < 1024; ++i) data_n8_paired_pass[i] = 1;
    for (int i = 0; i < 8192; ++i) data_n8_matrix_reuse[i] = 1;
    for (int i = 0; i < 4096; ++i) data_n8_row_column[i] = 1;
    for (int i = 0; i < 4096; ++i) data_n8_row_column_mirrored[i] = 1;
}
uint32_t (*const workload_jobs[])(void) = {
    task_job_n2_window_coeff,
    task_job_n2_window_bank,
    task_job_n2_paired_pass,
    task_job_n2_matrix_reuse,
    task_job_n2_row_column,
    task_job_n2_row_column_mirrored,
    task_job_n8_window_coeff,
    task_job_n8_window_bank,
    task_job_n8_paired_pass,
    task_job_n8_matrix_reuse,
    task_job_n8_row_column,
    task_job_n8_row_column_mirrored,
};
const uint32_t workload_expected[] = {
48U, 96U, 48U, 64U, 32U, 32U, 576U, 1152U, 192U, 4096U, 512U, 512U
};
