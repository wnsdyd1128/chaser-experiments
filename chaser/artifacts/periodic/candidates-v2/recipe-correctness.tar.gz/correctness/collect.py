from pathlib import Path
import importlib.util,json,shutil
from chaser.periodic import make_plan
from chaser.periodic_recipes import block_size
from chaser.periodic_build import prepare,check_layout,read_symbols
from chaser.periodic_analysis import analyze
from tools.rtems_smoke import file_hash,write_json,check_inputs

spec=importlib.util.spec_from_file_location('recipe_tests', 'tests/test_periodic_recipes.py')
tests=importlib.util.module_from_spec(spec);spec.loader.exec_module(tests)
root=Path('.cache/periodic-recipes-correctness-v2-r1')
root.mkdir(parents=True,exist_ok=False)

def independent(pattern,n):
    if n==2: return tests.TRACES[pattern]
    # Construct named regions/rows, then concatenate or zip their visits.
    if pattern.startswith('window-'):
        a=list(range(2*n)); banks=[list(range(2*n,3*n))]
        if pattern=='window-bank': banks.append(list(range(3*n,4*n)))
        return [v for w in range(n+1) for bank in banks
                for pair in zip(a[w:w+n],bank) for v in pair]
    if pattern=='paired-pass':
        a=list(range(n));b=list(range(n,2*n))
        return a*2+b*2+[v for pair in zip(a,b) for v in pair]
    if pattern=='matrix-reuse':
        a=[list(range(r*n,(r+1)*n)) for r in range(n)]
        b=[list(range(n*n+c*n,n*n+(c+1)*n)) for c in range(n)]
        return [v for column in b for row in a for pair in zip(row,column) for v in pair]
    rows=[list(range(r*n,(r+1)*n)) for r in range(n)]
    lines=rows+list(zip(*rows))
    if pattern=='row-column-mirrored':
        lines=[[v for pair in zip(line[:n//2],reversed(line[n//2:])) for v in pair]
               for line in lines]
    return [v for line in lines for v in line]

config=tests.configuration('window-coeff')
config['tasks']=[];references={}
for n in (2,8):
    for p in tests.TRACES:
        name=f'n{n}_{p.replace("-","_")}'
        task=dict(tests.configuration(p,width=n)['tasks'][0],task_id=name,core=len(config['tasks'])%4)
        one=independent(p,n)
        assert set(one)==set(range(block_size(p,n)))
        references[name]=[32*(v+b*block_size(p,n)) for b in range(2) for v in one]*2
        config['tasks'].append(task)
write_json(root/'reference-traces.json',references)
prepare(config,root/'snapshot')
result=analyze(root/'snapshot')
plan=make_plan(config,2)
checked=0
for arch in ('g','c','p'):
    layout={x['symbol']:x['address'] for x in check_layout(read_symbols(root/f'snapshot/build/{arch}.exe'),plan['tasks'])}
    for name,expected in references.items():
        events=json.loads((root/f'snapshot/analysis/{arch}/{name}/events.json').read_text())['events']
        assert [e['linked_address']-layout['data_'+name] for e in events]==expected,(arch,name)
        checked+=1
shutil.copyfile(__file__,root/'collect.py')
shutil.copyfile('tests/test_periodic_recipes.py',root/'test_periodic_recipes.py')
write_json(root/'result.json',dict(status='PASS',fixture_tasks=len(references),linked_streams=checked,
    accesses_per_architecture=sum(map(len,references.values())),widths=[2,8],target_runtime_runs=0,
    scope='correctness-only; separate from candidate membership and timing/labels'))
write_json(root/'manifest.json',dict(files={str(p.relative_to(root)):file_hash(p)
    for p in sorted(root.rglob('*')) if p.is_file()}))
check_inputs(root,json.loads((root/'manifest.json').read_text()))
print((root/'result.json').read_text())
