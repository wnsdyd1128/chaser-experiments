#define TASK_COUNT 8
#define MAX_JOBS 2
#define ARCHITECTURE 0
#define CHASER_CONTRACT_ID "chaser-periodic-measurement-v2"
#define CHASER_PLAN_HASH "0c62e2bed288717a071821c7c46f638c124e4c1ba5670f00c2f9df8f83c833ad"
#define CHASER_PERIODS {20, 20, 20, 20, 20, 20, 20, 20}
#define CHASER_JOB_COUNTS {2, 2, 2, 2, 2, 2, 2, 2}
#define CHASER_CORES {0, 1, 2, 3, 0, 1, 2, 3}
