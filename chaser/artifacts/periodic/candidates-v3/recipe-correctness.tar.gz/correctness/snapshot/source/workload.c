#include "workload.h"
#ifdef __clang__
#define ANALYZE __attribute__((annotate("ape.analyze")))
#define INLINE __attribute__((annotate("ape.inline")))
#else
#define ANALYZE
#define INLINE
#endif
volatile uint8_t data_t0[384] __attribute__((aligned(4096), section(".chaser_data.00")));
INLINE static uint32_t kernel_t0(void) {
    uint32_t sum = 0;
    for (int b = 0; b < 2; ++b) {
        for (int lane = 0; lane < 1; ++lane) {
            sum += data_t0[(b * 6 + 4 + 2 * lane) * 32];
            sum += data_t0[(b * 6 + 5 + 2 * lane) * 32];
            for (int g = 0; g < 1; ++g) {
                sum += data_t0[(b * 6 + 4 * g + 2 * lane + 2) * 32];
                sum += data_t0[(b * 6 + 4 * g + 2 * lane + 3) * 32];
                sum += data_t0[(b * 6 + 4 * g + 2 * lane + 0) * 32];
                sum += data_t0[(b * 6 + 4 * g + 2 * lane + 1) * 32];
            }
        }
    }
    return sum;
}
/** @brief Execute one fixed job without resetting data or cache.
 * @return Load-count checksum, modulo 2^32. */
ANALYZE uint32_t task_job_t0(void) {
    uint32_t sum = 0;
    for (int s = 0; s < 2; ++s)
        sum += kernel_t0();
    return sum;
}
volatile uint8_t data_t1[384] __attribute__((aligned(4096), section(".chaser_data.01")));
INLINE static uint32_t kernel_t1(void) {
    uint32_t sum = 0;
    for (int b = 0; b < 2; ++b) {
        for (int lane = 0; lane < 1; ++lane) {
            sum += data_t1[(b * 6 + 4 + 2 * lane) * 32];
            sum += data_t1[(b * 6 + 5 + 2 * lane) * 32];
            for (int g = 0; g < 1; ++g) {
                sum += data_t1[(b * 6 + 4 * g + 2 * lane + 2) * 32];
                sum += data_t1[(b * 6 + 4 * g + 2 * lane + 3) * 32];
                sum += data_t1[(b * 6 + 4 * g + 2 * lane + 0) * 32];
                sum += data_t1[(b * 6 + 4 * g + 2 * lane + 1) * 32];
            }
        }
        for (int i = 0; i < 4; ++i)
            sum += data_t1[(b * 6 + i) * 32];
    }
    return sum;
}
/** @brief Execute one fixed job without resetting data or cache.
 * @return Load-count checksum, modulo 2^32. */
ANALYZE uint32_t task_job_t1(void) {
    uint32_t sum = 0;
    for (int s = 0; s < 2; ++s)
        sum += kernel_t1();
    return sum;
}
volatile uint8_t data_t2[576] __attribute__((aligned(4096), section(".chaser_data.02")));
INLINE static uint32_t kernel_t2(void) {
    uint32_t sum = 0;
    for (int b = 0; b < 2; ++b) {
        sum += data_t2[(b * 9 + 4) * 32];
        sum += data_t2[(b * 9 + 5) * 32];
        for (int j = 0; j < 1; ++j) {
            sum += data_t2[(b * 9 + 2 + j) * 32];
            sum += data_t2[(b * 9 + 6 + j) * 32];
        }
        sum += data_t2[(b * 9 + 7) * 32];
        sum += data_t2[(b * 9 + 3) * 32];
        sum += data_t2[(b * 9 + 6) * 32];
        for (int j = 1; j < 2; ++j) {
            sum += data_t2[(b * 9 + 0 + j) * 32];
            sum += data_t2[(b * 9 + 7 + j) * 32];
        }
        sum += data_t2[(b * 9 + 0) * 32];
    }
    return sum;
}
/** @brief Execute one fixed job without resetting data or cache.
 * @return Load-count checksum, modulo 2^32. */
ANALYZE uint32_t task_job_t2(void) {
    uint32_t sum = 0;
    for (int s = 0; s < 2; ++s)
        sum += kernel_t2();
    return sum;
}
volatile uint8_t data_t3[576] __attribute__((aligned(4096), section(".chaser_data.03")));
INLINE static uint32_t kernel_t3(void) {
    uint32_t sum = 0;
    for (int b = 0; b < 2; ++b) {
        sum += data_t3[(b * 9 + 4) * 32];
        sum += data_t3[(b * 9 + 5) * 32];
        for (int j = 0; j < 1; ++j) {
            sum += data_t3[(b * 9 + j * 2 + 1) * 32];
            sum += data_t3[(b * 9 + 6 + j) * 32];
        }
        sum += data_t3[(b * 9 + 7) * 32];
        sum += data_t3[(b * 9 + 3) * 32];
        sum += data_t3[(b * 9 + 6) * 32];
        for (int j = 1; j < 2; ++j) {
            sum += data_t3[(b * 9 + j * 2 + 0) * 32];
            sum += data_t3[(b * 9 + 7 + j) * 32];
        }
        sum += data_t3[(b * 9 + 0) * 32];
    }
    return sum;
}
/** @brief Execute one fixed job without resetting data or cache.
 * @return Load-count checksum, modulo 2^32. */
ANALYZE uint32_t task_job_t3(void) {
    uint32_t sum = 0;
    for (int s = 0; s < 2; ++s)
        sum += kernel_t3();
    return sum;
}
volatile uint8_t data_t4[1920] __attribute__((aligned(4096), section(".chaser_data.04")));
INLINE static uint32_t kernel_t4(void) {
    uint32_t sum = 0;
    for (int b = 0; b < 2; ++b) {
        for (int lane = 0; lane < 1; ++lane) {
            sum += data_t4[(b * 30 + 16 + 2 * lane) * 32];
            sum += data_t4[(b * 30 + 17 + 2 * lane) * 32];
            for (int g = 0; g < 4; ++g) {
                sum += data_t4[(b * 30 + 4 * g + 2 * lane + 2) * 32];
                sum += data_t4[(b * 30 + 4 * g + 2 * lane + 3) * 32];
                sum += data_t4[(b * 30 + 4 * g + 2 * lane + 0) * 32];
                sum += data_t4[(b * 30 + 4 * g + 2 * lane + 1) * 32];
            }
        }
        for (int lane = 0; lane < 2; ++lane) {
            sum += data_t4[(b * 30 + 18 + 2 * lane) * 32];
            sum += data_t4[(b * 30 + 19 + 2 * lane) * 32];
            for (int g = 0; g < 2; ++g) {
                sum += data_t4[(b * 30 + 8 * g + 2 * lane + 4) * 32];
                sum += data_t4[(b * 30 + 8 * g + 2 * lane + 5) * 32];
                sum += data_t4[(b * 30 + 8 * g + 2 * lane + 0) * 32];
                sum += data_t4[(b * 30 + 8 * g + 2 * lane + 1) * 32];
            }
        }
        for (int lane = 0; lane < 4; ++lane) {
            sum += data_t4[(b * 30 + 22 + 2 * lane) * 32];
            sum += data_t4[(b * 30 + 23 + 2 * lane) * 32];
            for (int g = 0; g < 1; ++g) {
                sum += data_t4[(b * 30 + 16 * g + 2 * lane + 8) * 32];
                sum += data_t4[(b * 30 + 16 * g + 2 * lane + 9) * 32];
                sum += data_t4[(b * 30 + 16 * g + 2 * lane + 0) * 32];
                sum += data_t4[(b * 30 + 16 * g + 2 * lane + 1) * 32];
            }
        }
    }
    return sum;
}
/** @brief Execute one fixed job without resetting data or cache.
 * @return Load-count checksum, modulo 2^32. */
ANALYZE uint32_t task_job_t4(void) {
    uint32_t sum = 0;
    for (int s = 0; s < 2; ++s)
        sum += kernel_t4();
    return sum;
}
volatile uint8_t data_t5[1920] __attribute__((aligned(4096), section(".chaser_data.05")));
INLINE static uint32_t kernel_t5(void) {
    uint32_t sum = 0;
    for (int b = 0; b < 2; ++b) {
        for (int lane = 0; lane < 1; ++lane) {
            sum += data_t5[(b * 30 + 16 + 2 * lane) * 32];
            sum += data_t5[(b * 30 + 17 + 2 * lane) * 32];
            for (int g = 0; g < 4; ++g) {
                sum += data_t5[(b * 30 + 4 * g + 2 * lane + 2) * 32];
                sum += data_t5[(b * 30 + 4 * g + 2 * lane + 3) * 32];
                sum += data_t5[(b * 30 + 4 * g + 2 * lane + 0) * 32];
                sum += data_t5[(b * 30 + 4 * g + 2 * lane + 1) * 32];
            }
        }
        for (int i = 0; i < 16; ++i)
            sum += data_t5[(b * 30 + i) * 32];
        for (int lane = 0; lane < 2; ++lane) {
            sum += data_t5[(b * 30 + 18 + 2 * lane) * 32];
            sum += data_t5[(b * 30 + 19 + 2 * lane) * 32];
            for (int g = 0; g < 2; ++g) {
                sum += data_t5[(b * 30 + 8 * g + 2 * lane + 4) * 32];
                sum += data_t5[(b * 30 + 8 * g + 2 * lane + 5) * 32];
                sum += data_t5[(b * 30 + 8 * g + 2 * lane + 0) * 32];
                sum += data_t5[(b * 30 + 8 * g + 2 * lane + 1) * 32];
            }
        }
        for (int i = 0; i < 16; ++i)
            sum += data_t5[(b * 30 + i) * 32];
        for (int lane = 0; lane < 4; ++lane) {
            sum += data_t5[(b * 30 + 22 + 2 * lane) * 32];
            sum += data_t5[(b * 30 + 23 + 2 * lane) * 32];
            for (int g = 0; g < 1; ++g) {
                sum += data_t5[(b * 30 + 16 * g + 2 * lane + 8) * 32];
                sum += data_t5[(b * 30 + 16 * g + 2 * lane + 9) * 32];
                sum += data_t5[(b * 30 + 16 * g + 2 * lane + 0) * 32];
                sum += data_t5[(b * 30 + 16 * g + 2 * lane + 1) * 32];
            }
        }
        for (int i = 0; i < 16; ++i)
            sum += data_t5[(b * 30 + i) * 32];
    }
    return sum;
}
/** @brief Execute one fixed job without resetting data or cache.
 * @return Load-count checksum, modulo 2^32. */
ANALYZE uint32_t task_job_t5(void) {
    uint32_t sum = 0;
    for (int s = 0; s < 2; ++s)
        sum += kernel_t5();
    return sum;
}
volatile uint8_t data_t6[5568] __attribute__((aligned(4096), section(".chaser_data.06")));
INLINE static uint32_t kernel_t6(void) {
    uint32_t sum = 0;
    for (int b = 0; b < 2; ++b) {
        sum += data_t6[(b * 87 + 64) * 32];
        sum += data_t6[(b * 87 + 65) * 32];
        for (int j = 0; j < 1; ++j) {
            sum += data_t6[(b * 87 + 8 + j) * 32];
            sum += data_t6[(b * 87 + 72 + j) * 32];
        }
        sum += data_t6[(b * 87 + 66) * 32];
        for (int j = 0; j < 2; ++j) {
            sum += data_t6[(b * 87 + 16 + j) * 32];
            sum += data_t6[(b * 87 + 72 + j) * 32];
        }
        sum += data_t6[(b * 87 + 67) * 32];
        for (int j = 0; j < 3; ++j) {
            sum += data_t6[(b * 87 + 24 + j) * 32];
            sum += data_t6[(b * 87 + 72 + j) * 32];
        }
        sum += data_t6[(b * 87 + 68) * 32];
        for (int j = 0; j < 4; ++j) {
            sum += data_t6[(b * 87 + 32 + j) * 32];
            sum += data_t6[(b * 87 + 72 + j) * 32];
        }
        sum += data_t6[(b * 87 + 69) * 32];
        for (int j = 0; j < 5; ++j) {
            sum += data_t6[(b * 87 + 40 + j) * 32];
            sum += data_t6[(b * 87 + 72 + j) * 32];
        }
        sum += data_t6[(b * 87 + 70) * 32];
        for (int j = 0; j < 6; ++j) {
            sum += data_t6[(b * 87 + 48 + j) * 32];
            sum += data_t6[(b * 87 + 72 + j) * 32];
        }
        sum += data_t6[(b * 87 + 71) * 32];
        for (int j = 0; j < 7; ++j) {
            sum += data_t6[(b * 87 + 56 + j) * 32];
            sum += data_t6[(b * 87 + 72 + j) * 32];
        }
        sum += data_t6[(b * 87 + 79) * 32];
        sum += data_t6[(b * 87 + 63) * 32];
        sum += data_t6[(b * 87 + 78) * 32];
        for (int j = 7; j < 8; ++j) {
            sum += data_t6[(b * 87 + 48 + j) * 32];
            sum += data_t6[(b * 87 + 79 + j) * 32];
        }
        sum += data_t6[(b * 87 + 54) * 32];
        sum += data_t6[(b * 87 + 77) * 32];
        for (int j = 6; j < 8; ++j) {
            sum += data_t6[(b * 87 + 40 + j) * 32];
            sum += data_t6[(b * 87 + 79 + j) * 32];
        }
        sum += data_t6[(b * 87 + 45) * 32];
        sum += data_t6[(b * 87 + 76) * 32];
        for (int j = 5; j < 8; ++j) {
            sum += data_t6[(b * 87 + 32 + j) * 32];
            sum += data_t6[(b * 87 + 79 + j) * 32];
        }
        sum += data_t6[(b * 87 + 36) * 32];
        sum += data_t6[(b * 87 + 75) * 32];
        for (int j = 4; j < 8; ++j) {
            sum += data_t6[(b * 87 + 24 + j) * 32];
            sum += data_t6[(b * 87 + 79 + j) * 32];
        }
        sum += data_t6[(b * 87 + 27) * 32];
        sum += data_t6[(b * 87 + 74) * 32];
        for (int j = 3; j < 8; ++j) {
            sum += data_t6[(b * 87 + 16 + j) * 32];
            sum += data_t6[(b * 87 + 79 + j) * 32];
        }
        sum += data_t6[(b * 87 + 18) * 32];
        sum += data_t6[(b * 87 + 73) * 32];
        for (int j = 2; j < 8; ++j) {
            sum += data_t6[(b * 87 + 8 + j) * 32];
            sum += data_t6[(b * 87 + 79 + j) * 32];
        }
        sum += data_t6[(b * 87 + 9) * 32];
        sum += data_t6[(b * 87 + 72) * 32];
        for (int j = 1; j < 8; ++j) {
            sum += data_t6[(b * 87 + 0 + j) * 32];
            sum += data_t6[(b * 87 + 79 + j) * 32];
        }
        sum += data_t6[(b * 87 + 0) * 32];
    }
    return sum;
}
/** @brief Execute one fixed job without resetting data or cache.
 * @return Load-count checksum, modulo 2^32. */
ANALYZE uint32_t task_job_t6(void) {
    uint32_t sum = 0;
    for (int s = 0; s < 2; ++s)
        sum += kernel_t6();
    return sum;
}
volatile uint8_t data_t7[5568] __attribute__((aligned(4096), section(".chaser_data.07")));
INLINE static uint32_t kernel_t7(void) {
    uint32_t sum = 0;
    for (int b = 0; b < 2; ++b) {
        sum += data_t7[(b * 87 + 64) * 32];
        sum += data_t7[(b * 87 + 65) * 32];
        for (int j = 0; j < 1; ++j) {
            sum += data_t7[(b * 87 + j * 8 + 1) * 32];
            sum += data_t7[(b * 87 + 72 + j) * 32];
        }
        sum += data_t7[(b * 87 + 66) * 32];
        for (int j = 0; j < 2; ++j) {
            sum += data_t7[(b * 87 + j * 8 + 2) * 32];
            sum += data_t7[(b * 87 + 72 + j) * 32];
        }
        sum += data_t7[(b * 87 + 67) * 32];
        for (int j = 0; j < 3; ++j) {
            sum += data_t7[(b * 87 + j * 8 + 3) * 32];
            sum += data_t7[(b * 87 + 72 + j) * 32];
        }
        sum += data_t7[(b * 87 + 68) * 32];
        for (int j = 0; j < 4; ++j) {
            sum += data_t7[(b * 87 + j * 8 + 4) * 32];
            sum += data_t7[(b * 87 + 72 + j) * 32];
        }
        sum += data_t7[(b * 87 + 69) * 32];
        for (int j = 0; j < 5; ++j) {
            sum += data_t7[(b * 87 + j * 8 + 5) * 32];
            sum += data_t7[(b * 87 + 72 + j) * 32];
        }
        sum += data_t7[(b * 87 + 70) * 32];
        for (int j = 0; j < 6; ++j) {
            sum += data_t7[(b * 87 + j * 8 + 6) * 32];
            sum += data_t7[(b * 87 + 72 + j) * 32];
        }
        sum += data_t7[(b * 87 + 71) * 32];
        for (int j = 0; j < 7; ++j) {
            sum += data_t7[(b * 87 + j * 8 + 7) * 32];
            sum += data_t7[(b * 87 + 72 + j) * 32];
        }
        sum += data_t7[(b * 87 + 79) * 32];
        sum += data_t7[(b * 87 + 63) * 32];
        sum += data_t7[(b * 87 + 78) * 32];
        for (int j = 7; j < 8; ++j) {
            sum += data_t7[(b * 87 + j * 8 + 6) * 32];
            sum += data_t7[(b * 87 + 79 + j) * 32];
        }
        sum += data_t7[(b * 87 + 54) * 32];
        sum += data_t7[(b * 87 + 77) * 32];
        for (int j = 6; j < 8; ++j) {
            sum += data_t7[(b * 87 + j * 8 + 5) * 32];
            sum += data_t7[(b * 87 + 79 + j) * 32];
        }
        sum += data_t7[(b * 87 + 45) * 32];
        sum += data_t7[(b * 87 + 76) * 32];
        for (int j = 5; j < 8; ++j) {
            sum += data_t7[(b * 87 + j * 8 + 4) * 32];
            sum += data_t7[(b * 87 + 79 + j) * 32];
        }
        sum += data_t7[(b * 87 + 36) * 32];
        sum += data_t7[(b * 87 + 75) * 32];
        for (int j = 4; j < 8; ++j) {
            sum += data_t7[(b * 87 + j * 8 + 3) * 32];
            sum += data_t7[(b * 87 + 79 + j) * 32];
        }
        sum += data_t7[(b * 87 + 27) * 32];
        sum += data_t7[(b * 87 + 74) * 32];
        for (int j = 3; j < 8; ++j) {
            sum += data_t7[(b * 87 + j * 8 + 2) * 32];
            sum += data_t7[(b * 87 + 79 + j) * 32];
        }
        sum += data_t7[(b * 87 + 18) * 32];
        sum += data_t7[(b * 87 + 73) * 32];
        for (int j = 2; j < 8; ++j) {
            sum += data_t7[(b * 87 + j * 8 + 1) * 32];
            sum += data_t7[(b * 87 + 79 + j) * 32];
        }
        sum += data_t7[(b * 87 + 9) * 32];
        sum += data_t7[(b * 87 + 72) * 32];
        for (int j = 1; j < 8; ++j) {
            sum += data_t7[(b * 87 + j * 8 + 0) * 32];
            sum += data_t7[(b * 87 + 79 + j) * 32];
        }
        sum += data_t7[(b * 87 + 0) * 32];
    }
    return sum;
}
/** @brief Execute one fixed job without resetting data or cache.
 * @return Load-count checksum, modulo 2^32. */
ANALYZE uint32_t task_job_t7(void) {
    uint32_t sum = 0;
    for (int s = 0; s < 2; ++s)
        sum += kernel_t7();
    return sum;
}
void workload_prepare(void) {
    for (int i = 0; i < 384; ++i) data_t0[i] = 1;
    for (int i = 0; i < 384; ++i) data_t1[i] = 1;
    for (int i = 0; i < 576; ++i) data_t2[i] = 1;
    for (int i = 0; i < 576; ++i) data_t3[i] = 1;
    for (int i = 0; i < 1920; ++i) data_t4[i] = 1;
    for (int i = 0; i < 1920; ++i) data_t5[i] = 1;
    for (int i = 0; i < 5568; ++i) data_t6[i] = 1;
    for (int i = 0; i < 5568; ++i) data_t7[i] = 1;
}
uint32_t (*const workload_jobs[])(void) = {
    task_job_t0,
    task_job_t1,
    task_job_t2,
    task_job_t3,
    task_job_t4,
    task_job_t5,
    task_job_t6,
    task_job_t7,
};
const uint32_t workload_expected[] = {
24U, 40U, 40U, 40U, 248U, 440U, 544U, 544U
};
