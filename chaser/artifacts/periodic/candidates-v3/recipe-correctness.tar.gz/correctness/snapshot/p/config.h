#define TASK_COUNT 8
#define MAX_JOBS 2
#define ARCHITECTURE 2
#define CHASER_CONTRACT_ID "chaser-periodic-measurement-v2"
#define CHASER_PLAN_HASH "9294f1e8c0b6cee30a0cbff20b87a454c947142da85e89c0b5a46ed880c4a879"
#define CHASER_PERIODS {20, 20, 20, 20, 20, 20, 20, 20}
#define CHASER_JOB_COUNTS {2, 2, 2, 2, 2, 2, 2, 2}
#define CHASER_CORES {0, 1, 2, 3, 0, 1, 2, 3}
