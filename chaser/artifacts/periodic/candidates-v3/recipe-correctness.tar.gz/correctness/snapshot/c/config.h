#define TASK_COUNT 8
#define MAX_JOBS 2
#define ARCHITECTURE 1
#define CHASER_CONTRACT_ID "chaser-periodic-measurement-v2"
#define CHASER_PLAN_HASH "64a39a19e7a884e8f46ec8063b72f8b1e749fb856239cc8396f1c46250ecab93"
#define CHASER_PERIODS {20, 20, 20, 20, 20, 20, 20, 20}
#define CHASER_JOB_COUNTS {2, 2, 2, 2, 2, 2, 2, 2}
#define CHASER_CORES {0, 1, 2, 3, 0, 1, 2, 3}
