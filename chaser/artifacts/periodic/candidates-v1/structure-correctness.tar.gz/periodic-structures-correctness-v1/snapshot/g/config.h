#define TASK_COUNT 10
#define MAX_JOBS 2
#define ARCHITECTURE 0
#define CHASER_CONTRACT_ID "chaser-periodic-measurement-v2"
#define CHASER_PLAN_HASH "188dc075e493e9f34e3e0628462939436a9b7d39f5b889f26155d0fcdcb91716"
#define CHASER_PERIODS {20, 20, 20, 20, 20, 20, 20, 20, 20, 20}
#define CHASER_JOB_COUNTS {2, 2, 2, 2, 2, 2, 2, 2, 2, 2}
#define CHASER_CORES {0, 1, 2, 3, 0, 1, 2, 3, 0, 1}
