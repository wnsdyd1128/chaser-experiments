; ModuleID = '/workspace/experiments/chaser/.cache/periodic-structures-correctness-v1/snapshot/source/workload.c'
source_filename = "/workspace/experiments/chaser/.cache/periodic-structures-correctness-v1/snapshot/source/workload.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

@.str = private unnamed_addr constant [12 x i8] c"ape.analyze\00", section "llvm.metadata"
@.str.1 = private unnamed_addr constant [99 x i8] c"/workspace/experiments/chaser/.cache/periodic-structures-correctness-v1/snapshot/source/workload.c\00", section "llvm.metadata"
@data_t0 = dso_local global [768 x i8] zeroinitializer, section ".chaser_data.00", align 4096, !dbg !0
@data_t1 = dso_local global [768 x i8] zeroinitializer, section ".chaser_data.01", align 4096, !dbg !24
@data_t2 = dso_local global [768 x i8] zeroinitializer, section ".chaser_data.02", align 4096, !dbg !33
@data_t3 = dso_local global [768 x i8] zeroinitializer, section ".chaser_data.03", align 4096, !dbg !35
@data_t4 = dso_local global [768 x i8] zeroinitializer, section ".chaser_data.04", align 4096, !dbg !37
@data_t5 = dso_local global [768 x i8] zeroinitializer, section ".chaser_data.05", align 4096, !dbg !39
@data_t6 = dso_local global [768 x i8] zeroinitializer, section ".chaser_data.06", align 4096, !dbg !41
@data_t7 = dso_local global [768 x i8] zeroinitializer, section ".chaser_data.07", align 4096, !dbg !43
@data_t8 = dso_local global [768 x i8] zeroinitializer, section ".chaser_data.08", align 4096, !dbg !45
@data_t9 = dso_local global [768 x i8] zeroinitializer, section ".chaser_data.09", align 4096, !dbg !47
@workload_jobs = dso_local constant [10 x i32 ()*] [i32 ()* @task_job_t0, i32 ()* @task_job_t1, i32 ()* @task_job_t2, i32 ()* @task_job_t3, i32 ()* @task_job_t4, i32 ()* @task_job_t5, i32 ()* @task_job_t6, i32 ()* @task_job_t7, i32 ()* @task_job_t8, i32 ()* @task_job_t9], align 16, !dbg !5
@workload_expected = dso_local constant [10 x i32] [i32 96, i32 84, i32 48, i32 96, i32 48, i32 92, i32 96, i32 108, i32 96, i32 60], align 16, !dbg !20
@.str.2 = private unnamed_addr constant [11 x i8] c"ape.inline\00", section "llvm.metadata"
@llvm.global.annotations = appending global [20 x { i8*, i8*, i8*, i32, i8* }] [{ i8*, i8*, i8*, i32, i8* } { i8* bitcast (i32 ()* @task_job_t0 to i8*), i8* getelementptr inbounds ([12 x i8], [12 x i8]* @.str, i32 0, i32 0), i8* getelementptr inbounds ([99 x i8], [99 x i8]* @.str.1, i32 0, i32 0), i32 20, i8* null }, { i8*, i8*, i8*, i32, i8* } { i8* bitcast (i32 ()* @task_job_t1 to i8*), i8* getelementptr inbounds ([12 x i8], [12 x i8]* @.str, i32 0, i32 0), i8* getelementptr inbounds ([99 x i8], [99 x i8]* @.str.1, i32 0, i32 0), i32 36, i8* null }, { i8*, i8*, i8*, i32, i8* } { i8* bitcast (i32 ()* @task_job_t2 to i8*), i8* getelementptr inbounds ([12 x i8], [12 x i8]* @.str, i32 0, i32 0), i8* getelementptr inbounds ([99 x i8], [99 x i8]* @.str.1, i32 0, i32 0), i32 52, i8* null }, { i8*, i8*, i8*, i32, i8* } { i8* bitcast (i32 ()* @task_job_t3 to i8*), i8* getelementptr inbounds ([12 x i8], [12 x i8]* @.str, i32 0, i32 0), i8* getelementptr inbounds ([99 x i8], [99 x i8]* @.str.1, i32 0, i32 0), i32 69, i8* null }, { i8*, i8*, i8*, i32, i8* } { i8* bitcast (i32 ()* @task_job_t4 to i8*), i8* getelementptr inbounds ([12 x i8], [12 x i8]* @.str, i32 0, i32 0), i8* getelementptr inbounds ([99 x i8], [99 x i8]* @.str.1, i32 0, i32 0), i32 86, i8* null }, { i8*, i8*, i8*, i32, i8* } { i8* bitcast (i32 ()* @task_job_t5 to i8*), i8* getelementptr inbounds ([12 x i8], [12 x i8]* @.str, i32 0, i32 0), i8* getelementptr inbounds ([99 x i8], [99 x i8]* @.str.1, i32 0, i32 0), i32 103, i8* null }, { i8*, i8*, i8*, i32, i8* } { i8* bitcast (i32 ()* @task_job_t6 to i8*), i8* getelementptr inbounds ([12 x i8], [12 x i8]* @.str, i32 0, i32 0), i8* getelementptr inbounds ([99 x i8], [99 x i8]* @.str.1, i32 0, i32 0), i32 122, i8* null }, { i8*, i8*, i8*, i32, i8* } { i8* bitcast (i32 ()* @task_job_t7 to i8*), i8* getelementptr inbounds ([12 x i8], [12 x i8]* @.str, i32 0, i32 0), i8* getelementptr inbounds ([99 x i8], [99 x i8]* @.str.1, i32 0, i32 0), i32 142, i8* null }, { i8*, i8*, i8*, i32, i8* } { i8* bitcast (i32 ()* @task_job_t8 to i8*), i8* getelementptr inbounds ([12 x i8], [12 x i8]* @.str, i32 0, i32 0), i8* getelementptr inbounds ([99 x i8], [99 x i8]* @.str.1, i32 0, i32 0), i32 167, i8* null }, { i8*, i8*, i8*, i32, i8* } { i8* bitcast (i32 ()* @task_job_t9 to i8*), i8* getelementptr inbounds ([12 x i8], [12 x i8]* @.str, i32 0, i32 0), i8* getelementptr inbounds ([99 x i8], [99 x i8]* @.str.1, i32 0, i32 0), i32 184, i8* null }, { i8*, i8*, i8*, i32, i8* } { i8* bitcast (i32 ()* @kernel_t0 to i8*), i8* getelementptr inbounds ([11 x i8], [11 x i8]* @.str.2, i32 0, i32 0), i8* getelementptr inbounds ([99 x i8], [99 x i8]* @.str.1, i32 0, i32 0), i32 10, i8* null }, { i8*, i8*, i8*, i32, i8* } { i8* bitcast (i32 ()* @kernel_t1 to i8*), i8* getelementptr inbounds ([11 x i8], [11 x i8]* @.str.2, i32 0, i32 0), i8* getelementptr inbounds ([99 x i8], [99 x i8]* @.str.1, i32 0, i32 0), i32 27, i8* null }, { i8*, i8*, i8*, i32, i8* } { i8* bitcast (i32 ()* @kernel_t2 to i8*), i8* getelementptr inbounds ([11 x i8], [11 x i8]* @.str.2, i32 0, i32 0), i8* getelementptr inbounds ([99 x i8], [99 x i8]* @.str.1, i32 0, i32 0), i32 43, i8* null }, { i8*, i8*, i8*, i32, i8* } { i8* bitcast (i32 ()* @kernel_t3 to i8*), i8* getelementptr inbounds ([11 x i8], [11 x i8]* @.str.2, i32 0, i32 0), i8* getelementptr inbounds ([99 x i8], [99 x i8]* @.str.1, i32 0, i32 0), i32 59, i8* null }, { i8*, i8*, i8*, i32, i8* } { i8* bitcast (i32 ()* @kernel_t4 to i8*), i8* getelementptr inbounds ([11 x i8], [11 x i8]* @.str.2, i32 0, i32 0), i8* getelementptr inbounds ([99 x i8], [99 x i8]* @.str.1, i32 0, i32 0), i32 76, i8* null }, { i8*, i8*, i8*, i32, i8* } { i8* bitcast (i32 ()* @kernel_t5 to i8*), i8* getelementptr inbounds ([11 x i8], [11 x i8]* @.str.2, i32 0, i32 0), i8* getelementptr inbounds ([99 x i8], [99 x i8]* @.str.1, i32 0, i32 0), i32 93, i8* null }, { i8*, i8*, i8*, i32, i8* } { i8* bitcast (i32 ()* @kernel_t6 to i8*), i8* getelementptr inbounds ([11 x i8], [11 x i8]* @.str.2, i32 0, i32 0), i8* getelementptr inbounds ([99 x i8], [99 x i8]* @.str.1, i32 0, i32 0), i32 110, i8* null }, { i8*, i8*, i8*, i32, i8* } { i8* bitcast (i32 ()* @kernel_t7 to i8*), i8* getelementptr inbounds ([11 x i8], [11 x i8]* @.str.2, i32 0, i32 0), i8* getelementptr inbounds ([99 x i8], [99 x i8]* @.str.1, i32 0, i32 0), i32 129, i8* null }, { i8*, i8*, i8*, i32, i8* } { i8* bitcast (i32 ()* @kernel_t8 to i8*), i8* getelementptr inbounds ([11 x i8], [11 x i8]* @.str.2, i32 0, i32 0), i8* getelementptr inbounds ([99 x i8], [99 x i8]* @.str.1, i32 0, i32 0), i32 149, i8* null }, { i8*, i8*, i8*, i32, i8* } { i8* bitcast (i32 ()* @kernel_t9 to i8*), i8* getelementptr inbounds ([11 x i8], [11 x i8]* @.str.2, i32 0, i32 0), i8* getelementptr inbounds ([99 x i8], [99 x i8]* @.str.1, i32 0, i32 0), i32 174, i8* null }], section "llvm.metadata"

; Function Attrs: noinline nounwind uwtable
define dso_local i32 @task_job_t0() #0 !dbg !57 {
  %1 = alloca i32, align 4
  %2 = alloca i32, align 4
  call void @llvm.dbg.declare(metadata i32* %1, metadata !59, metadata !DIExpression()), !dbg !60
  store i32 0, i32* %1, align 4, !dbg !60
  call void @llvm.dbg.declare(metadata i32* %2, metadata !61, metadata !DIExpression()), !dbg !64
  store i32 0, i32* %2, align 4, !dbg !64
  br label %3, !dbg !65

3:                                                ; preds = %10, %0
  %4 = load i32, i32* %2, align 4, !dbg !66
  %5 = icmp slt i32 %4, 2, !dbg !68
  br i1 %5, label %6, label %13, !dbg !69

6:                                                ; preds = %3
  %7 = call i32 @kernel_t0(), !dbg !70
  %8 = load i32, i32* %1, align 4, !dbg !71
  %9 = add i32 %8, %7, !dbg !71
  store i32 %9, i32* %1, align 4, !dbg !71
  br label %10, !dbg !72

10:                                               ; preds = %6
  %11 = load i32, i32* %2, align 4, !dbg !73
  %12 = add nsw i32 %11, 1, !dbg !73
  store i32 %12, i32* %2, align 4, !dbg !73
  br label %3, !dbg !74, !llvm.loop !75

13:                                               ; preds = %3
  %14 = load i32, i32* %1, align 4, !dbg !78
  ret i32 %14, !dbg !79
}

; Function Attrs: nofree nosync nounwind readnone speculatable willreturn
declare void @llvm.dbg.declare(metadata, metadata, metadata) #1

; Function Attrs: noinline nounwind uwtable
define internal i32 @kernel_t0() #0 !dbg !80 {
  %1 = alloca i32, align 4
  %2 = alloca i32, align 4
  %3 = alloca i32, align 4
  %4 = alloca i32, align 4
  call void @llvm.dbg.declare(metadata i32* %1, metadata !81, metadata !DIExpression()), !dbg !82
  store i32 0, i32* %1, align 4, !dbg !82
  call void @llvm.dbg.declare(metadata i32* %2, metadata !83, metadata !DIExpression()), !dbg !85
  store i32 0, i32* %2, align 4, !dbg !85
  br label %5, !dbg !86

5:                                                ; preds = %36, %0
  %6 = load i32, i32* %2, align 4, !dbg !87
  %7 = icmp slt i32 %6, 4, !dbg !89
  br i1 %7, label %8, label %39, !dbg !90

8:                                                ; preds = %5
  call void @llvm.dbg.declare(metadata i32* %3, metadata !91, metadata !DIExpression()), !dbg !93
  store i32 0, i32* %3, align 4, !dbg !93
  br label %9, !dbg !94

9:                                                ; preds = %32, %8
  %10 = load i32, i32* %3, align 4, !dbg !95
  %11 = icmp slt i32 %10, 2, !dbg !97
  br i1 %11, label %12, label %35, !dbg !98

12:                                               ; preds = %9
  call void @llvm.dbg.declare(metadata i32* %4, metadata !99, metadata !DIExpression()), !dbg !101
  store i32 0, i32* %4, align 4, !dbg !101
  br label %13, !dbg !102

13:                                               ; preds = %28, %12
  %14 = load i32, i32* %4, align 4, !dbg !103
  %15 = icmp slt i32 %14, 6, !dbg !105
  br i1 %15, label %16, label %31, !dbg !106

16:                                               ; preds = %13
  %17 = load i32, i32* %2, align 4, !dbg !107
  %18 = mul nsw i32 %17, 6, !dbg !108
  %19 = load i32, i32* %4, align 4, !dbg !109
  %20 = add nsw i32 %18, %19, !dbg !110
  %21 = mul nsw i32 %20, 32, !dbg !111
  %22 = sext i32 %21 to i64, !dbg !112
  %23 = getelementptr inbounds [768 x i8], [768 x i8]* @data_t0, i64 0, i64 %22, !dbg !112
  %24 = load volatile i8, i8* %23, align 1, !dbg !112
  %25 = zext i8 %24 to i32, !dbg !112
  %26 = load i32, i32* %1, align 4, !dbg !113
  %27 = add i32 %26, %25, !dbg !113
  store i32 %27, i32* %1, align 4, !dbg !113
  br label %28, !dbg !114

28:                                               ; preds = %16
  %29 = load i32, i32* %4, align 4, !dbg !115
  %30 = add nsw i32 %29, 1, !dbg !115
  store i32 %30, i32* %4, align 4, !dbg !115
  br label %13, !dbg !116, !llvm.loop !117

31:                                               ; preds = %13
  br label %32, !dbg !118

32:                                               ; preds = %31
  %33 = load i32, i32* %3, align 4, !dbg !119
  %34 = add nsw i32 %33, 1, !dbg !119
  store i32 %34, i32* %3, align 4, !dbg !119
  br label %9, !dbg !120, !llvm.loop !121

35:                                               ; preds = %9
  br label %36, !dbg !122

36:                                               ; preds = %35
  %37 = load i32, i32* %2, align 4, !dbg !123
  %38 = add nsw i32 %37, 1, !dbg !123
  store i32 %38, i32* %2, align 4, !dbg !123
  br label %5, !dbg !124, !llvm.loop !125

39:                                               ; preds = %5
  %40 = load i32, i32* %1, align 4, !dbg !127
  ret i32 %40, !dbg !128
}

; Function Attrs: noinline nounwind uwtable
define dso_local i32 @task_job_t1() #0 !dbg !129 {
  %1 = alloca i32, align 4
  %2 = alloca i32, align 4
  call void @llvm.dbg.declare(metadata i32* %1, metadata !130, metadata !DIExpression()), !dbg !131
  store i32 0, i32* %1, align 4, !dbg !131
  call void @llvm.dbg.declare(metadata i32* %2, metadata !132, metadata !DIExpression()), !dbg !134
  store i32 0, i32* %2, align 4, !dbg !134
  br label %3, !dbg !135

3:                                                ; preds = %10, %0
  %4 = load i32, i32* %2, align 4, !dbg !136
  %5 = icmp slt i32 %4, 2, !dbg !138
  br i1 %5, label %6, label %13, !dbg !139

6:                                                ; preds = %3
  %7 = call i32 @kernel_t1(), !dbg !140
  %8 = load i32, i32* %1, align 4, !dbg !141
  %9 = add i32 %8, %7, !dbg !141
  store i32 %9, i32* %1, align 4, !dbg !141
  br label %10, !dbg !142

10:                                               ; preds = %6
  %11 = load i32, i32* %2, align 4, !dbg !143
  %12 = add nsw i32 %11, 1, !dbg !143
  store i32 %12, i32* %2, align 4, !dbg !143
  br label %3, !dbg !144, !llvm.loop !145

13:                                               ; preds = %3
  %14 = load i32, i32* %1, align 4, !dbg !147
  ret i32 %14, !dbg !148
}

; Function Attrs: noinline nounwind uwtable
define internal i32 @kernel_t1() #0 !dbg !149 {
  %1 = alloca i32, align 4
  %2 = alloca i32, align 4
  %3 = alloca i32, align 4
  call void @llvm.dbg.declare(metadata i32* %1, metadata !150, metadata !DIExpression()), !dbg !151
  store i32 0, i32* %1, align 4, !dbg !151
  call void @llvm.dbg.declare(metadata i32* %2, metadata !152, metadata !DIExpression()), !dbg !154
  store i32 0, i32* %2, align 4, !dbg !154
  br label %4, !dbg !155

4:                                                ; preds = %27, %0
  %5 = load i32, i32* %2, align 4, !dbg !156
  %6 = icmp slt i32 %5, 7, !dbg !158
  br i1 %6, label %7, label %30, !dbg !159

7:                                                ; preds = %4
  call void @llvm.dbg.declare(metadata i32* %3, metadata !160, metadata !DIExpression()), !dbg !162
  store i32 0, i32* %3, align 4, !dbg !162
  br label %8, !dbg !163

8:                                                ; preds = %23, %7
  %9 = load i32, i32* %3, align 4, !dbg !164
  %10 = icmp slt i32 %9, 6, !dbg !166
  br i1 %10, label %11, label %26, !dbg !167

11:                                               ; preds = %8
  %12 = load i32, i32* %2, align 4, !dbg !168
  %13 = mul nsw i32 %12, 3, !dbg !169
  %14 = load i32, i32* %3, align 4, !dbg !170
  %15 = add nsw i32 %13, %14, !dbg !171
  %16 = mul nsw i32 %15, 32, !dbg !172
  %17 = sext i32 %16 to i64, !dbg !173
  %18 = getelementptr inbounds [768 x i8], [768 x i8]* @data_t1, i64 0, i64 %17, !dbg !173
  %19 = load volatile i8, i8* %18, align 1, !dbg !173
  %20 = zext i8 %19 to i32, !dbg !173
  %21 = load i32, i32* %1, align 4, !dbg !174
  %22 = add i32 %21, %20, !dbg !174
  store i32 %22, i32* %1, align 4, !dbg !174
  br label %23, !dbg !175

23:                                               ; preds = %11
  %24 = load i32, i32* %3, align 4, !dbg !176
  %25 = add nsw i32 %24, 1, !dbg !176
  store i32 %25, i32* %3, align 4, !dbg !176
  br label %8, !dbg !177, !llvm.loop !178

26:                                               ; preds = %8
  br label %27, !dbg !179

27:                                               ; preds = %26
  %28 = load i32, i32* %2, align 4, !dbg !180
  %29 = add nsw i32 %28, 1, !dbg !180
  store i32 %29, i32* %2, align 4, !dbg !180
  br label %4, !dbg !181, !llvm.loop !182

30:                                               ; preds = %4
  %31 = load i32, i32* %1, align 4, !dbg !184
  ret i32 %31, !dbg !185
}

; Function Attrs: noinline nounwind uwtable
define dso_local i32 @task_job_t2() #0 !dbg !186 {
  %1 = alloca i32, align 4
  %2 = alloca i32, align 4
  call void @llvm.dbg.declare(metadata i32* %1, metadata !187, metadata !DIExpression()), !dbg !188
  store i32 0, i32* %1, align 4, !dbg !188
  call void @llvm.dbg.declare(metadata i32* %2, metadata !189, metadata !DIExpression()), !dbg !191
  store i32 0, i32* %2, align 4, !dbg !191
  br label %3, !dbg !192

3:                                                ; preds = %10, %0
  %4 = load i32, i32* %2, align 4, !dbg !193
  %5 = icmp slt i32 %4, 2, !dbg !195
  br i1 %5, label %6, label %13, !dbg !196

6:                                                ; preds = %3
  %7 = call i32 @kernel_t2(), !dbg !197
  %8 = load i32, i32* %1, align 4, !dbg !198
  %9 = add i32 %8, %7, !dbg !198
  store i32 %9, i32* %1, align 4, !dbg !198
  br label %10, !dbg !199

10:                                               ; preds = %6
  %11 = load i32, i32* %2, align 4, !dbg !200
  %12 = add nsw i32 %11, 1, !dbg !200
  store i32 %12, i32* %2, align 4, !dbg !200
  br label %3, !dbg !201, !llvm.loop !202

13:                                               ; preds = %3
  %14 = load i32, i32* %1, align 4, !dbg !204
  ret i32 %14, !dbg !205
}

; Function Attrs: noinline nounwind uwtable
define internal i32 @kernel_t2() #0 !dbg !206 {
  %1 = alloca i32, align 4
  %2 = alloca i32, align 4
  %3 = alloca i32, align 4
  call void @llvm.dbg.declare(metadata i32* %1, metadata !207, metadata !DIExpression()), !dbg !208
  store i32 0, i32* %1, align 4, !dbg !208
  call void @llvm.dbg.declare(metadata i32* %2, metadata !209, metadata !DIExpression()), !dbg !211
  store i32 0, i32* %2, align 4, !dbg !211
  br label %4, !dbg !212

4:                                                ; preds = %27, %0
  %5 = load i32, i32* %2, align 4, !dbg !213
  %6 = icmp slt i32 %5, 3, !dbg !215
  br i1 %6, label %7, label %30, !dbg !216

7:                                                ; preds = %4
  call void @llvm.dbg.declare(metadata i32* %3, metadata !217, metadata !DIExpression()), !dbg !219
  store i32 0, i32* %3, align 4, !dbg !219
  br label %8, !dbg !220

8:                                                ; preds = %23, %7
  %9 = load i32, i32* %3, align 4, !dbg !221
  %10 = icmp slt i32 %9, 8, !dbg !223
  br i1 %10, label %11, label %26, !dbg !224

11:                                               ; preds = %8
  %12 = load i32, i32* %3, align 4, !dbg !225
  %13 = mul nsw i32 %12, 3, !dbg !226
  %14 = load i32, i32* %2, align 4, !dbg !227
  %15 = add nsw i32 %13, %14, !dbg !228
  %16 = mul nsw i32 %15, 32, !dbg !229
  %17 = sext i32 %16 to i64, !dbg !230
  %18 = getelementptr inbounds [768 x i8], [768 x i8]* @data_t2, i64 0, i64 %17, !dbg !230
  %19 = load volatile i8, i8* %18, align 1, !dbg !230
  %20 = zext i8 %19 to i32, !dbg !230
  %21 = load i32, i32* %1, align 4, !dbg !231
  %22 = add i32 %21, %20, !dbg !231
  store i32 %22, i32* %1, align 4, !dbg !231
  br label %23, !dbg !232

23:                                               ; preds = %11
  %24 = load i32, i32* %3, align 4, !dbg !233
  %25 = add nsw i32 %24, 1, !dbg !233
  store i32 %25, i32* %3, align 4, !dbg !233
  br label %8, !dbg !234, !llvm.loop !235

26:                                               ; preds = %8
  br label %27, !dbg !236

27:                                               ; preds = %26
  %28 = load i32, i32* %2, align 4, !dbg !237
  %29 = add nsw i32 %28, 1, !dbg !237
  store i32 %29, i32* %2, align 4, !dbg !237
  br label %4, !dbg !238, !llvm.loop !239

30:                                               ; preds = %4
  %31 = load i32, i32* %1, align 4, !dbg !241
  ret i32 %31, !dbg !242
}

; Function Attrs: noinline nounwind uwtable
define dso_local i32 @task_job_t3() #0 !dbg !243 {
  %1 = alloca i32, align 4
  %2 = alloca i32, align 4
  call void @llvm.dbg.declare(metadata i32* %1, metadata !244, metadata !DIExpression()), !dbg !245
  store i32 0, i32* %1, align 4, !dbg !245
  call void @llvm.dbg.declare(metadata i32* %2, metadata !246, metadata !DIExpression()), !dbg !248
  store i32 0, i32* %2, align 4, !dbg !248
  br label %3, !dbg !249

3:                                                ; preds = %10, %0
  %4 = load i32, i32* %2, align 4, !dbg !250
  %5 = icmp slt i32 %4, 2, !dbg !252
  br i1 %5, label %6, label %13, !dbg !253

6:                                                ; preds = %3
  %7 = call i32 @kernel_t3(), !dbg !254
  %8 = load i32, i32* %1, align 4, !dbg !255
  %9 = add i32 %8, %7, !dbg !255
  store i32 %9, i32* %1, align 4, !dbg !255
  br label %10, !dbg !256

10:                                               ; preds = %6
  %11 = load i32, i32* %2, align 4, !dbg !257
  %12 = add nsw i32 %11, 1, !dbg !257
  store i32 %12, i32* %2, align 4, !dbg !257
  br label %3, !dbg !258, !llvm.loop !259

13:                                               ; preds = %3
  %14 = load i32, i32* %1, align 4, !dbg !261
  ret i32 %14, !dbg !262
}

; Function Attrs: noinline nounwind uwtable
define internal i32 @kernel_t3() #0 !dbg !263 {
  %1 = alloca i32, align 4
  %2 = alloca i32, align 4
  %3 = alloca i32, align 4
  call void @llvm.dbg.declare(metadata i32* %1, metadata !264, metadata !DIExpression()), !dbg !265
  store i32 0, i32* %1, align 4, !dbg !265
  call void @llvm.dbg.declare(metadata i32* %2, metadata !266, metadata !DIExpression()), !dbg !268
  store i32 0, i32* %2, align 4, !dbg !268
  br label %4, !dbg !269

4:                                                ; preds = %16, %0
  %5 = load i32, i32* %2, align 4, !dbg !270
  %6 = icmp slt i32 %5, 24, !dbg !272
  br i1 %6, label %7, label %19, !dbg !273

7:                                                ; preds = %4
  %8 = load i32, i32* %2, align 4, !dbg !274
  %9 = mul nsw i32 %8, 32, !dbg !275
  %10 = sext i32 %9 to i64, !dbg !276
  %11 = getelementptr inbounds [768 x i8], [768 x i8]* @data_t3, i64 0, i64 %10, !dbg !276
  %12 = load volatile i8, i8* %11, align 1, !dbg !276
  %13 = zext i8 %12 to i32, !dbg !276
  %14 = load i32, i32* %1, align 4, !dbg !277
  %15 = add i32 %14, %13, !dbg !277
  store i32 %15, i32* %1, align 4, !dbg !277
  br label %16, !dbg !278

16:                                               ; preds = %7
  %17 = load i32, i32* %2, align 4, !dbg !279
  %18 = add nsw i32 %17, 1, !dbg !279
  store i32 %18, i32* %2, align 4, !dbg !279
  br label %4, !dbg !280, !llvm.loop !281

19:                                               ; preds = %4
  call void @llvm.dbg.declare(metadata i32* %3, metadata !283, metadata !DIExpression()), !dbg !285
  store i32 0, i32* %3, align 4, !dbg !285
  br label %20, !dbg !286

20:                                               ; preds = %33, %19
  %21 = load i32, i32* %3, align 4, !dbg !287
  %22 = icmp slt i32 %21, 24, !dbg !289
  br i1 %22, label %23, label %36, !dbg !290

23:                                               ; preds = %20
  %24 = load i32, i32* %3, align 4, !dbg !291
  %25 = sub nsw i32 23, %24, !dbg !292
  %26 = mul nsw i32 %25, 32, !dbg !293
  %27 = sext i32 %26 to i64, !dbg !294
  %28 = getelementptr inbounds [768 x i8], [768 x i8]* @data_t3, i64 0, i64 %27, !dbg !294
  %29 = load volatile i8, i8* %28, align 1, !dbg !294
  %30 = zext i8 %29 to i32, !dbg !294
  %31 = load i32, i32* %1, align 4, !dbg !295
  %32 = add i32 %31, %30, !dbg !295
  store i32 %32, i32* %1, align 4, !dbg !295
  br label %33, !dbg !296

33:                                               ; preds = %23
  %34 = load i32, i32* %3, align 4, !dbg !297
  %35 = add nsw i32 %34, 1, !dbg !297
  store i32 %35, i32* %3, align 4, !dbg !297
  br label %20, !dbg !298, !llvm.loop !299

36:                                               ; preds = %20
  %37 = load i32, i32* %1, align 4, !dbg !301
  ret i32 %37, !dbg !302
}

; Function Attrs: noinline nounwind uwtable
define dso_local i32 @task_job_t4() #0 !dbg !303 {
  %1 = alloca i32, align 4
  %2 = alloca i32, align 4
  call void @llvm.dbg.declare(metadata i32* %1, metadata !304, metadata !DIExpression()), !dbg !305
  store i32 0, i32* %1, align 4, !dbg !305
  call void @llvm.dbg.declare(metadata i32* %2, metadata !306, metadata !DIExpression()), !dbg !308
  store i32 0, i32* %2, align 4, !dbg !308
  br label %3, !dbg !309

3:                                                ; preds = %10, %0
  %4 = load i32, i32* %2, align 4, !dbg !310
  %5 = icmp slt i32 %4, 2, !dbg !312
  br i1 %5, label %6, label %13, !dbg !313

6:                                                ; preds = %3
  %7 = call i32 @kernel_t4(), !dbg !314
  %8 = load i32, i32* %1, align 4, !dbg !315
  %9 = add i32 %8, %7, !dbg !315
  store i32 %9, i32* %1, align 4, !dbg !315
  br label %10, !dbg !316

10:                                               ; preds = %6
  %11 = load i32, i32* %2, align 4, !dbg !317
  %12 = add nsw i32 %11, 1, !dbg !317
  store i32 %12, i32* %2, align 4, !dbg !317
  br label %3, !dbg !318, !llvm.loop !319

13:                                               ; preds = %3
  %14 = load i32, i32* %1, align 4, !dbg !321
  ret i32 %14, !dbg !322
}

; Function Attrs: noinline nounwind uwtable
define internal i32 @kernel_t4() #0 !dbg !323 {
  %1 = alloca i32, align 4
  %2 = alloca i32, align 4
  call void @llvm.dbg.declare(metadata i32* %1, metadata !324, metadata !DIExpression()), !dbg !325
  store i32 0, i32* %1, align 4, !dbg !325
  call void @llvm.dbg.declare(metadata i32* %2, metadata !326, metadata !DIExpression()), !dbg !328
  store i32 0, i32* %2, align 4, !dbg !328
  br label %3, !dbg !329

3:                                                ; preds = %24, %0
  %4 = load i32, i32* %2, align 4, !dbg !330
  %5 = icmp slt i32 %4, 12, !dbg !332
  br i1 %5, label %6, label %27, !dbg !333

6:                                                ; preds = %3
  %7 = load i32, i32* %2, align 4, !dbg !334
  %8 = mul nsw i32 %7, 32, !dbg !336
  %9 = sext i32 %8 to i64, !dbg !337
  %10 = getelementptr inbounds [768 x i8], [768 x i8]* @data_t4, i64 0, i64 %9, !dbg !337
  %11 = load volatile i8, i8* %10, align 1, !dbg !337
  %12 = zext i8 %11 to i32, !dbg !337
  %13 = load i32, i32* %1, align 4, !dbg !338
  %14 = add i32 %13, %12, !dbg !338
  store i32 %14, i32* %1, align 4, !dbg !338
  %15 = load i32, i32* %2, align 4, !dbg !339
  %16 = sub nsw i32 23, %15, !dbg !340
  %17 = mul nsw i32 %16, 32, !dbg !341
  %18 = sext i32 %17 to i64, !dbg !342
  %19 = getelementptr inbounds [768 x i8], [768 x i8]* @data_t4, i64 0, i64 %18, !dbg !342
  %20 = load volatile i8, i8* %19, align 1, !dbg !342
  %21 = zext i8 %20 to i32, !dbg !342
  %22 = load i32, i32* %1, align 4, !dbg !343
  %23 = add i32 %22, %21, !dbg !343
  store i32 %23, i32* %1, align 4, !dbg !343
  br label %24, !dbg !344

24:                                               ; preds = %6
  %25 = load i32, i32* %2, align 4, !dbg !345
  %26 = add nsw i32 %25, 1, !dbg !345
  store i32 %26, i32* %2, align 4, !dbg !345
  br label %3, !dbg !346, !llvm.loop !347

27:                                               ; preds = %3
  %28 = load i32, i32* %1, align 4, !dbg !349
  ret i32 %28, !dbg !350
}

; Function Attrs: noinline nounwind uwtable
define dso_local i32 @task_job_t5() #0 !dbg !351 {
  %1 = alloca i32, align 4
  %2 = alloca i32, align 4
  call void @llvm.dbg.declare(metadata i32* %1, metadata !352, metadata !DIExpression()), !dbg !353
  store i32 0, i32* %1, align 4, !dbg !353
  call void @llvm.dbg.declare(metadata i32* %2, metadata !354, metadata !DIExpression()), !dbg !356
  store i32 0, i32* %2, align 4, !dbg !356
  br label %3, !dbg !357

3:                                                ; preds = %10, %0
  %4 = load i32, i32* %2, align 4, !dbg !358
  %5 = icmp slt i32 %4, 2, !dbg !360
  br i1 %5, label %6, label %13, !dbg !361

6:                                                ; preds = %3
  %7 = call i32 @kernel_t5(), !dbg !362
  %8 = load i32, i32* %1, align 4, !dbg !363
  %9 = add i32 %8, %7, !dbg !363
  store i32 %9, i32* %1, align 4, !dbg !363
  br label %10, !dbg !364

10:                                               ; preds = %6
  %11 = load i32, i32* %2, align 4, !dbg !365
  %12 = add nsw i32 %11, 1, !dbg !365
  store i32 %12, i32* %2, align 4, !dbg !365
  br label %3, !dbg !366, !llvm.loop !367

13:                                               ; preds = %3
  %14 = load i32, i32* %1, align 4, !dbg !369
  ret i32 %14, !dbg !370
}

; Function Attrs: noinline nounwind uwtable
define internal i32 @kernel_t5() #0 !dbg !371 {
  %1 = alloca i32, align 4
  %2 = alloca i32, align 4
  call void @llvm.dbg.declare(metadata i32* %1, metadata !372, metadata !DIExpression()), !dbg !373
  store i32 0, i32* %1, align 4, !dbg !373
  call void @llvm.dbg.declare(metadata i32* %2, metadata !374, metadata !DIExpression()), !dbg !376
  store i32 0, i32* %2, align 4, !dbg !376
  br label %3, !dbg !377

3:                                                ; preds = %20, %0
  %4 = load i32, i32* %2, align 4, !dbg !378
  %5 = icmp slt i32 %4, 23, !dbg !380
  br i1 %5, label %6, label %23, !dbg !381

6:                                                ; preds = %3
  %7 = load volatile i8, i8* getelementptr inbounds ([768 x i8], [768 x i8]* @data_t5, i64 0, i64 0), align 4096, !dbg !382
  %8 = zext i8 %7 to i32, !dbg !382
  %9 = load i32, i32* %1, align 4, !dbg !384
  %10 = add i32 %9, %8, !dbg !384
  store i32 %10, i32* %1, align 4, !dbg !384
  %11 = load i32, i32* %2, align 4, !dbg !385
  %12 = add nsw i32 %11, 1, !dbg !386
  %13 = mul nsw i32 %12, 32, !dbg !387
  %14 = sext i32 %13 to i64, !dbg !388
  %15 = getelementptr inbounds [768 x i8], [768 x i8]* @data_t5, i64 0, i64 %14, !dbg !388
  %16 = load volatile i8, i8* %15, align 1, !dbg !388
  %17 = zext i8 %16 to i32, !dbg !388
  %18 = load i32, i32* %1, align 4, !dbg !389
  %19 = add i32 %18, %17, !dbg !389
  store i32 %19, i32* %1, align 4, !dbg !389
  br label %20, !dbg !390

20:                                               ; preds = %6
  %21 = load i32, i32* %2, align 4, !dbg !391
  %22 = add nsw i32 %21, 1, !dbg !391
  store i32 %22, i32* %2, align 4, !dbg !391
  br label %3, !dbg !392, !llvm.loop !393

23:                                               ; preds = %3
  %24 = load i32, i32* %1, align 4, !dbg !395
  ret i32 %24, !dbg !396
}

; Function Attrs: noinline nounwind uwtable
define dso_local i32 @task_job_t6() #0 !dbg !397 {
  %1 = alloca i32, align 4
  %2 = alloca i32, align 4
  call void @llvm.dbg.declare(metadata i32* %1, metadata !398, metadata !DIExpression()), !dbg !399
  store i32 0, i32* %1, align 4, !dbg !399
  call void @llvm.dbg.declare(metadata i32* %2, metadata !400, metadata !DIExpression()), !dbg !402
  store i32 0, i32* %2, align 4, !dbg !402
  br label %3, !dbg !403

3:                                                ; preds = %10, %0
  %4 = load i32, i32* %2, align 4, !dbg !404
  %5 = icmp slt i32 %4, 2, !dbg !406
  br i1 %5, label %6, label %13, !dbg !407

6:                                                ; preds = %3
  %7 = call i32 @kernel_t6(), !dbg !408
  %8 = load i32, i32* %1, align 4, !dbg !409
  %9 = add i32 %8, %7, !dbg !409
  store i32 %9, i32* %1, align 4, !dbg !409
  br label %10, !dbg !410

10:                                               ; preds = %6
  %11 = load i32, i32* %2, align 4, !dbg !411
  %12 = add nsw i32 %11, 1, !dbg !411
  store i32 %12, i32* %2, align 4, !dbg !411
  br label %3, !dbg !412, !llvm.loop !413

13:                                               ; preds = %3
  %14 = load i32, i32* %1, align 4, !dbg !415
  ret i32 %14, !dbg !416
}

; Function Attrs: noinline nounwind uwtable
define internal i32 @kernel_t6() #0 !dbg !417 {
  %1 = alloca i32, align 4
  %2 = alloca i32, align 4
  %3 = alloca i32, align 4
  %4 = alloca i32, align 4
  call void @llvm.dbg.declare(metadata i32* %1, metadata !418, metadata !DIExpression()), !dbg !419
  store i32 0, i32* %1, align 4, !dbg !419
  call void @llvm.dbg.declare(metadata i32* %2, metadata !420, metadata !DIExpression()), !dbg !422
  store i32 0, i32* %2, align 4, !dbg !422
  br label %5, !dbg !423

5:                                                ; preds = %48, %0
  %6 = load i32, i32* %2, align 4, !dbg !424
  %7 = icmp slt i32 %6, 4, !dbg !426
  br i1 %7, label %8, label %51, !dbg !427

8:                                                ; preds = %5
  call void @llvm.dbg.declare(metadata i32* %3, metadata !428, metadata !DIExpression()), !dbg !431
  store i32 0, i32* %3, align 4, !dbg !431
  br label %9, !dbg !432

9:                                                ; preds = %24, %8
  %10 = load i32, i32* %3, align 4, !dbg !433
  %11 = icmp slt i32 %10, 6, !dbg !435
  br i1 %11, label %12, label %27, !dbg !436

12:                                               ; preds = %9
  %13 = load i32, i32* %2, align 4, !dbg !437
  %14 = mul nsw i32 %13, 6, !dbg !438
  %15 = load i32, i32* %3, align 4, !dbg !439
  %16 = add nsw i32 %14, %15, !dbg !440
  %17 = mul nsw i32 %16, 32, !dbg !441
  %18 = sext i32 %17 to i64, !dbg !442
  %19 = getelementptr inbounds [768 x i8], [768 x i8]* @data_t6, i64 0, i64 %18, !dbg !442
  %20 = load volatile i8, i8* %19, align 1, !dbg !442
  %21 = zext i8 %20 to i32, !dbg !442
  %22 = load i32, i32* %1, align 4, !dbg !443
  %23 = add i32 %22, %21, !dbg !443
  store i32 %23, i32* %1, align 4, !dbg !443
  br label %24, !dbg !444

24:                                               ; preds = %12
  %25 = load i32, i32* %3, align 4, !dbg !445
  %26 = add nsw i32 %25, 1, !dbg !445
  store i32 %26, i32* %3, align 4, !dbg !445
  br label %9, !dbg !446, !llvm.loop !447

27:                                               ; preds = %9
  call void @llvm.dbg.declare(metadata i32* %4, metadata !449, metadata !DIExpression()), !dbg !451
  store i32 0, i32* %4, align 4, !dbg !451
  br label %28, !dbg !452

28:                                               ; preds = %44, %27
  %29 = load i32, i32* %4, align 4, !dbg !453
  %30 = icmp slt i32 %29, 6, !dbg !455
  br i1 %30, label %31, label %47, !dbg !456

31:                                               ; preds = %28
  %32 = load i32, i32* %2, align 4, !dbg !457
  %33 = mul nsw i32 %32, 6, !dbg !458
  %34 = add nsw i32 %33, 5, !dbg !459
  %35 = load i32, i32* %4, align 4, !dbg !460
  %36 = sub nsw i32 %34, %35, !dbg !461
  %37 = mul nsw i32 %36, 32, !dbg !462
  %38 = sext i32 %37 to i64, !dbg !463
  %39 = getelementptr inbounds [768 x i8], [768 x i8]* @data_t6, i64 0, i64 %38, !dbg !463
  %40 = load volatile i8, i8* %39, align 1, !dbg !463
  %41 = zext i8 %40 to i32, !dbg !463
  %42 = load i32, i32* %1, align 4, !dbg !464
  %43 = add i32 %42, %41, !dbg !464
  store i32 %43, i32* %1, align 4, !dbg !464
  br label %44, !dbg !465

44:                                               ; preds = %31
  %45 = load i32, i32* %4, align 4, !dbg !466
  %46 = add nsw i32 %45, 1, !dbg !466
  store i32 %46, i32* %4, align 4, !dbg !466
  br label %28, !dbg !467, !llvm.loop !468

47:                                               ; preds = %28
  br label %48, !dbg !470

48:                                               ; preds = %47
  %49 = load i32, i32* %2, align 4, !dbg !471
  %50 = add nsw i32 %49, 1, !dbg !471
  store i32 %50, i32* %2, align 4, !dbg !471
  br label %5, !dbg !472, !llvm.loop !473

51:                                               ; preds = %5
  %52 = load i32, i32* %1, align 4, !dbg !475
  ret i32 %52, !dbg !476
}

; Function Attrs: noinline nounwind uwtable
define dso_local i32 @task_job_t7() #0 !dbg !477 {
  %1 = alloca i32, align 4
  %2 = alloca i32, align 4
  call void @llvm.dbg.declare(metadata i32* %1, metadata !478, metadata !DIExpression()), !dbg !479
  store i32 0, i32* %1, align 4, !dbg !479
  call void @llvm.dbg.declare(metadata i32* %2, metadata !480, metadata !DIExpression()), !dbg !482
  store i32 0, i32* %2, align 4, !dbg !482
  br label %3, !dbg !483

3:                                                ; preds = %10, %0
  %4 = load i32, i32* %2, align 4, !dbg !484
  %5 = icmp slt i32 %4, 2, !dbg !486
  br i1 %5, label %6, label %13, !dbg !487

6:                                                ; preds = %3
  %7 = call i32 @kernel_t7(), !dbg !488
  %8 = load i32, i32* %1, align 4, !dbg !489
  %9 = add i32 %8, %7, !dbg !489
  store i32 %9, i32* %1, align 4, !dbg !489
  br label %10, !dbg !490

10:                                               ; preds = %6
  %11 = load i32, i32* %2, align 4, !dbg !491
  %12 = add nsw i32 %11, 1, !dbg !491
  store i32 %12, i32* %2, align 4, !dbg !491
  br label %3, !dbg !492, !llvm.loop !493

13:                                               ; preds = %3
  %14 = load i32, i32* %1, align 4, !dbg !495
  ret i32 %14, !dbg !496
}

; Function Attrs: noinline nounwind uwtable
define internal i32 @kernel_t7() #0 !dbg !497 {
  %1 = alloca i32, align 4
  %2 = alloca i32, align 4
  %3 = alloca i32, align 4
  %4 = alloca i32, align 4
  %5 = alloca i32, align 4
  call void @llvm.dbg.declare(metadata i32* %1, metadata !498, metadata !DIExpression()), !dbg !499
  store i32 0, i32* %1, align 4, !dbg !499
  call void @llvm.dbg.declare(metadata i32* %2, metadata !500, metadata !DIExpression()), !dbg !502
  store i32 0, i32* %2, align 4, !dbg !502
  br label %6, !dbg !503

6:                                                ; preds = %54, %0
  %7 = load i32, i32* %2, align 4, !dbg !504
  %8 = icmp slt i32 %7, 3, !dbg !506
  br i1 %8, label %9, label %57, !dbg !507

9:                                                ; preds = %6
  call void @llvm.dbg.declare(metadata i32* %3, metadata !508, metadata !DIExpression()), !dbg !511
  store i32 0, i32* %3, align 4, !dbg !511
  br label %10, !dbg !512

10:                                               ; preds = %30, %9
  %11 = load i32, i32* %3, align 4, !dbg !513
  %12 = icmp slt i32 %11, 2, !dbg !515
  br i1 %12, label %13, label %33, !dbg !516

13:                                               ; preds = %10
  call void @llvm.dbg.declare(metadata i32* %4, metadata !517, metadata !DIExpression()), !dbg !519
  store i32 0, i32* %4, align 4, !dbg !519
  br label %14, !dbg !520

14:                                               ; preds = %26, %13
  %15 = load i32, i32* %4, align 4, !dbg !521
  %16 = icmp slt i32 %15, 6, !dbg !523
  br i1 %16, label %17, label %29, !dbg !524

17:                                               ; preds = %14
  %18 = load i32, i32* %4, align 4, !dbg !525
  %19 = mul nsw i32 %18, 32, !dbg !526
  %20 = sext i32 %19 to i64, !dbg !527
  %21 = getelementptr inbounds [768 x i8], [768 x i8]* @data_t7, i64 0, i64 %20, !dbg !527
  %22 = load volatile i8, i8* %21, align 1, !dbg !527
  %23 = zext i8 %22 to i32, !dbg !527
  %24 = load i32, i32* %1, align 4, !dbg !528
  %25 = add i32 %24, %23, !dbg !528
  store i32 %25, i32* %1, align 4, !dbg !528
  br label %26, !dbg !529

26:                                               ; preds = %17
  %27 = load i32, i32* %4, align 4, !dbg !530
  %28 = add nsw i32 %27, 1, !dbg !530
  store i32 %28, i32* %4, align 4, !dbg !530
  br label %14, !dbg !531, !llvm.loop !532

29:                                               ; preds = %14
  br label %30, !dbg !533

30:                                               ; preds = %29
  %31 = load i32, i32* %3, align 4, !dbg !534
  %32 = add nsw i32 %31, 1, !dbg !534
  store i32 %32, i32* %3, align 4, !dbg !534
  br label %10, !dbg !535, !llvm.loop !536

33:                                               ; preds = %10
  call void @llvm.dbg.declare(metadata i32* %5, metadata !538, metadata !DIExpression()), !dbg !540
  store i32 0, i32* %5, align 4, !dbg !540
  br label %34, !dbg !541

34:                                               ; preds = %50, %33
  %35 = load i32, i32* %5, align 4, !dbg !542
  %36 = icmp slt i32 %35, 6, !dbg !544
  br i1 %36, label %37, label %53, !dbg !545

37:                                               ; preds = %34
  %38 = load i32, i32* %2, align 4, !dbg !546
  %39 = add nsw i32 %38, 1, !dbg !547
  %40 = mul nsw i32 %39, 6, !dbg !548
  %41 = load i32, i32* %5, align 4, !dbg !549
  %42 = add nsw i32 %40, %41, !dbg !550
  %43 = mul nsw i32 %42, 32, !dbg !551
  %44 = sext i32 %43 to i64, !dbg !552
  %45 = getelementptr inbounds [768 x i8], [768 x i8]* @data_t7, i64 0, i64 %44, !dbg !552
  %46 = load volatile i8, i8* %45, align 1, !dbg !552
  %47 = zext i8 %46 to i32, !dbg !552
  %48 = load i32, i32* %1, align 4, !dbg !553
  %49 = add i32 %48, %47, !dbg !553
  store i32 %49, i32* %1, align 4, !dbg !553
  br label %50, !dbg !554

50:                                               ; preds = %37
  %51 = load i32, i32* %5, align 4, !dbg !555
  %52 = add nsw i32 %51, 1, !dbg !555
  store i32 %52, i32* %5, align 4, !dbg !555
  br label %34, !dbg !556, !llvm.loop !557

53:                                               ; preds = %34
  br label %54, !dbg !559

54:                                               ; preds = %53
  %55 = load i32, i32* %2, align 4, !dbg !560
  %56 = add nsw i32 %55, 1, !dbg !560
  store i32 %56, i32* %2, align 4, !dbg !560
  br label %6, !dbg !561, !llvm.loop !562

57:                                               ; preds = %6
  %58 = load i32, i32* %1, align 4, !dbg !564
  ret i32 %58, !dbg !565
}

; Function Attrs: noinline nounwind uwtable
define dso_local i32 @task_job_t8() #0 !dbg !566 {
  %1 = alloca i32, align 4
  %2 = alloca i32, align 4
  call void @llvm.dbg.declare(metadata i32* %1, metadata !567, metadata !DIExpression()), !dbg !568
  store i32 0, i32* %1, align 4, !dbg !568
  call void @llvm.dbg.declare(metadata i32* %2, metadata !569, metadata !DIExpression()), !dbg !571
  store i32 0, i32* %2, align 4, !dbg !571
  br label %3, !dbg !572

3:                                                ; preds = %10, %0
  %4 = load i32, i32* %2, align 4, !dbg !573
  %5 = icmp slt i32 %4, 2, !dbg !575
  br i1 %5, label %6, label %13, !dbg !576

6:                                                ; preds = %3
  %7 = call i32 @kernel_t8(), !dbg !577
  %8 = load i32, i32* %1, align 4, !dbg !578
  %9 = add i32 %8, %7, !dbg !578
  store i32 %9, i32* %1, align 4, !dbg !578
  br label %10, !dbg !579

10:                                               ; preds = %6
  %11 = load i32, i32* %2, align 4, !dbg !580
  %12 = add nsw i32 %11, 1, !dbg !580
  store i32 %12, i32* %2, align 4, !dbg !580
  br label %3, !dbg !581, !llvm.loop !582

13:                                               ; preds = %3
  %14 = load i32, i32* %1, align 4, !dbg !584
  ret i32 %14, !dbg !585
}

; Function Attrs: noinline nounwind uwtable
define internal i32 @kernel_t8() #0 !dbg !586 {
  %1 = alloca i32, align 4
  %2 = alloca i32, align 4
  %3 = alloca i32, align 4
  %4 = alloca i32, align 4
  %5 = alloca i32, align 4
  %6 = alloca i32, align 4
  %7 = alloca i32, align 4
  call void @llvm.dbg.declare(metadata i32* %1, metadata !587, metadata !DIExpression()), !dbg !588
  store i32 0, i32* %1, align 4, !dbg !588
  call void @llvm.dbg.declare(metadata i32* %2, metadata !589, metadata !DIExpression()), !dbg !591
  store i32 0, i32* %2, align 4, !dbg !591
  br label %8, !dbg !592

8:                                                ; preds = %21, %0
  %9 = load i32, i32* %2, align 4, !dbg !593
  %10 = icmp slt i32 %9, 8, !dbg !595
  br i1 %10, label %11, label %24, !dbg !596

11:                                               ; preds = %8
  %12 = load i32, i32* %2, align 4, !dbg !597
  %13 = add nsw i32 0, %12, !dbg !598
  %14 = mul nsw i32 %13, 32, !dbg !599
  %15 = sext i32 %14 to i64, !dbg !600
  %16 = getelementptr inbounds [768 x i8], [768 x i8]* @data_t8, i64 0, i64 %15, !dbg !600
  %17 = load volatile i8, i8* %16, align 1, !dbg !600
  %18 = zext i8 %17 to i32, !dbg !600
  %19 = load i32, i32* %1, align 4, !dbg !601
  %20 = add i32 %19, %18, !dbg !601
  store i32 %20, i32* %1, align 4, !dbg !601
  br label %21, !dbg !602

21:                                               ; preds = %11
  %22 = load i32, i32* %2, align 4, !dbg !603
  %23 = add nsw i32 %22, 1, !dbg !603
  store i32 %23, i32* %2, align 4, !dbg !603
  br label %8, !dbg !604, !llvm.loop !605

24:                                               ; preds = %8
  call void @llvm.dbg.declare(metadata i32* %3, metadata !607, metadata !DIExpression()), !dbg !609
  store i32 0, i32* %3, align 4, !dbg !609
  br label %25, !dbg !610

25:                                               ; preds = %38, %24
  %26 = load i32, i32* %3, align 4, !dbg !611
  %27 = icmp slt i32 %26, 8, !dbg !613
  br i1 %27, label %28, label %41, !dbg !614

28:                                               ; preds = %25
  %29 = load i32, i32* %3, align 4, !dbg !615
  %30 = add nsw i32 8, %29, !dbg !616
  %31 = mul nsw i32 %30, 32, !dbg !617
  %32 = sext i32 %31 to i64, !dbg !618
  %33 = getelementptr inbounds [768 x i8], [768 x i8]* @data_t8, i64 0, i64 %32, !dbg !618
  %34 = load volatile i8, i8* %33, align 1, !dbg !618
  %35 = zext i8 %34 to i32, !dbg !618
  %36 = load i32, i32* %1, align 4, !dbg !619
  %37 = add i32 %36, %35, !dbg !619
  store i32 %37, i32* %1, align 4, !dbg !619
  br label %38, !dbg !620

38:                                               ; preds = %28
  %39 = load i32, i32* %3, align 4, !dbg !621
  %40 = add nsw i32 %39, 1, !dbg !621
  store i32 %40, i32* %3, align 4, !dbg !621
  br label %25, !dbg !622, !llvm.loop !623

41:                                               ; preds = %25
  call void @llvm.dbg.declare(metadata i32* %4, metadata !625, metadata !DIExpression()), !dbg !627
  store i32 0, i32* %4, align 4, !dbg !627
  br label %42, !dbg !628

42:                                               ; preds = %55, %41
  %43 = load i32, i32* %4, align 4, !dbg !629
  %44 = icmp slt i32 %43, 8, !dbg !631
  br i1 %44, label %45, label %58, !dbg !632

45:                                               ; preds = %42
  %46 = load i32, i32* %4, align 4, !dbg !633
  %47 = add nsw i32 0, %46, !dbg !634
  %48 = mul nsw i32 %47, 32, !dbg !635
  %49 = sext i32 %48 to i64, !dbg !636
  %50 = getelementptr inbounds [768 x i8], [768 x i8]* @data_t8, i64 0, i64 %49, !dbg !636
  %51 = load volatile i8, i8* %50, align 1, !dbg !636
  %52 = zext i8 %51 to i32, !dbg !636
  %53 = load i32, i32* %1, align 4, !dbg !637
  %54 = add i32 %53, %52, !dbg !637
  store i32 %54, i32* %1, align 4, !dbg !637
  br label %55, !dbg !638

55:                                               ; preds = %45
  %56 = load i32, i32* %4, align 4, !dbg !639
  %57 = add nsw i32 %56, 1, !dbg !639
  store i32 %57, i32* %4, align 4, !dbg !639
  br label %42, !dbg !640, !llvm.loop !641

58:                                               ; preds = %42
  call void @llvm.dbg.declare(metadata i32* %5, metadata !643, metadata !DIExpression()), !dbg !645
  store i32 0, i32* %5, align 4, !dbg !645
  br label %59, !dbg !646

59:                                               ; preds = %72, %58
  %60 = load i32, i32* %5, align 4, !dbg !647
  %61 = icmp slt i32 %60, 8, !dbg !649
  br i1 %61, label %62, label %75, !dbg !650

62:                                               ; preds = %59
  %63 = load i32, i32* %5, align 4, !dbg !651
  %64 = add nsw i32 16, %63, !dbg !652
  %65 = mul nsw i32 %64, 32, !dbg !653
  %66 = sext i32 %65 to i64, !dbg !654
  %67 = getelementptr inbounds [768 x i8], [768 x i8]* @data_t8, i64 0, i64 %66, !dbg !654
  %68 = load volatile i8, i8* %67, align 1, !dbg !654
  %69 = zext i8 %68 to i32, !dbg !654
  %70 = load i32, i32* %1, align 4, !dbg !655
  %71 = add i32 %70, %69, !dbg !655
  store i32 %71, i32* %1, align 4, !dbg !655
  br label %72, !dbg !656

72:                                               ; preds = %62
  %73 = load i32, i32* %5, align 4, !dbg !657
  %74 = add nsw i32 %73, 1, !dbg !657
  store i32 %74, i32* %5, align 4, !dbg !657
  br label %59, !dbg !658, !llvm.loop !659

75:                                               ; preds = %59
  call void @llvm.dbg.declare(metadata i32* %6, metadata !661, metadata !DIExpression()), !dbg !663
  store i32 0, i32* %6, align 4, !dbg !663
  br label %76, !dbg !664

76:                                               ; preds = %89, %75
  %77 = load i32, i32* %6, align 4, !dbg !665
  %78 = icmp slt i32 %77, 8, !dbg !667
  br i1 %78, label %79, label %92, !dbg !668

79:                                               ; preds = %76
  %80 = load i32, i32* %6, align 4, !dbg !669
  %81 = add nsw i32 8, %80, !dbg !670
  %82 = mul nsw i32 %81, 32, !dbg !671
  %83 = sext i32 %82 to i64, !dbg !672
  %84 = getelementptr inbounds [768 x i8], [768 x i8]* @data_t8, i64 0, i64 %83, !dbg !672
  %85 = load volatile i8, i8* %84, align 1, !dbg !672
  %86 = zext i8 %85 to i32, !dbg !672
  %87 = load i32, i32* %1, align 4, !dbg !673
  %88 = add i32 %87, %86, !dbg !673
  store i32 %88, i32* %1, align 4, !dbg !673
  br label %89, !dbg !674

89:                                               ; preds = %79
  %90 = load i32, i32* %6, align 4, !dbg !675
  %91 = add nsw i32 %90, 1, !dbg !675
  store i32 %91, i32* %6, align 4, !dbg !675
  br label %76, !dbg !676, !llvm.loop !677

92:                                               ; preds = %76
  call void @llvm.dbg.declare(metadata i32* %7, metadata !679, metadata !DIExpression()), !dbg !681
  store i32 0, i32* %7, align 4, !dbg !681
  br label %93, !dbg !682

93:                                               ; preds = %106, %92
  %94 = load i32, i32* %7, align 4, !dbg !683
  %95 = icmp slt i32 %94, 8, !dbg !685
  br i1 %95, label %96, label %109, !dbg !686

96:                                               ; preds = %93
  %97 = load i32, i32* %7, align 4, !dbg !687
  %98 = add nsw i32 16, %97, !dbg !688
  %99 = mul nsw i32 %98, 32, !dbg !689
  %100 = sext i32 %99 to i64, !dbg !690
  %101 = getelementptr inbounds [768 x i8], [768 x i8]* @data_t8, i64 0, i64 %100, !dbg !690
  %102 = load volatile i8, i8* %101, align 1, !dbg !690
  %103 = zext i8 %102 to i32, !dbg !690
  %104 = load i32, i32* %1, align 4, !dbg !691
  %105 = add i32 %104, %103, !dbg !691
  store i32 %105, i32* %1, align 4, !dbg !691
  br label %106, !dbg !692

106:                                              ; preds = %96
  %107 = load i32, i32* %7, align 4, !dbg !693
  %108 = add nsw i32 %107, 1, !dbg !693
  store i32 %108, i32* %7, align 4, !dbg !693
  br label %93, !dbg !694, !llvm.loop !695

109:                                              ; preds = %93
  %110 = load i32, i32* %1, align 4, !dbg !697
  ret i32 %110, !dbg !698
}

; Function Attrs: noinline nounwind uwtable
define dso_local i32 @task_job_t9() #0 !dbg !699 {
  %1 = alloca i32, align 4
  %2 = alloca i32, align 4
  call void @llvm.dbg.declare(metadata i32* %1, metadata !700, metadata !DIExpression()), !dbg !701
  store i32 0, i32* %1, align 4, !dbg !701
  call void @llvm.dbg.declare(metadata i32* %2, metadata !702, metadata !DIExpression()), !dbg !704
  store i32 0, i32* %2, align 4, !dbg !704
  br label %3, !dbg !705

3:                                                ; preds = %10, %0
  %4 = load i32, i32* %2, align 4, !dbg !706
  %5 = icmp slt i32 %4, 2, !dbg !708
  br i1 %5, label %6, label %13, !dbg !709

6:                                                ; preds = %3
  %7 = call i32 @kernel_t9(), !dbg !710
  %8 = load i32, i32* %1, align 4, !dbg !711
  %9 = add i32 %8, %7, !dbg !711
  store i32 %9, i32* %1, align 4, !dbg !711
  br label %10, !dbg !712

10:                                               ; preds = %6
  %11 = load i32, i32* %2, align 4, !dbg !713
  %12 = add nsw i32 %11, 1, !dbg !713
  store i32 %12, i32* %2, align 4, !dbg !713
  br label %3, !dbg !714, !llvm.loop !715

13:                                               ; preds = %3
  %14 = load i32, i32* %1, align 4, !dbg !717
  ret i32 %14, !dbg !718
}

; Function Attrs: noinline nounwind uwtable
define internal i32 @kernel_t9() #0 !dbg !719 {
  %1 = alloca i32, align 4
  %2 = alloca i32, align 4
  %3 = alloca i32, align 4
  call void @llvm.dbg.declare(metadata i32* %1, metadata !720, metadata !DIExpression()), !dbg !721
  store i32 0, i32* %1, align 4, !dbg !721
  call void @llvm.dbg.declare(metadata i32* %2, metadata !722, metadata !DIExpression()), !dbg !724
  store i32 0, i32* %2, align 4, !dbg !724
  br label %4, !dbg !725

4:                                                ; preds = %17, %0
  %5 = load i32, i32* %2, align 4, !dbg !726
  %6 = icmp slt i32 %5, 6, !dbg !728
  br i1 %6, label %7, label %20, !dbg !729

7:                                                ; preds = %4
  %8 = load i32, i32* %2, align 4, !dbg !730
  %9 = mul nsw i32 4, %8, !dbg !731
  %10 = mul nsw i32 %9, 32, !dbg !732
  %11 = sext i32 %10 to i64, !dbg !733
  %12 = getelementptr inbounds [768 x i8], [768 x i8]* @data_t9, i64 0, i64 %11, !dbg !733
  %13 = load volatile i8, i8* %12, align 1, !dbg !733
  %14 = zext i8 %13 to i32, !dbg !733
  %15 = load i32, i32* %1, align 4, !dbg !734
  %16 = add i32 %15, %14, !dbg !734
  store i32 %16, i32* %1, align 4, !dbg !734
  br label %17, !dbg !735

17:                                               ; preds = %7
  %18 = load i32, i32* %2, align 4, !dbg !736
  %19 = add nsw i32 %18, 1, !dbg !736
  store i32 %19, i32* %2, align 4, !dbg !736
  br label %4, !dbg !737, !llvm.loop !738

20:                                               ; preds = %4
  call void @llvm.dbg.declare(metadata i32* %3, metadata !740, metadata !DIExpression()), !dbg !742
  store i32 0, i32* %3, align 4, !dbg !742
  br label %21, !dbg !743

21:                                               ; preds = %33, %20
  %22 = load i32, i32* %3, align 4, !dbg !744
  %23 = icmp slt i32 %22, 24, !dbg !746
  br i1 %23, label %24, label %36, !dbg !747

24:                                               ; preds = %21
  %25 = load i32, i32* %3, align 4, !dbg !748
  %26 = mul nsw i32 %25, 32, !dbg !749
  %27 = sext i32 %26 to i64, !dbg !750
  %28 = getelementptr inbounds [768 x i8], [768 x i8]* @data_t9, i64 0, i64 %27, !dbg !750
  %29 = load volatile i8, i8* %28, align 1, !dbg !750
  %30 = zext i8 %29 to i32, !dbg !750
  %31 = load i32, i32* %1, align 4, !dbg !751
  %32 = add i32 %31, %30, !dbg !751
  store i32 %32, i32* %1, align 4, !dbg !751
  br label %33, !dbg !752

33:                                               ; preds = %24
  %34 = load i32, i32* %3, align 4, !dbg !753
  %35 = add nsw i32 %34, 1, !dbg !753
  store i32 %35, i32* %3, align 4, !dbg !753
  br label %21, !dbg !754, !llvm.loop !755

36:                                               ; preds = %21
  %37 = load i32, i32* %1, align 4, !dbg !757
  ret i32 %37, !dbg !758
}

; Function Attrs: noinline nounwind uwtable
define dso_local void @workload_prepare() #0 !dbg !759 {
  %1 = alloca i32, align 4
  %2 = alloca i32, align 4
  %3 = alloca i32, align 4
  %4 = alloca i32, align 4
  %5 = alloca i32, align 4
  %6 = alloca i32, align 4
  %7 = alloca i32, align 4
  %8 = alloca i32, align 4
  %9 = alloca i32, align 4
  %10 = alloca i32, align 4
  call void @llvm.dbg.declare(metadata i32* %1, metadata !762, metadata !DIExpression()), !dbg !764
  store i32 0, i32* %1, align 4, !dbg !764
  br label %11, !dbg !765

11:                                               ; preds = %18, %0
  %12 = load i32, i32* %1, align 4, !dbg !766
  %13 = icmp slt i32 %12, 768, !dbg !768
  br i1 %13, label %14, label %21, !dbg !769

14:                                               ; preds = %11
  %15 = load i32, i32* %1, align 4, !dbg !770
  %16 = sext i32 %15 to i64, !dbg !771
  %17 = getelementptr inbounds [768 x i8], [768 x i8]* @data_t0, i64 0, i64 %16, !dbg !771
  store volatile i8 1, i8* %17, align 1, !dbg !772
  br label %18, !dbg !771

18:                                               ; preds = %14
  %19 = load i32, i32* %1, align 4, !dbg !773
  %20 = add nsw i32 %19, 1, !dbg !773
  store i32 %20, i32* %1, align 4, !dbg !773
  br label %11, !dbg !774, !llvm.loop !775

21:                                               ; preds = %11
  call void @llvm.dbg.declare(metadata i32* %2, metadata !777, metadata !DIExpression()), !dbg !779
  store i32 0, i32* %2, align 4, !dbg !779
  br label %22, !dbg !780

22:                                               ; preds = %29, %21
  %23 = load i32, i32* %2, align 4, !dbg !781
  %24 = icmp slt i32 %23, 768, !dbg !783
  br i1 %24, label %25, label %32, !dbg !784

25:                                               ; preds = %22
  %26 = load i32, i32* %2, align 4, !dbg !785
  %27 = sext i32 %26 to i64, !dbg !786
  %28 = getelementptr inbounds [768 x i8], [768 x i8]* @data_t1, i64 0, i64 %27, !dbg !786
  store volatile i8 1, i8* %28, align 1, !dbg !787
  br label %29, !dbg !786

29:                                               ; preds = %25
  %30 = load i32, i32* %2, align 4, !dbg !788
  %31 = add nsw i32 %30, 1, !dbg !788
  store i32 %31, i32* %2, align 4, !dbg !788
  br label %22, !dbg !789, !llvm.loop !790

32:                                               ; preds = %22
  call void @llvm.dbg.declare(metadata i32* %3, metadata !792, metadata !DIExpression()), !dbg !794
  store i32 0, i32* %3, align 4, !dbg !794
  br label %33, !dbg !795

33:                                               ; preds = %40, %32
  %34 = load i32, i32* %3, align 4, !dbg !796
  %35 = icmp slt i32 %34, 768, !dbg !798
  br i1 %35, label %36, label %43, !dbg !799

36:                                               ; preds = %33
  %37 = load i32, i32* %3, align 4, !dbg !800
  %38 = sext i32 %37 to i64, !dbg !801
  %39 = getelementptr inbounds [768 x i8], [768 x i8]* @data_t2, i64 0, i64 %38, !dbg !801
  store volatile i8 1, i8* %39, align 1, !dbg !802
  br label %40, !dbg !801

40:                                               ; preds = %36
  %41 = load i32, i32* %3, align 4, !dbg !803
  %42 = add nsw i32 %41, 1, !dbg !803
  store i32 %42, i32* %3, align 4, !dbg !803
  br label %33, !dbg !804, !llvm.loop !805

43:                                               ; preds = %33
  call void @llvm.dbg.declare(metadata i32* %4, metadata !807, metadata !DIExpression()), !dbg !809
  store i32 0, i32* %4, align 4, !dbg !809
  br label %44, !dbg !810

44:                                               ; preds = %51, %43
  %45 = load i32, i32* %4, align 4, !dbg !811
  %46 = icmp slt i32 %45, 768, !dbg !813
  br i1 %46, label %47, label %54, !dbg !814

47:                                               ; preds = %44
  %48 = load i32, i32* %4, align 4, !dbg !815
  %49 = sext i32 %48 to i64, !dbg !816
  %50 = getelementptr inbounds [768 x i8], [768 x i8]* @data_t3, i64 0, i64 %49, !dbg !816
  store volatile i8 1, i8* %50, align 1, !dbg !817
  br label %51, !dbg !816

51:                                               ; preds = %47
  %52 = load i32, i32* %4, align 4, !dbg !818
  %53 = add nsw i32 %52, 1, !dbg !818
  store i32 %53, i32* %4, align 4, !dbg !818
  br label %44, !dbg !819, !llvm.loop !820

54:                                               ; preds = %44
  call void @llvm.dbg.declare(metadata i32* %5, metadata !822, metadata !DIExpression()), !dbg !824
  store i32 0, i32* %5, align 4, !dbg !824
  br label %55, !dbg !825

55:                                               ; preds = %62, %54
  %56 = load i32, i32* %5, align 4, !dbg !826
  %57 = icmp slt i32 %56, 768, !dbg !828
  br i1 %57, label %58, label %65, !dbg !829

58:                                               ; preds = %55
  %59 = load i32, i32* %5, align 4, !dbg !830
  %60 = sext i32 %59 to i64, !dbg !831
  %61 = getelementptr inbounds [768 x i8], [768 x i8]* @data_t4, i64 0, i64 %60, !dbg !831
  store volatile i8 1, i8* %61, align 1, !dbg !832
  br label %62, !dbg !831

62:                                               ; preds = %58
  %63 = load i32, i32* %5, align 4, !dbg !833
  %64 = add nsw i32 %63, 1, !dbg !833
  store i32 %64, i32* %5, align 4, !dbg !833
  br label %55, !dbg !834, !llvm.loop !835

65:                                               ; preds = %55
  call void @llvm.dbg.declare(metadata i32* %6, metadata !837, metadata !DIExpression()), !dbg !839
  store i32 0, i32* %6, align 4, !dbg !839
  br label %66, !dbg !840

66:                                               ; preds = %73, %65
  %67 = load i32, i32* %6, align 4, !dbg !841
  %68 = icmp slt i32 %67, 768, !dbg !843
  br i1 %68, label %69, label %76, !dbg !844

69:                                               ; preds = %66
  %70 = load i32, i32* %6, align 4, !dbg !845
  %71 = sext i32 %70 to i64, !dbg !846
  %72 = getelementptr inbounds [768 x i8], [768 x i8]* @data_t5, i64 0, i64 %71, !dbg !846
  store volatile i8 1, i8* %72, align 1, !dbg !847
  br label %73, !dbg !846

73:                                               ; preds = %69
  %74 = load i32, i32* %6, align 4, !dbg !848
  %75 = add nsw i32 %74, 1, !dbg !848
  store i32 %75, i32* %6, align 4, !dbg !848
  br label %66, !dbg !849, !llvm.loop !850

76:                                               ; preds = %66
  call void @llvm.dbg.declare(metadata i32* %7, metadata !852, metadata !DIExpression()), !dbg !854
  store i32 0, i32* %7, align 4, !dbg !854
  br label %77, !dbg !855

77:                                               ; preds = %84, %76
  %78 = load i32, i32* %7, align 4, !dbg !856
  %79 = icmp slt i32 %78, 768, !dbg !858
  br i1 %79, label %80, label %87, !dbg !859

80:                                               ; preds = %77
  %81 = load i32, i32* %7, align 4, !dbg !860
  %82 = sext i32 %81 to i64, !dbg !861
  %83 = getelementptr inbounds [768 x i8], [768 x i8]* @data_t6, i64 0, i64 %82, !dbg !861
  store volatile i8 1, i8* %83, align 1, !dbg !862
  br label %84, !dbg !861

84:                                               ; preds = %80
  %85 = load i32, i32* %7, align 4, !dbg !863
  %86 = add nsw i32 %85, 1, !dbg !863
  store i32 %86, i32* %7, align 4, !dbg !863
  br label %77, !dbg !864, !llvm.loop !865

87:                                               ; preds = %77
  call void @llvm.dbg.declare(metadata i32* %8, metadata !867, metadata !DIExpression()), !dbg !869
  store i32 0, i32* %8, align 4, !dbg !869
  br label %88, !dbg !870

88:                                               ; preds = %95, %87
  %89 = load i32, i32* %8, align 4, !dbg !871
  %90 = icmp slt i32 %89, 768, !dbg !873
  br i1 %90, label %91, label %98, !dbg !874

91:                                               ; preds = %88
  %92 = load i32, i32* %8, align 4, !dbg !875
  %93 = sext i32 %92 to i64, !dbg !876
  %94 = getelementptr inbounds [768 x i8], [768 x i8]* @data_t7, i64 0, i64 %93, !dbg !876
  store volatile i8 1, i8* %94, align 1, !dbg !877
  br label %95, !dbg !876

95:                                               ; preds = %91
  %96 = load i32, i32* %8, align 4, !dbg !878
  %97 = add nsw i32 %96, 1, !dbg !878
  store i32 %97, i32* %8, align 4, !dbg !878
  br label %88, !dbg !879, !llvm.loop !880

98:                                               ; preds = %88
  call void @llvm.dbg.declare(metadata i32* %9, metadata !882, metadata !DIExpression()), !dbg !884
  store i32 0, i32* %9, align 4, !dbg !884
  br label %99, !dbg !885

99:                                               ; preds = %106, %98
  %100 = load i32, i32* %9, align 4, !dbg !886
  %101 = icmp slt i32 %100, 768, !dbg !888
  br i1 %101, label %102, label %109, !dbg !889

102:                                              ; preds = %99
  %103 = load i32, i32* %9, align 4, !dbg !890
  %104 = sext i32 %103 to i64, !dbg !891
  %105 = getelementptr inbounds [768 x i8], [768 x i8]* @data_t8, i64 0, i64 %104, !dbg !891
  store volatile i8 1, i8* %105, align 1, !dbg !892
  br label %106, !dbg !891

106:                                              ; preds = %102
  %107 = load i32, i32* %9, align 4, !dbg !893
  %108 = add nsw i32 %107, 1, !dbg !893
  store i32 %108, i32* %9, align 4, !dbg !893
  br label %99, !dbg !894, !llvm.loop !895

109:                                              ; preds = %99
  call void @llvm.dbg.declare(metadata i32* %10, metadata !897, metadata !DIExpression()), !dbg !899
  store i32 0, i32* %10, align 4, !dbg !899
  br label %110, !dbg !900

110:                                              ; preds = %117, %109
  %111 = load i32, i32* %10, align 4, !dbg !901
  %112 = icmp slt i32 %111, 768, !dbg !903
  br i1 %112, label %113, label %120, !dbg !904

113:                                              ; preds = %110
  %114 = load i32, i32* %10, align 4, !dbg !905
  %115 = sext i32 %114 to i64, !dbg !906
  %116 = getelementptr inbounds [768 x i8], [768 x i8]* @data_t9, i64 0, i64 %115, !dbg !906
  store volatile i8 1, i8* %116, align 1, !dbg !907
  br label %117, !dbg !906

117:                                              ; preds = %113
  %118 = load i32, i32* %10, align 4, !dbg !908
  %119 = add nsw i32 %118, 1, !dbg !908
  store i32 %119, i32* %10, align 4, !dbg !908
  br label %110, !dbg !909, !llvm.loop !910

120:                                              ; preds = %110
  ret void, !dbg !912
}

attributes #0 = { noinline nounwind uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { nofree nosync nounwind readnone speculatable willreturn }

!llvm.dbg.cu = !{!2}
!llvm.module.flags = !{!49, !50, !51, !52, !53, !54, !55}
!llvm.ident = !{!56}

!0 = !DIGlobalVariableExpression(var: !1, expr: !DIExpression())
!1 = distinct !DIGlobalVariable(name: "data_t0", scope: !2, file: !7, line: 9, type: !26, isLocal: false, isDefinition: true, align: 32768)
!2 = distinct !DICompileUnit(language: DW_LANG_C99, file: !3, producer: "Ubuntu clang version 14.0.0-1ubuntu1.1", isOptimized: false, runtimeVersion: 0, emissionKind: FullDebug, globals: !4, splitDebugInlining: false, nameTableKind: None)
!3 = !DIFile(filename: "/workspace/experiments/chaser/.cache/periodic-structures-correctness-v1/snapshot/source/workload.c", directory: "/workspace/experiments/chaser/.cache/periodic-structures-correctness-v1/snapshot/analysis", checksumkind: CSK_MD5, checksum: "4d7b1eaf736081dfb834ff5d0945ba3d")
!4 = !{!5, !20, !0, !24, !33, !35, !37, !39, !41, !43, !45, !47}
!5 = !DIGlobalVariableExpression(var: !6, expr: !DIExpression())
!6 = distinct !DIGlobalVariable(name: "workload_jobs", scope: !2, file: !7, line: 202, type: !8, isLocal: false, isDefinition: true)
!7 = !DIFile(filename: "source/workload.c", directory: "/workspace/experiments/chaser/.cache/periodic-structures-correctness-v1/snapshot", checksumkind: CSK_MD5, checksum: "4d7b1eaf736081dfb834ff5d0945ba3d")
!8 = !DICompositeType(tag: DW_TAG_array_type, baseType: !9, size: 640, elements: !18)
!9 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !10)
!10 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !11, size: 64)
!11 = !DISubroutineType(types: !12)
!12 = !{!13}
!13 = !DIDerivedType(tag: DW_TAG_typedef, name: "uint32_t", file: !14, line: 26, baseType: !15)
!14 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/stdint-uintn.h", directory: "", checksumkind: CSK_MD5, checksum: "2bf2ae53c58c01b1a1b9383b5195125c")
!15 = !DIDerivedType(tag: DW_TAG_typedef, name: "__uint32_t", file: !16, line: 42, baseType: !17)
!16 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/types.h", directory: "", checksumkind: CSK_MD5, checksum: "d108b5f93a74c50510d7d9bc0ab36df9")
!17 = !DIBasicType(name: "unsigned int", size: 32, encoding: DW_ATE_unsigned)
!18 = !{!19}
!19 = !DISubrange(count: 10)
!20 = !DIGlobalVariableExpression(var: !21, expr: !DIExpression())
!21 = distinct !DIGlobalVariable(name: "workload_expected", scope: !2, file: !7, line: 214, type: !22, isLocal: false, isDefinition: true)
!22 = !DICompositeType(tag: DW_TAG_array_type, baseType: !23, size: 320, elements: !18)
!23 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !13)
!24 = !DIGlobalVariableExpression(var: !25, expr: !DIExpression())
!25 = distinct !DIGlobalVariable(name: "data_t1", scope: !2, file: !7, line: 26, type: !26, isLocal: false, isDefinition: true, align: 32768)
!26 = !DICompositeType(tag: DW_TAG_array_type, baseType: !27, size: 6144, elements: !31)
!27 = !DIDerivedType(tag: DW_TAG_volatile_type, baseType: !28)
!28 = !DIDerivedType(tag: DW_TAG_typedef, name: "uint8_t", file: !14, line: 24, baseType: !29)
!29 = !DIDerivedType(tag: DW_TAG_typedef, name: "__uint8_t", file: !16, line: 38, baseType: !30)
!30 = !DIBasicType(name: "unsigned char", size: 8, encoding: DW_ATE_unsigned_char)
!31 = !{!32}
!32 = !DISubrange(count: 768)
!33 = !DIGlobalVariableExpression(var: !34, expr: !DIExpression())
!34 = distinct !DIGlobalVariable(name: "data_t2", scope: !2, file: !7, line: 42, type: !26, isLocal: false, isDefinition: true, align: 32768)
!35 = !DIGlobalVariableExpression(var: !36, expr: !DIExpression())
!36 = distinct !DIGlobalVariable(name: "data_t3", scope: !2, file: !7, line: 58, type: !26, isLocal: false, isDefinition: true, align: 32768)
!37 = !DIGlobalVariableExpression(var: !38, expr: !DIExpression())
!38 = distinct !DIGlobalVariable(name: "data_t4", scope: !2, file: !7, line: 75, type: !26, isLocal: false, isDefinition: true, align: 32768)
!39 = !DIGlobalVariableExpression(var: !40, expr: !DIExpression())
!40 = distinct !DIGlobalVariable(name: "data_t5", scope: !2, file: !7, line: 92, type: !26, isLocal: false, isDefinition: true, align: 32768)
!41 = !DIGlobalVariableExpression(var: !42, expr: !DIExpression())
!42 = distinct !DIGlobalVariable(name: "data_t6", scope: !2, file: !7, line: 109, type: !26, isLocal: false, isDefinition: true, align: 32768)
!43 = !DIGlobalVariableExpression(var: !44, expr: !DIExpression())
!44 = distinct !DIGlobalVariable(name: "data_t7", scope: !2, file: !7, line: 128, type: !26, isLocal: false, isDefinition: true, align: 32768)
!45 = !DIGlobalVariableExpression(var: !46, expr: !DIExpression())
!46 = distinct !DIGlobalVariable(name: "data_t8", scope: !2, file: !7, line: 148, type: !26, isLocal: false, isDefinition: true, align: 32768)
!47 = !DIGlobalVariableExpression(var: !48, expr: !DIExpression())
!48 = distinct !DIGlobalVariable(name: "data_t9", scope: !2, file: !7, line: 173, type: !26, isLocal: false, isDefinition: true, align: 32768)
!49 = !{i32 7, !"Dwarf Version", i32 5}
!50 = !{i32 2, !"Debug Info Version", i32 3}
!51 = !{i32 1, !"wchar_size", i32 4}
!52 = !{i32 7, !"PIC Level", i32 2}
!53 = !{i32 7, !"PIE Level", i32 2}
!54 = !{i32 7, !"uwtable", i32 1}
!55 = !{i32 7, !"frame-pointer", i32 2}
!56 = !{!"Ubuntu clang version 14.0.0-1ubuntu1.1"}
!57 = distinct !DISubprogram(name: "task_job_t0", scope: !7, file: !7, line: 20, type: !11, scopeLine: 20, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !2, retainedNodes: !58)
!58 = !{}
!59 = !DILocalVariable(name: "sum", scope: !57, file: !7, line: 21, type: !13)
!60 = !DILocation(line: 21, column: 14, scope: !57)
!61 = !DILocalVariable(name: "s", scope: !62, file: !7, line: 22, type: !63)
!62 = distinct !DILexicalBlock(scope: !57, file: !7, line: 22, column: 5)
!63 = !DIBasicType(name: "int", size: 32, encoding: DW_ATE_signed)
!64 = !DILocation(line: 22, column: 14, scope: !62)
!65 = !DILocation(line: 22, column: 10, scope: !62)
!66 = !DILocation(line: 22, column: 21, scope: !67)
!67 = distinct !DILexicalBlock(scope: !62, file: !7, line: 22, column: 5)
!68 = !DILocation(line: 22, column: 23, scope: !67)
!69 = !DILocation(line: 22, column: 5, scope: !62)
!70 = !DILocation(line: 23, column: 16, scope: !67)
!71 = !DILocation(line: 23, column: 13, scope: !67)
!72 = !DILocation(line: 23, column: 9, scope: !67)
!73 = !DILocation(line: 22, column: 28, scope: !67)
!74 = !DILocation(line: 22, column: 5, scope: !67)
!75 = distinct !{!75, !69, !76, !77}
!76 = !DILocation(line: 23, column: 26, scope: !62)
!77 = !{!"llvm.loop.mustprogress"}
!78 = !DILocation(line: 24, column: 12, scope: !57)
!79 = !DILocation(line: 24, column: 5, scope: !57)
!80 = distinct !DISubprogram(name: "kernel_t0", scope: !7, file: !7, line: 10, type: !11, scopeLine: 10, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition, unit: !2, retainedNodes: !58)
!81 = !DILocalVariable(name: "sum", scope: !80, file: !7, line: 11, type: !13)
!82 = !DILocation(line: 11, column: 14, scope: !80)
!83 = !DILocalVariable(name: "b", scope: !84, file: !7, line: 12, type: !63)
!84 = distinct !DILexicalBlock(scope: !80, file: !7, line: 12, column: 5)
!85 = !DILocation(line: 12, column: 14, scope: !84)
!86 = !DILocation(line: 12, column: 10, scope: !84)
!87 = !DILocation(line: 12, column: 21, scope: !88)
!88 = distinct !DILexicalBlock(scope: !84, file: !7, line: 12, column: 5)
!89 = !DILocation(line: 12, column: 23, scope: !88)
!90 = !DILocation(line: 12, column: 5, scope: !84)
!91 = !DILocalVariable(name: "r", scope: !92, file: !7, line: 13, type: !63)
!92 = distinct !DILexicalBlock(scope: !88, file: !7, line: 13, column: 9)
!93 = !DILocation(line: 13, column: 18, scope: !92)
!94 = !DILocation(line: 13, column: 14, scope: !92)
!95 = !DILocation(line: 13, column: 25, scope: !96)
!96 = distinct !DILexicalBlock(scope: !92, file: !7, line: 13, column: 9)
!97 = !DILocation(line: 13, column: 27, scope: !96)
!98 = !DILocation(line: 13, column: 9, scope: !92)
!99 = !DILocalVariable(name: "i", scope: !100, file: !7, line: 14, type: !63)
!100 = distinct !DILexicalBlock(scope: !96, file: !7, line: 14, column: 13)
!101 = !DILocation(line: 14, column: 22, scope: !100)
!102 = !DILocation(line: 14, column: 18, scope: !100)
!103 = !DILocation(line: 14, column: 29, scope: !104)
!104 = distinct !DILexicalBlock(scope: !100, file: !7, line: 14, column: 13)
!105 = !DILocation(line: 14, column: 31, scope: !104)
!106 = !DILocation(line: 14, column: 13, scope: !100)
!107 = !DILocation(line: 15, column: 33, scope: !104)
!108 = !DILocation(line: 15, column: 35, scope: !104)
!109 = !DILocation(line: 15, column: 41, scope: !104)
!110 = !DILocation(line: 15, column: 39, scope: !104)
!111 = !DILocation(line: 15, column: 44, scope: !104)
!112 = !DILocation(line: 15, column: 24, scope: !104)
!113 = !DILocation(line: 15, column: 21, scope: !104)
!114 = !DILocation(line: 15, column: 17, scope: !104)
!115 = !DILocation(line: 14, column: 36, scope: !104)
!116 = !DILocation(line: 14, column: 13, scope: !104)
!117 = distinct !{!117, !106, !118, !77}
!118 = !DILocation(line: 15, column: 48, scope: !100)
!119 = !DILocation(line: 13, column: 32, scope: !96)
!120 = !DILocation(line: 13, column: 9, scope: !96)
!121 = distinct !{!121, !98, !122, !77}
!122 = !DILocation(line: 15, column: 48, scope: !92)
!123 = !DILocation(line: 12, column: 28, scope: !88)
!124 = !DILocation(line: 12, column: 5, scope: !88)
!125 = distinct !{!125, !90, !126, !77}
!126 = !DILocation(line: 15, column: 48, scope: !84)
!127 = !DILocation(line: 16, column: 12, scope: !80)
!128 = !DILocation(line: 16, column: 5, scope: !80)
!129 = distinct !DISubprogram(name: "task_job_t1", scope: !7, file: !7, line: 36, type: !11, scopeLine: 36, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !2, retainedNodes: !58)
!130 = !DILocalVariable(name: "sum", scope: !129, file: !7, line: 37, type: !13)
!131 = !DILocation(line: 37, column: 14, scope: !129)
!132 = !DILocalVariable(name: "s", scope: !133, file: !7, line: 38, type: !63)
!133 = distinct !DILexicalBlock(scope: !129, file: !7, line: 38, column: 5)
!134 = !DILocation(line: 38, column: 14, scope: !133)
!135 = !DILocation(line: 38, column: 10, scope: !133)
!136 = !DILocation(line: 38, column: 21, scope: !137)
!137 = distinct !DILexicalBlock(scope: !133, file: !7, line: 38, column: 5)
!138 = !DILocation(line: 38, column: 23, scope: !137)
!139 = !DILocation(line: 38, column: 5, scope: !133)
!140 = !DILocation(line: 39, column: 16, scope: !137)
!141 = !DILocation(line: 39, column: 13, scope: !137)
!142 = !DILocation(line: 39, column: 9, scope: !137)
!143 = !DILocation(line: 38, column: 28, scope: !137)
!144 = !DILocation(line: 38, column: 5, scope: !137)
!145 = distinct !{!145, !139, !146, !77}
!146 = !DILocation(line: 39, column: 26, scope: !133)
!147 = !DILocation(line: 40, column: 12, scope: !129)
!148 = !DILocation(line: 40, column: 5, scope: !129)
!149 = distinct !DISubprogram(name: "kernel_t1", scope: !7, file: !7, line: 27, type: !11, scopeLine: 27, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition, unit: !2, retainedNodes: !58)
!150 = !DILocalVariable(name: "sum", scope: !149, file: !7, line: 28, type: !13)
!151 = !DILocation(line: 28, column: 14, scope: !149)
!152 = !DILocalVariable(name: "w", scope: !153, file: !7, line: 29, type: !63)
!153 = distinct !DILexicalBlock(scope: !149, file: !7, line: 29, column: 5)
!154 = !DILocation(line: 29, column: 14, scope: !153)
!155 = !DILocation(line: 29, column: 10, scope: !153)
!156 = !DILocation(line: 29, column: 21, scope: !157)
!157 = distinct !DILexicalBlock(scope: !153, file: !7, line: 29, column: 5)
!158 = !DILocation(line: 29, column: 23, scope: !157)
!159 = !DILocation(line: 29, column: 5, scope: !153)
!160 = !DILocalVariable(name: "i", scope: !161, file: !7, line: 30, type: !63)
!161 = distinct !DILexicalBlock(scope: !157, file: !7, line: 30, column: 9)
!162 = !DILocation(line: 30, column: 18, scope: !161)
!163 = !DILocation(line: 30, column: 14, scope: !161)
!164 = !DILocation(line: 30, column: 25, scope: !165)
!165 = distinct !DILexicalBlock(scope: !161, file: !7, line: 30, column: 9)
!166 = !DILocation(line: 30, column: 27, scope: !165)
!167 = !DILocation(line: 30, column: 9, scope: !161)
!168 = !DILocation(line: 31, column: 29, scope: !165)
!169 = !DILocation(line: 31, column: 31, scope: !165)
!170 = !DILocation(line: 31, column: 37, scope: !165)
!171 = !DILocation(line: 31, column: 35, scope: !165)
!172 = !DILocation(line: 31, column: 40, scope: !165)
!173 = !DILocation(line: 31, column: 20, scope: !165)
!174 = !DILocation(line: 31, column: 17, scope: !165)
!175 = !DILocation(line: 31, column: 13, scope: !165)
!176 = !DILocation(line: 30, column: 32, scope: !165)
!177 = !DILocation(line: 30, column: 9, scope: !165)
!178 = distinct !{!178, !167, !179, !77}
!179 = !DILocation(line: 31, column: 44, scope: !161)
!180 = !DILocation(line: 29, column: 28, scope: !157)
!181 = !DILocation(line: 29, column: 5, scope: !157)
!182 = distinct !{!182, !159, !183, !77}
!183 = !DILocation(line: 31, column: 44, scope: !153)
!184 = !DILocation(line: 32, column: 12, scope: !149)
!185 = !DILocation(line: 32, column: 5, scope: !149)
!186 = distinct !DISubprogram(name: "task_job_t2", scope: !7, file: !7, line: 52, type: !11, scopeLine: 52, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !2, retainedNodes: !58)
!187 = !DILocalVariable(name: "sum", scope: !186, file: !7, line: 53, type: !13)
!188 = !DILocation(line: 53, column: 14, scope: !186)
!189 = !DILocalVariable(name: "s", scope: !190, file: !7, line: 54, type: !63)
!190 = distinct !DILexicalBlock(scope: !186, file: !7, line: 54, column: 5)
!191 = !DILocation(line: 54, column: 14, scope: !190)
!192 = !DILocation(line: 54, column: 10, scope: !190)
!193 = !DILocation(line: 54, column: 21, scope: !194)
!194 = distinct !DILexicalBlock(scope: !190, file: !7, line: 54, column: 5)
!195 = !DILocation(line: 54, column: 23, scope: !194)
!196 = !DILocation(line: 54, column: 5, scope: !190)
!197 = !DILocation(line: 55, column: 16, scope: !194)
!198 = !DILocation(line: 55, column: 13, scope: !194)
!199 = !DILocation(line: 55, column: 9, scope: !194)
!200 = !DILocation(line: 54, column: 28, scope: !194)
!201 = !DILocation(line: 54, column: 5, scope: !194)
!202 = distinct !{!202, !196, !203, !77}
!203 = !DILocation(line: 55, column: 26, scope: !190)
!204 = !DILocation(line: 56, column: 12, scope: !186)
!205 = !DILocation(line: 56, column: 5, scope: !186)
!206 = distinct !DISubprogram(name: "kernel_t2", scope: !7, file: !7, line: 43, type: !11, scopeLine: 43, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition, unit: !2, retainedNodes: !58)
!207 = !DILocalVariable(name: "sum", scope: !206, file: !7, line: 44, type: !13)
!208 = !DILocation(line: 44, column: 14, scope: !206)
!209 = !DILocalVariable(name: "lane", scope: !210, file: !7, line: 45, type: !63)
!210 = distinct !DILexicalBlock(scope: !206, file: !7, line: 45, column: 5)
!211 = !DILocation(line: 45, column: 14, scope: !210)
!212 = !DILocation(line: 45, column: 10, scope: !210)
!213 = !DILocation(line: 45, column: 24, scope: !214)
!214 = distinct !DILexicalBlock(scope: !210, file: !7, line: 45, column: 5)
!215 = !DILocation(line: 45, column: 29, scope: !214)
!216 = !DILocation(line: 45, column: 5, scope: !210)
!217 = !DILocalVariable(name: "i", scope: !218, file: !7, line: 46, type: !63)
!218 = distinct !DILexicalBlock(scope: !214, file: !7, line: 46, column: 9)
!219 = !DILocation(line: 46, column: 18, scope: !218)
!220 = !DILocation(line: 46, column: 14, scope: !218)
!221 = !DILocation(line: 46, column: 25, scope: !222)
!222 = distinct !DILexicalBlock(scope: !218, file: !7, line: 46, column: 9)
!223 = !DILocation(line: 46, column: 27, scope: !222)
!224 = !DILocation(line: 46, column: 9, scope: !218)
!225 = !DILocation(line: 47, column: 29, scope: !222)
!226 = !DILocation(line: 47, column: 31, scope: !222)
!227 = !DILocation(line: 47, column: 37, scope: !222)
!228 = !DILocation(line: 47, column: 35, scope: !222)
!229 = !DILocation(line: 47, column: 43, scope: !222)
!230 = !DILocation(line: 47, column: 20, scope: !222)
!231 = !DILocation(line: 47, column: 17, scope: !222)
!232 = !DILocation(line: 47, column: 13, scope: !222)
!233 = !DILocation(line: 46, column: 32, scope: !222)
!234 = !DILocation(line: 46, column: 9, scope: !222)
!235 = distinct !{!235, !224, !236, !77}
!236 = !DILocation(line: 47, column: 47, scope: !218)
!237 = !DILocation(line: 45, column: 34, scope: !214)
!238 = !DILocation(line: 45, column: 5, scope: !214)
!239 = distinct !{!239, !216, !240, !77}
!240 = !DILocation(line: 47, column: 47, scope: !210)
!241 = !DILocation(line: 48, column: 12, scope: !206)
!242 = !DILocation(line: 48, column: 5, scope: !206)
!243 = distinct !DISubprogram(name: "task_job_t3", scope: !7, file: !7, line: 69, type: !11, scopeLine: 69, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !2, retainedNodes: !58)
!244 = !DILocalVariable(name: "sum", scope: !243, file: !7, line: 70, type: !13)
!245 = !DILocation(line: 70, column: 14, scope: !243)
!246 = !DILocalVariable(name: "s", scope: !247, file: !7, line: 71, type: !63)
!247 = distinct !DILexicalBlock(scope: !243, file: !7, line: 71, column: 5)
!248 = !DILocation(line: 71, column: 14, scope: !247)
!249 = !DILocation(line: 71, column: 10, scope: !247)
!250 = !DILocation(line: 71, column: 21, scope: !251)
!251 = distinct !DILexicalBlock(scope: !247, file: !7, line: 71, column: 5)
!252 = !DILocation(line: 71, column: 23, scope: !251)
!253 = !DILocation(line: 71, column: 5, scope: !247)
!254 = !DILocation(line: 72, column: 16, scope: !251)
!255 = !DILocation(line: 72, column: 13, scope: !251)
!256 = !DILocation(line: 72, column: 9, scope: !251)
!257 = !DILocation(line: 71, column: 28, scope: !251)
!258 = !DILocation(line: 71, column: 5, scope: !251)
!259 = distinct !{!259, !253, !260, !77}
!260 = !DILocation(line: 72, column: 26, scope: !247)
!261 = !DILocation(line: 73, column: 12, scope: !243)
!262 = !DILocation(line: 73, column: 5, scope: !243)
!263 = distinct !DISubprogram(name: "kernel_t3", scope: !7, file: !7, line: 59, type: !11, scopeLine: 59, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition, unit: !2, retainedNodes: !58)
!264 = !DILocalVariable(name: "sum", scope: !263, file: !7, line: 60, type: !13)
!265 = !DILocation(line: 60, column: 14, scope: !263)
!266 = !DILocalVariable(name: "i", scope: !267, file: !7, line: 61, type: !63)
!267 = distinct !DILexicalBlock(scope: !263, file: !7, line: 61, column: 5)
!268 = !DILocation(line: 61, column: 14, scope: !267)
!269 = !DILocation(line: 61, column: 10, scope: !267)
!270 = !DILocation(line: 61, column: 21, scope: !271)
!271 = distinct !DILexicalBlock(scope: !267, file: !7, line: 61, column: 5)
!272 = !DILocation(line: 61, column: 23, scope: !271)
!273 = !DILocation(line: 61, column: 5, scope: !267)
!274 = !DILocation(line: 62, column: 25, scope: !271)
!275 = !DILocation(line: 62, column: 28, scope: !271)
!276 = !DILocation(line: 62, column: 16, scope: !271)
!277 = !DILocation(line: 62, column: 13, scope: !271)
!278 = !DILocation(line: 62, column: 9, scope: !271)
!279 = !DILocation(line: 61, column: 29, scope: !271)
!280 = !DILocation(line: 61, column: 5, scope: !271)
!281 = distinct !{!281, !273, !282, !77}
!282 = !DILocation(line: 62, column: 32, scope: !267)
!283 = !DILocalVariable(name: "i", scope: !284, file: !7, line: 63, type: !63)
!284 = distinct !DILexicalBlock(scope: !263, file: !7, line: 63, column: 5)
!285 = !DILocation(line: 63, column: 14, scope: !284)
!286 = !DILocation(line: 63, column: 10, scope: !284)
!287 = !DILocation(line: 63, column: 21, scope: !288)
!288 = distinct !DILexicalBlock(scope: !284, file: !7, line: 63, column: 5)
!289 = !DILocation(line: 63, column: 23, scope: !288)
!290 = !DILocation(line: 63, column: 5, scope: !284)
!291 = !DILocation(line: 64, column: 30, scope: !288)
!292 = !DILocation(line: 64, column: 28, scope: !288)
!293 = !DILocation(line: 64, column: 33, scope: !288)
!294 = !DILocation(line: 64, column: 16, scope: !288)
!295 = !DILocation(line: 64, column: 13, scope: !288)
!296 = !DILocation(line: 64, column: 9, scope: !288)
!297 = !DILocation(line: 63, column: 29, scope: !288)
!298 = !DILocation(line: 63, column: 5, scope: !288)
!299 = distinct !{!299, !290, !300, !77}
!300 = !DILocation(line: 64, column: 37, scope: !284)
!301 = !DILocation(line: 65, column: 12, scope: !263)
!302 = !DILocation(line: 65, column: 5, scope: !263)
!303 = distinct !DISubprogram(name: "task_job_t4", scope: !7, file: !7, line: 86, type: !11, scopeLine: 86, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !2, retainedNodes: !58)
!304 = !DILocalVariable(name: "sum", scope: !303, file: !7, line: 87, type: !13)
!305 = !DILocation(line: 87, column: 14, scope: !303)
!306 = !DILocalVariable(name: "s", scope: !307, file: !7, line: 88, type: !63)
!307 = distinct !DILexicalBlock(scope: !303, file: !7, line: 88, column: 5)
!308 = !DILocation(line: 88, column: 14, scope: !307)
!309 = !DILocation(line: 88, column: 10, scope: !307)
!310 = !DILocation(line: 88, column: 21, scope: !311)
!311 = distinct !DILexicalBlock(scope: !307, file: !7, line: 88, column: 5)
!312 = !DILocation(line: 88, column: 23, scope: !311)
!313 = !DILocation(line: 88, column: 5, scope: !307)
!314 = !DILocation(line: 89, column: 16, scope: !311)
!315 = !DILocation(line: 89, column: 13, scope: !311)
!316 = !DILocation(line: 89, column: 9, scope: !311)
!317 = !DILocation(line: 88, column: 28, scope: !311)
!318 = !DILocation(line: 88, column: 5, scope: !311)
!319 = distinct !{!319, !313, !320, !77}
!320 = !DILocation(line: 89, column: 26, scope: !307)
!321 = !DILocation(line: 90, column: 12, scope: !303)
!322 = !DILocation(line: 90, column: 5, scope: !303)
!323 = distinct !DISubprogram(name: "kernel_t4", scope: !7, file: !7, line: 76, type: !11, scopeLine: 76, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition, unit: !2, retainedNodes: !58)
!324 = !DILocalVariable(name: "sum", scope: !323, file: !7, line: 77, type: !13)
!325 = !DILocation(line: 77, column: 14, scope: !323)
!326 = !DILocalVariable(name: "i", scope: !327, file: !7, line: 78, type: !63)
!327 = distinct !DILexicalBlock(scope: !323, file: !7, line: 78, column: 5)
!328 = !DILocation(line: 78, column: 14, scope: !327)
!329 = !DILocation(line: 78, column: 10, scope: !327)
!330 = !DILocation(line: 78, column: 21, scope: !331)
!331 = distinct !DILexicalBlock(scope: !327, file: !7, line: 78, column: 5)
!332 = !DILocation(line: 78, column: 23, scope: !331)
!333 = !DILocation(line: 78, column: 5, scope: !327)
!334 = !DILocation(line: 79, column: 25, scope: !335)
!335 = distinct !DILexicalBlock(scope: !331, file: !7, line: 78, column: 34)
!336 = !DILocation(line: 79, column: 28, scope: !335)
!337 = !DILocation(line: 79, column: 16, scope: !335)
!338 = !DILocation(line: 79, column: 13, scope: !335)
!339 = !DILocation(line: 80, column: 30, scope: !335)
!340 = !DILocation(line: 80, column: 28, scope: !335)
!341 = !DILocation(line: 80, column: 33, scope: !335)
!342 = !DILocation(line: 80, column: 16, scope: !335)
!343 = !DILocation(line: 80, column: 13, scope: !335)
!344 = !DILocation(line: 81, column: 5, scope: !335)
!345 = !DILocation(line: 78, column: 29, scope: !331)
!346 = !DILocation(line: 78, column: 5, scope: !331)
!347 = distinct !{!347, !333, !348, !77}
!348 = !DILocation(line: 81, column: 5, scope: !327)
!349 = !DILocation(line: 82, column: 12, scope: !323)
!350 = !DILocation(line: 82, column: 5, scope: !323)
!351 = distinct !DISubprogram(name: "task_job_t5", scope: !7, file: !7, line: 103, type: !11, scopeLine: 103, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !2, retainedNodes: !58)
!352 = !DILocalVariable(name: "sum", scope: !351, file: !7, line: 104, type: !13)
!353 = !DILocation(line: 104, column: 14, scope: !351)
!354 = !DILocalVariable(name: "s", scope: !355, file: !7, line: 105, type: !63)
!355 = distinct !DILexicalBlock(scope: !351, file: !7, line: 105, column: 5)
!356 = !DILocation(line: 105, column: 14, scope: !355)
!357 = !DILocation(line: 105, column: 10, scope: !355)
!358 = !DILocation(line: 105, column: 21, scope: !359)
!359 = distinct !DILexicalBlock(scope: !355, file: !7, line: 105, column: 5)
!360 = !DILocation(line: 105, column: 23, scope: !359)
!361 = !DILocation(line: 105, column: 5, scope: !355)
!362 = !DILocation(line: 106, column: 16, scope: !359)
!363 = !DILocation(line: 106, column: 13, scope: !359)
!364 = !DILocation(line: 106, column: 9, scope: !359)
!365 = !DILocation(line: 105, column: 28, scope: !359)
!366 = !DILocation(line: 105, column: 5, scope: !359)
!367 = distinct !{!367, !361, !368, !77}
!368 = !DILocation(line: 106, column: 26, scope: !355)
!369 = !DILocation(line: 107, column: 12, scope: !351)
!370 = !DILocation(line: 107, column: 5, scope: !351)
!371 = distinct !DISubprogram(name: "kernel_t5", scope: !7, file: !7, line: 93, type: !11, scopeLine: 93, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition, unit: !2, retainedNodes: !58)
!372 = !DILocalVariable(name: "sum", scope: !371, file: !7, line: 94, type: !13)
!373 = !DILocation(line: 94, column: 14, scope: !371)
!374 = !DILocalVariable(name: "i", scope: !375, file: !7, line: 95, type: !63)
!375 = distinct !DILexicalBlock(scope: !371, file: !7, line: 95, column: 5)
!376 = !DILocation(line: 95, column: 14, scope: !375)
!377 = !DILocation(line: 95, column: 10, scope: !375)
!378 = !DILocation(line: 95, column: 21, scope: !379)
!379 = distinct !DILexicalBlock(scope: !375, file: !7, line: 95, column: 5)
!380 = !DILocation(line: 95, column: 23, scope: !379)
!381 = !DILocation(line: 95, column: 5, scope: !375)
!382 = !DILocation(line: 96, column: 16, scope: !383)
!383 = distinct !DILexicalBlock(scope: !379, file: !7, line: 95, column: 34)
!384 = !DILocation(line: 96, column: 13, scope: !383)
!385 = !DILocation(line: 97, column: 25, scope: !383)
!386 = !DILocation(line: 97, column: 27, scope: !383)
!387 = !DILocation(line: 97, column: 32, scope: !383)
!388 = !DILocation(line: 97, column: 16, scope: !383)
!389 = !DILocation(line: 97, column: 13, scope: !383)
!390 = !DILocation(line: 98, column: 5, scope: !383)
!391 = !DILocation(line: 95, column: 29, scope: !379)
!392 = !DILocation(line: 95, column: 5, scope: !379)
!393 = distinct !{!393, !381, !394, !77}
!394 = !DILocation(line: 98, column: 5, scope: !375)
!395 = !DILocation(line: 99, column: 12, scope: !371)
!396 = !DILocation(line: 99, column: 5, scope: !371)
!397 = distinct !DISubprogram(name: "task_job_t6", scope: !7, file: !7, line: 122, type: !11, scopeLine: 122, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !2, retainedNodes: !58)
!398 = !DILocalVariable(name: "sum", scope: !397, file: !7, line: 123, type: !13)
!399 = !DILocation(line: 123, column: 14, scope: !397)
!400 = !DILocalVariable(name: "s", scope: !401, file: !7, line: 124, type: !63)
!401 = distinct !DILexicalBlock(scope: !397, file: !7, line: 124, column: 5)
!402 = !DILocation(line: 124, column: 14, scope: !401)
!403 = !DILocation(line: 124, column: 10, scope: !401)
!404 = !DILocation(line: 124, column: 21, scope: !405)
!405 = distinct !DILexicalBlock(scope: !401, file: !7, line: 124, column: 5)
!406 = !DILocation(line: 124, column: 23, scope: !405)
!407 = !DILocation(line: 124, column: 5, scope: !401)
!408 = !DILocation(line: 125, column: 16, scope: !405)
!409 = !DILocation(line: 125, column: 13, scope: !405)
!410 = !DILocation(line: 125, column: 9, scope: !405)
!411 = !DILocation(line: 124, column: 28, scope: !405)
!412 = !DILocation(line: 124, column: 5, scope: !405)
!413 = distinct !{!413, !407, !414, !77}
!414 = !DILocation(line: 125, column: 26, scope: !401)
!415 = !DILocation(line: 126, column: 12, scope: !397)
!416 = !DILocation(line: 126, column: 5, scope: !397)
!417 = distinct !DISubprogram(name: "kernel_t6", scope: !7, file: !7, line: 110, type: !11, scopeLine: 110, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition, unit: !2, retainedNodes: !58)
!418 = !DILocalVariable(name: "sum", scope: !417, file: !7, line: 111, type: !13)
!419 = !DILocation(line: 111, column: 14, scope: !417)
!420 = !DILocalVariable(name: "b", scope: !421, file: !7, line: 112, type: !63)
!421 = distinct !DILexicalBlock(scope: !417, file: !7, line: 112, column: 5)
!422 = !DILocation(line: 112, column: 14, scope: !421)
!423 = !DILocation(line: 112, column: 10, scope: !421)
!424 = !DILocation(line: 112, column: 21, scope: !425)
!425 = distinct !DILexicalBlock(scope: !421, file: !7, line: 112, column: 5)
!426 = !DILocation(line: 112, column: 23, scope: !425)
!427 = !DILocation(line: 112, column: 5, scope: !421)
!428 = !DILocalVariable(name: "i", scope: !429, file: !7, line: 113, type: !63)
!429 = distinct !DILexicalBlock(scope: !430, file: !7, line: 113, column: 9)
!430 = distinct !DILexicalBlock(scope: !425, file: !7, line: 112, column: 33)
!431 = !DILocation(line: 113, column: 18, scope: !429)
!432 = !DILocation(line: 113, column: 14, scope: !429)
!433 = !DILocation(line: 113, column: 25, scope: !434)
!434 = distinct !DILexicalBlock(scope: !429, file: !7, line: 113, column: 9)
!435 = !DILocation(line: 113, column: 27, scope: !434)
!436 = !DILocation(line: 113, column: 9, scope: !429)
!437 = !DILocation(line: 114, column: 29, scope: !434)
!438 = !DILocation(line: 114, column: 31, scope: !434)
!439 = !DILocation(line: 114, column: 37, scope: !434)
!440 = !DILocation(line: 114, column: 35, scope: !434)
!441 = !DILocation(line: 114, column: 40, scope: !434)
!442 = !DILocation(line: 114, column: 20, scope: !434)
!443 = !DILocation(line: 114, column: 17, scope: !434)
!444 = !DILocation(line: 114, column: 13, scope: !434)
!445 = !DILocation(line: 113, column: 32, scope: !434)
!446 = !DILocation(line: 113, column: 9, scope: !434)
!447 = distinct !{!447, !436, !448, !77}
!448 = !DILocation(line: 114, column: 44, scope: !429)
!449 = !DILocalVariable(name: "i", scope: !450, file: !7, line: 115, type: !63)
!450 = distinct !DILexicalBlock(scope: !430, file: !7, line: 115, column: 9)
!451 = !DILocation(line: 115, column: 18, scope: !450)
!452 = !DILocation(line: 115, column: 14, scope: !450)
!453 = !DILocation(line: 115, column: 25, scope: !454)
!454 = distinct !DILexicalBlock(scope: !450, file: !7, line: 115, column: 9)
!455 = !DILocation(line: 115, column: 27, scope: !454)
!456 = !DILocation(line: 115, column: 9, scope: !450)
!457 = !DILocation(line: 116, column: 29, scope: !454)
!458 = !DILocation(line: 116, column: 31, scope: !454)
!459 = !DILocation(line: 116, column: 35, scope: !454)
!460 = !DILocation(line: 116, column: 41, scope: !454)
!461 = !DILocation(line: 116, column: 39, scope: !454)
!462 = !DILocation(line: 116, column: 44, scope: !454)
!463 = !DILocation(line: 116, column: 20, scope: !454)
!464 = !DILocation(line: 116, column: 17, scope: !454)
!465 = !DILocation(line: 116, column: 13, scope: !454)
!466 = !DILocation(line: 115, column: 32, scope: !454)
!467 = !DILocation(line: 115, column: 9, scope: !454)
!468 = distinct !{!468, !456, !469, !77}
!469 = !DILocation(line: 116, column: 48, scope: !450)
!470 = !DILocation(line: 117, column: 5, scope: !430)
!471 = !DILocation(line: 112, column: 28, scope: !425)
!472 = !DILocation(line: 112, column: 5, scope: !425)
!473 = distinct !{!473, !427, !474, !77}
!474 = !DILocation(line: 117, column: 5, scope: !421)
!475 = !DILocation(line: 118, column: 12, scope: !417)
!476 = !DILocation(line: 118, column: 5, scope: !417)
!477 = distinct !DISubprogram(name: "task_job_t7", scope: !7, file: !7, line: 142, type: !11, scopeLine: 142, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !2, retainedNodes: !58)
!478 = !DILocalVariable(name: "sum", scope: !477, file: !7, line: 143, type: !13)
!479 = !DILocation(line: 143, column: 14, scope: !477)
!480 = !DILocalVariable(name: "s", scope: !481, file: !7, line: 144, type: !63)
!481 = distinct !DILexicalBlock(scope: !477, file: !7, line: 144, column: 5)
!482 = !DILocation(line: 144, column: 14, scope: !481)
!483 = !DILocation(line: 144, column: 10, scope: !481)
!484 = !DILocation(line: 144, column: 21, scope: !485)
!485 = distinct !DILexicalBlock(scope: !481, file: !7, line: 144, column: 5)
!486 = !DILocation(line: 144, column: 23, scope: !485)
!487 = !DILocation(line: 144, column: 5, scope: !481)
!488 = !DILocation(line: 145, column: 16, scope: !485)
!489 = !DILocation(line: 145, column: 13, scope: !485)
!490 = !DILocation(line: 145, column: 9, scope: !485)
!491 = !DILocation(line: 144, column: 28, scope: !485)
!492 = !DILocation(line: 144, column: 5, scope: !485)
!493 = distinct !{!493, !487, !494, !77}
!494 = !DILocation(line: 145, column: 26, scope: !481)
!495 = !DILocation(line: 146, column: 12, scope: !477)
!496 = !DILocation(line: 146, column: 5, scope: !477)
!497 = distinct !DISubprogram(name: "kernel_t7", scope: !7, file: !7, line: 129, type: !11, scopeLine: 129, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition, unit: !2, retainedNodes: !58)
!498 = !DILocalVariable(name: "sum", scope: !497, file: !7, line: 130, type: !13)
!499 = !DILocation(line: 130, column: 14, scope: !497)
!500 = !DILocalVariable(name: "b", scope: !501, file: !7, line: 131, type: !63)
!501 = distinct !DILexicalBlock(scope: !497, file: !7, line: 131, column: 5)
!502 = !DILocation(line: 131, column: 14, scope: !501)
!503 = !DILocation(line: 131, column: 10, scope: !501)
!504 = !DILocation(line: 131, column: 21, scope: !505)
!505 = distinct !DILexicalBlock(scope: !501, file: !7, line: 131, column: 5)
!506 = !DILocation(line: 131, column: 23, scope: !505)
!507 = !DILocation(line: 131, column: 5, scope: !501)
!508 = !DILocalVariable(name: "r", scope: !509, file: !7, line: 132, type: !63)
!509 = distinct !DILexicalBlock(scope: !510, file: !7, line: 132, column: 9)
!510 = distinct !DILexicalBlock(scope: !505, file: !7, line: 131, column: 33)
!511 = !DILocation(line: 132, column: 18, scope: !509)
!512 = !DILocation(line: 132, column: 14, scope: !509)
!513 = !DILocation(line: 132, column: 25, scope: !514)
!514 = distinct !DILexicalBlock(scope: !509, file: !7, line: 132, column: 9)
!515 = !DILocation(line: 132, column: 27, scope: !514)
!516 = !DILocation(line: 132, column: 9, scope: !509)
!517 = !DILocalVariable(name: "i", scope: !518, file: !7, line: 133, type: !63)
!518 = distinct !DILexicalBlock(scope: !514, file: !7, line: 133, column: 13)
!519 = !DILocation(line: 133, column: 22, scope: !518)
!520 = !DILocation(line: 133, column: 18, scope: !518)
!521 = !DILocation(line: 133, column: 29, scope: !522)
!522 = distinct !DILexicalBlock(scope: !518, file: !7, line: 133, column: 13)
!523 = !DILocation(line: 133, column: 31, scope: !522)
!524 = !DILocation(line: 133, column: 13, scope: !518)
!525 = !DILocation(line: 134, column: 33, scope: !522)
!526 = !DILocation(line: 134, column: 36, scope: !522)
!527 = !DILocation(line: 134, column: 24, scope: !522)
!528 = !DILocation(line: 134, column: 21, scope: !522)
!529 = !DILocation(line: 134, column: 17, scope: !522)
!530 = !DILocation(line: 133, column: 36, scope: !522)
!531 = !DILocation(line: 133, column: 13, scope: !522)
!532 = distinct !{!532, !524, !533, !77}
!533 = !DILocation(line: 134, column: 40, scope: !518)
!534 = !DILocation(line: 132, column: 32, scope: !514)
!535 = !DILocation(line: 132, column: 9, scope: !514)
!536 = distinct !{!536, !516, !537, !77}
!537 = !DILocation(line: 134, column: 40, scope: !509)
!538 = !DILocalVariable(name: "i", scope: !539, file: !7, line: 135, type: !63)
!539 = distinct !DILexicalBlock(scope: !510, file: !7, line: 135, column: 9)
!540 = !DILocation(line: 135, column: 18, scope: !539)
!541 = !DILocation(line: 135, column: 14, scope: !539)
!542 = !DILocation(line: 135, column: 25, scope: !543)
!543 = distinct !DILexicalBlock(scope: !539, file: !7, line: 135, column: 9)
!544 = !DILocation(line: 135, column: 27, scope: !543)
!545 = !DILocation(line: 135, column: 9, scope: !539)
!546 = !DILocation(line: 136, column: 30, scope: !543)
!547 = !DILocation(line: 136, column: 32, scope: !543)
!548 = !DILocation(line: 136, column: 37, scope: !543)
!549 = !DILocation(line: 136, column: 43, scope: !543)
!550 = !DILocation(line: 136, column: 41, scope: !543)
!551 = !DILocation(line: 136, column: 46, scope: !543)
!552 = !DILocation(line: 136, column: 20, scope: !543)
!553 = !DILocation(line: 136, column: 17, scope: !543)
!554 = !DILocation(line: 136, column: 13, scope: !543)
!555 = !DILocation(line: 135, column: 32, scope: !543)
!556 = !DILocation(line: 135, column: 9, scope: !543)
!557 = distinct !{!557, !545, !558, !77}
!558 = !DILocation(line: 136, column: 50, scope: !539)
!559 = !DILocation(line: 137, column: 5, scope: !510)
!560 = !DILocation(line: 131, column: 28, scope: !505)
!561 = !DILocation(line: 131, column: 5, scope: !505)
!562 = distinct !{!562, !507, !563, !77}
!563 = !DILocation(line: 137, column: 5, scope: !501)
!564 = !DILocation(line: 138, column: 12, scope: !497)
!565 = !DILocation(line: 138, column: 5, scope: !497)
!566 = distinct !DISubprogram(name: "task_job_t8", scope: !7, file: !7, line: 167, type: !11, scopeLine: 167, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !2, retainedNodes: !58)
!567 = !DILocalVariable(name: "sum", scope: !566, file: !7, line: 168, type: !13)
!568 = !DILocation(line: 168, column: 14, scope: !566)
!569 = !DILocalVariable(name: "s", scope: !570, file: !7, line: 169, type: !63)
!570 = distinct !DILexicalBlock(scope: !566, file: !7, line: 169, column: 5)
!571 = !DILocation(line: 169, column: 14, scope: !570)
!572 = !DILocation(line: 169, column: 10, scope: !570)
!573 = !DILocation(line: 169, column: 21, scope: !574)
!574 = distinct !DILexicalBlock(scope: !570, file: !7, line: 169, column: 5)
!575 = !DILocation(line: 169, column: 23, scope: !574)
!576 = !DILocation(line: 169, column: 5, scope: !570)
!577 = !DILocation(line: 170, column: 16, scope: !574)
!578 = !DILocation(line: 170, column: 13, scope: !574)
!579 = !DILocation(line: 170, column: 9, scope: !574)
!580 = !DILocation(line: 169, column: 28, scope: !574)
!581 = !DILocation(line: 169, column: 5, scope: !574)
!582 = distinct !{!582, !576, !583, !77}
!583 = !DILocation(line: 170, column: 26, scope: !570)
!584 = !DILocation(line: 171, column: 12, scope: !566)
!585 = !DILocation(line: 171, column: 5, scope: !566)
!586 = distinct !DISubprogram(name: "kernel_t8", scope: !7, file: !7, line: 149, type: !11, scopeLine: 149, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition, unit: !2, retainedNodes: !58)
!587 = !DILocalVariable(name: "sum", scope: !586, file: !7, line: 150, type: !13)
!588 = !DILocation(line: 150, column: 14, scope: !586)
!589 = !DILocalVariable(name: "i", scope: !590, file: !7, line: 151, type: !63)
!590 = distinct !DILexicalBlock(scope: !586, file: !7, line: 151, column: 5)
!591 = !DILocation(line: 151, column: 14, scope: !590)
!592 = !DILocation(line: 151, column: 10, scope: !590)
!593 = !DILocation(line: 151, column: 21, scope: !594)
!594 = distinct !DILexicalBlock(scope: !590, file: !7, line: 151, column: 5)
!595 = !DILocation(line: 151, column: 23, scope: !594)
!596 = !DILocation(line: 151, column: 5, scope: !590)
!597 = !DILocation(line: 152, column: 29, scope: !594)
!598 = !DILocation(line: 152, column: 27, scope: !594)
!599 = !DILocation(line: 152, column: 32, scope: !594)
!600 = !DILocation(line: 152, column: 16, scope: !594)
!601 = !DILocation(line: 152, column: 13, scope: !594)
!602 = !DILocation(line: 152, column: 9, scope: !594)
!603 = !DILocation(line: 151, column: 28, scope: !594)
!604 = !DILocation(line: 151, column: 5, scope: !594)
!605 = distinct !{!605, !596, !606, !77}
!606 = !DILocation(line: 152, column: 36, scope: !590)
!607 = !DILocalVariable(name: "i", scope: !608, file: !7, line: 153, type: !63)
!608 = distinct !DILexicalBlock(scope: !586, file: !7, line: 153, column: 5)
!609 = !DILocation(line: 153, column: 14, scope: !608)
!610 = !DILocation(line: 153, column: 10, scope: !608)
!611 = !DILocation(line: 153, column: 21, scope: !612)
!612 = distinct !DILexicalBlock(scope: !608, file: !7, line: 153, column: 5)
!613 = !DILocation(line: 153, column: 23, scope: !612)
!614 = !DILocation(line: 153, column: 5, scope: !608)
!615 = !DILocation(line: 154, column: 29, scope: !612)
!616 = !DILocation(line: 154, column: 27, scope: !612)
!617 = !DILocation(line: 154, column: 32, scope: !612)
!618 = !DILocation(line: 154, column: 16, scope: !612)
!619 = !DILocation(line: 154, column: 13, scope: !612)
!620 = !DILocation(line: 154, column: 9, scope: !612)
!621 = !DILocation(line: 153, column: 28, scope: !612)
!622 = !DILocation(line: 153, column: 5, scope: !612)
!623 = distinct !{!623, !614, !624, !77}
!624 = !DILocation(line: 154, column: 36, scope: !608)
!625 = !DILocalVariable(name: "i", scope: !626, file: !7, line: 155, type: !63)
!626 = distinct !DILexicalBlock(scope: !586, file: !7, line: 155, column: 5)
!627 = !DILocation(line: 155, column: 14, scope: !626)
!628 = !DILocation(line: 155, column: 10, scope: !626)
!629 = !DILocation(line: 155, column: 21, scope: !630)
!630 = distinct !DILexicalBlock(scope: !626, file: !7, line: 155, column: 5)
!631 = !DILocation(line: 155, column: 23, scope: !630)
!632 = !DILocation(line: 155, column: 5, scope: !626)
!633 = !DILocation(line: 156, column: 29, scope: !630)
!634 = !DILocation(line: 156, column: 27, scope: !630)
!635 = !DILocation(line: 156, column: 32, scope: !630)
!636 = !DILocation(line: 156, column: 16, scope: !630)
!637 = !DILocation(line: 156, column: 13, scope: !630)
!638 = !DILocation(line: 156, column: 9, scope: !630)
!639 = !DILocation(line: 155, column: 28, scope: !630)
!640 = !DILocation(line: 155, column: 5, scope: !630)
!641 = distinct !{!641, !632, !642, !77}
!642 = !DILocation(line: 156, column: 36, scope: !626)
!643 = !DILocalVariable(name: "i", scope: !644, file: !7, line: 157, type: !63)
!644 = distinct !DILexicalBlock(scope: !586, file: !7, line: 157, column: 5)
!645 = !DILocation(line: 157, column: 14, scope: !644)
!646 = !DILocation(line: 157, column: 10, scope: !644)
!647 = !DILocation(line: 157, column: 21, scope: !648)
!648 = distinct !DILexicalBlock(scope: !644, file: !7, line: 157, column: 5)
!649 = !DILocation(line: 157, column: 23, scope: !648)
!650 = !DILocation(line: 157, column: 5, scope: !644)
!651 = !DILocation(line: 158, column: 30, scope: !648)
!652 = !DILocation(line: 158, column: 28, scope: !648)
!653 = !DILocation(line: 158, column: 33, scope: !648)
!654 = !DILocation(line: 158, column: 16, scope: !648)
!655 = !DILocation(line: 158, column: 13, scope: !648)
!656 = !DILocation(line: 158, column: 9, scope: !648)
!657 = !DILocation(line: 157, column: 28, scope: !648)
!658 = !DILocation(line: 157, column: 5, scope: !648)
!659 = distinct !{!659, !650, !660, !77}
!660 = !DILocation(line: 158, column: 37, scope: !644)
!661 = !DILocalVariable(name: "i", scope: !662, file: !7, line: 159, type: !63)
!662 = distinct !DILexicalBlock(scope: !586, file: !7, line: 159, column: 5)
!663 = !DILocation(line: 159, column: 14, scope: !662)
!664 = !DILocation(line: 159, column: 10, scope: !662)
!665 = !DILocation(line: 159, column: 21, scope: !666)
!666 = distinct !DILexicalBlock(scope: !662, file: !7, line: 159, column: 5)
!667 = !DILocation(line: 159, column: 23, scope: !666)
!668 = !DILocation(line: 159, column: 5, scope: !662)
!669 = !DILocation(line: 160, column: 29, scope: !666)
!670 = !DILocation(line: 160, column: 27, scope: !666)
!671 = !DILocation(line: 160, column: 32, scope: !666)
!672 = !DILocation(line: 160, column: 16, scope: !666)
!673 = !DILocation(line: 160, column: 13, scope: !666)
!674 = !DILocation(line: 160, column: 9, scope: !666)
!675 = !DILocation(line: 159, column: 28, scope: !666)
!676 = !DILocation(line: 159, column: 5, scope: !666)
!677 = distinct !{!677, !668, !678, !77}
!678 = !DILocation(line: 160, column: 36, scope: !662)
!679 = !DILocalVariable(name: "i", scope: !680, file: !7, line: 161, type: !63)
!680 = distinct !DILexicalBlock(scope: !586, file: !7, line: 161, column: 5)
!681 = !DILocation(line: 161, column: 14, scope: !680)
!682 = !DILocation(line: 161, column: 10, scope: !680)
!683 = !DILocation(line: 161, column: 21, scope: !684)
!684 = distinct !DILexicalBlock(scope: !680, file: !7, line: 161, column: 5)
!685 = !DILocation(line: 161, column: 23, scope: !684)
!686 = !DILocation(line: 161, column: 5, scope: !680)
!687 = !DILocation(line: 162, column: 30, scope: !684)
!688 = !DILocation(line: 162, column: 28, scope: !684)
!689 = !DILocation(line: 162, column: 33, scope: !684)
!690 = !DILocation(line: 162, column: 16, scope: !684)
!691 = !DILocation(line: 162, column: 13, scope: !684)
!692 = !DILocation(line: 162, column: 9, scope: !684)
!693 = !DILocation(line: 161, column: 28, scope: !684)
!694 = !DILocation(line: 161, column: 5, scope: !684)
!695 = distinct !{!695, !686, !696, !77}
!696 = !DILocation(line: 162, column: 37, scope: !680)
!697 = !DILocation(line: 163, column: 12, scope: !586)
!698 = !DILocation(line: 163, column: 5, scope: !586)
!699 = distinct !DISubprogram(name: "task_job_t9", scope: !7, file: !7, line: 184, type: !11, scopeLine: 184, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !2, retainedNodes: !58)
!700 = !DILocalVariable(name: "sum", scope: !699, file: !7, line: 185, type: !13)
!701 = !DILocation(line: 185, column: 14, scope: !699)
!702 = !DILocalVariable(name: "s", scope: !703, file: !7, line: 186, type: !63)
!703 = distinct !DILexicalBlock(scope: !699, file: !7, line: 186, column: 5)
!704 = !DILocation(line: 186, column: 14, scope: !703)
!705 = !DILocation(line: 186, column: 10, scope: !703)
!706 = !DILocation(line: 186, column: 21, scope: !707)
!707 = distinct !DILexicalBlock(scope: !703, file: !7, line: 186, column: 5)
!708 = !DILocation(line: 186, column: 23, scope: !707)
!709 = !DILocation(line: 186, column: 5, scope: !703)
!710 = !DILocation(line: 187, column: 16, scope: !707)
!711 = !DILocation(line: 187, column: 13, scope: !707)
!712 = !DILocation(line: 187, column: 9, scope: !707)
!713 = !DILocation(line: 186, column: 28, scope: !707)
!714 = !DILocation(line: 186, column: 5, scope: !707)
!715 = distinct !{!715, !709, !716, !77}
!716 = !DILocation(line: 187, column: 26, scope: !703)
!717 = !DILocation(line: 188, column: 12, scope: !699)
!718 = !DILocation(line: 188, column: 5, scope: !699)
!719 = distinct !DISubprogram(name: "kernel_t9", scope: !7, file: !7, line: 174, type: !11, scopeLine: 174, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition, unit: !2, retainedNodes: !58)
!720 = !DILocalVariable(name: "sum", scope: !719, file: !7, line: 175, type: !13)
!721 = !DILocation(line: 175, column: 14, scope: !719)
!722 = !DILocalVariable(name: "i", scope: !723, file: !7, line: 176, type: !63)
!723 = distinct !DILexicalBlock(scope: !719, file: !7, line: 176, column: 5)
!724 = !DILocation(line: 176, column: 14, scope: !723)
!725 = !DILocation(line: 176, column: 10, scope: !723)
!726 = !DILocation(line: 176, column: 21, scope: !727)
!727 = distinct !DILexicalBlock(scope: !723, file: !7, line: 176, column: 5)
!728 = !DILocation(line: 176, column: 23, scope: !727)
!729 = !DILocation(line: 176, column: 5, scope: !723)
!730 = !DILocation(line: 177, column: 29, scope: !727)
!731 = !DILocation(line: 177, column: 27, scope: !727)
!732 = !DILocation(line: 177, column: 32, scope: !727)
!733 = !DILocation(line: 177, column: 16, scope: !727)
!734 = !DILocation(line: 177, column: 13, scope: !727)
!735 = !DILocation(line: 177, column: 9, scope: !727)
!736 = !DILocation(line: 176, column: 28, scope: !727)
!737 = !DILocation(line: 176, column: 5, scope: !727)
!738 = distinct !{!738, !729, !739, !77}
!739 = !DILocation(line: 177, column: 36, scope: !723)
!740 = !DILocalVariable(name: "i", scope: !741, file: !7, line: 178, type: !63)
!741 = distinct !DILexicalBlock(scope: !719, file: !7, line: 178, column: 5)
!742 = !DILocation(line: 178, column: 14, scope: !741)
!743 = !DILocation(line: 178, column: 10, scope: !741)
!744 = !DILocation(line: 178, column: 21, scope: !745)
!745 = distinct !DILexicalBlock(scope: !741, file: !7, line: 178, column: 5)
!746 = !DILocation(line: 178, column: 23, scope: !745)
!747 = !DILocation(line: 178, column: 5, scope: !741)
!748 = !DILocation(line: 179, column: 25, scope: !745)
!749 = !DILocation(line: 179, column: 28, scope: !745)
!750 = !DILocation(line: 179, column: 16, scope: !745)
!751 = !DILocation(line: 179, column: 13, scope: !745)
!752 = !DILocation(line: 179, column: 9, scope: !745)
!753 = !DILocation(line: 178, column: 29, scope: !745)
!754 = !DILocation(line: 178, column: 5, scope: !745)
!755 = distinct !{!755, !747, !756, !77}
!756 = !DILocation(line: 179, column: 32, scope: !741)
!757 = !DILocation(line: 180, column: 12, scope: !719)
!758 = !DILocation(line: 180, column: 5, scope: !719)
!759 = distinct !DISubprogram(name: "workload_prepare", scope: !7, file: !7, line: 190, type: !760, scopeLine: 190, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !2, retainedNodes: !58)
!760 = !DISubroutineType(types: !761)
!761 = !{null}
!762 = !DILocalVariable(name: "i", scope: !763, file: !7, line: 191, type: !63)
!763 = distinct !DILexicalBlock(scope: !759, file: !7, line: 191, column: 5)
!764 = !DILocation(line: 191, column: 14, scope: !763)
!765 = !DILocation(line: 191, column: 10, scope: !763)
!766 = !DILocation(line: 191, column: 21, scope: !767)
!767 = distinct !DILexicalBlock(scope: !763, file: !7, line: 191, column: 5)
!768 = !DILocation(line: 191, column: 23, scope: !767)
!769 = !DILocation(line: 191, column: 5, scope: !763)
!770 = !DILocation(line: 191, column: 43, scope: !767)
!771 = !DILocation(line: 191, column: 35, scope: !767)
!772 = !DILocation(line: 191, column: 46, scope: !767)
!773 = !DILocation(line: 191, column: 30, scope: !767)
!774 = !DILocation(line: 191, column: 5, scope: !767)
!775 = distinct !{!775, !769, !776, !77}
!776 = !DILocation(line: 191, column: 48, scope: !763)
!777 = !DILocalVariable(name: "i", scope: !778, file: !7, line: 192, type: !63)
!778 = distinct !DILexicalBlock(scope: !759, file: !7, line: 192, column: 5)
!779 = !DILocation(line: 192, column: 14, scope: !778)
!780 = !DILocation(line: 192, column: 10, scope: !778)
!781 = !DILocation(line: 192, column: 21, scope: !782)
!782 = distinct !DILexicalBlock(scope: !778, file: !7, line: 192, column: 5)
!783 = !DILocation(line: 192, column: 23, scope: !782)
!784 = !DILocation(line: 192, column: 5, scope: !778)
!785 = !DILocation(line: 192, column: 43, scope: !782)
!786 = !DILocation(line: 192, column: 35, scope: !782)
!787 = !DILocation(line: 192, column: 46, scope: !782)
!788 = !DILocation(line: 192, column: 30, scope: !782)
!789 = !DILocation(line: 192, column: 5, scope: !782)
!790 = distinct !{!790, !784, !791, !77}
!791 = !DILocation(line: 192, column: 48, scope: !778)
!792 = !DILocalVariable(name: "i", scope: !793, file: !7, line: 193, type: !63)
!793 = distinct !DILexicalBlock(scope: !759, file: !7, line: 193, column: 5)
!794 = !DILocation(line: 193, column: 14, scope: !793)
!795 = !DILocation(line: 193, column: 10, scope: !793)
!796 = !DILocation(line: 193, column: 21, scope: !797)
!797 = distinct !DILexicalBlock(scope: !793, file: !7, line: 193, column: 5)
!798 = !DILocation(line: 193, column: 23, scope: !797)
!799 = !DILocation(line: 193, column: 5, scope: !793)
!800 = !DILocation(line: 193, column: 43, scope: !797)
!801 = !DILocation(line: 193, column: 35, scope: !797)
!802 = !DILocation(line: 193, column: 46, scope: !797)
!803 = !DILocation(line: 193, column: 30, scope: !797)
!804 = !DILocation(line: 193, column: 5, scope: !797)
!805 = distinct !{!805, !799, !806, !77}
!806 = !DILocation(line: 193, column: 48, scope: !793)
!807 = !DILocalVariable(name: "i", scope: !808, file: !7, line: 194, type: !63)
!808 = distinct !DILexicalBlock(scope: !759, file: !7, line: 194, column: 5)
!809 = !DILocation(line: 194, column: 14, scope: !808)
!810 = !DILocation(line: 194, column: 10, scope: !808)
!811 = !DILocation(line: 194, column: 21, scope: !812)
!812 = distinct !DILexicalBlock(scope: !808, file: !7, line: 194, column: 5)
!813 = !DILocation(line: 194, column: 23, scope: !812)
!814 = !DILocation(line: 194, column: 5, scope: !808)
!815 = !DILocation(line: 194, column: 43, scope: !812)
!816 = !DILocation(line: 194, column: 35, scope: !812)
!817 = !DILocation(line: 194, column: 46, scope: !812)
!818 = !DILocation(line: 194, column: 30, scope: !812)
!819 = !DILocation(line: 194, column: 5, scope: !812)
!820 = distinct !{!820, !814, !821, !77}
!821 = !DILocation(line: 194, column: 48, scope: !808)
!822 = !DILocalVariable(name: "i", scope: !823, file: !7, line: 195, type: !63)
!823 = distinct !DILexicalBlock(scope: !759, file: !7, line: 195, column: 5)
!824 = !DILocation(line: 195, column: 14, scope: !823)
!825 = !DILocation(line: 195, column: 10, scope: !823)
!826 = !DILocation(line: 195, column: 21, scope: !827)
!827 = distinct !DILexicalBlock(scope: !823, file: !7, line: 195, column: 5)
!828 = !DILocation(line: 195, column: 23, scope: !827)
!829 = !DILocation(line: 195, column: 5, scope: !823)
!830 = !DILocation(line: 195, column: 43, scope: !827)
!831 = !DILocation(line: 195, column: 35, scope: !827)
!832 = !DILocation(line: 195, column: 46, scope: !827)
!833 = !DILocation(line: 195, column: 30, scope: !827)
!834 = !DILocation(line: 195, column: 5, scope: !827)
!835 = distinct !{!835, !829, !836, !77}
!836 = !DILocation(line: 195, column: 48, scope: !823)
!837 = !DILocalVariable(name: "i", scope: !838, file: !7, line: 196, type: !63)
!838 = distinct !DILexicalBlock(scope: !759, file: !7, line: 196, column: 5)
!839 = !DILocation(line: 196, column: 14, scope: !838)
!840 = !DILocation(line: 196, column: 10, scope: !838)
!841 = !DILocation(line: 196, column: 21, scope: !842)
!842 = distinct !DILexicalBlock(scope: !838, file: !7, line: 196, column: 5)
!843 = !DILocation(line: 196, column: 23, scope: !842)
!844 = !DILocation(line: 196, column: 5, scope: !838)
!845 = !DILocation(line: 196, column: 43, scope: !842)
!846 = !DILocation(line: 196, column: 35, scope: !842)
!847 = !DILocation(line: 196, column: 46, scope: !842)
!848 = !DILocation(line: 196, column: 30, scope: !842)
!849 = !DILocation(line: 196, column: 5, scope: !842)
!850 = distinct !{!850, !844, !851, !77}
!851 = !DILocation(line: 196, column: 48, scope: !838)
!852 = !DILocalVariable(name: "i", scope: !853, file: !7, line: 197, type: !63)
!853 = distinct !DILexicalBlock(scope: !759, file: !7, line: 197, column: 5)
!854 = !DILocation(line: 197, column: 14, scope: !853)
!855 = !DILocation(line: 197, column: 10, scope: !853)
!856 = !DILocation(line: 197, column: 21, scope: !857)
!857 = distinct !DILexicalBlock(scope: !853, file: !7, line: 197, column: 5)
!858 = !DILocation(line: 197, column: 23, scope: !857)
!859 = !DILocation(line: 197, column: 5, scope: !853)
!860 = !DILocation(line: 197, column: 43, scope: !857)
!861 = !DILocation(line: 197, column: 35, scope: !857)
!862 = !DILocation(line: 197, column: 46, scope: !857)
!863 = !DILocation(line: 197, column: 30, scope: !857)
!864 = !DILocation(line: 197, column: 5, scope: !857)
!865 = distinct !{!865, !859, !866, !77}
!866 = !DILocation(line: 197, column: 48, scope: !853)
!867 = !DILocalVariable(name: "i", scope: !868, file: !7, line: 198, type: !63)
!868 = distinct !DILexicalBlock(scope: !759, file: !7, line: 198, column: 5)
!869 = !DILocation(line: 198, column: 14, scope: !868)
!870 = !DILocation(line: 198, column: 10, scope: !868)
!871 = !DILocation(line: 198, column: 21, scope: !872)
!872 = distinct !DILexicalBlock(scope: !868, file: !7, line: 198, column: 5)
!873 = !DILocation(line: 198, column: 23, scope: !872)
!874 = !DILocation(line: 198, column: 5, scope: !868)
!875 = !DILocation(line: 198, column: 43, scope: !872)
!876 = !DILocation(line: 198, column: 35, scope: !872)
!877 = !DILocation(line: 198, column: 46, scope: !872)
!878 = !DILocation(line: 198, column: 30, scope: !872)
!879 = !DILocation(line: 198, column: 5, scope: !872)
!880 = distinct !{!880, !874, !881, !77}
!881 = !DILocation(line: 198, column: 48, scope: !868)
!882 = !DILocalVariable(name: "i", scope: !883, file: !7, line: 199, type: !63)
!883 = distinct !DILexicalBlock(scope: !759, file: !7, line: 199, column: 5)
!884 = !DILocation(line: 199, column: 14, scope: !883)
!885 = !DILocation(line: 199, column: 10, scope: !883)
!886 = !DILocation(line: 199, column: 21, scope: !887)
!887 = distinct !DILexicalBlock(scope: !883, file: !7, line: 199, column: 5)
!888 = !DILocation(line: 199, column: 23, scope: !887)
!889 = !DILocation(line: 199, column: 5, scope: !883)
!890 = !DILocation(line: 199, column: 43, scope: !887)
!891 = !DILocation(line: 199, column: 35, scope: !887)
!892 = !DILocation(line: 199, column: 46, scope: !887)
!893 = !DILocation(line: 199, column: 30, scope: !887)
!894 = !DILocation(line: 199, column: 5, scope: !887)
!895 = distinct !{!895, !889, !896, !77}
!896 = !DILocation(line: 199, column: 48, scope: !883)
!897 = !DILocalVariable(name: "i", scope: !898, file: !7, line: 200, type: !63)
!898 = distinct !DILexicalBlock(scope: !759, file: !7, line: 200, column: 5)
!899 = !DILocation(line: 200, column: 14, scope: !898)
!900 = !DILocation(line: 200, column: 10, scope: !898)
!901 = !DILocation(line: 200, column: 21, scope: !902)
!902 = distinct !DILexicalBlock(scope: !898, file: !7, line: 200, column: 5)
!903 = !DILocation(line: 200, column: 23, scope: !902)
!904 = !DILocation(line: 200, column: 5, scope: !898)
!905 = !DILocation(line: 200, column: 43, scope: !902)
!906 = !DILocation(line: 200, column: 35, scope: !902)
!907 = !DILocation(line: 200, column: 46, scope: !902)
!908 = !DILocation(line: 200, column: 30, scope: !902)
!909 = !DILocation(line: 200, column: 5, scope: !902)
!910 = distinct !{!910, !904, !911, !77}
!911 = !DILocation(line: 200, column: 48, scope: !898)
!912 = !DILocation(line: 201, column: 1, scope: !759)
