#include "workload.h"
#ifdef __clang__
#define ANALYZE __attribute__((annotate("ape.analyze")))
#define INLINE __attribute__((annotate("ape.inline")))
#else
#define ANALYZE
#define INLINE
#endif
volatile uint8_t data_t0[768] __attribute__((aligned(4096), section(".chaser_data.00")));
INLINE static uint32_t kernel_t0(void) {
    uint32_t sum = 0;
    for (int b = 0; b < 4; ++b)
        for (int r = 0; r < 2; ++r)
            for (int i = 0; i < 6; ++i)
                sum += data_t0[(b * 6 + i) * 32];
    return sum;
}
/** @brief Execute one fixed job without resetting data or cache.
 * @return Load-count checksum, modulo 2^32. */
ANALYZE uint32_t task_job_t0(void) {
    uint32_t sum = 0;
    for (int s = 0; s < 2; ++s)
        sum += kernel_t0();
    return sum;
}
volatile uint8_t data_t1[768] __attribute__((aligned(4096), section(".chaser_data.01")));
INLINE static uint32_t kernel_t1(void) {
    uint32_t sum = 0;
    for (int w = 0; w < 7; ++w)
        for (int i = 0; i < 6; ++i)
            sum += data_t1[(w * 3 + i) * 32];
    return sum;
}
/** @brief Execute one fixed job without resetting data or cache.
 * @return Load-count checksum, modulo 2^32. */
ANALYZE uint32_t task_job_t1(void) {
    uint32_t sum = 0;
    for (int s = 0; s < 2; ++s)
        sum += kernel_t1();
    return sum;
}
volatile uint8_t data_t2[768] __attribute__((aligned(4096), section(".chaser_data.02")));
INLINE static uint32_t kernel_t2(void) {
    uint32_t sum = 0;
    for (int lane = 0; lane < 3; ++lane)
        for (int i = 0; i < 8; ++i)
            sum += data_t2[(i * 3 + lane) * 32];
    return sum;
}
/** @brief Execute one fixed job without resetting data or cache.
 * @return Load-count checksum, modulo 2^32. */
ANALYZE uint32_t task_job_t2(void) {
    uint32_t sum = 0;
    for (int s = 0; s < 2; ++s)
        sum += kernel_t2();
    return sum;
}
volatile uint8_t data_t3[768] __attribute__((aligned(4096), section(".chaser_data.03")));
INLINE static uint32_t kernel_t3(void) {
    uint32_t sum = 0;
    for (int i = 0; i < 24; ++i)
        sum += data_t3[(i) * 32];
    for (int i = 0; i < 24; ++i)
        sum += data_t3[(23 - i) * 32];
    return sum;
}
/** @brief Execute one fixed job without resetting data or cache.
 * @return Load-count checksum, modulo 2^32. */
ANALYZE uint32_t task_job_t3(void) {
    uint32_t sum = 0;
    for (int s = 0; s < 2; ++s)
        sum += kernel_t3();
    return sum;
}
volatile uint8_t data_t4[768] __attribute__((aligned(4096), section(".chaser_data.04")));
INLINE static uint32_t kernel_t4(void) {
    uint32_t sum = 0;
    for (int i = 0; i < 12; ++i) {
        sum += data_t4[(i) * 32];
        sum += data_t4[(23 - i) * 32];
    }
    return sum;
}
/** @brief Execute one fixed job without resetting data or cache.
 * @return Load-count checksum, modulo 2^32. */
ANALYZE uint32_t task_job_t4(void) {
    uint32_t sum = 0;
    for (int s = 0; s < 2; ++s)
        sum += kernel_t4();
    return sum;
}
volatile uint8_t data_t5[768] __attribute__((aligned(4096), section(".chaser_data.05")));
INLINE static uint32_t kernel_t5(void) {
    uint32_t sum = 0;
    for (int i = 0; i < 23; ++i) {
        sum += data_t5[(0) * 32];
        sum += data_t5[(i + 1) * 32];
    }
    return sum;
}
/** @brief Execute one fixed job without resetting data or cache.
 * @return Load-count checksum, modulo 2^32. */
ANALYZE uint32_t task_job_t5(void) {
    uint32_t sum = 0;
    for (int s = 0; s < 2; ++s)
        sum += kernel_t5();
    return sum;
}
volatile uint8_t data_t6[768] __attribute__((aligned(4096), section(".chaser_data.06")));
INLINE static uint32_t kernel_t6(void) {
    uint32_t sum = 0;
    for (int b = 0; b < 4; ++b) {
        for (int i = 0; i < 6; ++i)
            sum += data_t6[(b * 6 + i) * 32];
        for (int i = 0; i < 6; ++i)
            sum += data_t6[(b * 6 + 5 - i) * 32];
    }
    return sum;
}
/** @brief Execute one fixed job without resetting data or cache.
 * @return Load-count checksum, modulo 2^32. */
ANALYZE uint32_t task_job_t6(void) {
    uint32_t sum = 0;
    for (int s = 0; s < 2; ++s)
        sum += kernel_t6();
    return sum;
}
volatile uint8_t data_t7[768] __attribute__((aligned(4096), section(".chaser_data.07")));
INLINE static uint32_t kernel_t7(void) {
    uint32_t sum = 0;
    for (int b = 0; b < 3; ++b) {
        for (int r = 0; r < 2; ++r)
            for (int i = 0; i < 6; ++i)
                sum += data_t7[(i) * 32];
        for (int i = 0; i < 6; ++i)
            sum += data_t7[((b + 1) * 6 + i) * 32];
    }
    return sum;
}
/** @brief Execute one fixed job without resetting data or cache.
 * @return Load-count checksum, modulo 2^32. */
ANALYZE uint32_t task_job_t7(void) {
    uint32_t sum = 0;
    for (int s = 0; s < 2; ++s)
        sum += kernel_t7();
    return sum;
}
volatile uint8_t data_t8[768] __attribute__((aligned(4096), section(".chaser_data.08")));
INLINE static uint32_t kernel_t8(void) {
    uint32_t sum = 0;
    for (int i = 0; i < 8; ++i)
        sum += data_t8[(0 + i) * 32];
    for (int i = 0; i < 8; ++i)
        sum += data_t8[(8 + i) * 32];
    for (int i = 0; i < 8; ++i)
        sum += data_t8[(0 + i) * 32];
    for (int i = 0; i < 8; ++i)
        sum += data_t8[(16 + i) * 32];
    for (int i = 0; i < 8; ++i)
        sum += data_t8[(8 + i) * 32];
    for (int i = 0; i < 8; ++i)
        sum += data_t8[(16 + i) * 32];
    return sum;
}
/** @brief Execute one fixed job without resetting data or cache.
 * @return Load-count checksum, modulo 2^32. */
ANALYZE uint32_t task_job_t8(void) {
    uint32_t sum = 0;
    for (int s = 0; s < 2; ++s)
        sum += kernel_t8();
    return sum;
}
volatile uint8_t data_t9[768] __attribute__((aligned(4096), section(".chaser_data.09")));
INLINE static uint32_t kernel_t9(void) {
    uint32_t sum = 0;
    for (int i = 0; i < 6; ++i)
        sum += data_t9[(4 * i) * 32];
    for (int i = 0; i < 24; ++i)
        sum += data_t9[(i) * 32];
    return sum;
}
/** @brief Execute one fixed job without resetting data or cache.
 * @return Load-count checksum, modulo 2^32. */
ANALYZE uint32_t task_job_t9(void) {
    uint32_t sum = 0;
    for (int s = 0; s < 2; ++s)
        sum += kernel_t9();
    return sum;
}
void workload_prepare(void) {
    for (int i = 0; i < 768; ++i) data_t0[i] = 1;
    for (int i = 0; i < 768; ++i) data_t1[i] = 1;
    for (int i = 0; i < 768; ++i) data_t2[i] = 1;
    for (int i = 0; i < 768; ++i) data_t3[i] = 1;
    for (int i = 0; i < 768; ++i) data_t4[i] = 1;
    for (int i = 0; i < 768; ++i) data_t5[i] = 1;
    for (int i = 0; i < 768; ++i) data_t6[i] = 1;
    for (int i = 0; i < 768; ++i) data_t7[i] = 1;
    for (int i = 0; i < 768; ++i) data_t8[i] = 1;
    for (int i = 0; i < 768; ++i) data_t9[i] = 1;
}
uint32_t (*const workload_jobs[])(void) = {
    task_job_t0,
    task_job_t1,
    task_job_t2,
    task_job_t3,
    task_job_t4,
    task_job_t5,
    task_job_t6,
    task_job_t7,
    task_job_t8,
    task_job_t9,
};
const uint32_t workload_expected[] = {
96U, 84U, 48U, 96U, 48U, 92U, 96U, 108U, 96U, 60U
};
