#define TASK_COUNT 10
#define MAX_JOBS 2
#define ARCHITECTURE 1
#define CHASER_CONTRACT_ID "chaser-periodic-measurement-v2"
#define CHASER_PLAN_HASH "d9e715e8e27311f7777f414541205d54ecdb3df1e8d6b69069cd79474ce118b6"
#define CHASER_PERIODS {20, 20, 20, 20, 20, 20, 20, 20, 20, 20}
#define CHASER_JOB_COUNTS {2, 2, 2, 2, 2, 2, 2, 2, 2, 2}
#define CHASER_CORES {0, 1, 2, 3, 0, 1, 2, 3, 0, 1}
