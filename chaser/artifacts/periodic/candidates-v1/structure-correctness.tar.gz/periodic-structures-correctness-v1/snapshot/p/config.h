#define TASK_COUNT 10
#define MAX_JOBS 2
#define ARCHITECTURE 2
#define CHASER_CONTRACT_ID "chaser-periodic-measurement-v2"
#define CHASER_PLAN_HASH "571165842bb18fe95429d0d4c894d4ef13489293273ff8b10aac818dc431d1f4"
#define CHASER_PERIODS {20, 20, 20, 20, 20, 20, 20, 20, 20, 20}
#define CHASER_JOB_COUNTS {2, 2, 2, 2, 2, 2, 2, 2, 2, 2}
#define CHASER_CORES {0, 1, 2, 3, 0, 1, 2, 3, 0, 1}
