; ModuleID = 'workload.ll'
source_filename = "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/triangular-20260929/suite/gramschmidt/source/workload.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

%struct._IO_FILE = type { i32, i8*, i8*, i8*, i8*, i8*, i8*, i8*, i8*, i8*, i8*, i8*, %struct._IO_marker*, %struct._IO_FILE*, i32, i32, i64, i16, i8, [1 x i8], i8*, i64, %struct._IO_codecvt*, %struct._IO_wide_data*, %struct._IO_FILE*, i8*, i64, i32, [20 x i8] }
%struct._IO_marker = type opaque
%struct._IO_codecvt = type opaque
%struct._IO_wide_data = type opaque
%struct.__va_list_tag = type { i32, i32, i8*, i8* }

@m = dso_local global i32 200, align 4, !dbg !0
@n = dso_local global i32 240, align 4, !dbg !9
@A = dso_local global [200 x [240 x double]] zeroinitializer, section ".chaser_data.A", align 64, !dbg !33
@R = dso_local global [240 x [240 x double]] zeroinitializer, section ".chaser_data.R", align 64, !dbg !39
@Q = dso_local global [200 x [240 x double]] zeroinitializer, section ".chaser_data.Q", align 64, !dbg !43
@.str = private unnamed_addr constant [12 x i8] c"ape.analyze\00", section "llvm.metadata"
@.str.1 = private unnamed_addr constant [126 x i8] c"/workspace/experiments-array-support/chaser/.cache/periodic-polybench/triangular-20260929/suite/gramschmidt/source/workload.c\00", section "llvm.metadata"
@pb_hash = internal global i32 0, align 4, !dbg !30
@workload_jobs = dso_local constant [1 x i32 ()*] [i32 ()* @task_job_polybench], align 8, !dbg !13
@workload_expected = dso_local constant [1 x i32] [i32 -932879858], align 4, !dbg !26
@stderr = external global %struct._IO_FILE*, align 8
@.str.2 = private unnamed_addr constant [23 x i8] c"==BEGIN DUMP_ARRAYS==\0A\00", align 1
@.str.3 = private unnamed_addr constant [15 x i8] c"begin dump: %s\00", align 1
@.str.4 = private unnamed_addr constant [2 x i8] c"R\00", align 1
@.str.5 = private unnamed_addr constant [2 x i8] c"\0A\00", align 1
@.str.6 = private unnamed_addr constant [8 x i8] c"%0.2lf \00", align 1
@.str.7 = private unnamed_addr constant [17 x i8] c"\0Aend   dump: %s\0A\00", align 1
@.str.8 = private unnamed_addr constant [2 x i8] c"Q\00", align 1
@.str.9 = private unnamed_addr constant [23 x i8] c"==END   DUMP_ARRAYS==\0A\00", align 1
@pb_emit = internal global i32 1, align 4, !dbg !45
@llvm.global.annotations = appending global [1 x { i8*, i8*, i8*, i32, i8* }] [{ i8*, i8*, i8*, i32, i8* } { i8* bitcast (i32 ()* @task_job_polybench to i8*), i8* getelementptr inbounds ([12 x i8], [12 x i8]* @.str, i32 0, i32 0), i8* getelementptr inbounds ([126 x i8], [126 x i8]* @.str.1, i32 0, i32 0), i32 137, i8* null }], section "llvm.metadata"

; Function Attrs: noinline nounwind uwtable
define dso_local void @workload_prepare() #0 !dbg !55 {
  ret void, !dbg !59
}

; Function Attrs: noinline nounwind uwtable
define dso_local void @workload_reset(i32 noundef %0) #0 !dbg !60 {
  call void @llvm.dbg.value(metadata i32 %0, metadata !63, metadata !DIExpression()), !dbg !64
  call void @llvm.memset.p0i8.i64(i8* align 64 bitcast ([200 x [240 x double]]* @A to i8*), i8 0, i64 384000, i1 false), !dbg !65
  call void @llvm.memset.p0i8.i64(i8* align 64 bitcast ([240 x [240 x double]]* @R to i8*), i8 0, i64 460800, i1 false), !dbg !66
  call void @llvm.memset.p0i8.i64(i8* align 64 bitcast ([200 x [240 x double]]* @Q to i8*), i8 0, i64 384000, i1 false), !dbg !67
  %2 = load i32, i32* @m, align 4, !dbg !68
  %3 = load i32, i32* @n, align 4, !dbg !69
  call void @init_array(i32 noundef %2, i32 noundef %3, [240 x double]* noundef getelementptr inbounds ([200 x [240 x double]], [200 x [240 x double]]* @A, i64 0, i64 0), [240 x double]* noundef getelementptr inbounds ([240 x [240 x double]], [240 x [240 x double]]* @R, i64 0, i64 0), [240 x double]* noundef getelementptr inbounds ([200 x [240 x double]], [200 x [240 x double]]* @Q, i64 0, i64 0)), !dbg !70
  ret void, !dbg !71
}

; Function Attrs: nofree nosync nounwind readnone speculatable willreturn
declare void @llvm.dbg.declare(metadata, metadata, metadata) #1

; Function Attrs: argmemonly nofree nounwind willreturn writeonly
declare void @llvm.memset.p0i8.i64(i8* nocapture writeonly, i8, i64, i1 immarg) #2

; Function Attrs: noinline nounwind uwtable
define internal void @init_array(i32 noundef %0, i32 noundef %1, [240 x double]* noundef %2, [240 x double]* noundef %3, [240 x double]* noundef %4) #0 !dbg !72 {
  call void @llvm.dbg.value(metadata i32 %0, metadata !78, metadata !DIExpression()), !dbg !79
  call void @llvm.dbg.value(metadata i32 %1, metadata !80, metadata !DIExpression()), !dbg !79
  call void @llvm.dbg.value(metadata [240 x double]* %2, metadata !81, metadata !DIExpression()), !dbg !79
  call void @llvm.dbg.value(metadata [240 x double]* %3, metadata !82, metadata !DIExpression()), !dbg !79
  call void @llvm.dbg.value(metadata [240 x double]* %4, metadata !83, metadata !DIExpression()), !dbg !79
  call void @llvm.dbg.value(metadata i32 0, metadata !84, metadata !DIExpression()), !dbg !79
  br label %6, !dbg !85

6:                                                ; preds = %30, %5
  %.01 = phi i32 [ 0, %5 ], [ %31, %30 ], !dbg !87
  call void @llvm.dbg.value(metadata i32 %.01, metadata !84, metadata !DIExpression()), !dbg !79
  %7 = icmp slt i32 %.01, %0, !dbg !88
  br i1 %7, label %8, label %32, !dbg !90

8:                                                ; preds = %6
  call void @llvm.dbg.value(metadata i32 0, metadata !91, metadata !DIExpression()), !dbg !79
  br label %9, !dbg !92

9:                                                ; preds = %27, %8
  %.0 = phi i32 [ 0, %8 ], [ %28, %27 ], !dbg !94
  call void @llvm.dbg.value(metadata i32 %.0, metadata !91, metadata !DIExpression()), !dbg !79
  %10 = icmp slt i32 %.0, %1, !dbg !95
  br i1 %10, label %11, label %29, !dbg !97

11:                                               ; preds = %9
  %12 = mul nsw i32 %.01, %.0, !dbg !98
  %13 = srem i32 %12, %0, !dbg !100
  %14 = sitofp i32 %13 to double, !dbg !101
  %15 = sitofp i32 %0 to double, !dbg !102
  %16 = fdiv double %14, %15, !dbg !103
  %17 = fmul double %16, 1.000000e+02, !dbg !104
  %18 = fadd double %17, 1.000000e+01, !dbg !105
  %19 = sext i32 %.01 to i64, !dbg !106
  %20 = getelementptr inbounds [240 x double], [240 x double]* %2, i64 %19, !dbg !106
  %21 = sext i32 %.0 to i64, !dbg !106
  %22 = getelementptr inbounds [240 x double], [240 x double]* %20, i64 0, i64 %21, !dbg !106
  store double %18, double* %22, align 8, !dbg !107
  %23 = sext i32 %.01 to i64, !dbg !108
  %24 = getelementptr inbounds [240 x double], [240 x double]* %4, i64 %23, !dbg !108
  %25 = sext i32 %.0 to i64, !dbg !108
  %26 = getelementptr inbounds [240 x double], [240 x double]* %24, i64 0, i64 %25, !dbg !108
  store double 0.000000e+00, double* %26, align 8, !dbg !109
  br label %27, !dbg !110

27:                                               ; preds = %11
  %28 = add nsw i32 %.0, 1, !dbg !111
  call void @llvm.dbg.value(metadata i32 %28, metadata !91, metadata !DIExpression()), !dbg !79
  br label %9, !dbg !112, !llvm.loop !113

29:                                               ; preds = %9
  br label %30, !dbg !114

30:                                               ; preds = %29
  %31 = add nsw i32 %.01, 1, !dbg !116
  call void @llvm.dbg.value(metadata i32 %31, metadata !84, metadata !DIExpression()), !dbg !79
  br label %6, !dbg !117, !llvm.loop !118

32:                                               ; preds = %6
  call void @llvm.dbg.value(metadata i32 0, metadata !84, metadata !DIExpression()), !dbg !79
  br label %33, !dbg !120

33:                                               ; preds = %46, %32
  %.12 = phi i32 [ 0, %32 ], [ %47, %46 ], !dbg !122
  call void @llvm.dbg.value(metadata i32 %.12, metadata !84, metadata !DIExpression()), !dbg !79
  %34 = icmp slt i32 %.12, %1, !dbg !123
  br i1 %34, label %35, label %48, !dbg !125

35:                                               ; preds = %33
  call void @llvm.dbg.value(metadata i32 0, metadata !91, metadata !DIExpression()), !dbg !79
  br label %36, !dbg !126

36:                                               ; preds = %43, %35
  %.1 = phi i32 [ 0, %35 ], [ %44, %43 ], !dbg !128
  call void @llvm.dbg.value(metadata i32 %.1, metadata !91, metadata !DIExpression()), !dbg !79
  %37 = icmp slt i32 %.1, %1, !dbg !129
  br i1 %37, label %38, label %45, !dbg !131

38:                                               ; preds = %36
  %39 = sext i32 %.12 to i64, !dbg !132
  %40 = getelementptr inbounds [240 x double], [240 x double]* %3, i64 %39, !dbg !132
  %41 = sext i32 %.1 to i64, !dbg !132
  %42 = getelementptr inbounds [240 x double], [240 x double]* %40, i64 0, i64 %41, !dbg !132
  store double 0.000000e+00, double* %42, align 8, !dbg !133
  br label %43, !dbg !132

43:                                               ; preds = %38
  %44 = add nsw i32 %.1, 1, !dbg !134
  call void @llvm.dbg.value(metadata i32 %44, metadata !91, metadata !DIExpression()), !dbg !79
  br label %36, !dbg !135, !llvm.loop !136

45:                                               ; preds = %36
  br label %46, !dbg !137

46:                                               ; preds = %45
  %47 = add nsw i32 %.12, 1, !dbg !138
  call void @llvm.dbg.value(metadata i32 %47, metadata !84, metadata !DIExpression()), !dbg !79
  br label %33, !dbg !139, !llvm.loop !140

48:                                               ; preds = %33
  ret void, !dbg !142
}

; Function Attrs: noinline nounwind uwtable
define dso_local i32 @task_job_polybench() #0 !dbg !143 {
  %1 = load i32, i32* @m, align 4, !dbg !144
  %2 = load i32, i32* @n, align 4, !dbg !145
  call void @llvm.dbg.value(metadata i32 %1, metadata !146, metadata !DIExpression()), !dbg !148
  call void @llvm.dbg.value(metadata i32 %2, metadata !150, metadata !DIExpression()), !dbg !148
  call void @llvm.dbg.value(metadata [240 x double]* getelementptr inbounds ([200 x [240 x double]], [200 x [240 x double]]* @A, i64 0, i64 0), metadata !151, metadata !DIExpression()), !dbg !148
  call void @llvm.dbg.value(metadata [240 x double]* getelementptr inbounds ([240 x [240 x double]], [240 x [240 x double]]* @R, i64 0, i64 0), metadata !152, metadata !DIExpression()), !dbg !148
  call void @llvm.dbg.value(metadata [240 x double]* getelementptr inbounds ([200 x [240 x double]], [200 x [240 x double]]* @Q, i64 0, i64 0), metadata !153, metadata !DIExpression()), !dbg !148
  call void @llvm.dbg.value(metadata i32 0, metadata !154, metadata !DIExpression()), !dbg !148
  br label %3, !dbg !155

3:                                                ; preds = %105, %0
  %.01 = phi i32 [ 0, %0 ], [ %106, %105 ], !dbg !157
  call void @llvm.dbg.value(metadata i32 %.01, metadata !154, metadata !DIExpression()), !dbg !148
  %4 = icmp slt i32 %.01, 240, !dbg !158
  br i1 %4, label %5, label %107, !dbg !160

5:                                                ; preds = %3
  call void @llvm.dbg.value(metadata double 0.000000e+00, metadata !161, metadata !DIExpression()), !dbg !148
  call void @llvm.dbg.value(metadata i32 0, metadata !162, metadata !DIExpression()), !dbg !148
  br label %6, !dbg !163

6:                                                ; preds = %8, %5
  %.03 = phi i32 [ 0, %5 ], [ %21, %8 ], !dbg !166
  %.0 = phi double [ 0.000000e+00, %5 ], [ %20, %8 ], !dbg !167
  call void @llvm.dbg.value(metadata double %.0, metadata !161, metadata !DIExpression()), !dbg !148
  call void @llvm.dbg.value(metadata i32 %.03, metadata !162, metadata !DIExpression()), !dbg !148
  %7 = icmp slt i32 %.03, 200, !dbg !168
  br i1 %7, label %8, label %22, !dbg !170

8:                                                ; preds = %6
  %9 = sext i32 %.03 to i64, !dbg !171
  %10 = getelementptr inbounds [240 x double], [240 x double]* getelementptr inbounds ([200 x [240 x double]], [200 x [240 x double]]* @A, i64 0, i64 0), i64 %9, !dbg !171
  %11 = sext i32 %.01 to i64, !dbg !171
  %12 = getelementptr inbounds [240 x double], [240 x double]* %10, i64 0, i64 %11, !dbg !171
  %13 = load double, double* %12, align 8, !dbg !171
  %14 = sext i32 %.03 to i64, !dbg !172
  %15 = getelementptr inbounds [240 x double], [240 x double]* getelementptr inbounds ([200 x [240 x double]], [200 x [240 x double]]* @A, i64 0, i64 0), i64 %14, !dbg !172
  %16 = sext i32 %.01 to i64, !dbg !172
  %17 = getelementptr inbounds [240 x double], [240 x double]* %15, i64 0, i64 %16, !dbg !172
  %18 = load double, double* %17, align 8, !dbg !172
  %19 = fmul double %13, %18, !dbg !173
  %20 = fadd double %.0, %19, !dbg !174
  call void @llvm.dbg.value(metadata double %20, metadata !161, metadata !DIExpression()), !dbg !148
  %21 = add nsw i32 %.03, 1, !dbg !175
  call void @llvm.dbg.value(metadata i32 %21, metadata !162, metadata !DIExpression()), !dbg !148
  br label %6, !dbg !176, !llvm.loop !177

22:                                               ; preds = %6
  %23 = call double @sqrt(double noundef %.0) #6, !dbg !179
  %24 = sext i32 %.01 to i64, !dbg !180
  %25 = getelementptr inbounds [240 x double], [240 x double]* getelementptr inbounds ([240 x [240 x double]], [240 x [240 x double]]* @R, i64 0, i64 0), i64 %24, !dbg !180
  %26 = sext i32 %.01 to i64, !dbg !180
  %27 = getelementptr inbounds [240 x double], [240 x double]* %25, i64 0, i64 %26, !dbg !180
  store double %23, double* %27, align 8, !dbg !181
  call void @llvm.dbg.value(metadata i32 0, metadata !162, metadata !DIExpression()), !dbg !148
  br label %28, !dbg !182

28:                                               ; preds = %30, %22
  %.1 = phi i32 [ 0, %22 ], [ %46, %30 ], !dbg !184
  call void @llvm.dbg.value(metadata i32 %.1, metadata !162, metadata !DIExpression()), !dbg !148
  %29 = icmp slt i32 %.1, 200, !dbg !185
  br i1 %29, label %30, label %47, !dbg !187

30:                                               ; preds = %28
  %31 = sext i32 %.1 to i64, !dbg !188
  %32 = getelementptr inbounds [240 x double], [240 x double]* getelementptr inbounds ([200 x [240 x double]], [200 x [240 x double]]* @A, i64 0, i64 0), i64 %31, !dbg !188
  %33 = sext i32 %.01 to i64, !dbg !188
  %34 = getelementptr inbounds [240 x double], [240 x double]* %32, i64 0, i64 %33, !dbg !188
  %35 = load double, double* %34, align 8, !dbg !188
  %36 = sext i32 %.01 to i64, !dbg !189
  %37 = getelementptr inbounds [240 x double], [240 x double]* getelementptr inbounds ([240 x [240 x double]], [240 x [240 x double]]* @R, i64 0, i64 0), i64 %36, !dbg !189
  %38 = sext i32 %.01 to i64, !dbg !189
  %39 = getelementptr inbounds [240 x double], [240 x double]* %37, i64 0, i64 %38, !dbg !189
  %40 = load double, double* %39, align 8, !dbg !189
  %41 = fdiv double %35, %40, !dbg !190
  %42 = sext i32 %.1 to i64, !dbg !191
  %43 = getelementptr inbounds [240 x double], [240 x double]* getelementptr inbounds ([200 x [240 x double]], [200 x [240 x double]]* @Q, i64 0, i64 0), i64 %42, !dbg !191
  %44 = sext i32 %.01 to i64, !dbg !191
  %45 = getelementptr inbounds [240 x double], [240 x double]* %43, i64 0, i64 %44, !dbg !191
  store double %41, double* %45, align 8, !dbg !192
  %46 = add nsw i32 %.1, 1, !dbg !193
  call void @llvm.dbg.value(metadata i32 %46, metadata !162, metadata !DIExpression()), !dbg !148
  br label %28, !dbg !194, !llvm.loop !195

47:                                               ; preds = %28
  %48 = add nsw i32 %.01, 1, !dbg !197
  call void @llvm.dbg.value(metadata i32 %48, metadata !199, metadata !DIExpression()), !dbg !148
  br label %49, !dbg !200

49:                                               ; preds = %103, %47
  %.02 = phi i32 [ %48, %47 ], [ %104, %103 ], !dbg !201
  call void @llvm.dbg.value(metadata i32 %.02, metadata !199, metadata !DIExpression()), !dbg !148
  %50 = icmp slt i32 %.02, 240, !dbg !202
  br i1 %50, label %51, label %105, !dbg !204

51:                                               ; preds = %49
  %52 = sext i32 %.01 to i64, !dbg !205
  %53 = getelementptr inbounds [240 x double], [240 x double]* getelementptr inbounds ([240 x [240 x double]], [240 x [240 x double]]* @R, i64 0, i64 0), i64 %52, !dbg !205
  %54 = sext i32 %.02 to i64, !dbg !205
  %55 = getelementptr inbounds [240 x double], [240 x double]* %53, i64 0, i64 %54, !dbg !205
  store double 0.000000e+00, double* %55, align 8, !dbg !207
  call void @llvm.dbg.value(metadata i32 0, metadata !162, metadata !DIExpression()), !dbg !148
  br label %56, !dbg !208

56:                                               ; preds = %58, %51
  %.2 = phi i32 [ 0, %51 ], [ %76, %58 ], !dbg !210
  call void @llvm.dbg.value(metadata i32 %.2, metadata !162, metadata !DIExpression()), !dbg !148
  %57 = icmp slt i32 %.2, 200, !dbg !211
  br i1 %57, label %58, label %77, !dbg !213

58:                                               ; preds = %56
  %59 = sext i32 %.2 to i64, !dbg !214
  %60 = getelementptr inbounds [240 x double], [240 x double]* getelementptr inbounds ([200 x [240 x double]], [200 x [240 x double]]* @Q, i64 0, i64 0), i64 %59, !dbg !214
  %61 = sext i32 %.01 to i64, !dbg !214
  %62 = getelementptr inbounds [240 x double], [240 x double]* %60, i64 0, i64 %61, !dbg !214
  %63 = load double, double* %62, align 8, !dbg !214
  %64 = sext i32 %.2 to i64, !dbg !215
  %65 = getelementptr inbounds [240 x double], [240 x double]* getelementptr inbounds ([200 x [240 x double]], [200 x [240 x double]]* @A, i64 0, i64 0), i64 %64, !dbg !215
  %66 = sext i32 %.02 to i64, !dbg !215
  %67 = getelementptr inbounds [240 x double], [240 x double]* %65, i64 0, i64 %66, !dbg !215
  %68 = load double, double* %67, align 8, !dbg !215
  %69 = fmul double %63, %68, !dbg !216
  %70 = sext i32 %.01 to i64, !dbg !217
  %71 = getelementptr inbounds [240 x double], [240 x double]* getelementptr inbounds ([240 x [240 x double]], [240 x [240 x double]]* @R, i64 0, i64 0), i64 %70, !dbg !217
  %72 = sext i32 %.02 to i64, !dbg !217
  %73 = getelementptr inbounds [240 x double], [240 x double]* %71, i64 0, i64 %72, !dbg !217
  %74 = load double, double* %73, align 8, !dbg !218
  %75 = fadd double %74, %69, !dbg !218
  store double %75, double* %73, align 8, !dbg !218
  %76 = add nsw i32 %.2, 1, !dbg !219
  call void @llvm.dbg.value(metadata i32 %76, metadata !162, metadata !DIExpression()), !dbg !148
  br label %56, !dbg !220, !llvm.loop !221

77:                                               ; preds = %56
  call void @llvm.dbg.value(metadata i32 0, metadata !162, metadata !DIExpression()), !dbg !148
  br label %78, !dbg !223

78:                                               ; preds = %80, %77
  %.3 = phi i32 [ 0, %77 ], [ %102, %80 ], !dbg !225
  call void @llvm.dbg.value(metadata i32 %.3, metadata !162, metadata !DIExpression()), !dbg !148
  %79 = icmp slt i32 %.3, 200, !dbg !226
  br i1 %79, label %80, label %103, !dbg !228

80:                                               ; preds = %78
  %81 = sext i32 %.3 to i64, !dbg !229
  %82 = getelementptr inbounds [240 x double], [240 x double]* getelementptr inbounds ([200 x [240 x double]], [200 x [240 x double]]* @A, i64 0, i64 0), i64 %81, !dbg !229
  %83 = sext i32 %.02 to i64, !dbg !229
  %84 = getelementptr inbounds [240 x double], [240 x double]* %82, i64 0, i64 %83, !dbg !229
  %85 = load double, double* %84, align 8, !dbg !229
  %86 = sext i32 %.3 to i64, !dbg !230
  %87 = getelementptr inbounds [240 x double], [240 x double]* getelementptr inbounds ([200 x [240 x double]], [200 x [240 x double]]* @Q, i64 0, i64 0), i64 %86, !dbg !230
  %88 = sext i32 %.01 to i64, !dbg !230
  %89 = getelementptr inbounds [240 x double], [240 x double]* %87, i64 0, i64 %88, !dbg !230
  %90 = load double, double* %89, align 8, !dbg !230
  %91 = sext i32 %.01 to i64, !dbg !231
  %92 = getelementptr inbounds [240 x double], [240 x double]* getelementptr inbounds ([240 x [240 x double]], [240 x [240 x double]]* @R, i64 0, i64 0), i64 %91, !dbg !231
  %93 = sext i32 %.02 to i64, !dbg !231
  %94 = getelementptr inbounds [240 x double], [240 x double]* %92, i64 0, i64 %93, !dbg !231
  %95 = load double, double* %94, align 8, !dbg !231
  %96 = fmul double %90, %95, !dbg !232
  %97 = fsub double %85, %96, !dbg !233
  %98 = sext i32 %.3 to i64, !dbg !234
  %99 = getelementptr inbounds [240 x double], [240 x double]* getelementptr inbounds ([200 x [240 x double]], [200 x [240 x double]]* @A, i64 0, i64 0), i64 %98, !dbg !234
  %100 = sext i32 %.02 to i64, !dbg !234
  %101 = getelementptr inbounds [240 x double], [240 x double]* %99, i64 0, i64 %100, !dbg !234
  store double %97, double* %101, align 8, !dbg !235
  %102 = add nsw i32 %.3, 1, !dbg !236
  call void @llvm.dbg.value(metadata i32 %102, metadata !162, metadata !DIExpression()), !dbg !148
  br label %78, !dbg !237, !llvm.loop !238

103:                                              ; preds = %78
  %104 = add nsw i32 %.02, 1, !dbg !240
  call void @llvm.dbg.value(metadata i32 %104, metadata !199, metadata !DIExpression()), !dbg !148
  br label %49, !dbg !241, !llvm.loop !242

105:                                              ; preds = %49
  %106 = add nsw i32 %.01, 1, !dbg !244
  call void @llvm.dbg.value(metadata i32 %106, metadata !154, metadata !DIExpression()), !dbg !148
  br label %3, !dbg !245, !llvm.loop !246

107:                                              ; preds = %3
  ret i32 0, !dbg !248
}

; Function Attrs: noinline nounwind uwtable
define dso_local i32 @workload_checksum(i32 noundef %0) #0 !dbg !249 {
  call void @llvm.dbg.value(metadata i32 %0, metadata !252, metadata !DIExpression()), !dbg !253
  store i32 -2128831035, i32* @pb_hash, align 4, !dbg !254
  %2 = load i32, i32* @m, align 4, !dbg !255
  %3 = load i32, i32* @n, align 4, !dbg !256
  call void @print_array(i32 noundef %2, i32 noundef %3, [240 x double]* noundef getelementptr inbounds ([200 x [240 x double]], [200 x [240 x double]]* @A, i64 0, i64 0), [240 x double]* noundef getelementptr inbounds ([240 x [240 x double]], [240 x [240 x double]]* @R, i64 0, i64 0), [240 x double]* noundef getelementptr inbounds ([200 x [240 x double]], [200 x [240 x double]]* @Q, i64 0, i64 0)), !dbg !257
  %4 = load i32, i32* @pb_hash, align 4, !dbg !258
  ret i32 %4, !dbg !259
}

; Function Attrs: noinline nounwind uwtable
define internal void @print_array(i32 noundef %0, i32 noundef %1, [240 x double]* noundef %2, [240 x double]* noundef %3, [240 x double]* noundef %4) #0 !dbg !260 {
  call void @llvm.dbg.value(metadata i32 %0, metadata !261, metadata !DIExpression()), !dbg !262
  call void @llvm.dbg.value(metadata i32 %1, metadata !263, metadata !DIExpression()), !dbg !262
  call void @llvm.dbg.value(metadata [240 x double]* %2, metadata !264, metadata !DIExpression()), !dbg !262
  call void @llvm.dbg.value(metadata [240 x double]* %3, metadata !265, metadata !DIExpression()), !dbg !262
  call void @llvm.dbg.value(metadata [240 x double]* %4, metadata !266, metadata !DIExpression()), !dbg !262
  %6 = load %struct._IO_FILE*, %struct._IO_FILE** @stderr, align 8, !dbg !267
  %7 = call i32 (%struct._IO_FILE*, i8*, ...) @pb_fprintf(%struct._IO_FILE* noundef %6, i8* noundef getelementptr inbounds ([23 x i8], [23 x i8]* @.str.2, i64 0, i64 0)), !dbg !267
  %8 = load %struct._IO_FILE*, %struct._IO_FILE** @stderr, align 8, !dbg !268
  %9 = call i32 (%struct._IO_FILE*, i8*, ...) @pb_fprintf(%struct._IO_FILE* noundef %8, i8* noundef getelementptr inbounds ([15 x i8], [15 x i8]* @.str.3, i64 0, i64 0), i8* noundef getelementptr inbounds ([2 x i8], [2 x i8]* @.str.4, i64 0, i64 0)), !dbg !268
  call void @llvm.dbg.value(metadata i32 0, metadata !269, metadata !DIExpression()), !dbg !262
  br label %10, !dbg !270

10:                                               ; preds = %34, %5
  %.01 = phi i32 [ 0, %5 ], [ %35, %34 ], !dbg !272
  call void @llvm.dbg.value(metadata i32 %.01, metadata !269, metadata !DIExpression()), !dbg !262
  %11 = icmp slt i32 %.01, %1, !dbg !273
  br i1 %11, label %12, label %36, !dbg !275

12:                                               ; preds = %10
  call void @llvm.dbg.value(metadata i32 0, metadata !276, metadata !DIExpression()), !dbg !262
  br label %13, !dbg !277

13:                                               ; preds = %31, %12
  %.0 = phi i32 [ 0, %12 ], [ %32, %31 ], !dbg !279
  call void @llvm.dbg.value(metadata i32 %.0, metadata !276, metadata !DIExpression()), !dbg !262
  %14 = icmp slt i32 %.0, %1, !dbg !280
  br i1 %14, label %15, label %33, !dbg !282

15:                                               ; preds = %13
  %16 = mul nsw i32 %.01, %1, !dbg !283
  %17 = add nsw i32 %16, %.0, !dbg !286
  %18 = srem i32 %17, 20, !dbg !287
  %19 = icmp eq i32 %18, 0, !dbg !288
  br i1 %19, label %20, label %23, !dbg !289

20:                                               ; preds = %15
  %21 = load %struct._IO_FILE*, %struct._IO_FILE** @stderr, align 8, !dbg !290
  %22 = call i32 (%struct._IO_FILE*, i8*, ...) @pb_fprintf(%struct._IO_FILE* noundef %21, i8* noundef getelementptr inbounds ([2 x i8], [2 x i8]* @.str.5, i64 0, i64 0)), !dbg !291
  br label %23, !dbg !291

23:                                               ; preds = %20, %15
  %24 = load %struct._IO_FILE*, %struct._IO_FILE** @stderr, align 8, !dbg !292
  %25 = sext i32 %.01 to i64, !dbg !293
  %26 = getelementptr inbounds [240 x double], [240 x double]* %3, i64 %25, !dbg !293
  %27 = sext i32 %.0 to i64, !dbg !293
  %28 = getelementptr inbounds [240 x double], [240 x double]* %26, i64 0, i64 %27, !dbg !293
  %29 = load double, double* %28, align 8, !dbg !293
  %30 = call i32 (%struct._IO_FILE*, i8*, ...) @pb_fprintf(%struct._IO_FILE* noundef %24, i8* noundef getelementptr inbounds ([8 x i8], [8 x i8]* @.str.6, i64 0, i64 0), double noundef %29), !dbg !294
  br label %31, !dbg !295

31:                                               ; preds = %23
  %32 = add nsw i32 %.0, 1, !dbg !296
  call void @llvm.dbg.value(metadata i32 %32, metadata !276, metadata !DIExpression()), !dbg !262
  br label %13, !dbg !297, !llvm.loop !298

33:                                               ; preds = %13
  br label %34, !dbg !299

34:                                               ; preds = %33
  %35 = add nsw i32 %.01, 1, !dbg !300
  call void @llvm.dbg.value(metadata i32 %35, metadata !269, metadata !DIExpression()), !dbg !262
  br label %10, !dbg !301, !llvm.loop !302

36:                                               ; preds = %10
  %37 = load %struct._IO_FILE*, %struct._IO_FILE** @stderr, align 8, !dbg !304
  %38 = call i32 (%struct._IO_FILE*, i8*, ...) @pb_fprintf(%struct._IO_FILE* noundef %37, i8* noundef getelementptr inbounds ([17 x i8], [17 x i8]* @.str.7, i64 0, i64 0), i8* noundef getelementptr inbounds ([2 x i8], [2 x i8]* @.str.4, i64 0, i64 0)), !dbg !304
  %39 = load %struct._IO_FILE*, %struct._IO_FILE** @stderr, align 8, !dbg !305
  %40 = call i32 (%struct._IO_FILE*, i8*, ...) @pb_fprintf(%struct._IO_FILE* noundef %39, i8* noundef getelementptr inbounds ([15 x i8], [15 x i8]* @.str.3, i64 0, i64 0), i8* noundef getelementptr inbounds ([2 x i8], [2 x i8]* @.str.8, i64 0, i64 0)), !dbg !305
  call void @llvm.dbg.value(metadata i32 0, metadata !269, metadata !DIExpression()), !dbg !262
  br label %41, !dbg !306

41:                                               ; preds = %65, %36
  %.12 = phi i32 [ 0, %36 ], [ %66, %65 ], !dbg !308
  call void @llvm.dbg.value(metadata i32 %.12, metadata !269, metadata !DIExpression()), !dbg !262
  %42 = icmp slt i32 %.12, %0, !dbg !309
  br i1 %42, label %43, label %67, !dbg !311

43:                                               ; preds = %41
  call void @llvm.dbg.value(metadata i32 0, metadata !276, metadata !DIExpression()), !dbg !262
  br label %44, !dbg !312

44:                                               ; preds = %62, %43
  %.1 = phi i32 [ 0, %43 ], [ %63, %62 ], !dbg !314
  call void @llvm.dbg.value(metadata i32 %.1, metadata !276, metadata !DIExpression()), !dbg !262
  %45 = icmp slt i32 %.1, %1, !dbg !315
  br i1 %45, label %46, label %64, !dbg !317

46:                                               ; preds = %44
  %47 = mul nsw i32 %.12, %1, !dbg !318
  %48 = add nsw i32 %47, %.1, !dbg !321
  %49 = srem i32 %48, 20, !dbg !322
  %50 = icmp eq i32 %49, 0, !dbg !323
  br i1 %50, label %51, label %54, !dbg !324

51:                                               ; preds = %46
  %52 = load %struct._IO_FILE*, %struct._IO_FILE** @stderr, align 8, !dbg !325
  %53 = call i32 (%struct._IO_FILE*, i8*, ...) @pb_fprintf(%struct._IO_FILE* noundef %52, i8* noundef getelementptr inbounds ([2 x i8], [2 x i8]* @.str.5, i64 0, i64 0)), !dbg !326
  br label %54, !dbg !326

54:                                               ; preds = %51, %46
  %55 = load %struct._IO_FILE*, %struct._IO_FILE** @stderr, align 8, !dbg !327
  %56 = sext i32 %.12 to i64, !dbg !328
  %57 = getelementptr inbounds [240 x double], [240 x double]* %4, i64 %56, !dbg !328
  %58 = sext i32 %.1 to i64, !dbg !328
  %59 = getelementptr inbounds [240 x double], [240 x double]* %57, i64 0, i64 %58, !dbg !328
  %60 = load double, double* %59, align 8, !dbg !328
  %61 = call i32 (%struct._IO_FILE*, i8*, ...) @pb_fprintf(%struct._IO_FILE* noundef %55, i8* noundef getelementptr inbounds ([8 x i8], [8 x i8]* @.str.6, i64 0, i64 0), double noundef %60), !dbg !329
  br label %62, !dbg !330

62:                                               ; preds = %54
  %63 = add nsw i32 %.1, 1, !dbg !331
  call void @llvm.dbg.value(metadata i32 %63, metadata !276, metadata !DIExpression()), !dbg !262
  br label %44, !dbg !332, !llvm.loop !333

64:                                               ; preds = %44
  br label %65, !dbg !334

65:                                               ; preds = %64
  %66 = add nsw i32 %.12, 1, !dbg !335
  call void @llvm.dbg.value(metadata i32 %66, metadata !269, metadata !DIExpression()), !dbg !262
  br label %41, !dbg !336, !llvm.loop !337

67:                                               ; preds = %41
  %68 = load %struct._IO_FILE*, %struct._IO_FILE** @stderr, align 8, !dbg !339
  %69 = call i32 (%struct._IO_FILE*, i8*, ...) @pb_fprintf(%struct._IO_FILE* noundef %68, i8* noundef getelementptr inbounds ([17 x i8], [17 x i8]* @.str.7, i64 0, i64 0), i8* noundef getelementptr inbounds ([2 x i8], [2 x i8]* @.str.8, i64 0, i64 0)), !dbg !339
  %70 = load %struct._IO_FILE*, %struct._IO_FILE** @stderr, align 8, !dbg !340
  %71 = call i32 (%struct._IO_FILE*, i8*, ...) @pb_fprintf(%struct._IO_FILE* noundef %70, i8* noundef getelementptr inbounds ([23 x i8], [23 x i8]* @.str.9, i64 0, i64 0)), !dbg !340
  ret void, !dbg !341
}

; Function Attrs: nounwind
declare double @sqrt(double noundef) #3

; Function Attrs: noinline nounwind uwtable
define internal i32 @pb_fprintf(%struct._IO_FILE* noundef %0, i8* noundef %1, ...) #0 !dbg !342 {
  %3 = alloca [768 x i8], align 16
  %4 = alloca [1 x %struct.__va_list_tag], align 16
  call void @llvm.dbg.value(metadata %struct._IO_FILE* %0, metadata !406, metadata !DIExpression()), !dbg !407
  call void @llvm.dbg.value(metadata i8* %1, metadata !408, metadata !DIExpression()), !dbg !407
  call void @llvm.dbg.declare(metadata [768 x i8]* %3, metadata !409, metadata !DIExpression()), !dbg !413
  call void @llvm.dbg.declare(metadata [1 x %struct.__va_list_tag]* %4, metadata !414, metadata !DIExpression()), !dbg !428
  %5 = getelementptr inbounds [1 x %struct.__va_list_tag], [1 x %struct.__va_list_tag]* %4, i64 0, i64 0, !dbg !429
  %6 = bitcast %struct.__va_list_tag* %5 to i8*, !dbg !429
  call void @llvm.va_start(i8* %6), !dbg !429
  %7 = getelementptr inbounds [768 x i8], [768 x i8]* %3, i64 0, i64 0, !dbg !430
  %8 = getelementptr inbounds [1 x %struct.__va_list_tag], [1 x %struct.__va_list_tag]* %4, i64 0, i64 0, !dbg !431
  %9 = call i32 @vsnprintf(i8* noundef %7, i64 noundef 768, i8* noundef %1, %struct.__va_list_tag* noundef %8) #6, !dbg !432
  call void @llvm.dbg.value(metadata i32 %9, metadata !433, metadata !DIExpression()), !dbg !407
  %10 = getelementptr inbounds [1 x %struct.__va_list_tag], [1 x %struct.__va_list_tag]* %4, i64 0, i64 0, !dbg !434
  %11 = bitcast %struct.__va_list_tag* %10 to i8*, !dbg !434
  call void @llvm.va_end(i8* %11), !dbg !434
  %12 = icmp slt i32 %9, 0, !dbg !435
  br i1 %12, label %16, label %13, !dbg !437

13:                                               ; preds = %2
  %14 = zext i32 %9 to i64, !dbg !438
  %15 = icmp uge i64 %14, 768, !dbg !439
  br i1 %15, label %16, label %17, !dbg !440

16:                                               ; preds = %13, %2
  call void @abort() #7, !dbg !441
  unreachable, !dbg !441

17:                                               ; preds = %13
  call void @llvm.dbg.value(metadata i32 0, metadata !442, metadata !DIExpression()), !dbg !444
  br label %18, !dbg !445

18:                                               ; preds = %29, %17
  %.0 = phi i32 [ 0, %17 ], [ %30, %29 ], !dbg !444
  call void @llvm.dbg.value(metadata i32 %.0, metadata !442, metadata !DIExpression()), !dbg !444
  %19 = icmp slt i32 %.0, %9, !dbg !446
  br i1 %19, label %20, label %31, !dbg !448

20:                                               ; preds = %18
  %21 = sext i32 %.0 to i64, !dbg !449
  %22 = getelementptr inbounds [768 x i8], [768 x i8]* %3, i64 0, i64 %21, !dbg !449
  %23 = load i8, i8* %22, align 1, !dbg !449
  %24 = zext i8 %23 to i32, !dbg !451
  %25 = load i32, i32* @pb_hash, align 4, !dbg !452
  %26 = xor i32 %25, %24, !dbg !452
  store i32 %26, i32* @pb_hash, align 4, !dbg !452
  %27 = load i32, i32* @pb_hash, align 4, !dbg !453
  %28 = mul i32 %27, 16777619, !dbg !453
  store i32 %28, i32* @pb_hash, align 4, !dbg !453
  br label %29, !dbg !454

29:                                               ; preds = %20
  %30 = add nsw i32 %.0, 1, !dbg !455
  call void @llvm.dbg.value(metadata i32 %30, metadata !442, metadata !DIExpression()), !dbg !444
  br label %18, !dbg !456, !llvm.loop !457

31:                                               ; preds = %18
  %32 = load i32, i32* @pb_emit, align 4, !dbg !459
  ret i32 %9, !dbg !460
}

; Function Attrs: nofree nosync nounwind willreturn
declare void @llvm.va_start(i8*) #4

; Function Attrs: nounwind
declare i32 @vsnprintf(i8* noundef, i64 noundef, i8* noundef, %struct.__va_list_tag* noundef) #3

; Function Attrs: nofree nosync nounwind willreturn
declare void @llvm.va_end(i8*) #4

; Function Attrs: noreturn nounwind
declare void @abort() #5

; Function Attrs: nofree nosync nounwind readnone speculatable willreturn
declare void @llvm.dbg.value(metadata, metadata, metadata) #1

attributes #0 = { noinline nounwind uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { nofree nosync nounwind readnone speculatable willreturn }
attributes #2 = { argmemonly nofree nounwind willreturn writeonly }
attributes #3 = { nounwind "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #4 = { nofree nosync nounwind willreturn }
attributes #5 = { noreturn nounwind "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #6 = { nounwind }
attributes #7 = { noreturn nounwind }

!llvm.dbg.cu = !{!2}
!llvm.module.flags = !{!47, !48, !49, !50, !51, !52, !53}
!llvm.ident = !{!54}

!0 = !DIGlobalVariableExpression(var: !1, expr: !DIExpression())
!1 = distinct !DIGlobalVariable(name: "m", scope: !2, file: !11, line: 124, type: !12, isLocal: false, isDefinition: true)
!2 = distinct !DICompileUnit(language: DW_LANG_C99, file: !3, producer: "Ubuntu clang version 14.0.0-1ubuntu1.1", isOptimized: false, runtimeVersion: 0, emissionKind: FullDebug, retainedTypes: !4, globals: !8, splitDebugInlining: false, nameTableKind: None)
!3 = !DIFile(filename: "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/triangular-20260929/suite/gramschmidt/source/workload.c", directory: "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/triangular-20260929/suite/gramschmidt/analysis-c", checksumkind: CSK_MD5, checksum: "eeae836a398c1603585df2c88ebc745e")
!4 = !{!5, !6, !7}
!5 = !DIBasicType(name: "double", size: 64, encoding: DW_ATE_float)
!6 = !DIBasicType(name: "unsigned int", size: 32, encoding: DW_ATE_unsigned)
!7 = !DIBasicType(name: "unsigned char", size: 8, encoding: DW_ATE_unsigned_char)
!8 = !{!0, !9, !13, !26, !30, !33, !39, !43, !45}
!9 = !DIGlobalVariableExpression(var: !10, expr: !DIExpression())
!10 = distinct !DIGlobalVariable(name: "n", scope: !2, file: !11, line: 125, type: !12, isLocal: false, isDefinition: true)
!11 = !DIFile(filename: "source/workload.c", directory: "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/triangular-20260929/suite/gramschmidt", checksumkind: CSK_MD5, checksum: "eeae836a398c1603585df2c88ebc745e")
!12 = !DIBasicType(name: "int", size: 32, encoding: DW_ATE_signed)
!13 = !DIGlobalVariableExpression(var: !14, expr: !DIExpression())
!14 = distinct !DIGlobalVariable(name: "workload_jobs", scope: !2, file: !11, line: 150, type: !15, isLocal: false, isDefinition: true)
!15 = !DICompositeType(tag: DW_TAG_array_type, baseType: !16, size: 64, elements: !24)
!16 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !17)
!17 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !18, size: 64)
!18 = !DISubroutineType(types: !19)
!19 = !{!20}
!20 = !DIDerivedType(tag: DW_TAG_typedef, name: "uint32_t", file: !21, line: 26, baseType: !22)
!21 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/stdint-uintn.h", directory: "", checksumkind: CSK_MD5, checksum: "2bf2ae53c58c01b1a1b9383b5195125c")
!22 = !DIDerivedType(tag: DW_TAG_typedef, name: "__uint32_t", file: !23, line: 42, baseType: !6)
!23 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/types.h", directory: "", checksumkind: CSK_MD5, checksum: "d108b5f93a74c50510d7d9bc0ab36df9")
!24 = !{!25}
!25 = !DISubrange(count: 1)
!26 = !DIGlobalVariableExpression(var: !27, expr: !DIExpression())
!27 = distinct !DIGlobalVariable(name: "workload_expected", scope: !2, file: !11, line: 154, type: !28, isLocal: false, isDefinition: true)
!28 = !DICompositeType(tag: DW_TAG_array_type, baseType: !29, size: 32, elements: !24)
!29 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !20)
!30 = !DIGlobalVariableExpression(var: !31, expr: !DIExpression())
!31 = distinct !DIGlobalVariable(name: "pb_hash", scope: !2, file: !32, line: 9, type: !20, isLocal: true, isDefinition: true)
!32 = !DIFile(filename: "source/adapter.h", directory: "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/triangular-20260929/suite/gramschmidt", checksumkind: CSK_MD5, checksum: "26a6068928b2092758f244a9d00163d7")
!33 = !DIGlobalVariableExpression(var: !34, expr: !DIExpression())
!34 = distinct !DIGlobalVariable(name: "A", scope: !2, file: !11, line: 34, type: !35, isLocal: false, isDefinition: true, align: 512)
!35 = !DICompositeType(tag: DW_TAG_array_type, baseType: !5, size: 3072000, elements: !36)
!36 = !{!37, !38}
!37 = !DISubrange(count: 200)
!38 = !DISubrange(count: 240)
!39 = !DIGlobalVariableExpression(var: !40, expr: !DIExpression())
!40 = distinct !DIGlobalVariable(name: "R", scope: !2, file: !11, line: 35, type: !41, isLocal: false, isDefinition: true, align: 512)
!41 = !DICompositeType(tag: DW_TAG_array_type, baseType: !5, size: 3686400, elements: !42)
!42 = !{!38, !38}
!43 = !DIGlobalVariableExpression(var: !44, expr: !DIExpression())
!44 = distinct !DIGlobalVariable(name: "Q", scope: !2, file: !11, line: 36, type: !35, isLocal: false, isDefinition: true, align: 512)
!45 = !DIGlobalVariableExpression(var: !46, expr: !DIExpression())
!46 = distinct !DIGlobalVariable(name: "pb_emit", scope: !2, file: !32, line: 10, type: !12, isLocal: true, isDefinition: true)
!47 = !{i32 7, !"Dwarf Version", i32 5}
!48 = !{i32 2, !"Debug Info Version", i32 3}
!49 = !{i32 1, !"wchar_size", i32 4}
!50 = !{i32 7, !"PIC Level", i32 2}
!51 = !{i32 7, !"PIE Level", i32 2}
!52 = !{i32 7, !"uwtable", i32 1}
!53 = !{i32 7, !"frame-pointer", i32 2}
!54 = !{!"Ubuntu clang version 14.0.0-1ubuntu1.1"}
!55 = distinct !DISubprogram(name: "workload_prepare", scope: !11, file: !11, line: 126, type: !56, scopeLine: 126, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !2, retainedNodes: !58)
!56 = !DISubroutineType(types: !57)
!57 = !{null}
!58 = !{}
!59 = !DILocation(line: 126, column: 30, scope: !55)
!60 = distinct !DISubprogram(name: "workload_reset", scope: !11, file: !11, line: 127, type: !61, scopeLine: 127, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !2, retainedNodes: !58)
!61 = !DISubroutineType(types: !62)
!62 = !{null, !6}
!63 = !DILocalVariable(name: "task", arg: 1, scope: !60, file: !11, line: 127, type: !6)
!64 = !DILocation(line: 0, scope: !60)
!65 = !DILocation(line: 129, column: 3, scope: !60)
!66 = !DILocation(line: 130, column: 3, scope: !60)
!67 = !DILocation(line: 131, column: 3, scope: !60)
!68 = !DILocation(line: 132, column: 15, scope: !60)
!69 = !DILocation(line: 132, column: 18, scope: !60)
!70 = !DILocation(line: 132, column: 3, scope: !60)
!71 = !DILocation(line: 136, column: 1, scope: !60)
!72 = distinct !DISubprogram(name: "init_array", scope: !11, file: !11, line: 38, type: !73, scopeLine: 42, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition, unit: !2, retainedNodes: !58)
!73 = !DISubroutineType(types: !74)
!74 = !{null, !12, !12, !75, !75, !75}
!75 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !76, size: 64)
!76 = !DICompositeType(tag: DW_TAG_array_type, baseType: !5, size: 15360, elements: !77)
!77 = !{!38}
!78 = !DILocalVariable(name: "m", arg: 1, scope: !72, file: !11, line: 38, type: !12)
!79 = !DILocation(line: 0, scope: !72)
!80 = !DILocalVariable(name: "n", arg: 2, scope: !72, file: !11, line: 38, type: !12)
!81 = !DILocalVariable(name: "A", arg: 3, scope: !72, file: !11, line: 39, type: !75)
!82 = !DILocalVariable(name: "R", arg: 4, scope: !72, file: !11, line: 40, type: !75)
!83 = !DILocalVariable(name: "Q", arg: 5, scope: !72, file: !11, line: 41, type: !75)
!84 = !DILocalVariable(name: "i", scope: !72, file: !11, line: 43, type: !12)
!85 = !DILocation(line: 45, column: 8, scope: !86)
!86 = distinct !DILexicalBlock(scope: !72, file: !11, line: 45, column: 3)
!87 = !DILocation(line: 0, scope: !86)
!88 = !DILocation(line: 45, column: 17, scope: !89)
!89 = distinct !DILexicalBlock(scope: !86, file: !11, line: 45, column: 3)
!90 = !DILocation(line: 45, column: 3, scope: !86)
!91 = !DILocalVariable(name: "j", scope: !72, file: !11, line: 43, type: !12)
!92 = !DILocation(line: 46, column: 10, scope: !93)
!93 = distinct !DILexicalBlock(scope: !89, file: !11, line: 46, column: 5)
!94 = !DILocation(line: 0, scope: !93)
!95 = !DILocation(line: 46, column: 19, scope: !96)
!96 = distinct !DILexicalBlock(scope: !93, file: !11, line: 46, column: 5)
!97 = !DILocation(line: 46, column: 5, scope: !93)
!98 = !DILocation(line: 47, column: 34, scope: !99)
!99 = distinct !DILexicalBlock(scope: !96, file: !11, line: 46, column: 29)
!100 = !DILocation(line: 47, column: 38, scope: !99)
!101 = !DILocation(line: 47, column: 19, scope: !99)
!102 = !DILocation(line: 47, column: 45, scope: !99)
!103 = !DILocation(line: 47, column: 43, scope: !99)
!104 = !DILocation(line: 47, column: 48, scope: !99)
!105 = !DILocation(line: 47, column: 54, scope: !99)
!106 = !DILocation(line: 47, column: 7, scope: !99)
!107 = !DILocation(line: 47, column: 15, scope: !99)
!108 = !DILocation(line: 48, column: 7, scope: !99)
!109 = !DILocation(line: 48, column: 15, scope: !99)
!110 = !DILocation(line: 49, column: 5, scope: !99)
!111 = !DILocation(line: 46, column: 25, scope: !96)
!112 = !DILocation(line: 46, column: 5, scope: !96)
!113 = distinct !{!113, !97, !114, !115}
!114 = !DILocation(line: 49, column: 5, scope: !93)
!115 = !{!"llvm.loop.mustprogress"}
!116 = !DILocation(line: 45, column: 23, scope: !89)
!117 = !DILocation(line: 45, column: 3, scope: !89)
!118 = distinct !{!118, !90, !119, !115}
!119 = !DILocation(line: 49, column: 5, scope: !86)
!120 = !DILocation(line: 50, column: 8, scope: !121)
!121 = distinct !DILexicalBlock(scope: !72, file: !11, line: 50, column: 3)
!122 = !DILocation(line: 0, scope: !121)
!123 = !DILocation(line: 50, column: 17, scope: !124)
!124 = distinct !DILexicalBlock(scope: !121, file: !11, line: 50, column: 3)
!125 = !DILocation(line: 50, column: 3, scope: !121)
!126 = !DILocation(line: 51, column: 10, scope: !127)
!127 = distinct !DILexicalBlock(scope: !124, file: !11, line: 51, column: 5)
!128 = !DILocation(line: 0, scope: !127)
!129 = !DILocation(line: 51, column: 19, scope: !130)
!130 = distinct !DILexicalBlock(scope: !127, file: !11, line: 51, column: 5)
!131 = !DILocation(line: 51, column: 5, scope: !127)
!132 = !DILocation(line: 52, column: 7, scope: !130)
!133 = !DILocation(line: 52, column: 15, scope: !130)
!134 = !DILocation(line: 51, column: 25, scope: !130)
!135 = !DILocation(line: 51, column: 5, scope: !130)
!136 = distinct !{!136, !131, !137, !115}
!137 = !DILocation(line: 52, column: 17, scope: !127)
!138 = !DILocation(line: 50, column: 23, scope: !124)
!139 = !DILocation(line: 50, column: 3, scope: !124)
!140 = distinct !{!140, !125, !141, !115}
!141 = !DILocation(line: 52, column: 17, scope: !121)
!142 = !DILocation(line: 53, column: 1, scope: !72)
!143 = distinct !DISubprogram(name: "task_job_polybench", scope: !11, file: !11, line: 137, type: !18, scopeLine: 137, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !2, retainedNodes: !58)
!144 = !DILocation(line: 138, column: 23, scope: !143)
!145 = !DILocation(line: 138, column: 26, scope: !143)
!146 = !DILocalVariable(name: "m", arg: 1, scope: !147, file: !11, line: 91, type: !12)
!147 = distinct !DISubprogram(name: "kernel_gramschmidt", scope: !11, file: !11, line: 91, type: !73, scopeLine: 95, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition, unit: !2, retainedNodes: !58)
!148 = !DILocation(line: 0, scope: !147, inlinedAt: !149)
!149 = distinct !DILocation(line: 138, column: 3, scope: !143)
!150 = !DILocalVariable(name: "n", arg: 2, scope: !147, file: !11, line: 91, type: !12)
!151 = !DILocalVariable(name: "A", arg: 3, scope: !147, file: !11, line: 92, type: !75)
!152 = !DILocalVariable(name: "R", arg: 4, scope: !147, file: !11, line: 93, type: !75)
!153 = !DILocalVariable(name: "Q", arg: 5, scope: !147, file: !11, line: 94, type: !75)
!154 = !DILocalVariable(name: "k", scope: !147, file: !11, line: 96, type: !12)
!155 = !DILocation(line: 101, column: 8, scope: !156, inlinedAt: !149)
!156 = distinct !DILexicalBlock(scope: !147, file: !11, line: 101, column: 3)
!157 = !DILocation(line: 0, scope: !156, inlinedAt: !149)
!158 = !DILocation(line: 101, column: 17, scope: !159, inlinedAt: !149)
!159 = distinct !DILexicalBlock(scope: !156, file: !11, line: 101, column: 3)
!160 = !DILocation(line: 101, column: 3, scope: !156, inlinedAt: !149)
!161 = !DILocalVariable(name: "nrm", scope: !147, file: !11, line: 98, type: !5)
!162 = !DILocalVariable(name: "i", scope: !147, file: !11, line: 96, type: !12)
!163 = !DILocation(line: 104, column: 12, scope: !164, inlinedAt: !149)
!164 = distinct !DILexicalBlock(scope: !165, file: !11, line: 104, column: 7)
!165 = distinct !DILexicalBlock(scope: !159, file: !11, line: 102, column: 5)
!166 = !DILocation(line: 0, scope: !164, inlinedAt: !149)
!167 = !DILocation(line: 0, scope: !165, inlinedAt: !149)
!168 = !DILocation(line: 104, column: 21, scope: !169, inlinedAt: !149)
!169 = distinct !DILexicalBlock(scope: !164, file: !11, line: 104, column: 7)
!170 = !DILocation(line: 104, column: 7, scope: !164, inlinedAt: !149)
!171 = !DILocation(line: 105, column: 16, scope: !169, inlinedAt: !149)
!172 = !DILocation(line: 105, column: 26, scope: !169, inlinedAt: !149)
!173 = !DILocation(line: 105, column: 24, scope: !169, inlinedAt: !149)
!174 = !DILocation(line: 105, column: 13, scope: !169, inlinedAt: !149)
!175 = !DILocation(line: 104, column: 31, scope: !169, inlinedAt: !149)
!176 = !DILocation(line: 104, column: 7, scope: !169, inlinedAt: !149)
!177 = distinct !{!177, !170, !178, !115}
!178 = !DILocation(line: 105, column: 32, scope: !164, inlinedAt: !149)
!179 = !DILocation(line: 106, column: 17, scope: !165, inlinedAt: !149)
!180 = !DILocation(line: 106, column: 7, scope: !165, inlinedAt: !149)
!181 = !DILocation(line: 106, column: 15, scope: !165, inlinedAt: !149)
!182 = !DILocation(line: 107, column: 12, scope: !183, inlinedAt: !149)
!183 = distinct !DILexicalBlock(scope: !165, file: !11, line: 107, column: 7)
!184 = !DILocation(line: 0, scope: !183, inlinedAt: !149)
!185 = !DILocation(line: 107, column: 21, scope: !186, inlinedAt: !149)
!186 = distinct !DILexicalBlock(scope: !183, file: !11, line: 107, column: 7)
!187 = !DILocation(line: 107, column: 7, scope: !183, inlinedAt: !149)
!188 = !DILocation(line: 108, column: 19, scope: !186, inlinedAt: !149)
!189 = !DILocation(line: 108, column: 29, scope: !186, inlinedAt: !149)
!190 = !DILocation(line: 108, column: 27, scope: !186, inlinedAt: !149)
!191 = !DILocation(line: 108, column: 9, scope: !186, inlinedAt: !149)
!192 = !DILocation(line: 108, column: 17, scope: !186, inlinedAt: !149)
!193 = !DILocation(line: 107, column: 31, scope: !186, inlinedAt: !149)
!194 = !DILocation(line: 107, column: 7, scope: !186, inlinedAt: !149)
!195 = distinct !{!195, !187, !196, !115}
!196 = !DILocation(line: 108, column: 35, scope: !183, inlinedAt: !149)
!197 = !DILocation(line: 109, column: 18, scope: !198, inlinedAt: !149)
!198 = distinct !DILexicalBlock(scope: !165, file: !11, line: 109, column: 7)
!199 = !DILocalVariable(name: "j", scope: !147, file: !11, line: 96, type: !12)
!200 = !DILocation(line: 109, column: 12, scope: !198, inlinedAt: !149)
!201 = !DILocation(line: 0, scope: !198, inlinedAt: !149)
!202 = !DILocation(line: 109, column: 25, scope: !203, inlinedAt: !149)
!203 = distinct !DILexicalBlock(scope: !198, file: !11, line: 109, column: 7)
!204 = !DILocation(line: 109, column: 7, scope: !198, inlinedAt: !149)
!205 = !DILocation(line: 111, column: 4, scope: !206, inlinedAt: !149)
!206 = distinct !DILexicalBlock(scope: !203, file: !11, line: 110, column: 2)
!207 = !DILocation(line: 111, column: 12, scope: !206, inlinedAt: !149)
!208 = !DILocation(line: 112, column: 9, scope: !209, inlinedAt: !149)
!209 = distinct !DILexicalBlock(scope: !206, file: !11, line: 112, column: 4)
!210 = !DILocation(line: 0, scope: !209, inlinedAt: !149)
!211 = !DILocation(line: 112, column: 18, scope: !212, inlinedAt: !149)
!212 = distinct !DILexicalBlock(scope: !209, file: !11, line: 112, column: 4)
!213 = !DILocation(line: 112, column: 4, scope: !209, inlinedAt: !149)
!214 = !DILocation(line: 113, column: 17, scope: !212, inlinedAt: !149)
!215 = !DILocation(line: 113, column: 27, scope: !212, inlinedAt: !149)
!216 = !DILocation(line: 113, column: 25, scope: !212, inlinedAt: !149)
!217 = !DILocation(line: 113, column: 6, scope: !212, inlinedAt: !149)
!218 = !DILocation(line: 113, column: 14, scope: !212, inlinedAt: !149)
!219 = !DILocation(line: 112, column: 28, scope: !212, inlinedAt: !149)
!220 = !DILocation(line: 112, column: 4, scope: !212, inlinedAt: !149)
!221 = distinct !{!221, !213, !222, !115}
!222 = !DILocation(line: 113, column: 33, scope: !209, inlinedAt: !149)
!223 = !DILocation(line: 114, column: 9, scope: !224, inlinedAt: !149)
!224 = distinct !DILexicalBlock(scope: !206, file: !11, line: 114, column: 4)
!225 = !DILocation(line: 0, scope: !224, inlinedAt: !149)
!226 = !DILocation(line: 114, column: 18, scope: !227, inlinedAt: !149)
!227 = distinct !DILexicalBlock(scope: !224, file: !11, line: 114, column: 4)
!228 = !DILocation(line: 114, column: 4, scope: !224, inlinedAt: !149)
!229 = !DILocation(line: 115, column: 16, scope: !227, inlinedAt: !149)
!230 = !DILocation(line: 115, column: 26, scope: !227, inlinedAt: !149)
!231 = !DILocation(line: 115, column: 36, scope: !227, inlinedAt: !149)
!232 = !DILocation(line: 115, column: 34, scope: !227, inlinedAt: !149)
!233 = !DILocation(line: 115, column: 24, scope: !227, inlinedAt: !149)
!234 = !DILocation(line: 115, column: 6, scope: !227, inlinedAt: !149)
!235 = !DILocation(line: 115, column: 14, scope: !227, inlinedAt: !149)
!236 = !DILocation(line: 114, column: 28, scope: !227, inlinedAt: !149)
!237 = !DILocation(line: 114, column: 4, scope: !227, inlinedAt: !149)
!238 = distinct !{!238, !228, !239, !115}
!239 = !DILocation(line: 115, column: 42, scope: !224, inlinedAt: !149)
!240 = !DILocation(line: 109, column: 35, scope: !203, inlinedAt: !149)
!241 = !DILocation(line: 109, column: 7, scope: !203, inlinedAt: !149)
!242 = distinct !{!242, !204, !243, !115}
!243 = !DILocation(line: 116, column: 2, scope: !198, inlinedAt: !149)
!244 = !DILocation(line: 101, column: 27, scope: !159, inlinedAt: !149)
!245 = !DILocation(line: 101, column: 3, scope: !159, inlinedAt: !149)
!246 = distinct !{!246, !160, !247, !115}
!247 = !DILocation(line: 117, column: 5, scope: !156, inlinedAt: !149)
!248 = !DILocation(line: 142, column: 3, scope: !143)
!249 = distinct !DISubprogram(name: "workload_checksum", scope: !11, file: !11, line: 144, type: !250, scopeLine: 144, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !2, retainedNodes: !58)
!250 = !DISubroutineType(types: !251)
!251 = !{!20, !6}
!252 = !DILocalVariable(name: "task", arg: 1, scope: !249, file: !11, line: 144, type: !6)
!253 = !DILocation(line: 0, scope: !249)
!254 = !DILocation(line: 146, column: 11, scope: !249)
!255 = !DILocation(line: 147, column: 15, scope: !249)
!256 = !DILocation(line: 147, column: 18, scope: !249)
!257 = !DILocation(line: 147, column: 3, scope: !249)
!258 = !DILocation(line: 148, column: 10, scope: !249)
!259 = !DILocation(line: 148, column: 3, scope: !249)
!260 = distinct !DISubprogram(name: "print_array", scope: !11, file: !11, line: 59, type: !73, scopeLine: 63, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition, unit: !2, retainedNodes: !58)
!261 = !DILocalVariable(name: "m", arg: 1, scope: !260, file: !11, line: 59, type: !12)
!262 = !DILocation(line: 0, scope: !260)
!263 = !DILocalVariable(name: "n", arg: 2, scope: !260, file: !11, line: 59, type: !12)
!264 = !DILocalVariable(name: "A", arg: 3, scope: !260, file: !11, line: 60, type: !75)
!265 = !DILocalVariable(name: "R", arg: 4, scope: !260, file: !11, line: 61, type: !75)
!266 = !DILocalVariable(name: "Q", arg: 5, scope: !260, file: !11, line: 62, type: !75)
!267 = !DILocation(line: 66, column: 3, scope: !260)
!268 = !DILocation(line: 67, column: 3, scope: !260)
!269 = !DILocalVariable(name: "i", scope: !260, file: !11, line: 64, type: !12)
!270 = !DILocation(line: 68, column: 8, scope: !271)
!271 = distinct !DILexicalBlock(scope: !260, file: !11, line: 68, column: 3)
!272 = !DILocation(line: 0, scope: !271)
!273 = !DILocation(line: 68, column: 17, scope: !274)
!274 = distinct !DILexicalBlock(scope: !271, file: !11, line: 68, column: 3)
!275 = !DILocation(line: 68, column: 3, scope: !271)
!276 = !DILocalVariable(name: "j", scope: !260, file: !11, line: 64, type: !12)
!277 = !DILocation(line: 69, column: 10, scope: !278)
!278 = distinct !DILexicalBlock(scope: !274, file: !11, line: 69, column: 5)
!279 = !DILocation(line: 0, scope: !278)
!280 = !DILocation(line: 69, column: 19, scope: !281)
!281 = distinct !DILexicalBlock(scope: !278, file: !11, line: 69, column: 5)
!282 = !DILocation(line: 69, column: 5, scope: !278)
!283 = !DILocation(line: 70, column: 8, scope: !284)
!284 = distinct !DILexicalBlock(scope: !285, file: !11, line: 70, column: 6)
!285 = distinct !DILexicalBlock(scope: !281, file: !11, line: 69, column: 29)
!286 = !DILocation(line: 70, column: 10, scope: !284)
!287 = !DILocation(line: 70, column: 14, scope: !284)
!288 = !DILocation(line: 70, column: 19, scope: !284)
!289 = !DILocation(line: 70, column: 6, scope: !285)
!290 = !DILocation(line: 70, column: 34, scope: !284)
!291 = !DILocation(line: 70, column: 25, scope: !284)
!292 = !DILocation(line: 71, column: 11, scope: !285)
!293 = !DILocation(line: 71, column: 56, scope: !285)
!294 = !DILocation(line: 71, column: 2, scope: !285)
!295 = !DILocation(line: 72, column: 5, scope: !285)
!296 = !DILocation(line: 69, column: 25, scope: !281)
!297 = !DILocation(line: 69, column: 5, scope: !281)
!298 = distinct !{!298, !282, !299, !115}
!299 = !DILocation(line: 72, column: 5, scope: !278)
!300 = !DILocation(line: 68, column: 23, scope: !274)
!301 = !DILocation(line: 68, column: 3, scope: !274)
!302 = distinct !{!302, !275, !303, !115}
!303 = !DILocation(line: 72, column: 5, scope: !271)
!304 = !DILocation(line: 73, column: 3, scope: !260)
!305 = !DILocation(line: 75, column: 3, scope: !260)
!306 = !DILocation(line: 76, column: 8, scope: !307)
!307 = distinct !DILexicalBlock(scope: !260, file: !11, line: 76, column: 3)
!308 = !DILocation(line: 0, scope: !307)
!309 = !DILocation(line: 76, column: 17, scope: !310)
!310 = distinct !DILexicalBlock(scope: !307, file: !11, line: 76, column: 3)
!311 = !DILocation(line: 76, column: 3, scope: !307)
!312 = !DILocation(line: 77, column: 10, scope: !313)
!313 = distinct !DILexicalBlock(scope: !310, file: !11, line: 77, column: 5)
!314 = !DILocation(line: 0, scope: !313)
!315 = !DILocation(line: 77, column: 19, scope: !316)
!316 = distinct !DILexicalBlock(scope: !313, file: !11, line: 77, column: 5)
!317 = !DILocation(line: 77, column: 5, scope: !313)
!318 = !DILocation(line: 78, column: 8, scope: !319)
!319 = distinct !DILexicalBlock(scope: !320, file: !11, line: 78, column: 6)
!320 = distinct !DILexicalBlock(scope: !316, file: !11, line: 77, column: 29)
!321 = !DILocation(line: 78, column: 10, scope: !319)
!322 = !DILocation(line: 78, column: 14, scope: !319)
!323 = !DILocation(line: 78, column: 19, scope: !319)
!324 = !DILocation(line: 78, column: 6, scope: !320)
!325 = !DILocation(line: 78, column: 34, scope: !319)
!326 = !DILocation(line: 78, column: 25, scope: !319)
!327 = !DILocation(line: 79, column: 11, scope: !320)
!328 = !DILocation(line: 79, column: 56, scope: !320)
!329 = !DILocation(line: 79, column: 2, scope: !320)
!330 = !DILocation(line: 80, column: 5, scope: !320)
!331 = !DILocation(line: 77, column: 25, scope: !316)
!332 = !DILocation(line: 77, column: 5, scope: !316)
!333 = distinct !{!333, !317, !334, !115}
!334 = !DILocation(line: 80, column: 5, scope: !313)
!335 = !DILocation(line: 76, column: 23, scope: !310)
!336 = !DILocation(line: 76, column: 3, scope: !310)
!337 = distinct !{!337, !311, !338, !115}
!338 = !DILocation(line: 80, column: 5, scope: !307)
!339 = !DILocation(line: 81, column: 3, scope: !260)
!340 = !DILocation(line: 82, column: 3, scope: !260)
!341 = !DILocation(line: 83, column: 1, scope: !260)
!342 = distinct !DISubprogram(name: "pb_fprintf", scope: !32, file: !32, line: 13, type: !343, scopeLine: 14, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition, unit: !2, retainedNodes: !58)
!343 = !DISubroutineType(types: !344)
!344 = !{!12, !345, !404, null}
!345 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !346, size: 64)
!346 = !DIDerivedType(tag: DW_TAG_typedef, name: "FILE", file: !347, line: 7, baseType: !348)
!347 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/types/FILE.h", directory: "", checksumkind: CSK_MD5, checksum: "571f9fb6223c42439075fdde11a0de5d")
!348 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "_IO_FILE", file: !349, line: 49, size: 1728, elements: !350)
!349 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/types/struct_FILE.h", directory: "", checksumkind: CSK_MD5, checksum: "1bad07471b7974df4ecc1d1c2ca207e6")
!350 = !{!351, !352, !355, !356, !357, !358, !359, !360, !361, !362, !363, !364, !365, !368, !370, !371, !372, !375, !377, !379, !381, !384, !386, !389, !392, !393, !395, !399, !400}
!351 = !DIDerivedType(tag: DW_TAG_member, name: "_flags", scope: !348, file: !349, line: 51, baseType: !12, size: 32)
!352 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_read_ptr", scope: !348, file: !349, line: 54, baseType: !353, size: 64, offset: 64)
!353 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !354, size: 64)
!354 = !DIBasicType(name: "char", size: 8, encoding: DW_ATE_signed_char)
!355 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_read_end", scope: !348, file: !349, line: 55, baseType: !353, size: 64, offset: 128)
!356 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_read_base", scope: !348, file: !349, line: 56, baseType: !353, size: 64, offset: 192)
!357 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_write_base", scope: !348, file: !349, line: 57, baseType: !353, size: 64, offset: 256)
!358 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_write_ptr", scope: !348, file: !349, line: 58, baseType: !353, size: 64, offset: 320)
!359 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_write_end", scope: !348, file: !349, line: 59, baseType: !353, size: 64, offset: 384)
!360 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_buf_base", scope: !348, file: !349, line: 60, baseType: !353, size: 64, offset: 448)
!361 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_buf_end", scope: !348, file: !349, line: 61, baseType: !353, size: 64, offset: 512)
!362 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_save_base", scope: !348, file: !349, line: 64, baseType: !353, size: 64, offset: 576)
!363 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_backup_base", scope: !348, file: !349, line: 65, baseType: !353, size: 64, offset: 640)
!364 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_save_end", scope: !348, file: !349, line: 66, baseType: !353, size: 64, offset: 704)
!365 = !DIDerivedType(tag: DW_TAG_member, name: "_markers", scope: !348, file: !349, line: 68, baseType: !366, size: 64, offset: 768)
!366 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !367, size: 64)
!367 = !DICompositeType(tag: DW_TAG_structure_type, name: "_IO_marker", file: !349, line: 36, flags: DIFlagFwdDecl)
!368 = !DIDerivedType(tag: DW_TAG_member, name: "_chain", scope: !348, file: !349, line: 70, baseType: !369, size: 64, offset: 832)
!369 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !348, size: 64)
!370 = !DIDerivedType(tag: DW_TAG_member, name: "_fileno", scope: !348, file: !349, line: 72, baseType: !12, size: 32, offset: 896)
!371 = !DIDerivedType(tag: DW_TAG_member, name: "_flags2", scope: !348, file: !349, line: 73, baseType: !12, size: 32, offset: 928)
!372 = !DIDerivedType(tag: DW_TAG_member, name: "_old_offset", scope: !348, file: !349, line: 74, baseType: !373, size: 64, offset: 960)
!373 = !DIDerivedType(tag: DW_TAG_typedef, name: "__off_t", file: !23, line: 152, baseType: !374)
!374 = !DIBasicType(name: "long", size: 64, encoding: DW_ATE_signed)
!375 = !DIDerivedType(tag: DW_TAG_member, name: "_cur_column", scope: !348, file: !349, line: 77, baseType: !376, size: 16, offset: 1024)
!376 = !DIBasicType(name: "unsigned short", size: 16, encoding: DW_ATE_unsigned)
!377 = !DIDerivedType(tag: DW_TAG_member, name: "_vtable_offset", scope: !348, file: !349, line: 78, baseType: !378, size: 8, offset: 1040)
!378 = !DIBasicType(name: "signed char", size: 8, encoding: DW_ATE_signed_char)
!379 = !DIDerivedType(tag: DW_TAG_member, name: "_shortbuf", scope: !348, file: !349, line: 79, baseType: !380, size: 8, offset: 1048)
!380 = !DICompositeType(tag: DW_TAG_array_type, baseType: !354, size: 8, elements: !24)
!381 = !DIDerivedType(tag: DW_TAG_member, name: "_lock", scope: !348, file: !349, line: 81, baseType: !382, size: 64, offset: 1088)
!382 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !383, size: 64)
!383 = !DIDerivedType(tag: DW_TAG_typedef, name: "_IO_lock_t", file: !349, line: 43, baseType: null)
!384 = !DIDerivedType(tag: DW_TAG_member, name: "_offset", scope: !348, file: !349, line: 89, baseType: !385, size: 64, offset: 1152)
!385 = !DIDerivedType(tag: DW_TAG_typedef, name: "__off64_t", file: !23, line: 153, baseType: !374)
!386 = !DIDerivedType(tag: DW_TAG_member, name: "_codecvt", scope: !348, file: !349, line: 91, baseType: !387, size: 64, offset: 1216)
!387 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !388, size: 64)
!388 = !DICompositeType(tag: DW_TAG_structure_type, name: "_IO_codecvt", file: !349, line: 37, flags: DIFlagFwdDecl)
!389 = !DIDerivedType(tag: DW_TAG_member, name: "_wide_data", scope: !348, file: !349, line: 92, baseType: !390, size: 64, offset: 1280)
!390 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !391, size: 64)
!391 = !DICompositeType(tag: DW_TAG_structure_type, name: "_IO_wide_data", file: !349, line: 38, flags: DIFlagFwdDecl)
!392 = !DIDerivedType(tag: DW_TAG_member, name: "_freeres_list", scope: !348, file: !349, line: 93, baseType: !369, size: 64, offset: 1344)
!393 = !DIDerivedType(tag: DW_TAG_member, name: "_freeres_buf", scope: !348, file: !349, line: 94, baseType: !394, size: 64, offset: 1408)
!394 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: null, size: 64)
!395 = !DIDerivedType(tag: DW_TAG_member, name: "__pad5", scope: !348, file: !349, line: 95, baseType: !396, size: 64, offset: 1472)
!396 = !DIDerivedType(tag: DW_TAG_typedef, name: "size_t", file: !397, line: 46, baseType: !398)
!397 = !DIFile(filename: "/usr/lib/llvm-14/lib/clang/14.0.0/include/stddef.h", directory: "", checksumkind: CSK_MD5, checksum: "2499dd2361b915724b073282bea3a7bc")
!398 = !DIBasicType(name: "unsigned long", size: 64, encoding: DW_ATE_unsigned)
!399 = !DIDerivedType(tag: DW_TAG_member, name: "_mode", scope: !348, file: !349, line: 96, baseType: !12, size: 32, offset: 1536)
!400 = !DIDerivedType(tag: DW_TAG_member, name: "_unused2", scope: !348, file: !349, line: 98, baseType: !401, size: 160, offset: 1568)
!401 = !DICompositeType(tag: DW_TAG_array_type, baseType: !354, size: 160, elements: !402)
!402 = !{!403}
!403 = !DISubrange(count: 20)
!404 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !405, size: 64)
!405 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !354)
!406 = !DILocalVariable(name: "stream", arg: 1, scope: !342, file: !32, line: 13, type: !345)
!407 = !DILocation(line: 0, scope: !342)
!408 = !DILocalVariable(name: "format", arg: 2, scope: !342, file: !32, line: 13, type: !404)
!409 = !DILocalVariable(name: "buffer", scope: !342, file: !32, line: 15, type: !410)
!410 = !DICompositeType(tag: DW_TAG_array_type, baseType: !354, size: 6144, elements: !411)
!411 = !{!412}
!412 = !DISubrange(count: 768)
!413 = !DILocation(line: 15, column: 10, scope: !342)
!414 = !DILocalVariable(name: "args", scope: !342, file: !32, line: 16, type: !415)
!415 = !DIDerivedType(tag: DW_TAG_typedef, name: "va_list", file: !416, line: 52, baseType: !417)
!416 = !DIFile(filename: "/usr/include/stdio.h", directory: "", checksumkind: CSK_MD5, checksum: "f31eefcc3f15835fc5a4023a625cf609")
!417 = !DIDerivedType(tag: DW_TAG_typedef, name: "__gnuc_va_list", file: !418, line: 32, baseType: !419)
!418 = !DIFile(filename: "/usr/lib/llvm-14/lib/clang/14.0.0/include/stdarg.h", directory: "", checksumkind: CSK_MD5, checksum: "4de3cbd931b589d291e5c39387aecf82")
!419 = !DIDerivedType(tag: DW_TAG_typedef, name: "__builtin_va_list", file: !420, baseType: !421)
!420 = !DIFile(filename: "source/workload.c", directory: "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/triangular-20260929/suite/gramschmidt")
!421 = !DICompositeType(tag: DW_TAG_array_type, baseType: !422, size: 192, elements: !24)
!422 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "__va_list_tag", size: 192, elements: !423)
!423 = !{!424, !425, !426, !427}
!424 = !DIDerivedType(tag: DW_TAG_member, name: "gp_offset", scope: !422, file: !420, line: 16, baseType: !6, size: 32)
!425 = !DIDerivedType(tag: DW_TAG_member, name: "fp_offset", scope: !422, file: !420, line: 16, baseType: !6, size: 32, offset: 32)
!426 = !DIDerivedType(tag: DW_TAG_member, name: "overflow_arg_area", scope: !422, file: !420, line: 16, baseType: !394, size: 64, offset: 64)
!427 = !DIDerivedType(tag: DW_TAG_member, name: "reg_save_area", scope: !422, file: !420, line: 16, baseType: !394, size: 64, offset: 128)
!428 = !DILocation(line: 16, column: 13, scope: !342)
!429 = !DILocation(line: 17, column: 5, scope: !342)
!430 = !DILocation(line: 18, column: 27, scope: !342)
!431 = !DILocation(line: 18, column: 59, scope: !342)
!432 = !DILocation(line: 18, column: 17, scope: !342)
!433 = !DILocalVariable(name: "count", scope: !342, file: !32, line: 18, type: !12)
!434 = !DILocation(line: 19, column: 5, scope: !342)
!435 = !DILocation(line: 20, column: 15, scope: !436)
!436 = distinct !DILexicalBlock(scope: !342, file: !32, line: 20, column: 9)
!437 = !DILocation(line: 20, column: 19, scope: !436)
!438 = !DILocation(line: 20, column: 22, scope: !436)
!439 = !DILocation(line: 20, column: 38, scope: !436)
!440 = !DILocation(line: 20, column: 9, scope: !342)
!441 = !DILocation(line: 20, column: 57, scope: !436)
!442 = !DILocalVariable(name: "i", scope: !443, file: !32, line: 21, type: !12)
!443 = distinct !DILexicalBlock(scope: !342, file: !32, line: 21, column: 5)
!444 = !DILocation(line: 0, scope: !443)
!445 = !DILocation(line: 21, column: 10, scope: !443)
!446 = !DILocation(line: 21, column: 23, scope: !447)
!447 = distinct !DILexicalBlock(scope: !443, file: !32, line: 21, column: 5)
!448 = !DILocation(line: 21, column: 5, scope: !443)
!449 = !DILocation(line: 22, column: 35, scope: !450)
!450 = distinct !DILexicalBlock(scope: !447, file: !32, line: 21, column: 37)
!451 = !DILocation(line: 22, column: 20, scope: !450)
!452 = !DILocation(line: 22, column: 17, scope: !450)
!453 = !DILocation(line: 23, column: 17, scope: !450)
!454 = !DILocation(line: 24, column: 5, scope: !450)
!455 = !DILocation(line: 21, column: 32, scope: !447)
!456 = !DILocation(line: 21, column: 5, scope: !447)
!457 = distinct !{!457, !448, !458, !115}
!458 = !DILocation(line: 24, column: 5, scope: !443)
!459 = !DILocation(line: 29, column: 11, scope: !342)
!460 = !DILocation(line: 31, column: 5, scope: !342)
