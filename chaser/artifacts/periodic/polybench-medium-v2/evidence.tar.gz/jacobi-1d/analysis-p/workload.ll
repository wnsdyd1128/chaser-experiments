; ModuleID = '/workspace/experiments-array-support/chaser/.cache/periodic-polybench/triangular-20260929/suite/jacobi-1d/source/workload.c'
source_filename = "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/triangular-20260929/suite/jacobi-1d/source/workload.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

%struct._IO_FILE = type { i32, i8*, i8*, i8*, i8*, i8*, i8*, i8*, i8*, i8*, i8*, i8*, %struct._IO_marker*, %struct._IO_FILE*, i32, i32, i64, i16, i8, [1 x i8], i8*, i64, %struct._IO_codecvt*, %struct._IO_wide_data*, %struct._IO_FILE*, i8*, i64, i32, [20 x i8] }
%struct._IO_marker = type opaque
%struct._IO_codecvt = type opaque
%struct._IO_wide_data = type opaque
%struct.__va_list_tag = type { i32, i32, i8*, i8* }

@n = dso_local global i32 400, align 4, !dbg !0
@tsteps = dso_local global i32 100, align 4, !dbg !9
@A = dso_local global [400 x double] zeroinitializer, section ".chaser_data.A", align 64, !dbg !33
@B = dso_local global [400 x double] zeroinitializer, section ".chaser_data.B", align 64, !dbg !38
@.str = private unnamed_addr constant [12 x i8] c"ape.analyze\00", section "llvm.metadata"
@.str.1 = private unnamed_addr constant [124 x i8] c"/workspace/experiments-array-support/chaser/.cache/periodic-polybench/triangular-20260929/suite/jacobi-1d/source/workload.c\00", section "llvm.metadata"
@pb_hash = internal global i32 0, align 4, !dbg !30
@workload_jobs = dso_local constant [1 x i32 ()*] [i32 ()* @task_job_polybench], align 8, !dbg !13
@workload_expected = dso_local constant [1 x i32] [i32 548581004], align 4, !dbg !26
@stderr = external global %struct._IO_FILE*, align 8
@.str.2 = private unnamed_addr constant [23 x i8] c"==BEGIN DUMP_ARRAYS==\0A\00", align 1
@.str.3 = private unnamed_addr constant [15 x i8] c"begin dump: %s\00", align 1
@.str.4 = private unnamed_addr constant [2 x i8] c"A\00", align 1
@.str.5 = private unnamed_addr constant [2 x i8] c"\0A\00", align 1
@.str.6 = private unnamed_addr constant [8 x i8] c"%0.2lf \00", align 1
@.str.7 = private unnamed_addr constant [17 x i8] c"\0Aend   dump: %s\0A\00", align 1
@.str.8 = private unnamed_addr constant [23 x i8] c"==END   DUMP_ARRAYS==\0A\00", align 1
@pb_emit = internal global i32 1, align 4, !dbg !40
@llvm.global.annotations = appending global [1 x { i8*, i8*, i8*, i32, i8* }] [{ i8*, i8*, i8*, i32, i8* } { i8* bitcast (i32 ()* @task_job_polybench to i8*), i8* getelementptr inbounds ([12 x i8], [12 x i8]* @.str, i32 0, i32 0), i8* getelementptr inbounds ([124 x i8], [124 x i8]* @.str.1, i32 0, i32 0), i32 105, i8* null }], section "llvm.metadata"

; Function Attrs: noinline nounwind uwtable
define dso_local void @workload_prepare() #0 !dbg !50 {
  ret void, !dbg !54
}

; Function Attrs: noinline nounwind uwtable
define dso_local void @workload_reset(i32 noundef %0) #0 !dbg !55 {
  %2 = alloca i32, align 4
  store i32 %0, i32* %2, align 4
  call void @llvm.dbg.declare(metadata i32* %2, metadata !58, metadata !DIExpression()), !dbg !59
  %3 = load i32, i32* %2, align 4, !dbg !60
  call void @llvm.memset.p0i8.i64(i8* align 64 bitcast ([400 x double]* @A to i8*), i8 0, i64 3200, i1 false), !dbg !61
  call void @llvm.memset.p0i8.i64(i8* align 64 bitcast ([400 x double]* @B to i8*), i8 0, i64 3200, i1 false), !dbg !62
  %4 = load i32, i32* @n, align 4, !dbg !63
  call void @init_array(i32 noundef %4, double* noundef getelementptr inbounds ([400 x double], [400 x double]* @A, i64 0, i64 0), double* noundef getelementptr inbounds ([400 x double], [400 x double]* @B, i64 0, i64 0)), !dbg !64
  ret void, !dbg !65
}

; Function Attrs: nofree nosync nounwind readnone speculatable willreturn
declare void @llvm.dbg.declare(metadata, metadata, metadata) #1

; Function Attrs: argmemonly nofree nounwind willreturn writeonly
declare void @llvm.memset.p0i8.i64(i8* nocapture writeonly, i8, i64, i1 immarg) #2

; Function Attrs: noinline nounwind uwtable
define internal void @init_array(i32 noundef %0, double* noundef %1, double* noundef %2) #0 !dbg !66 {
  %4 = alloca i32, align 4
  %5 = alloca double*, align 8
  %6 = alloca double*, align 8
  %7 = alloca i32, align 4
  store i32 %0, i32* %4, align 4
  call void @llvm.dbg.declare(metadata i32* %4, metadata !70, metadata !DIExpression()), !dbg !71
  store double* %1, double** %5, align 8
  call void @llvm.dbg.declare(metadata double** %5, metadata !72, metadata !DIExpression()), !dbg !73
  store double* %2, double** %6, align 8
  call void @llvm.dbg.declare(metadata double** %6, metadata !74, metadata !DIExpression()), !dbg !75
  call void @llvm.dbg.declare(metadata i32* %7, metadata !76, metadata !DIExpression()), !dbg !77
  store i32 0, i32* %7, align 4, !dbg !78
  br label %8, !dbg !80

8:                                                ; preds = %33, %3
  %9 = load i32, i32* %7, align 4, !dbg !81
  %10 = load i32, i32* %4, align 4, !dbg !83
  %11 = icmp slt i32 %9, %10, !dbg !84
  br i1 %11, label %12, label %36, !dbg !85

12:                                               ; preds = %8
  %13 = load i32, i32* %7, align 4, !dbg !86
  %14 = sitofp i32 %13 to double, !dbg !88
  %15 = fadd double %14, 2.000000e+00, !dbg !89
  %16 = load i32, i32* %4, align 4, !dbg !90
  %17 = sitofp i32 %16 to double, !dbg !90
  %18 = fdiv double %15, %17, !dbg !91
  %19 = load double*, double** %5, align 8, !dbg !92
  %20 = load i32, i32* %7, align 4, !dbg !93
  %21 = sext i32 %20 to i64, !dbg !92
  %22 = getelementptr inbounds double, double* %19, i64 %21, !dbg !92
  store double %18, double* %22, align 8, !dbg !94
  %23 = load i32, i32* %7, align 4, !dbg !95
  %24 = sitofp i32 %23 to double, !dbg !96
  %25 = fadd double %24, 3.000000e+00, !dbg !97
  %26 = load i32, i32* %4, align 4, !dbg !98
  %27 = sitofp i32 %26 to double, !dbg !98
  %28 = fdiv double %25, %27, !dbg !99
  %29 = load double*, double** %6, align 8, !dbg !100
  %30 = load i32, i32* %7, align 4, !dbg !101
  %31 = sext i32 %30 to i64, !dbg !100
  %32 = getelementptr inbounds double, double* %29, i64 %31, !dbg !100
  store double %28, double* %32, align 8, !dbg !102
  br label %33, !dbg !103

33:                                               ; preds = %12
  %34 = load i32, i32* %7, align 4, !dbg !104
  %35 = add nsw i32 %34, 1, !dbg !104
  store i32 %35, i32* %7, align 4, !dbg !104
  br label %8, !dbg !105, !llvm.loop !106

36:                                               ; preds = %8
  ret void, !dbg !109
}

; Function Attrs: noinline nounwind uwtable
define dso_local i32 @task_job_polybench() #0 !dbg !110 {
  %1 = alloca i32, align 4
  %2 = alloca i32, align 4
  %3 = alloca double*, align 8
  %4 = alloca double*, align 8
  %5 = alloca i32, align 4
  %6 = alloca i32, align 4
  %7 = load i32, i32* @tsteps, align 4, !dbg !111
  %8 = load i32, i32* @n, align 4, !dbg !112
  store i32 %7, i32* %1, align 4
  call void @llvm.dbg.declare(metadata i32* %1, metadata !113, metadata !DIExpression()), !dbg !117
  store i32 %8, i32* %2, align 4
  call void @llvm.dbg.declare(metadata i32* %2, metadata !119, metadata !DIExpression()), !dbg !120
  store double* getelementptr inbounds ([400 x double], [400 x double]* @A, i64 0, i64 0), double** %3, align 8
  call void @llvm.dbg.declare(metadata double** %3, metadata !121, metadata !DIExpression()), !dbg !122
  store double* getelementptr inbounds ([400 x double], [400 x double]* @B, i64 0, i64 0), double** %4, align 8
  call void @llvm.dbg.declare(metadata double** %4, metadata !123, metadata !DIExpression()), !dbg !124
  call void @llvm.dbg.declare(metadata i32* %5, metadata !125, metadata !DIExpression()), !dbg !126
  call void @llvm.dbg.declare(metadata i32* %6, metadata !127, metadata !DIExpression()), !dbg !128
  store i32 0, i32* %5, align 4, !dbg !129
  br label %9, !dbg !131

9:                                                ; preds = %74, %0
  %10 = load i32, i32* %5, align 4, !dbg !132
  %11 = icmp slt i32 %10, 100, !dbg !134
  br i1 %11, label %12, label %77, !dbg !135

12:                                               ; preds = %9
  store i32 1, i32* %6, align 4, !dbg !136
  br label %13, !dbg !139

13:                                               ; preds = %16, %12
  %14 = load i32, i32* %6, align 4, !dbg !140
  %15 = icmp slt i32 %14, 399, !dbg !142
  br i1 %15, label %16, label %43, !dbg !143

16:                                               ; preds = %13
  %17 = load double*, double** %3, align 8, !dbg !144
  %18 = load i32, i32* %6, align 4, !dbg !145
  %19 = sub nsw i32 %18, 1, !dbg !146
  %20 = sext i32 %19 to i64, !dbg !144
  %21 = getelementptr inbounds double, double* %17, i64 %20, !dbg !144
  %22 = load double, double* %21, align 8, !dbg !144
  %23 = load double*, double** %3, align 8, !dbg !147
  %24 = load i32, i32* %6, align 4, !dbg !148
  %25 = sext i32 %24 to i64, !dbg !147
  %26 = getelementptr inbounds double, double* %23, i64 %25, !dbg !147
  %27 = load double, double* %26, align 8, !dbg !147
  %28 = fadd double %22, %27, !dbg !149
  %29 = load double*, double** %3, align 8, !dbg !150
  %30 = load i32, i32* %6, align 4, !dbg !151
  %31 = add nsw i32 %30, 1, !dbg !152
  %32 = sext i32 %31 to i64, !dbg !150
  %33 = getelementptr inbounds double, double* %29, i64 %32, !dbg !150
  %34 = load double, double* %33, align 8, !dbg !150
  %35 = fadd double %28, %34, !dbg !153
  %36 = fmul double 3.333300e-01, %35, !dbg !154
  %37 = load double*, double** %4, align 8, !dbg !155
  %38 = load i32, i32* %6, align 4, !dbg !156
  %39 = sext i32 %38 to i64, !dbg !155
  %40 = getelementptr inbounds double, double* %37, i64 %39, !dbg !155
  store double %36, double* %40, align 8, !dbg !157
  %41 = load i32, i32* %6, align 4, !dbg !158
  %42 = add nsw i32 %41, 1, !dbg !158
  store i32 %42, i32* %6, align 4, !dbg !158
  br label %13, !dbg !159, !llvm.loop !160

43:                                               ; preds = %13
  store i32 1, i32* %6, align 4, !dbg !162
  br label %44, !dbg !164

44:                                               ; preds = %47, %43
  %45 = load i32, i32* %6, align 4, !dbg !165
  %46 = icmp slt i32 %45, 399, !dbg !167
  br i1 %46, label %47, label %74, !dbg !168

47:                                               ; preds = %44
  %48 = load double*, double** %4, align 8, !dbg !169
  %49 = load i32, i32* %6, align 4, !dbg !170
  %50 = sub nsw i32 %49, 1, !dbg !171
  %51 = sext i32 %50 to i64, !dbg !169
  %52 = getelementptr inbounds double, double* %48, i64 %51, !dbg !169
  %53 = load double, double* %52, align 8, !dbg !169
  %54 = load double*, double** %4, align 8, !dbg !172
  %55 = load i32, i32* %6, align 4, !dbg !173
  %56 = sext i32 %55 to i64, !dbg !172
  %57 = getelementptr inbounds double, double* %54, i64 %56, !dbg !172
  %58 = load double, double* %57, align 8, !dbg !172
  %59 = fadd double %53, %58, !dbg !174
  %60 = load double*, double** %4, align 8, !dbg !175
  %61 = load i32, i32* %6, align 4, !dbg !176
  %62 = add nsw i32 %61, 1, !dbg !177
  %63 = sext i32 %62 to i64, !dbg !175
  %64 = getelementptr inbounds double, double* %60, i64 %63, !dbg !175
  %65 = load double, double* %64, align 8, !dbg !175
  %66 = fadd double %59, %65, !dbg !178
  %67 = fmul double 3.333300e-01, %66, !dbg !179
  %68 = load double*, double** %3, align 8, !dbg !180
  %69 = load i32, i32* %6, align 4, !dbg !181
  %70 = sext i32 %69 to i64, !dbg !180
  %71 = getelementptr inbounds double, double* %68, i64 %70, !dbg !180
  store double %67, double* %71, align 8, !dbg !182
  %72 = load i32, i32* %6, align 4, !dbg !183
  %73 = add nsw i32 %72, 1, !dbg !183
  store i32 %73, i32* %6, align 4, !dbg !183
  br label %44, !dbg !184, !llvm.loop !185

74:                                               ; preds = %44
  %75 = load i32, i32* %5, align 4, !dbg !187
  %76 = add nsw i32 %75, 1, !dbg !187
  store i32 %76, i32* %5, align 4, !dbg !187
  br label %9, !dbg !188, !llvm.loop !189

77:                                               ; preds = %9
  ret i32 0, !dbg !191
}

; Function Attrs: noinline nounwind uwtable
define dso_local i32 @workload_checksum(i32 noundef %0) #0 !dbg !192 {
  %2 = alloca i32, align 4
  store i32 %0, i32* %2, align 4
  call void @llvm.dbg.declare(metadata i32* %2, metadata !195, metadata !DIExpression()), !dbg !196
  %3 = load i32, i32* %2, align 4, !dbg !197
  store i32 -2128831035, i32* @pb_hash, align 4, !dbg !198
  %4 = load i32, i32* @n, align 4, !dbg !199
  call void @print_array(i32 noundef %4, double* noundef getelementptr inbounds ([400 x double], [400 x double]* @A, i64 0, i64 0)), !dbg !200
  %5 = load i32, i32* @pb_hash, align 4, !dbg !201
  ret i32 %5, !dbg !202
}

; Function Attrs: noinline nounwind uwtable
define internal void @print_array(i32 noundef %0, double* noundef %1) #0 !dbg !203 {
  %3 = alloca i32, align 4
  %4 = alloca double*, align 8
  %5 = alloca i32, align 4
  store i32 %0, i32* %3, align 4
  call void @llvm.dbg.declare(metadata i32* %3, metadata !206, metadata !DIExpression()), !dbg !207
  store double* %1, double** %4, align 8
  call void @llvm.dbg.declare(metadata double** %4, metadata !208, metadata !DIExpression()), !dbg !209
  call void @llvm.dbg.declare(metadata i32* %5, metadata !210, metadata !DIExpression()), !dbg !211
  %6 = load %struct._IO_FILE*, %struct._IO_FILE** @stderr, align 8, !dbg !212
  %7 = call i32 (%struct._IO_FILE*, i8*, ...) @pb_fprintf(%struct._IO_FILE* noundef %6, i8* noundef getelementptr inbounds ([23 x i8], [23 x i8]* @.str.2, i64 0, i64 0)), !dbg !212
  %8 = load %struct._IO_FILE*, %struct._IO_FILE** @stderr, align 8, !dbg !213
  %9 = call i32 (%struct._IO_FILE*, i8*, ...) @pb_fprintf(%struct._IO_FILE* noundef %8, i8* noundef getelementptr inbounds ([15 x i8], [15 x i8]* @.str.3, i64 0, i64 0), i8* noundef getelementptr inbounds ([2 x i8], [2 x i8]* @.str.4, i64 0, i64 0)), !dbg !213
  store i32 0, i32* %5, align 4, !dbg !214
  br label %10, !dbg !216

10:                                               ; preds = %29, %2
  %11 = load i32, i32* %5, align 4, !dbg !217
  %12 = load i32, i32* %3, align 4, !dbg !219
  %13 = icmp slt i32 %11, %12, !dbg !220
  br i1 %13, label %14, label %32, !dbg !221

14:                                               ; preds = %10
  %15 = load i32, i32* %5, align 4, !dbg !222
  %16 = srem i32 %15, 20, !dbg !225
  %17 = icmp eq i32 %16, 0, !dbg !226
  br i1 %17, label %18, label %21, !dbg !227

18:                                               ; preds = %14
  %19 = load %struct._IO_FILE*, %struct._IO_FILE** @stderr, align 8, !dbg !228
  %20 = call i32 (%struct._IO_FILE*, i8*, ...) @pb_fprintf(%struct._IO_FILE* noundef %19, i8* noundef getelementptr inbounds ([2 x i8], [2 x i8]* @.str.5, i64 0, i64 0)), !dbg !229
  br label %21, !dbg !229

21:                                               ; preds = %18, %14
  %22 = load %struct._IO_FILE*, %struct._IO_FILE** @stderr, align 8, !dbg !230
  %23 = load double*, double** %4, align 8, !dbg !231
  %24 = load i32, i32* %5, align 4, !dbg !232
  %25 = sext i32 %24 to i64, !dbg !231
  %26 = getelementptr inbounds double, double* %23, i64 %25, !dbg !231
  %27 = load double, double* %26, align 8, !dbg !231
  %28 = call i32 (%struct._IO_FILE*, i8*, ...) @pb_fprintf(%struct._IO_FILE* noundef %22, i8* noundef getelementptr inbounds ([8 x i8], [8 x i8]* @.str.6, i64 0, i64 0), double noundef %27), !dbg !233
  br label %29, !dbg !234

29:                                               ; preds = %21
  %30 = load i32, i32* %5, align 4, !dbg !235
  %31 = add nsw i32 %30, 1, !dbg !235
  store i32 %31, i32* %5, align 4, !dbg !235
  br label %10, !dbg !236, !llvm.loop !237

32:                                               ; preds = %10
  %33 = load %struct._IO_FILE*, %struct._IO_FILE** @stderr, align 8, !dbg !239
  %34 = call i32 (%struct._IO_FILE*, i8*, ...) @pb_fprintf(%struct._IO_FILE* noundef %33, i8* noundef getelementptr inbounds ([17 x i8], [17 x i8]* @.str.7, i64 0, i64 0), i8* noundef getelementptr inbounds ([2 x i8], [2 x i8]* @.str.4, i64 0, i64 0)), !dbg !239
  %35 = load %struct._IO_FILE*, %struct._IO_FILE** @stderr, align 8, !dbg !240
  %36 = call i32 (%struct._IO_FILE*, i8*, ...) @pb_fprintf(%struct._IO_FILE* noundef %35, i8* noundef getelementptr inbounds ([23 x i8], [23 x i8]* @.str.8, i64 0, i64 0)), !dbg !240
  ret void, !dbg !241
}

; Function Attrs: noinline nounwind uwtable
define internal i32 @pb_fprintf(%struct._IO_FILE* noundef %0, i8* noundef %1, ...) #0 !dbg !242 {
  %3 = alloca %struct._IO_FILE*, align 8
  %4 = alloca i8*, align 8
  %5 = alloca [768 x i8], align 16
  %6 = alloca [1 x %struct.__va_list_tag], align 16
  %7 = alloca i32, align 4
  %8 = alloca i32, align 4
  store %struct._IO_FILE* %0, %struct._IO_FILE** %3, align 8
  call void @llvm.dbg.declare(metadata %struct._IO_FILE** %3, metadata !306, metadata !DIExpression()), !dbg !307
  store i8* %1, i8** %4, align 8
  call void @llvm.dbg.declare(metadata i8** %4, metadata !308, metadata !DIExpression()), !dbg !309
  call void @llvm.dbg.declare(metadata [768 x i8]* %5, metadata !310, metadata !DIExpression()), !dbg !314
  call void @llvm.dbg.declare(metadata [1 x %struct.__va_list_tag]* %6, metadata !315, metadata !DIExpression()), !dbg !329
  %9 = getelementptr inbounds [1 x %struct.__va_list_tag], [1 x %struct.__va_list_tag]* %6, i64 0, i64 0, !dbg !330
  %10 = bitcast %struct.__va_list_tag* %9 to i8*, !dbg !330
  call void @llvm.va_start(i8* %10), !dbg !330
  call void @llvm.dbg.declare(metadata i32* %7, metadata !331, metadata !DIExpression()), !dbg !332
  %11 = getelementptr inbounds [768 x i8], [768 x i8]* %5, i64 0, i64 0, !dbg !333
  %12 = load i8*, i8** %4, align 8, !dbg !334
  %13 = getelementptr inbounds [1 x %struct.__va_list_tag], [1 x %struct.__va_list_tag]* %6, i64 0, i64 0, !dbg !335
  %14 = call i32 @vsnprintf(i8* noundef %11, i64 noundef 768, i8* noundef %12, %struct.__va_list_tag* noundef %13) #6, !dbg !336
  store i32 %14, i32* %7, align 4, !dbg !332
  %15 = getelementptr inbounds [1 x %struct.__va_list_tag], [1 x %struct.__va_list_tag]* %6, i64 0, i64 0, !dbg !337
  %16 = bitcast %struct.__va_list_tag* %15 to i8*, !dbg !337
  call void @llvm.va_end(i8* %16), !dbg !337
  %17 = load i32, i32* %7, align 4, !dbg !338
  %18 = icmp slt i32 %17, 0, !dbg !340
  br i1 %18, label %23, label %19, !dbg !341

19:                                               ; preds = %2
  %20 = load i32, i32* %7, align 4, !dbg !342
  %21 = zext i32 %20 to i64, !dbg !343
  %22 = icmp uge i64 %21, 768, !dbg !344
  br i1 %22, label %23, label %24, !dbg !345

23:                                               ; preds = %19, %2
  call void @abort() #7, !dbg !346
  unreachable, !dbg !346

24:                                               ; preds = %19
  call void @llvm.dbg.declare(metadata i32* %8, metadata !347, metadata !DIExpression()), !dbg !349
  store i32 0, i32* %8, align 4, !dbg !349
  br label %25, !dbg !350

25:                                               ; preds = %39, %24
  %26 = load i32, i32* %8, align 4, !dbg !351
  %27 = load i32, i32* %7, align 4, !dbg !353
  %28 = icmp slt i32 %26, %27, !dbg !354
  br i1 %28, label %29, label %42, !dbg !355

29:                                               ; preds = %25
  %30 = load i32, i32* %8, align 4, !dbg !356
  %31 = sext i32 %30 to i64, !dbg !358
  %32 = getelementptr inbounds [768 x i8], [768 x i8]* %5, i64 0, i64 %31, !dbg !358
  %33 = load i8, i8* %32, align 1, !dbg !358
  %34 = zext i8 %33 to i32, !dbg !359
  %35 = load i32, i32* @pb_hash, align 4, !dbg !360
  %36 = xor i32 %35, %34, !dbg !360
  store i32 %36, i32* @pb_hash, align 4, !dbg !360
  %37 = load i32, i32* @pb_hash, align 4, !dbg !361
  %38 = mul i32 %37, 16777619, !dbg !361
  store i32 %38, i32* @pb_hash, align 4, !dbg !361
  br label %39, !dbg !362

39:                                               ; preds = %29
  %40 = load i32, i32* %8, align 4, !dbg !363
  %41 = add nsw i32 %40, 1, !dbg !363
  store i32 %41, i32* %8, align 4, !dbg !363
  br label %25, !dbg !364, !llvm.loop !365

42:                                               ; preds = %25
  %43 = load %struct._IO_FILE*, %struct._IO_FILE** %3, align 8, !dbg !367
  %44 = load i32, i32* @pb_emit, align 4, !dbg !368
  %45 = load i32, i32* %7, align 4, !dbg !369
  ret i32 %45, !dbg !370
}

; Function Attrs: nofree nosync nounwind willreturn
declare void @llvm.va_start(i8*) #3

; Function Attrs: nounwind
declare i32 @vsnprintf(i8* noundef, i64 noundef, i8* noundef, %struct.__va_list_tag* noundef) #4

; Function Attrs: nofree nosync nounwind willreturn
declare void @llvm.va_end(i8*) #3

; Function Attrs: noreturn nounwind
declare void @abort() #5

attributes #0 = { noinline nounwind uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { nofree nosync nounwind readnone speculatable willreturn }
attributes #2 = { argmemonly nofree nounwind willreturn writeonly }
attributes #3 = { nofree nosync nounwind willreturn }
attributes #4 = { nounwind "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #5 = { noreturn nounwind "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #6 = { nounwind }
attributes #7 = { noreturn nounwind }

!llvm.dbg.cu = !{!2}
!llvm.module.flags = !{!42, !43, !44, !45, !46, !47, !48}
!llvm.ident = !{!49}

!0 = !DIGlobalVariableExpression(var: !1, expr: !DIExpression())
!1 = distinct !DIGlobalVariable(name: "n", scope: !2, file: !11, line: 96, type: !12, isLocal: false, isDefinition: true)
!2 = distinct !DICompileUnit(language: DW_LANG_C99, file: !3, producer: "Ubuntu clang version 14.0.0-1ubuntu1.1", isOptimized: false, runtimeVersion: 0, emissionKind: FullDebug, retainedTypes: !4, globals: !8, splitDebugInlining: false, nameTableKind: None)
!3 = !DIFile(filename: "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/triangular-20260929/suite/jacobi-1d/source/workload.c", directory: "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/triangular-20260929/suite/jacobi-1d/analysis-p", checksumkind: CSK_MD5, checksum: "32f13b44e0cda1ff9f9c858c735c495e")
!4 = !{!5, !6, !7}
!5 = !DIBasicType(name: "double", size: 64, encoding: DW_ATE_float)
!6 = !DIBasicType(name: "unsigned int", size: 32, encoding: DW_ATE_unsigned)
!7 = !DIBasicType(name: "unsigned char", size: 8, encoding: DW_ATE_unsigned_char)
!8 = !{!0, !9, !13, !26, !30, !33, !38, !40}
!9 = !DIGlobalVariableExpression(var: !10, expr: !DIExpression())
!10 = distinct !DIGlobalVariable(name: "tsteps", scope: !2, file: !11, line: 97, type: !12, isLocal: false, isDefinition: true)
!11 = !DIFile(filename: "source/workload.c", directory: "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/triangular-20260929/suite/jacobi-1d", checksumkind: CSK_MD5, checksum: "32f13b44e0cda1ff9f9c858c735c495e")
!12 = !DIBasicType(name: "int", size: 32, encoding: DW_ATE_signed)
!13 = !DIGlobalVariableExpression(var: !14, expr: !DIExpression())
!14 = distinct !DIGlobalVariable(name: "workload_jobs", scope: !2, file: !11, line: 115, type: !15, isLocal: false, isDefinition: true)
!15 = !DICompositeType(tag: DW_TAG_array_type, baseType: !16, size: 64, elements: !24)
!16 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !17)
!17 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !18, size: 64)
!18 = !DISubroutineType(types: !19)
!19 = !{!20}
!20 = !DIDerivedType(tag: DW_TAG_typedef, name: "uint32_t", file: !21, line: 26, baseType: !22)
!21 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/stdint-uintn.h", directory: "", checksumkind: CSK_MD5, checksum: "2bf2ae53c58c01b1a1b9383b5195125c")
!22 = !DIDerivedType(tag: DW_TAG_typedef, name: "__uint32_t", file: !23, line: 42, baseType: !6)
!23 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/types.h", directory: "", checksumkind: CSK_MD5, checksum: "d108b5f93a74c50510d7d9bc0ab36df9")
!24 = !{!25}
!25 = !DISubrange(count: 1)
!26 = !DIGlobalVariableExpression(var: !27, expr: !DIExpression())
!27 = distinct !DIGlobalVariable(name: "workload_expected", scope: !2, file: !11, line: 119, type: !28, isLocal: false, isDefinition: true)
!28 = !DICompositeType(tag: DW_TAG_array_type, baseType: !29, size: 32, elements: !24)
!29 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !20)
!30 = !DIGlobalVariableExpression(var: !31, expr: !DIExpression())
!31 = distinct !DIGlobalVariable(name: "pb_hash", scope: !2, file: !32, line: 9, type: !20, isLocal: true, isDefinition: true)
!32 = !DIFile(filename: "source/adapter.h", directory: "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/triangular-20260929/suite/jacobi-1d", checksumkind: CSK_MD5, checksum: "26a6068928b2092758f244a9d00163d7")
!33 = !DIGlobalVariableExpression(var: !34, expr: !DIExpression())
!34 = distinct !DIGlobalVariable(name: "A", scope: !2, file: !11, line: 34, type: !35, isLocal: false, isDefinition: true, align: 512)
!35 = !DICompositeType(tag: DW_TAG_array_type, baseType: !5, size: 25600, elements: !36)
!36 = !{!37}
!37 = !DISubrange(count: 400)
!38 = !DIGlobalVariableExpression(var: !39, expr: !DIExpression())
!39 = distinct !DIGlobalVariable(name: "B", scope: !2, file: !11, line: 35, type: !35, isLocal: false, isDefinition: true, align: 512)
!40 = !DIGlobalVariableExpression(var: !41, expr: !DIExpression())
!41 = distinct !DIGlobalVariable(name: "pb_emit", scope: !2, file: !32, line: 10, type: !12, isLocal: true, isDefinition: true)
!42 = !{i32 7, !"Dwarf Version", i32 5}
!43 = !{i32 2, !"Debug Info Version", i32 3}
!44 = !{i32 1, !"wchar_size", i32 4}
!45 = !{i32 7, !"PIC Level", i32 2}
!46 = !{i32 7, !"PIE Level", i32 2}
!47 = !{i32 7, !"uwtable", i32 1}
!48 = !{i32 7, !"frame-pointer", i32 2}
!49 = !{!"Ubuntu clang version 14.0.0-1ubuntu1.1"}
!50 = distinct !DISubprogram(name: "workload_prepare", scope: !11, file: !11, line: 98, type: !51, scopeLine: 98, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !2, retainedNodes: !53)
!51 = !DISubroutineType(types: !52)
!52 = !{null}
!53 = !{}
!54 = !DILocation(line: 98, column: 30, scope: !50)
!55 = distinct !DISubprogram(name: "workload_reset", scope: !11, file: !11, line: 99, type: !56, scopeLine: 99, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !2, retainedNodes: !53)
!56 = !DISubroutineType(types: !57)
!57 = !{null, !6}
!58 = !DILocalVariable(name: "task", arg: 1, scope: !55, file: !11, line: 99, type: !6)
!59 = !DILocation(line: 99, column: 30, scope: !55)
!60 = !DILocation(line: 100, column: 9, scope: !55)
!61 = !DILocation(line: 101, column: 3, scope: !55)
!62 = !DILocation(line: 102, column: 3, scope: !55)
!63 = !DILocation(line: 103, column: 15, scope: !55)
!64 = !DILocation(line: 103, column: 3, scope: !55)
!65 = !DILocation(line: 104, column: 1, scope: !55)
!66 = distinct !DISubprogram(name: "init_array", scope: !11, file: !11, line: 37, type: !67, scopeLine: 40, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition, unit: !2, retainedNodes: !53)
!67 = !DISubroutineType(types: !68)
!68 = !{null, !12, !69, !69}
!69 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !5, size: 64)
!70 = !DILocalVariable(name: "n", arg: 1, scope: !66, file: !11, line: 37, type: !12)
!71 = !DILocation(line: 37, column: 22, scope: !66)
!72 = !DILocalVariable(name: "A", arg: 2, scope: !66, file: !11, line: 38, type: !69)
!73 = !DILocation(line: 38, column: 14, scope: !66)
!74 = !DILocalVariable(name: "B", arg: 3, scope: !66, file: !11, line: 39, type: !69)
!75 = !DILocation(line: 39, column: 14, scope: !66)
!76 = !DILocalVariable(name: "i", scope: !66, file: !11, line: 41, type: !12)
!77 = !DILocation(line: 41, column: 7, scope: !66)
!78 = !DILocation(line: 43, column: 10, scope: !79)
!79 = distinct !DILexicalBlock(scope: !66, file: !11, line: 43, column: 3)
!80 = !DILocation(line: 43, column: 8, scope: !79)
!81 = !DILocation(line: 43, column: 15, scope: !82)
!82 = distinct !DILexicalBlock(scope: !79, file: !11, line: 43, column: 3)
!83 = !DILocation(line: 43, column: 19, scope: !82)
!84 = !DILocation(line: 43, column: 17, scope: !82)
!85 = !DILocation(line: 43, column: 3, scope: !79)
!86 = !DILocation(line: 45, column: 22, scope: !87)
!87 = distinct !DILexicalBlock(scope: !82, file: !11, line: 44, column: 7)
!88 = !DILocation(line: 45, column: 10, scope: !87)
!89 = !DILocation(line: 45, column: 23, scope: !87)
!90 = !DILocation(line: 45, column: 30, scope: !87)
!91 = !DILocation(line: 45, column: 28, scope: !87)
!92 = !DILocation(line: 45, column: 2, scope: !87)
!93 = !DILocation(line: 45, column: 4, scope: !87)
!94 = !DILocation(line: 45, column: 7, scope: !87)
!95 = !DILocation(line: 46, column: 22, scope: !87)
!96 = !DILocation(line: 46, column: 10, scope: !87)
!97 = !DILocation(line: 46, column: 23, scope: !87)
!98 = !DILocation(line: 46, column: 30, scope: !87)
!99 = !DILocation(line: 46, column: 28, scope: !87)
!100 = !DILocation(line: 46, column: 2, scope: !87)
!101 = !DILocation(line: 46, column: 4, scope: !87)
!102 = !DILocation(line: 46, column: 7, scope: !87)
!103 = !DILocation(line: 47, column: 7, scope: !87)
!104 = !DILocation(line: 43, column: 23, scope: !82)
!105 = !DILocation(line: 43, column: 3, scope: !82)
!106 = distinct !{!106, !85, !107, !108}
!107 = !DILocation(line: 47, column: 7, scope: !79)
!108 = !{!"llvm.loop.mustprogress"}
!109 = !DILocation(line: 48, column: 1, scope: !66)
!110 = distinct !DISubprogram(name: "task_job_polybench", scope: !11, file: !11, line: 105, type: !18, scopeLine: 105, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !2, retainedNodes: !53)
!111 = !DILocation(line: 106, column: 20, scope: !110)
!112 = !DILocation(line: 106, column: 28, scope: !110)
!113 = !DILocalVariable(name: "tsteps", arg: 1, scope: !114, file: !11, line: 75, type: !12)
!114 = distinct !DISubprogram(name: "kernel_jacobi_1d", scope: !11, file: !11, line: 75, type: !115, scopeLine: 79, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition, unit: !2, retainedNodes: !53)
!115 = !DISubroutineType(types: !116)
!116 = !{null, !12, !12, !69, !69}
!117 = !DILocation(line: 75, column: 65, scope: !114, inlinedAt: !118)
!118 = distinct !DILocation(line: 106, column: 3, scope: !110)
!119 = !DILocalVariable(name: "n", arg: 2, scope: !114, file: !11, line: 76, type: !12)
!120 = !DILocation(line: 76, column: 12, scope: !114, inlinedAt: !118)
!121 = !DILocalVariable(name: "A", arg: 3, scope: !114, file: !11, line: 77, type: !69)
!122 = !DILocation(line: 77, column: 18, scope: !114, inlinedAt: !118)
!123 = !DILocalVariable(name: "B", arg: 4, scope: !114, file: !11, line: 78, type: !69)
!124 = !DILocation(line: 78, column: 18, scope: !114, inlinedAt: !118)
!125 = !DILocalVariable(name: "t", scope: !114, file: !11, line: 80, type: !12)
!126 = !DILocation(line: 80, column: 7, scope: !114, inlinedAt: !118)
!127 = !DILocalVariable(name: "i", scope: !114, file: !11, line: 80, type: !12)
!128 = !DILocation(line: 80, column: 10, scope: !114, inlinedAt: !118)
!129 = !DILocation(line: 83, column: 10, scope: !130, inlinedAt: !118)
!130 = distinct !DILexicalBlock(scope: !114, file: !11, line: 83, column: 3)
!131 = !DILocation(line: 83, column: 8, scope: !130, inlinedAt: !118)
!132 = !DILocation(line: 83, column: 15, scope: !133, inlinedAt: !118)
!133 = distinct !DILexicalBlock(scope: !130, file: !11, line: 83, column: 3)
!134 = !DILocation(line: 83, column: 17, scope: !133, inlinedAt: !118)
!135 = !DILocation(line: 83, column: 3, scope: !130, inlinedAt: !118)
!136 = !DILocation(line: 85, column: 14, scope: !137, inlinedAt: !118)
!137 = distinct !DILexicalBlock(scope: !138, file: !11, line: 85, column: 7)
!138 = distinct !DILexicalBlock(scope: !133, file: !11, line: 84, column: 5)
!139 = !DILocation(line: 85, column: 12, scope: !137, inlinedAt: !118)
!140 = !DILocation(line: 85, column: 19, scope: !141, inlinedAt: !118)
!141 = distinct !DILexicalBlock(scope: !137, file: !11, line: 85, column: 7)
!142 = !DILocation(line: 85, column: 21, scope: !141, inlinedAt: !118)
!143 = !DILocation(line: 85, column: 7, scope: !137, inlinedAt: !118)
!144 = !DILocation(line: 86, column: 20, scope: !141, inlinedAt: !118)
!145 = !DILocation(line: 86, column: 22, scope: !141, inlinedAt: !118)
!146 = !DILocation(line: 86, column: 23, scope: !141, inlinedAt: !118)
!147 = !DILocation(line: 86, column: 29, scope: !141, inlinedAt: !118)
!148 = !DILocation(line: 86, column: 31, scope: !141, inlinedAt: !118)
!149 = !DILocation(line: 86, column: 27, scope: !141, inlinedAt: !118)
!150 = !DILocation(line: 86, column: 36, scope: !141, inlinedAt: !118)
!151 = !DILocation(line: 86, column: 38, scope: !141, inlinedAt: !118)
!152 = !DILocation(line: 86, column: 40, scope: !141, inlinedAt: !118)
!153 = !DILocation(line: 86, column: 34, scope: !141, inlinedAt: !118)
!154 = !DILocation(line: 86, column: 17, scope: !141, inlinedAt: !118)
!155 = !DILocation(line: 86, column: 2, scope: !141, inlinedAt: !118)
!156 = !DILocation(line: 86, column: 4, scope: !141, inlinedAt: !118)
!157 = !DILocation(line: 86, column: 7, scope: !141, inlinedAt: !118)
!158 = !DILocation(line: 85, column: 35, scope: !141, inlinedAt: !118)
!159 = !DILocation(line: 85, column: 7, scope: !141, inlinedAt: !118)
!160 = distinct !{!160, !143, !161, !108}
!161 = !DILocation(line: 86, column: 44, scope: !137, inlinedAt: !118)
!162 = !DILocation(line: 87, column: 14, scope: !163, inlinedAt: !118)
!163 = distinct !DILexicalBlock(scope: !138, file: !11, line: 87, column: 7)
!164 = !DILocation(line: 87, column: 12, scope: !163, inlinedAt: !118)
!165 = !DILocation(line: 87, column: 19, scope: !166, inlinedAt: !118)
!166 = distinct !DILexicalBlock(scope: !163, file: !11, line: 87, column: 7)
!167 = !DILocation(line: 87, column: 21, scope: !166, inlinedAt: !118)
!168 = !DILocation(line: 87, column: 7, scope: !163, inlinedAt: !118)
!169 = !DILocation(line: 88, column: 20, scope: !166, inlinedAt: !118)
!170 = !DILocation(line: 88, column: 22, scope: !166, inlinedAt: !118)
!171 = !DILocation(line: 88, column: 23, scope: !166, inlinedAt: !118)
!172 = !DILocation(line: 88, column: 29, scope: !166, inlinedAt: !118)
!173 = !DILocation(line: 88, column: 31, scope: !166, inlinedAt: !118)
!174 = !DILocation(line: 88, column: 27, scope: !166, inlinedAt: !118)
!175 = !DILocation(line: 88, column: 36, scope: !166, inlinedAt: !118)
!176 = !DILocation(line: 88, column: 38, scope: !166, inlinedAt: !118)
!177 = !DILocation(line: 88, column: 40, scope: !166, inlinedAt: !118)
!178 = !DILocation(line: 88, column: 34, scope: !166, inlinedAt: !118)
!179 = !DILocation(line: 88, column: 17, scope: !166, inlinedAt: !118)
!180 = !DILocation(line: 88, column: 2, scope: !166, inlinedAt: !118)
!181 = !DILocation(line: 88, column: 4, scope: !166, inlinedAt: !118)
!182 = !DILocation(line: 88, column: 7, scope: !166, inlinedAt: !118)
!183 = !DILocation(line: 87, column: 35, scope: !166, inlinedAt: !118)
!184 = !DILocation(line: 87, column: 7, scope: !166, inlinedAt: !118)
!185 = distinct !{!185, !168, !186, !108}
!186 = !DILocation(line: 88, column: 44, scope: !163, inlinedAt: !118)
!187 = !DILocation(line: 83, column: 32, scope: !133, inlinedAt: !118)
!188 = !DILocation(line: 83, column: 3, scope: !133, inlinedAt: !118)
!189 = distinct !{!189, !135, !190, !108}
!190 = !DILocation(line: 89, column: 5, scope: !130, inlinedAt: !118)
!191 = !DILocation(line: 107, column: 3, scope: !110)
!192 = distinct !DISubprogram(name: "workload_checksum", scope: !11, file: !11, line: 109, type: !193, scopeLine: 109, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !2, retainedNodes: !53)
!193 = !DISubroutineType(types: !194)
!194 = !{!20, !6}
!195 = !DILocalVariable(name: "task", arg: 1, scope: !192, file: !11, line: 109, type: !6)
!196 = !DILocation(line: 109, column: 37, scope: !192)
!197 = !DILocation(line: 110, column: 9, scope: !192)
!198 = !DILocation(line: 111, column: 11, scope: !192)
!199 = !DILocation(line: 112, column: 15, scope: !192)
!200 = !DILocation(line: 112, column: 3, scope: !192)
!201 = !DILocation(line: 113, column: 10, scope: !192)
!202 = !DILocation(line: 113, column: 3, scope: !192)
!203 = distinct !DISubprogram(name: "print_array", scope: !11, file: !11, line: 54, type: !204, scopeLine: 57, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition, unit: !2, retainedNodes: !53)
!204 = !DISubroutineType(types: !205)
!205 = !{null, !12, !69}
!206 = !DILocalVariable(name: "n", arg: 1, scope: !203, file: !11, line: 54, type: !12)
!207 = !DILocation(line: 54, column: 22, scope: !203)
!208 = !DILocalVariable(name: "A", arg: 2, scope: !203, file: !11, line: 55, type: !69)
!209 = !DILocation(line: 55, column: 14, scope: !203)
!210 = !DILocalVariable(name: "i", scope: !203, file: !11, line: 58, type: !12)
!211 = !DILocation(line: 58, column: 7, scope: !203)
!212 = !DILocation(line: 60, column: 3, scope: !203)
!213 = !DILocation(line: 61, column: 3, scope: !203)
!214 = !DILocation(line: 62, column: 10, scope: !215)
!215 = distinct !DILexicalBlock(scope: !203, file: !11, line: 62, column: 3)
!216 = !DILocation(line: 62, column: 8, scope: !215)
!217 = !DILocation(line: 62, column: 15, scope: !218)
!218 = distinct !DILexicalBlock(scope: !215, file: !11, line: 62, column: 3)
!219 = !DILocation(line: 62, column: 19, scope: !218)
!220 = !DILocation(line: 62, column: 17, scope: !218)
!221 = !DILocation(line: 62, column: 3, scope: !215)
!222 = !DILocation(line: 64, column: 11, scope: !223)
!223 = distinct !DILexicalBlock(scope: !224, file: !11, line: 64, column: 11)
!224 = distinct !DILexicalBlock(scope: !218, file: !11, line: 63, column: 5)
!225 = !DILocation(line: 64, column: 13, scope: !223)
!226 = !DILocation(line: 64, column: 18, scope: !223)
!227 = !DILocation(line: 64, column: 11, scope: !224)
!228 = !DILocation(line: 64, column: 32, scope: !223)
!229 = !DILocation(line: 64, column: 24, scope: !223)
!230 = !DILocation(line: 65, column: 15, scope: !224)
!231 = !DILocation(line: 65, column: 60, scope: !224)
!232 = !DILocation(line: 65, column: 62, scope: !224)
!233 = !DILocation(line: 65, column: 7, scope: !224)
!234 = !DILocation(line: 66, column: 5, scope: !224)
!235 = !DILocation(line: 62, column: 23, scope: !218)
!236 = !DILocation(line: 62, column: 3, scope: !218)
!237 = distinct !{!237, !221, !238, !108}
!238 = !DILocation(line: 66, column: 5, scope: !215)
!239 = !DILocation(line: 67, column: 3, scope: !203)
!240 = !DILocation(line: 68, column: 3, scope: !203)
!241 = !DILocation(line: 69, column: 1, scope: !203)
!242 = distinct !DISubprogram(name: "pb_fprintf", scope: !32, file: !32, line: 13, type: !243, scopeLine: 14, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition, unit: !2, retainedNodes: !53)
!243 = !DISubroutineType(types: !244)
!244 = !{!12, !245, !304, null}
!245 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !246, size: 64)
!246 = !DIDerivedType(tag: DW_TAG_typedef, name: "FILE", file: !247, line: 7, baseType: !248)
!247 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/types/FILE.h", directory: "", checksumkind: CSK_MD5, checksum: "571f9fb6223c42439075fdde11a0de5d")
!248 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "_IO_FILE", file: !249, line: 49, size: 1728, elements: !250)
!249 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/types/struct_FILE.h", directory: "", checksumkind: CSK_MD5, checksum: "1bad07471b7974df4ecc1d1c2ca207e6")
!250 = !{!251, !252, !255, !256, !257, !258, !259, !260, !261, !262, !263, !264, !265, !268, !270, !271, !272, !275, !277, !279, !281, !284, !286, !289, !292, !293, !295, !299, !300}
!251 = !DIDerivedType(tag: DW_TAG_member, name: "_flags", scope: !248, file: !249, line: 51, baseType: !12, size: 32)
!252 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_read_ptr", scope: !248, file: !249, line: 54, baseType: !253, size: 64, offset: 64)
!253 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !254, size: 64)
!254 = !DIBasicType(name: "char", size: 8, encoding: DW_ATE_signed_char)
!255 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_read_end", scope: !248, file: !249, line: 55, baseType: !253, size: 64, offset: 128)
!256 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_read_base", scope: !248, file: !249, line: 56, baseType: !253, size: 64, offset: 192)
!257 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_write_base", scope: !248, file: !249, line: 57, baseType: !253, size: 64, offset: 256)
!258 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_write_ptr", scope: !248, file: !249, line: 58, baseType: !253, size: 64, offset: 320)
!259 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_write_end", scope: !248, file: !249, line: 59, baseType: !253, size: 64, offset: 384)
!260 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_buf_base", scope: !248, file: !249, line: 60, baseType: !253, size: 64, offset: 448)
!261 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_buf_end", scope: !248, file: !249, line: 61, baseType: !253, size: 64, offset: 512)
!262 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_save_base", scope: !248, file: !249, line: 64, baseType: !253, size: 64, offset: 576)
!263 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_backup_base", scope: !248, file: !249, line: 65, baseType: !253, size: 64, offset: 640)
!264 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_save_end", scope: !248, file: !249, line: 66, baseType: !253, size: 64, offset: 704)
!265 = !DIDerivedType(tag: DW_TAG_member, name: "_markers", scope: !248, file: !249, line: 68, baseType: !266, size: 64, offset: 768)
!266 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !267, size: 64)
!267 = !DICompositeType(tag: DW_TAG_structure_type, name: "_IO_marker", file: !249, line: 36, flags: DIFlagFwdDecl)
!268 = !DIDerivedType(tag: DW_TAG_member, name: "_chain", scope: !248, file: !249, line: 70, baseType: !269, size: 64, offset: 832)
!269 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !248, size: 64)
!270 = !DIDerivedType(tag: DW_TAG_member, name: "_fileno", scope: !248, file: !249, line: 72, baseType: !12, size: 32, offset: 896)
!271 = !DIDerivedType(tag: DW_TAG_member, name: "_flags2", scope: !248, file: !249, line: 73, baseType: !12, size: 32, offset: 928)
!272 = !DIDerivedType(tag: DW_TAG_member, name: "_old_offset", scope: !248, file: !249, line: 74, baseType: !273, size: 64, offset: 960)
!273 = !DIDerivedType(tag: DW_TAG_typedef, name: "__off_t", file: !23, line: 152, baseType: !274)
!274 = !DIBasicType(name: "long", size: 64, encoding: DW_ATE_signed)
!275 = !DIDerivedType(tag: DW_TAG_member, name: "_cur_column", scope: !248, file: !249, line: 77, baseType: !276, size: 16, offset: 1024)
!276 = !DIBasicType(name: "unsigned short", size: 16, encoding: DW_ATE_unsigned)
!277 = !DIDerivedType(tag: DW_TAG_member, name: "_vtable_offset", scope: !248, file: !249, line: 78, baseType: !278, size: 8, offset: 1040)
!278 = !DIBasicType(name: "signed char", size: 8, encoding: DW_ATE_signed_char)
!279 = !DIDerivedType(tag: DW_TAG_member, name: "_shortbuf", scope: !248, file: !249, line: 79, baseType: !280, size: 8, offset: 1048)
!280 = !DICompositeType(tag: DW_TAG_array_type, baseType: !254, size: 8, elements: !24)
!281 = !DIDerivedType(tag: DW_TAG_member, name: "_lock", scope: !248, file: !249, line: 81, baseType: !282, size: 64, offset: 1088)
!282 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !283, size: 64)
!283 = !DIDerivedType(tag: DW_TAG_typedef, name: "_IO_lock_t", file: !249, line: 43, baseType: null)
!284 = !DIDerivedType(tag: DW_TAG_member, name: "_offset", scope: !248, file: !249, line: 89, baseType: !285, size: 64, offset: 1152)
!285 = !DIDerivedType(tag: DW_TAG_typedef, name: "__off64_t", file: !23, line: 153, baseType: !274)
!286 = !DIDerivedType(tag: DW_TAG_member, name: "_codecvt", scope: !248, file: !249, line: 91, baseType: !287, size: 64, offset: 1216)
!287 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !288, size: 64)
!288 = !DICompositeType(tag: DW_TAG_structure_type, name: "_IO_codecvt", file: !249, line: 37, flags: DIFlagFwdDecl)
!289 = !DIDerivedType(tag: DW_TAG_member, name: "_wide_data", scope: !248, file: !249, line: 92, baseType: !290, size: 64, offset: 1280)
!290 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !291, size: 64)
!291 = !DICompositeType(tag: DW_TAG_structure_type, name: "_IO_wide_data", file: !249, line: 38, flags: DIFlagFwdDecl)
!292 = !DIDerivedType(tag: DW_TAG_member, name: "_freeres_list", scope: !248, file: !249, line: 93, baseType: !269, size: 64, offset: 1344)
!293 = !DIDerivedType(tag: DW_TAG_member, name: "_freeres_buf", scope: !248, file: !249, line: 94, baseType: !294, size: 64, offset: 1408)
!294 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: null, size: 64)
!295 = !DIDerivedType(tag: DW_TAG_member, name: "__pad5", scope: !248, file: !249, line: 95, baseType: !296, size: 64, offset: 1472)
!296 = !DIDerivedType(tag: DW_TAG_typedef, name: "size_t", file: !297, line: 46, baseType: !298)
!297 = !DIFile(filename: "/usr/lib/llvm-14/lib/clang/14.0.0/include/stddef.h", directory: "", checksumkind: CSK_MD5, checksum: "2499dd2361b915724b073282bea3a7bc")
!298 = !DIBasicType(name: "unsigned long", size: 64, encoding: DW_ATE_unsigned)
!299 = !DIDerivedType(tag: DW_TAG_member, name: "_mode", scope: !248, file: !249, line: 96, baseType: !12, size: 32, offset: 1536)
!300 = !DIDerivedType(tag: DW_TAG_member, name: "_unused2", scope: !248, file: !249, line: 98, baseType: !301, size: 160, offset: 1568)
!301 = !DICompositeType(tag: DW_TAG_array_type, baseType: !254, size: 160, elements: !302)
!302 = !{!303}
!303 = !DISubrange(count: 20)
!304 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !305, size: 64)
!305 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !254)
!306 = !DILocalVariable(name: "stream", arg: 1, scope: !242, file: !32, line: 13, type: !245)
!307 = !DILocation(line: 13, column: 29, scope: !242)
!308 = !DILocalVariable(name: "format", arg: 2, scope: !242, file: !32, line: 13, type: !304)
!309 = !DILocation(line: 13, column: 49, scope: !242)
!310 = !DILocalVariable(name: "buffer", scope: !242, file: !32, line: 15, type: !311)
!311 = !DICompositeType(tag: DW_TAG_array_type, baseType: !254, size: 6144, elements: !312)
!312 = !{!313}
!313 = !DISubrange(count: 768)
!314 = !DILocation(line: 15, column: 10, scope: !242)
!315 = !DILocalVariable(name: "args", scope: !242, file: !32, line: 16, type: !316)
!316 = !DIDerivedType(tag: DW_TAG_typedef, name: "va_list", file: !317, line: 52, baseType: !318)
!317 = !DIFile(filename: "/usr/include/stdio.h", directory: "", checksumkind: CSK_MD5, checksum: "f31eefcc3f15835fc5a4023a625cf609")
!318 = !DIDerivedType(tag: DW_TAG_typedef, name: "__gnuc_va_list", file: !319, line: 32, baseType: !320)
!319 = !DIFile(filename: "/usr/lib/llvm-14/lib/clang/14.0.0/include/stdarg.h", directory: "", checksumkind: CSK_MD5, checksum: "4de3cbd931b589d291e5c39387aecf82")
!320 = !DIDerivedType(tag: DW_TAG_typedef, name: "__builtin_va_list", file: !321, baseType: !322)
!321 = !DIFile(filename: "source/workload.c", directory: "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/triangular-20260929/suite/jacobi-1d")
!322 = !DICompositeType(tag: DW_TAG_array_type, baseType: !323, size: 192, elements: !24)
!323 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "__va_list_tag", size: 192, elements: !324)
!324 = !{!325, !326, !327, !328}
!325 = !DIDerivedType(tag: DW_TAG_member, name: "gp_offset", scope: !323, file: !321, line: 16, baseType: !6, size: 32)
!326 = !DIDerivedType(tag: DW_TAG_member, name: "fp_offset", scope: !323, file: !321, line: 16, baseType: !6, size: 32, offset: 32)
!327 = !DIDerivedType(tag: DW_TAG_member, name: "overflow_arg_area", scope: !323, file: !321, line: 16, baseType: !294, size: 64, offset: 64)
!328 = !DIDerivedType(tag: DW_TAG_member, name: "reg_save_area", scope: !323, file: !321, line: 16, baseType: !294, size: 64, offset: 128)
!329 = !DILocation(line: 16, column: 13, scope: !242)
!330 = !DILocation(line: 17, column: 5, scope: !242)
!331 = !DILocalVariable(name: "count", scope: !242, file: !32, line: 18, type: !12)
!332 = !DILocation(line: 18, column: 9, scope: !242)
!333 = !DILocation(line: 18, column: 27, scope: !242)
!334 = !DILocation(line: 18, column: 51, scope: !242)
!335 = !DILocation(line: 18, column: 59, scope: !242)
!336 = !DILocation(line: 18, column: 17, scope: !242)
!337 = !DILocation(line: 19, column: 5, scope: !242)
!338 = !DILocation(line: 20, column: 9, scope: !339)
!339 = distinct !DILexicalBlock(scope: !242, file: !32, line: 20, column: 9)
!340 = !DILocation(line: 20, column: 15, scope: !339)
!341 = !DILocation(line: 20, column: 19, scope: !339)
!342 = !DILocation(line: 20, column: 32, scope: !339)
!343 = !DILocation(line: 20, column: 22, scope: !339)
!344 = !DILocation(line: 20, column: 38, scope: !339)
!345 = !DILocation(line: 20, column: 9, scope: !242)
!346 = !DILocation(line: 20, column: 57, scope: !339)
!347 = !DILocalVariable(name: "i", scope: !348, file: !32, line: 21, type: !12)
!348 = distinct !DILexicalBlock(scope: !242, file: !32, line: 21, column: 5)
!349 = !DILocation(line: 21, column: 14, scope: !348)
!350 = !DILocation(line: 21, column: 10, scope: !348)
!351 = !DILocation(line: 21, column: 21, scope: !352)
!352 = distinct !DILexicalBlock(scope: !348, file: !32, line: 21, column: 5)
!353 = !DILocation(line: 21, column: 25, scope: !352)
!354 = !DILocation(line: 21, column: 23, scope: !352)
!355 = !DILocation(line: 21, column: 5, scope: !348)
!356 = !DILocation(line: 22, column: 42, scope: !357)
!357 = distinct !DILexicalBlock(scope: !352, file: !32, line: 21, column: 37)
!358 = !DILocation(line: 22, column: 35, scope: !357)
!359 = !DILocation(line: 22, column: 20, scope: !357)
!360 = !DILocation(line: 22, column: 17, scope: !357)
!361 = !DILocation(line: 23, column: 17, scope: !357)
!362 = !DILocation(line: 24, column: 5, scope: !357)
!363 = !DILocation(line: 21, column: 32, scope: !352)
!364 = !DILocation(line: 21, column: 5, scope: !352)
!365 = distinct !{!365, !355, !366, !108}
!366 = !DILocation(line: 24, column: 5, scope: !348)
!367 = !DILocation(line: 28, column: 11, scope: !242)
!368 = !DILocation(line: 29, column: 11, scope: !242)
!369 = !DILocation(line: 31, column: 12, scope: !242)
!370 = !DILocation(line: 31, column: 5, scope: !242)
