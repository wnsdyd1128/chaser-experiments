; ModuleID = 'inlined.ll'
source_filename = "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/triangular-20260929/suite/jacobi-1d/source/workload.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

@n = external dso_local global i32, align 4, !dbg !0
@tsteps = external dso_local global i32, align 4, !dbg !9
@A = external dso_local global [400 x double], section ".chaser_data.A", align 64, !dbg !13
@B = external dso_local global [400 x double], section ".chaser_data.B", align 64, !dbg !18
@.str = hidden unnamed_addr constant [12 x i8] c"ape.analyze\00", section "llvm.metadata"
@.str.1 = hidden unnamed_addr constant [124 x i8] c"/workspace/experiments-array-support/chaser/.cache/periodic-polybench/triangular-20260929/suite/jacobi-1d/source/workload.c\00", section "llvm.metadata"
@.str.2 = hidden unnamed_addr constant [23 x i8] c"==BEGIN DUMP_ARRAYS==\0A\00", align 1
@.str.3 = hidden unnamed_addr constant [15 x i8] c"begin dump: %s\00", align 1
@.str.4 = hidden unnamed_addr constant [2 x i8] c"A\00", align 1
@.str.5 = hidden unnamed_addr constant [2 x i8] c"\0A\00", align 1
@.str.6 = hidden unnamed_addr constant [8 x i8] c"%0.2lf \00", align 1
@.str.7 = hidden unnamed_addr constant [17 x i8] c"\0Aend   dump: %s\0A\00", align 1
@.str.8 = hidden unnamed_addr constant [23 x i8] c"==END   DUMP_ARRAYS==\0A\00", align 1
@llvm.global.annotations = appending global [1 x { i8*, i8*, i8*, i32, i8* }] [{ i8*, i8*, i8*, i32, i8* } { i8* bitcast (i32 ()* @task_job_polybench to i8*), i8* getelementptr inbounds ([12 x i8], [12 x i8]* @.str, i32 0, i32 0), i8* getelementptr inbounds ([124 x i8], [124 x i8]* @.str.1, i32 0, i32 0), i32 105, i8* null }], section "llvm.metadata"

; Function Attrs: noinline nounwind uwtable
define dso_local i32 @task_job_polybench() #0 !dbg !28 {
  %1 = load i32, i32* @tsteps, align 4, !dbg !36
  %2 = load i32, i32* @n, align 4, !dbg !37
  call void @llvm.dbg.value(metadata i32 %1, metadata !38, metadata !DIExpression()), !dbg !43
  call void @llvm.dbg.value(metadata i32 %2, metadata !45, metadata !DIExpression()), !dbg !43
  call void @llvm.dbg.value(metadata double* getelementptr inbounds ([400 x double], [400 x double]* @A, i64 0, i64 0), metadata !46, metadata !DIExpression()), !dbg !43
  call void @llvm.dbg.value(metadata double* getelementptr inbounds ([400 x double], [400 x double]* @B, i64 0, i64 0), metadata !47, metadata !DIExpression()), !dbg !43
  call void @llvm.dbg.value(metadata i32 0, metadata !48, metadata !DIExpression()), !dbg !43
  br label %3, !dbg !49

3:                                                ; preds = %47, %0
  %.01 = phi i32 [ 0, %0 ], [ %48, %47 ], !dbg !51
  call void @llvm.dbg.value(metadata i32 %.01, metadata !48, metadata !DIExpression()), !dbg !43
  %4 = icmp slt i32 %.01, 100, !dbg !52
  br i1 %4, label %5, label %49, !dbg !54

5:                                                ; preds = %3
  call void @llvm.dbg.value(metadata i32 1, metadata !55, metadata !DIExpression()), !dbg !43
  br label %6, !dbg !56

6:                                                ; preds = %8, %5
  %.0 = phi i32 [ 1, %5 ], [ %25, %8 ], !dbg !59
  call void @llvm.dbg.value(metadata i32 %.0, metadata !55, metadata !DIExpression()), !dbg !43
  %7 = icmp slt i32 %.0, 399, !dbg !60
  br i1 %7, label %8, label %26, !dbg !62

8:                                                ; preds = %6
  %9 = sub nsw i32 %.0, 1, !dbg !63
  %10 = sext i32 %9 to i64, !dbg !64
  %11 = getelementptr inbounds double, double* getelementptr inbounds ([400 x double], [400 x double]* @A, i64 0, i64 0), i64 %10, !dbg !64
  %12 = load double, double* %11, align 8, !dbg !64
  %13 = sext i32 %.0 to i64, !dbg !65
  %14 = getelementptr inbounds double, double* getelementptr inbounds ([400 x double], [400 x double]* @A, i64 0, i64 0), i64 %13, !dbg !65
  %15 = load double, double* %14, align 8, !dbg !65
  %16 = fadd double %12, %15, !dbg !66
  %17 = add nsw i32 %.0, 1, !dbg !67
  %18 = sext i32 %17 to i64, !dbg !68
  %19 = getelementptr inbounds double, double* getelementptr inbounds ([400 x double], [400 x double]* @A, i64 0, i64 0), i64 %18, !dbg !68
  %20 = load double, double* %19, align 8, !dbg !68
  %21 = fadd double %16, %20, !dbg !69
  %22 = fmul double 3.333300e-01, %21, !dbg !70
  %23 = sext i32 %.0 to i64, !dbg !71
  %24 = getelementptr inbounds double, double* getelementptr inbounds ([400 x double], [400 x double]* @B, i64 0, i64 0), i64 %23, !dbg !71
  store double %22, double* %24, align 8, !dbg !72
  %25 = add nsw i32 %.0, 1, !dbg !73
  call void @llvm.dbg.value(metadata i32 %25, metadata !55, metadata !DIExpression()), !dbg !43
  br label %6, !dbg !74, !llvm.loop !75

26:                                               ; preds = %6
  call void @llvm.dbg.value(metadata i32 1, metadata !55, metadata !DIExpression()), !dbg !43
  br label %27, !dbg !78

27:                                               ; preds = %29, %26
  %.1 = phi i32 [ 1, %26 ], [ %46, %29 ], !dbg !80
  call void @llvm.dbg.value(metadata i32 %.1, metadata !55, metadata !DIExpression()), !dbg !43
  %28 = icmp slt i32 %.1, 399, !dbg !81
  br i1 %28, label %29, label %47, !dbg !83

29:                                               ; preds = %27
  %30 = sub nsw i32 %.1, 1, !dbg !84
  %31 = sext i32 %30 to i64, !dbg !85
  %32 = getelementptr inbounds double, double* getelementptr inbounds ([400 x double], [400 x double]* @B, i64 0, i64 0), i64 %31, !dbg !85
  %33 = load double, double* %32, align 8, !dbg !85
  %34 = sext i32 %.1 to i64, !dbg !86
  %35 = getelementptr inbounds double, double* getelementptr inbounds ([400 x double], [400 x double]* @B, i64 0, i64 0), i64 %34, !dbg !86
  %36 = load double, double* %35, align 8, !dbg !86
  %37 = fadd double %33, %36, !dbg !87
  %38 = add nsw i32 %.1, 1, !dbg !88
  %39 = sext i32 %38 to i64, !dbg !89
  %40 = getelementptr inbounds double, double* getelementptr inbounds ([400 x double], [400 x double]* @B, i64 0, i64 0), i64 %39, !dbg !89
  %41 = load double, double* %40, align 8, !dbg !89
  %42 = fadd double %37, %41, !dbg !90
  %43 = fmul double 3.333300e-01, %42, !dbg !91
  %44 = sext i32 %.1 to i64, !dbg !92
  %45 = getelementptr inbounds double, double* getelementptr inbounds ([400 x double], [400 x double]* @A, i64 0, i64 0), i64 %44, !dbg !92
  store double %43, double* %45, align 8, !dbg !93
  %46 = add nsw i32 %.1, 1, !dbg !94
  call void @llvm.dbg.value(metadata i32 %46, metadata !55, metadata !DIExpression()), !dbg !43
  br label %27, !dbg !95, !llvm.loop !96

47:                                               ; preds = %27
  %48 = add nsw i32 %.01, 1, !dbg !98
  call void @llvm.dbg.value(metadata i32 %48, metadata !48, metadata !DIExpression()), !dbg !43
  br label %3, !dbg !99, !llvm.loop !100

49:                                               ; preds = %3
  ret i32 0, !dbg !102
}

; Function Attrs: nofree nosync nounwind readnone speculatable willreturn
declare void @llvm.dbg.value(metadata, metadata, metadata) #1

attributes #0 = { noinline nounwind uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { nofree nosync nounwind readnone speculatable willreturn }

!llvm.dbg.cu = !{!2}
!llvm.module.flags = !{!20, !21, !22, !23, !24, !25, !26}
!llvm.ident = !{!27}

!0 = !DIGlobalVariableExpression(var: !1, expr: !DIExpression())
!1 = distinct !DIGlobalVariable(name: "n", scope: !2, file: !11, line: 96, type: !12, isLocal: false, isDefinition: true)
!2 = distinct !DICompileUnit(language: DW_LANG_C99, file: !3, producer: "Ubuntu clang version 14.0.0-1ubuntu1.1", isOptimized: false, runtimeVersion: 0, emissionKind: FullDebug, retainedTypes: !4, globals: !8, splitDebugInlining: false, nameTableKind: None)
!3 = !DIFile(filename: "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/triangular-20260929/suite/jacobi-1d/source/workload.c", directory: "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/triangular-20260929/suite/jacobi-1d/analysis-native", checksumkind: CSK_MD5, checksum: "32f13b44e0cda1ff9f9c858c735c495e")
!4 = !{!5, !6, !7}
!5 = !DIBasicType(name: "double", size: 64, encoding: DW_ATE_float)
!6 = !DIBasicType(name: "unsigned int", size: 32, encoding: DW_ATE_unsigned)
!7 = !DIBasicType(name: "unsigned char", size: 8, encoding: DW_ATE_unsigned_char)
!8 = !{!0, !9, !13, !18}
!9 = !DIGlobalVariableExpression(var: !10, expr: !DIExpression())
!10 = distinct !DIGlobalVariable(name: "tsteps", scope: !2, file: !11, line: 97, type: !12, isLocal: false, isDefinition: true)
!11 = !DIFile(filename: "source/workload.c", directory: "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/triangular-20260929/suite/jacobi-1d", checksumkind: CSK_MD5, checksum: "32f13b44e0cda1ff9f9c858c735c495e")
!12 = !DIBasicType(name: "int", size: 32, encoding: DW_ATE_signed)
!13 = !DIGlobalVariableExpression(var: !14, expr: !DIExpression())
!14 = distinct !DIGlobalVariable(name: "A", scope: !2, file: !11, line: 34, type: !15, isLocal: false, isDefinition: true, align: 512)
!15 = !DICompositeType(tag: DW_TAG_array_type, baseType: !5, size: 25600, elements: !16)
!16 = !{!17}
!17 = !DISubrange(count: 400)
!18 = !DIGlobalVariableExpression(var: !19, expr: !DIExpression())
!19 = distinct !DIGlobalVariable(name: "B", scope: !2, file: !11, line: 35, type: !15, isLocal: false, isDefinition: true, align: 512)
!20 = !{i32 7, !"Dwarf Version", i32 5}
!21 = !{i32 2, !"Debug Info Version", i32 3}
!22 = !{i32 1, !"wchar_size", i32 4}
!23 = !{i32 7, !"PIC Level", i32 2}
!24 = !{i32 7, !"PIE Level", i32 2}
!25 = !{i32 7, !"uwtable", i32 1}
!26 = !{i32 7, !"frame-pointer", i32 2}
!27 = !{!"Ubuntu clang version 14.0.0-1ubuntu1.1"}
!28 = distinct !DISubprogram(name: "task_job_polybench", scope: !11, file: !11, line: 105, type: !29, scopeLine: 105, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !2, retainedNodes: !35)
!29 = !DISubroutineType(types: !30)
!30 = !{!31}
!31 = !DIDerivedType(tag: DW_TAG_typedef, name: "uint32_t", file: !32, line: 26, baseType: !33)
!32 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/stdint-uintn.h", directory: "", checksumkind: CSK_MD5, checksum: "2bf2ae53c58c01b1a1b9383b5195125c")
!33 = !DIDerivedType(tag: DW_TAG_typedef, name: "__uint32_t", file: !34, line: 42, baseType: !6)
!34 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/types.h", directory: "", checksumkind: CSK_MD5, checksum: "d108b5f93a74c50510d7d9bc0ab36df9")
!35 = !{}
!36 = !DILocation(line: 106, column: 20, scope: !28)
!37 = !DILocation(line: 106, column: 28, scope: !28)
!38 = !DILocalVariable(name: "tsteps", arg: 1, scope: !39, file: !11, line: 75, type: !12)
!39 = distinct !DISubprogram(name: "kernel_jacobi_1d", scope: !11, file: !11, line: 75, type: !40, scopeLine: 79, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition, unit: !2, retainedNodes: !35)
!40 = !DISubroutineType(types: !41)
!41 = !{null, !12, !12, !42, !42}
!42 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !5, size: 64)
!43 = !DILocation(line: 0, scope: !39, inlinedAt: !44)
!44 = distinct !DILocation(line: 106, column: 3, scope: !28)
!45 = !DILocalVariable(name: "n", arg: 2, scope: !39, file: !11, line: 76, type: !12)
!46 = !DILocalVariable(name: "A", arg: 3, scope: !39, file: !11, line: 77, type: !42)
!47 = !DILocalVariable(name: "B", arg: 4, scope: !39, file: !11, line: 78, type: !42)
!48 = !DILocalVariable(name: "t", scope: !39, file: !11, line: 80, type: !12)
!49 = !DILocation(line: 83, column: 8, scope: !50, inlinedAt: !44)
!50 = distinct !DILexicalBlock(scope: !39, file: !11, line: 83, column: 3)
!51 = !DILocation(line: 0, scope: !50, inlinedAt: !44)
!52 = !DILocation(line: 83, column: 17, scope: !53, inlinedAt: !44)
!53 = distinct !DILexicalBlock(scope: !50, file: !11, line: 83, column: 3)
!54 = !DILocation(line: 83, column: 3, scope: !50, inlinedAt: !44)
!55 = !DILocalVariable(name: "i", scope: !39, file: !11, line: 80, type: !12)
!56 = !DILocation(line: 85, column: 12, scope: !57, inlinedAt: !44)
!57 = distinct !DILexicalBlock(scope: !58, file: !11, line: 85, column: 7)
!58 = distinct !DILexicalBlock(scope: !53, file: !11, line: 84, column: 5)
!59 = !DILocation(line: 0, scope: !57, inlinedAt: !44)
!60 = !DILocation(line: 85, column: 21, scope: !61, inlinedAt: !44)
!61 = distinct !DILexicalBlock(scope: !57, file: !11, line: 85, column: 7)
!62 = !DILocation(line: 85, column: 7, scope: !57, inlinedAt: !44)
!63 = !DILocation(line: 86, column: 23, scope: !61, inlinedAt: !44)
!64 = !DILocation(line: 86, column: 20, scope: !61, inlinedAt: !44)
!65 = !DILocation(line: 86, column: 29, scope: !61, inlinedAt: !44)
!66 = !DILocation(line: 86, column: 27, scope: !61, inlinedAt: !44)
!67 = !DILocation(line: 86, column: 40, scope: !61, inlinedAt: !44)
!68 = !DILocation(line: 86, column: 36, scope: !61, inlinedAt: !44)
!69 = !DILocation(line: 86, column: 34, scope: !61, inlinedAt: !44)
!70 = !DILocation(line: 86, column: 17, scope: !61, inlinedAt: !44)
!71 = !DILocation(line: 86, column: 2, scope: !61, inlinedAt: !44)
!72 = !DILocation(line: 86, column: 7, scope: !61, inlinedAt: !44)
!73 = !DILocation(line: 85, column: 35, scope: !61, inlinedAt: !44)
!74 = !DILocation(line: 85, column: 7, scope: !61, inlinedAt: !44)
!75 = distinct !{!75, !62, !76, !77}
!76 = !DILocation(line: 86, column: 44, scope: !57, inlinedAt: !44)
!77 = !{!"llvm.loop.mustprogress"}
!78 = !DILocation(line: 87, column: 12, scope: !79, inlinedAt: !44)
!79 = distinct !DILexicalBlock(scope: !58, file: !11, line: 87, column: 7)
!80 = !DILocation(line: 0, scope: !79, inlinedAt: !44)
!81 = !DILocation(line: 87, column: 21, scope: !82, inlinedAt: !44)
!82 = distinct !DILexicalBlock(scope: !79, file: !11, line: 87, column: 7)
!83 = !DILocation(line: 87, column: 7, scope: !79, inlinedAt: !44)
!84 = !DILocation(line: 88, column: 23, scope: !82, inlinedAt: !44)
!85 = !DILocation(line: 88, column: 20, scope: !82, inlinedAt: !44)
!86 = !DILocation(line: 88, column: 29, scope: !82, inlinedAt: !44)
!87 = !DILocation(line: 88, column: 27, scope: !82, inlinedAt: !44)
!88 = !DILocation(line: 88, column: 40, scope: !82, inlinedAt: !44)
!89 = !DILocation(line: 88, column: 36, scope: !82, inlinedAt: !44)
!90 = !DILocation(line: 88, column: 34, scope: !82, inlinedAt: !44)
!91 = !DILocation(line: 88, column: 17, scope: !82, inlinedAt: !44)
!92 = !DILocation(line: 88, column: 2, scope: !82, inlinedAt: !44)
!93 = !DILocation(line: 88, column: 7, scope: !82, inlinedAt: !44)
!94 = !DILocation(line: 87, column: 35, scope: !82, inlinedAt: !44)
!95 = !DILocation(line: 87, column: 7, scope: !82, inlinedAt: !44)
!96 = distinct !{!96, !83, !97, !77}
!97 = !DILocation(line: 88, column: 44, scope: !79, inlinedAt: !44)
!98 = !DILocation(line: 83, column: 32, scope: !53, inlinedAt: !44)
!99 = !DILocation(line: 83, column: 3, scope: !53, inlinedAt: !44)
!100 = distinct !{!100, !54, !101, !77}
!101 = !DILocation(line: 89, column: 5, scope: !50, inlinedAt: !44)
!102 = !DILocation(line: 107, column: 3, scope: !28)
