; ModuleID = 'inlined.ll'
source_filename = "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/triangular-20260929/suite/cholesky/source/workload.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

@n = external dso_local global i32, align 4, !dbg !0
@A = external dso_local global [400 x [400 x double]], section ".chaser_data.A", align 64, !dbg !9
@.str = hidden unnamed_addr constant [12 x i8] c"ape.analyze\00", section "llvm.metadata"
@.str.1 = hidden unnamed_addr constant [123 x i8] c"/workspace/experiments-array-support/chaser/.cache/periodic-polybench/triangular-20260929/suite/cholesky/source/workload.c\00", section "llvm.metadata"
@.str.2 = hidden unnamed_addr constant [23 x i8] c"==BEGIN DUMP_ARRAYS==\0A\00", align 1
@.str.3 = hidden unnamed_addr constant [15 x i8] c"begin dump: %s\00", align 1
@.str.4 = hidden unnamed_addr constant [2 x i8] c"A\00", align 1
@.str.5 = hidden unnamed_addr constant [2 x i8] c"\0A\00", align 1
@.str.6 = hidden unnamed_addr constant [8 x i8] c"%0.2lf \00", align 1
@.str.7 = hidden unnamed_addr constant [17 x i8] c"\0Aend   dump: %s\0A\00", align 1
@.str.8 = hidden unnamed_addr constant [23 x i8] c"==END   DUMP_ARRAYS==\0A\00", align 1
@llvm.global.annotations = appending global [1 x { i8*, i8*, i8*, i32, i8* }] [{ i8*, i8*, i8*, i32, i8* } { i8* bitcast (i32 ()* @task_job_polybench to i8*), i8* getelementptr inbounds ([12 x i8], [12 x i8]* @.str, i32 0, i32 0), i8* getelementptr inbounds ([123 x i8], [123 x i8]* @.str.1, i32 0, i32 0), i32 129, i8* null }], section "llvm.metadata"

; Function Attrs: noinline nounwind uwtable
define dso_local i32 @task_job_polybench() #0 !dbg !24 {
  %1 = load i32, i32* @n, align 4, !dbg !32
  call void @llvm.dbg.value(metadata i32 %1, metadata !33, metadata !DIExpression()), !dbg !40
  call void @llvm.dbg.value(metadata [400 x double]* getelementptr inbounds ([400 x [400 x double]], [400 x [400 x double]]* @A, i64 0, i64 0), metadata !42, metadata !DIExpression()), !dbg !40
  call void @llvm.dbg.value(metadata i32 0, metadata !43, metadata !DIExpression()), !dbg !40
  br label %2, !dbg !44

2:                                                ; preds = %64, %0
  %.02 = phi i32 [ 0, %0 ], [ %75, %64 ], !dbg !46
  call void @llvm.dbg.value(metadata i32 %.02, metadata !43, metadata !DIExpression()), !dbg !40
  %3 = icmp slt i32 %.02, 400, !dbg !47
  br i1 %3, label %4, label %76, !dbg !49

4:                                                ; preds = %2
  call void @llvm.dbg.value(metadata i32 0, metadata !50, metadata !DIExpression()), !dbg !40
  br label %5, !dbg !51

5:                                                ; preds = %29, %4
  %.01 = phi i32 [ 0, %4 ], [ %41, %29 ], !dbg !54
  call void @llvm.dbg.value(metadata i32 %.01, metadata !50, metadata !DIExpression()), !dbg !40
  %6 = icmp slt i32 %.01, %.02, !dbg !55
  br i1 %6, label %7, label %42, !dbg !57

7:                                                ; preds = %5
  call void @llvm.dbg.value(metadata i32 0, metadata !58, metadata !DIExpression()), !dbg !40
  br label %8, !dbg !59

8:                                                ; preds = %10, %7
  %.0 = phi i32 [ 0, %7 ], [ %28, %10 ], !dbg !62
  call void @llvm.dbg.value(metadata i32 %.0, metadata !58, metadata !DIExpression()), !dbg !40
  %9 = icmp slt i32 %.0, %.01, !dbg !63
  br i1 %9, label %10, label %29, !dbg !65

10:                                               ; preds = %8
  %11 = sext i32 %.02 to i64, !dbg !66
  %12 = getelementptr inbounds [400 x double], [400 x double]* getelementptr inbounds ([400 x [400 x double]], [400 x [400 x double]]* @A, i64 0, i64 0), i64 %11, !dbg !66
  %13 = sext i32 %.0 to i64, !dbg !66
  %14 = getelementptr inbounds [400 x double], [400 x double]* %12, i64 0, i64 %13, !dbg !66
  %15 = load double, double* %14, align 8, !dbg !66
  %16 = sext i32 %.01 to i64, !dbg !68
  %17 = getelementptr inbounds [400 x double], [400 x double]* getelementptr inbounds ([400 x [400 x double]], [400 x [400 x double]]* @A, i64 0, i64 0), i64 %16, !dbg !68
  %18 = sext i32 %.0 to i64, !dbg !68
  %19 = getelementptr inbounds [400 x double], [400 x double]* %17, i64 0, i64 %18, !dbg !68
  %20 = load double, double* %19, align 8, !dbg !68
  %21 = fmul double %15, %20, !dbg !69
  %22 = sext i32 %.02 to i64, !dbg !70
  %23 = getelementptr inbounds [400 x double], [400 x double]* getelementptr inbounds ([400 x [400 x double]], [400 x [400 x double]]* @A, i64 0, i64 0), i64 %22, !dbg !70
  %24 = sext i32 %.01 to i64, !dbg !70
  %25 = getelementptr inbounds [400 x double], [400 x double]* %23, i64 0, i64 %24, !dbg !70
  %26 = load double, double* %25, align 8, !dbg !71
  %27 = fsub double %26, %21, !dbg !71
  store double %27, double* %25, align 8, !dbg !71
  %28 = add nsw i32 %.0, 1, !dbg !72
  call void @llvm.dbg.value(metadata i32 %28, metadata !58, metadata !DIExpression()), !dbg !40
  br label %8, !dbg !73, !llvm.loop !74

29:                                               ; preds = %8
  %30 = sext i32 %.01 to i64, !dbg !77
  %31 = getelementptr inbounds [400 x double], [400 x double]* getelementptr inbounds ([400 x [400 x double]], [400 x [400 x double]]* @A, i64 0, i64 0), i64 %30, !dbg !77
  %32 = sext i32 %.01 to i64, !dbg !77
  %33 = getelementptr inbounds [400 x double], [400 x double]* %31, i64 0, i64 %32, !dbg !77
  %34 = load double, double* %33, align 8, !dbg !77
  %35 = sext i32 %.02 to i64, !dbg !78
  %36 = getelementptr inbounds [400 x double], [400 x double]* getelementptr inbounds ([400 x [400 x double]], [400 x [400 x double]]* @A, i64 0, i64 0), i64 %35, !dbg !78
  %37 = sext i32 %.01 to i64, !dbg !78
  %38 = getelementptr inbounds [400 x double], [400 x double]* %36, i64 0, i64 %37, !dbg !78
  %39 = load double, double* %38, align 8, !dbg !79
  %40 = fdiv double %39, %34, !dbg !79
  store double %40, double* %38, align 8, !dbg !79
  %41 = add nsw i32 %.01, 1, !dbg !80
  call void @llvm.dbg.value(metadata i32 %41, metadata !50, metadata !DIExpression()), !dbg !40
  br label %5, !dbg !81, !llvm.loop !82

42:                                               ; preds = %5
  call void @llvm.dbg.value(metadata i32 0, metadata !58, metadata !DIExpression()), !dbg !40
  br label %43, !dbg !84

43:                                               ; preds = %45, %42
  %.1 = phi i32 [ 0, %42 ], [ %63, %45 ], !dbg !86
  call void @llvm.dbg.value(metadata i32 %.1, metadata !58, metadata !DIExpression()), !dbg !40
  %44 = icmp slt i32 %.1, %.02, !dbg !87
  br i1 %44, label %45, label %64, !dbg !89

45:                                               ; preds = %43
  %46 = sext i32 %.02 to i64, !dbg !90
  %47 = getelementptr inbounds [400 x double], [400 x double]* getelementptr inbounds ([400 x [400 x double]], [400 x [400 x double]]* @A, i64 0, i64 0), i64 %46, !dbg !90
  %48 = sext i32 %.1 to i64, !dbg !90
  %49 = getelementptr inbounds [400 x double], [400 x double]* %47, i64 0, i64 %48, !dbg !90
  %50 = load double, double* %49, align 8, !dbg !90
  %51 = sext i32 %.02 to i64, !dbg !92
  %52 = getelementptr inbounds [400 x double], [400 x double]* getelementptr inbounds ([400 x [400 x double]], [400 x [400 x double]]* @A, i64 0, i64 0), i64 %51, !dbg !92
  %53 = sext i32 %.1 to i64, !dbg !92
  %54 = getelementptr inbounds [400 x double], [400 x double]* %52, i64 0, i64 %53, !dbg !92
  %55 = load double, double* %54, align 8, !dbg !92
  %56 = fmul double %50, %55, !dbg !93
  %57 = sext i32 %.02 to i64, !dbg !94
  %58 = getelementptr inbounds [400 x double], [400 x double]* getelementptr inbounds ([400 x [400 x double]], [400 x [400 x double]]* @A, i64 0, i64 0), i64 %57, !dbg !94
  %59 = sext i32 %.02 to i64, !dbg !94
  %60 = getelementptr inbounds [400 x double], [400 x double]* %58, i64 0, i64 %59, !dbg !94
  %61 = load double, double* %60, align 8, !dbg !95
  %62 = fsub double %61, %56, !dbg !95
  store double %62, double* %60, align 8, !dbg !95
  %63 = add nsw i32 %.1, 1, !dbg !96
  call void @llvm.dbg.value(metadata i32 %63, metadata !58, metadata !DIExpression()), !dbg !40
  br label %43, !dbg !97, !llvm.loop !98

64:                                               ; preds = %43
  %65 = sext i32 %.02 to i64, !dbg !100
  %66 = getelementptr inbounds [400 x double], [400 x double]* getelementptr inbounds ([400 x [400 x double]], [400 x [400 x double]]* @A, i64 0, i64 0), i64 %65, !dbg !100
  %67 = sext i32 %.02 to i64, !dbg !100
  %68 = getelementptr inbounds [400 x double], [400 x double]* %66, i64 0, i64 %67, !dbg !100
  %69 = load double, double* %68, align 8, !dbg !100
  %70 = call double @sqrt(double noundef %69) #3, !dbg !100
  %71 = sext i32 %.02 to i64, !dbg !101
  %72 = getelementptr inbounds [400 x double], [400 x double]* getelementptr inbounds ([400 x [400 x double]], [400 x [400 x double]]* @A, i64 0, i64 0), i64 %71, !dbg !101
  %73 = sext i32 %.02 to i64, !dbg !101
  %74 = getelementptr inbounds [400 x double], [400 x double]* %72, i64 0, i64 %73, !dbg !101
  store double %70, double* %74, align 8, !dbg !102
  %75 = add nsw i32 %.02, 1, !dbg !103
  call void @llvm.dbg.value(metadata i32 %75, metadata !43, metadata !DIExpression()), !dbg !40
  br label %2, !dbg !104, !llvm.loop !105

76:                                               ; preds = %2
  ret i32 0, !dbg !107
}

; Function Attrs: nounwind
declare double @sqrt(double noundef) #1

; Function Attrs: nofree nosync nounwind readnone speculatable willreturn
declare void @llvm.dbg.value(metadata, metadata, metadata) #2

attributes #0 = { noinline nounwind uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { nounwind "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #2 = { nofree nosync nounwind readnone speculatable willreturn }
attributes #3 = { nounwind }

!llvm.dbg.cu = !{!2}
!llvm.module.flags = !{!16, !17, !18, !19, !20, !21, !22}
!llvm.ident = !{!23}

!0 = !DIGlobalVariableExpression(var: !1, expr: !DIExpression())
!1 = distinct !DIGlobalVariable(name: "n", scope: !2, file: !11, line: 121, type: !15, isLocal: false, isDefinition: true)
!2 = distinct !DICompileUnit(language: DW_LANG_C99, file: !3, producer: "Ubuntu clang version 14.0.0-1ubuntu1.1", isOptimized: false, runtimeVersion: 0, emissionKind: FullDebug, retainedTypes: !4, globals: !8, splitDebugInlining: false, nameTableKind: None)
!3 = !DIFile(filename: "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/triangular-20260929/suite/cholesky/source/workload.c", directory: "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/triangular-20260929/suite/cholesky/analysis-g", checksumkind: CSK_MD5, checksum: "d170b7a602b37f77698095470cf1b4b6")
!4 = !{!5, !6, !7}
!5 = !DIBasicType(name: "double", size: 64, encoding: DW_ATE_float)
!6 = !DIBasicType(name: "unsigned int", size: 32, encoding: DW_ATE_unsigned)
!7 = !DIBasicType(name: "unsigned char", size: 8, encoding: DW_ATE_unsigned_char)
!8 = !{!0, !9}
!9 = !DIGlobalVariableExpression(var: !10, expr: !DIExpression())
!10 = distinct !DIGlobalVariable(name: "A", scope: !2, file: !11, line: 35, type: !12, isLocal: false, isDefinition: true, align: 512)
!11 = !DIFile(filename: "source/workload.c", directory: "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/triangular-20260929/suite/cholesky", checksumkind: CSK_MD5, checksum: "d170b7a602b37f77698095470cf1b4b6")
!12 = !DICompositeType(tag: DW_TAG_array_type, baseType: !5, size: 10240000, elements: !13)
!13 = !{!14, !14}
!14 = !DISubrange(count: 400)
!15 = !DIBasicType(name: "int", size: 32, encoding: DW_ATE_signed)
!16 = !{i32 7, !"Dwarf Version", i32 5}
!17 = !{i32 2, !"Debug Info Version", i32 3}
!18 = !{i32 1, !"wchar_size", i32 4}
!19 = !{i32 7, !"PIC Level", i32 2}
!20 = !{i32 7, !"PIE Level", i32 2}
!21 = !{i32 7, !"uwtable", i32 1}
!22 = !{i32 7, !"frame-pointer", i32 2}
!23 = !{!"Ubuntu clang version 14.0.0-1ubuntu1.1"}
!24 = distinct !DISubprogram(name: "task_job_polybench", scope: !11, file: !11, line: 129, type: !25, scopeLine: 129, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !2, retainedNodes: !31)
!25 = !DISubroutineType(types: !26)
!26 = !{!27}
!27 = !DIDerivedType(tag: DW_TAG_typedef, name: "uint32_t", file: !28, line: 26, baseType: !29)
!28 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/stdint-uintn.h", directory: "", checksumkind: CSK_MD5, checksum: "2bf2ae53c58c01b1a1b9383b5195125c")
!29 = !DIDerivedType(tag: DW_TAG_typedef, name: "__uint32_t", file: !30, line: 42, baseType: !6)
!30 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/types.h", directory: "", checksumkind: CSK_MD5, checksum: "d108b5f93a74c50510d7d9bc0ab36df9")
!31 = !{}
!32 = !DILocation(line: 130, column: 20, scope: !24)
!33 = !DILocalVariable(name: "n", arg: 1, scope: !34, file: !11, line: 94, type: !15)
!34 = distinct !DISubprogram(name: "kernel_cholesky", scope: !11, file: !11, line: 94, type: !35, scopeLine: 96, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition, unit: !2, retainedNodes: !31)
!35 = !DISubroutineType(types: !36)
!36 = !{null, !15, !37}
!37 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !38, size: 64)
!38 = !DICompositeType(tag: DW_TAG_array_type, baseType: !5, size: 25600, elements: !39)
!39 = !{!14}
!40 = !DILocation(line: 0, scope: !34, inlinedAt: !41)
!41 = distinct !DILocation(line: 130, column: 3, scope: !24)
!42 = !DILocalVariable(name: "A", arg: 2, scope: !34, file: !11, line: 95, type: !37)
!43 = !DILocalVariable(name: "i", scope: !34, file: !11, line: 97, type: !15)
!44 = !DILocation(line: 101, column: 8, scope: !45, inlinedAt: !41)
!45 = distinct !DILexicalBlock(scope: !34, file: !11, line: 101, column: 3)
!46 = !DILocation(line: 0, scope: !45, inlinedAt: !41)
!47 = !DILocation(line: 101, column: 17, scope: !48, inlinedAt: !41)
!48 = distinct !DILexicalBlock(scope: !45, file: !11, line: 101, column: 3)
!49 = !DILocation(line: 101, column: 3, scope: !45, inlinedAt: !41)
!50 = !DILocalVariable(name: "j", scope: !34, file: !11, line: 97, type: !15)
!51 = !DILocation(line: 103, column: 11, scope: !52, inlinedAt: !41)
!52 = distinct !DILexicalBlock(scope: !53, file: !11, line: 103, column: 6)
!53 = distinct !DILexicalBlock(scope: !48, file: !11, line: 101, column: 31)
!54 = !DILocation(line: 0, scope: !52, inlinedAt: !41)
!55 = !DILocation(line: 103, column: 20, scope: !56, inlinedAt: !41)
!56 = distinct !DILexicalBlock(scope: !52, file: !11, line: 103, column: 6)
!57 = !DILocation(line: 103, column: 6, scope: !52, inlinedAt: !41)
!58 = !DILocalVariable(name: "k", scope: !34, file: !11, line: 97, type: !15)
!59 = !DILocation(line: 104, column: 14, scope: !60, inlinedAt: !41)
!60 = distinct !DILexicalBlock(scope: !61, file: !11, line: 104, column: 9)
!61 = distinct !DILexicalBlock(scope: !56, file: !11, line: 103, column: 30)
!62 = !DILocation(line: 0, scope: !60, inlinedAt: !41)
!63 = !DILocation(line: 104, column: 23, scope: !64, inlinedAt: !41)
!64 = distinct !DILexicalBlock(scope: !60, file: !11, line: 104, column: 9)
!65 = !DILocation(line: 104, column: 9, scope: !60, inlinedAt: !41)
!66 = !DILocation(line: 105, column: 23, scope: !67, inlinedAt: !41)
!67 = distinct !DILexicalBlock(scope: !64, file: !11, line: 104, column: 33)
!68 = !DILocation(line: 105, column: 33, scope: !67, inlinedAt: !41)
!69 = !DILocation(line: 105, column: 31, scope: !67, inlinedAt: !41)
!70 = !DILocation(line: 105, column: 12, scope: !67, inlinedAt: !41)
!71 = !DILocation(line: 105, column: 20, scope: !67, inlinedAt: !41)
!72 = !DILocation(line: 104, column: 29, scope: !64, inlinedAt: !41)
!73 = !DILocation(line: 104, column: 9, scope: !64, inlinedAt: !41)
!74 = distinct !{!74, !65, !75, !76}
!75 = !DILocation(line: 106, column: 9, scope: !60, inlinedAt: !41)
!76 = !{!"llvm.loop.mustprogress"}
!77 = !DILocation(line: 107, column: 20, scope: !61, inlinedAt: !41)
!78 = !DILocation(line: 107, column: 9, scope: !61, inlinedAt: !41)
!79 = !DILocation(line: 107, column: 17, scope: !61, inlinedAt: !41)
!80 = !DILocation(line: 103, column: 26, scope: !56, inlinedAt: !41)
!81 = !DILocation(line: 103, column: 6, scope: !56, inlinedAt: !41)
!82 = distinct !{!82, !57, !83, !76}
!83 = !DILocation(line: 108, column: 6, scope: !52, inlinedAt: !41)
!84 = !DILocation(line: 110, column: 11, scope: !85, inlinedAt: !41)
!85 = distinct !DILexicalBlock(scope: !53, file: !11, line: 110, column: 6)
!86 = !DILocation(line: 0, scope: !85, inlinedAt: !41)
!87 = !DILocation(line: 110, column: 20, scope: !88, inlinedAt: !41)
!88 = distinct !DILexicalBlock(scope: !85, file: !11, line: 110, column: 6)
!89 = !DILocation(line: 110, column: 6, scope: !85, inlinedAt: !41)
!90 = !DILocation(line: 111, column: 20, scope: !91, inlinedAt: !41)
!91 = distinct !DILexicalBlock(scope: !88, file: !11, line: 110, column: 30)
!92 = !DILocation(line: 111, column: 30, scope: !91, inlinedAt: !41)
!93 = !DILocation(line: 111, column: 28, scope: !91, inlinedAt: !41)
!94 = !DILocation(line: 111, column: 9, scope: !91, inlinedAt: !41)
!95 = !DILocation(line: 111, column: 17, scope: !91, inlinedAt: !41)
!96 = !DILocation(line: 110, column: 26, scope: !88, inlinedAt: !41)
!97 = !DILocation(line: 110, column: 6, scope: !88, inlinedAt: !41)
!98 = distinct !{!98, !89, !99, !76}
!99 = !DILocation(line: 112, column: 6, scope: !85, inlinedAt: !41)
!100 = !DILocation(line: 113, column: 16, scope: !53, inlinedAt: !41)
!101 = !DILocation(line: 113, column: 6, scope: !53, inlinedAt: !41)
!102 = !DILocation(line: 113, column: 14, scope: !53, inlinedAt: !41)
!103 = !DILocation(line: 101, column: 27, scope: !48, inlinedAt: !41)
!104 = !DILocation(line: 101, column: 3, scope: !48, inlinedAt: !41)
!105 = distinct !{!105, !49, !106, !76}
!106 = !DILocation(line: 114, column: 3, scope: !45, inlinedAt: !41)
!107 = !DILocation(line: 131, column: 3, scope: !24)
