#define CHASER_EXPECTED 2682064622u
/* Generated driver; original functions follow unchanged except storage. */
#define MEDIUM_DATASET
#define POLYBENCH_USE_SCALAR_LB
#define POLYBENCH_STACK_ARRAYS
#define POLYBENCH_DUMP_ARRAYS
#include "adapter.h"
/**
 * This version is stamped on May 10, 2016
 *
 * Contact:
 *   Louis-Noel Pouchet <pouchet.ohio-state.edu>
 *   Tomofumi Yuki <tomofumi.yuki.fr>
 *
 * Web address: http://polybench.sourceforge.net
 */
/* jacobi-2d.c: this file is part of PolyBench/C */

#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <math.h>

/* Include polybench common header. */
#include <polybench.h>

/* Include benchmark-specific header. */
#include "jacobi-2d.h"


/* Array initialization. */

#define y1 pb_y1
DATA_TYPE A[N][N] PB_STORAGE(A);
DATA_TYPE B[N][N] PB_STORAGE(B);
static
void init_array (int n,
		 DATA_TYPE POLYBENCH_2D(A,N,N,n,n),
		 DATA_TYPE POLYBENCH_2D(B,N,N,n,n))
{
  int i, j;

  for (i = 0; i < n; i++)
    for (j = 0; j < n; j++)
      {
	A[i][j] = ((DATA_TYPE) i*(j+2) + 2) / n;
	B[i][j] = ((DATA_TYPE) i*(j+3) + 3) / n;
      }
}


/* DCE code. Must scan the entire live-out data.
   Can be used also to check the correctness of the output. */
static
void print_array(int n,
		 DATA_TYPE POLYBENCH_2D(A,N,N,n,n))

{
  int i, j;

  POLYBENCH_DUMP_START;
  POLYBENCH_DUMP_BEGIN("A");
  for (i = 0; i < n; i++)
    for (j = 0; j < n; j++) {
      if ((i * n + j) % 20 == 0) fprintf(POLYBENCH_DUMP_TARGET, "\n");
      fprintf(POLYBENCH_DUMP_TARGET, DATA_PRINTF_MODIFIER, A[i][j]);
    }
  POLYBENCH_DUMP_END("A");
  POLYBENCH_DUMP_FINISH;
}


/* Main computational kernel. The whole function will be timed,
   including the call and return. */
static
__attribute__((always_inline)) inline void kernel_jacobi_2d(int tsteps,
			    int n,
			    DATA_TYPE POLYBENCH_2D(A,N,N,n,n),
			    DATA_TYPE POLYBENCH_2D(B,N,N,n,n))
{
  int t, i, j;

#pragma scop
  for (t = 0; t < _PB_TSTEPS; t++)
    {
      for (i = 1; i < _PB_N - 1; i++)
	for (j = 1; j < _PB_N - 1; j++)
	  B[i][j] = SCALAR_VAL(0.2) * (A[i][j] + A[i][j-1] + A[i][1+j] + A[1+i][j] + A[i-1][j]);
      for (i = 1; i < _PB_N - 1; i++)
	for (j = 1; j < _PB_N - 1; j++)
	  A[i][j] = SCALAR_VAL(0.2) * (B[i][j] + B[i][j-1] + B[i][1+j] + B[1+i][j] + B[i-1][j]);
    }
#pragma endscop

}



int n = N;
  int tsteps = TSTEPS;
void workload_prepare(void) {}
void workload_reset(unsigned task) {
  (void)task;
  memset(A, 0, sizeof(A));
  memset(B, 0, sizeof(B));
  init_array (n, POLYBENCH_ARRAY(A), POLYBENCH_ARRAY(B));
}
PB_ANALYZE uint32_t task_job_polybench(void) {
  kernel_jacobi_2d(tsteps, n, POLYBENCH_ARRAY(A), POLYBENCH_ARRAY(B));
  return 0;
}
uint32_t workload_checksum(unsigned task) {
  (void)task;
  pb_hash = 2166136261u;
  print_array(n, POLYBENCH_ARRAY(A));
  return pb_hash;
}
uint32_t (*const workload_jobs[])(void) = {task_job_polybench};
#ifndef CHASER_EXPECTED
#define CHASER_EXPECTED 0u
#endif
const uint32_t workload_expected[] = {CHASER_EXPECTED};
#ifdef CHASER_NATIVE
int main(void) { workload_reset(0); task_job_polybench();
  uint32_t first = workload_checksum(0); pb_emit = 0;
  workload_reset(0); task_job_polybench();
  if (first != workload_checksum(0)) return 1;
  printf("%u\n", first); return 0; }
#endif
