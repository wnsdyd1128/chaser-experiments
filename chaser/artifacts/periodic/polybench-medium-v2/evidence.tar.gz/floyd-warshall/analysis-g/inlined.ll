; ModuleID = 'workload.ll'
source_filename = "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/triangular-20260929/suite/floyd-warshall/source/workload.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

%struct._IO_FILE = type { i32, i8*, i8*, i8*, i8*, i8*, i8*, i8*, i8*, i8*, i8*, i8*, %struct._IO_marker*, %struct._IO_FILE*, i32, i32, i64, i16, i8, [1 x i8], i8*, i64, %struct._IO_codecvt*, %struct._IO_wide_data*, %struct._IO_FILE*, i8*, i64, i32, [20 x i8] }
%struct._IO_marker = type opaque
%struct._IO_codecvt = type opaque
%struct._IO_wide_data = type opaque
%struct.__va_list_tag = type { i32, i32, i8*, i8* }

@n = dso_local global i32 500, align 4, !dbg !0
@path = dso_local global [500 x [500 x i32]] zeroinitializer, section ".chaser_data.path", align 64, !dbg !29
@.str = private unnamed_addr constant [12 x i8] c"ape.analyze\00", section "llvm.metadata"
@.str.1 = private unnamed_addr constant [129 x i8] c"/workspace/experiments-array-support/chaser/.cache/periodic-polybench/triangular-20260929/suite/floyd-warshall/source/workload.c\00", section "llvm.metadata"
@pb_hash = internal global i32 0, align 4, !dbg !26
@workload_jobs = dso_local constant [1 x i32 ()*] [i32 ()* @task_job_polybench], align 8, !dbg !8
@workload_expected = dso_local constant [1 x i32] [i32 -161771851], align 4, !dbg !22
@stderr = external global %struct._IO_FILE*, align 8
@.str.2 = private unnamed_addr constant [23 x i8] c"==BEGIN DUMP_ARRAYS==\0A\00", align 1
@.str.3 = private unnamed_addr constant [15 x i8] c"begin dump: %s\00", align 1
@.str.4 = private unnamed_addr constant [5 x i8] c"path\00", align 1
@.str.5 = private unnamed_addr constant [2 x i8] c"\0A\00", align 1
@.str.6 = private unnamed_addr constant [4 x i8] c"%d \00", align 1
@.str.7 = private unnamed_addr constant [17 x i8] c"\0Aend   dump: %s\0A\00", align 1
@.str.8 = private unnamed_addr constant [23 x i8] c"==END   DUMP_ARRAYS==\0A\00", align 1
@pb_emit = internal global i32 1, align 4, !dbg !35
@llvm.global.annotations = appending global [1 x { i8*, i8*, i8*, i32, i8* }] [{ i8*, i8*, i8*, i32, i8* } { i8* bitcast (i32 ()* @task_job_polybench to i8*), i8* getelementptr inbounds ([12 x i8], [12 x i8]* @.str, i32 0, i32 0), i8* getelementptr inbounds ([129 x i8], [129 x i8]* @.str.1, i32 0, i32 0), i32 100, i8* null }], section "llvm.metadata"

; Function Attrs: noinline nounwind uwtable
define dso_local void @workload_prepare() #0 !dbg !45 {
  ret void, !dbg !49
}

; Function Attrs: noinline nounwind uwtable
define dso_local void @workload_reset(i32 noundef %0) #0 !dbg !50 {
  call void @llvm.dbg.value(metadata i32 %0, metadata !53, metadata !DIExpression()), !dbg !54
  call void @llvm.memset.p0i8.i64(i8* align 64 bitcast ([500 x [500 x i32]]* @path to i8*), i8 0, i64 1000000, i1 false), !dbg !55
  %2 = load i32, i32* @n, align 4, !dbg !56
  call void @init_array(i32 noundef %2, [500 x i32]* noundef getelementptr inbounds ([500 x [500 x i32]], [500 x [500 x i32]]* @path, i64 0, i64 0)), !dbg !57
  ret void, !dbg !58
}

; Function Attrs: nofree nosync nounwind readnone speculatable willreturn
declare void @llvm.dbg.declare(metadata, metadata, metadata) #1

; Function Attrs: argmemonly nofree nounwind willreturn writeonly
declare void @llvm.memset.p0i8.i64(i8* nocapture writeonly, i8, i64, i1 immarg) #2

; Function Attrs: noinline nounwind uwtable
define internal void @init_array(i32 noundef %0, [500 x i32]* noundef %1) #0 !dbg !59 {
  call void @llvm.dbg.value(metadata i32 %0, metadata !65, metadata !DIExpression()), !dbg !66
  call void @llvm.dbg.value(metadata [500 x i32]* %1, metadata !67, metadata !DIExpression()), !dbg !66
  call void @llvm.dbg.value(metadata i32 0, metadata !68, metadata !DIExpression()), !dbg !66
  br label %3, !dbg !69

3:                                                ; preds = %36, %2
  %.01 = phi i32 [ 0, %2 ], [ %37, %36 ], !dbg !71
  call void @llvm.dbg.value(metadata i32 %.01, metadata !68, metadata !DIExpression()), !dbg !66
  %4 = icmp slt i32 %.01, %0, !dbg !72
  br i1 %4, label %5, label %38, !dbg !74

5:                                                ; preds = %3
  call void @llvm.dbg.value(metadata i32 0, metadata !75, metadata !DIExpression()), !dbg !66
  br label %6, !dbg !76

6:                                                ; preds = %33, %5
  %.0 = phi i32 [ 0, %5 ], [ %34, %33 ], !dbg !78
  call void @llvm.dbg.value(metadata i32 %.0, metadata !75, metadata !DIExpression()), !dbg !66
  %7 = icmp slt i32 %.0, %0, !dbg !79
  br i1 %7, label %8, label %35, !dbg !81

8:                                                ; preds = %6
  %9 = mul nsw i32 %.01, %.0, !dbg !82
  %10 = srem i32 %9, 7, !dbg !84
  %11 = add nsw i32 %10, 1, !dbg !85
  %12 = sext i32 %.01 to i64, !dbg !86
  %13 = getelementptr inbounds [500 x i32], [500 x i32]* %1, i64 %12, !dbg !86
  %14 = sext i32 %.0 to i64, !dbg !86
  %15 = getelementptr inbounds [500 x i32], [500 x i32]* %13, i64 0, i64 %14, !dbg !86
  store i32 %11, i32* %15, align 4, !dbg !87
  %16 = add nsw i32 %.01, %.0, !dbg !88
  %17 = srem i32 %16, 13, !dbg !90
  %18 = icmp eq i32 %17, 0, !dbg !91
  br i1 %18, label %27, label %19, !dbg !92

19:                                               ; preds = %8
  %20 = add nsw i32 %.01, %.0, !dbg !93
  %21 = srem i32 %20, 7, !dbg !94
  %22 = icmp eq i32 %21, 0, !dbg !95
  br i1 %22, label %27, label %23, !dbg !96

23:                                               ; preds = %19
  %24 = add nsw i32 %.01, %.0, !dbg !97
  %25 = srem i32 %24, 11, !dbg !98
  %26 = icmp eq i32 %25, 0, !dbg !99
  br i1 %26, label %27, label %32, !dbg !100

27:                                               ; preds = %23, %19, %8
  %28 = sext i32 %.01 to i64, !dbg !101
  %29 = getelementptr inbounds [500 x i32], [500 x i32]* %1, i64 %28, !dbg !101
  %30 = sext i32 %.0 to i64, !dbg !101
  %31 = getelementptr inbounds [500 x i32], [500 x i32]* %29, i64 0, i64 %30, !dbg !101
  store i32 999, i32* %31, align 4, !dbg !102
  br label %32, !dbg !101

32:                                               ; preds = %27, %23
  br label %33, !dbg !103

33:                                               ; preds = %32
  %34 = add nsw i32 %.0, 1, !dbg !104
  call void @llvm.dbg.value(metadata i32 %34, metadata !75, metadata !DIExpression()), !dbg !66
  br label %6, !dbg !105, !llvm.loop !106

35:                                               ; preds = %6
  br label %36, !dbg !107

36:                                               ; preds = %35
  %37 = add nsw i32 %.01, 1, !dbg !109
  call void @llvm.dbg.value(metadata i32 %37, metadata !68, metadata !DIExpression()), !dbg !66
  br label %3, !dbg !110, !llvm.loop !111

38:                                               ; preds = %3
  ret void, !dbg !113
}

; Function Attrs: noinline nounwind uwtable
define dso_local i32 @task_job_polybench() #0 !dbg !114 {
  %1 = load i32, i32* @n, align 4, !dbg !115
  call void @llvm.dbg.value(metadata i32 %1, metadata !116, metadata !DIExpression()), !dbg !118
  call void @llvm.dbg.value(metadata [500 x i32]* getelementptr inbounds ([500 x [500 x i32]], [500 x [500 x i32]]* @path, i64 0, i64 0), metadata !120, metadata !DIExpression()), !dbg !118
  call void @llvm.dbg.value(metadata i32 0, metadata !121, metadata !DIExpression()), !dbg !118
  br label %2, !dbg !122

2:                                                ; preds = %55, %0
  %.0 = phi i32 [ 0, %0 ], [ %56, %55 ], !dbg !124
  call void @llvm.dbg.value(metadata i32 %.0, metadata !121, metadata !DIExpression()), !dbg !118
  %3 = icmp slt i32 %.0, 500, !dbg !125
  br i1 %3, label %4, label %57, !dbg !127

4:                                                ; preds = %2
  call void @llvm.dbg.value(metadata i32 0, metadata !128, metadata !DIExpression()), !dbg !118
  br label %5, !dbg !129

5:                                                ; preds = %53, %4
  %.02 = phi i32 [ 0, %4 ], [ %54, %53 ], !dbg !132
  call void @llvm.dbg.value(metadata i32 %.02, metadata !128, metadata !DIExpression()), !dbg !118
  %6 = icmp slt i32 %.02, 500, !dbg !133
  br i1 %6, label %7, label %55, !dbg !135

7:                                                ; preds = %5
  call void @llvm.dbg.value(metadata i32 0, metadata !136, metadata !DIExpression()), !dbg !118
  br label %8, !dbg !137

8:                                                ; preds = %46, %7
  %.01 = phi i32 [ 0, %7 ], [ %52, %46 ], !dbg !139
  call void @llvm.dbg.value(metadata i32 %.01, metadata !136, metadata !DIExpression()), !dbg !118
  %9 = icmp slt i32 %.01, 500, !dbg !140
  br i1 %9, label %10, label %53, !dbg !142

10:                                               ; preds = %8
  %11 = sext i32 %.02 to i64, !dbg !143
  %12 = getelementptr inbounds [500 x i32], [500 x i32]* getelementptr inbounds ([500 x [500 x i32]], [500 x [500 x i32]]* @path, i64 0, i64 0), i64 %11, !dbg !143
  %13 = sext i32 %.01 to i64, !dbg !143
  %14 = getelementptr inbounds [500 x i32], [500 x i32]* %12, i64 0, i64 %13, !dbg !143
  %15 = load i32, i32* %14, align 4, !dbg !143
  %16 = sext i32 %.02 to i64, !dbg !144
  %17 = getelementptr inbounds [500 x i32], [500 x i32]* getelementptr inbounds ([500 x [500 x i32]], [500 x [500 x i32]]* @path, i64 0, i64 0), i64 %16, !dbg !144
  %18 = sext i32 %.0 to i64, !dbg !144
  %19 = getelementptr inbounds [500 x i32], [500 x i32]* %17, i64 0, i64 %18, !dbg !144
  %20 = load i32, i32* %19, align 4, !dbg !144
  %21 = sext i32 %.0 to i64, !dbg !145
  %22 = getelementptr inbounds [500 x i32], [500 x i32]* getelementptr inbounds ([500 x [500 x i32]], [500 x [500 x i32]]* @path, i64 0, i64 0), i64 %21, !dbg !145
  %23 = sext i32 %.01 to i64, !dbg !145
  %24 = getelementptr inbounds [500 x i32], [500 x i32]* %22, i64 0, i64 %23, !dbg !145
  %25 = load i32, i32* %24, align 4, !dbg !145
  %26 = add nsw i32 %20, %25, !dbg !146
  %27 = icmp slt i32 %15, %26, !dbg !147
  br i1 %27, label %28, label %34, !dbg !143

28:                                               ; preds = %10
  %29 = sext i32 %.02 to i64, !dbg !148
  %30 = getelementptr inbounds [500 x i32], [500 x i32]* getelementptr inbounds ([500 x [500 x i32]], [500 x [500 x i32]]* @path, i64 0, i64 0), i64 %29, !dbg !148
  %31 = sext i32 %.01 to i64, !dbg !148
  %32 = getelementptr inbounds [500 x i32], [500 x i32]* %30, i64 0, i64 %31, !dbg !148
  %33 = load i32, i32* %32, align 4, !dbg !148
  br label %46, !dbg !143

34:                                               ; preds = %10
  %35 = sext i32 %.02 to i64, !dbg !149
  %36 = getelementptr inbounds [500 x i32], [500 x i32]* getelementptr inbounds ([500 x [500 x i32]], [500 x [500 x i32]]* @path, i64 0, i64 0), i64 %35, !dbg !149
  %37 = sext i32 %.0 to i64, !dbg !149
  %38 = getelementptr inbounds [500 x i32], [500 x i32]* %36, i64 0, i64 %37, !dbg !149
  %39 = load i32, i32* %38, align 4, !dbg !149
  %40 = sext i32 %.0 to i64, !dbg !150
  %41 = getelementptr inbounds [500 x i32], [500 x i32]* getelementptr inbounds ([500 x [500 x i32]], [500 x [500 x i32]]* @path, i64 0, i64 0), i64 %40, !dbg !150
  %42 = sext i32 %.01 to i64, !dbg !150
  %43 = getelementptr inbounds [500 x i32], [500 x i32]* %41, i64 0, i64 %42, !dbg !150
  %44 = load i32, i32* %43, align 4, !dbg !150
  %45 = add nsw i32 %39, %44, !dbg !151
  br label %46, !dbg !143

46:                                               ; preds = %34, %28
  %47 = phi i32 [ %33, %28 ], [ %45, %34 ], !dbg !143
  %48 = sext i32 %.02 to i64, !dbg !152
  %49 = getelementptr inbounds [500 x i32], [500 x i32]* getelementptr inbounds ([500 x [500 x i32]], [500 x [500 x i32]]* @path, i64 0, i64 0), i64 %48, !dbg !152
  %50 = sext i32 %.01 to i64, !dbg !152
  %51 = getelementptr inbounds [500 x i32], [500 x i32]* %49, i64 0, i64 %50, !dbg !152
  store i32 %47, i32* %51, align 4, !dbg !153
  %52 = add nsw i32 %.01, 1, !dbg !154
  call void @llvm.dbg.value(metadata i32 %52, metadata !136, metadata !DIExpression()), !dbg !118
  br label %8, !dbg !155, !llvm.loop !156

53:                                               ; preds = %8
  %54 = add nsw i32 %.02, 1, !dbg !158
  call void @llvm.dbg.value(metadata i32 %54, metadata !128, metadata !DIExpression()), !dbg !118
  br label %5, !dbg !159, !llvm.loop !160

55:                                               ; preds = %5
  %56 = add nsw i32 %.0, 1, !dbg !162
  call void @llvm.dbg.value(metadata i32 %56, metadata !121, metadata !DIExpression()), !dbg !118
  br label %2, !dbg !163, !llvm.loop !164

57:                                               ; preds = %2
  ret i32 0, !dbg !166
}

; Function Attrs: noinline nounwind uwtable
define dso_local i32 @workload_checksum(i32 noundef %0) #0 !dbg !167 {
  call void @llvm.dbg.value(metadata i32 %0, metadata !170, metadata !DIExpression()), !dbg !171
  store i32 -2128831035, i32* @pb_hash, align 4, !dbg !172
  %2 = load i32, i32* @n, align 4, !dbg !173
  call void @print_array(i32 noundef %2, [500 x i32]* noundef getelementptr inbounds ([500 x [500 x i32]], [500 x [500 x i32]]* @path, i64 0, i64 0)), !dbg !174
  %3 = load i32, i32* @pb_hash, align 4, !dbg !175
  ret i32 %3, !dbg !176
}

; Function Attrs: noinline nounwind uwtable
define internal void @print_array(i32 noundef %0, [500 x i32]* noundef %1) #0 !dbg !177 {
  call void @llvm.dbg.value(metadata i32 %0, metadata !178, metadata !DIExpression()), !dbg !179
  call void @llvm.dbg.value(metadata [500 x i32]* %1, metadata !180, metadata !DIExpression()), !dbg !179
  %3 = load %struct._IO_FILE*, %struct._IO_FILE** @stderr, align 8, !dbg !181
  %4 = call i32 (%struct._IO_FILE*, i8*, ...) @pb_fprintf(%struct._IO_FILE* noundef %3, i8* noundef getelementptr inbounds ([23 x i8], [23 x i8]* @.str.2, i64 0, i64 0)), !dbg !181
  %5 = load %struct._IO_FILE*, %struct._IO_FILE** @stderr, align 8, !dbg !182
  %6 = call i32 (%struct._IO_FILE*, i8*, ...) @pb_fprintf(%struct._IO_FILE* noundef %5, i8* noundef getelementptr inbounds ([15 x i8], [15 x i8]* @.str.3, i64 0, i64 0), i8* noundef getelementptr inbounds ([5 x i8], [5 x i8]* @.str.4, i64 0, i64 0)), !dbg !182
  call void @llvm.dbg.value(metadata i32 0, metadata !183, metadata !DIExpression()), !dbg !179
  br label %7, !dbg !184

7:                                                ; preds = %31, %2
  %.01 = phi i32 [ 0, %2 ], [ %32, %31 ], !dbg !186
  call void @llvm.dbg.value(metadata i32 %.01, metadata !183, metadata !DIExpression()), !dbg !179
  %8 = icmp slt i32 %.01, %0, !dbg !187
  br i1 %8, label %9, label %33, !dbg !189

9:                                                ; preds = %7
  call void @llvm.dbg.value(metadata i32 0, metadata !190, metadata !DIExpression()), !dbg !179
  br label %10, !dbg !191

10:                                               ; preds = %28, %9
  %.0 = phi i32 [ 0, %9 ], [ %29, %28 ], !dbg !193
  call void @llvm.dbg.value(metadata i32 %.0, metadata !190, metadata !DIExpression()), !dbg !179
  %11 = icmp slt i32 %.0, %0, !dbg !194
  br i1 %11, label %12, label %30, !dbg !196

12:                                               ; preds = %10
  %13 = mul nsw i32 %.01, %0, !dbg !197
  %14 = add nsw i32 %13, %.0, !dbg !200
  %15 = srem i32 %14, 20, !dbg !201
  %16 = icmp eq i32 %15, 0, !dbg !202
  br i1 %16, label %17, label %20, !dbg !203

17:                                               ; preds = %12
  %18 = load %struct._IO_FILE*, %struct._IO_FILE** @stderr, align 8, !dbg !204
  %19 = call i32 (%struct._IO_FILE*, i8*, ...) @pb_fprintf(%struct._IO_FILE* noundef %18, i8* noundef getelementptr inbounds ([2 x i8], [2 x i8]* @.str.5, i64 0, i64 0)), !dbg !205
  br label %20, !dbg !205

20:                                               ; preds = %17, %12
  %21 = load %struct._IO_FILE*, %struct._IO_FILE** @stderr, align 8, !dbg !206
  %22 = sext i32 %.01 to i64, !dbg !207
  %23 = getelementptr inbounds [500 x i32], [500 x i32]* %1, i64 %22, !dbg !207
  %24 = sext i32 %.0 to i64, !dbg !207
  %25 = getelementptr inbounds [500 x i32], [500 x i32]* %23, i64 0, i64 %24, !dbg !207
  %26 = load i32, i32* %25, align 4, !dbg !207
  %27 = call i32 (%struct._IO_FILE*, i8*, ...) @pb_fprintf(%struct._IO_FILE* noundef %21, i8* noundef getelementptr inbounds ([4 x i8], [4 x i8]* @.str.6, i64 0, i64 0), i32 noundef %26), !dbg !208
  br label %28, !dbg !209

28:                                               ; preds = %20
  %29 = add nsw i32 %.0, 1, !dbg !210
  call void @llvm.dbg.value(metadata i32 %29, metadata !190, metadata !DIExpression()), !dbg !179
  br label %10, !dbg !211, !llvm.loop !212

30:                                               ; preds = %10
  br label %31, !dbg !213

31:                                               ; preds = %30
  %32 = add nsw i32 %.01, 1, !dbg !214
  call void @llvm.dbg.value(metadata i32 %32, metadata !183, metadata !DIExpression()), !dbg !179
  br label %7, !dbg !215, !llvm.loop !216

33:                                               ; preds = %7
  %34 = load %struct._IO_FILE*, %struct._IO_FILE** @stderr, align 8, !dbg !218
  %35 = call i32 (%struct._IO_FILE*, i8*, ...) @pb_fprintf(%struct._IO_FILE* noundef %34, i8* noundef getelementptr inbounds ([17 x i8], [17 x i8]* @.str.7, i64 0, i64 0), i8* noundef getelementptr inbounds ([5 x i8], [5 x i8]* @.str.4, i64 0, i64 0)), !dbg !218
  %36 = load %struct._IO_FILE*, %struct._IO_FILE** @stderr, align 8, !dbg !219
  %37 = call i32 (%struct._IO_FILE*, i8*, ...) @pb_fprintf(%struct._IO_FILE* noundef %36, i8* noundef getelementptr inbounds ([23 x i8], [23 x i8]* @.str.8, i64 0, i64 0)), !dbg !219
  ret void, !dbg !220
}

; Function Attrs: noinline nounwind uwtable
define internal i32 @pb_fprintf(%struct._IO_FILE* noundef %0, i8* noundef %1, ...) #0 !dbg !221 {
  %3 = alloca [768 x i8], align 16
  %4 = alloca [1 x %struct.__va_list_tag], align 16
  call void @llvm.dbg.value(metadata %struct._IO_FILE* %0, metadata !285, metadata !DIExpression()), !dbg !286
  call void @llvm.dbg.value(metadata i8* %1, metadata !287, metadata !DIExpression()), !dbg !286
  call void @llvm.dbg.declare(metadata [768 x i8]* %3, metadata !288, metadata !DIExpression()), !dbg !292
  call void @llvm.dbg.declare(metadata [1 x %struct.__va_list_tag]* %4, metadata !293, metadata !DIExpression()), !dbg !307
  %5 = getelementptr inbounds [1 x %struct.__va_list_tag], [1 x %struct.__va_list_tag]* %4, i64 0, i64 0, !dbg !308
  %6 = bitcast %struct.__va_list_tag* %5 to i8*, !dbg !308
  call void @llvm.va_start(i8* %6), !dbg !308
  %7 = getelementptr inbounds [768 x i8], [768 x i8]* %3, i64 0, i64 0, !dbg !309
  %8 = getelementptr inbounds [1 x %struct.__va_list_tag], [1 x %struct.__va_list_tag]* %4, i64 0, i64 0, !dbg !310
  %9 = call i32 @vsnprintf(i8* noundef %7, i64 noundef 768, i8* noundef %1, %struct.__va_list_tag* noundef %8) #6, !dbg !311
  call void @llvm.dbg.value(metadata i32 %9, metadata !312, metadata !DIExpression()), !dbg !286
  %10 = getelementptr inbounds [1 x %struct.__va_list_tag], [1 x %struct.__va_list_tag]* %4, i64 0, i64 0, !dbg !313
  %11 = bitcast %struct.__va_list_tag* %10 to i8*, !dbg !313
  call void @llvm.va_end(i8* %11), !dbg !313
  %12 = icmp slt i32 %9, 0, !dbg !314
  br i1 %12, label %16, label %13, !dbg !316

13:                                               ; preds = %2
  %14 = zext i32 %9 to i64, !dbg !317
  %15 = icmp uge i64 %14, 768, !dbg !318
  br i1 %15, label %16, label %17, !dbg !319

16:                                               ; preds = %13, %2
  call void @abort() #7, !dbg !320
  unreachable, !dbg !320

17:                                               ; preds = %13
  call void @llvm.dbg.value(metadata i32 0, metadata !321, metadata !DIExpression()), !dbg !323
  br label %18, !dbg !324

18:                                               ; preds = %29, %17
  %.0 = phi i32 [ 0, %17 ], [ %30, %29 ], !dbg !323
  call void @llvm.dbg.value(metadata i32 %.0, metadata !321, metadata !DIExpression()), !dbg !323
  %19 = icmp slt i32 %.0, %9, !dbg !325
  br i1 %19, label %20, label %31, !dbg !327

20:                                               ; preds = %18
  %21 = sext i32 %.0 to i64, !dbg !328
  %22 = getelementptr inbounds [768 x i8], [768 x i8]* %3, i64 0, i64 %21, !dbg !328
  %23 = load i8, i8* %22, align 1, !dbg !328
  %24 = zext i8 %23 to i32, !dbg !330
  %25 = load i32, i32* @pb_hash, align 4, !dbg !331
  %26 = xor i32 %25, %24, !dbg !331
  store i32 %26, i32* @pb_hash, align 4, !dbg !331
  %27 = load i32, i32* @pb_hash, align 4, !dbg !332
  %28 = mul i32 %27, 16777619, !dbg !332
  store i32 %28, i32* @pb_hash, align 4, !dbg !332
  br label %29, !dbg !333

29:                                               ; preds = %20
  %30 = add nsw i32 %.0, 1, !dbg !334
  call void @llvm.dbg.value(metadata i32 %30, metadata !321, metadata !DIExpression()), !dbg !323
  br label %18, !dbg !335, !llvm.loop !336

31:                                               ; preds = %18
  %32 = load i32, i32* @pb_emit, align 4, !dbg !338
  ret i32 %9, !dbg !339
}

; Function Attrs: nofree nosync nounwind willreturn
declare void @llvm.va_start(i8*) #3

; Function Attrs: nounwind
declare i32 @vsnprintf(i8* noundef, i64 noundef, i8* noundef, %struct.__va_list_tag* noundef) #4

; Function Attrs: nofree nosync nounwind willreturn
declare void @llvm.va_end(i8*) #3

; Function Attrs: noreturn nounwind
declare void @abort() #5

; Function Attrs: nofree nosync nounwind readnone speculatable willreturn
declare void @llvm.dbg.value(metadata, metadata, metadata) #1

attributes #0 = { noinline nounwind uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { nofree nosync nounwind readnone speculatable willreturn }
attributes #2 = { argmemonly nofree nounwind willreturn writeonly }
attributes #3 = { nofree nosync nounwind willreturn }
attributes #4 = { nounwind "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #5 = { noreturn nounwind "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #6 = { nounwind }
attributes #7 = { noreturn nounwind }

!llvm.dbg.cu = !{!2}
!llvm.module.flags = !{!37, !38, !39, !40, !41, !42, !43}
!llvm.ident = !{!44}

!0 = !DIGlobalVariableExpression(var: !1, expr: !DIExpression())
!1 = distinct !DIGlobalVariable(name: "n", scope: !2, file: !10, line: 93, type: !32, isLocal: false, isDefinition: true)
!2 = distinct !DICompileUnit(language: DW_LANG_C99, file: !3, producer: "Ubuntu clang version 14.0.0-1ubuntu1.1", isOptimized: false, runtimeVersion: 0, emissionKind: FullDebug, retainedTypes: !4, globals: !7, splitDebugInlining: false, nameTableKind: None)
!3 = !DIFile(filename: "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/triangular-20260929/suite/floyd-warshall/source/workload.c", directory: "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/triangular-20260929/suite/floyd-warshall/analysis-g", checksumkind: CSK_MD5, checksum: "829643a027e81ecd281897c0f8fc5926")
!4 = !{!5, !6}
!5 = !DIBasicType(name: "unsigned int", size: 32, encoding: DW_ATE_unsigned)
!6 = !DIBasicType(name: "unsigned char", size: 8, encoding: DW_ATE_unsigned_char)
!7 = !{!0, !8, !22, !26, !29, !35}
!8 = !DIGlobalVariableExpression(var: !9, expr: !DIExpression())
!9 = distinct !DIGlobalVariable(name: "workload_jobs", scope: !2, file: !10, line: 110, type: !11, isLocal: false, isDefinition: true)
!10 = !DIFile(filename: "source/workload.c", directory: "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/triangular-20260929/suite/floyd-warshall", checksumkind: CSK_MD5, checksum: "829643a027e81ecd281897c0f8fc5926")
!11 = !DICompositeType(tag: DW_TAG_array_type, baseType: !12, size: 64, elements: !20)
!12 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !13)
!13 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !14, size: 64)
!14 = !DISubroutineType(types: !15)
!15 = !{!16}
!16 = !DIDerivedType(tag: DW_TAG_typedef, name: "uint32_t", file: !17, line: 26, baseType: !18)
!17 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/stdint-uintn.h", directory: "", checksumkind: CSK_MD5, checksum: "2bf2ae53c58c01b1a1b9383b5195125c")
!18 = !DIDerivedType(tag: DW_TAG_typedef, name: "__uint32_t", file: !19, line: 42, baseType: !5)
!19 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/types.h", directory: "", checksumkind: CSK_MD5, checksum: "d108b5f93a74c50510d7d9bc0ab36df9")
!20 = !{!21}
!21 = !DISubrange(count: 1)
!22 = !DIGlobalVariableExpression(var: !23, expr: !DIExpression())
!23 = distinct !DIGlobalVariable(name: "workload_expected", scope: !2, file: !10, line: 114, type: !24, isLocal: false, isDefinition: true)
!24 = !DICompositeType(tag: DW_TAG_array_type, baseType: !25, size: 32, elements: !20)
!25 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !16)
!26 = !DIGlobalVariableExpression(var: !27, expr: !DIExpression())
!27 = distinct !DIGlobalVariable(name: "pb_hash", scope: !2, file: !28, line: 9, type: !16, isLocal: true, isDefinition: true)
!28 = !DIFile(filename: "source/adapter.h", directory: "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/triangular-20260929/suite/floyd-warshall", checksumkind: CSK_MD5, checksum: "26a6068928b2092758f244a9d00163d7")
!29 = !DIGlobalVariableExpression(var: !30, expr: !DIExpression())
!30 = distinct !DIGlobalVariable(name: "path", scope: !2, file: !10, line: 34, type: !31, isLocal: false, isDefinition: true, align: 512)
!31 = !DICompositeType(tag: DW_TAG_array_type, baseType: !32, size: 8000000, elements: !33)
!32 = !DIBasicType(name: "int", size: 32, encoding: DW_ATE_signed)
!33 = !{!34, !34}
!34 = !DISubrange(count: 500)
!35 = !DIGlobalVariableExpression(var: !36, expr: !DIExpression())
!36 = distinct !DIGlobalVariable(name: "pb_emit", scope: !2, file: !28, line: 10, type: !32, isLocal: true, isDefinition: true)
!37 = !{i32 7, !"Dwarf Version", i32 5}
!38 = !{i32 2, !"Debug Info Version", i32 3}
!39 = !{i32 1, !"wchar_size", i32 4}
!40 = !{i32 7, !"PIC Level", i32 2}
!41 = !{i32 7, !"PIE Level", i32 2}
!42 = !{i32 7, !"uwtable", i32 1}
!43 = !{i32 7, !"frame-pointer", i32 2}
!44 = !{!"Ubuntu clang version 14.0.0-1ubuntu1.1"}
!45 = distinct !DISubprogram(name: "workload_prepare", scope: !10, file: !10, line: 94, type: !46, scopeLine: 94, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !2, retainedNodes: !48)
!46 = !DISubroutineType(types: !47)
!47 = !{null}
!48 = !{}
!49 = !DILocation(line: 94, column: 30, scope: !45)
!50 = distinct !DISubprogram(name: "workload_reset", scope: !10, file: !10, line: 95, type: !51, scopeLine: 95, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !2, retainedNodes: !48)
!51 = !DISubroutineType(types: !52)
!52 = !{null, !5}
!53 = !DILocalVariable(name: "task", arg: 1, scope: !50, file: !10, line: 95, type: !5)
!54 = !DILocation(line: 0, scope: !50)
!55 = !DILocation(line: 97, column: 3, scope: !50)
!56 = !DILocation(line: 98, column: 15, scope: !50)
!57 = !DILocation(line: 98, column: 3, scope: !50)
!58 = !DILocation(line: 99, column: 1, scope: !50)
!59 = distinct !DISubprogram(name: "init_array", scope: !10, file: !10, line: 36, type: !60, scopeLine: 38, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition, unit: !2, retainedNodes: !48)
!60 = !DISubroutineType(types: !61)
!61 = !{null, !32, !62}
!62 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !63, size: 64)
!63 = !DICompositeType(tag: DW_TAG_array_type, baseType: !32, size: 16000, elements: !64)
!64 = !{!34}
!65 = !DILocalVariable(name: "n", arg: 1, scope: !59, file: !10, line: 36, type: !32)
!66 = !DILocation(line: 0, scope: !59)
!67 = !DILocalVariable(name: "path", arg: 2, scope: !59, file: !10, line: 37, type: !62)
!68 = !DILocalVariable(name: "i", scope: !59, file: !10, line: 39, type: !32)
!69 = !DILocation(line: 41, column: 8, scope: !70)
!70 = distinct !DILexicalBlock(scope: !59, file: !10, line: 41, column: 3)
!71 = !DILocation(line: 0, scope: !70)
!72 = !DILocation(line: 41, column: 17, scope: !73)
!73 = distinct !DILexicalBlock(scope: !70, file: !10, line: 41, column: 3)
!74 = !DILocation(line: 41, column: 3, scope: !70)
!75 = !DILocalVariable(name: "j", scope: !59, file: !10, line: 39, type: !32)
!76 = !DILocation(line: 42, column: 10, scope: !77)
!77 = distinct !DILexicalBlock(scope: !73, file: !10, line: 42, column: 5)
!78 = !DILocation(line: 0, scope: !77)
!79 = !DILocation(line: 42, column: 19, scope: !80)
!80 = distinct !DILexicalBlock(scope: !77, file: !10, line: 42, column: 5)
!81 = !DILocation(line: 42, column: 5, scope: !77)
!82 = !DILocation(line: 43, column: 21, scope: !83)
!83 = distinct !DILexicalBlock(scope: !80, file: !10, line: 42, column: 29)
!84 = !DILocation(line: 43, column: 23, scope: !83)
!85 = !DILocation(line: 43, column: 25, scope: !83)
!86 = !DILocation(line: 43, column: 7, scope: !83)
!87 = !DILocation(line: 43, column: 18, scope: !83)
!88 = !DILocation(line: 44, column: 13, scope: !89)
!89 = distinct !DILexicalBlock(scope: !83, file: !10, line: 44, column: 11)
!90 = !DILocation(line: 44, column: 16, scope: !89)
!91 = !DILocation(line: 44, column: 20, scope: !89)
!92 = !DILocation(line: 44, column: 25, scope: !89)
!93 = !DILocation(line: 44, column: 30, scope: !89)
!94 = !DILocation(line: 44, column: 33, scope: !89)
!95 = !DILocation(line: 44, column: 35, scope: !89)
!96 = !DILocation(line: 44, column: 39, scope: !89)
!97 = !DILocation(line: 44, column: 44, scope: !89)
!98 = !DILocation(line: 44, column: 47, scope: !89)
!99 = !DILocation(line: 44, column: 51, scope: !89)
!100 = !DILocation(line: 44, column: 11, scope: !83)
!101 = !DILocation(line: 45, column: 10, scope: !89)
!102 = !DILocation(line: 45, column: 21, scope: !89)
!103 = !DILocation(line: 46, column: 5, scope: !83)
!104 = !DILocation(line: 42, column: 25, scope: !80)
!105 = !DILocation(line: 42, column: 5, scope: !80)
!106 = distinct !{!106, !81, !107, !108}
!107 = !DILocation(line: 46, column: 5, scope: !77)
!108 = !{!"llvm.loop.mustprogress"}
!109 = !DILocation(line: 41, column: 23, scope: !73)
!110 = !DILocation(line: 41, column: 3, scope: !73)
!111 = distinct !{!111, !74, !112, !108}
!112 = !DILocation(line: 46, column: 5, scope: !70)
!113 = !DILocation(line: 47, column: 1, scope: !59)
!114 = distinct !DISubprogram(name: "task_job_polybench", scope: !10, file: !10, line: 100, type: !14, scopeLine: 100, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !2, retainedNodes: !48)
!115 = !DILocation(line: 101, column: 26, scope: !114)
!116 = !DILocalVariable(name: "n", arg: 1, scope: !117, file: !10, line: 74, type: !32)
!117 = distinct !DISubprogram(name: "kernel_floyd_warshall", scope: !10, file: !10, line: 74, type: !60, scopeLine: 76, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition, unit: !2, retainedNodes: !48)
!118 = !DILocation(line: 0, scope: !117, inlinedAt: !119)
!119 = distinct !DILocation(line: 101, column: 3, scope: !114)
!120 = !DILocalVariable(name: "path", arg: 2, scope: !117, file: !10, line: 75, type: !62)
!121 = !DILocalVariable(name: "k", scope: !117, file: !10, line: 77, type: !32)
!122 = !DILocation(line: 80, column: 8, scope: !123, inlinedAt: !119)
!123 = distinct !DILexicalBlock(scope: !117, file: !10, line: 80, column: 3)
!124 = !DILocation(line: 0, scope: !123, inlinedAt: !119)
!125 = !DILocation(line: 80, column: 17, scope: !126, inlinedAt: !119)
!126 = distinct !DILexicalBlock(scope: !123, file: !10, line: 80, column: 3)
!127 = !DILocation(line: 80, column: 3, scope: !123, inlinedAt: !119)
!128 = !DILocalVariable(name: "i", scope: !117, file: !10, line: 77, type: !32)
!129 = !DILocation(line: 82, column: 11, scope: !130, inlinedAt: !119)
!130 = distinct !DILexicalBlock(scope: !131, file: !10, line: 82, column: 7)
!131 = distinct !DILexicalBlock(scope: !126, file: !10, line: 81, column: 5)
!132 = !DILocation(line: 0, scope: !130, inlinedAt: !119)
!133 = !DILocation(line: 82, column: 20, scope: !134, inlinedAt: !119)
!134 = distinct !DILexicalBlock(scope: !130, file: !10, line: 82, column: 7)
!135 = !DILocation(line: 82, column: 7, scope: !130, inlinedAt: !119)
!136 = !DILocalVariable(name: "j", scope: !117, file: !10, line: 77, type: !32)
!137 = !DILocation(line: 83, column: 7, scope: !138, inlinedAt: !119)
!138 = distinct !DILexicalBlock(scope: !134, file: !10, line: 83, column: 2)
!139 = !DILocation(line: 0, scope: !138, inlinedAt: !119)
!140 = !DILocation(line: 83, column: 16, scope: !141, inlinedAt: !119)
!141 = distinct !DILexicalBlock(scope: !138, file: !10, line: 83, column: 2)
!142 = !DILocation(line: 83, column: 2, scope: !138, inlinedAt: !119)
!143 = !DILocation(line: 84, column: 17, scope: !141, inlinedAt: !119)
!144 = !DILocation(line: 84, column: 30, scope: !141, inlinedAt: !119)
!145 = !DILocation(line: 84, column: 43, scope: !141, inlinedAt: !119)
!146 = !DILocation(line: 84, column: 41, scope: !141, inlinedAt: !119)
!147 = !DILocation(line: 84, column: 28, scope: !141, inlinedAt: !119)
!148 = !DILocation(line: 85, column: 6, scope: !141, inlinedAt: !119)
!149 = !DILocation(line: 85, column: 19, scope: !141, inlinedAt: !119)
!150 = !DILocation(line: 85, column: 32, scope: !141, inlinedAt: !119)
!151 = !DILocation(line: 85, column: 30, scope: !141, inlinedAt: !119)
!152 = !DILocation(line: 84, column: 4, scope: !141, inlinedAt: !119)
!153 = !DILocation(line: 84, column: 15, scope: !141, inlinedAt: !119)
!154 = !DILocation(line: 83, column: 26, scope: !141, inlinedAt: !119)
!155 = !DILocation(line: 83, column: 2, scope: !141, inlinedAt: !119)
!156 = distinct !{!156, !142, !157, !108}
!157 = !DILocation(line: 85, column: 41, scope: !138, inlinedAt: !119)
!158 = !DILocation(line: 82, column: 30, scope: !134, inlinedAt: !119)
!159 = !DILocation(line: 82, column: 7, scope: !134, inlinedAt: !119)
!160 = distinct !{!160, !135, !161, !108}
!161 = !DILocation(line: 85, column: 41, scope: !130, inlinedAt: !119)
!162 = !DILocation(line: 80, column: 27, scope: !126, inlinedAt: !119)
!163 = !DILocation(line: 80, column: 3, scope: !126, inlinedAt: !119)
!164 = distinct !{!164, !127, !165, !108}
!165 = !DILocation(line: 86, column: 5, scope: !123, inlinedAt: !119)
!166 = !DILocation(line: 102, column: 3, scope: !114)
!167 = distinct !DISubprogram(name: "workload_checksum", scope: !10, file: !10, line: 104, type: !168, scopeLine: 104, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !2, retainedNodes: !48)
!168 = !DISubroutineType(types: !169)
!169 = !{!16, !5}
!170 = !DILocalVariable(name: "task", arg: 1, scope: !167, file: !10, line: 104, type: !5)
!171 = !DILocation(line: 0, scope: !167)
!172 = !DILocation(line: 106, column: 11, scope: !167)
!173 = !DILocation(line: 107, column: 15, scope: !167)
!174 = !DILocation(line: 107, column: 3, scope: !167)
!175 = !DILocation(line: 108, column: 10, scope: !167)
!176 = !DILocation(line: 108, column: 3, scope: !167)
!177 = distinct !DISubprogram(name: "print_array", scope: !10, file: !10, line: 53, type: !60, scopeLine: 56, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition, unit: !2, retainedNodes: !48)
!178 = !DILocalVariable(name: "n", arg: 1, scope: !177, file: !10, line: 53, type: !32)
!179 = !DILocation(line: 0, scope: !177)
!180 = !DILocalVariable(name: "path", arg: 2, scope: !177, file: !10, line: 54, type: !62)
!181 = !DILocation(line: 59, column: 3, scope: !177)
!182 = !DILocation(line: 60, column: 3, scope: !177)
!183 = !DILocalVariable(name: "i", scope: !177, file: !10, line: 57, type: !32)
!184 = !DILocation(line: 61, column: 8, scope: !185)
!185 = distinct !DILexicalBlock(scope: !177, file: !10, line: 61, column: 3)
!186 = !DILocation(line: 0, scope: !185)
!187 = !DILocation(line: 61, column: 17, scope: !188)
!188 = distinct !DILexicalBlock(scope: !185, file: !10, line: 61, column: 3)
!189 = !DILocation(line: 61, column: 3, scope: !185)
!190 = !DILocalVariable(name: "j", scope: !177, file: !10, line: 57, type: !32)
!191 = !DILocation(line: 62, column: 10, scope: !192)
!192 = distinct !DILexicalBlock(scope: !188, file: !10, line: 62, column: 5)
!193 = !DILocation(line: 0, scope: !192)
!194 = !DILocation(line: 62, column: 19, scope: !195)
!195 = distinct !DILexicalBlock(scope: !192, file: !10, line: 62, column: 5)
!196 = !DILocation(line: 62, column: 5, scope: !192)
!197 = !DILocation(line: 63, column: 14, scope: !198)
!198 = distinct !DILexicalBlock(scope: !199, file: !10, line: 63, column: 11)
!199 = distinct !DILexicalBlock(scope: !195, file: !10, line: 62, column: 29)
!200 = !DILocation(line: 63, column: 18, scope: !198)
!201 = !DILocation(line: 63, column: 23, scope: !198)
!202 = !DILocation(line: 63, column: 28, scope: !198)
!203 = !DILocation(line: 63, column: 11, scope: !199)
!204 = !DILocation(line: 63, column: 43, scope: !198)
!205 = !DILocation(line: 63, column: 34, scope: !198)
!206 = !DILocation(line: 64, column: 16, scope: !199)
!207 = !DILocation(line: 64, column: 61, scope: !199)
!208 = !DILocation(line: 64, column: 7, scope: !199)
!209 = !DILocation(line: 65, column: 5, scope: !199)
!210 = !DILocation(line: 62, column: 25, scope: !195)
!211 = !DILocation(line: 62, column: 5, scope: !195)
!212 = distinct !{!212, !196, !213, !108}
!213 = !DILocation(line: 65, column: 5, scope: !192)
!214 = !DILocation(line: 61, column: 23, scope: !188)
!215 = !DILocation(line: 61, column: 3, scope: !188)
!216 = distinct !{!216, !189, !217, !108}
!217 = !DILocation(line: 65, column: 5, scope: !185)
!218 = !DILocation(line: 66, column: 3, scope: !177)
!219 = !DILocation(line: 67, column: 3, scope: !177)
!220 = !DILocation(line: 68, column: 1, scope: !177)
!221 = distinct !DISubprogram(name: "pb_fprintf", scope: !28, file: !28, line: 13, type: !222, scopeLine: 14, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition, unit: !2, retainedNodes: !48)
!222 = !DISubroutineType(types: !223)
!223 = !{!32, !224, !283, null}
!224 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !225, size: 64)
!225 = !DIDerivedType(tag: DW_TAG_typedef, name: "FILE", file: !226, line: 7, baseType: !227)
!226 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/types/FILE.h", directory: "", checksumkind: CSK_MD5, checksum: "571f9fb6223c42439075fdde11a0de5d")
!227 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "_IO_FILE", file: !228, line: 49, size: 1728, elements: !229)
!228 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/types/struct_FILE.h", directory: "", checksumkind: CSK_MD5, checksum: "1bad07471b7974df4ecc1d1c2ca207e6")
!229 = !{!230, !231, !234, !235, !236, !237, !238, !239, !240, !241, !242, !243, !244, !247, !249, !250, !251, !254, !256, !258, !260, !263, !265, !268, !271, !272, !274, !278, !279}
!230 = !DIDerivedType(tag: DW_TAG_member, name: "_flags", scope: !227, file: !228, line: 51, baseType: !32, size: 32)
!231 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_read_ptr", scope: !227, file: !228, line: 54, baseType: !232, size: 64, offset: 64)
!232 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !233, size: 64)
!233 = !DIBasicType(name: "char", size: 8, encoding: DW_ATE_signed_char)
!234 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_read_end", scope: !227, file: !228, line: 55, baseType: !232, size: 64, offset: 128)
!235 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_read_base", scope: !227, file: !228, line: 56, baseType: !232, size: 64, offset: 192)
!236 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_write_base", scope: !227, file: !228, line: 57, baseType: !232, size: 64, offset: 256)
!237 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_write_ptr", scope: !227, file: !228, line: 58, baseType: !232, size: 64, offset: 320)
!238 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_write_end", scope: !227, file: !228, line: 59, baseType: !232, size: 64, offset: 384)
!239 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_buf_base", scope: !227, file: !228, line: 60, baseType: !232, size: 64, offset: 448)
!240 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_buf_end", scope: !227, file: !228, line: 61, baseType: !232, size: 64, offset: 512)
!241 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_save_base", scope: !227, file: !228, line: 64, baseType: !232, size: 64, offset: 576)
!242 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_backup_base", scope: !227, file: !228, line: 65, baseType: !232, size: 64, offset: 640)
!243 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_save_end", scope: !227, file: !228, line: 66, baseType: !232, size: 64, offset: 704)
!244 = !DIDerivedType(tag: DW_TAG_member, name: "_markers", scope: !227, file: !228, line: 68, baseType: !245, size: 64, offset: 768)
!245 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !246, size: 64)
!246 = !DICompositeType(tag: DW_TAG_structure_type, name: "_IO_marker", file: !228, line: 36, flags: DIFlagFwdDecl)
!247 = !DIDerivedType(tag: DW_TAG_member, name: "_chain", scope: !227, file: !228, line: 70, baseType: !248, size: 64, offset: 832)
!248 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !227, size: 64)
!249 = !DIDerivedType(tag: DW_TAG_member, name: "_fileno", scope: !227, file: !228, line: 72, baseType: !32, size: 32, offset: 896)
!250 = !DIDerivedType(tag: DW_TAG_member, name: "_flags2", scope: !227, file: !228, line: 73, baseType: !32, size: 32, offset: 928)
!251 = !DIDerivedType(tag: DW_TAG_member, name: "_old_offset", scope: !227, file: !228, line: 74, baseType: !252, size: 64, offset: 960)
!252 = !DIDerivedType(tag: DW_TAG_typedef, name: "__off_t", file: !19, line: 152, baseType: !253)
!253 = !DIBasicType(name: "long", size: 64, encoding: DW_ATE_signed)
!254 = !DIDerivedType(tag: DW_TAG_member, name: "_cur_column", scope: !227, file: !228, line: 77, baseType: !255, size: 16, offset: 1024)
!255 = !DIBasicType(name: "unsigned short", size: 16, encoding: DW_ATE_unsigned)
!256 = !DIDerivedType(tag: DW_TAG_member, name: "_vtable_offset", scope: !227, file: !228, line: 78, baseType: !257, size: 8, offset: 1040)
!257 = !DIBasicType(name: "signed char", size: 8, encoding: DW_ATE_signed_char)
!258 = !DIDerivedType(tag: DW_TAG_member, name: "_shortbuf", scope: !227, file: !228, line: 79, baseType: !259, size: 8, offset: 1048)
!259 = !DICompositeType(tag: DW_TAG_array_type, baseType: !233, size: 8, elements: !20)
!260 = !DIDerivedType(tag: DW_TAG_member, name: "_lock", scope: !227, file: !228, line: 81, baseType: !261, size: 64, offset: 1088)
!261 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !262, size: 64)
!262 = !DIDerivedType(tag: DW_TAG_typedef, name: "_IO_lock_t", file: !228, line: 43, baseType: null)
!263 = !DIDerivedType(tag: DW_TAG_member, name: "_offset", scope: !227, file: !228, line: 89, baseType: !264, size: 64, offset: 1152)
!264 = !DIDerivedType(tag: DW_TAG_typedef, name: "__off64_t", file: !19, line: 153, baseType: !253)
!265 = !DIDerivedType(tag: DW_TAG_member, name: "_codecvt", scope: !227, file: !228, line: 91, baseType: !266, size: 64, offset: 1216)
!266 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !267, size: 64)
!267 = !DICompositeType(tag: DW_TAG_structure_type, name: "_IO_codecvt", file: !228, line: 37, flags: DIFlagFwdDecl)
!268 = !DIDerivedType(tag: DW_TAG_member, name: "_wide_data", scope: !227, file: !228, line: 92, baseType: !269, size: 64, offset: 1280)
!269 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !270, size: 64)
!270 = !DICompositeType(tag: DW_TAG_structure_type, name: "_IO_wide_data", file: !228, line: 38, flags: DIFlagFwdDecl)
!271 = !DIDerivedType(tag: DW_TAG_member, name: "_freeres_list", scope: !227, file: !228, line: 93, baseType: !248, size: 64, offset: 1344)
!272 = !DIDerivedType(tag: DW_TAG_member, name: "_freeres_buf", scope: !227, file: !228, line: 94, baseType: !273, size: 64, offset: 1408)
!273 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: null, size: 64)
!274 = !DIDerivedType(tag: DW_TAG_member, name: "__pad5", scope: !227, file: !228, line: 95, baseType: !275, size: 64, offset: 1472)
!275 = !DIDerivedType(tag: DW_TAG_typedef, name: "size_t", file: !276, line: 46, baseType: !277)
!276 = !DIFile(filename: "/usr/lib/llvm-14/lib/clang/14.0.0/include/stddef.h", directory: "", checksumkind: CSK_MD5, checksum: "2499dd2361b915724b073282bea3a7bc")
!277 = !DIBasicType(name: "unsigned long", size: 64, encoding: DW_ATE_unsigned)
!278 = !DIDerivedType(tag: DW_TAG_member, name: "_mode", scope: !227, file: !228, line: 96, baseType: !32, size: 32, offset: 1536)
!279 = !DIDerivedType(tag: DW_TAG_member, name: "_unused2", scope: !227, file: !228, line: 98, baseType: !280, size: 160, offset: 1568)
!280 = !DICompositeType(tag: DW_TAG_array_type, baseType: !233, size: 160, elements: !281)
!281 = !{!282}
!282 = !DISubrange(count: 20)
!283 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !284, size: 64)
!284 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !233)
!285 = !DILocalVariable(name: "stream", arg: 1, scope: !221, file: !28, line: 13, type: !224)
!286 = !DILocation(line: 0, scope: !221)
!287 = !DILocalVariable(name: "format", arg: 2, scope: !221, file: !28, line: 13, type: !283)
!288 = !DILocalVariable(name: "buffer", scope: !221, file: !28, line: 15, type: !289)
!289 = !DICompositeType(tag: DW_TAG_array_type, baseType: !233, size: 6144, elements: !290)
!290 = !{!291}
!291 = !DISubrange(count: 768)
!292 = !DILocation(line: 15, column: 10, scope: !221)
!293 = !DILocalVariable(name: "args", scope: !221, file: !28, line: 16, type: !294)
!294 = !DIDerivedType(tag: DW_TAG_typedef, name: "va_list", file: !295, line: 52, baseType: !296)
!295 = !DIFile(filename: "/usr/include/stdio.h", directory: "", checksumkind: CSK_MD5, checksum: "f31eefcc3f15835fc5a4023a625cf609")
!296 = !DIDerivedType(tag: DW_TAG_typedef, name: "__gnuc_va_list", file: !297, line: 32, baseType: !298)
!297 = !DIFile(filename: "/usr/lib/llvm-14/lib/clang/14.0.0/include/stdarg.h", directory: "", checksumkind: CSK_MD5, checksum: "4de3cbd931b589d291e5c39387aecf82")
!298 = !DIDerivedType(tag: DW_TAG_typedef, name: "__builtin_va_list", file: !299, baseType: !300)
!299 = !DIFile(filename: "source/workload.c", directory: "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/triangular-20260929/suite/floyd-warshall")
!300 = !DICompositeType(tag: DW_TAG_array_type, baseType: !301, size: 192, elements: !20)
!301 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "__va_list_tag", size: 192, elements: !302)
!302 = !{!303, !304, !305, !306}
!303 = !DIDerivedType(tag: DW_TAG_member, name: "gp_offset", scope: !301, file: !299, line: 16, baseType: !5, size: 32)
!304 = !DIDerivedType(tag: DW_TAG_member, name: "fp_offset", scope: !301, file: !299, line: 16, baseType: !5, size: 32, offset: 32)
!305 = !DIDerivedType(tag: DW_TAG_member, name: "overflow_arg_area", scope: !301, file: !299, line: 16, baseType: !273, size: 64, offset: 64)
!306 = !DIDerivedType(tag: DW_TAG_member, name: "reg_save_area", scope: !301, file: !299, line: 16, baseType: !273, size: 64, offset: 128)
!307 = !DILocation(line: 16, column: 13, scope: !221)
!308 = !DILocation(line: 17, column: 5, scope: !221)
!309 = !DILocation(line: 18, column: 27, scope: !221)
!310 = !DILocation(line: 18, column: 59, scope: !221)
!311 = !DILocation(line: 18, column: 17, scope: !221)
!312 = !DILocalVariable(name: "count", scope: !221, file: !28, line: 18, type: !32)
!313 = !DILocation(line: 19, column: 5, scope: !221)
!314 = !DILocation(line: 20, column: 15, scope: !315)
!315 = distinct !DILexicalBlock(scope: !221, file: !28, line: 20, column: 9)
!316 = !DILocation(line: 20, column: 19, scope: !315)
!317 = !DILocation(line: 20, column: 22, scope: !315)
!318 = !DILocation(line: 20, column: 38, scope: !315)
!319 = !DILocation(line: 20, column: 9, scope: !221)
!320 = !DILocation(line: 20, column: 57, scope: !315)
!321 = !DILocalVariable(name: "i", scope: !322, file: !28, line: 21, type: !32)
!322 = distinct !DILexicalBlock(scope: !221, file: !28, line: 21, column: 5)
!323 = !DILocation(line: 0, scope: !322)
!324 = !DILocation(line: 21, column: 10, scope: !322)
!325 = !DILocation(line: 21, column: 23, scope: !326)
!326 = distinct !DILexicalBlock(scope: !322, file: !28, line: 21, column: 5)
!327 = !DILocation(line: 21, column: 5, scope: !322)
!328 = !DILocation(line: 22, column: 35, scope: !329)
!329 = distinct !DILexicalBlock(scope: !326, file: !28, line: 21, column: 37)
!330 = !DILocation(line: 22, column: 20, scope: !329)
!331 = !DILocation(line: 22, column: 17, scope: !329)
!332 = !DILocation(line: 23, column: 17, scope: !329)
!333 = !DILocation(line: 24, column: 5, scope: !329)
!334 = !DILocation(line: 21, column: 32, scope: !326)
!335 = !DILocation(line: 21, column: 5, scope: !326)
!336 = distinct !{!336, !327, !337, !108}
!337 = !DILocation(line: 24, column: 5, scope: !322)
!338 = !DILocation(line: 29, column: 11, scope: !221)
!339 = !DILocation(line: 31, column: 5, scope: !221)
