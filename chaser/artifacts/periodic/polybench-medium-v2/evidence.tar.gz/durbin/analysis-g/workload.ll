; ModuleID = '/workspace/experiments-array-support/chaser/.cache/periodic-polybench/triangular-20260929/suite/durbin/source/workload.c'
source_filename = "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/triangular-20260929/suite/durbin/source/workload.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

%struct._IO_FILE = type { i32, i8*, i8*, i8*, i8*, i8*, i8*, i8*, i8*, i8*, i8*, i8*, %struct._IO_marker*, %struct._IO_FILE*, i32, i32, i64, i16, i8, [1 x i8], i8*, i64, %struct._IO_codecvt*, %struct._IO_wide_data*, %struct._IO_FILE*, i8*, i64, i32, [20 x i8] }
%struct._IO_marker = type opaque
%struct._IO_codecvt = type opaque
%struct._IO_wide_data = type opaque
%struct.__va_list_tag = type { i32, i32, i8*, i8* }

@n = dso_local global i32 400, align 4, !dbg !0
@r = dso_local global [400 x double] zeroinitializer, section ".chaser_data.r", align 64, !dbg !29
@y = dso_local global [400 x double] zeroinitializer, section ".chaser_data.y", align 64, !dbg !35
@z = dso_local global [400 x double] zeroinitializer, section ".chaser_data.z", align 64, !dbg !37
@.str = private unnamed_addr constant [12 x i8] c"ape.analyze\00", section "llvm.metadata"
@.str.1 = private unnamed_addr constant [121 x i8] c"/workspace/experiments-array-support/chaser/.cache/periodic-polybench/triangular-20260929/suite/durbin/source/workload.c\00", section "llvm.metadata"
@pb_hash = internal global i32 0, align 4, !dbg !26
@workload_jobs = dso_local constant [1 x i32 ()*] [i32 ()* @task_job_polybench], align 8, !dbg !8
@workload_expected = dso_local constant [1 x i32] [i32 -1040675123], align 4, !dbg !22
@stderr = external global %struct._IO_FILE*, align 8
@.str.2 = private unnamed_addr constant [23 x i8] c"==BEGIN DUMP_ARRAYS==\0A\00", align 1
@.str.3 = private unnamed_addr constant [15 x i8] c"begin dump: %s\00", align 1
@.str.4 = private unnamed_addr constant [2 x i8] c"y\00", align 1
@.str.5 = private unnamed_addr constant [2 x i8] c"\0A\00", align 1
@.str.6 = private unnamed_addr constant [8 x i8] c"%0.2lf \00", align 1
@.str.7 = private unnamed_addr constant [17 x i8] c"\0Aend   dump: %s\0A\00", align 1
@.str.8 = private unnamed_addr constant [23 x i8] c"==END   DUMP_ARRAYS==\0A\00", align 1
@pb_emit = internal global i32 1, align 4, !dbg !39
@llvm.global.annotations = appending global [1 x { i8*, i8*, i8*, i32, i8* }] [{ i8*, i8*, i8*, i32, i8* } { i8* bitcast (i32 ()* @task_job_polybench to i8*), i8* getelementptr inbounds ([12 x i8], [12 x i8]* @.str, i32 0, i32 0), i8* getelementptr inbounds ([121 x i8], [121 x i8]* @.str.1, i32 0, i32 0), i32 120, i8* null }], section "llvm.metadata"

; Function Attrs: noinline nounwind uwtable
define dso_local void @workload_prepare() #0 !dbg !50 {
  ret void, !dbg !54
}

; Function Attrs: noinline nounwind uwtable
define dso_local void @workload_reset(i32 noundef %0) #0 !dbg !55 {
  %2 = alloca i32, align 4
  store i32 %0, i32* %2, align 4
  call void @llvm.dbg.declare(metadata i32* %2, metadata !58, metadata !DIExpression()), !dbg !59
  %3 = load i32, i32* %2, align 4, !dbg !60
  call void @llvm.memset.p0i8.i64(i8* align 64 bitcast ([400 x double]* @r to i8*), i8 0, i64 3200, i1 false), !dbg !61
  call void @llvm.memset.p0i8.i64(i8* align 64 bitcast ([400 x double]* @y to i8*), i8 0, i64 3200, i1 false), !dbg !62
  call void @llvm.memset.p0i8.i64(i8* align 64 bitcast ([400 x double]* @z to i8*), i8 0, i64 3200, i1 false), !dbg !63
  %4 = load i32, i32* @n, align 4, !dbg !64
  call void @init_array(i32 noundef %4, double* noundef getelementptr inbounds ([400 x double], [400 x double]* @r, i64 0, i64 0)), !dbg !65
  ret void, !dbg !66
}

; Function Attrs: nofree nosync nounwind readnone speculatable willreturn
declare void @llvm.dbg.declare(metadata, metadata, metadata) #1

; Function Attrs: argmemonly nofree nounwind willreturn writeonly
declare void @llvm.memset.p0i8.i64(i8* nocapture writeonly, i8, i64, i1 immarg) #2

; Function Attrs: noinline nounwind uwtable
define internal void @init_array(i32 noundef %0, double* noundef %1) #0 !dbg !67 {
  %3 = alloca i32, align 4
  %4 = alloca double*, align 8
  %5 = alloca i32, align 4
  %6 = alloca i32, align 4
  store i32 %0, i32* %3, align 4
  call void @llvm.dbg.declare(metadata i32* %3, metadata !71, metadata !DIExpression()), !dbg !72
  store double* %1, double** %4, align 8
  call void @llvm.dbg.declare(metadata double** %4, metadata !73, metadata !DIExpression()), !dbg !74
  call void @llvm.dbg.declare(metadata i32* %5, metadata !75, metadata !DIExpression()), !dbg !76
  call void @llvm.dbg.declare(metadata i32* %6, metadata !77, metadata !DIExpression()), !dbg !78
  store i32 0, i32* %5, align 4, !dbg !79
  br label %7, !dbg !81

7:                                                ; preds = %21, %2
  %8 = load i32, i32* %5, align 4, !dbg !82
  %9 = load i32, i32* %3, align 4, !dbg !84
  %10 = icmp slt i32 %8, %9, !dbg !85
  br i1 %10, label %11, label %24, !dbg !86

11:                                               ; preds = %7
  %12 = load i32, i32* %3, align 4, !dbg !87
  %13 = add nsw i32 %12, 1, !dbg !89
  %14 = load i32, i32* %5, align 4, !dbg !90
  %15 = sub nsw i32 %13, %14, !dbg !91
  %16 = sitofp i32 %15 to double, !dbg !92
  %17 = load double*, double** %4, align 8, !dbg !93
  %18 = load i32, i32* %5, align 4, !dbg !94
  %19 = sext i32 %18 to i64, !dbg !93
  %20 = getelementptr inbounds double, double* %17, i64 %19, !dbg !93
  store double %16, double* %20, align 8, !dbg !95
  br label %21, !dbg !96

21:                                               ; preds = %11
  %22 = load i32, i32* %5, align 4, !dbg !97
  %23 = add nsw i32 %22, 1, !dbg !97
  store i32 %23, i32* %5, align 4, !dbg !97
  br label %7, !dbg !98, !llvm.loop !99

24:                                               ; preds = %7
  ret void, !dbg !102
}

; Function Attrs: noinline nounwind uwtable
define dso_local i32 @task_job_polybench() #0 !dbg !103 {
  %1 = alloca i32, align 4
  %2 = alloca double*, align 8
  %3 = alloca double*, align 8
  %4 = alloca double, align 8
  %5 = alloca double, align 8
  %6 = alloca double, align 8
  %7 = alloca i32, align 4
  %8 = alloca i32, align 4
  %9 = load i32, i32* @n, align 4, !dbg !104
  store i32 %9, i32* %1, align 4
  call void @llvm.dbg.declare(metadata i32* %1, metadata !105, metadata !DIExpression()), !dbg !109
  store double* getelementptr inbounds ([400 x double], [400 x double]* @r, i64 0, i64 0), double** %2, align 8
  call void @llvm.dbg.declare(metadata double** %2, metadata !111, metadata !DIExpression()), !dbg !112
  store double* getelementptr inbounds ([400 x double], [400 x double]* @y, i64 0, i64 0), double** %3, align 8
  call void @llvm.dbg.declare(metadata double** %3, metadata !113, metadata !DIExpression()), !dbg !114
  call void @llvm.dbg.declare(metadata double* %4, metadata !115, metadata !DIExpression()), !dbg !116
  call void @llvm.dbg.declare(metadata double* %5, metadata !117, metadata !DIExpression()), !dbg !118
  call void @llvm.dbg.declare(metadata double* %6, metadata !119, metadata !DIExpression()), !dbg !120
  call void @llvm.dbg.declare(metadata i32* %7, metadata !121, metadata !DIExpression()), !dbg !122
  call void @llvm.dbg.declare(metadata i32* %8, metadata !123, metadata !DIExpression()), !dbg !124
  %10 = load double*, double** %2, align 8, !dbg !125
  %11 = load double, double* %10, align 8, !dbg !125
  %12 = fneg double %11, !dbg !126
  %13 = load double*, double** %3, align 8, !dbg !127
  store double %12, double* %13, align 8, !dbg !128
  store double 1.000000e+00, double* %5, align 8, !dbg !129
  %14 = load double*, double** %2, align 8, !dbg !130
  %15 = load double, double* %14, align 8, !dbg !130
  %16 = fneg double %15, !dbg !131
  store double %16, double* %4, align 8, !dbg !132
  store i32 1, i32* %8, align 4, !dbg !133
  br label %17, !dbg !135

17:                                               ; preds = %103, %0
  %18 = load i32, i32* %8, align 4, !dbg !136
  %19 = icmp slt i32 %18, 400, !dbg !138
  br i1 %19, label %20, label %111, !dbg !139

20:                                               ; preds = %17
  %21 = load double, double* %4, align 8, !dbg !140
  %22 = load double, double* %4, align 8, !dbg !142
  %23 = fmul double %21, %22, !dbg !143
  %24 = fsub double 1.000000e+00, %23, !dbg !144
  %25 = load double, double* %5, align 8, !dbg !145
  %26 = fmul double %24, %25, !dbg !146
  store double %26, double* %5, align 8, !dbg !147
  store double 0.000000e+00, double* %6, align 8, !dbg !148
  store i32 0, i32* %7, align 4, !dbg !149
  br label %27, !dbg !151

27:                                               ; preds = %31, %20
  %28 = load i32, i32* %7, align 4, !dbg !152
  %29 = load i32, i32* %8, align 4, !dbg !154
  %30 = icmp slt i32 %28, %29, !dbg !155
  br i1 %30, label %31, label %50, !dbg !156

31:                                               ; preds = %27
  %32 = load double*, double** %2, align 8, !dbg !157
  %33 = load i32, i32* %8, align 4, !dbg !159
  %34 = load i32, i32* %7, align 4, !dbg !160
  %35 = sub nsw i32 %33, %34, !dbg !161
  %36 = sub nsw i32 %35, 1, !dbg !162
  %37 = sext i32 %36 to i64, !dbg !157
  %38 = getelementptr inbounds double, double* %32, i64 %37, !dbg !157
  %39 = load double, double* %38, align 8, !dbg !157
  %40 = load double*, double** %3, align 8, !dbg !163
  %41 = load i32, i32* %7, align 4, !dbg !164
  %42 = sext i32 %41 to i64, !dbg !163
  %43 = getelementptr inbounds double, double* %40, i64 %42, !dbg !163
  %44 = load double, double* %43, align 8, !dbg !163
  %45 = fmul double %39, %44, !dbg !165
  %46 = load double, double* %6, align 8, !dbg !166
  %47 = fadd double %46, %45, !dbg !166
  store double %47, double* %6, align 8, !dbg !166
  %48 = load i32, i32* %7, align 4, !dbg !167
  %49 = add nsw i32 %48, 1, !dbg !167
  store i32 %49, i32* %7, align 4, !dbg !167
  br label %27, !dbg !168, !llvm.loop !169

50:                                               ; preds = %27
  %51 = load double*, double** %2, align 8, !dbg !171
  %52 = load i32, i32* %8, align 4, !dbg !172
  %53 = sext i32 %52 to i64, !dbg !171
  %54 = getelementptr inbounds double, double* %51, i64 %53, !dbg !171
  %55 = load double, double* %54, align 8, !dbg !171
  %56 = load double, double* %6, align 8, !dbg !173
  %57 = fadd double %55, %56, !dbg !174
  %58 = fneg double %57, !dbg !175
  %59 = load double, double* %5, align 8, !dbg !176
  %60 = fdiv double %58, %59, !dbg !177
  store double %60, double* %4, align 8, !dbg !178
  store i32 0, i32* %7, align 4, !dbg !179
  br label %61, !dbg !181

61:                                               ; preds = %65, %50
  %62 = load i32, i32* %7, align 4, !dbg !182
  %63 = load i32, i32* %8, align 4, !dbg !184
  %64 = icmp slt i32 %62, %63, !dbg !185
  br i1 %64, label %65, label %87, !dbg !186

65:                                               ; preds = %61
  %66 = load double*, double** %3, align 8, !dbg !187
  %67 = load i32, i32* %7, align 4, !dbg !189
  %68 = sext i32 %67 to i64, !dbg !187
  %69 = getelementptr inbounds double, double* %66, i64 %68, !dbg !187
  %70 = load double, double* %69, align 8, !dbg !187
  %71 = load double, double* %4, align 8, !dbg !190
  %72 = load double*, double** %3, align 8, !dbg !191
  %73 = load i32, i32* %8, align 4, !dbg !192
  %74 = load i32, i32* %7, align 4, !dbg !193
  %75 = sub nsw i32 %73, %74, !dbg !194
  %76 = sub nsw i32 %75, 1, !dbg !195
  %77 = sext i32 %76 to i64, !dbg !191
  %78 = getelementptr inbounds double, double* %72, i64 %77, !dbg !191
  %79 = load double, double* %78, align 8, !dbg !191
  %80 = fmul double %71, %79, !dbg !196
  %81 = fadd double %70, %80, !dbg !197
  %82 = load i32, i32* %7, align 4, !dbg !198
  %83 = sext i32 %82 to i64, !dbg !199
  %84 = getelementptr inbounds [400 x double], [400 x double]* @z, i64 0, i64 %83, !dbg !199
  store double %81, double* %84, align 8, !dbg !200
  %85 = load i32, i32* %7, align 4, !dbg !201
  %86 = add nsw i32 %85, 1, !dbg !201
  store i32 %86, i32* %7, align 4, !dbg !201
  br label %61, !dbg !202, !llvm.loop !203

87:                                               ; preds = %61
  store i32 0, i32* %7, align 4, !dbg !205
  br label %88, !dbg !207

88:                                               ; preds = %92, %87
  %89 = load i32, i32* %7, align 4, !dbg !208
  %90 = load i32, i32* %8, align 4, !dbg !210
  %91 = icmp slt i32 %89, %90, !dbg !211
  br i1 %91, label %92, label %103, !dbg !212

92:                                               ; preds = %88
  %93 = load i32, i32* %7, align 4, !dbg !213
  %94 = sext i32 %93 to i64, !dbg !215
  %95 = getelementptr inbounds [400 x double], [400 x double]* @z, i64 0, i64 %94, !dbg !215
  %96 = load double, double* %95, align 8, !dbg !215
  %97 = load double*, double** %3, align 8, !dbg !216
  %98 = load i32, i32* %7, align 4, !dbg !217
  %99 = sext i32 %98 to i64, !dbg !216
  %100 = getelementptr inbounds double, double* %97, i64 %99, !dbg !216
  store double %96, double* %100, align 8, !dbg !218
  %101 = load i32, i32* %7, align 4, !dbg !219
  %102 = add nsw i32 %101, 1, !dbg !219
  store i32 %102, i32* %7, align 4, !dbg !219
  br label %88, !dbg !220, !llvm.loop !221

103:                                              ; preds = %88
  %104 = load double, double* %4, align 8, !dbg !223
  %105 = load double*, double** %3, align 8, !dbg !224
  %106 = load i32, i32* %8, align 4, !dbg !225
  %107 = sext i32 %106 to i64, !dbg !224
  %108 = getelementptr inbounds double, double* %105, i64 %107, !dbg !224
  store double %104, double* %108, align 8, !dbg !226
  %109 = load i32, i32* %8, align 4, !dbg !227
  %110 = add nsw i32 %109, 1, !dbg !227
  store i32 %110, i32* %8, align 4, !dbg !227
  br label %17, !dbg !228, !llvm.loop !229

111:                                              ; preds = %17
  ret i32 0, !dbg !231
}

; Function Attrs: noinline nounwind uwtable
define dso_local i32 @workload_checksum(i32 noundef %0) #0 !dbg !232 {
  %2 = alloca i32, align 4
  store i32 %0, i32* %2, align 4
  call void @llvm.dbg.declare(metadata i32* %2, metadata !235, metadata !DIExpression()), !dbg !236
  %3 = load i32, i32* %2, align 4, !dbg !237
  store i32 -2128831035, i32* @pb_hash, align 4, !dbg !238
  %4 = load i32, i32* @n, align 4, !dbg !239
  call void @print_array(i32 noundef %4, double* noundef getelementptr inbounds ([400 x double], [400 x double]* @y, i64 0, i64 0)), !dbg !240
  %5 = load i32, i32* @pb_hash, align 4, !dbg !241
  ret i32 %5, !dbg !242
}

; Function Attrs: noinline nounwind uwtable
define internal void @print_array(i32 noundef %0, double* noundef %1) #0 !dbg !243 {
  %3 = alloca i32, align 4
  %4 = alloca double*, align 8
  %5 = alloca i32, align 4
  store i32 %0, i32* %3, align 4
  call void @llvm.dbg.declare(metadata i32* %3, metadata !244, metadata !DIExpression()), !dbg !245
  store double* %1, double** %4, align 8
  call void @llvm.dbg.declare(metadata double** %4, metadata !246, metadata !DIExpression()), !dbg !247
  call void @llvm.dbg.declare(metadata i32* %5, metadata !248, metadata !DIExpression()), !dbg !249
  %6 = load %struct._IO_FILE*, %struct._IO_FILE** @stderr, align 8, !dbg !250
  %7 = call i32 (%struct._IO_FILE*, i8*, ...) @pb_fprintf(%struct._IO_FILE* noundef %6, i8* noundef getelementptr inbounds ([23 x i8], [23 x i8]* @.str.2, i64 0, i64 0)), !dbg !250
  %8 = load %struct._IO_FILE*, %struct._IO_FILE** @stderr, align 8, !dbg !251
  %9 = call i32 (%struct._IO_FILE*, i8*, ...) @pb_fprintf(%struct._IO_FILE* noundef %8, i8* noundef getelementptr inbounds ([15 x i8], [15 x i8]* @.str.3, i64 0, i64 0), i8* noundef getelementptr inbounds ([2 x i8], [2 x i8]* @.str.4, i64 0, i64 0)), !dbg !251
  store i32 0, i32* %5, align 4, !dbg !252
  br label %10, !dbg !254

10:                                               ; preds = %29, %2
  %11 = load i32, i32* %5, align 4, !dbg !255
  %12 = load i32, i32* %3, align 4, !dbg !257
  %13 = icmp slt i32 %11, %12, !dbg !258
  br i1 %13, label %14, label %32, !dbg !259

14:                                               ; preds = %10
  %15 = load i32, i32* %5, align 4, !dbg !260
  %16 = srem i32 %15, 20, !dbg !263
  %17 = icmp eq i32 %16, 0, !dbg !264
  br i1 %17, label %18, label %21, !dbg !265

18:                                               ; preds = %14
  %19 = load %struct._IO_FILE*, %struct._IO_FILE** @stderr, align 8, !dbg !266
  %20 = call i32 (%struct._IO_FILE*, i8*, ...) @pb_fprintf(%struct._IO_FILE* noundef %19, i8* noundef getelementptr inbounds ([2 x i8], [2 x i8]* @.str.5, i64 0, i64 0)), !dbg !267
  br label %21, !dbg !267

21:                                               ; preds = %18, %14
  %22 = load %struct._IO_FILE*, %struct._IO_FILE** @stderr, align 8, !dbg !268
  %23 = load double*, double** %4, align 8, !dbg !269
  %24 = load i32, i32* %5, align 4, !dbg !270
  %25 = sext i32 %24 to i64, !dbg !269
  %26 = getelementptr inbounds double, double* %23, i64 %25, !dbg !269
  %27 = load double, double* %26, align 8, !dbg !269
  %28 = call i32 (%struct._IO_FILE*, i8*, ...) @pb_fprintf(%struct._IO_FILE* noundef %22, i8* noundef getelementptr inbounds ([8 x i8], [8 x i8]* @.str.6, i64 0, i64 0), double noundef %27), !dbg !271
  br label %29, !dbg !272

29:                                               ; preds = %21
  %30 = load i32, i32* %5, align 4, !dbg !273
  %31 = add nsw i32 %30, 1, !dbg !273
  store i32 %31, i32* %5, align 4, !dbg !273
  br label %10, !dbg !274, !llvm.loop !275

32:                                               ; preds = %10
  %33 = load %struct._IO_FILE*, %struct._IO_FILE** @stderr, align 8, !dbg !277
  %34 = call i32 (%struct._IO_FILE*, i8*, ...) @pb_fprintf(%struct._IO_FILE* noundef %33, i8* noundef getelementptr inbounds ([17 x i8], [17 x i8]* @.str.7, i64 0, i64 0), i8* noundef getelementptr inbounds ([2 x i8], [2 x i8]* @.str.4, i64 0, i64 0)), !dbg !277
  %35 = load %struct._IO_FILE*, %struct._IO_FILE** @stderr, align 8, !dbg !278
  %36 = call i32 (%struct._IO_FILE*, i8*, ...) @pb_fprintf(%struct._IO_FILE* noundef %35, i8* noundef getelementptr inbounds ([23 x i8], [23 x i8]* @.str.8, i64 0, i64 0)), !dbg !278
  ret void, !dbg !279
}

; Function Attrs: noinline nounwind uwtable
define internal i32 @pb_fprintf(%struct._IO_FILE* noundef %0, i8* noundef %1, ...) #0 !dbg !280 {
  %3 = alloca %struct._IO_FILE*, align 8
  %4 = alloca i8*, align 8
  %5 = alloca [768 x i8], align 16
  %6 = alloca [1 x %struct.__va_list_tag], align 16
  %7 = alloca i32, align 4
  %8 = alloca i32, align 4
  store %struct._IO_FILE* %0, %struct._IO_FILE** %3, align 8
  call void @llvm.dbg.declare(metadata %struct._IO_FILE** %3, metadata !344, metadata !DIExpression()), !dbg !345
  store i8* %1, i8** %4, align 8
  call void @llvm.dbg.declare(metadata i8** %4, metadata !346, metadata !DIExpression()), !dbg !347
  call void @llvm.dbg.declare(metadata [768 x i8]* %5, metadata !348, metadata !DIExpression()), !dbg !352
  call void @llvm.dbg.declare(metadata [1 x %struct.__va_list_tag]* %6, metadata !353, metadata !DIExpression()), !dbg !367
  %9 = getelementptr inbounds [1 x %struct.__va_list_tag], [1 x %struct.__va_list_tag]* %6, i64 0, i64 0, !dbg !368
  %10 = bitcast %struct.__va_list_tag* %9 to i8*, !dbg !368
  call void @llvm.va_start(i8* %10), !dbg !368
  call void @llvm.dbg.declare(metadata i32* %7, metadata !369, metadata !DIExpression()), !dbg !370
  %11 = getelementptr inbounds [768 x i8], [768 x i8]* %5, i64 0, i64 0, !dbg !371
  %12 = load i8*, i8** %4, align 8, !dbg !372
  %13 = getelementptr inbounds [1 x %struct.__va_list_tag], [1 x %struct.__va_list_tag]* %6, i64 0, i64 0, !dbg !373
  %14 = call i32 @vsnprintf(i8* noundef %11, i64 noundef 768, i8* noundef %12, %struct.__va_list_tag* noundef %13) #6, !dbg !374
  store i32 %14, i32* %7, align 4, !dbg !370
  %15 = getelementptr inbounds [1 x %struct.__va_list_tag], [1 x %struct.__va_list_tag]* %6, i64 0, i64 0, !dbg !375
  %16 = bitcast %struct.__va_list_tag* %15 to i8*, !dbg !375
  call void @llvm.va_end(i8* %16), !dbg !375
  %17 = load i32, i32* %7, align 4, !dbg !376
  %18 = icmp slt i32 %17, 0, !dbg !378
  br i1 %18, label %23, label %19, !dbg !379

19:                                               ; preds = %2
  %20 = load i32, i32* %7, align 4, !dbg !380
  %21 = zext i32 %20 to i64, !dbg !381
  %22 = icmp uge i64 %21, 768, !dbg !382
  br i1 %22, label %23, label %24, !dbg !383

23:                                               ; preds = %19, %2
  call void @abort() #7, !dbg !384
  unreachable, !dbg !384

24:                                               ; preds = %19
  call void @llvm.dbg.declare(metadata i32* %8, metadata !385, metadata !DIExpression()), !dbg !387
  store i32 0, i32* %8, align 4, !dbg !387
  br label %25, !dbg !388

25:                                               ; preds = %39, %24
  %26 = load i32, i32* %8, align 4, !dbg !389
  %27 = load i32, i32* %7, align 4, !dbg !391
  %28 = icmp slt i32 %26, %27, !dbg !392
  br i1 %28, label %29, label %42, !dbg !393

29:                                               ; preds = %25
  %30 = load i32, i32* %8, align 4, !dbg !394
  %31 = sext i32 %30 to i64, !dbg !396
  %32 = getelementptr inbounds [768 x i8], [768 x i8]* %5, i64 0, i64 %31, !dbg !396
  %33 = load i8, i8* %32, align 1, !dbg !396
  %34 = zext i8 %33 to i32, !dbg !397
  %35 = load i32, i32* @pb_hash, align 4, !dbg !398
  %36 = xor i32 %35, %34, !dbg !398
  store i32 %36, i32* @pb_hash, align 4, !dbg !398
  %37 = load i32, i32* @pb_hash, align 4, !dbg !399
  %38 = mul i32 %37, 16777619, !dbg !399
  store i32 %38, i32* @pb_hash, align 4, !dbg !399
  br label %39, !dbg !400

39:                                               ; preds = %29
  %40 = load i32, i32* %8, align 4, !dbg !401
  %41 = add nsw i32 %40, 1, !dbg !401
  store i32 %41, i32* %8, align 4, !dbg !401
  br label %25, !dbg !402, !llvm.loop !403

42:                                               ; preds = %25
  %43 = load %struct._IO_FILE*, %struct._IO_FILE** %3, align 8, !dbg !405
  %44 = load i32, i32* @pb_emit, align 4, !dbg !406
  %45 = load i32, i32* %7, align 4, !dbg !407
  ret i32 %45, !dbg !408
}

; Function Attrs: nofree nosync nounwind willreturn
declare void @llvm.va_start(i8*) #3

; Function Attrs: nounwind
declare i32 @vsnprintf(i8* noundef, i64 noundef, i8* noundef, %struct.__va_list_tag* noundef) #4

; Function Attrs: nofree nosync nounwind willreturn
declare void @llvm.va_end(i8*) #3

; Function Attrs: noreturn nounwind
declare void @abort() #5

attributes #0 = { noinline nounwind uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { nofree nosync nounwind readnone speculatable willreturn }
attributes #2 = { argmemonly nofree nounwind willreturn writeonly }
attributes #3 = { nofree nosync nounwind willreturn }
attributes #4 = { nounwind "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #5 = { noreturn nounwind "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #6 = { nounwind }
attributes #7 = { noreturn nounwind }

!llvm.dbg.cu = !{!2}
!llvm.module.flags = !{!42, !43, !44, !45, !46, !47, !48}
!llvm.ident = !{!49}

!0 = !DIGlobalVariableExpression(var: !1, expr: !DIExpression())
!1 = distinct !DIGlobalVariable(name: "n", scope: !2, file: !10, line: 111, type: !41, isLocal: false, isDefinition: true)
!2 = distinct !DICompileUnit(language: DW_LANG_C99, file: !3, producer: "Ubuntu clang version 14.0.0-1ubuntu1.1", isOptimized: false, runtimeVersion: 0, emissionKind: FullDebug, retainedTypes: !4, globals: !7, splitDebugInlining: false, nameTableKind: None)
!3 = !DIFile(filename: "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/triangular-20260929/suite/durbin/source/workload.c", directory: "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/triangular-20260929/suite/durbin/analysis-g", checksumkind: CSK_MD5, checksum: "70112e389066249fa1577d58e2d004e2")
!4 = !{!5, !6}
!5 = !DIBasicType(name: "unsigned int", size: 32, encoding: DW_ATE_unsigned)
!6 = !DIBasicType(name: "unsigned char", size: 8, encoding: DW_ATE_unsigned_char)
!7 = !{!0, !8, !22, !26, !29, !35, !37, !39}
!8 = !DIGlobalVariableExpression(var: !9, expr: !DIExpression())
!9 = distinct !DIGlobalVariable(name: "workload_jobs", scope: !2, file: !10, line: 132, type: !11, isLocal: false, isDefinition: true)
!10 = !DIFile(filename: "source/workload.c", directory: "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/triangular-20260929/suite/durbin", checksumkind: CSK_MD5, checksum: "70112e389066249fa1577d58e2d004e2")
!11 = !DICompositeType(tag: DW_TAG_array_type, baseType: !12, size: 64, elements: !20)
!12 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !13)
!13 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !14, size: 64)
!14 = !DISubroutineType(types: !15)
!15 = !{!16}
!16 = !DIDerivedType(tag: DW_TAG_typedef, name: "uint32_t", file: !17, line: 26, baseType: !18)
!17 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/stdint-uintn.h", directory: "", checksumkind: CSK_MD5, checksum: "2bf2ae53c58c01b1a1b9383b5195125c")
!18 = !DIDerivedType(tag: DW_TAG_typedef, name: "__uint32_t", file: !19, line: 42, baseType: !5)
!19 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/types.h", directory: "", checksumkind: CSK_MD5, checksum: "d108b5f93a74c50510d7d9bc0ab36df9")
!20 = !{!21}
!21 = !DISubrange(count: 1)
!22 = !DIGlobalVariableExpression(var: !23, expr: !DIExpression())
!23 = distinct !DIGlobalVariable(name: "workload_expected", scope: !2, file: !10, line: 136, type: !24, isLocal: false, isDefinition: true)
!24 = !DICompositeType(tag: DW_TAG_array_type, baseType: !25, size: 32, elements: !20)
!25 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !16)
!26 = !DIGlobalVariableExpression(var: !27, expr: !DIExpression())
!27 = distinct !DIGlobalVariable(name: "pb_hash", scope: !2, file: !28, line: 9, type: !16, isLocal: true, isDefinition: true)
!28 = !DIFile(filename: "source/adapter.h", directory: "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/triangular-20260929/suite/durbin", checksumkind: CSK_MD5, checksum: "26a6068928b2092758f244a9d00163d7")
!29 = !DIGlobalVariableExpression(var: !30, expr: !DIExpression())
!30 = distinct !DIGlobalVariable(name: "r", scope: !2, file: !10, line: 34, type: !31, isLocal: false, isDefinition: true, align: 512)
!31 = !DICompositeType(tag: DW_TAG_array_type, baseType: !32, size: 25600, elements: !33)
!32 = !DIBasicType(name: "double", size: 64, encoding: DW_ATE_float)
!33 = !{!34}
!34 = !DISubrange(count: 400)
!35 = !DIGlobalVariableExpression(var: !36, expr: !DIExpression())
!36 = distinct !DIGlobalVariable(name: "y", scope: !2, file: !10, line: 35, type: !31, isLocal: false, isDefinition: true, align: 512)
!37 = !DIGlobalVariableExpression(var: !38, expr: !DIExpression())
!38 = distinct !DIGlobalVariable(name: "z", scope: !2, file: !10, line: 36, type: !31, isLocal: false, isDefinition: true, align: 512)
!39 = !DIGlobalVariableExpression(var: !40, expr: !DIExpression())
!40 = distinct !DIGlobalVariable(name: "pb_emit", scope: !2, file: !28, line: 10, type: !41, isLocal: true, isDefinition: true)
!41 = !DIBasicType(name: "int", size: 32, encoding: DW_ATE_signed)
!42 = !{i32 7, !"Dwarf Version", i32 5}
!43 = !{i32 2, !"Debug Info Version", i32 3}
!44 = !{i32 1, !"wchar_size", i32 4}
!45 = !{i32 7, !"PIC Level", i32 2}
!46 = !{i32 7, !"PIE Level", i32 2}
!47 = !{i32 7, !"uwtable", i32 1}
!48 = !{i32 7, !"frame-pointer", i32 2}
!49 = !{!"Ubuntu clang version 14.0.0-1ubuntu1.1"}
!50 = distinct !DISubprogram(name: "workload_prepare", scope: !10, file: !10, line: 112, type: !51, scopeLine: 112, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !2, retainedNodes: !53)
!51 = !DISubroutineType(types: !52)
!52 = !{null}
!53 = !{}
!54 = !DILocation(line: 112, column: 30, scope: !50)
!55 = distinct !DISubprogram(name: "workload_reset", scope: !10, file: !10, line: 113, type: !56, scopeLine: 113, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !2, retainedNodes: !53)
!56 = !DISubroutineType(types: !57)
!57 = !{null, !5}
!58 = !DILocalVariable(name: "task", arg: 1, scope: !55, file: !10, line: 113, type: !5)
!59 = !DILocation(line: 113, column: 30, scope: !55)
!60 = !DILocation(line: 114, column: 9, scope: !55)
!61 = !DILocation(line: 115, column: 3, scope: !55)
!62 = !DILocation(line: 116, column: 3, scope: !55)
!63 = !DILocation(line: 117, column: 3, scope: !55)
!64 = !DILocation(line: 118, column: 15, scope: !55)
!65 = !DILocation(line: 118, column: 3, scope: !55)
!66 = !DILocation(line: 119, column: 1, scope: !55)
!67 = distinct !DISubprogram(name: "init_array", scope: !10, file: !10, line: 38, type: !68, scopeLine: 40, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition, unit: !2, retainedNodes: !53)
!68 = !DISubroutineType(types: !69)
!69 = !{null, !41, !70}
!70 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !32, size: 64)
!71 = !DILocalVariable(name: "n", arg: 1, scope: !67, file: !10, line: 38, type: !41)
!72 = !DILocation(line: 38, column: 22, scope: !67)
!73 = !DILocalVariable(name: "r", arg: 2, scope: !67, file: !10, line: 39, type: !70)
!74 = !DILocation(line: 39, column: 14, scope: !67)
!75 = !DILocalVariable(name: "i", scope: !67, file: !10, line: 41, type: !41)
!76 = !DILocation(line: 41, column: 7, scope: !67)
!77 = !DILocalVariable(name: "j", scope: !67, file: !10, line: 41, type: !41)
!78 = !DILocation(line: 41, column: 10, scope: !67)
!79 = !DILocation(line: 43, column: 10, scope: !80)
!80 = distinct !DILexicalBlock(scope: !67, file: !10, line: 43, column: 3)
!81 = !DILocation(line: 43, column: 8, scope: !80)
!82 = !DILocation(line: 43, column: 15, scope: !83)
!83 = distinct !DILexicalBlock(scope: !80, file: !10, line: 43, column: 3)
!84 = !DILocation(line: 43, column: 19, scope: !83)
!85 = !DILocation(line: 43, column: 17, scope: !83)
!86 = !DILocation(line: 43, column: 3, scope: !80)
!87 = !DILocation(line: 45, column: 15, scope: !88)
!88 = distinct !DILexicalBlock(scope: !83, file: !10, line: 44, column: 5)
!89 = !DILocation(line: 45, column: 16, scope: !88)
!90 = !DILocation(line: 45, column: 19, scope: !88)
!91 = !DILocation(line: 45, column: 18, scope: !88)
!92 = !DILocation(line: 45, column: 14, scope: !88)
!93 = !DILocation(line: 45, column: 7, scope: !88)
!94 = !DILocation(line: 45, column: 9, scope: !88)
!95 = !DILocation(line: 45, column: 12, scope: !88)
!96 = !DILocation(line: 46, column: 5, scope: !88)
!97 = !DILocation(line: 43, column: 23, scope: !83)
!98 = !DILocation(line: 43, column: 3, scope: !83)
!99 = distinct !{!99, !86, !100, !101}
!100 = !DILocation(line: 46, column: 5, scope: !80)
!101 = !{!"llvm.loop.mustprogress"}
!102 = !DILocation(line: 47, column: 1, scope: !67)
!103 = distinct !DISubprogram(name: "task_job_polybench", scope: !10, file: !10, line: 120, type: !14, scopeLine: 120, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !2, retainedNodes: !53)
!104 = !DILocation(line: 121, column: 18, scope: !103)
!105 = !DILocalVariable(name: "n", arg: 1, scope: !106, file: !10, line: 73, type: !41)
!106 = distinct !DISubprogram(name: "kernel_durbin", scope: !10, file: !10, line: 73, type: !107, scopeLine: 76, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition, unit: !2, retainedNodes: !53)
!107 = !DISubroutineType(types: !108)
!108 = !{null, !41, !70, !70}
!109 = !DILocation(line: 73, column: 62, scope: !106, inlinedAt: !110)
!110 = distinct !DILocation(line: 121, column: 3, scope: !103)
!111 = !DILocalVariable(name: "r", arg: 2, scope: !106, file: !10, line: 74, type: !70)
!112 = !DILocation(line: 74, column: 16, scope: !106, inlinedAt: !110)
!113 = !DILocalVariable(name: "y", arg: 3, scope: !106, file: !10, line: 75, type: !70)
!114 = !DILocation(line: 75, column: 16, scope: !106, inlinedAt: !110)
!115 = !DILocalVariable(name: "alpha", scope: !106, file: !10, line: 78, type: !32)
!116 = !DILocation(line: 78, column: 12, scope: !106, inlinedAt: !110)
!117 = !DILocalVariable(name: "beta", scope: !106, file: !10, line: 79, type: !32)
!118 = !DILocation(line: 79, column: 12, scope: !106, inlinedAt: !110)
!119 = !DILocalVariable(name: "sum", scope: !106, file: !10, line: 80, type: !32)
!120 = !DILocation(line: 80, column: 12, scope: !106, inlinedAt: !110)
!121 = !DILocalVariable(name: "i", scope: !106, file: !10, line: 82, type: !41)
!122 = !DILocation(line: 82, column: 6, scope: !106, inlinedAt: !110)
!123 = !DILocalVariable(name: "k", scope: !106, file: !10, line: 82, type: !41)
!124 = !DILocation(line: 82, column: 8, scope: !106, inlinedAt: !110)
!125 = !DILocation(line: 85, column: 10, scope: !106, inlinedAt: !110)
!126 = !DILocation(line: 85, column: 9, scope: !106, inlinedAt: !110)
!127 = !DILocation(line: 85, column: 2, scope: !106, inlinedAt: !110)
!128 = !DILocation(line: 85, column: 7, scope: !106, inlinedAt: !110)
!129 = !DILocation(line: 86, column: 7, scope: !106, inlinedAt: !110)
!130 = !DILocation(line: 87, column: 11, scope: !106, inlinedAt: !110)
!131 = !DILocation(line: 87, column: 10, scope: !106, inlinedAt: !110)
!132 = !DILocation(line: 87, column: 8, scope: !106, inlinedAt: !110)
!133 = !DILocation(line: 89, column: 9, scope: !134, inlinedAt: !110)
!134 = distinct !DILexicalBlock(scope: !106, file: !10, line: 89, column: 2)
!135 = !DILocation(line: 89, column: 7, scope: !134, inlinedAt: !110)
!136 = !DILocation(line: 89, column: 14, scope: !137, inlinedAt: !110)
!137 = distinct !DILexicalBlock(scope: !134, file: !10, line: 89, column: 2)
!138 = !DILocation(line: 89, column: 16, scope: !137, inlinedAt: !110)
!139 = !DILocation(line: 89, column: 2, scope: !134, inlinedAt: !110)
!140 = !DILocation(line: 90, column: 14, scope: !141, inlinedAt: !110)
!141 = distinct !DILexicalBlock(scope: !137, file: !10, line: 89, column: 30)
!142 = !DILocation(line: 90, column: 20, scope: !141, inlinedAt: !110)
!143 = !DILocation(line: 90, column: 19, scope: !141, inlinedAt: !110)
!144 = !DILocation(line: 90, column: 13, scope: !141, inlinedAt: !110)
!145 = !DILocation(line: 90, column: 27, scope: !141, inlinedAt: !110)
!146 = !DILocation(line: 90, column: 26, scope: !141, inlinedAt: !110)
!147 = !DILocation(line: 90, column: 9, scope: !141, inlinedAt: !110)
!148 = !DILocation(line: 91, column: 8, scope: !141, inlinedAt: !110)
!149 = !DILocation(line: 92, column: 10, scope: !150, inlinedAt: !110)
!150 = distinct !DILexicalBlock(scope: !141, file: !10, line: 92, column: 4)
!151 = !DILocation(line: 92, column: 9, scope: !150, inlinedAt: !110)
!152 = !DILocation(line: 92, column: 14, scope: !153, inlinedAt: !110)
!153 = distinct !DILexicalBlock(scope: !150, file: !10, line: 92, column: 4)
!154 = !DILocation(line: 92, column: 16, scope: !153, inlinedAt: !110)
!155 = !DILocation(line: 92, column: 15, scope: !153, inlinedAt: !110)
!156 = !DILocation(line: 92, column: 4, scope: !150, inlinedAt: !110)
!157 = !DILocation(line: 93, column: 14, scope: !158, inlinedAt: !110)
!158 = distinct !DILexicalBlock(scope: !153, file: !10, line: 92, column: 24)
!159 = !DILocation(line: 93, column: 16, scope: !158, inlinedAt: !110)
!160 = !DILocation(line: 93, column: 18, scope: !158, inlinedAt: !110)
!161 = !DILocation(line: 93, column: 17, scope: !158, inlinedAt: !110)
!162 = !DILocation(line: 93, column: 19, scope: !158, inlinedAt: !110)
!163 = !DILocation(line: 93, column: 23, scope: !158, inlinedAt: !110)
!164 = !DILocation(line: 93, column: 25, scope: !158, inlinedAt: !110)
!165 = !DILocation(line: 93, column: 22, scope: !158, inlinedAt: !110)
!166 = !DILocation(line: 93, column: 11, scope: !158, inlinedAt: !110)
!167 = !DILocation(line: 92, column: 20, scope: !153, inlinedAt: !110)
!168 = !DILocation(line: 92, column: 4, scope: !153, inlinedAt: !110)
!169 = distinct !{!169, !156, !170, !101}
!170 = !DILocation(line: 94, column: 4, scope: !150, inlinedAt: !110)
!171 = !DILocation(line: 95, column: 15, scope: !141, inlinedAt: !110)
!172 = !DILocation(line: 95, column: 17, scope: !141, inlinedAt: !110)
!173 = !DILocation(line: 95, column: 22, scope: !141, inlinedAt: !110)
!174 = !DILocation(line: 95, column: 20, scope: !141, inlinedAt: !110)
!175 = !DILocation(line: 95, column: 12, scope: !141, inlinedAt: !110)
!176 = !DILocation(line: 95, column: 27, scope: !141, inlinedAt: !110)
!177 = !DILocation(line: 95, column: 26, scope: !141, inlinedAt: !110)
!178 = !DILocation(line: 95, column: 10, scope: !141, inlinedAt: !110)
!179 = !DILocation(line: 97, column: 10, scope: !180, inlinedAt: !110)
!180 = distinct !DILexicalBlock(scope: !141, file: !10, line: 97, column: 4)
!181 = !DILocation(line: 97, column: 9, scope: !180, inlinedAt: !110)
!182 = !DILocation(line: 97, column: 14, scope: !183, inlinedAt: !110)
!183 = distinct !DILexicalBlock(scope: !180, file: !10, line: 97, column: 4)
!184 = !DILocation(line: 97, column: 16, scope: !183, inlinedAt: !110)
!185 = !DILocation(line: 97, column: 15, scope: !183, inlinedAt: !110)
!186 = !DILocation(line: 97, column: 4, scope: !180, inlinedAt: !110)
!187 = !DILocation(line: 98, column: 14, scope: !188, inlinedAt: !110)
!188 = distinct !DILexicalBlock(scope: !183, file: !10, line: 97, column: 24)
!189 = !DILocation(line: 98, column: 16, scope: !188, inlinedAt: !110)
!190 = !DILocation(line: 98, column: 21, scope: !188, inlinedAt: !110)
!191 = !DILocation(line: 98, column: 27, scope: !188, inlinedAt: !110)
!192 = !DILocation(line: 98, column: 29, scope: !188, inlinedAt: !110)
!193 = !DILocation(line: 98, column: 31, scope: !188, inlinedAt: !110)
!194 = !DILocation(line: 98, column: 30, scope: !188, inlinedAt: !110)
!195 = !DILocation(line: 98, column: 32, scope: !188, inlinedAt: !110)
!196 = !DILocation(line: 98, column: 26, scope: !188, inlinedAt: !110)
!197 = !DILocation(line: 98, column: 19, scope: !188, inlinedAt: !110)
!198 = !DILocation(line: 98, column: 9, scope: !188, inlinedAt: !110)
!199 = !DILocation(line: 98, column: 7, scope: !188, inlinedAt: !110)
!200 = !DILocation(line: 98, column: 12, scope: !188, inlinedAt: !110)
!201 = !DILocation(line: 97, column: 20, scope: !183, inlinedAt: !110)
!202 = !DILocation(line: 97, column: 4, scope: !183, inlinedAt: !110)
!203 = distinct !{!203, !186, !204, !101}
!204 = !DILocation(line: 99, column: 4, scope: !180, inlinedAt: !110)
!205 = !DILocation(line: 100, column: 10, scope: !206, inlinedAt: !110)
!206 = distinct !DILexicalBlock(scope: !141, file: !10, line: 100, column: 4)
!207 = !DILocation(line: 100, column: 9, scope: !206, inlinedAt: !110)
!208 = !DILocation(line: 100, column: 14, scope: !209, inlinedAt: !110)
!209 = distinct !DILexicalBlock(scope: !206, file: !10, line: 100, column: 4)
!210 = !DILocation(line: 100, column: 16, scope: !209, inlinedAt: !110)
!211 = !DILocation(line: 100, column: 15, scope: !209, inlinedAt: !110)
!212 = !DILocation(line: 100, column: 4, scope: !206, inlinedAt: !110)
!213 = !DILocation(line: 101, column: 15, scope: !214, inlinedAt: !110)
!214 = distinct !DILexicalBlock(scope: !209, file: !10, line: 100, column: 24)
!215 = !DILocation(line: 101, column: 13, scope: !214, inlinedAt: !110)
!216 = !DILocation(line: 101, column: 6, scope: !214, inlinedAt: !110)
!217 = !DILocation(line: 101, column: 8, scope: !214, inlinedAt: !110)
!218 = !DILocation(line: 101, column: 11, scope: !214, inlinedAt: !110)
!219 = !DILocation(line: 100, column: 20, scope: !209, inlinedAt: !110)
!220 = !DILocation(line: 100, column: 4, scope: !209, inlinedAt: !110)
!221 = distinct !{!221, !212, !222, !101}
!222 = !DILocation(line: 102, column: 4, scope: !206, inlinedAt: !110)
!223 = !DILocation(line: 103, column: 11, scope: !141, inlinedAt: !110)
!224 = !DILocation(line: 103, column: 4, scope: !141, inlinedAt: !110)
!225 = !DILocation(line: 103, column: 6, scope: !141, inlinedAt: !110)
!226 = !DILocation(line: 103, column: 9, scope: !141, inlinedAt: !110)
!227 = !DILocation(line: 89, column: 26, scope: !137, inlinedAt: !110)
!228 = !DILocation(line: 89, column: 2, scope: !137, inlinedAt: !110)
!229 = distinct !{!229, !139, !230, !101}
!230 = !DILocation(line: 104, column: 2, scope: !134, inlinedAt: !110)
!231 = !DILocation(line: 124, column: 3, scope: !103)
!232 = distinct !DISubprogram(name: "workload_checksum", scope: !10, file: !10, line: 126, type: !233, scopeLine: 126, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !2, retainedNodes: !53)
!233 = !DISubroutineType(types: !234)
!234 = !{!16, !5}
!235 = !DILocalVariable(name: "task", arg: 1, scope: !232, file: !10, line: 126, type: !5)
!236 = !DILocation(line: 126, column: 37, scope: !232)
!237 = !DILocation(line: 127, column: 9, scope: !232)
!238 = !DILocation(line: 128, column: 11, scope: !232)
!239 = !DILocation(line: 129, column: 15, scope: !232)
!240 = !DILocation(line: 129, column: 3, scope: !232)
!241 = !DILocation(line: 130, column: 10, scope: !232)
!242 = !DILocation(line: 130, column: 3, scope: !232)
!243 = distinct !DISubprogram(name: "print_array", scope: !10, file: !10, line: 53, type: !68, scopeLine: 56, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition, unit: !2, retainedNodes: !53)
!244 = !DILocalVariable(name: "n", arg: 1, scope: !243, file: !10, line: 53, type: !41)
!245 = !DILocation(line: 53, column: 22, scope: !243)
!246 = !DILocalVariable(name: "y", arg: 2, scope: !243, file: !10, line: 54, type: !70)
!247 = !DILocation(line: 54, column: 14, scope: !243)
!248 = !DILocalVariable(name: "i", scope: !243, file: !10, line: 57, type: !41)
!249 = !DILocation(line: 57, column: 7, scope: !243)
!250 = !DILocation(line: 59, column: 3, scope: !243)
!251 = !DILocation(line: 60, column: 3, scope: !243)
!252 = !DILocation(line: 61, column: 10, scope: !253)
!253 = distinct !DILexicalBlock(scope: !243, file: !10, line: 61, column: 3)
!254 = !DILocation(line: 61, column: 8, scope: !253)
!255 = !DILocation(line: 61, column: 15, scope: !256)
!256 = distinct !DILexicalBlock(scope: !253, file: !10, line: 61, column: 3)
!257 = !DILocation(line: 61, column: 19, scope: !256)
!258 = !DILocation(line: 61, column: 17, scope: !256)
!259 = !DILocation(line: 61, column: 3, scope: !253)
!260 = !DILocation(line: 62, column: 9, scope: !261)
!261 = distinct !DILexicalBlock(scope: !262, file: !10, line: 62, column: 9)
!262 = distinct !DILexicalBlock(scope: !256, file: !10, line: 61, column: 27)
!263 = !DILocation(line: 62, column: 11, scope: !261)
!264 = !DILocation(line: 62, column: 16, scope: !261)
!265 = !DILocation(line: 62, column: 9, scope: !262)
!266 = !DILocation(line: 62, column: 31, scope: !261)
!267 = !DILocation(line: 62, column: 22, scope: !261)
!268 = !DILocation(line: 63, column: 14, scope: !262)
!269 = !DILocation(line: 63, column: 59, scope: !262)
!270 = !DILocation(line: 63, column: 61, scope: !262)
!271 = !DILocation(line: 63, column: 5, scope: !262)
!272 = !DILocation(line: 64, column: 3, scope: !262)
!273 = !DILocation(line: 61, column: 23, scope: !256)
!274 = !DILocation(line: 61, column: 3, scope: !256)
!275 = distinct !{!275, !259, !276, !101}
!276 = !DILocation(line: 64, column: 3, scope: !253)
!277 = !DILocation(line: 65, column: 3, scope: !243)
!278 = !DILocation(line: 66, column: 3, scope: !243)
!279 = !DILocation(line: 67, column: 1, scope: !243)
!280 = distinct !DISubprogram(name: "pb_fprintf", scope: !28, file: !28, line: 13, type: !281, scopeLine: 14, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition, unit: !2, retainedNodes: !53)
!281 = !DISubroutineType(types: !282)
!282 = !{!41, !283, !342, null}
!283 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !284, size: 64)
!284 = !DIDerivedType(tag: DW_TAG_typedef, name: "FILE", file: !285, line: 7, baseType: !286)
!285 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/types/FILE.h", directory: "", checksumkind: CSK_MD5, checksum: "571f9fb6223c42439075fdde11a0de5d")
!286 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "_IO_FILE", file: !287, line: 49, size: 1728, elements: !288)
!287 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/types/struct_FILE.h", directory: "", checksumkind: CSK_MD5, checksum: "1bad07471b7974df4ecc1d1c2ca207e6")
!288 = !{!289, !290, !293, !294, !295, !296, !297, !298, !299, !300, !301, !302, !303, !306, !308, !309, !310, !313, !315, !317, !319, !322, !324, !327, !330, !331, !333, !337, !338}
!289 = !DIDerivedType(tag: DW_TAG_member, name: "_flags", scope: !286, file: !287, line: 51, baseType: !41, size: 32)
!290 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_read_ptr", scope: !286, file: !287, line: 54, baseType: !291, size: 64, offset: 64)
!291 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !292, size: 64)
!292 = !DIBasicType(name: "char", size: 8, encoding: DW_ATE_signed_char)
!293 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_read_end", scope: !286, file: !287, line: 55, baseType: !291, size: 64, offset: 128)
!294 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_read_base", scope: !286, file: !287, line: 56, baseType: !291, size: 64, offset: 192)
!295 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_write_base", scope: !286, file: !287, line: 57, baseType: !291, size: 64, offset: 256)
!296 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_write_ptr", scope: !286, file: !287, line: 58, baseType: !291, size: 64, offset: 320)
!297 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_write_end", scope: !286, file: !287, line: 59, baseType: !291, size: 64, offset: 384)
!298 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_buf_base", scope: !286, file: !287, line: 60, baseType: !291, size: 64, offset: 448)
!299 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_buf_end", scope: !286, file: !287, line: 61, baseType: !291, size: 64, offset: 512)
!300 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_save_base", scope: !286, file: !287, line: 64, baseType: !291, size: 64, offset: 576)
!301 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_backup_base", scope: !286, file: !287, line: 65, baseType: !291, size: 64, offset: 640)
!302 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_save_end", scope: !286, file: !287, line: 66, baseType: !291, size: 64, offset: 704)
!303 = !DIDerivedType(tag: DW_TAG_member, name: "_markers", scope: !286, file: !287, line: 68, baseType: !304, size: 64, offset: 768)
!304 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !305, size: 64)
!305 = !DICompositeType(tag: DW_TAG_structure_type, name: "_IO_marker", file: !287, line: 36, flags: DIFlagFwdDecl)
!306 = !DIDerivedType(tag: DW_TAG_member, name: "_chain", scope: !286, file: !287, line: 70, baseType: !307, size: 64, offset: 832)
!307 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !286, size: 64)
!308 = !DIDerivedType(tag: DW_TAG_member, name: "_fileno", scope: !286, file: !287, line: 72, baseType: !41, size: 32, offset: 896)
!309 = !DIDerivedType(tag: DW_TAG_member, name: "_flags2", scope: !286, file: !287, line: 73, baseType: !41, size: 32, offset: 928)
!310 = !DIDerivedType(tag: DW_TAG_member, name: "_old_offset", scope: !286, file: !287, line: 74, baseType: !311, size: 64, offset: 960)
!311 = !DIDerivedType(tag: DW_TAG_typedef, name: "__off_t", file: !19, line: 152, baseType: !312)
!312 = !DIBasicType(name: "long", size: 64, encoding: DW_ATE_signed)
!313 = !DIDerivedType(tag: DW_TAG_member, name: "_cur_column", scope: !286, file: !287, line: 77, baseType: !314, size: 16, offset: 1024)
!314 = !DIBasicType(name: "unsigned short", size: 16, encoding: DW_ATE_unsigned)
!315 = !DIDerivedType(tag: DW_TAG_member, name: "_vtable_offset", scope: !286, file: !287, line: 78, baseType: !316, size: 8, offset: 1040)
!316 = !DIBasicType(name: "signed char", size: 8, encoding: DW_ATE_signed_char)
!317 = !DIDerivedType(tag: DW_TAG_member, name: "_shortbuf", scope: !286, file: !287, line: 79, baseType: !318, size: 8, offset: 1048)
!318 = !DICompositeType(tag: DW_TAG_array_type, baseType: !292, size: 8, elements: !20)
!319 = !DIDerivedType(tag: DW_TAG_member, name: "_lock", scope: !286, file: !287, line: 81, baseType: !320, size: 64, offset: 1088)
!320 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !321, size: 64)
!321 = !DIDerivedType(tag: DW_TAG_typedef, name: "_IO_lock_t", file: !287, line: 43, baseType: null)
!322 = !DIDerivedType(tag: DW_TAG_member, name: "_offset", scope: !286, file: !287, line: 89, baseType: !323, size: 64, offset: 1152)
!323 = !DIDerivedType(tag: DW_TAG_typedef, name: "__off64_t", file: !19, line: 153, baseType: !312)
!324 = !DIDerivedType(tag: DW_TAG_member, name: "_codecvt", scope: !286, file: !287, line: 91, baseType: !325, size: 64, offset: 1216)
!325 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !326, size: 64)
!326 = !DICompositeType(tag: DW_TAG_structure_type, name: "_IO_codecvt", file: !287, line: 37, flags: DIFlagFwdDecl)
!327 = !DIDerivedType(tag: DW_TAG_member, name: "_wide_data", scope: !286, file: !287, line: 92, baseType: !328, size: 64, offset: 1280)
!328 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !329, size: 64)
!329 = !DICompositeType(tag: DW_TAG_structure_type, name: "_IO_wide_data", file: !287, line: 38, flags: DIFlagFwdDecl)
!330 = !DIDerivedType(tag: DW_TAG_member, name: "_freeres_list", scope: !286, file: !287, line: 93, baseType: !307, size: 64, offset: 1344)
!331 = !DIDerivedType(tag: DW_TAG_member, name: "_freeres_buf", scope: !286, file: !287, line: 94, baseType: !332, size: 64, offset: 1408)
!332 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: null, size: 64)
!333 = !DIDerivedType(tag: DW_TAG_member, name: "__pad5", scope: !286, file: !287, line: 95, baseType: !334, size: 64, offset: 1472)
!334 = !DIDerivedType(tag: DW_TAG_typedef, name: "size_t", file: !335, line: 46, baseType: !336)
!335 = !DIFile(filename: "/usr/lib/llvm-14/lib/clang/14.0.0/include/stddef.h", directory: "", checksumkind: CSK_MD5, checksum: "2499dd2361b915724b073282bea3a7bc")
!336 = !DIBasicType(name: "unsigned long", size: 64, encoding: DW_ATE_unsigned)
!337 = !DIDerivedType(tag: DW_TAG_member, name: "_mode", scope: !286, file: !287, line: 96, baseType: !41, size: 32, offset: 1536)
!338 = !DIDerivedType(tag: DW_TAG_member, name: "_unused2", scope: !286, file: !287, line: 98, baseType: !339, size: 160, offset: 1568)
!339 = !DICompositeType(tag: DW_TAG_array_type, baseType: !292, size: 160, elements: !340)
!340 = !{!341}
!341 = !DISubrange(count: 20)
!342 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !343, size: 64)
!343 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !292)
!344 = !DILocalVariable(name: "stream", arg: 1, scope: !280, file: !28, line: 13, type: !283)
!345 = !DILocation(line: 13, column: 29, scope: !280)
!346 = !DILocalVariable(name: "format", arg: 2, scope: !280, file: !28, line: 13, type: !342)
!347 = !DILocation(line: 13, column: 49, scope: !280)
!348 = !DILocalVariable(name: "buffer", scope: !280, file: !28, line: 15, type: !349)
!349 = !DICompositeType(tag: DW_TAG_array_type, baseType: !292, size: 6144, elements: !350)
!350 = !{!351}
!351 = !DISubrange(count: 768)
!352 = !DILocation(line: 15, column: 10, scope: !280)
!353 = !DILocalVariable(name: "args", scope: !280, file: !28, line: 16, type: !354)
!354 = !DIDerivedType(tag: DW_TAG_typedef, name: "va_list", file: !355, line: 52, baseType: !356)
!355 = !DIFile(filename: "/usr/include/stdio.h", directory: "", checksumkind: CSK_MD5, checksum: "f31eefcc3f15835fc5a4023a625cf609")
!356 = !DIDerivedType(tag: DW_TAG_typedef, name: "__gnuc_va_list", file: !357, line: 32, baseType: !358)
!357 = !DIFile(filename: "/usr/lib/llvm-14/lib/clang/14.0.0/include/stdarg.h", directory: "", checksumkind: CSK_MD5, checksum: "4de3cbd931b589d291e5c39387aecf82")
!358 = !DIDerivedType(tag: DW_TAG_typedef, name: "__builtin_va_list", file: !359, baseType: !360)
!359 = !DIFile(filename: "source/workload.c", directory: "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/triangular-20260929/suite/durbin")
!360 = !DICompositeType(tag: DW_TAG_array_type, baseType: !361, size: 192, elements: !20)
!361 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "__va_list_tag", size: 192, elements: !362)
!362 = !{!363, !364, !365, !366}
!363 = !DIDerivedType(tag: DW_TAG_member, name: "gp_offset", scope: !361, file: !359, line: 16, baseType: !5, size: 32)
!364 = !DIDerivedType(tag: DW_TAG_member, name: "fp_offset", scope: !361, file: !359, line: 16, baseType: !5, size: 32, offset: 32)
!365 = !DIDerivedType(tag: DW_TAG_member, name: "overflow_arg_area", scope: !361, file: !359, line: 16, baseType: !332, size: 64, offset: 64)
!366 = !DIDerivedType(tag: DW_TAG_member, name: "reg_save_area", scope: !361, file: !359, line: 16, baseType: !332, size: 64, offset: 128)
!367 = !DILocation(line: 16, column: 13, scope: !280)
!368 = !DILocation(line: 17, column: 5, scope: !280)
!369 = !DILocalVariable(name: "count", scope: !280, file: !28, line: 18, type: !41)
!370 = !DILocation(line: 18, column: 9, scope: !280)
!371 = !DILocation(line: 18, column: 27, scope: !280)
!372 = !DILocation(line: 18, column: 51, scope: !280)
!373 = !DILocation(line: 18, column: 59, scope: !280)
!374 = !DILocation(line: 18, column: 17, scope: !280)
!375 = !DILocation(line: 19, column: 5, scope: !280)
!376 = !DILocation(line: 20, column: 9, scope: !377)
!377 = distinct !DILexicalBlock(scope: !280, file: !28, line: 20, column: 9)
!378 = !DILocation(line: 20, column: 15, scope: !377)
!379 = !DILocation(line: 20, column: 19, scope: !377)
!380 = !DILocation(line: 20, column: 32, scope: !377)
!381 = !DILocation(line: 20, column: 22, scope: !377)
!382 = !DILocation(line: 20, column: 38, scope: !377)
!383 = !DILocation(line: 20, column: 9, scope: !280)
!384 = !DILocation(line: 20, column: 57, scope: !377)
!385 = !DILocalVariable(name: "i", scope: !386, file: !28, line: 21, type: !41)
!386 = distinct !DILexicalBlock(scope: !280, file: !28, line: 21, column: 5)
!387 = !DILocation(line: 21, column: 14, scope: !386)
!388 = !DILocation(line: 21, column: 10, scope: !386)
!389 = !DILocation(line: 21, column: 21, scope: !390)
!390 = distinct !DILexicalBlock(scope: !386, file: !28, line: 21, column: 5)
!391 = !DILocation(line: 21, column: 25, scope: !390)
!392 = !DILocation(line: 21, column: 23, scope: !390)
!393 = !DILocation(line: 21, column: 5, scope: !386)
!394 = !DILocation(line: 22, column: 42, scope: !395)
!395 = distinct !DILexicalBlock(scope: !390, file: !28, line: 21, column: 37)
!396 = !DILocation(line: 22, column: 35, scope: !395)
!397 = !DILocation(line: 22, column: 20, scope: !395)
!398 = !DILocation(line: 22, column: 17, scope: !395)
!399 = !DILocation(line: 23, column: 17, scope: !395)
!400 = !DILocation(line: 24, column: 5, scope: !395)
!401 = !DILocation(line: 21, column: 32, scope: !390)
!402 = !DILocation(line: 21, column: 5, scope: !390)
!403 = distinct !{!403, !393, !404, !101}
!404 = !DILocation(line: 24, column: 5, scope: !386)
!405 = !DILocation(line: 28, column: 11, scope: !280)
!406 = !DILocation(line: 29, column: 11, scope: !280)
!407 = !DILocation(line: 31, column: 12, scope: !280)
!408 = !DILocation(line: 31, column: 5, scope: !280)
