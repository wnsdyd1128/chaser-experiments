; ModuleID = 'inlined.ll'
source_filename = "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/triangular-20260929/suite/ludcmp/source/workload.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

@n = external dso_local global i32, align 4, !dbg !0
@A = external dso_local global [400 x [400 x double]], section ".chaser_data.A", align 64, !dbg !9
@b = external dso_local global [400 x double], section ".chaser_data.b", align 64, !dbg !15
@x = external dso_local global [400 x double], section ".chaser_data.x", align 64, !dbg !19
@y = external dso_local global [400 x double], section ".chaser_data.y", align 64, !dbg !21
@.str = hidden unnamed_addr constant [12 x i8] c"ape.analyze\00", section "llvm.metadata"
@.str.1 = hidden unnamed_addr constant [121 x i8] c"/workspace/experiments-array-support/chaser/.cache/periodic-polybench/triangular-20260929/suite/ludcmp/source/workload.c\00", section "llvm.metadata"
@.str.2 = hidden unnamed_addr constant [23 x i8] c"==BEGIN DUMP_ARRAYS==\0A\00", align 1
@.str.3 = hidden unnamed_addr constant [15 x i8] c"begin dump: %s\00", align 1
@.str.4 = hidden unnamed_addr constant [2 x i8] c"x\00", align 1
@.str.5 = hidden unnamed_addr constant [2 x i8] c"\0A\00", align 1
@.str.6 = hidden unnamed_addr constant [8 x i8] c"%0.2lf \00", align 1
@.str.7 = hidden unnamed_addr constant [17 x i8] c"\0Aend   dump: %s\0A\00", align 1
@.str.8 = hidden unnamed_addr constant [23 x i8] c"==END   DUMP_ARRAYS==\0A\00", align 1
@llvm.global.annotations = appending global [1 x { i8*, i8*, i8*, i32, i8* }] [{ i8*, i8*, i8*, i32, i8* } { i8* bitcast (i32 ()* @task_job_polybench to i8*), i8* getelementptr inbounds ([12 x i8], [12 x i8]* @.str, i32 0, i32 0), i8* getelementptr inbounds ([121 x i8], [121 x i8]* @.str.1, i32 0, i32 0), i32 170, i8* null }], section "llvm.metadata"

; Function Attrs: noinline nounwind uwtable
define dso_local i32 @task_job_polybench() #0 !dbg !32 {
  %1 = load i32, i32* @n, align 4, !dbg !40
  call void @llvm.dbg.value(metadata i32 %1, metadata !41, metadata !DIExpression()), !dbg !47
  call void @llvm.dbg.value(metadata [400 x double]* getelementptr inbounds ([400 x [400 x double]], [400 x [400 x double]]* @A, i64 0, i64 0), metadata !49, metadata !DIExpression()), !dbg !47
  call void @llvm.dbg.value(metadata double* getelementptr inbounds ([400 x double], [400 x double]* @b, i64 0, i64 0), metadata !50, metadata !DIExpression()), !dbg !47
  call void @llvm.dbg.value(metadata double* getelementptr inbounds ([400 x double], [400 x double]* @x, i64 0, i64 0), metadata !51, metadata !DIExpression()), !dbg !47
  call void @llvm.dbg.value(metadata double* getelementptr inbounds ([400 x double], [400 x double]* @y, i64 0, i64 0), metadata !52, metadata !DIExpression()), !dbg !47
  call void @llvm.dbg.value(metadata i32 0, metadata !53, metadata !DIExpression()), !dbg !47
  br label %2, !dbg !54

2:                                                ; preds = %72, %0
  %.07 = phi i32 [ 0, %0 ], [ %73, %72 ], !dbg !56
  call void @llvm.dbg.value(metadata i32 %.07, metadata !53, metadata !DIExpression()), !dbg !47
  %3 = icmp slt i32 %.07, 400, !dbg !57
  br i1 %3, label %4, label %74, !dbg !59

4:                                                ; preds = %2
  call void @llvm.dbg.value(metadata i32 0, metadata !60, metadata !DIExpression()), !dbg !47
  br label %5, !dbg !61

5:                                                ; preds = %29, %4
  %.03 = phi i32 [ 0, %4 ], [ %40, %29 ], !dbg !64
  call void @llvm.dbg.value(metadata i32 %.03, metadata !60, metadata !DIExpression()), !dbg !47
  %6 = icmp slt i32 %.03, %.07, !dbg !65
  br i1 %6, label %7, label %41, !dbg !67

7:                                                ; preds = %5
  %8 = sext i32 %.07 to i64, !dbg !68
  %9 = getelementptr inbounds [400 x double], [400 x double]* getelementptr inbounds ([400 x [400 x double]], [400 x [400 x double]]* @A, i64 0, i64 0), i64 %8, !dbg !68
  %10 = sext i32 %.03 to i64, !dbg !68
  %11 = getelementptr inbounds [400 x double], [400 x double]* %9, i64 0, i64 %10, !dbg !68
  %12 = load double, double* %11, align 8, !dbg !68
  call void @llvm.dbg.value(metadata double %12, metadata !70, metadata !DIExpression()), !dbg !47
  call void @llvm.dbg.value(metadata i32 0, metadata !71, metadata !DIExpression()), !dbg !47
  br label %13, !dbg !72

13:                                               ; preds = %15, %7
  %.01 = phi i32 [ 0, %7 ], [ %28, %15 ], !dbg !74
  %.0 = phi double [ %12, %7 ], [ %27, %15 ], !dbg !75
  call void @llvm.dbg.value(metadata double %.0, metadata !70, metadata !DIExpression()), !dbg !47
  call void @llvm.dbg.value(metadata i32 %.01, metadata !71, metadata !DIExpression()), !dbg !47
  %14 = icmp slt i32 %.01, %.03, !dbg !76
  br i1 %14, label %15, label %29, !dbg !78

15:                                               ; preds = %13
  %16 = sext i32 %.07 to i64, !dbg !79
  %17 = getelementptr inbounds [400 x double], [400 x double]* getelementptr inbounds ([400 x [400 x double]], [400 x [400 x double]]* @A, i64 0, i64 0), i64 %16, !dbg !79
  %18 = sext i32 %.01 to i64, !dbg !79
  %19 = getelementptr inbounds [400 x double], [400 x double]* %17, i64 0, i64 %18, !dbg !79
  %20 = load double, double* %19, align 8, !dbg !79
  %21 = sext i32 %.01 to i64, !dbg !81
  %22 = getelementptr inbounds [400 x double], [400 x double]* getelementptr inbounds ([400 x [400 x double]], [400 x [400 x double]]* @A, i64 0, i64 0), i64 %21, !dbg !81
  %23 = sext i32 %.03 to i64, !dbg !81
  %24 = getelementptr inbounds [400 x double], [400 x double]* %22, i64 0, i64 %23, !dbg !81
  %25 = load double, double* %24, align 8, !dbg !81
  %26 = fmul double %20, %25, !dbg !82
  %27 = fsub double %.0, %26, !dbg !83
  call void @llvm.dbg.value(metadata double %27, metadata !70, metadata !DIExpression()), !dbg !47
  %28 = add nsw i32 %.01, 1, !dbg !84
  call void @llvm.dbg.value(metadata i32 %28, metadata !71, metadata !DIExpression()), !dbg !47
  br label %13, !dbg !85, !llvm.loop !86

29:                                               ; preds = %13
  %30 = sext i32 %.03 to i64, !dbg !89
  %31 = getelementptr inbounds [400 x double], [400 x double]* getelementptr inbounds ([400 x [400 x double]], [400 x [400 x double]]* @A, i64 0, i64 0), i64 %30, !dbg !89
  %32 = sext i32 %.03 to i64, !dbg !89
  %33 = getelementptr inbounds [400 x double], [400 x double]* %31, i64 0, i64 %32, !dbg !89
  %34 = load double, double* %33, align 8, !dbg !89
  %35 = fdiv double %.0, %34, !dbg !90
  %36 = sext i32 %.07 to i64, !dbg !91
  %37 = getelementptr inbounds [400 x double], [400 x double]* getelementptr inbounds ([400 x [400 x double]], [400 x [400 x double]]* @A, i64 0, i64 0), i64 %36, !dbg !91
  %38 = sext i32 %.03 to i64, !dbg !91
  %39 = getelementptr inbounds [400 x double], [400 x double]* %37, i64 0, i64 %38, !dbg !91
  store double %35, double* %39, align 8, !dbg !92
  %40 = add nsw i32 %.03, 1, !dbg !93
  call void @llvm.dbg.value(metadata i32 %40, metadata !60, metadata !DIExpression()), !dbg !47
  br label %5, !dbg !94, !llvm.loop !95

41:                                               ; preds = %5
  call void @llvm.dbg.value(metadata i32 %.07, metadata !60, metadata !DIExpression()), !dbg !47
  br label %42, !dbg !97

42:                                               ; preds = %66, %41
  %.14 = phi i32 [ %.07, %41 ], [ %71, %66 ], !dbg !99
  call void @llvm.dbg.value(metadata i32 %.14, metadata !60, metadata !DIExpression()), !dbg !47
  %43 = icmp slt i32 %.14, 400, !dbg !100
  br i1 %43, label %44, label %72, !dbg !102

44:                                               ; preds = %42
  %45 = sext i32 %.07 to i64, !dbg !103
  %46 = getelementptr inbounds [400 x double], [400 x double]* getelementptr inbounds ([400 x [400 x double]], [400 x [400 x double]]* @A, i64 0, i64 0), i64 %45, !dbg !103
  %47 = sext i32 %.14 to i64, !dbg !103
  %48 = getelementptr inbounds [400 x double], [400 x double]* %46, i64 0, i64 %47, !dbg !103
  %49 = load double, double* %48, align 8, !dbg !103
  call void @llvm.dbg.value(metadata double %49, metadata !70, metadata !DIExpression()), !dbg !47
  call void @llvm.dbg.value(metadata i32 0, metadata !71, metadata !DIExpression()), !dbg !47
  br label %50, !dbg !105

50:                                               ; preds = %52, %44
  %.12 = phi i32 [ 0, %44 ], [ %65, %52 ], !dbg !107
  %.1 = phi double [ %49, %44 ], [ %64, %52 ], !dbg !108
  call void @llvm.dbg.value(metadata double %.1, metadata !70, metadata !DIExpression()), !dbg !47
  call void @llvm.dbg.value(metadata i32 %.12, metadata !71, metadata !DIExpression()), !dbg !47
  %51 = icmp slt i32 %.12, %.07, !dbg !109
  br i1 %51, label %52, label %66, !dbg !111

52:                                               ; preds = %50
  %53 = sext i32 %.07 to i64, !dbg !112
  %54 = getelementptr inbounds [400 x double], [400 x double]* getelementptr inbounds ([400 x [400 x double]], [400 x [400 x double]]* @A, i64 0, i64 0), i64 %53, !dbg !112
  %55 = sext i32 %.12 to i64, !dbg !112
  %56 = getelementptr inbounds [400 x double], [400 x double]* %54, i64 0, i64 %55, !dbg !112
  %57 = load double, double* %56, align 8, !dbg !112
  %58 = sext i32 %.12 to i64, !dbg !114
  %59 = getelementptr inbounds [400 x double], [400 x double]* getelementptr inbounds ([400 x [400 x double]], [400 x [400 x double]]* @A, i64 0, i64 0), i64 %58, !dbg !114
  %60 = sext i32 %.14 to i64, !dbg !114
  %61 = getelementptr inbounds [400 x double], [400 x double]* %59, i64 0, i64 %60, !dbg !114
  %62 = load double, double* %61, align 8, !dbg !114
  %63 = fmul double %57, %62, !dbg !115
  %64 = fsub double %.1, %63, !dbg !116
  call void @llvm.dbg.value(metadata double %64, metadata !70, metadata !DIExpression()), !dbg !47
  %65 = add nsw i32 %.12, 1, !dbg !117
  call void @llvm.dbg.value(metadata i32 %65, metadata !71, metadata !DIExpression()), !dbg !47
  br label %50, !dbg !118, !llvm.loop !119

66:                                               ; preds = %50
  %67 = sext i32 %.07 to i64, !dbg !121
  %68 = getelementptr inbounds [400 x double], [400 x double]* getelementptr inbounds ([400 x [400 x double]], [400 x [400 x double]]* @A, i64 0, i64 0), i64 %67, !dbg !121
  %69 = sext i32 %.14 to i64, !dbg !121
  %70 = getelementptr inbounds [400 x double], [400 x double]* %68, i64 0, i64 %69, !dbg !121
  store double %.1, double* %70, align 8, !dbg !122
  %71 = add nsw i32 %.14, 1, !dbg !123
  call void @llvm.dbg.value(metadata i32 %71, metadata !60, metadata !DIExpression()), !dbg !47
  br label %42, !dbg !124, !llvm.loop !125

72:                                               ; preds = %42
  %73 = add nsw i32 %.07, 1, !dbg !127
  call void @llvm.dbg.value(metadata i32 %73, metadata !53, metadata !DIExpression()), !dbg !47
  br label %2, !dbg !128, !llvm.loop !129

74:                                               ; preds = %2
  call void @llvm.dbg.value(metadata i32 0, metadata !53, metadata !DIExpression()), !dbg !47
  br label %75, !dbg !131

75:                                               ; preds = %95, %74
  %.18 = phi i32 [ 0, %74 ], [ %98, %95 ], !dbg !133
  call void @llvm.dbg.value(metadata i32 %.18, metadata !53, metadata !DIExpression()), !dbg !47
  %76 = icmp slt i32 %.18, 400, !dbg !134
  br i1 %76, label %77, label %99, !dbg !136

77:                                               ; preds = %75
  %78 = sext i32 %.18 to i64, !dbg !137
  %79 = getelementptr inbounds double, double* getelementptr inbounds ([400 x double], [400 x double]* @b, i64 0, i64 0), i64 %78, !dbg !137
  %80 = load double, double* %79, align 8, !dbg !137
  call void @llvm.dbg.value(metadata double %80, metadata !70, metadata !DIExpression()), !dbg !47
  call void @llvm.dbg.value(metadata i32 0, metadata !60, metadata !DIExpression()), !dbg !47
  br label %81, !dbg !139

81:                                               ; preds = %83, %77
  %.25 = phi i32 [ 0, %77 ], [ %94, %83 ], !dbg !141
  %.2 = phi double [ %80, %77 ], [ %93, %83 ], !dbg !142
  call void @llvm.dbg.value(metadata double %.2, metadata !70, metadata !DIExpression()), !dbg !47
  call void @llvm.dbg.value(metadata i32 %.25, metadata !60, metadata !DIExpression()), !dbg !47
  %82 = icmp slt i32 %.25, %.18, !dbg !143
  br i1 %82, label %83, label %95, !dbg !145

83:                                               ; preds = %81
  %84 = sext i32 %.18 to i64, !dbg !146
  %85 = getelementptr inbounds [400 x double], [400 x double]* getelementptr inbounds ([400 x [400 x double]], [400 x [400 x double]]* @A, i64 0, i64 0), i64 %84, !dbg !146
  %86 = sext i32 %.25 to i64, !dbg !146
  %87 = getelementptr inbounds [400 x double], [400 x double]* %85, i64 0, i64 %86, !dbg !146
  %88 = load double, double* %87, align 8, !dbg !146
  %89 = sext i32 %.25 to i64, !dbg !147
  %90 = getelementptr inbounds double, double* getelementptr inbounds ([400 x double], [400 x double]* @y, i64 0, i64 0), i64 %89, !dbg !147
  %91 = load double, double* %90, align 8, !dbg !147
  %92 = fmul double %88, %91, !dbg !148
  %93 = fsub double %.2, %92, !dbg !149
  call void @llvm.dbg.value(metadata double %93, metadata !70, metadata !DIExpression()), !dbg !47
  %94 = add nsw i32 %.25, 1, !dbg !150
  call void @llvm.dbg.value(metadata i32 %94, metadata !60, metadata !DIExpression()), !dbg !47
  br label %81, !dbg !151, !llvm.loop !152

95:                                               ; preds = %81
  %96 = sext i32 %.18 to i64, !dbg !154
  %97 = getelementptr inbounds double, double* getelementptr inbounds ([400 x double], [400 x double]* @y, i64 0, i64 0), i64 %96, !dbg !154
  store double %.2, double* %97, align 8, !dbg !155
  %98 = add nsw i32 %.18, 1, !dbg !156
  call void @llvm.dbg.value(metadata i32 %98, metadata !53, metadata !DIExpression()), !dbg !47
  br label %75, !dbg !157, !llvm.loop !158

99:                                               ; preds = %75
  call void @llvm.dbg.value(metadata i32 399, metadata !53, metadata !DIExpression()), !dbg !47
  br label %100, !dbg !160

100:                                              ; preds = %121, %99
  %.29 = phi i32 [ 399, %99 ], [ %130, %121 ], !dbg !162
  call void @llvm.dbg.value(metadata i32 %.29, metadata !53, metadata !DIExpression()), !dbg !47
  %101 = icmp sge i32 %.29, 0, !dbg !163
  br i1 %101, label %102, label %131, !dbg !165

102:                                              ; preds = %100
  %103 = sext i32 %.29 to i64, !dbg !166
  %104 = getelementptr inbounds double, double* getelementptr inbounds ([400 x double], [400 x double]* @y, i64 0, i64 0), i64 %103, !dbg !166
  %105 = load double, double* %104, align 8, !dbg !166
  call void @llvm.dbg.value(metadata double %105, metadata !70, metadata !DIExpression()), !dbg !47
  %106 = add nsw i32 %.29, 1, !dbg !168
  call void @llvm.dbg.value(metadata i32 %106, metadata !60, metadata !DIExpression()), !dbg !47
  br label %107, !dbg !170

107:                                              ; preds = %109, %102
  %.36 = phi i32 [ %106, %102 ], [ %120, %109 ], !dbg !171
  %.3 = phi double [ %105, %102 ], [ %119, %109 ], !dbg !172
  call void @llvm.dbg.value(metadata double %.3, metadata !70, metadata !DIExpression()), !dbg !47
  call void @llvm.dbg.value(metadata i32 %.36, metadata !60, metadata !DIExpression()), !dbg !47
  %108 = icmp slt i32 %.36, 400, !dbg !173
  br i1 %108, label %109, label %121, !dbg !175

109:                                              ; preds = %107
  %110 = sext i32 %.29 to i64, !dbg !176
  %111 = getelementptr inbounds [400 x double], [400 x double]* getelementptr inbounds ([400 x [400 x double]], [400 x [400 x double]]* @A, i64 0, i64 0), i64 %110, !dbg !176
  %112 = sext i32 %.36 to i64, !dbg !176
  %113 = getelementptr inbounds [400 x double], [400 x double]* %111, i64 0, i64 %112, !dbg !176
  %114 = load double, double* %113, align 8, !dbg !176
  %115 = sext i32 %.36 to i64, !dbg !177
  %116 = getelementptr inbounds double, double* getelementptr inbounds ([400 x double], [400 x double]* @x, i64 0, i64 0), i64 %115, !dbg !177
  %117 = load double, double* %116, align 8, !dbg !177
  %118 = fmul double %114, %117, !dbg !178
  %119 = fsub double %.3, %118, !dbg !179
  call void @llvm.dbg.value(metadata double %119, metadata !70, metadata !DIExpression()), !dbg !47
  %120 = add nsw i32 %.36, 1, !dbg !180
  call void @llvm.dbg.value(metadata i32 %120, metadata !60, metadata !DIExpression()), !dbg !47
  br label %107, !dbg !181, !llvm.loop !182

121:                                              ; preds = %107
  %122 = sext i32 %.29 to i64, !dbg !184
  %123 = getelementptr inbounds [400 x double], [400 x double]* getelementptr inbounds ([400 x [400 x double]], [400 x [400 x double]]* @A, i64 0, i64 0), i64 %122, !dbg !184
  %124 = sext i32 %.29 to i64, !dbg !184
  %125 = getelementptr inbounds [400 x double], [400 x double]* %123, i64 0, i64 %124, !dbg !184
  %126 = load double, double* %125, align 8, !dbg !184
  %127 = fdiv double %.3, %126, !dbg !185
  %128 = sext i32 %.29 to i64, !dbg !186
  %129 = getelementptr inbounds double, double* getelementptr inbounds ([400 x double], [400 x double]* @x, i64 0, i64 0), i64 %128, !dbg !186
  store double %127, double* %129, align 8, !dbg !187
  %130 = add nsw i32 %.29, -1, !dbg !188
  call void @llvm.dbg.value(metadata i32 %130, metadata !53, metadata !DIExpression()), !dbg !47
  br label %100, !dbg !189, !llvm.loop !190

131:                                              ; preds = %100
  ret i32 0, !dbg !192
}

; Function Attrs: nofree nosync nounwind readnone speculatable willreturn
declare void @llvm.dbg.value(metadata, metadata, metadata) #1

attributes #0 = { noinline nounwind uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { nofree nosync nounwind readnone speculatable willreturn }

!llvm.dbg.cu = !{!2}
!llvm.module.flags = !{!24, !25, !26, !27, !28, !29, !30}
!llvm.ident = !{!31}

!0 = !DIGlobalVariableExpression(var: !1, expr: !DIExpression())
!1 = distinct !DIGlobalVariable(name: "n", scope: !2, file: !11, line: 155, type: !23, isLocal: false, isDefinition: true)
!2 = distinct !DICompileUnit(language: DW_LANG_C99, file: !3, producer: "Ubuntu clang version 14.0.0-1ubuntu1.1", isOptimized: false, runtimeVersion: 0, emissionKind: FullDebug, retainedTypes: !4, globals: !8, splitDebugInlining: false, nameTableKind: None)
!3 = !DIFile(filename: "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/triangular-20260929/suite/ludcmp/source/workload.c", directory: "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/triangular-20260929/suite/ludcmp/analysis-c", checksumkind: CSK_MD5, checksum: "a8b2bf59d78c069b73b824d9fd1ac779")
!4 = !{!5, !6, !7}
!5 = !DIBasicType(name: "double", size: 64, encoding: DW_ATE_float)
!6 = !DIBasicType(name: "unsigned int", size: 32, encoding: DW_ATE_unsigned)
!7 = !DIBasicType(name: "unsigned char", size: 8, encoding: DW_ATE_unsigned_char)
!8 = !{!0, !9, !15, !19, !21}
!9 = !DIGlobalVariableExpression(var: !10, expr: !DIExpression())
!10 = distinct !DIGlobalVariable(name: "A", scope: !2, file: !11, line: 35, type: !12, isLocal: false, isDefinition: true, align: 512)
!11 = !DIFile(filename: "source/workload.c", directory: "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/triangular-20260929/suite/ludcmp", checksumkind: CSK_MD5, checksum: "a8b2bf59d78c069b73b824d9fd1ac779")
!12 = !DICompositeType(tag: DW_TAG_array_type, baseType: !5, size: 10240000, elements: !13)
!13 = !{!14, !14}
!14 = !DISubrange(count: 400)
!15 = !DIGlobalVariableExpression(var: !16, expr: !DIExpression())
!16 = distinct !DIGlobalVariable(name: "b", scope: !2, file: !11, line: 36, type: !17, isLocal: false, isDefinition: true, align: 512)
!17 = !DICompositeType(tag: DW_TAG_array_type, baseType: !5, size: 25600, elements: !18)
!18 = !{!14}
!19 = !DIGlobalVariableExpression(var: !20, expr: !DIExpression())
!20 = distinct !DIGlobalVariable(name: "x", scope: !2, file: !11, line: 37, type: !17, isLocal: false, isDefinition: true, align: 512)
!21 = !DIGlobalVariableExpression(var: !22, expr: !DIExpression())
!22 = distinct !DIGlobalVariable(name: "y", scope: !2, file: !11, line: 38, type: !17, isLocal: false, isDefinition: true, align: 512)
!23 = !DIBasicType(name: "int", size: 32, encoding: DW_ATE_signed)
!24 = !{i32 7, !"Dwarf Version", i32 5}
!25 = !{i32 2, !"Debug Info Version", i32 3}
!26 = !{i32 1, !"wchar_size", i32 4}
!27 = !{i32 7, !"PIC Level", i32 2}
!28 = !{i32 7, !"PIE Level", i32 2}
!29 = !{i32 7, !"uwtable", i32 1}
!30 = !{i32 7, !"frame-pointer", i32 2}
!31 = !{!"Ubuntu clang version 14.0.0-1ubuntu1.1"}
!32 = distinct !DISubprogram(name: "task_job_polybench", scope: !11, file: !11, line: 170, type: !33, scopeLine: 170, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !2, retainedNodes: !39)
!33 = !DISubroutineType(types: !34)
!34 = !{!35}
!35 = !DIDerivedType(tag: DW_TAG_typedef, name: "uint32_t", file: !36, line: 26, baseType: !37)
!36 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/stdint-uintn.h", directory: "", checksumkind: CSK_MD5, checksum: "2bf2ae53c58c01b1a1b9383b5195125c")
!37 = !DIDerivedType(tag: DW_TAG_typedef, name: "__uint32_t", file: !38, line: 42, baseType: !6)
!38 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/types.h", directory: "", checksumkind: CSK_MD5, checksum: "d108b5f93a74c50510d7d9bc0ab36df9")
!39 = !{}
!40 = !DILocation(line: 171, column: 18, scope: !32)
!41 = !DILocalVariable(name: "n", arg: 1, scope: !42, file: !11, line: 108, type: !23)
!42 = distinct !DISubprogram(name: "kernel_ludcmp", scope: !11, file: !11, line: 108, type: !43, scopeLine: 113, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition, unit: !2, retainedNodes: !39)
!43 = !DISubroutineType(types: !44)
!44 = !{null, !23, !45, !46, !46, !46}
!45 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !17, size: 64)
!46 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !5, size: 64)
!47 = !DILocation(line: 0, scope: !42, inlinedAt: !48)
!48 = distinct !DILocation(line: 171, column: 3, scope: !32)
!49 = !DILocalVariable(name: "A", arg: 2, scope: !42, file: !11, line: 109, type: !45)
!50 = !DILocalVariable(name: "b", arg: 3, scope: !42, file: !11, line: 110, type: !46)
!51 = !DILocalVariable(name: "x", arg: 4, scope: !42, file: !11, line: 111, type: !46)
!52 = !DILocalVariable(name: "y", arg: 5, scope: !42, file: !11, line: 112, type: !46)
!53 = !DILocalVariable(name: "i", scope: !42, file: !11, line: 114, type: !23)
!54 = !DILocation(line: 119, column: 8, scope: !55, inlinedAt: !48)
!55 = distinct !DILexicalBlock(scope: !42, file: !11, line: 119, column: 3)
!56 = !DILocation(line: 0, scope: !55, inlinedAt: !48)
!57 = !DILocation(line: 119, column: 17, scope: !58, inlinedAt: !48)
!58 = distinct !DILexicalBlock(scope: !55, file: !11, line: 119, column: 3)
!59 = !DILocation(line: 119, column: 3, scope: !55, inlinedAt: !48)
!60 = !DILocalVariable(name: "j", scope: !42, file: !11, line: 114, type: !23)
!61 = !DILocation(line: 120, column: 10, scope: !62, inlinedAt: !48)
!62 = distinct !DILexicalBlock(scope: !63, file: !11, line: 120, column: 5)
!63 = distinct !DILexicalBlock(scope: !58, file: !11, line: 119, column: 31)
!64 = !DILocation(line: 0, scope: !62, inlinedAt: !48)
!65 = !DILocation(line: 120, column: 19, scope: !66, inlinedAt: !48)
!66 = distinct !DILexicalBlock(scope: !62, file: !11, line: 120, column: 5)
!67 = !DILocation(line: 120, column: 5, scope: !62, inlinedAt: !48)
!68 = !DILocation(line: 121, column: 12, scope: !69, inlinedAt: !48)
!69 = distinct !DILexicalBlock(scope: !66, file: !11, line: 120, column: 28)
!70 = !DILocalVariable(name: "w", scope: !42, file: !11, line: 116, type: !5)
!71 = !DILocalVariable(name: "k", scope: !42, file: !11, line: 114, type: !23)
!72 = !DILocation(line: 122, column: 13, scope: !73, inlinedAt: !48)
!73 = distinct !DILexicalBlock(scope: !69, file: !11, line: 122, column: 8)
!74 = !DILocation(line: 0, scope: !73, inlinedAt: !48)
!75 = !DILocation(line: 0, scope: !69, inlinedAt: !48)
!76 = !DILocation(line: 122, column: 22, scope: !77, inlinedAt: !48)
!77 = distinct !DILexicalBlock(scope: !73, file: !11, line: 122, column: 8)
!78 = !DILocation(line: 122, column: 8, scope: !73, inlinedAt: !48)
!79 = !DILocation(line: 123, column: 16, scope: !80, inlinedAt: !48)
!80 = distinct !DILexicalBlock(scope: !77, file: !11, line: 122, column: 32)
!81 = !DILocation(line: 123, column: 26, scope: !80, inlinedAt: !48)
!82 = !DILocation(line: 123, column: 24, scope: !80, inlinedAt: !48)
!83 = !DILocation(line: 123, column: 13, scope: !80, inlinedAt: !48)
!84 = !DILocation(line: 122, column: 28, scope: !77, inlinedAt: !48)
!85 = !DILocation(line: 122, column: 8, scope: !77, inlinedAt: !48)
!86 = distinct !{!86, !78, !87, !88}
!87 = !DILocation(line: 124, column: 8, scope: !73, inlinedAt: !48)
!88 = !{!"llvm.loop.mustprogress"}
!89 = !DILocation(line: 125, column: 23, scope: !69, inlinedAt: !48)
!90 = !DILocation(line: 125, column: 21, scope: !69, inlinedAt: !48)
!91 = !DILocation(line: 125, column: 9, scope: !69, inlinedAt: !48)
!92 = !DILocation(line: 125, column: 17, scope: !69, inlinedAt: !48)
!93 = !DILocation(line: 120, column: 24, scope: !66, inlinedAt: !48)
!94 = !DILocation(line: 120, column: 5, scope: !66, inlinedAt: !48)
!95 = distinct !{!95, !67, !96, !88}
!96 = !DILocation(line: 126, column: 5, scope: !62, inlinedAt: !48)
!97 = !DILocation(line: 127, column: 9, scope: !98, inlinedAt: !48)
!98 = distinct !DILexicalBlock(scope: !63, file: !11, line: 127, column: 4)
!99 = !DILocation(line: 0, scope: !98, inlinedAt: !48)
!100 = !DILocation(line: 127, column: 18, scope: !101, inlinedAt: !48)
!101 = distinct !DILexicalBlock(scope: !98, file: !11, line: 127, column: 4)
!102 = !DILocation(line: 127, column: 4, scope: !98, inlinedAt: !48)
!103 = !DILocation(line: 128, column: 12, scope: !104, inlinedAt: !48)
!104 = distinct !DILexicalBlock(scope: !101, file: !11, line: 127, column: 32)
!105 = !DILocation(line: 129, column: 13, scope: !106, inlinedAt: !48)
!106 = distinct !DILexicalBlock(scope: !104, file: !11, line: 129, column: 8)
!107 = !DILocation(line: 0, scope: !106, inlinedAt: !48)
!108 = !DILocation(line: 0, scope: !104, inlinedAt: !48)
!109 = !DILocation(line: 129, column: 22, scope: !110, inlinedAt: !48)
!110 = distinct !DILexicalBlock(scope: !106, file: !11, line: 129, column: 8)
!111 = !DILocation(line: 129, column: 8, scope: !106, inlinedAt: !48)
!112 = !DILocation(line: 130, column: 16, scope: !113, inlinedAt: !48)
!113 = distinct !DILexicalBlock(scope: !110, file: !11, line: 129, column: 32)
!114 = !DILocation(line: 130, column: 26, scope: !113, inlinedAt: !48)
!115 = !DILocation(line: 130, column: 24, scope: !113, inlinedAt: !48)
!116 = !DILocation(line: 130, column: 13, scope: !113, inlinedAt: !48)
!117 = !DILocation(line: 129, column: 28, scope: !110, inlinedAt: !48)
!118 = !DILocation(line: 129, column: 8, scope: !110, inlinedAt: !48)
!119 = distinct !{!119, !111, !120, !88}
!120 = !DILocation(line: 131, column: 8, scope: !106, inlinedAt: !48)
!121 = !DILocation(line: 132, column: 8, scope: !104, inlinedAt: !48)
!122 = !DILocation(line: 132, column: 16, scope: !104, inlinedAt: !48)
!123 = !DILocation(line: 127, column: 28, scope: !101, inlinedAt: !48)
!124 = !DILocation(line: 127, column: 4, scope: !101, inlinedAt: !48)
!125 = distinct !{!125, !102, !126, !88}
!126 = !DILocation(line: 133, column: 5, scope: !98, inlinedAt: !48)
!127 = !DILocation(line: 119, column: 27, scope: !58, inlinedAt: !48)
!128 = !DILocation(line: 119, column: 3, scope: !58, inlinedAt: !48)
!129 = distinct !{!129, !59, !130, !88}
!130 = !DILocation(line: 134, column: 3, scope: !55, inlinedAt: !48)
!131 = !DILocation(line: 136, column: 8, scope: !132, inlinedAt: !48)
!132 = distinct !DILexicalBlock(scope: !42, file: !11, line: 136, column: 3)
!133 = !DILocation(line: 0, scope: !132, inlinedAt: !48)
!134 = !DILocation(line: 136, column: 17, scope: !135, inlinedAt: !48)
!135 = distinct !DILexicalBlock(scope: !132, file: !11, line: 136, column: 3)
!136 = !DILocation(line: 136, column: 3, scope: !132, inlinedAt: !48)
!137 = !DILocation(line: 137, column: 10, scope: !138, inlinedAt: !48)
!138 = distinct !DILexicalBlock(scope: !135, file: !11, line: 136, column: 31)
!139 = !DILocation(line: 138, column: 11, scope: !140, inlinedAt: !48)
!140 = distinct !DILexicalBlock(scope: !138, file: !11, line: 138, column: 6)
!141 = !DILocation(line: 0, scope: !140, inlinedAt: !48)
!142 = !DILocation(line: 0, scope: !138, inlinedAt: !48)
!143 = !DILocation(line: 138, column: 20, scope: !144, inlinedAt: !48)
!144 = distinct !DILexicalBlock(scope: !140, file: !11, line: 138, column: 6)
!145 = !DILocation(line: 138, column: 6, scope: !140, inlinedAt: !48)
!146 = !DILocation(line: 139, column: 14, scope: !144, inlinedAt: !48)
!147 = !DILocation(line: 139, column: 24, scope: !144, inlinedAt: !48)
!148 = !DILocation(line: 139, column: 22, scope: !144, inlinedAt: !48)
!149 = !DILocation(line: 139, column: 11, scope: !144, inlinedAt: !48)
!150 = !DILocation(line: 138, column: 26, scope: !144, inlinedAt: !48)
!151 = !DILocation(line: 138, column: 6, scope: !144, inlinedAt: !48)
!152 = distinct !{!152, !145, !153, !88}
!153 = !DILocation(line: 139, column: 27, scope: !140, inlinedAt: !48)
!154 = !DILocation(line: 140, column: 6, scope: !138, inlinedAt: !48)
!155 = !DILocation(line: 140, column: 11, scope: !138, inlinedAt: !48)
!156 = !DILocation(line: 136, column: 27, scope: !135, inlinedAt: !48)
!157 = !DILocation(line: 136, column: 3, scope: !135, inlinedAt: !48)
!158 = distinct !{!158, !136, !159, !88}
!159 = !DILocation(line: 141, column: 3, scope: !132, inlinedAt: !48)
!160 = !DILocation(line: 143, column: 9, scope: !161, inlinedAt: !48)
!161 = distinct !DILexicalBlock(scope: !42, file: !11, line: 143, column: 4)
!162 = !DILocation(line: 0, scope: !161, inlinedAt: !48)
!163 = !DILocation(line: 143, column: 24, scope: !164, inlinedAt: !48)
!164 = distinct !DILexicalBlock(scope: !161, file: !11, line: 143, column: 4)
!165 = !DILocation(line: 143, column: 4, scope: !161, inlinedAt: !48)
!166 = !DILocation(line: 144, column: 10, scope: !167, inlinedAt: !48)
!167 = distinct !DILexicalBlock(scope: !164, file: !11, line: 143, column: 34)
!168 = !DILocation(line: 145, column: 16, scope: !169, inlinedAt: !48)
!169 = distinct !DILexicalBlock(scope: !167, file: !11, line: 145, column: 6)
!170 = !DILocation(line: 145, column: 11, scope: !169, inlinedAt: !48)
!171 = !DILocation(line: 0, scope: !169, inlinedAt: !48)
!172 = !DILocation(line: 0, scope: !167, inlinedAt: !48)
!173 = !DILocation(line: 145, column: 22, scope: !174, inlinedAt: !48)
!174 = distinct !DILexicalBlock(scope: !169, file: !11, line: 145, column: 6)
!175 = !DILocation(line: 145, column: 6, scope: !169, inlinedAt: !48)
!176 = !DILocation(line: 146, column: 14, scope: !174, inlinedAt: !48)
!177 = !DILocation(line: 146, column: 24, scope: !174, inlinedAt: !48)
!178 = !DILocation(line: 146, column: 22, scope: !174, inlinedAt: !48)
!179 = !DILocation(line: 146, column: 11, scope: !174, inlinedAt: !48)
!180 = !DILocation(line: 145, column: 32, scope: !174, inlinedAt: !48)
!181 = !DILocation(line: 145, column: 6, scope: !174, inlinedAt: !48)
!182 = distinct !{!182, !175, !183, !88}
!183 = !DILocation(line: 146, column: 27, scope: !169, inlinedAt: !48)
!184 = !DILocation(line: 147, column: 17, scope: !167, inlinedAt: !48)
!185 = !DILocation(line: 147, column: 15, scope: !167, inlinedAt: !48)
!186 = !DILocation(line: 147, column: 6, scope: !167, inlinedAt: !48)
!187 = !DILocation(line: 147, column: 11, scope: !167, inlinedAt: !48)
!188 = !DILocation(line: 143, column: 30, scope: !164, inlinedAt: !48)
!189 = !DILocation(line: 143, column: 4, scope: !164, inlinedAt: !48)
!190 = distinct !{!190, !165, !191, !88}
!191 = !DILocation(line: 148, column: 3, scope: !161, inlinedAt: !48)
!192 = !DILocation(line: 176, column: 3, scope: !32)
