; ModuleID = 'workload.ll'
source_filename = "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/triangular-20260929/suite/heat-3d/source/workload.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

%struct._IO_FILE = type { i32, i8*, i8*, i8*, i8*, i8*, i8*, i8*, i8*, i8*, i8*, i8*, %struct._IO_marker*, %struct._IO_FILE*, i32, i32, i64, i16, i8, [1 x i8], i8*, i64, %struct._IO_codecvt*, %struct._IO_wide_data*, %struct._IO_FILE*, i8*, i64, i32, [20 x i8] }
%struct._IO_marker = type opaque
%struct._IO_codecvt = type opaque
%struct._IO_wide_data = type opaque
%struct.__va_list_tag = type { i32, i32, i8*, i8* }

@n = dso_local global i32 40, align 4, !dbg !0
@tsteps = dso_local global i32 100, align 4, !dbg !9
@A = dso_local global [40 x [40 x [40 x double]]] zeroinitializer, section ".chaser_data.A", align 64, !dbg !33
@B = dso_local global [40 x [40 x [40 x double]]] zeroinitializer, section ".chaser_data.B", align 64, !dbg !38
@.str = private unnamed_addr constant [12 x i8] c"ape.analyze\00", section "llvm.metadata"
@.str.1 = private unnamed_addr constant [122 x i8] c"/workspace/experiments-array-support/chaser/.cache/periodic-polybench/triangular-20260929/suite/heat-3d/source/workload.c\00", section "llvm.metadata"
@pb_hash = internal global i32 0, align 4, !dbg !30
@workload_jobs = dso_local constant [1 x i32 ()*] [i32 ()* @task_job_polybench], align 8, !dbg !13
@workload_expected = dso_local constant [1 x i32] [i32 -850454241], align 4, !dbg !26
@stderr = external global %struct._IO_FILE*, align 8
@.str.2 = private unnamed_addr constant [23 x i8] c"==BEGIN DUMP_ARRAYS==\0A\00", align 1
@.str.3 = private unnamed_addr constant [15 x i8] c"begin dump: %s\00", align 1
@.str.4 = private unnamed_addr constant [2 x i8] c"A\00", align 1
@.str.5 = private unnamed_addr constant [2 x i8] c"\0A\00", align 1
@.str.6 = private unnamed_addr constant [8 x i8] c"%0.2lf \00", align 1
@.str.7 = private unnamed_addr constant [17 x i8] c"\0Aend   dump: %s\0A\00", align 1
@.str.8 = private unnamed_addr constant [23 x i8] c"==END   DUMP_ARRAYS==\0A\00", align 1
@pb_emit = internal global i32 1, align 4, !dbg !40
@llvm.global.annotations = appending global [1 x { i8*, i8*, i8*, i32, i8* }] [{ i8*, i8*, i8*, i32, i8* } { i8* bitcast (i32 ()* @task_job_polybench to i8*), i8* getelementptr inbounds ([12 x i8], [12 x i8]* @.str, i32 0, i32 0), i8* getelementptr inbounds ([122 x i8], [122 x i8]* @.str.1, i32 0, i32 0), i32 120, i8* null }], section "llvm.metadata"

; Function Attrs: noinline nounwind uwtable
define dso_local void @workload_prepare() #0 !dbg !50 {
  ret void, !dbg !54
}

; Function Attrs: noinline nounwind uwtable
define dso_local void @workload_reset(i32 noundef %0) #0 !dbg !55 {
  call void @llvm.dbg.value(metadata i32 %0, metadata !58, metadata !DIExpression()), !dbg !59
  call void @llvm.memset.p0i8.i64(i8* align 64 bitcast ([40 x [40 x [40 x double]]]* @A to i8*), i8 0, i64 512000, i1 false), !dbg !60
  call void @llvm.memset.p0i8.i64(i8* align 64 bitcast ([40 x [40 x [40 x double]]]* @B to i8*), i8 0, i64 512000, i1 false), !dbg !61
  %2 = load i32, i32* @n, align 4, !dbg !62
  call void @init_array(i32 noundef %2, [40 x [40 x double]]* noundef getelementptr inbounds ([40 x [40 x [40 x double]]], [40 x [40 x [40 x double]]]* @A, i64 0, i64 0), [40 x [40 x double]]* noundef getelementptr inbounds ([40 x [40 x [40 x double]]], [40 x [40 x [40 x double]]]* @B, i64 0, i64 0)), !dbg !63
  ret void, !dbg !64
}

; Function Attrs: nofree nosync nounwind readnone speculatable willreturn
declare void @llvm.dbg.declare(metadata, metadata, metadata) #1

; Function Attrs: argmemonly nofree nounwind willreturn writeonly
declare void @llvm.memset.p0i8.i64(i8* nocapture writeonly, i8, i64, i1 immarg) #2

; Function Attrs: noinline nounwind uwtable
define internal void @init_array(i32 noundef %0, [40 x [40 x double]]* noundef %1, [40 x [40 x double]]* noundef %2) #0 !dbg !65 {
  call void @llvm.dbg.value(metadata i32 %0, metadata !71, metadata !DIExpression()), !dbg !72
  call void @llvm.dbg.value(metadata [40 x [40 x double]]* %1, metadata !73, metadata !DIExpression()), !dbg !72
  call void @llvm.dbg.value(metadata [40 x [40 x double]]* %2, metadata !74, metadata !DIExpression()), !dbg !72
  call void @llvm.dbg.value(metadata i32 0, metadata !75, metadata !DIExpression()), !dbg !72
  br label %4, !dbg !76

4:                                                ; preds = %38, %3
  %.02 = phi i32 [ 0, %3 ], [ %39, %38 ], !dbg !78
  call void @llvm.dbg.value(metadata i32 %.02, metadata !75, metadata !DIExpression()), !dbg !72
  %5 = icmp slt i32 %.02, %0, !dbg !79
  br i1 %5, label %6, label %40, !dbg !81

6:                                                ; preds = %4
  call void @llvm.dbg.value(metadata i32 0, metadata !82, metadata !DIExpression()), !dbg !72
  br label %7, !dbg !83

7:                                                ; preds = %35, %6
  %.01 = phi i32 [ 0, %6 ], [ %36, %35 ], !dbg !85
  call void @llvm.dbg.value(metadata i32 %.01, metadata !82, metadata !DIExpression()), !dbg !72
  %8 = icmp slt i32 %.01, %0, !dbg !86
  br i1 %8, label %9, label %37, !dbg !88

9:                                                ; preds = %7
  call void @llvm.dbg.value(metadata i32 0, metadata !89, metadata !DIExpression()), !dbg !72
  br label %10, !dbg !90

10:                                               ; preds = %32, %9
  %.0 = phi i32 [ 0, %9 ], [ %33, %32 ], !dbg !92
  call void @llvm.dbg.value(metadata i32 %.0, metadata !89, metadata !DIExpression()), !dbg !72
  %11 = icmp slt i32 %.0, %0, !dbg !93
  br i1 %11, label %12, label %34, !dbg !95

12:                                               ; preds = %10
  %13 = add nsw i32 %.02, %.01, !dbg !96
  %14 = sub nsw i32 %0, %.0, !dbg !97
  %15 = add nsw i32 %13, %14, !dbg !98
  %16 = sitofp i32 %15 to double, !dbg !99
  %17 = fmul double %16, 1.000000e+01, !dbg !100
  %18 = sitofp i32 %0 to double, !dbg !101
  %19 = fdiv double %17, %18, !dbg !102
  %20 = sext i32 %.02 to i64, !dbg !103
  %21 = getelementptr inbounds [40 x [40 x double]], [40 x [40 x double]]* %2, i64 %20, !dbg !103
  %22 = sext i32 %.01 to i64, !dbg !103
  %23 = getelementptr inbounds [40 x [40 x double]], [40 x [40 x double]]* %21, i64 0, i64 %22, !dbg !103
  %24 = sext i32 %.0 to i64, !dbg !103
  %25 = getelementptr inbounds [40 x double], [40 x double]* %23, i64 0, i64 %24, !dbg !103
  store double %19, double* %25, align 8, !dbg !104
  %26 = sext i32 %.02 to i64, !dbg !105
  %27 = getelementptr inbounds [40 x [40 x double]], [40 x [40 x double]]* %1, i64 %26, !dbg !105
  %28 = sext i32 %.01 to i64, !dbg !105
  %29 = getelementptr inbounds [40 x [40 x double]], [40 x [40 x double]]* %27, i64 0, i64 %28, !dbg !105
  %30 = sext i32 %.0 to i64, !dbg !105
  %31 = getelementptr inbounds [40 x double], [40 x double]* %29, i64 0, i64 %30, !dbg !105
  store double %19, double* %31, align 8, !dbg !106
  br label %32, !dbg !105

32:                                               ; preds = %12
  %33 = add nsw i32 %.0, 1, !dbg !107
  call void @llvm.dbg.value(metadata i32 %33, metadata !89, metadata !DIExpression()), !dbg !72
  br label %10, !dbg !108, !llvm.loop !109

34:                                               ; preds = %10
  br label %35, !dbg !110

35:                                               ; preds = %34
  %36 = add nsw i32 %.01, 1, !dbg !112
  call void @llvm.dbg.value(metadata i32 %36, metadata !82, metadata !DIExpression()), !dbg !72
  br label %7, !dbg !113, !llvm.loop !114

37:                                               ; preds = %7
  br label %38, !dbg !115

38:                                               ; preds = %37
  %39 = add nsw i32 %.02, 1, !dbg !116
  call void @llvm.dbg.value(metadata i32 %39, metadata !75, metadata !DIExpression()), !dbg !72
  br label %4, !dbg !117, !llvm.loop !118

40:                                               ; preds = %4
  ret void, !dbg !120
}

; Function Attrs: noinline nounwind uwtable
define dso_local i32 @task_job_polybench() #0 !dbg !121 {
  %1 = load i32, i32* @tsteps, align 4, !dbg !122
  %2 = load i32, i32* @n, align 4, !dbg !123
  call void @llvm.dbg.value(metadata i32 %1, metadata !124, metadata !DIExpression()), !dbg !128
  call void @llvm.dbg.value(metadata i32 %2, metadata !130, metadata !DIExpression()), !dbg !128
  call void @llvm.dbg.value(metadata [40 x [40 x double]]* getelementptr inbounds ([40 x [40 x [40 x double]]], [40 x [40 x [40 x double]]]* @A, i64 0, i64 0), metadata !131, metadata !DIExpression()), !dbg !128
  call void @llvm.dbg.value(metadata [40 x [40 x double]]* getelementptr inbounds ([40 x [40 x [40 x double]]], [40 x [40 x [40 x double]]]* @B, i64 0, i64 0), metadata !132, metadata !DIExpression()), !dbg !128
  call void @llvm.dbg.value(metadata i32 1, metadata !133, metadata !DIExpression()), !dbg !128
  br label %3, !dbg !134

3:                                                ; preds = %229, %0
  %.05 = phi i32 [ 1, %0 ], [ %230, %229 ], !dbg !136
  call void @llvm.dbg.value(metadata i32 %.05, metadata !133, metadata !DIExpression()), !dbg !128
  %4 = icmp sle i32 %.05, 100, !dbg !137
  br i1 %4, label %5, label %231, !dbg !139

5:                                                ; preds = %3
  call void @llvm.dbg.value(metadata i32 1, metadata !140, metadata !DIExpression()), !dbg !128
  br label %6, !dbg !141

6:                                                ; preds = %115, %5
  %.03 = phi i32 [ 1, %5 ], [ %116, %115 ], !dbg !144
  call void @llvm.dbg.value(metadata i32 %.03, metadata !140, metadata !DIExpression()), !dbg !128
  %7 = icmp slt i32 %.03, 39, !dbg !145
  br i1 %7, label %8, label %117, !dbg !147

8:                                                ; preds = %6
  call void @llvm.dbg.value(metadata i32 1, metadata !148, metadata !DIExpression()), !dbg !128
  br label %9, !dbg !149

9:                                                ; preds = %113, %8
  %.01 = phi i32 [ 1, %8 ], [ %114, %113 ], !dbg !152
  call void @llvm.dbg.value(metadata i32 %.01, metadata !148, metadata !DIExpression()), !dbg !128
  %10 = icmp slt i32 %.01, 39, !dbg !153
  br i1 %10, label %11, label %115, !dbg !155

11:                                               ; preds = %9
  call void @llvm.dbg.value(metadata i32 1, metadata !156, metadata !DIExpression()), !dbg !128
  br label %12, !dbg !157

12:                                               ; preds = %14, %11
  %.0 = phi i32 [ 1, %11 ], [ %112, %14 ], !dbg !160
  call void @llvm.dbg.value(metadata i32 %.0, metadata !156, metadata !DIExpression()), !dbg !128
  %13 = icmp slt i32 %.0, 39, !dbg !161
  br i1 %13, label %14, label %113, !dbg !163

14:                                               ; preds = %12
  %15 = add nsw i32 %.03, 1, !dbg !164
  %16 = sext i32 %15 to i64, !dbg !166
  %17 = getelementptr inbounds [40 x [40 x double]], [40 x [40 x double]]* getelementptr inbounds ([40 x [40 x [40 x double]]], [40 x [40 x [40 x double]]]* @A, i64 0, i64 0), i64 %16, !dbg !166
  %18 = sext i32 %.01 to i64, !dbg !166
  %19 = getelementptr inbounds [40 x [40 x double]], [40 x [40 x double]]* %17, i64 0, i64 %18, !dbg !166
  %20 = sext i32 %.0 to i64, !dbg !166
  %21 = getelementptr inbounds [40 x double], [40 x double]* %19, i64 0, i64 %20, !dbg !166
  %22 = load double, double* %21, align 8, !dbg !166
  %23 = sext i32 %.03 to i64, !dbg !167
  %24 = getelementptr inbounds [40 x [40 x double]], [40 x [40 x double]]* getelementptr inbounds ([40 x [40 x [40 x double]]], [40 x [40 x [40 x double]]]* @A, i64 0, i64 0), i64 %23, !dbg !167
  %25 = sext i32 %.01 to i64, !dbg !167
  %26 = getelementptr inbounds [40 x [40 x double]], [40 x [40 x double]]* %24, i64 0, i64 %25, !dbg !167
  %27 = sext i32 %.0 to i64, !dbg !167
  %28 = getelementptr inbounds [40 x double], [40 x double]* %26, i64 0, i64 %27, !dbg !167
  %29 = load double, double* %28, align 8, !dbg !167
  %30 = fmul double 2.000000e+00, %29, !dbg !168
  %31 = fsub double %22, %30, !dbg !169
  %32 = sub nsw i32 %.03, 1, !dbg !170
  %33 = sext i32 %32 to i64, !dbg !171
  %34 = getelementptr inbounds [40 x [40 x double]], [40 x [40 x double]]* getelementptr inbounds ([40 x [40 x [40 x double]]], [40 x [40 x [40 x double]]]* @A, i64 0, i64 0), i64 %33, !dbg !171
  %35 = sext i32 %.01 to i64, !dbg !171
  %36 = getelementptr inbounds [40 x [40 x double]], [40 x [40 x double]]* %34, i64 0, i64 %35, !dbg !171
  %37 = sext i32 %.0 to i64, !dbg !171
  %38 = getelementptr inbounds [40 x double], [40 x double]* %36, i64 0, i64 %37, !dbg !171
  %39 = load double, double* %38, align 8, !dbg !171
  %40 = fadd double %31, %39, !dbg !172
  %41 = fmul double 1.250000e-01, %40, !dbg !173
  %42 = sext i32 %.03 to i64, !dbg !174
  %43 = getelementptr inbounds [40 x [40 x double]], [40 x [40 x double]]* getelementptr inbounds ([40 x [40 x [40 x double]]], [40 x [40 x [40 x double]]]* @A, i64 0, i64 0), i64 %42, !dbg !174
  %44 = add nsw i32 %.01, 1, !dbg !175
  %45 = sext i32 %44 to i64, !dbg !174
  %46 = getelementptr inbounds [40 x [40 x double]], [40 x [40 x double]]* %43, i64 0, i64 %45, !dbg !174
  %47 = sext i32 %.0 to i64, !dbg !174
  %48 = getelementptr inbounds [40 x double], [40 x double]* %46, i64 0, i64 %47, !dbg !174
  %49 = load double, double* %48, align 8, !dbg !174
  %50 = sext i32 %.03 to i64, !dbg !176
  %51 = getelementptr inbounds [40 x [40 x double]], [40 x [40 x double]]* getelementptr inbounds ([40 x [40 x [40 x double]]], [40 x [40 x [40 x double]]]* @A, i64 0, i64 0), i64 %50, !dbg !176
  %52 = sext i32 %.01 to i64, !dbg !176
  %53 = getelementptr inbounds [40 x [40 x double]], [40 x [40 x double]]* %51, i64 0, i64 %52, !dbg !176
  %54 = sext i32 %.0 to i64, !dbg !176
  %55 = getelementptr inbounds [40 x double], [40 x double]* %53, i64 0, i64 %54, !dbg !176
  %56 = load double, double* %55, align 8, !dbg !176
  %57 = fmul double 2.000000e+00, %56, !dbg !177
  %58 = fsub double %49, %57, !dbg !178
  %59 = sext i32 %.03 to i64, !dbg !179
  %60 = getelementptr inbounds [40 x [40 x double]], [40 x [40 x double]]* getelementptr inbounds ([40 x [40 x [40 x double]]], [40 x [40 x [40 x double]]]* @A, i64 0, i64 0), i64 %59, !dbg !179
  %61 = sub nsw i32 %.01, 1, !dbg !180
  %62 = sext i32 %61 to i64, !dbg !179
  %63 = getelementptr inbounds [40 x [40 x double]], [40 x [40 x double]]* %60, i64 0, i64 %62, !dbg !179
  %64 = sext i32 %.0 to i64, !dbg !179
  %65 = getelementptr inbounds [40 x double], [40 x double]* %63, i64 0, i64 %64, !dbg !179
  %66 = load double, double* %65, align 8, !dbg !179
  %67 = fadd double %58, %66, !dbg !181
  %68 = fmul double 1.250000e-01, %67, !dbg !182
  %69 = fadd double %41, %68, !dbg !183
  %70 = sext i32 %.03 to i64, !dbg !184
  %71 = getelementptr inbounds [40 x [40 x double]], [40 x [40 x double]]* getelementptr inbounds ([40 x [40 x [40 x double]]], [40 x [40 x [40 x double]]]* @A, i64 0, i64 0), i64 %70, !dbg !184
  %72 = sext i32 %.01 to i64, !dbg !184
  %73 = getelementptr inbounds [40 x [40 x double]], [40 x [40 x double]]* %71, i64 0, i64 %72, !dbg !184
  %74 = add nsw i32 %.0, 1, !dbg !185
  %75 = sext i32 %74 to i64, !dbg !184
  %76 = getelementptr inbounds [40 x double], [40 x double]* %73, i64 0, i64 %75, !dbg !184
  %77 = load double, double* %76, align 8, !dbg !184
  %78 = sext i32 %.03 to i64, !dbg !186
  %79 = getelementptr inbounds [40 x [40 x double]], [40 x [40 x double]]* getelementptr inbounds ([40 x [40 x [40 x double]]], [40 x [40 x [40 x double]]]* @A, i64 0, i64 0), i64 %78, !dbg !186
  %80 = sext i32 %.01 to i64, !dbg !186
  %81 = getelementptr inbounds [40 x [40 x double]], [40 x [40 x double]]* %79, i64 0, i64 %80, !dbg !186
  %82 = sext i32 %.0 to i64, !dbg !186
  %83 = getelementptr inbounds [40 x double], [40 x double]* %81, i64 0, i64 %82, !dbg !186
  %84 = load double, double* %83, align 8, !dbg !186
  %85 = fmul double 2.000000e+00, %84, !dbg !187
  %86 = fsub double %77, %85, !dbg !188
  %87 = sext i32 %.03 to i64, !dbg !189
  %88 = getelementptr inbounds [40 x [40 x double]], [40 x [40 x double]]* getelementptr inbounds ([40 x [40 x [40 x double]]], [40 x [40 x [40 x double]]]* @A, i64 0, i64 0), i64 %87, !dbg !189
  %89 = sext i32 %.01 to i64, !dbg !189
  %90 = getelementptr inbounds [40 x [40 x double]], [40 x [40 x double]]* %88, i64 0, i64 %89, !dbg !189
  %91 = sub nsw i32 %.0, 1, !dbg !190
  %92 = sext i32 %91 to i64, !dbg !189
  %93 = getelementptr inbounds [40 x double], [40 x double]* %90, i64 0, i64 %92, !dbg !189
  %94 = load double, double* %93, align 8, !dbg !189
  %95 = fadd double %86, %94, !dbg !191
  %96 = fmul double 1.250000e-01, %95, !dbg !192
  %97 = fadd double %69, %96, !dbg !193
  %98 = sext i32 %.03 to i64, !dbg !194
  %99 = getelementptr inbounds [40 x [40 x double]], [40 x [40 x double]]* getelementptr inbounds ([40 x [40 x [40 x double]]], [40 x [40 x [40 x double]]]* @A, i64 0, i64 0), i64 %98, !dbg !194
  %100 = sext i32 %.01 to i64, !dbg !194
  %101 = getelementptr inbounds [40 x [40 x double]], [40 x [40 x double]]* %99, i64 0, i64 %100, !dbg !194
  %102 = sext i32 %.0 to i64, !dbg !194
  %103 = getelementptr inbounds [40 x double], [40 x double]* %101, i64 0, i64 %102, !dbg !194
  %104 = load double, double* %103, align 8, !dbg !194
  %105 = fadd double %97, %104, !dbg !195
  %106 = sext i32 %.03 to i64, !dbg !196
  %107 = getelementptr inbounds [40 x [40 x double]], [40 x [40 x double]]* getelementptr inbounds ([40 x [40 x [40 x double]]], [40 x [40 x [40 x double]]]* @B, i64 0, i64 0), i64 %106, !dbg !196
  %108 = sext i32 %.01 to i64, !dbg !196
  %109 = getelementptr inbounds [40 x [40 x double]], [40 x [40 x double]]* %107, i64 0, i64 %108, !dbg !196
  %110 = sext i32 %.0 to i64, !dbg !196
  %111 = getelementptr inbounds [40 x double], [40 x double]* %109, i64 0, i64 %110, !dbg !196
  store double %105, double* %111, align 8, !dbg !197
  %112 = add nsw i32 %.0, 1, !dbg !198
  call void @llvm.dbg.value(metadata i32 %112, metadata !156, metadata !DIExpression()), !dbg !128
  br label %12, !dbg !199, !llvm.loop !200

113:                                              ; preds = %12
  %114 = add nsw i32 %.01, 1, !dbg !202
  call void @llvm.dbg.value(metadata i32 %114, metadata !148, metadata !DIExpression()), !dbg !128
  br label %9, !dbg !203, !llvm.loop !204

115:                                              ; preds = %9
  %116 = add nsw i32 %.03, 1, !dbg !206
  call void @llvm.dbg.value(metadata i32 %116, metadata !140, metadata !DIExpression()), !dbg !128
  br label %6, !dbg !207, !llvm.loop !208

117:                                              ; preds = %6
  call void @llvm.dbg.value(metadata i32 1, metadata !140, metadata !DIExpression()), !dbg !128
  br label %118, !dbg !210

118:                                              ; preds = %227, %117
  %.14 = phi i32 [ 1, %117 ], [ %228, %227 ], !dbg !212
  call void @llvm.dbg.value(metadata i32 %.14, metadata !140, metadata !DIExpression()), !dbg !128
  %119 = icmp slt i32 %.14, 39, !dbg !213
  br i1 %119, label %120, label %229, !dbg !215

120:                                              ; preds = %118
  call void @llvm.dbg.value(metadata i32 1, metadata !148, metadata !DIExpression()), !dbg !128
  br label %121, !dbg !216

121:                                              ; preds = %225, %120
  %.12 = phi i32 [ 1, %120 ], [ %226, %225 ], !dbg !219
  call void @llvm.dbg.value(metadata i32 %.12, metadata !148, metadata !DIExpression()), !dbg !128
  %122 = icmp slt i32 %.12, 39, !dbg !220
  br i1 %122, label %123, label %227, !dbg !222

123:                                              ; preds = %121
  call void @llvm.dbg.value(metadata i32 1, metadata !156, metadata !DIExpression()), !dbg !128
  br label %124, !dbg !223

124:                                              ; preds = %126, %123
  %.1 = phi i32 [ 1, %123 ], [ %224, %126 ], !dbg !226
  call void @llvm.dbg.value(metadata i32 %.1, metadata !156, metadata !DIExpression()), !dbg !128
  %125 = icmp slt i32 %.1, 39, !dbg !227
  br i1 %125, label %126, label %225, !dbg !229

126:                                              ; preds = %124
  %127 = add nsw i32 %.14, 1, !dbg !230
  %128 = sext i32 %127 to i64, !dbg !232
  %129 = getelementptr inbounds [40 x [40 x double]], [40 x [40 x double]]* getelementptr inbounds ([40 x [40 x [40 x double]]], [40 x [40 x [40 x double]]]* @B, i64 0, i64 0), i64 %128, !dbg !232
  %130 = sext i32 %.12 to i64, !dbg !232
  %131 = getelementptr inbounds [40 x [40 x double]], [40 x [40 x double]]* %129, i64 0, i64 %130, !dbg !232
  %132 = sext i32 %.1 to i64, !dbg !232
  %133 = getelementptr inbounds [40 x double], [40 x double]* %131, i64 0, i64 %132, !dbg !232
  %134 = load double, double* %133, align 8, !dbg !232
  %135 = sext i32 %.14 to i64, !dbg !233
  %136 = getelementptr inbounds [40 x [40 x double]], [40 x [40 x double]]* getelementptr inbounds ([40 x [40 x [40 x double]]], [40 x [40 x [40 x double]]]* @B, i64 0, i64 0), i64 %135, !dbg !233
  %137 = sext i32 %.12 to i64, !dbg !233
  %138 = getelementptr inbounds [40 x [40 x double]], [40 x [40 x double]]* %136, i64 0, i64 %137, !dbg !233
  %139 = sext i32 %.1 to i64, !dbg !233
  %140 = getelementptr inbounds [40 x double], [40 x double]* %138, i64 0, i64 %139, !dbg !233
  %141 = load double, double* %140, align 8, !dbg !233
  %142 = fmul double 2.000000e+00, %141, !dbg !234
  %143 = fsub double %134, %142, !dbg !235
  %144 = sub nsw i32 %.14, 1, !dbg !236
  %145 = sext i32 %144 to i64, !dbg !237
  %146 = getelementptr inbounds [40 x [40 x double]], [40 x [40 x double]]* getelementptr inbounds ([40 x [40 x [40 x double]]], [40 x [40 x [40 x double]]]* @B, i64 0, i64 0), i64 %145, !dbg !237
  %147 = sext i32 %.12 to i64, !dbg !237
  %148 = getelementptr inbounds [40 x [40 x double]], [40 x [40 x double]]* %146, i64 0, i64 %147, !dbg !237
  %149 = sext i32 %.1 to i64, !dbg !237
  %150 = getelementptr inbounds [40 x double], [40 x double]* %148, i64 0, i64 %149, !dbg !237
  %151 = load double, double* %150, align 8, !dbg !237
  %152 = fadd double %143, %151, !dbg !238
  %153 = fmul double 1.250000e-01, %152, !dbg !239
  %154 = sext i32 %.14 to i64, !dbg !240
  %155 = getelementptr inbounds [40 x [40 x double]], [40 x [40 x double]]* getelementptr inbounds ([40 x [40 x [40 x double]]], [40 x [40 x [40 x double]]]* @B, i64 0, i64 0), i64 %154, !dbg !240
  %156 = add nsw i32 %.12, 1, !dbg !241
  %157 = sext i32 %156 to i64, !dbg !240
  %158 = getelementptr inbounds [40 x [40 x double]], [40 x [40 x double]]* %155, i64 0, i64 %157, !dbg !240
  %159 = sext i32 %.1 to i64, !dbg !240
  %160 = getelementptr inbounds [40 x double], [40 x double]* %158, i64 0, i64 %159, !dbg !240
  %161 = load double, double* %160, align 8, !dbg !240
  %162 = sext i32 %.14 to i64, !dbg !242
  %163 = getelementptr inbounds [40 x [40 x double]], [40 x [40 x double]]* getelementptr inbounds ([40 x [40 x [40 x double]]], [40 x [40 x [40 x double]]]* @B, i64 0, i64 0), i64 %162, !dbg !242
  %164 = sext i32 %.12 to i64, !dbg !242
  %165 = getelementptr inbounds [40 x [40 x double]], [40 x [40 x double]]* %163, i64 0, i64 %164, !dbg !242
  %166 = sext i32 %.1 to i64, !dbg !242
  %167 = getelementptr inbounds [40 x double], [40 x double]* %165, i64 0, i64 %166, !dbg !242
  %168 = load double, double* %167, align 8, !dbg !242
  %169 = fmul double 2.000000e+00, %168, !dbg !243
  %170 = fsub double %161, %169, !dbg !244
  %171 = sext i32 %.14 to i64, !dbg !245
  %172 = getelementptr inbounds [40 x [40 x double]], [40 x [40 x double]]* getelementptr inbounds ([40 x [40 x [40 x double]]], [40 x [40 x [40 x double]]]* @B, i64 0, i64 0), i64 %171, !dbg !245
  %173 = sub nsw i32 %.12, 1, !dbg !246
  %174 = sext i32 %173 to i64, !dbg !245
  %175 = getelementptr inbounds [40 x [40 x double]], [40 x [40 x double]]* %172, i64 0, i64 %174, !dbg !245
  %176 = sext i32 %.1 to i64, !dbg !245
  %177 = getelementptr inbounds [40 x double], [40 x double]* %175, i64 0, i64 %176, !dbg !245
  %178 = load double, double* %177, align 8, !dbg !245
  %179 = fadd double %170, %178, !dbg !247
  %180 = fmul double 1.250000e-01, %179, !dbg !248
  %181 = fadd double %153, %180, !dbg !249
  %182 = sext i32 %.14 to i64, !dbg !250
  %183 = getelementptr inbounds [40 x [40 x double]], [40 x [40 x double]]* getelementptr inbounds ([40 x [40 x [40 x double]]], [40 x [40 x [40 x double]]]* @B, i64 0, i64 0), i64 %182, !dbg !250
  %184 = sext i32 %.12 to i64, !dbg !250
  %185 = getelementptr inbounds [40 x [40 x double]], [40 x [40 x double]]* %183, i64 0, i64 %184, !dbg !250
  %186 = add nsw i32 %.1, 1, !dbg !251
  %187 = sext i32 %186 to i64, !dbg !250
  %188 = getelementptr inbounds [40 x double], [40 x double]* %185, i64 0, i64 %187, !dbg !250
  %189 = load double, double* %188, align 8, !dbg !250
  %190 = sext i32 %.14 to i64, !dbg !252
  %191 = getelementptr inbounds [40 x [40 x double]], [40 x [40 x double]]* getelementptr inbounds ([40 x [40 x [40 x double]]], [40 x [40 x [40 x double]]]* @B, i64 0, i64 0), i64 %190, !dbg !252
  %192 = sext i32 %.12 to i64, !dbg !252
  %193 = getelementptr inbounds [40 x [40 x double]], [40 x [40 x double]]* %191, i64 0, i64 %192, !dbg !252
  %194 = sext i32 %.1 to i64, !dbg !252
  %195 = getelementptr inbounds [40 x double], [40 x double]* %193, i64 0, i64 %194, !dbg !252
  %196 = load double, double* %195, align 8, !dbg !252
  %197 = fmul double 2.000000e+00, %196, !dbg !253
  %198 = fsub double %189, %197, !dbg !254
  %199 = sext i32 %.14 to i64, !dbg !255
  %200 = getelementptr inbounds [40 x [40 x double]], [40 x [40 x double]]* getelementptr inbounds ([40 x [40 x [40 x double]]], [40 x [40 x [40 x double]]]* @B, i64 0, i64 0), i64 %199, !dbg !255
  %201 = sext i32 %.12 to i64, !dbg !255
  %202 = getelementptr inbounds [40 x [40 x double]], [40 x [40 x double]]* %200, i64 0, i64 %201, !dbg !255
  %203 = sub nsw i32 %.1, 1, !dbg !256
  %204 = sext i32 %203 to i64, !dbg !255
  %205 = getelementptr inbounds [40 x double], [40 x double]* %202, i64 0, i64 %204, !dbg !255
  %206 = load double, double* %205, align 8, !dbg !255
  %207 = fadd double %198, %206, !dbg !257
  %208 = fmul double 1.250000e-01, %207, !dbg !258
  %209 = fadd double %181, %208, !dbg !259
  %210 = sext i32 %.14 to i64, !dbg !260
  %211 = getelementptr inbounds [40 x [40 x double]], [40 x [40 x double]]* getelementptr inbounds ([40 x [40 x [40 x double]]], [40 x [40 x [40 x double]]]* @B, i64 0, i64 0), i64 %210, !dbg !260
  %212 = sext i32 %.12 to i64, !dbg !260
  %213 = getelementptr inbounds [40 x [40 x double]], [40 x [40 x double]]* %211, i64 0, i64 %212, !dbg !260
  %214 = sext i32 %.1 to i64, !dbg !260
  %215 = getelementptr inbounds [40 x double], [40 x double]* %213, i64 0, i64 %214, !dbg !260
  %216 = load double, double* %215, align 8, !dbg !260
  %217 = fadd double %209, %216, !dbg !261
  %218 = sext i32 %.14 to i64, !dbg !262
  %219 = getelementptr inbounds [40 x [40 x double]], [40 x [40 x double]]* getelementptr inbounds ([40 x [40 x [40 x double]]], [40 x [40 x [40 x double]]]* @A, i64 0, i64 0), i64 %218, !dbg !262
  %220 = sext i32 %.12 to i64, !dbg !262
  %221 = getelementptr inbounds [40 x [40 x double]], [40 x [40 x double]]* %219, i64 0, i64 %220, !dbg !262
  %222 = sext i32 %.1 to i64, !dbg !262
  %223 = getelementptr inbounds [40 x double], [40 x double]* %221, i64 0, i64 %222, !dbg !262
  store double %217, double* %223, align 8, !dbg !263
  %224 = add nsw i32 %.1, 1, !dbg !264
  call void @llvm.dbg.value(metadata i32 %224, metadata !156, metadata !DIExpression()), !dbg !128
  br label %124, !dbg !265, !llvm.loop !266

225:                                              ; preds = %124
  %226 = add nsw i32 %.12, 1, !dbg !268
  call void @llvm.dbg.value(metadata i32 %226, metadata !148, metadata !DIExpression()), !dbg !128
  br label %121, !dbg !269, !llvm.loop !270

227:                                              ; preds = %121
  %228 = add nsw i32 %.14, 1, !dbg !272
  call void @llvm.dbg.value(metadata i32 %228, metadata !140, metadata !DIExpression()), !dbg !128
  br label %118, !dbg !273, !llvm.loop !274

229:                                              ; preds = %118
  %230 = add nsw i32 %.05, 1, !dbg !276
  call void @llvm.dbg.value(metadata i32 %230, metadata !133, metadata !DIExpression()), !dbg !128
  br label %3, !dbg !277, !llvm.loop !278

231:                                              ; preds = %3
  ret i32 0, !dbg !280
}

; Function Attrs: noinline nounwind uwtable
define dso_local i32 @workload_checksum(i32 noundef %0) #0 !dbg !281 {
  call void @llvm.dbg.value(metadata i32 %0, metadata !284, metadata !DIExpression()), !dbg !285
  store i32 -2128831035, i32* @pb_hash, align 4, !dbg !286
  %2 = load i32, i32* @n, align 4, !dbg !287
  call void @print_array(i32 noundef %2, [40 x [40 x double]]* noundef getelementptr inbounds ([40 x [40 x [40 x double]]], [40 x [40 x [40 x double]]]* @A, i64 0, i64 0)), !dbg !288
  %3 = load i32, i32* @pb_hash, align 4, !dbg !289
  ret i32 %3, !dbg !290
}

; Function Attrs: noinline nounwind uwtable
define internal void @print_array(i32 noundef %0, [40 x [40 x double]]* noundef %1) #0 !dbg !291 {
  call void @llvm.dbg.value(metadata i32 %0, metadata !294, metadata !DIExpression()), !dbg !295
  call void @llvm.dbg.value(metadata [40 x [40 x double]]* %1, metadata !296, metadata !DIExpression()), !dbg !295
  %3 = load %struct._IO_FILE*, %struct._IO_FILE** @stderr, align 8, !dbg !297
  %4 = call i32 (%struct._IO_FILE*, i8*, ...) @pb_fprintf(%struct._IO_FILE* noundef %3, i8* noundef getelementptr inbounds ([23 x i8], [23 x i8]* @.str.2, i64 0, i64 0)), !dbg !297
  %5 = load %struct._IO_FILE*, %struct._IO_FILE** @stderr, align 8, !dbg !298
  %6 = call i32 (%struct._IO_FILE*, i8*, ...) @pb_fprintf(%struct._IO_FILE* noundef %5, i8* noundef getelementptr inbounds ([15 x i8], [15 x i8]* @.str.3, i64 0, i64 0), i8* noundef getelementptr inbounds ([2 x i8], [2 x i8]* @.str.4, i64 0, i64 0)), !dbg !298
  call void @llvm.dbg.value(metadata i32 0, metadata !299, metadata !DIExpression()), !dbg !295
  br label %7, !dbg !300

7:                                                ; preds = %42, %2
  %.02 = phi i32 [ 0, %2 ], [ %43, %42 ], !dbg !302
  call void @llvm.dbg.value(metadata i32 %.02, metadata !299, metadata !DIExpression()), !dbg !295
  %8 = icmp slt i32 %.02, %0, !dbg !303
  br i1 %8, label %9, label %44, !dbg !305

9:                                                ; preds = %7
  call void @llvm.dbg.value(metadata i32 0, metadata !306, metadata !DIExpression()), !dbg !295
  br label %10, !dbg !307

10:                                               ; preds = %39, %9
  %.01 = phi i32 [ 0, %9 ], [ %40, %39 ], !dbg !309
  call void @llvm.dbg.value(metadata i32 %.01, metadata !306, metadata !DIExpression()), !dbg !295
  %11 = icmp slt i32 %.01, %0, !dbg !310
  br i1 %11, label %12, label %41, !dbg !312

12:                                               ; preds = %10
  call void @llvm.dbg.value(metadata i32 0, metadata !313, metadata !DIExpression()), !dbg !295
  br label %13, !dbg !314

13:                                               ; preds = %36, %12
  %.0 = phi i32 [ 0, %12 ], [ %37, %36 ], !dbg !316
  call void @llvm.dbg.value(metadata i32 %.0, metadata !313, metadata !DIExpression()), !dbg !295
  %14 = icmp slt i32 %.0, %0, !dbg !317
  br i1 %14, label %15, label %38, !dbg !319

15:                                               ; preds = %13
  %16 = mul nsw i32 %.02, %0, !dbg !320
  %17 = mul nsw i32 %16, %0, !dbg !323
  %18 = mul nsw i32 %.01, %0, !dbg !324
  %19 = add nsw i32 %17, %18, !dbg !325
  %20 = add nsw i32 %19, %.0, !dbg !326
  %21 = srem i32 %20, 20, !dbg !327
  %22 = icmp eq i32 %21, 0, !dbg !328
  br i1 %22, label %23, label %26, !dbg !329

23:                                               ; preds = %15
  %24 = load %struct._IO_FILE*, %struct._IO_FILE** @stderr, align 8, !dbg !330
  %25 = call i32 (%struct._IO_FILE*, i8*, ...) @pb_fprintf(%struct._IO_FILE* noundef %24, i8* noundef getelementptr inbounds ([2 x i8], [2 x i8]* @.str.5, i64 0, i64 0)), !dbg !331
  br label %26, !dbg !331

26:                                               ; preds = %23, %15
  %27 = load %struct._IO_FILE*, %struct._IO_FILE** @stderr, align 8, !dbg !332
  %28 = sext i32 %.02 to i64, !dbg !333
  %29 = getelementptr inbounds [40 x [40 x double]], [40 x [40 x double]]* %1, i64 %28, !dbg !333
  %30 = sext i32 %.01 to i64, !dbg !333
  %31 = getelementptr inbounds [40 x [40 x double]], [40 x [40 x double]]* %29, i64 0, i64 %30, !dbg !333
  %32 = sext i32 %.0 to i64, !dbg !333
  %33 = getelementptr inbounds [40 x double], [40 x double]* %31, i64 0, i64 %32, !dbg !333
  %34 = load double, double* %33, align 8, !dbg !333
  %35 = call i32 (%struct._IO_FILE*, i8*, ...) @pb_fprintf(%struct._IO_FILE* noundef %27, i8* noundef getelementptr inbounds ([8 x i8], [8 x i8]* @.str.6, i64 0, i64 0), double noundef %34), !dbg !334
  br label %36, !dbg !335

36:                                               ; preds = %26
  %37 = add nsw i32 %.0, 1, !dbg !336
  call void @llvm.dbg.value(metadata i32 %37, metadata !313, metadata !DIExpression()), !dbg !295
  br label %13, !dbg !337, !llvm.loop !338

38:                                               ; preds = %13
  br label %39, !dbg !339

39:                                               ; preds = %38
  %40 = add nsw i32 %.01, 1, !dbg !340
  call void @llvm.dbg.value(metadata i32 %40, metadata !306, metadata !DIExpression()), !dbg !295
  br label %10, !dbg !341, !llvm.loop !342

41:                                               ; preds = %10
  br label %42, !dbg !343

42:                                               ; preds = %41
  %43 = add nsw i32 %.02, 1, !dbg !344
  call void @llvm.dbg.value(metadata i32 %43, metadata !299, metadata !DIExpression()), !dbg !295
  br label %7, !dbg !345, !llvm.loop !346

44:                                               ; preds = %7
  %45 = load %struct._IO_FILE*, %struct._IO_FILE** @stderr, align 8, !dbg !348
  %46 = call i32 (%struct._IO_FILE*, i8*, ...) @pb_fprintf(%struct._IO_FILE* noundef %45, i8* noundef getelementptr inbounds ([17 x i8], [17 x i8]* @.str.7, i64 0, i64 0), i8* noundef getelementptr inbounds ([2 x i8], [2 x i8]* @.str.4, i64 0, i64 0)), !dbg !348
  %47 = load %struct._IO_FILE*, %struct._IO_FILE** @stderr, align 8, !dbg !349
  %48 = call i32 (%struct._IO_FILE*, i8*, ...) @pb_fprintf(%struct._IO_FILE* noundef %47, i8* noundef getelementptr inbounds ([23 x i8], [23 x i8]* @.str.8, i64 0, i64 0)), !dbg !349
  ret void, !dbg !350
}

; Function Attrs: noinline nounwind uwtable
define internal i32 @pb_fprintf(%struct._IO_FILE* noundef %0, i8* noundef %1, ...) #0 !dbg !351 {
  %3 = alloca [768 x i8], align 16
  %4 = alloca [1 x %struct.__va_list_tag], align 16
  call void @llvm.dbg.value(metadata %struct._IO_FILE* %0, metadata !415, metadata !DIExpression()), !dbg !416
  call void @llvm.dbg.value(metadata i8* %1, metadata !417, metadata !DIExpression()), !dbg !416
  call void @llvm.dbg.declare(metadata [768 x i8]* %3, metadata !418, metadata !DIExpression()), !dbg !422
  call void @llvm.dbg.declare(metadata [1 x %struct.__va_list_tag]* %4, metadata !423, metadata !DIExpression()), !dbg !437
  %5 = getelementptr inbounds [1 x %struct.__va_list_tag], [1 x %struct.__va_list_tag]* %4, i64 0, i64 0, !dbg !438
  %6 = bitcast %struct.__va_list_tag* %5 to i8*, !dbg !438
  call void @llvm.va_start(i8* %6), !dbg !438
  %7 = getelementptr inbounds [768 x i8], [768 x i8]* %3, i64 0, i64 0, !dbg !439
  %8 = getelementptr inbounds [1 x %struct.__va_list_tag], [1 x %struct.__va_list_tag]* %4, i64 0, i64 0, !dbg !440
  %9 = call i32 @vsnprintf(i8* noundef %7, i64 noundef 768, i8* noundef %1, %struct.__va_list_tag* noundef %8) #6, !dbg !441
  call void @llvm.dbg.value(metadata i32 %9, metadata !442, metadata !DIExpression()), !dbg !416
  %10 = getelementptr inbounds [1 x %struct.__va_list_tag], [1 x %struct.__va_list_tag]* %4, i64 0, i64 0, !dbg !443
  %11 = bitcast %struct.__va_list_tag* %10 to i8*, !dbg !443
  call void @llvm.va_end(i8* %11), !dbg !443
  %12 = icmp slt i32 %9, 0, !dbg !444
  br i1 %12, label %16, label %13, !dbg !446

13:                                               ; preds = %2
  %14 = zext i32 %9 to i64, !dbg !447
  %15 = icmp uge i64 %14, 768, !dbg !448
  br i1 %15, label %16, label %17, !dbg !449

16:                                               ; preds = %13, %2
  call void @abort() #7, !dbg !450
  unreachable, !dbg !450

17:                                               ; preds = %13
  call void @llvm.dbg.value(metadata i32 0, metadata !451, metadata !DIExpression()), !dbg !453
  br label %18, !dbg !454

18:                                               ; preds = %29, %17
  %.0 = phi i32 [ 0, %17 ], [ %30, %29 ], !dbg !453
  call void @llvm.dbg.value(metadata i32 %.0, metadata !451, metadata !DIExpression()), !dbg !453
  %19 = icmp slt i32 %.0, %9, !dbg !455
  br i1 %19, label %20, label %31, !dbg !457

20:                                               ; preds = %18
  %21 = sext i32 %.0 to i64, !dbg !458
  %22 = getelementptr inbounds [768 x i8], [768 x i8]* %3, i64 0, i64 %21, !dbg !458
  %23 = load i8, i8* %22, align 1, !dbg !458
  %24 = zext i8 %23 to i32, !dbg !460
  %25 = load i32, i32* @pb_hash, align 4, !dbg !461
  %26 = xor i32 %25, %24, !dbg !461
  store i32 %26, i32* @pb_hash, align 4, !dbg !461
  %27 = load i32, i32* @pb_hash, align 4, !dbg !462
  %28 = mul i32 %27, 16777619, !dbg !462
  store i32 %28, i32* @pb_hash, align 4, !dbg !462
  br label %29, !dbg !463

29:                                               ; preds = %20
  %30 = add nsw i32 %.0, 1, !dbg !464
  call void @llvm.dbg.value(metadata i32 %30, metadata !451, metadata !DIExpression()), !dbg !453
  br label %18, !dbg !465, !llvm.loop !466

31:                                               ; preds = %18
  %32 = load i32, i32* @pb_emit, align 4, !dbg !468
  ret i32 %9, !dbg !469
}

; Function Attrs: nofree nosync nounwind willreturn
declare void @llvm.va_start(i8*) #3

; Function Attrs: nounwind
declare i32 @vsnprintf(i8* noundef, i64 noundef, i8* noundef, %struct.__va_list_tag* noundef) #4

; Function Attrs: nofree nosync nounwind willreturn
declare void @llvm.va_end(i8*) #3

; Function Attrs: noreturn nounwind
declare void @abort() #5

; Function Attrs: nofree nosync nounwind readnone speculatable willreturn
declare void @llvm.dbg.value(metadata, metadata, metadata) #1

attributes #0 = { noinline nounwind uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { nofree nosync nounwind readnone speculatable willreturn }
attributes #2 = { argmemonly nofree nounwind willreturn writeonly }
attributes #3 = { nofree nosync nounwind willreturn }
attributes #4 = { nounwind "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #5 = { noreturn nounwind "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #6 = { nounwind }
attributes #7 = { noreturn nounwind }

!llvm.dbg.cu = !{!2}
!llvm.module.flags = !{!42, !43, !44, !45, !46, !47, !48}
!llvm.ident = !{!49}

!0 = !DIGlobalVariableExpression(var: !1, expr: !DIExpression())
!1 = distinct !DIGlobalVariable(name: "n", scope: !2, file: !11, line: 111, type: !12, isLocal: false, isDefinition: true)
!2 = distinct !DICompileUnit(language: DW_LANG_C99, file: !3, producer: "Ubuntu clang version 14.0.0-1ubuntu1.1", isOptimized: false, runtimeVersion: 0, emissionKind: FullDebug, retainedTypes: !4, globals: !8, splitDebugInlining: false, nameTableKind: None)
!3 = !DIFile(filename: "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/triangular-20260929/suite/heat-3d/source/workload.c", directory: "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/triangular-20260929/suite/heat-3d/analysis-p", checksumkind: CSK_MD5, checksum: "e518c0e59e23961c4a259c9438496417")
!4 = !{!5, !6, !7}
!5 = !DIBasicType(name: "double", size: 64, encoding: DW_ATE_float)
!6 = !DIBasicType(name: "unsigned int", size: 32, encoding: DW_ATE_unsigned)
!7 = !DIBasicType(name: "unsigned char", size: 8, encoding: DW_ATE_unsigned_char)
!8 = !{!0, !9, !13, !26, !30, !33, !38, !40}
!9 = !DIGlobalVariableExpression(var: !10, expr: !DIExpression())
!10 = distinct !DIGlobalVariable(name: "tsteps", scope: !2, file: !11, line: 112, type: !12, isLocal: false, isDefinition: true)
!11 = !DIFile(filename: "source/workload.c", directory: "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/triangular-20260929/suite/heat-3d", checksumkind: CSK_MD5, checksum: "e518c0e59e23961c4a259c9438496417")
!12 = !DIBasicType(name: "int", size: 32, encoding: DW_ATE_signed)
!13 = !DIGlobalVariableExpression(var: !14, expr: !DIExpression())
!14 = distinct !DIGlobalVariable(name: "workload_jobs", scope: !2, file: !11, line: 130, type: !15, isLocal: false, isDefinition: true)
!15 = !DICompositeType(tag: DW_TAG_array_type, baseType: !16, size: 64, elements: !24)
!16 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !17)
!17 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !18, size: 64)
!18 = !DISubroutineType(types: !19)
!19 = !{!20}
!20 = !DIDerivedType(tag: DW_TAG_typedef, name: "uint32_t", file: !21, line: 26, baseType: !22)
!21 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/stdint-uintn.h", directory: "", checksumkind: CSK_MD5, checksum: "2bf2ae53c58c01b1a1b9383b5195125c")
!22 = !DIDerivedType(tag: DW_TAG_typedef, name: "__uint32_t", file: !23, line: 42, baseType: !6)
!23 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/types.h", directory: "", checksumkind: CSK_MD5, checksum: "d108b5f93a74c50510d7d9bc0ab36df9")
!24 = !{!25}
!25 = !DISubrange(count: 1)
!26 = !DIGlobalVariableExpression(var: !27, expr: !DIExpression())
!27 = distinct !DIGlobalVariable(name: "workload_expected", scope: !2, file: !11, line: 134, type: !28, isLocal: false, isDefinition: true)
!28 = !DICompositeType(tag: DW_TAG_array_type, baseType: !29, size: 32, elements: !24)
!29 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !20)
!30 = !DIGlobalVariableExpression(var: !31, expr: !DIExpression())
!31 = distinct !DIGlobalVariable(name: "pb_hash", scope: !2, file: !32, line: 9, type: !20, isLocal: true, isDefinition: true)
!32 = !DIFile(filename: "source/adapter.h", directory: "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/triangular-20260929/suite/heat-3d", checksumkind: CSK_MD5, checksum: "26a6068928b2092758f244a9d00163d7")
!33 = !DIGlobalVariableExpression(var: !34, expr: !DIExpression())
!34 = distinct !DIGlobalVariable(name: "A", scope: !2, file: !11, line: 34, type: !35, isLocal: false, isDefinition: true, align: 512)
!35 = !DICompositeType(tag: DW_TAG_array_type, baseType: !5, size: 4096000, elements: !36)
!36 = !{!37, !37, !37}
!37 = !DISubrange(count: 40)
!38 = !DIGlobalVariableExpression(var: !39, expr: !DIExpression())
!39 = distinct !DIGlobalVariable(name: "B", scope: !2, file: !11, line: 35, type: !35, isLocal: false, isDefinition: true, align: 512)
!40 = !DIGlobalVariableExpression(var: !41, expr: !DIExpression())
!41 = distinct !DIGlobalVariable(name: "pb_emit", scope: !2, file: !32, line: 10, type: !12, isLocal: true, isDefinition: true)
!42 = !{i32 7, !"Dwarf Version", i32 5}
!43 = !{i32 2, !"Debug Info Version", i32 3}
!44 = !{i32 1, !"wchar_size", i32 4}
!45 = !{i32 7, !"PIC Level", i32 2}
!46 = !{i32 7, !"PIE Level", i32 2}
!47 = !{i32 7, !"uwtable", i32 1}
!48 = !{i32 7, !"frame-pointer", i32 2}
!49 = !{!"Ubuntu clang version 14.0.0-1ubuntu1.1"}
!50 = distinct !DISubprogram(name: "workload_prepare", scope: !11, file: !11, line: 113, type: !51, scopeLine: 113, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !2, retainedNodes: !53)
!51 = !DISubroutineType(types: !52)
!52 = !{null}
!53 = !{}
!54 = !DILocation(line: 113, column: 30, scope: !50)
!55 = distinct !DISubprogram(name: "workload_reset", scope: !11, file: !11, line: 114, type: !56, scopeLine: 114, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !2, retainedNodes: !53)
!56 = !DISubroutineType(types: !57)
!57 = !{null, !6}
!58 = !DILocalVariable(name: "task", arg: 1, scope: !55, file: !11, line: 114, type: !6)
!59 = !DILocation(line: 0, scope: !55)
!60 = !DILocation(line: 116, column: 3, scope: !55)
!61 = !DILocation(line: 117, column: 3, scope: !55)
!62 = !DILocation(line: 118, column: 15, scope: !55)
!63 = !DILocation(line: 118, column: 3, scope: !55)
!64 = !DILocation(line: 119, column: 1, scope: !55)
!65 = distinct !DISubprogram(name: "init_array", scope: !11, file: !11, line: 37, type: !66, scopeLine: 40, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition, unit: !2, retainedNodes: !53)
!66 = !DISubroutineType(types: !67)
!67 = !{null, !12, !68, !68}
!68 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !69, size: 64)
!69 = !DICompositeType(tag: DW_TAG_array_type, baseType: !5, size: 102400, elements: !70)
!70 = !{!37, !37}
!71 = !DILocalVariable(name: "n", arg: 1, scope: !65, file: !11, line: 37, type: !12)
!72 = !DILocation(line: 0, scope: !65)
!73 = !DILocalVariable(name: "A", arg: 2, scope: !65, file: !11, line: 38, type: !68)
!74 = !DILocalVariable(name: "B", arg: 3, scope: !65, file: !11, line: 39, type: !68)
!75 = !DILocalVariable(name: "i", scope: !65, file: !11, line: 41, type: !12)
!76 = !DILocation(line: 43, column: 8, scope: !77)
!77 = distinct !DILexicalBlock(scope: !65, file: !11, line: 43, column: 3)
!78 = !DILocation(line: 0, scope: !77)
!79 = !DILocation(line: 43, column: 17, scope: !80)
!80 = distinct !DILexicalBlock(scope: !77, file: !11, line: 43, column: 3)
!81 = !DILocation(line: 43, column: 3, scope: !77)
!82 = !DILocalVariable(name: "j", scope: !65, file: !11, line: 41, type: !12)
!83 = !DILocation(line: 44, column: 10, scope: !84)
!84 = distinct !DILexicalBlock(scope: !80, file: !11, line: 44, column: 5)
!85 = !DILocation(line: 0, scope: !84)
!86 = !DILocation(line: 44, column: 19, scope: !87)
!87 = distinct !DILexicalBlock(scope: !84, file: !11, line: 44, column: 5)
!88 = !DILocation(line: 44, column: 5, scope: !84)
!89 = !DILocalVariable(name: "k", scope: !65, file: !11, line: 41, type: !12)
!90 = !DILocation(line: 45, column: 12, scope: !91)
!91 = distinct !DILexicalBlock(scope: !87, file: !11, line: 45, column: 7)
!92 = !DILocation(line: 0, scope: !91)
!93 = !DILocation(line: 45, column: 21, scope: !94)
!94 = distinct !DILexicalBlock(scope: !91, file: !11, line: 45, column: 7)
!95 = !DILocation(line: 45, column: 7, scope: !91)
!96 = !DILocation(line: 46, column: 50, scope: !94)
!97 = !DILocation(line: 46, column: 58, scope: !94)
!98 = !DILocation(line: 46, column: 54, scope: !94)
!99 = !DILocation(line: 46, column: 35, scope: !94)
!100 = !DILocation(line: 46, column: 62, scope: !94)
!101 = !DILocation(line: 46, column: 69, scope: !94)
!102 = !DILocation(line: 46, column: 67, scope: !94)
!103 = !DILocation(line: 46, column: 22, scope: !94)
!104 = !DILocation(line: 46, column: 33, scope: !94)
!105 = !DILocation(line: 46, column: 9, scope: !94)
!106 = !DILocation(line: 46, column: 20, scope: !94)
!107 = !DILocation(line: 45, column: 27, scope: !94)
!108 = !DILocation(line: 45, column: 7, scope: !94)
!109 = distinct !{!109, !95, !110, !111}
!110 = !DILocation(line: 46, column: 71, scope: !91)
!111 = !{!"llvm.loop.mustprogress"}
!112 = !DILocation(line: 44, column: 25, scope: !87)
!113 = !DILocation(line: 44, column: 5, scope: !87)
!114 = distinct !{!114, !88, !115, !111}
!115 = !DILocation(line: 46, column: 71, scope: !84)
!116 = !DILocation(line: 43, column: 23, scope: !80)
!117 = !DILocation(line: 43, column: 3, scope: !80)
!118 = distinct !{!118, !81, !119, !111}
!119 = !DILocation(line: 46, column: 71, scope: !77)
!120 = !DILocation(line: 47, column: 1, scope: !65)
!121 = distinct !DISubprogram(name: "task_job_polybench", scope: !11, file: !11, line: 120, type: !18, scopeLine: 120, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !2, retainedNodes: !53)
!122 = !DILocation(line: 121, column: 19, scope: !121)
!123 = !DILocation(line: 121, column: 27, scope: !121)
!124 = !DILocalVariable(name: "tsteps", arg: 1, scope: !125, file: !11, line: 75, type: !12)
!125 = distinct !DISubprogram(name: "kernel_heat_3d", scope: !11, file: !11, line: 75, type: !126, scopeLine: 79, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition, unit: !2, retainedNodes: !53)
!126 = !DISubroutineType(types: !127)
!127 = !{null, !12, !12, !68, !68}
!128 = !DILocation(line: 0, scope: !125, inlinedAt: !129)
!129 = distinct !DILocation(line: 121, column: 3, scope: !121)
!130 = !DILocalVariable(name: "n", arg: 2, scope: !125, file: !11, line: 76, type: !12)
!131 = !DILocalVariable(name: "A", arg: 3, scope: !125, file: !11, line: 77, type: !68)
!132 = !DILocalVariable(name: "B", arg: 4, scope: !125, file: !11, line: 78, type: !68)
!133 = !DILocalVariable(name: "t", scope: !125, file: !11, line: 80, type: !12)
!134 = !DILocation(line: 83, column: 10, scope: !135, inlinedAt: !129)
!135 = distinct !DILexicalBlock(scope: !125, file: !11, line: 83, column: 5)
!136 = !DILocation(line: 0, scope: !135, inlinedAt: !129)
!137 = !DILocation(line: 83, column: 19, scope: !138, inlinedAt: !129)
!138 = distinct !DILexicalBlock(scope: !135, file: !11, line: 83, column: 5)
!139 = !DILocation(line: 83, column: 5, scope: !135, inlinedAt: !129)
!140 = !DILocalVariable(name: "i", scope: !125, file: !11, line: 80, type: !12)
!141 = !DILocation(line: 84, column: 14, scope: !142, inlinedAt: !129)
!142 = distinct !DILexicalBlock(scope: !143, file: !11, line: 84, column: 9)
!143 = distinct !DILexicalBlock(scope: !138, file: !11, line: 83, column: 35)
!144 = !DILocation(line: 0, scope: !142, inlinedAt: !129)
!145 = !DILocation(line: 84, column: 23, scope: !146, inlinedAt: !129)
!146 = distinct !DILexicalBlock(scope: !142, file: !11, line: 84, column: 9)
!147 = !DILocation(line: 84, column: 9, scope: !142, inlinedAt: !129)
!148 = !DILocalVariable(name: "j", scope: !125, file: !11, line: 80, type: !12)
!149 = !DILocation(line: 85, column: 18, scope: !150, inlinedAt: !129)
!150 = distinct !DILexicalBlock(scope: !151, file: !11, line: 85, column: 13)
!151 = distinct !DILexicalBlock(scope: !146, file: !11, line: 84, column: 39)
!152 = !DILocation(line: 0, scope: !150, inlinedAt: !129)
!153 = !DILocation(line: 85, column: 27, scope: !154, inlinedAt: !129)
!154 = distinct !DILexicalBlock(scope: !150, file: !11, line: 85, column: 13)
!155 = !DILocation(line: 85, column: 13, scope: !150, inlinedAt: !129)
!156 = !DILocalVariable(name: "k", scope: !125, file: !11, line: 80, type: !12)
!157 = !DILocation(line: 86, column: 22, scope: !158, inlinedAt: !129)
!158 = distinct !DILexicalBlock(scope: !159, file: !11, line: 86, column: 17)
!159 = distinct !DILexicalBlock(scope: !154, file: !11, line: 85, column: 43)
!160 = !DILocation(line: 0, scope: !158, inlinedAt: !129)
!161 = !DILocation(line: 86, column: 31, scope: !162, inlinedAt: !129)
!162 = distinct !DILexicalBlock(scope: !158, file: !11, line: 86, column: 17)
!163 = !DILocation(line: 86, column: 17, scope: !158, inlinedAt: !129)
!164 = !DILocation(line: 87, column: 60, scope: !165, inlinedAt: !129)
!165 = distinct !DILexicalBlock(scope: !162, file: !11, line: 86, column: 47)
!166 = !DILocation(line: 87, column: 57, scope: !165, inlinedAt: !129)
!167 = !DILocation(line: 87, column: 90, scope: !165, inlinedAt: !129)
!168 = !DILocation(line: 87, column: 88, scope: !165, inlinedAt: !129)
!169 = !DILocation(line: 87, column: 70, scope: !165, inlinedAt: !129)
!170 = !DILocation(line: 87, column: 106, scope: !165, inlinedAt: !129)
!171 = !DILocation(line: 87, column: 103, scope: !165, inlinedAt: !129)
!172 = !DILocation(line: 87, column: 101, scope: !165, inlinedAt: !129)
!173 = !DILocation(line: 87, column: 54, scope: !165, inlinedAt: !129)
!174 = !DILocation(line: 88, column: 57, scope: !165, inlinedAt: !129)
!175 = !DILocation(line: 88, column: 63, scope: !165, inlinedAt: !129)
!176 = !DILocation(line: 88, column: 90, scope: !165, inlinedAt: !129)
!177 = !DILocation(line: 88, column: 88, scope: !165, inlinedAt: !129)
!178 = !DILocation(line: 88, column: 70, scope: !165, inlinedAt: !129)
!179 = !DILocation(line: 88, column: 103, scope: !165, inlinedAt: !129)
!180 = !DILocation(line: 88, column: 109, scope: !165, inlinedAt: !129)
!181 = !DILocation(line: 88, column: 101, scope: !165, inlinedAt: !129)
!182 = !DILocation(line: 88, column: 54, scope: !165, inlinedAt: !129)
!183 = !DILocation(line: 88, column: 34, scope: !165, inlinedAt: !129)
!184 = !DILocation(line: 89, column: 57, scope: !165, inlinedAt: !129)
!185 = !DILocation(line: 89, column: 66, scope: !165, inlinedAt: !129)
!186 = !DILocation(line: 89, column: 90, scope: !165, inlinedAt: !129)
!187 = !DILocation(line: 89, column: 88, scope: !165, inlinedAt: !129)
!188 = !DILocation(line: 89, column: 70, scope: !165, inlinedAt: !129)
!189 = !DILocation(line: 89, column: 103, scope: !165, inlinedAt: !129)
!190 = !DILocation(line: 89, column: 112, scope: !165, inlinedAt: !129)
!191 = !DILocation(line: 89, column: 101, scope: !165, inlinedAt: !129)
!192 = !DILocation(line: 89, column: 54, scope: !165, inlinedAt: !129)
!193 = !DILocation(line: 89, column: 34, scope: !165, inlinedAt: !129)
!194 = !DILocation(line: 90, column: 36, scope: !165, inlinedAt: !129)
!195 = !DILocation(line: 90, column: 34, scope: !165, inlinedAt: !129)
!196 = !DILocation(line: 87, column: 21, scope: !165, inlinedAt: !129)
!197 = !DILocation(line: 87, column: 32, scope: !165, inlinedAt: !129)
!198 = !DILocation(line: 86, column: 43, scope: !162, inlinedAt: !129)
!199 = !DILocation(line: 86, column: 17, scope: !162, inlinedAt: !129)
!200 = distinct !{!200, !163, !201, !111}
!201 = !DILocation(line: 91, column: 17, scope: !158, inlinedAt: !129)
!202 = !DILocation(line: 85, column: 39, scope: !154, inlinedAt: !129)
!203 = !DILocation(line: 85, column: 13, scope: !154, inlinedAt: !129)
!204 = distinct !{!204, !155, !205, !111}
!205 = !DILocation(line: 92, column: 13, scope: !150, inlinedAt: !129)
!206 = !DILocation(line: 84, column: 35, scope: !146, inlinedAt: !129)
!207 = !DILocation(line: 84, column: 9, scope: !146, inlinedAt: !129)
!208 = distinct !{!208, !147, !209, !111}
!209 = !DILocation(line: 93, column: 9, scope: !142, inlinedAt: !129)
!210 = !DILocation(line: 94, column: 14, scope: !211, inlinedAt: !129)
!211 = distinct !DILexicalBlock(scope: !143, file: !11, line: 94, column: 9)
!212 = !DILocation(line: 0, scope: !211, inlinedAt: !129)
!213 = !DILocation(line: 94, column: 23, scope: !214, inlinedAt: !129)
!214 = distinct !DILexicalBlock(scope: !211, file: !11, line: 94, column: 9)
!215 = !DILocation(line: 94, column: 9, scope: !211, inlinedAt: !129)
!216 = !DILocation(line: 95, column: 17, scope: !217, inlinedAt: !129)
!217 = distinct !DILexicalBlock(scope: !218, file: !11, line: 95, column: 12)
!218 = distinct !DILexicalBlock(scope: !214, file: !11, line: 94, column: 39)
!219 = !DILocation(line: 0, scope: !217, inlinedAt: !129)
!220 = !DILocation(line: 95, column: 26, scope: !221, inlinedAt: !129)
!221 = distinct !DILexicalBlock(scope: !217, file: !11, line: 95, column: 12)
!222 = !DILocation(line: 95, column: 12, scope: !217, inlinedAt: !129)
!223 = !DILocation(line: 96, column: 21, scope: !224, inlinedAt: !129)
!224 = distinct !DILexicalBlock(scope: !225, file: !11, line: 96, column: 16)
!225 = distinct !DILexicalBlock(scope: !221, file: !11, line: 95, column: 42)
!226 = !DILocation(line: 0, scope: !224, inlinedAt: !129)
!227 = !DILocation(line: 96, column: 30, scope: !228, inlinedAt: !129)
!228 = distinct !DILexicalBlock(scope: !224, file: !11, line: 96, column: 16)
!229 = !DILocation(line: 96, column: 16, scope: !224, inlinedAt: !129)
!230 = !DILocation(line: 97, column: 59, scope: !231, inlinedAt: !129)
!231 = distinct !DILexicalBlock(scope: !228, file: !11, line: 96, column: 46)
!232 = !DILocation(line: 97, column: 56, scope: !231, inlinedAt: !129)
!233 = !DILocation(line: 97, column: 89, scope: !231, inlinedAt: !129)
!234 = !DILocation(line: 97, column: 87, scope: !231, inlinedAt: !129)
!235 = !DILocation(line: 97, column: 69, scope: !231, inlinedAt: !129)
!236 = !DILocation(line: 97, column: 105, scope: !231, inlinedAt: !129)
!237 = !DILocation(line: 97, column: 102, scope: !231, inlinedAt: !129)
!238 = !DILocation(line: 97, column: 100, scope: !231, inlinedAt: !129)
!239 = !DILocation(line: 97, column: 53, scope: !231, inlinedAt: !129)
!240 = !DILocation(line: 98, column: 56, scope: !231, inlinedAt: !129)
!241 = !DILocation(line: 98, column: 62, scope: !231, inlinedAt: !129)
!242 = !DILocation(line: 98, column: 89, scope: !231, inlinedAt: !129)
!243 = !DILocation(line: 98, column: 87, scope: !231, inlinedAt: !129)
!244 = !DILocation(line: 98, column: 69, scope: !231, inlinedAt: !129)
!245 = !DILocation(line: 98, column: 102, scope: !231, inlinedAt: !129)
!246 = !DILocation(line: 98, column: 108, scope: !231, inlinedAt: !129)
!247 = !DILocation(line: 98, column: 100, scope: !231, inlinedAt: !129)
!248 = !DILocation(line: 98, column: 53, scope: !231, inlinedAt: !129)
!249 = !DILocation(line: 98, column: 33, scope: !231, inlinedAt: !129)
!250 = !DILocation(line: 99, column: 56, scope: !231, inlinedAt: !129)
!251 = !DILocation(line: 99, column: 65, scope: !231, inlinedAt: !129)
!252 = !DILocation(line: 99, column: 89, scope: !231, inlinedAt: !129)
!253 = !DILocation(line: 99, column: 87, scope: !231, inlinedAt: !129)
!254 = !DILocation(line: 99, column: 69, scope: !231, inlinedAt: !129)
!255 = !DILocation(line: 99, column: 102, scope: !231, inlinedAt: !129)
!256 = !DILocation(line: 99, column: 111, scope: !231, inlinedAt: !129)
!257 = !DILocation(line: 99, column: 100, scope: !231, inlinedAt: !129)
!258 = !DILocation(line: 99, column: 53, scope: !231, inlinedAt: !129)
!259 = !DILocation(line: 99, column: 33, scope: !231, inlinedAt: !129)
!260 = !DILocation(line: 100, column: 35, scope: !231, inlinedAt: !129)
!261 = !DILocation(line: 100, column: 33, scope: !231, inlinedAt: !129)
!262 = !DILocation(line: 97, column: 20, scope: !231, inlinedAt: !129)
!263 = !DILocation(line: 97, column: 31, scope: !231, inlinedAt: !129)
!264 = !DILocation(line: 96, column: 42, scope: !228, inlinedAt: !129)
!265 = !DILocation(line: 96, column: 16, scope: !228, inlinedAt: !129)
!266 = distinct !{!266, !229, !267, !111}
!267 = !DILocation(line: 101, column: 16, scope: !224, inlinedAt: !129)
!268 = !DILocation(line: 95, column: 38, scope: !221, inlinedAt: !129)
!269 = !DILocation(line: 95, column: 12, scope: !221, inlinedAt: !129)
!270 = distinct !{!270, !222, !271, !111}
!271 = !DILocation(line: 102, column: 12, scope: !217, inlinedAt: !129)
!272 = !DILocation(line: 94, column: 35, scope: !214, inlinedAt: !129)
!273 = !DILocation(line: 94, column: 9, scope: !214, inlinedAt: !129)
!274 = distinct !{!274, !215, !275, !111}
!275 = !DILocation(line: 103, column: 8, scope: !211, inlinedAt: !129)
!276 = !DILocation(line: 83, column: 31, scope: !138, inlinedAt: !129)
!277 = !DILocation(line: 83, column: 5, scope: !138, inlinedAt: !129)
!278 = distinct !{!278, !139, !279, !111}
!279 = !DILocation(line: 104, column: 5, scope: !135, inlinedAt: !129)
!280 = !DILocation(line: 122, column: 3, scope: !121)
!281 = distinct !DISubprogram(name: "workload_checksum", scope: !11, file: !11, line: 124, type: !282, scopeLine: 124, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !2, retainedNodes: !53)
!282 = !DISubroutineType(types: !283)
!283 = !{!20, !6}
!284 = !DILocalVariable(name: "task", arg: 1, scope: !281, file: !11, line: 124, type: !6)
!285 = !DILocation(line: 0, scope: !281)
!286 = !DILocation(line: 126, column: 11, scope: !281)
!287 = !DILocation(line: 127, column: 15, scope: !281)
!288 = !DILocation(line: 127, column: 3, scope: !281)
!289 = !DILocation(line: 128, column: 10, scope: !281)
!290 = !DILocation(line: 128, column: 3, scope: !281)
!291 = distinct !DISubprogram(name: "print_array", scope: !11, file: !11, line: 53, type: !292, scopeLine: 56, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition, unit: !2, retainedNodes: !53)
!292 = !DISubroutineType(types: !293)
!293 = !{null, !12, !68}
!294 = !DILocalVariable(name: "n", arg: 1, scope: !291, file: !11, line: 53, type: !12)
!295 = !DILocation(line: 0, scope: !291)
!296 = !DILocalVariable(name: "A", arg: 2, scope: !291, file: !11, line: 54, type: !68)
!297 = !DILocation(line: 59, column: 3, scope: !291)
!298 = !DILocation(line: 60, column: 3, scope: !291)
!299 = !DILocalVariable(name: "i", scope: !291, file: !11, line: 57, type: !12)
!300 = !DILocation(line: 61, column: 8, scope: !301)
!301 = distinct !DILexicalBlock(scope: !291, file: !11, line: 61, column: 3)
!302 = !DILocation(line: 0, scope: !301)
!303 = !DILocation(line: 61, column: 17, scope: !304)
!304 = distinct !DILexicalBlock(scope: !301, file: !11, line: 61, column: 3)
!305 = !DILocation(line: 61, column: 3, scope: !301)
!306 = !DILocalVariable(name: "j", scope: !291, file: !11, line: 57, type: !12)
!307 = !DILocation(line: 62, column: 10, scope: !308)
!308 = distinct !DILexicalBlock(scope: !304, file: !11, line: 62, column: 5)
!309 = !DILocation(line: 0, scope: !308)
!310 = !DILocation(line: 62, column: 19, scope: !311)
!311 = distinct !DILexicalBlock(scope: !308, file: !11, line: 62, column: 5)
!312 = !DILocation(line: 62, column: 5, scope: !308)
!313 = !DILocalVariable(name: "k", scope: !291, file: !11, line: 57, type: !12)
!314 = !DILocation(line: 63, column: 12, scope: !315)
!315 = distinct !DILexicalBlock(scope: !311, file: !11, line: 63, column: 7)
!316 = !DILocation(line: 0, scope: !315)
!317 = !DILocation(line: 63, column: 21, scope: !318)
!318 = distinct !DILexicalBlock(scope: !315, file: !11, line: 63, column: 7)
!319 = !DILocation(line: 63, column: 7, scope: !315)
!320 = !DILocation(line: 64, column: 17, scope: !321)
!321 = distinct !DILexicalBlock(scope: !322, file: !11, line: 64, column: 14)
!322 = distinct !DILexicalBlock(scope: !318, file: !11, line: 63, column: 31)
!323 = !DILocation(line: 64, column: 21, scope: !321)
!324 = !DILocation(line: 64, column: 29, scope: !321)
!325 = !DILocation(line: 64, column: 25, scope: !321)
!326 = !DILocation(line: 64, column: 33, scope: !321)
!327 = !DILocation(line: 64, column: 38, scope: !321)
!328 = !DILocation(line: 64, column: 43, scope: !321)
!329 = !DILocation(line: 64, column: 14, scope: !322)
!330 = !DILocation(line: 64, column: 57, scope: !321)
!331 = !DILocation(line: 64, column: 49, scope: !321)
!332 = !DILocation(line: 65, column: 18, scope: !322)
!333 = !DILocation(line: 65, column: 63, scope: !322)
!334 = !DILocation(line: 65, column: 10, scope: !322)
!335 = !DILocation(line: 66, column: 7, scope: !322)
!336 = !DILocation(line: 63, column: 27, scope: !318)
!337 = !DILocation(line: 63, column: 7, scope: !318)
!338 = distinct !{!338, !319, !339, !111}
!339 = !DILocation(line: 66, column: 7, scope: !315)
!340 = !DILocation(line: 62, column: 25, scope: !311)
!341 = !DILocation(line: 62, column: 5, scope: !311)
!342 = distinct !{!342, !312, !343, !111}
!343 = !DILocation(line: 66, column: 7, scope: !308)
!344 = !DILocation(line: 61, column: 23, scope: !304)
!345 = !DILocation(line: 61, column: 3, scope: !304)
!346 = distinct !{!346, !305, !347, !111}
!347 = !DILocation(line: 66, column: 7, scope: !301)
!348 = !DILocation(line: 67, column: 3, scope: !291)
!349 = !DILocation(line: 68, column: 3, scope: !291)
!350 = !DILocation(line: 69, column: 1, scope: !291)
!351 = distinct !DISubprogram(name: "pb_fprintf", scope: !32, file: !32, line: 13, type: !352, scopeLine: 14, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition, unit: !2, retainedNodes: !53)
!352 = !DISubroutineType(types: !353)
!353 = !{!12, !354, !413, null}
!354 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !355, size: 64)
!355 = !DIDerivedType(tag: DW_TAG_typedef, name: "FILE", file: !356, line: 7, baseType: !357)
!356 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/types/FILE.h", directory: "", checksumkind: CSK_MD5, checksum: "571f9fb6223c42439075fdde11a0de5d")
!357 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "_IO_FILE", file: !358, line: 49, size: 1728, elements: !359)
!358 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/types/struct_FILE.h", directory: "", checksumkind: CSK_MD5, checksum: "1bad07471b7974df4ecc1d1c2ca207e6")
!359 = !{!360, !361, !364, !365, !366, !367, !368, !369, !370, !371, !372, !373, !374, !377, !379, !380, !381, !384, !386, !388, !390, !393, !395, !398, !401, !402, !404, !408, !409}
!360 = !DIDerivedType(tag: DW_TAG_member, name: "_flags", scope: !357, file: !358, line: 51, baseType: !12, size: 32)
!361 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_read_ptr", scope: !357, file: !358, line: 54, baseType: !362, size: 64, offset: 64)
!362 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !363, size: 64)
!363 = !DIBasicType(name: "char", size: 8, encoding: DW_ATE_signed_char)
!364 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_read_end", scope: !357, file: !358, line: 55, baseType: !362, size: 64, offset: 128)
!365 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_read_base", scope: !357, file: !358, line: 56, baseType: !362, size: 64, offset: 192)
!366 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_write_base", scope: !357, file: !358, line: 57, baseType: !362, size: 64, offset: 256)
!367 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_write_ptr", scope: !357, file: !358, line: 58, baseType: !362, size: 64, offset: 320)
!368 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_write_end", scope: !357, file: !358, line: 59, baseType: !362, size: 64, offset: 384)
!369 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_buf_base", scope: !357, file: !358, line: 60, baseType: !362, size: 64, offset: 448)
!370 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_buf_end", scope: !357, file: !358, line: 61, baseType: !362, size: 64, offset: 512)
!371 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_save_base", scope: !357, file: !358, line: 64, baseType: !362, size: 64, offset: 576)
!372 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_backup_base", scope: !357, file: !358, line: 65, baseType: !362, size: 64, offset: 640)
!373 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_save_end", scope: !357, file: !358, line: 66, baseType: !362, size: 64, offset: 704)
!374 = !DIDerivedType(tag: DW_TAG_member, name: "_markers", scope: !357, file: !358, line: 68, baseType: !375, size: 64, offset: 768)
!375 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !376, size: 64)
!376 = !DICompositeType(tag: DW_TAG_structure_type, name: "_IO_marker", file: !358, line: 36, flags: DIFlagFwdDecl)
!377 = !DIDerivedType(tag: DW_TAG_member, name: "_chain", scope: !357, file: !358, line: 70, baseType: !378, size: 64, offset: 832)
!378 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !357, size: 64)
!379 = !DIDerivedType(tag: DW_TAG_member, name: "_fileno", scope: !357, file: !358, line: 72, baseType: !12, size: 32, offset: 896)
!380 = !DIDerivedType(tag: DW_TAG_member, name: "_flags2", scope: !357, file: !358, line: 73, baseType: !12, size: 32, offset: 928)
!381 = !DIDerivedType(tag: DW_TAG_member, name: "_old_offset", scope: !357, file: !358, line: 74, baseType: !382, size: 64, offset: 960)
!382 = !DIDerivedType(tag: DW_TAG_typedef, name: "__off_t", file: !23, line: 152, baseType: !383)
!383 = !DIBasicType(name: "long", size: 64, encoding: DW_ATE_signed)
!384 = !DIDerivedType(tag: DW_TAG_member, name: "_cur_column", scope: !357, file: !358, line: 77, baseType: !385, size: 16, offset: 1024)
!385 = !DIBasicType(name: "unsigned short", size: 16, encoding: DW_ATE_unsigned)
!386 = !DIDerivedType(tag: DW_TAG_member, name: "_vtable_offset", scope: !357, file: !358, line: 78, baseType: !387, size: 8, offset: 1040)
!387 = !DIBasicType(name: "signed char", size: 8, encoding: DW_ATE_signed_char)
!388 = !DIDerivedType(tag: DW_TAG_member, name: "_shortbuf", scope: !357, file: !358, line: 79, baseType: !389, size: 8, offset: 1048)
!389 = !DICompositeType(tag: DW_TAG_array_type, baseType: !363, size: 8, elements: !24)
!390 = !DIDerivedType(tag: DW_TAG_member, name: "_lock", scope: !357, file: !358, line: 81, baseType: !391, size: 64, offset: 1088)
!391 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !392, size: 64)
!392 = !DIDerivedType(tag: DW_TAG_typedef, name: "_IO_lock_t", file: !358, line: 43, baseType: null)
!393 = !DIDerivedType(tag: DW_TAG_member, name: "_offset", scope: !357, file: !358, line: 89, baseType: !394, size: 64, offset: 1152)
!394 = !DIDerivedType(tag: DW_TAG_typedef, name: "__off64_t", file: !23, line: 153, baseType: !383)
!395 = !DIDerivedType(tag: DW_TAG_member, name: "_codecvt", scope: !357, file: !358, line: 91, baseType: !396, size: 64, offset: 1216)
!396 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !397, size: 64)
!397 = !DICompositeType(tag: DW_TAG_structure_type, name: "_IO_codecvt", file: !358, line: 37, flags: DIFlagFwdDecl)
!398 = !DIDerivedType(tag: DW_TAG_member, name: "_wide_data", scope: !357, file: !358, line: 92, baseType: !399, size: 64, offset: 1280)
!399 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !400, size: 64)
!400 = !DICompositeType(tag: DW_TAG_structure_type, name: "_IO_wide_data", file: !358, line: 38, flags: DIFlagFwdDecl)
!401 = !DIDerivedType(tag: DW_TAG_member, name: "_freeres_list", scope: !357, file: !358, line: 93, baseType: !378, size: 64, offset: 1344)
!402 = !DIDerivedType(tag: DW_TAG_member, name: "_freeres_buf", scope: !357, file: !358, line: 94, baseType: !403, size: 64, offset: 1408)
!403 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: null, size: 64)
!404 = !DIDerivedType(tag: DW_TAG_member, name: "__pad5", scope: !357, file: !358, line: 95, baseType: !405, size: 64, offset: 1472)
!405 = !DIDerivedType(tag: DW_TAG_typedef, name: "size_t", file: !406, line: 46, baseType: !407)
!406 = !DIFile(filename: "/usr/lib/llvm-14/lib/clang/14.0.0/include/stddef.h", directory: "", checksumkind: CSK_MD5, checksum: "2499dd2361b915724b073282bea3a7bc")
!407 = !DIBasicType(name: "unsigned long", size: 64, encoding: DW_ATE_unsigned)
!408 = !DIDerivedType(tag: DW_TAG_member, name: "_mode", scope: !357, file: !358, line: 96, baseType: !12, size: 32, offset: 1536)
!409 = !DIDerivedType(tag: DW_TAG_member, name: "_unused2", scope: !357, file: !358, line: 98, baseType: !410, size: 160, offset: 1568)
!410 = !DICompositeType(tag: DW_TAG_array_type, baseType: !363, size: 160, elements: !411)
!411 = !{!412}
!412 = !DISubrange(count: 20)
!413 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !414, size: 64)
!414 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !363)
!415 = !DILocalVariable(name: "stream", arg: 1, scope: !351, file: !32, line: 13, type: !354)
!416 = !DILocation(line: 0, scope: !351)
!417 = !DILocalVariable(name: "format", arg: 2, scope: !351, file: !32, line: 13, type: !413)
!418 = !DILocalVariable(name: "buffer", scope: !351, file: !32, line: 15, type: !419)
!419 = !DICompositeType(tag: DW_TAG_array_type, baseType: !363, size: 6144, elements: !420)
!420 = !{!421}
!421 = !DISubrange(count: 768)
!422 = !DILocation(line: 15, column: 10, scope: !351)
!423 = !DILocalVariable(name: "args", scope: !351, file: !32, line: 16, type: !424)
!424 = !DIDerivedType(tag: DW_TAG_typedef, name: "va_list", file: !425, line: 52, baseType: !426)
!425 = !DIFile(filename: "/usr/include/stdio.h", directory: "", checksumkind: CSK_MD5, checksum: "f31eefcc3f15835fc5a4023a625cf609")
!426 = !DIDerivedType(tag: DW_TAG_typedef, name: "__gnuc_va_list", file: !427, line: 32, baseType: !428)
!427 = !DIFile(filename: "/usr/lib/llvm-14/lib/clang/14.0.0/include/stdarg.h", directory: "", checksumkind: CSK_MD5, checksum: "4de3cbd931b589d291e5c39387aecf82")
!428 = !DIDerivedType(tag: DW_TAG_typedef, name: "__builtin_va_list", file: !429, baseType: !430)
!429 = !DIFile(filename: "source/workload.c", directory: "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/triangular-20260929/suite/heat-3d")
!430 = !DICompositeType(tag: DW_TAG_array_type, baseType: !431, size: 192, elements: !24)
!431 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "__va_list_tag", size: 192, elements: !432)
!432 = !{!433, !434, !435, !436}
!433 = !DIDerivedType(tag: DW_TAG_member, name: "gp_offset", scope: !431, file: !429, line: 16, baseType: !6, size: 32)
!434 = !DIDerivedType(tag: DW_TAG_member, name: "fp_offset", scope: !431, file: !429, line: 16, baseType: !6, size: 32, offset: 32)
!435 = !DIDerivedType(tag: DW_TAG_member, name: "overflow_arg_area", scope: !431, file: !429, line: 16, baseType: !403, size: 64, offset: 64)
!436 = !DIDerivedType(tag: DW_TAG_member, name: "reg_save_area", scope: !431, file: !429, line: 16, baseType: !403, size: 64, offset: 128)
!437 = !DILocation(line: 16, column: 13, scope: !351)
!438 = !DILocation(line: 17, column: 5, scope: !351)
!439 = !DILocation(line: 18, column: 27, scope: !351)
!440 = !DILocation(line: 18, column: 59, scope: !351)
!441 = !DILocation(line: 18, column: 17, scope: !351)
!442 = !DILocalVariable(name: "count", scope: !351, file: !32, line: 18, type: !12)
!443 = !DILocation(line: 19, column: 5, scope: !351)
!444 = !DILocation(line: 20, column: 15, scope: !445)
!445 = distinct !DILexicalBlock(scope: !351, file: !32, line: 20, column: 9)
!446 = !DILocation(line: 20, column: 19, scope: !445)
!447 = !DILocation(line: 20, column: 22, scope: !445)
!448 = !DILocation(line: 20, column: 38, scope: !445)
!449 = !DILocation(line: 20, column: 9, scope: !351)
!450 = !DILocation(line: 20, column: 57, scope: !445)
!451 = !DILocalVariable(name: "i", scope: !452, file: !32, line: 21, type: !12)
!452 = distinct !DILexicalBlock(scope: !351, file: !32, line: 21, column: 5)
!453 = !DILocation(line: 0, scope: !452)
!454 = !DILocation(line: 21, column: 10, scope: !452)
!455 = !DILocation(line: 21, column: 23, scope: !456)
!456 = distinct !DILexicalBlock(scope: !452, file: !32, line: 21, column: 5)
!457 = !DILocation(line: 21, column: 5, scope: !452)
!458 = !DILocation(line: 22, column: 35, scope: !459)
!459 = distinct !DILexicalBlock(scope: !456, file: !32, line: 21, column: 37)
!460 = !DILocation(line: 22, column: 20, scope: !459)
!461 = !DILocation(line: 22, column: 17, scope: !459)
!462 = !DILocation(line: 23, column: 17, scope: !459)
!463 = !DILocation(line: 24, column: 5, scope: !459)
!464 = !DILocation(line: 21, column: 32, scope: !456)
!465 = !DILocation(line: 21, column: 5, scope: !456)
!466 = distinct !{!466, !457, !467, !111}
!467 = !DILocation(line: 24, column: 5, scope: !452)
!468 = !DILocation(line: 29, column: 11, scope: !351)
!469 = !DILocation(line: 31, column: 5, scope: !351)
