; ModuleID = 'inlined.ll'
source_filename = "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/triangular-20260929/suite/heat-3d/source/workload.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

@n = external dso_local global i32, align 4, !dbg !0
@tsteps = external dso_local global i32, align 4, !dbg !9
@A = external dso_local global [40 x [40 x [40 x double]]], section ".chaser_data.A", align 64, !dbg !13
@B = external dso_local global [40 x [40 x [40 x double]]], section ".chaser_data.B", align 64, !dbg !18
@.str = hidden unnamed_addr constant [12 x i8] c"ape.analyze\00", section "llvm.metadata"
@.str.1 = hidden unnamed_addr constant [122 x i8] c"/workspace/experiments-array-support/chaser/.cache/periodic-polybench/triangular-20260929/suite/heat-3d/source/workload.c\00", section "llvm.metadata"
@.str.2 = hidden unnamed_addr constant [23 x i8] c"==BEGIN DUMP_ARRAYS==\0A\00", align 1
@.str.3 = hidden unnamed_addr constant [15 x i8] c"begin dump: %s\00", align 1
@.str.4 = hidden unnamed_addr constant [2 x i8] c"A\00", align 1
@.str.5 = hidden unnamed_addr constant [2 x i8] c"\0A\00", align 1
@.str.6 = hidden unnamed_addr constant [8 x i8] c"%0.2lf \00", align 1
@.str.7 = hidden unnamed_addr constant [17 x i8] c"\0Aend   dump: %s\0A\00", align 1
@.str.8 = hidden unnamed_addr constant [23 x i8] c"==END   DUMP_ARRAYS==\0A\00", align 1
@llvm.global.annotations = appending global [1 x { i8*, i8*, i8*, i32, i8* }] [{ i8*, i8*, i8*, i32, i8* } { i8* bitcast (i32 ()* @task_job_polybench to i8*), i8* getelementptr inbounds ([12 x i8], [12 x i8]* @.str, i32 0, i32 0), i8* getelementptr inbounds ([122 x i8], [122 x i8]* @.str.1, i32 0, i32 0), i32 120, i8* null }], section "llvm.metadata"

; Function Attrs: noinline nounwind uwtable
define dso_local i32 @task_job_polybench() #0 !dbg !28 {
  %1 = load i32, i32* @tsteps, align 4, !dbg !36
  %2 = load i32, i32* @n, align 4, !dbg !37
  call void @llvm.dbg.value(metadata i32 %1, metadata !38, metadata !DIExpression()), !dbg !45
  call void @llvm.dbg.value(metadata i32 %2, metadata !47, metadata !DIExpression()), !dbg !45
  call void @llvm.dbg.value(metadata [40 x [40 x double]]* getelementptr inbounds ([40 x [40 x [40 x double]]], [40 x [40 x [40 x double]]]* @A, i64 0, i64 0), metadata !48, metadata !DIExpression()), !dbg !45
  call void @llvm.dbg.value(metadata [40 x [40 x double]]* getelementptr inbounds ([40 x [40 x [40 x double]]], [40 x [40 x [40 x double]]]* @B, i64 0, i64 0), metadata !49, metadata !DIExpression()), !dbg !45
  call void @llvm.dbg.value(metadata i32 1, metadata !50, metadata !DIExpression()), !dbg !45
  br label %3, !dbg !51

3:                                                ; preds = %229, %0
  %.05 = phi i32 [ 1, %0 ], [ %230, %229 ], !dbg !53
  call void @llvm.dbg.value(metadata i32 %.05, metadata !50, metadata !DIExpression()), !dbg !45
  %4 = icmp sle i32 %.05, 100, !dbg !54
  br i1 %4, label %5, label %231, !dbg !56

5:                                                ; preds = %3
  call void @llvm.dbg.value(metadata i32 1, metadata !57, metadata !DIExpression()), !dbg !45
  br label %6, !dbg !58

6:                                                ; preds = %115, %5
  %.03 = phi i32 [ 1, %5 ], [ %116, %115 ], !dbg !61
  call void @llvm.dbg.value(metadata i32 %.03, metadata !57, metadata !DIExpression()), !dbg !45
  %7 = icmp slt i32 %.03, 39, !dbg !62
  br i1 %7, label %8, label %117, !dbg !64

8:                                                ; preds = %6
  call void @llvm.dbg.value(metadata i32 1, metadata !65, metadata !DIExpression()), !dbg !45
  br label %9, !dbg !66

9:                                                ; preds = %113, %8
  %.01 = phi i32 [ 1, %8 ], [ %114, %113 ], !dbg !69
  call void @llvm.dbg.value(metadata i32 %.01, metadata !65, metadata !DIExpression()), !dbg !45
  %10 = icmp slt i32 %.01, 39, !dbg !70
  br i1 %10, label %11, label %115, !dbg !72

11:                                               ; preds = %9
  call void @llvm.dbg.value(metadata i32 1, metadata !73, metadata !DIExpression()), !dbg !45
  br label %12, !dbg !74

12:                                               ; preds = %14, %11
  %.0 = phi i32 [ 1, %11 ], [ %112, %14 ], !dbg !77
  call void @llvm.dbg.value(metadata i32 %.0, metadata !73, metadata !DIExpression()), !dbg !45
  %13 = icmp slt i32 %.0, 39, !dbg !78
  br i1 %13, label %14, label %113, !dbg !80

14:                                               ; preds = %12
  %15 = add nsw i32 %.03, 1, !dbg !81
  %16 = sext i32 %15 to i64, !dbg !83
  %17 = getelementptr inbounds [40 x [40 x double]], [40 x [40 x double]]* getelementptr inbounds ([40 x [40 x [40 x double]]], [40 x [40 x [40 x double]]]* @A, i64 0, i64 0), i64 %16, !dbg !83
  %18 = sext i32 %.01 to i64, !dbg !83
  %19 = getelementptr inbounds [40 x [40 x double]], [40 x [40 x double]]* %17, i64 0, i64 %18, !dbg !83
  %20 = sext i32 %.0 to i64, !dbg !83
  %21 = getelementptr inbounds [40 x double], [40 x double]* %19, i64 0, i64 %20, !dbg !83
  %22 = load double, double* %21, align 8, !dbg !83
  %23 = sext i32 %.03 to i64, !dbg !84
  %24 = getelementptr inbounds [40 x [40 x double]], [40 x [40 x double]]* getelementptr inbounds ([40 x [40 x [40 x double]]], [40 x [40 x [40 x double]]]* @A, i64 0, i64 0), i64 %23, !dbg !84
  %25 = sext i32 %.01 to i64, !dbg !84
  %26 = getelementptr inbounds [40 x [40 x double]], [40 x [40 x double]]* %24, i64 0, i64 %25, !dbg !84
  %27 = sext i32 %.0 to i64, !dbg !84
  %28 = getelementptr inbounds [40 x double], [40 x double]* %26, i64 0, i64 %27, !dbg !84
  %29 = load double, double* %28, align 8, !dbg !84
  %30 = fmul double 2.000000e+00, %29, !dbg !85
  %31 = fsub double %22, %30, !dbg !86
  %32 = sub nsw i32 %.03, 1, !dbg !87
  %33 = sext i32 %32 to i64, !dbg !88
  %34 = getelementptr inbounds [40 x [40 x double]], [40 x [40 x double]]* getelementptr inbounds ([40 x [40 x [40 x double]]], [40 x [40 x [40 x double]]]* @A, i64 0, i64 0), i64 %33, !dbg !88
  %35 = sext i32 %.01 to i64, !dbg !88
  %36 = getelementptr inbounds [40 x [40 x double]], [40 x [40 x double]]* %34, i64 0, i64 %35, !dbg !88
  %37 = sext i32 %.0 to i64, !dbg !88
  %38 = getelementptr inbounds [40 x double], [40 x double]* %36, i64 0, i64 %37, !dbg !88
  %39 = load double, double* %38, align 8, !dbg !88
  %40 = fadd double %31, %39, !dbg !89
  %41 = fmul double 1.250000e-01, %40, !dbg !90
  %42 = sext i32 %.03 to i64, !dbg !91
  %43 = getelementptr inbounds [40 x [40 x double]], [40 x [40 x double]]* getelementptr inbounds ([40 x [40 x [40 x double]]], [40 x [40 x [40 x double]]]* @A, i64 0, i64 0), i64 %42, !dbg !91
  %44 = add nsw i32 %.01, 1, !dbg !92
  %45 = sext i32 %44 to i64, !dbg !91
  %46 = getelementptr inbounds [40 x [40 x double]], [40 x [40 x double]]* %43, i64 0, i64 %45, !dbg !91
  %47 = sext i32 %.0 to i64, !dbg !91
  %48 = getelementptr inbounds [40 x double], [40 x double]* %46, i64 0, i64 %47, !dbg !91
  %49 = load double, double* %48, align 8, !dbg !91
  %50 = sext i32 %.03 to i64, !dbg !93
  %51 = getelementptr inbounds [40 x [40 x double]], [40 x [40 x double]]* getelementptr inbounds ([40 x [40 x [40 x double]]], [40 x [40 x [40 x double]]]* @A, i64 0, i64 0), i64 %50, !dbg !93
  %52 = sext i32 %.01 to i64, !dbg !93
  %53 = getelementptr inbounds [40 x [40 x double]], [40 x [40 x double]]* %51, i64 0, i64 %52, !dbg !93
  %54 = sext i32 %.0 to i64, !dbg !93
  %55 = getelementptr inbounds [40 x double], [40 x double]* %53, i64 0, i64 %54, !dbg !93
  %56 = load double, double* %55, align 8, !dbg !93
  %57 = fmul double 2.000000e+00, %56, !dbg !94
  %58 = fsub double %49, %57, !dbg !95
  %59 = sext i32 %.03 to i64, !dbg !96
  %60 = getelementptr inbounds [40 x [40 x double]], [40 x [40 x double]]* getelementptr inbounds ([40 x [40 x [40 x double]]], [40 x [40 x [40 x double]]]* @A, i64 0, i64 0), i64 %59, !dbg !96
  %61 = sub nsw i32 %.01, 1, !dbg !97
  %62 = sext i32 %61 to i64, !dbg !96
  %63 = getelementptr inbounds [40 x [40 x double]], [40 x [40 x double]]* %60, i64 0, i64 %62, !dbg !96
  %64 = sext i32 %.0 to i64, !dbg !96
  %65 = getelementptr inbounds [40 x double], [40 x double]* %63, i64 0, i64 %64, !dbg !96
  %66 = load double, double* %65, align 8, !dbg !96
  %67 = fadd double %58, %66, !dbg !98
  %68 = fmul double 1.250000e-01, %67, !dbg !99
  %69 = fadd double %41, %68, !dbg !100
  %70 = sext i32 %.03 to i64, !dbg !101
  %71 = getelementptr inbounds [40 x [40 x double]], [40 x [40 x double]]* getelementptr inbounds ([40 x [40 x [40 x double]]], [40 x [40 x [40 x double]]]* @A, i64 0, i64 0), i64 %70, !dbg !101
  %72 = sext i32 %.01 to i64, !dbg !101
  %73 = getelementptr inbounds [40 x [40 x double]], [40 x [40 x double]]* %71, i64 0, i64 %72, !dbg !101
  %74 = add nsw i32 %.0, 1, !dbg !102
  %75 = sext i32 %74 to i64, !dbg !101
  %76 = getelementptr inbounds [40 x double], [40 x double]* %73, i64 0, i64 %75, !dbg !101
  %77 = load double, double* %76, align 8, !dbg !101
  %78 = sext i32 %.03 to i64, !dbg !103
  %79 = getelementptr inbounds [40 x [40 x double]], [40 x [40 x double]]* getelementptr inbounds ([40 x [40 x [40 x double]]], [40 x [40 x [40 x double]]]* @A, i64 0, i64 0), i64 %78, !dbg !103
  %80 = sext i32 %.01 to i64, !dbg !103
  %81 = getelementptr inbounds [40 x [40 x double]], [40 x [40 x double]]* %79, i64 0, i64 %80, !dbg !103
  %82 = sext i32 %.0 to i64, !dbg !103
  %83 = getelementptr inbounds [40 x double], [40 x double]* %81, i64 0, i64 %82, !dbg !103
  %84 = load double, double* %83, align 8, !dbg !103
  %85 = fmul double 2.000000e+00, %84, !dbg !104
  %86 = fsub double %77, %85, !dbg !105
  %87 = sext i32 %.03 to i64, !dbg !106
  %88 = getelementptr inbounds [40 x [40 x double]], [40 x [40 x double]]* getelementptr inbounds ([40 x [40 x [40 x double]]], [40 x [40 x [40 x double]]]* @A, i64 0, i64 0), i64 %87, !dbg !106
  %89 = sext i32 %.01 to i64, !dbg !106
  %90 = getelementptr inbounds [40 x [40 x double]], [40 x [40 x double]]* %88, i64 0, i64 %89, !dbg !106
  %91 = sub nsw i32 %.0, 1, !dbg !107
  %92 = sext i32 %91 to i64, !dbg !106
  %93 = getelementptr inbounds [40 x double], [40 x double]* %90, i64 0, i64 %92, !dbg !106
  %94 = load double, double* %93, align 8, !dbg !106
  %95 = fadd double %86, %94, !dbg !108
  %96 = fmul double 1.250000e-01, %95, !dbg !109
  %97 = fadd double %69, %96, !dbg !110
  %98 = sext i32 %.03 to i64, !dbg !111
  %99 = getelementptr inbounds [40 x [40 x double]], [40 x [40 x double]]* getelementptr inbounds ([40 x [40 x [40 x double]]], [40 x [40 x [40 x double]]]* @A, i64 0, i64 0), i64 %98, !dbg !111
  %100 = sext i32 %.01 to i64, !dbg !111
  %101 = getelementptr inbounds [40 x [40 x double]], [40 x [40 x double]]* %99, i64 0, i64 %100, !dbg !111
  %102 = sext i32 %.0 to i64, !dbg !111
  %103 = getelementptr inbounds [40 x double], [40 x double]* %101, i64 0, i64 %102, !dbg !111
  %104 = load double, double* %103, align 8, !dbg !111
  %105 = fadd double %97, %104, !dbg !112
  %106 = sext i32 %.03 to i64, !dbg !113
  %107 = getelementptr inbounds [40 x [40 x double]], [40 x [40 x double]]* getelementptr inbounds ([40 x [40 x [40 x double]]], [40 x [40 x [40 x double]]]* @B, i64 0, i64 0), i64 %106, !dbg !113
  %108 = sext i32 %.01 to i64, !dbg !113
  %109 = getelementptr inbounds [40 x [40 x double]], [40 x [40 x double]]* %107, i64 0, i64 %108, !dbg !113
  %110 = sext i32 %.0 to i64, !dbg !113
  %111 = getelementptr inbounds [40 x double], [40 x double]* %109, i64 0, i64 %110, !dbg !113
  store double %105, double* %111, align 8, !dbg !114
  %112 = add nsw i32 %.0, 1, !dbg !115
  call void @llvm.dbg.value(metadata i32 %112, metadata !73, metadata !DIExpression()), !dbg !45
  br label %12, !dbg !116, !llvm.loop !117

113:                                              ; preds = %12
  %114 = add nsw i32 %.01, 1, !dbg !120
  call void @llvm.dbg.value(metadata i32 %114, metadata !65, metadata !DIExpression()), !dbg !45
  br label %9, !dbg !121, !llvm.loop !122

115:                                              ; preds = %9
  %116 = add nsw i32 %.03, 1, !dbg !124
  call void @llvm.dbg.value(metadata i32 %116, metadata !57, metadata !DIExpression()), !dbg !45
  br label %6, !dbg !125, !llvm.loop !126

117:                                              ; preds = %6
  call void @llvm.dbg.value(metadata i32 1, metadata !57, metadata !DIExpression()), !dbg !45
  br label %118, !dbg !128

118:                                              ; preds = %227, %117
  %.14 = phi i32 [ 1, %117 ], [ %228, %227 ], !dbg !130
  call void @llvm.dbg.value(metadata i32 %.14, metadata !57, metadata !DIExpression()), !dbg !45
  %119 = icmp slt i32 %.14, 39, !dbg !131
  br i1 %119, label %120, label %229, !dbg !133

120:                                              ; preds = %118
  call void @llvm.dbg.value(metadata i32 1, metadata !65, metadata !DIExpression()), !dbg !45
  br label %121, !dbg !134

121:                                              ; preds = %225, %120
  %.12 = phi i32 [ 1, %120 ], [ %226, %225 ], !dbg !137
  call void @llvm.dbg.value(metadata i32 %.12, metadata !65, metadata !DIExpression()), !dbg !45
  %122 = icmp slt i32 %.12, 39, !dbg !138
  br i1 %122, label %123, label %227, !dbg !140

123:                                              ; preds = %121
  call void @llvm.dbg.value(metadata i32 1, metadata !73, metadata !DIExpression()), !dbg !45
  br label %124, !dbg !141

124:                                              ; preds = %126, %123
  %.1 = phi i32 [ 1, %123 ], [ %224, %126 ], !dbg !144
  call void @llvm.dbg.value(metadata i32 %.1, metadata !73, metadata !DIExpression()), !dbg !45
  %125 = icmp slt i32 %.1, 39, !dbg !145
  br i1 %125, label %126, label %225, !dbg !147

126:                                              ; preds = %124
  %127 = add nsw i32 %.14, 1, !dbg !148
  %128 = sext i32 %127 to i64, !dbg !150
  %129 = getelementptr inbounds [40 x [40 x double]], [40 x [40 x double]]* getelementptr inbounds ([40 x [40 x [40 x double]]], [40 x [40 x [40 x double]]]* @B, i64 0, i64 0), i64 %128, !dbg !150
  %130 = sext i32 %.12 to i64, !dbg !150
  %131 = getelementptr inbounds [40 x [40 x double]], [40 x [40 x double]]* %129, i64 0, i64 %130, !dbg !150
  %132 = sext i32 %.1 to i64, !dbg !150
  %133 = getelementptr inbounds [40 x double], [40 x double]* %131, i64 0, i64 %132, !dbg !150
  %134 = load double, double* %133, align 8, !dbg !150
  %135 = sext i32 %.14 to i64, !dbg !151
  %136 = getelementptr inbounds [40 x [40 x double]], [40 x [40 x double]]* getelementptr inbounds ([40 x [40 x [40 x double]]], [40 x [40 x [40 x double]]]* @B, i64 0, i64 0), i64 %135, !dbg !151
  %137 = sext i32 %.12 to i64, !dbg !151
  %138 = getelementptr inbounds [40 x [40 x double]], [40 x [40 x double]]* %136, i64 0, i64 %137, !dbg !151
  %139 = sext i32 %.1 to i64, !dbg !151
  %140 = getelementptr inbounds [40 x double], [40 x double]* %138, i64 0, i64 %139, !dbg !151
  %141 = load double, double* %140, align 8, !dbg !151
  %142 = fmul double 2.000000e+00, %141, !dbg !152
  %143 = fsub double %134, %142, !dbg !153
  %144 = sub nsw i32 %.14, 1, !dbg !154
  %145 = sext i32 %144 to i64, !dbg !155
  %146 = getelementptr inbounds [40 x [40 x double]], [40 x [40 x double]]* getelementptr inbounds ([40 x [40 x [40 x double]]], [40 x [40 x [40 x double]]]* @B, i64 0, i64 0), i64 %145, !dbg !155
  %147 = sext i32 %.12 to i64, !dbg !155
  %148 = getelementptr inbounds [40 x [40 x double]], [40 x [40 x double]]* %146, i64 0, i64 %147, !dbg !155
  %149 = sext i32 %.1 to i64, !dbg !155
  %150 = getelementptr inbounds [40 x double], [40 x double]* %148, i64 0, i64 %149, !dbg !155
  %151 = load double, double* %150, align 8, !dbg !155
  %152 = fadd double %143, %151, !dbg !156
  %153 = fmul double 1.250000e-01, %152, !dbg !157
  %154 = sext i32 %.14 to i64, !dbg !158
  %155 = getelementptr inbounds [40 x [40 x double]], [40 x [40 x double]]* getelementptr inbounds ([40 x [40 x [40 x double]]], [40 x [40 x [40 x double]]]* @B, i64 0, i64 0), i64 %154, !dbg !158
  %156 = add nsw i32 %.12, 1, !dbg !159
  %157 = sext i32 %156 to i64, !dbg !158
  %158 = getelementptr inbounds [40 x [40 x double]], [40 x [40 x double]]* %155, i64 0, i64 %157, !dbg !158
  %159 = sext i32 %.1 to i64, !dbg !158
  %160 = getelementptr inbounds [40 x double], [40 x double]* %158, i64 0, i64 %159, !dbg !158
  %161 = load double, double* %160, align 8, !dbg !158
  %162 = sext i32 %.14 to i64, !dbg !160
  %163 = getelementptr inbounds [40 x [40 x double]], [40 x [40 x double]]* getelementptr inbounds ([40 x [40 x [40 x double]]], [40 x [40 x [40 x double]]]* @B, i64 0, i64 0), i64 %162, !dbg !160
  %164 = sext i32 %.12 to i64, !dbg !160
  %165 = getelementptr inbounds [40 x [40 x double]], [40 x [40 x double]]* %163, i64 0, i64 %164, !dbg !160
  %166 = sext i32 %.1 to i64, !dbg !160
  %167 = getelementptr inbounds [40 x double], [40 x double]* %165, i64 0, i64 %166, !dbg !160
  %168 = load double, double* %167, align 8, !dbg !160
  %169 = fmul double 2.000000e+00, %168, !dbg !161
  %170 = fsub double %161, %169, !dbg !162
  %171 = sext i32 %.14 to i64, !dbg !163
  %172 = getelementptr inbounds [40 x [40 x double]], [40 x [40 x double]]* getelementptr inbounds ([40 x [40 x [40 x double]]], [40 x [40 x [40 x double]]]* @B, i64 0, i64 0), i64 %171, !dbg !163
  %173 = sub nsw i32 %.12, 1, !dbg !164
  %174 = sext i32 %173 to i64, !dbg !163
  %175 = getelementptr inbounds [40 x [40 x double]], [40 x [40 x double]]* %172, i64 0, i64 %174, !dbg !163
  %176 = sext i32 %.1 to i64, !dbg !163
  %177 = getelementptr inbounds [40 x double], [40 x double]* %175, i64 0, i64 %176, !dbg !163
  %178 = load double, double* %177, align 8, !dbg !163
  %179 = fadd double %170, %178, !dbg !165
  %180 = fmul double 1.250000e-01, %179, !dbg !166
  %181 = fadd double %153, %180, !dbg !167
  %182 = sext i32 %.14 to i64, !dbg !168
  %183 = getelementptr inbounds [40 x [40 x double]], [40 x [40 x double]]* getelementptr inbounds ([40 x [40 x [40 x double]]], [40 x [40 x [40 x double]]]* @B, i64 0, i64 0), i64 %182, !dbg !168
  %184 = sext i32 %.12 to i64, !dbg !168
  %185 = getelementptr inbounds [40 x [40 x double]], [40 x [40 x double]]* %183, i64 0, i64 %184, !dbg !168
  %186 = add nsw i32 %.1, 1, !dbg !169
  %187 = sext i32 %186 to i64, !dbg !168
  %188 = getelementptr inbounds [40 x double], [40 x double]* %185, i64 0, i64 %187, !dbg !168
  %189 = load double, double* %188, align 8, !dbg !168
  %190 = sext i32 %.14 to i64, !dbg !170
  %191 = getelementptr inbounds [40 x [40 x double]], [40 x [40 x double]]* getelementptr inbounds ([40 x [40 x [40 x double]]], [40 x [40 x [40 x double]]]* @B, i64 0, i64 0), i64 %190, !dbg !170
  %192 = sext i32 %.12 to i64, !dbg !170
  %193 = getelementptr inbounds [40 x [40 x double]], [40 x [40 x double]]* %191, i64 0, i64 %192, !dbg !170
  %194 = sext i32 %.1 to i64, !dbg !170
  %195 = getelementptr inbounds [40 x double], [40 x double]* %193, i64 0, i64 %194, !dbg !170
  %196 = load double, double* %195, align 8, !dbg !170
  %197 = fmul double 2.000000e+00, %196, !dbg !171
  %198 = fsub double %189, %197, !dbg !172
  %199 = sext i32 %.14 to i64, !dbg !173
  %200 = getelementptr inbounds [40 x [40 x double]], [40 x [40 x double]]* getelementptr inbounds ([40 x [40 x [40 x double]]], [40 x [40 x [40 x double]]]* @B, i64 0, i64 0), i64 %199, !dbg !173
  %201 = sext i32 %.12 to i64, !dbg !173
  %202 = getelementptr inbounds [40 x [40 x double]], [40 x [40 x double]]* %200, i64 0, i64 %201, !dbg !173
  %203 = sub nsw i32 %.1, 1, !dbg !174
  %204 = sext i32 %203 to i64, !dbg !173
  %205 = getelementptr inbounds [40 x double], [40 x double]* %202, i64 0, i64 %204, !dbg !173
  %206 = load double, double* %205, align 8, !dbg !173
  %207 = fadd double %198, %206, !dbg !175
  %208 = fmul double 1.250000e-01, %207, !dbg !176
  %209 = fadd double %181, %208, !dbg !177
  %210 = sext i32 %.14 to i64, !dbg !178
  %211 = getelementptr inbounds [40 x [40 x double]], [40 x [40 x double]]* getelementptr inbounds ([40 x [40 x [40 x double]]], [40 x [40 x [40 x double]]]* @B, i64 0, i64 0), i64 %210, !dbg !178
  %212 = sext i32 %.12 to i64, !dbg !178
  %213 = getelementptr inbounds [40 x [40 x double]], [40 x [40 x double]]* %211, i64 0, i64 %212, !dbg !178
  %214 = sext i32 %.1 to i64, !dbg !178
  %215 = getelementptr inbounds [40 x double], [40 x double]* %213, i64 0, i64 %214, !dbg !178
  %216 = load double, double* %215, align 8, !dbg !178
  %217 = fadd double %209, %216, !dbg !179
  %218 = sext i32 %.14 to i64, !dbg !180
  %219 = getelementptr inbounds [40 x [40 x double]], [40 x [40 x double]]* getelementptr inbounds ([40 x [40 x [40 x double]]], [40 x [40 x [40 x double]]]* @A, i64 0, i64 0), i64 %218, !dbg !180
  %220 = sext i32 %.12 to i64, !dbg !180
  %221 = getelementptr inbounds [40 x [40 x double]], [40 x [40 x double]]* %219, i64 0, i64 %220, !dbg !180
  %222 = sext i32 %.1 to i64, !dbg !180
  %223 = getelementptr inbounds [40 x double], [40 x double]* %221, i64 0, i64 %222, !dbg !180
  store double %217, double* %223, align 8, !dbg !181
  %224 = add nsw i32 %.1, 1, !dbg !182
  call void @llvm.dbg.value(metadata i32 %224, metadata !73, metadata !DIExpression()), !dbg !45
  br label %124, !dbg !183, !llvm.loop !184

225:                                              ; preds = %124
  %226 = add nsw i32 %.12, 1, !dbg !186
  call void @llvm.dbg.value(metadata i32 %226, metadata !65, metadata !DIExpression()), !dbg !45
  br label %121, !dbg !187, !llvm.loop !188

227:                                              ; preds = %121
  %228 = add nsw i32 %.14, 1, !dbg !190
  call void @llvm.dbg.value(metadata i32 %228, metadata !57, metadata !DIExpression()), !dbg !45
  br label %118, !dbg !191, !llvm.loop !192

229:                                              ; preds = %118
  %230 = add nsw i32 %.05, 1, !dbg !194
  call void @llvm.dbg.value(metadata i32 %230, metadata !50, metadata !DIExpression()), !dbg !45
  br label %3, !dbg !195, !llvm.loop !196

231:                                              ; preds = %3
  ret i32 0, !dbg !198
}

; Function Attrs: nofree nosync nounwind readnone speculatable willreturn
declare void @llvm.dbg.value(metadata, metadata, metadata) #1

attributes #0 = { noinline nounwind uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { nofree nosync nounwind readnone speculatable willreturn }

!llvm.dbg.cu = !{!2}
!llvm.module.flags = !{!20, !21, !22, !23, !24, !25, !26}
!llvm.ident = !{!27}

!0 = !DIGlobalVariableExpression(var: !1, expr: !DIExpression())
!1 = distinct !DIGlobalVariable(name: "n", scope: !2, file: !11, line: 111, type: !12, isLocal: false, isDefinition: true)
!2 = distinct !DICompileUnit(language: DW_LANG_C99, file: !3, producer: "Ubuntu clang version 14.0.0-1ubuntu1.1", isOptimized: false, runtimeVersion: 0, emissionKind: FullDebug, retainedTypes: !4, globals: !8, splitDebugInlining: false, nameTableKind: None)
!3 = !DIFile(filename: "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/triangular-20260929/suite/heat-3d/source/workload.c", directory: "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/triangular-20260929/suite/heat-3d/analysis-native", checksumkind: CSK_MD5, checksum: "e518c0e59e23961c4a259c9438496417")
!4 = !{!5, !6, !7}
!5 = !DIBasicType(name: "double", size: 64, encoding: DW_ATE_float)
!6 = !DIBasicType(name: "unsigned int", size: 32, encoding: DW_ATE_unsigned)
!7 = !DIBasicType(name: "unsigned char", size: 8, encoding: DW_ATE_unsigned_char)
!8 = !{!0, !9, !13, !18}
!9 = !DIGlobalVariableExpression(var: !10, expr: !DIExpression())
!10 = distinct !DIGlobalVariable(name: "tsteps", scope: !2, file: !11, line: 112, type: !12, isLocal: false, isDefinition: true)
!11 = !DIFile(filename: "source/workload.c", directory: "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/triangular-20260929/suite/heat-3d", checksumkind: CSK_MD5, checksum: "e518c0e59e23961c4a259c9438496417")
!12 = !DIBasicType(name: "int", size: 32, encoding: DW_ATE_signed)
!13 = !DIGlobalVariableExpression(var: !14, expr: !DIExpression())
!14 = distinct !DIGlobalVariable(name: "A", scope: !2, file: !11, line: 34, type: !15, isLocal: false, isDefinition: true, align: 512)
!15 = !DICompositeType(tag: DW_TAG_array_type, baseType: !5, size: 4096000, elements: !16)
!16 = !{!17, !17, !17}
!17 = !DISubrange(count: 40)
!18 = !DIGlobalVariableExpression(var: !19, expr: !DIExpression())
!19 = distinct !DIGlobalVariable(name: "B", scope: !2, file: !11, line: 35, type: !15, isLocal: false, isDefinition: true, align: 512)
!20 = !{i32 7, !"Dwarf Version", i32 5}
!21 = !{i32 2, !"Debug Info Version", i32 3}
!22 = !{i32 1, !"wchar_size", i32 4}
!23 = !{i32 7, !"PIC Level", i32 2}
!24 = !{i32 7, !"PIE Level", i32 2}
!25 = !{i32 7, !"uwtable", i32 1}
!26 = !{i32 7, !"frame-pointer", i32 2}
!27 = !{!"Ubuntu clang version 14.0.0-1ubuntu1.1"}
!28 = distinct !DISubprogram(name: "task_job_polybench", scope: !11, file: !11, line: 120, type: !29, scopeLine: 120, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !2, retainedNodes: !35)
!29 = !DISubroutineType(types: !30)
!30 = !{!31}
!31 = !DIDerivedType(tag: DW_TAG_typedef, name: "uint32_t", file: !32, line: 26, baseType: !33)
!32 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/stdint-uintn.h", directory: "", checksumkind: CSK_MD5, checksum: "2bf2ae53c58c01b1a1b9383b5195125c")
!33 = !DIDerivedType(tag: DW_TAG_typedef, name: "__uint32_t", file: !34, line: 42, baseType: !6)
!34 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/types.h", directory: "", checksumkind: CSK_MD5, checksum: "d108b5f93a74c50510d7d9bc0ab36df9")
!35 = !{}
!36 = !DILocation(line: 121, column: 19, scope: !28)
!37 = !DILocation(line: 121, column: 27, scope: !28)
!38 = !DILocalVariable(name: "tsteps", arg: 1, scope: !39, file: !11, line: 75, type: !12)
!39 = distinct !DISubprogram(name: "kernel_heat_3d", scope: !11, file: !11, line: 75, type: !40, scopeLine: 79, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition, unit: !2, retainedNodes: !35)
!40 = !DISubroutineType(types: !41)
!41 = !{null, !12, !12, !42, !42}
!42 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !43, size: 64)
!43 = !DICompositeType(tag: DW_TAG_array_type, baseType: !5, size: 102400, elements: !44)
!44 = !{!17, !17}
!45 = !DILocation(line: 0, scope: !39, inlinedAt: !46)
!46 = distinct !DILocation(line: 121, column: 3, scope: !28)
!47 = !DILocalVariable(name: "n", arg: 2, scope: !39, file: !11, line: 76, type: !12)
!48 = !DILocalVariable(name: "A", arg: 3, scope: !39, file: !11, line: 77, type: !42)
!49 = !DILocalVariable(name: "B", arg: 4, scope: !39, file: !11, line: 78, type: !42)
!50 = !DILocalVariable(name: "t", scope: !39, file: !11, line: 80, type: !12)
!51 = !DILocation(line: 83, column: 10, scope: !52, inlinedAt: !46)
!52 = distinct !DILexicalBlock(scope: !39, file: !11, line: 83, column: 5)
!53 = !DILocation(line: 0, scope: !52, inlinedAt: !46)
!54 = !DILocation(line: 83, column: 19, scope: !55, inlinedAt: !46)
!55 = distinct !DILexicalBlock(scope: !52, file: !11, line: 83, column: 5)
!56 = !DILocation(line: 83, column: 5, scope: !52, inlinedAt: !46)
!57 = !DILocalVariable(name: "i", scope: !39, file: !11, line: 80, type: !12)
!58 = !DILocation(line: 84, column: 14, scope: !59, inlinedAt: !46)
!59 = distinct !DILexicalBlock(scope: !60, file: !11, line: 84, column: 9)
!60 = distinct !DILexicalBlock(scope: !55, file: !11, line: 83, column: 35)
!61 = !DILocation(line: 0, scope: !59, inlinedAt: !46)
!62 = !DILocation(line: 84, column: 23, scope: !63, inlinedAt: !46)
!63 = distinct !DILexicalBlock(scope: !59, file: !11, line: 84, column: 9)
!64 = !DILocation(line: 84, column: 9, scope: !59, inlinedAt: !46)
!65 = !DILocalVariable(name: "j", scope: !39, file: !11, line: 80, type: !12)
!66 = !DILocation(line: 85, column: 18, scope: !67, inlinedAt: !46)
!67 = distinct !DILexicalBlock(scope: !68, file: !11, line: 85, column: 13)
!68 = distinct !DILexicalBlock(scope: !63, file: !11, line: 84, column: 39)
!69 = !DILocation(line: 0, scope: !67, inlinedAt: !46)
!70 = !DILocation(line: 85, column: 27, scope: !71, inlinedAt: !46)
!71 = distinct !DILexicalBlock(scope: !67, file: !11, line: 85, column: 13)
!72 = !DILocation(line: 85, column: 13, scope: !67, inlinedAt: !46)
!73 = !DILocalVariable(name: "k", scope: !39, file: !11, line: 80, type: !12)
!74 = !DILocation(line: 86, column: 22, scope: !75, inlinedAt: !46)
!75 = distinct !DILexicalBlock(scope: !76, file: !11, line: 86, column: 17)
!76 = distinct !DILexicalBlock(scope: !71, file: !11, line: 85, column: 43)
!77 = !DILocation(line: 0, scope: !75, inlinedAt: !46)
!78 = !DILocation(line: 86, column: 31, scope: !79, inlinedAt: !46)
!79 = distinct !DILexicalBlock(scope: !75, file: !11, line: 86, column: 17)
!80 = !DILocation(line: 86, column: 17, scope: !75, inlinedAt: !46)
!81 = !DILocation(line: 87, column: 60, scope: !82, inlinedAt: !46)
!82 = distinct !DILexicalBlock(scope: !79, file: !11, line: 86, column: 47)
!83 = !DILocation(line: 87, column: 57, scope: !82, inlinedAt: !46)
!84 = !DILocation(line: 87, column: 90, scope: !82, inlinedAt: !46)
!85 = !DILocation(line: 87, column: 88, scope: !82, inlinedAt: !46)
!86 = !DILocation(line: 87, column: 70, scope: !82, inlinedAt: !46)
!87 = !DILocation(line: 87, column: 106, scope: !82, inlinedAt: !46)
!88 = !DILocation(line: 87, column: 103, scope: !82, inlinedAt: !46)
!89 = !DILocation(line: 87, column: 101, scope: !82, inlinedAt: !46)
!90 = !DILocation(line: 87, column: 54, scope: !82, inlinedAt: !46)
!91 = !DILocation(line: 88, column: 57, scope: !82, inlinedAt: !46)
!92 = !DILocation(line: 88, column: 63, scope: !82, inlinedAt: !46)
!93 = !DILocation(line: 88, column: 90, scope: !82, inlinedAt: !46)
!94 = !DILocation(line: 88, column: 88, scope: !82, inlinedAt: !46)
!95 = !DILocation(line: 88, column: 70, scope: !82, inlinedAt: !46)
!96 = !DILocation(line: 88, column: 103, scope: !82, inlinedAt: !46)
!97 = !DILocation(line: 88, column: 109, scope: !82, inlinedAt: !46)
!98 = !DILocation(line: 88, column: 101, scope: !82, inlinedAt: !46)
!99 = !DILocation(line: 88, column: 54, scope: !82, inlinedAt: !46)
!100 = !DILocation(line: 88, column: 34, scope: !82, inlinedAt: !46)
!101 = !DILocation(line: 89, column: 57, scope: !82, inlinedAt: !46)
!102 = !DILocation(line: 89, column: 66, scope: !82, inlinedAt: !46)
!103 = !DILocation(line: 89, column: 90, scope: !82, inlinedAt: !46)
!104 = !DILocation(line: 89, column: 88, scope: !82, inlinedAt: !46)
!105 = !DILocation(line: 89, column: 70, scope: !82, inlinedAt: !46)
!106 = !DILocation(line: 89, column: 103, scope: !82, inlinedAt: !46)
!107 = !DILocation(line: 89, column: 112, scope: !82, inlinedAt: !46)
!108 = !DILocation(line: 89, column: 101, scope: !82, inlinedAt: !46)
!109 = !DILocation(line: 89, column: 54, scope: !82, inlinedAt: !46)
!110 = !DILocation(line: 89, column: 34, scope: !82, inlinedAt: !46)
!111 = !DILocation(line: 90, column: 36, scope: !82, inlinedAt: !46)
!112 = !DILocation(line: 90, column: 34, scope: !82, inlinedAt: !46)
!113 = !DILocation(line: 87, column: 21, scope: !82, inlinedAt: !46)
!114 = !DILocation(line: 87, column: 32, scope: !82, inlinedAt: !46)
!115 = !DILocation(line: 86, column: 43, scope: !79, inlinedAt: !46)
!116 = !DILocation(line: 86, column: 17, scope: !79, inlinedAt: !46)
!117 = distinct !{!117, !80, !118, !119}
!118 = !DILocation(line: 91, column: 17, scope: !75, inlinedAt: !46)
!119 = !{!"llvm.loop.mustprogress"}
!120 = !DILocation(line: 85, column: 39, scope: !71, inlinedAt: !46)
!121 = !DILocation(line: 85, column: 13, scope: !71, inlinedAt: !46)
!122 = distinct !{!122, !72, !123, !119}
!123 = !DILocation(line: 92, column: 13, scope: !67, inlinedAt: !46)
!124 = !DILocation(line: 84, column: 35, scope: !63, inlinedAt: !46)
!125 = !DILocation(line: 84, column: 9, scope: !63, inlinedAt: !46)
!126 = distinct !{!126, !64, !127, !119}
!127 = !DILocation(line: 93, column: 9, scope: !59, inlinedAt: !46)
!128 = !DILocation(line: 94, column: 14, scope: !129, inlinedAt: !46)
!129 = distinct !DILexicalBlock(scope: !60, file: !11, line: 94, column: 9)
!130 = !DILocation(line: 0, scope: !129, inlinedAt: !46)
!131 = !DILocation(line: 94, column: 23, scope: !132, inlinedAt: !46)
!132 = distinct !DILexicalBlock(scope: !129, file: !11, line: 94, column: 9)
!133 = !DILocation(line: 94, column: 9, scope: !129, inlinedAt: !46)
!134 = !DILocation(line: 95, column: 17, scope: !135, inlinedAt: !46)
!135 = distinct !DILexicalBlock(scope: !136, file: !11, line: 95, column: 12)
!136 = distinct !DILexicalBlock(scope: !132, file: !11, line: 94, column: 39)
!137 = !DILocation(line: 0, scope: !135, inlinedAt: !46)
!138 = !DILocation(line: 95, column: 26, scope: !139, inlinedAt: !46)
!139 = distinct !DILexicalBlock(scope: !135, file: !11, line: 95, column: 12)
!140 = !DILocation(line: 95, column: 12, scope: !135, inlinedAt: !46)
!141 = !DILocation(line: 96, column: 21, scope: !142, inlinedAt: !46)
!142 = distinct !DILexicalBlock(scope: !143, file: !11, line: 96, column: 16)
!143 = distinct !DILexicalBlock(scope: !139, file: !11, line: 95, column: 42)
!144 = !DILocation(line: 0, scope: !142, inlinedAt: !46)
!145 = !DILocation(line: 96, column: 30, scope: !146, inlinedAt: !46)
!146 = distinct !DILexicalBlock(scope: !142, file: !11, line: 96, column: 16)
!147 = !DILocation(line: 96, column: 16, scope: !142, inlinedAt: !46)
!148 = !DILocation(line: 97, column: 59, scope: !149, inlinedAt: !46)
!149 = distinct !DILexicalBlock(scope: !146, file: !11, line: 96, column: 46)
!150 = !DILocation(line: 97, column: 56, scope: !149, inlinedAt: !46)
!151 = !DILocation(line: 97, column: 89, scope: !149, inlinedAt: !46)
!152 = !DILocation(line: 97, column: 87, scope: !149, inlinedAt: !46)
!153 = !DILocation(line: 97, column: 69, scope: !149, inlinedAt: !46)
!154 = !DILocation(line: 97, column: 105, scope: !149, inlinedAt: !46)
!155 = !DILocation(line: 97, column: 102, scope: !149, inlinedAt: !46)
!156 = !DILocation(line: 97, column: 100, scope: !149, inlinedAt: !46)
!157 = !DILocation(line: 97, column: 53, scope: !149, inlinedAt: !46)
!158 = !DILocation(line: 98, column: 56, scope: !149, inlinedAt: !46)
!159 = !DILocation(line: 98, column: 62, scope: !149, inlinedAt: !46)
!160 = !DILocation(line: 98, column: 89, scope: !149, inlinedAt: !46)
!161 = !DILocation(line: 98, column: 87, scope: !149, inlinedAt: !46)
!162 = !DILocation(line: 98, column: 69, scope: !149, inlinedAt: !46)
!163 = !DILocation(line: 98, column: 102, scope: !149, inlinedAt: !46)
!164 = !DILocation(line: 98, column: 108, scope: !149, inlinedAt: !46)
!165 = !DILocation(line: 98, column: 100, scope: !149, inlinedAt: !46)
!166 = !DILocation(line: 98, column: 53, scope: !149, inlinedAt: !46)
!167 = !DILocation(line: 98, column: 33, scope: !149, inlinedAt: !46)
!168 = !DILocation(line: 99, column: 56, scope: !149, inlinedAt: !46)
!169 = !DILocation(line: 99, column: 65, scope: !149, inlinedAt: !46)
!170 = !DILocation(line: 99, column: 89, scope: !149, inlinedAt: !46)
!171 = !DILocation(line: 99, column: 87, scope: !149, inlinedAt: !46)
!172 = !DILocation(line: 99, column: 69, scope: !149, inlinedAt: !46)
!173 = !DILocation(line: 99, column: 102, scope: !149, inlinedAt: !46)
!174 = !DILocation(line: 99, column: 111, scope: !149, inlinedAt: !46)
!175 = !DILocation(line: 99, column: 100, scope: !149, inlinedAt: !46)
!176 = !DILocation(line: 99, column: 53, scope: !149, inlinedAt: !46)
!177 = !DILocation(line: 99, column: 33, scope: !149, inlinedAt: !46)
!178 = !DILocation(line: 100, column: 35, scope: !149, inlinedAt: !46)
!179 = !DILocation(line: 100, column: 33, scope: !149, inlinedAt: !46)
!180 = !DILocation(line: 97, column: 20, scope: !149, inlinedAt: !46)
!181 = !DILocation(line: 97, column: 31, scope: !149, inlinedAt: !46)
!182 = !DILocation(line: 96, column: 42, scope: !146, inlinedAt: !46)
!183 = !DILocation(line: 96, column: 16, scope: !146, inlinedAt: !46)
!184 = distinct !{!184, !147, !185, !119}
!185 = !DILocation(line: 101, column: 16, scope: !142, inlinedAt: !46)
!186 = !DILocation(line: 95, column: 38, scope: !139, inlinedAt: !46)
!187 = !DILocation(line: 95, column: 12, scope: !139, inlinedAt: !46)
!188 = distinct !{!188, !140, !189, !119}
!189 = !DILocation(line: 102, column: 12, scope: !135, inlinedAt: !46)
!190 = !DILocation(line: 94, column: 35, scope: !132, inlinedAt: !46)
!191 = !DILocation(line: 94, column: 9, scope: !132, inlinedAt: !46)
!192 = distinct !{!192, !133, !193, !119}
!193 = !DILocation(line: 103, column: 8, scope: !129, inlinedAt: !46)
!194 = !DILocation(line: 83, column: 31, scope: !55, inlinedAt: !46)
!195 = !DILocation(line: 83, column: 5, scope: !55, inlinedAt: !46)
!196 = distinct !{!196, !56, !197, !119}
!197 = !DILocation(line: 104, column: 5, scope: !52, inlinedAt: !46)
!198 = !DILocation(line: 122, column: 3, scope: !28)
