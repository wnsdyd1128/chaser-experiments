; ModuleID = 'inlined.ll'
source_filename = "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/triangular-20260929/suite/mvt/source/workload.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

@n = external dso_local global i32, align 4, !dbg !0
@A = external dso_local global [400 x [400 x double]], section ".chaser_data.A", align 64, !dbg !9
@x1 = external dso_local global [400 x double], section ".chaser_data.x1", align 64, !dbg !15
@x2 = external dso_local global [400 x double], section ".chaser_data.x2", align 64, !dbg !19
@y_1 = external dso_local global [400 x double], section ".chaser_data.y_1", align 64, !dbg !21
@y_2 = external dso_local global [400 x double], section ".chaser_data.y_2", align 64, !dbg !23
@.str = hidden unnamed_addr constant [12 x i8] c"ape.analyze\00", section "llvm.metadata"
@.str.1 = hidden unnamed_addr constant [118 x i8] c"/workspace/experiments-array-support/chaser/.cache/periodic-polybench/triangular-20260929/suite/mvt/source/workload.c\00", section "llvm.metadata"
@.str.2 = hidden unnamed_addr constant [23 x i8] c"==BEGIN DUMP_ARRAYS==\0A\00", align 1
@.str.3 = hidden unnamed_addr constant [15 x i8] c"begin dump: %s\00", align 1
@.str.4 = hidden unnamed_addr constant [3 x i8] c"x1\00", align 1
@.str.5 = hidden unnamed_addr constant [2 x i8] c"\0A\00", align 1
@.str.6 = hidden unnamed_addr constant [8 x i8] c"%0.2lf \00", align 1
@.str.7 = hidden unnamed_addr constant [17 x i8] c"\0Aend   dump: %s\0A\00", align 1
@.str.8 = hidden unnamed_addr constant [3 x i8] c"x2\00", align 1
@.str.9 = hidden unnamed_addr constant [23 x i8] c"==END   DUMP_ARRAYS==\0A\00", align 1
@llvm.global.annotations = appending global [1 x { i8*, i8*, i8*, i32, i8* }] [{ i8*, i8*, i8*, i32, i8* } { i8* bitcast (i32 ()* @task_job_polybench to i8*), i8* getelementptr inbounds ([12 x i8], [12 x i8]* @.str, i32 0, i32 0), i8* getelementptr inbounds ([118 x i8], [118 x i8]* @.str.1, i32 0, i32 0), i32 130, i8* null }], section "llvm.metadata"

; Function Attrs: noinline nounwind uwtable
define dso_local i32 @task_job_polybench() #0 !dbg !34 {
  %1 = load i32, i32* @n, align 4, !dbg !42
  call void @llvm.dbg.value(metadata i32 %1, metadata !43, metadata !DIExpression()), !dbg !49
  call void @llvm.dbg.value(metadata double* getelementptr inbounds ([400 x double], [400 x double]* @x1, i64 0, i64 0), metadata !51, metadata !DIExpression()), !dbg !49
  call void @llvm.dbg.value(metadata double* getelementptr inbounds ([400 x double], [400 x double]* @x2, i64 0, i64 0), metadata !52, metadata !DIExpression()), !dbg !49
  call void @llvm.dbg.value(metadata double* getelementptr inbounds ([400 x double], [400 x double]* @y_1, i64 0, i64 0), metadata !53, metadata !DIExpression()), !dbg !49
  call void @llvm.dbg.value(metadata double* getelementptr inbounds ([400 x double], [400 x double]* @y_2, i64 0, i64 0), metadata !54, metadata !DIExpression()), !dbg !49
  call void @llvm.dbg.value(metadata [400 x double]* getelementptr inbounds ([400 x [400 x double]], [400 x [400 x double]]* @A, i64 0, i64 0), metadata !55, metadata !DIExpression()), !dbg !49
  call void @llvm.dbg.value(metadata i32 0, metadata !56, metadata !DIExpression()), !dbg !49
  br label %2, !dbg !57

2:                                                ; preds = %24, %0
  %.01 = phi i32 [ 0, %0 ], [ %25, %24 ], !dbg !59
  call void @llvm.dbg.value(metadata i32 %.01, metadata !56, metadata !DIExpression()), !dbg !49
  %3 = icmp slt i32 %.01, 400, !dbg !60
  br i1 %3, label %4, label %26, !dbg !62

4:                                                ; preds = %2
  call void @llvm.dbg.value(metadata i32 0, metadata !63, metadata !DIExpression()), !dbg !49
  br label %5, !dbg !64

5:                                                ; preds = %7, %4
  %.0 = phi i32 [ 0, %4 ], [ %23, %7 ], !dbg !66
  call void @llvm.dbg.value(metadata i32 %.0, metadata !63, metadata !DIExpression()), !dbg !49
  %6 = icmp slt i32 %.0, 400, !dbg !67
  br i1 %6, label %7, label %24, !dbg !69

7:                                                ; preds = %5
  %8 = sext i32 %.01 to i64, !dbg !70
  %9 = getelementptr inbounds double, double* getelementptr inbounds ([400 x double], [400 x double]* @x1, i64 0, i64 0), i64 %8, !dbg !70
  %10 = load double, double* %9, align 8, !dbg !70
  %11 = sext i32 %.01 to i64, !dbg !71
  %12 = getelementptr inbounds [400 x double], [400 x double]* getelementptr inbounds ([400 x [400 x double]], [400 x [400 x double]]* @A, i64 0, i64 0), i64 %11, !dbg !71
  %13 = sext i32 %.0 to i64, !dbg !71
  %14 = getelementptr inbounds [400 x double], [400 x double]* %12, i64 0, i64 %13, !dbg !71
  %15 = load double, double* %14, align 8, !dbg !71
  %16 = sext i32 %.0 to i64, !dbg !72
  %17 = getelementptr inbounds double, double* getelementptr inbounds ([400 x double], [400 x double]* @y_1, i64 0, i64 0), i64 %16, !dbg !72
  %18 = load double, double* %17, align 8, !dbg !72
  %19 = fmul double %15, %18, !dbg !73
  %20 = fadd double %10, %19, !dbg !74
  %21 = sext i32 %.01 to i64, !dbg !75
  %22 = getelementptr inbounds double, double* getelementptr inbounds ([400 x double], [400 x double]* @x1, i64 0, i64 0), i64 %21, !dbg !75
  store double %20, double* %22, align 8, !dbg !76
  %23 = add nsw i32 %.0, 1, !dbg !77
  call void @llvm.dbg.value(metadata i32 %23, metadata !63, metadata !DIExpression()), !dbg !49
  br label %5, !dbg !78, !llvm.loop !79

24:                                               ; preds = %5
  %25 = add nsw i32 %.01, 1, !dbg !82
  call void @llvm.dbg.value(metadata i32 %25, metadata !56, metadata !DIExpression()), !dbg !49
  br label %2, !dbg !83, !llvm.loop !84

26:                                               ; preds = %2
  call void @llvm.dbg.value(metadata i32 0, metadata !56, metadata !DIExpression()), !dbg !49
  br label %27, !dbg !86

27:                                               ; preds = %49, %26
  %.12 = phi i32 [ 0, %26 ], [ %50, %49 ], !dbg !88
  call void @llvm.dbg.value(metadata i32 %.12, metadata !56, metadata !DIExpression()), !dbg !49
  %28 = icmp slt i32 %.12, 400, !dbg !89
  br i1 %28, label %29, label %51, !dbg !91

29:                                               ; preds = %27
  call void @llvm.dbg.value(metadata i32 0, metadata !63, metadata !DIExpression()), !dbg !49
  br label %30, !dbg !92

30:                                               ; preds = %32, %29
  %.1 = phi i32 [ 0, %29 ], [ %48, %32 ], !dbg !94
  call void @llvm.dbg.value(metadata i32 %.1, metadata !63, metadata !DIExpression()), !dbg !49
  %31 = icmp slt i32 %.1, 400, !dbg !95
  br i1 %31, label %32, label %49, !dbg !97

32:                                               ; preds = %30
  %33 = sext i32 %.12 to i64, !dbg !98
  %34 = getelementptr inbounds double, double* getelementptr inbounds ([400 x double], [400 x double]* @x2, i64 0, i64 0), i64 %33, !dbg !98
  %35 = load double, double* %34, align 8, !dbg !98
  %36 = sext i32 %.1 to i64, !dbg !99
  %37 = getelementptr inbounds [400 x double], [400 x double]* getelementptr inbounds ([400 x [400 x double]], [400 x [400 x double]]* @A, i64 0, i64 0), i64 %36, !dbg !99
  %38 = sext i32 %.12 to i64, !dbg !99
  %39 = getelementptr inbounds [400 x double], [400 x double]* %37, i64 0, i64 %38, !dbg !99
  %40 = load double, double* %39, align 8, !dbg !99
  %41 = sext i32 %.1 to i64, !dbg !100
  %42 = getelementptr inbounds double, double* getelementptr inbounds ([400 x double], [400 x double]* @y_2, i64 0, i64 0), i64 %41, !dbg !100
  %43 = load double, double* %42, align 8, !dbg !100
  %44 = fmul double %40, %43, !dbg !101
  %45 = fadd double %35, %44, !dbg !102
  %46 = sext i32 %.12 to i64, !dbg !103
  %47 = getelementptr inbounds double, double* getelementptr inbounds ([400 x double], [400 x double]* @x2, i64 0, i64 0), i64 %46, !dbg !103
  store double %45, double* %47, align 8, !dbg !104
  %48 = add nsw i32 %.1, 1, !dbg !105
  call void @llvm.dbg.value(metadata i32 %48, metadata !63, metadata !DIExpression()), !dbg !49
  br label %30, !dbg !106, !llvm.loop !107

49:                                               ; preds = %30
  %50 = add nsw i32 %.12, 1, !dbg !109
  call void @llvm.dbg.value(metadata i32 %50, metadata !56, metadata !DIExpression()), !dbg !49
  br label %27, !dbg !110, !llvm.loop !111

51:                                               ; preds = %27
  ret i32 0, !dbg !113
}

; Function Attrs: nofree nosync nounwind readnone speculatable willreturn
declare void @llvm.dbg.value(metadata, metadata, metadata) #1

attributes #0 = { noinline nounwind uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { nofree nosync nounwind readnone speculatable willreturn }

!llvm.dbg.cu = !{!2}
!llvm.module.flags = !{!26, !27, !28, !29, !30, !31, !32}
!llvm.ident = !{!33}

!0 = !DIGlobalVariableExpression(var: !1, expr: !DIExpression())
!1 = distinct !DIGlobalVariable(name: "n", scope: !2, file: !11, line: 114, type: !25, isLocal: false, isDefinition: true)
!2 = distinct !DICompileUnit(language: DW_LANG_C99, file: !3, producer: "Ubuntu clang version 14.0.0-1ubuntu1.1", isOptimized: false, runtimeVersion: 0, emissionKind: FullDebug, retainedTypes: !4, globals: !8, splitDebugInlining: false, nameTableKind: None)
!3 = !DIFile(filename: "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/triangular-20260929/suite/mvt/source/workload.c", directory: "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/triangular-20260929/suite/mvt/analysis-p", checksumkind: CSK_MD5, checksum: "f71e460355e980f9bb96215091b80313")
!4 = !{!5, !6, !7}
!5 = !DIBasicType(name: "double", size: 64, encoding: DW_ATE_float)
!6 = !DIBasicType(name: "unsigned int", size: 32, encoding: DW_ATE_unsigned)
!7 = !DIBasicType(name: "unsigned char", size: 8, encoding: DW_ATE_unsigned_char)
!8 = !{!0, !9, !15, !19, !21, !23}
!9 = !DIGlobalVariableExpression(var: !10, expr: !DIExpression())
!10 = distinct !DIGlobalVariable(name: "A", scope: !2, file: !11, line: 34, type: !12, isLocal: false, isDefinition: true, align: 512)
!11 = !DIFile(filename: "source/workload.c", directory: "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/triangular-20260929/suite/mvt", checksumkind: CSK_MD5, checksum: "f71e460355e980f9bb96215091b80313")
!12 = !DICompositeType(tag: DW_TAG_array_type, baseType: !5, size: 10240000, elements: !13)
!13 = !{!14, !14}
!14 = !DISubrange(count: 400)
!15 = !DIGlobalVariableExpression(var: !16, expr: !DIExpression())
!16 = distinct !DIGlobalVariable(name: "x1", scope: !2, file: !11, line: 35, type: !17, isLocal: false, isDefinition: true, align: 512)
!17 = !DICompositeType(tag: DW_TAG_array_type, baseType: !5, size: 25600, elements: !18)
!18 = !{!14}
!19 = !DIGlobalVariableExpression(var: !20, expr: !DIExpression())
!20 = distinct !DIGlobalVariable(name: "x2", scope: !2, file: !11, line: 36, type: !17, isLocal: false, isDefinition: true, align: 512)
!21 = !DIGlobalVariableExpression(var: !22, expr: !DIExpression())
!22 = distinct !DIGlobalVariable(name: "y_1", scope: !2, file: !11, line: 37, type: !17, isLocal: false, isDefinition: true, align: 512)
!23 = !DIGlobalVariableExpression(var: !24, expr: !DIExpression())
!24 = distinct !DIGlobalVariable(name: "y_2", scope: !2, file: !11, line: 38, type: !17, isLocal: false, isDefinition: true, align: 512)
!25 = !DIBasicType(name: "int", size: 32, encoding: DW_ATE_signed)
!26 = !{i32 7, !"Dwarf Version", i32 5}
!27 = !{i32 2, !"Debug Info Version", i32 3}
!28 = !{i32 1, !"wchar_size", i32 4}
!29 = !{i32 7, !"PIC Level", i32 2}
!30 = !{i32 7, !"PIE Level", i32 2}
!31 = !{i32 7, !"uwtable", i32 1}
!32 = !{i32 7, !"frame-pointer", i32 2}
!33 = !{!"Ubuntu clang version 14.0.0-1ubuntu1.1"}
!34 = distinct !DISubprogram(name: "task_job_polybench", scope: !11, file: !11, line: 130, type: !35, scopeLine: 130, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !2, retainedNodes: !41)
!35 = !DISubroutineType(types: !36)
!36 = !{!37}
!37 = !DIDerivedType(tag: DW_TAG_typedef, name: "uint32_t", file: !38, line: 26, baseType: !39)
!38 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/stdint-uintn.h", directory: "", checksumkind: CSK_MD5, checksum: "2bf2ae53c58c01b1a1b9383b5195125c")
!39 = !DIDerivedType(tag: DW_TAG_typedef, name: "__uint32_t", file: !40, line: 42, baseType: !6)
!40 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/types.h", directory: "", checksumkind: CSK_MD5, checksum: "d108b5f93a74c50510d7d9bc0ab36df9")
!41 = !{}
!42 = !DILocation(line: 131, column: 15, scope: !34)
!43 = !DILocalVariable(name: "n", arg: 1, scope: !44, file: !11, line: 92, type: !25)
!44 = distinct !DISubprogram(name: "kernel_mvt", scope: !11, file: !11, line: 92, type: !45, scopeLine: 98, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition, unit: !2, retainedNodes: !41)
!45 = !DISubroutineType(types: !46)
!46 = !{null, !25, !47, !47, !47, !47, !48}
!47 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !5, size: 64)
!48 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !17, size: 64)
!49 = !DILocation(line: 0, scope: !44, inlinedAt: !50)
!50 = distinct !DILocation(line: 131, column: 3, scope: !34)
!51 = !DILocalVariable(name: "x1", arg: 2, scope: !44, file: !11, line: 93, type: !47)
!52 = !DILocalVariable(name: "x2", arg: 3, scope: !44, file: !11, line: 94, type: !47)
!53 = !DILocalVariable(name: "y_1", arg: 4, scope: !44, file: !11, line: 95, type: !47)
!54 = !DILocalVariable(name: "y_2", arg: 5, scope: !44, file: !11, line: 96, type: !47)
!55 = !DILocalVariable(name: "A", arg: 6, scope: !44, file: !11, line: 97, type: !48)
!56 = !DILocalVariable(name: "i", scope: !44, file: !11, line: 99, type: !25)
!57 = !DILocation(line: 102, column: 8, scope: !58, inlinedAt: !50)
!58 = distinct !DILexicalBlock(scope: !44, file: !11, line: 102, column: 3)
!59 = !DILocation(line: 0, scope: !58, inlinedAt: !50)
!60 = !DILocation(line: 102, column: 17, scope: !61, inlinedAt: !50)
!61 = distinct !DILexicalBlock(scope: !58, file: !11, line: 102, column: 3)
!62 = !DILocation(line: 102, column: 3, scope: !58, inlinedAt: !50)
!63 = !DILocalVariable(name: "j", scope: !44, file: !11, line: 99, type: !25)
!64 = !DILocation(line: 103, column: 10, scope: !65, inlinedAt: !50)
!65 = distinct !DILexicalBlock(scope: !61, file: !11, line: 103, column: 5)
!66 = !DILocation(line: 0, scope: !65, inlinedAt: !50)
!67 = !DILocation(line: 103, column: 19, scope: !68, inlinedAt: !50)
!68 = distinct !DILexicalBlock(scope: !65, file: !11, line: 103, column: 5)
!69 = !DILocation(line: 103, column: 5, scope: !65, inlinedAt: !50)
!70 = !DILocation(line: 104, column: 15, scope: !68, inlinedAt: !50)
!71 = !DILocation(line: 104, column: 23, scope: !68, inlinedAt: !50)
!72 = !DILocation(line: 104, column: 33, scope: !68, inlinedAt: !50)
!73 = !DILocation(line: 104, column: 31, scope: !68, inlinedAt: !50)
!74 = !DILocation(line: 104, column: 21, scope: !68, inlinedAt: !50)
!75 = !DILocation(line: 104, column: 7, scope: !68, inlinedAt: !50)
!76 = !DILocation(line: 104, column: 13, scope: !68, inlinedAt: !50)
!77 = !DILocation(line: 103, column: 29, scope: !68, inlinedAt: !50)
!78 = !DILocation(line: 103, column: 5, scope: !68, inlinedAt: !50)
!79 = distinct !{!79, !69, !80, !81}
!80 = !DILocation(line: 104, column: 38, scope: !65, inlinedAt: !50)
!81 = !{!"llvm.loop.mustprogress"}
!82 = !DILocation(line: 102, column: 27, scope: !61, inlinedAt: !50)
!83 = !DILocation(line: 102, column: 3, scope: !61, inlinedAt: !50)
!84 = distinct !{!84, !62, !85, !81}
!85 = !DILocation(line: 104, column: 38, scope: !58, inlinedAt: !50)
!86 = !DILocation(line: 105, column: 8, scope: !87, inlinedAt: !50)
!87 = distinct !DILexicalBlock(scope: !44, file: !11, line: 105, column: 3)
!88 = !DILocation(line: 0, scope: !87, inlinedAt: !50)
!89 = !DILocation(line: 105, column: 17, scope: !90, inlinedAt: !50)
!90 = distinct !DILexicalBlock(scope: !87, file: !11, line: 105, column: 3)
!91 = !DILocation(line: 105, column: 3, scope: !87, inlinedAt: !50)
!92 = !DILocation(line: 106, column: 10, scope: !93, inlinedAt: !50)
!93 = distinct !DILexicalBlock(scope: !90, file: !11, line: 106, column: 5)
!94 = !DILocation(line: 0, scope: !93, inlinedAt: !50)
!95 = !DILocation(line: 106, column: 19, scope: !96, inlinedAt: !50)
!96 = distinct !DILexicalBlock(scope: !93, file: !11, line: 106, column: 5)
!97 = !DILocation(line: 106, column: 5, scope: !93, inlinedAt: !50)
!98 = !DILocation(line: 107, column: 15, scope: !96, inlinedAt: !50)
!99 = !DILocation(line: 107, column: 23, scope: !96, inlinedAt: !50)
!100 = !DILocation(line: 107, column: 33, scope: !96, inlinedAt: !50)
!101 = !DILocation(line: 107, column: 31, scope: !96, inlinedAt: !50)
!102 = !DILocation(line: 107, column: 21, scope: !96, inlinedAt: !50)
!103 = !DILocation(line: 107, column: 7, scope: !96, inlinedAt: !50)
!104 = !DILocation(line: 107, column: 13, scope: !96, inlinedAt: !50)
!105 = !DILocation(line: 106, column: 29, scope: !96, inlinedAt: !50)
!106 = !DILocation(line: 106, column: 5, scope: !96, inlinedAt: !50)
!107 = distinct !{!107, !97, !108, !81}
!108 = !DILocation(line: 107, column: 38, scope: !93, inlinedAt: !50)
!109 = !DILocation(line: 105, column: 27, scope: !90, inlinedAt: !50)
!110 = !DILocation(line: 105, column: 3, scope: !90, inlinedAt: !50)
!111 = distinct !{!111, !91, !112, !81}
!112 = !DILocation(line: 107, column: 38, scope: !87, inlinedAt: !50)
!113 = !DILocation(line: 137, column: 3, scope: !34)
