; ModuleID = 'workload.ll'
source_filename = "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/triangular-20260929/suite/gesummv/source/workload.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

%struct._IO_FILE = type { i32, i8*, i8*, i8*, i8*, i8*, i8*, i8*, i8*, i8*, i8*, i8*, %struct._IO_marker*, %struct._IO_FILE*, i32, i32, i64, i16, i8, [1 x i8], i8*, i64, %struct._IO_codecvt*, %struct._IO_wide_data*, %struct._IO_FILE*, i8*, i64, i32, [20 x i8] }
%struct._IO_marker = type opaque
%struct._IO_codecvt = type opaque
%struct._IO_wide_data = type opaque
%struct.__va_list_tag = type { i32, i32, i8*, i8* }

@n = dso_local global i32 250, align 4, !dbg !0
@A = dso_local global [250 x [250 x double]] zeroinitializer, section ".chaser_data.A", align 64, !dbg !30
@B = dso_local global [250 x [250 x double]] zeroinitializer, section ".chaser_data.B", align 64, !dbg !35
@tmp = dso_local global [250 x double] zeroinitializer, section ".chaser_data.tmp", align 64, !dbg !37
@x = dso_local global [250 x double] zeroinitializer, section ".chaser_data.x", align 64, !dbg !41
@y = dso_local global [250 x double] zeroinitializer, section ".chaser_data.y", align 64, !dbg !43
@alpha = dso_local global double 0.000000e+00, align 8, !dbg !45
@beta = dso_local global double 0.000000e+00, align 8, !dbg !47
@.str = private unnamed_addr constant [12 x i8] c"ape.analyze\00", section "llvm.metadata"
@.str.1 = private unnamed_addr constant [122 x i8] c"/workspace/experiments-array-support/chaser/.cache/periodic-polybench/triangular-20260929/suite/gesummv/source/workload.c\00", section "llvm.metadata"
@pb_hash = internal global i32 0, align 4, !dbg !27
@workload_jobs = dso_local constant [1 x i32 ()*] [i32 ()* @task_job_polybench], align 8, !dbg !9
@workload_expected = dso_local constant [1 x i32] [i32 -1941187741], align 4, !dbg !23
@stderr = external global %struct._IO_FILE*, align 8
@.str.2 = private unnamed_addr constant [23 x i8] c"==BEGIN DUMP_ARRAYS==\0A\00", align 1
@.str.3 = private unnamed_addr constant [15 x i8] c"begin dump: %s\00", align 1
@.str.4 = private unnamed_addr constant [2 x i8] c"y\00", align 1
@.str.5 = private unnamed_addr constant [2 x i8] c"\0A\00", align 1
@.str.6 = private unnamed_addr constant [8 x i8] c"%0.2lf \00", align 1
@.str.7 = private unnamed_addr constant [17 x i8] c"\0Aend   dump: %s\0A\00", align 1
@.str.8 = private unnamed_addr constant [23 x i8] c"==END   DUMP_ARRAYS==\0A\00", align 1
@pb_emit = internal global i32 1, align 4, !dbg !49
@llvm.global.annotations = appending global [1 x { i8*, i8*, i8*, i32, i8* }] [{ i8*, i8*, i8*, i32, i8* } { i8* bitcast (i32 ()* @task_job_polybench to i8*), i8* getelementptr inbounds ([12 x i8], [12 x i8]* @.str, i32 0, i32 0), i8* getelementptr inbounds ([122 x i8], [122 x i8]* @.str.1, i32 0, i32 0), i32 132, i8* null }], section "llvm.metadata"

; Function Attrs: noinline nounwind uwtable
define dso_local void @workload_prepare() #0 !dbg !60 {
  ret void, !dbg !64
}

; Function Attrs: noinline nounwind uwtable
define dso_local void @workload_reset(i32 noundef %0) #0 !dbg !65 {
  call void @llvm.dbg.value(metadata i32 %0, metadata !68, metadata !DIExpression()), !dbg !69
  call void @llvm.memset.p0i8.i64(i8* align 64 bitcast ([250 x [250 x double]]* @A to i8*), i8 0, i64 500000, i1 false), !dbg !70
  call void @llvm.memset.p0i8.i64(i8* align 64 bitcast ([250 x [250 x double]]* @B to i8*), i8 0, i64 500000, i1 false), !dbg !71
  call void @llvm.memset.p0i8.i64(i8* align 64 bitcast ([250 x double]* @tmp to i8*), i8 0, i64 2000, i1 false), !dbg !72
  call void @llvm.memset.p0i8.i64(i8* align 64 bitcast ([250 x double]* @x to i8*), i8 0, i64 2000, i1 false), !dbg !73
  call void @llvm.memset.p0i8.i64(i8* align 64 bitcast ([250 x double]* @y to i8*), i8 0, i64 2000, i1 false), !dbg !74
  %2 = load i32, i32* @n, align 4, !dbg !75
  call void @init_array(i32 noundef %2, double* noundef @alpha, double* noundef @beta, [250 x double]* noundef getelementptr inbounds ([250 x [250 x double]], [250 x [250 x double]]* @A, i64 0, i64 0), [250 x double]* noundef getelementptr inbounds ([250 x [250 x double]], [250 x [250 x double]]* @B, i64 0, i64 0), double* noundef getelementptr inbounds ([250 x double], [250 x double]* @x, i64 0, i64 0)), !dbg !76
  ret void, !dbg !77
}

; Function Attrs: nofree nosync nounwind readnone speculatable willreturn
declare void @llvm.dbg.declare(metadata, metadata, metadata) #1

; Function Attrs: argmemonly nofree nounwind willreturn writeonly
declare void @llvm.memset.p0i8.i64(i8* nocapture writeonly, i8, i64, i1 immarg) #2

; Function Attrs: noinline nounwind uwtable
define internal void @init_array(i32 noundef %0, double* noundef %1, double* noundef %2, [250 x double]* noundef %3, [250 x double]* noundef %4, double* noundef %5) #0 !dbg !78 {
  call void @llvm.dbg.value(metadata i32 %0, metadata !83, metadata !DIExpression()), !dbg !84
  call void @llvm.dbg.value(metadata double* %1, metadata !85, metadata !DIExpression()), !dbg !84
  call void @llvm.dbg.value(metadata double* %2, metadata !86, metadata !DIExpression()), !dbg !84
  call void @llvm.dbg.value(metadata [250 x double]* %3, metadata !87, metadata !DIExpression()), !dbg !84
  call void @llvm.dbg.value(metadata [250 x double]* %4, metadata !88, metadata !DIExpression()), !dbg !84
  call void @llvm.dbg.value(metadata double* %5, metadata !89, metadata !DIExpression()), !dbg !84
  store double 1.500000e+00, double* %1, align 8, !dbg !90
  store double 1.200000e+00, double* %2, align 8, !dbg !91
  call void @llvm.dbg.value(metadata i32 0, metadata !92, metadata !DIExpression()), !dbg !84
  br label %7, !dbg !93

7:                                                ; preds = %42, %6
  %.01 = phi i32 [ 0, %6 ], [ %43, %42 ], !dbg !95
  call void @llvm.dbg.value(metadata i32 %.01, metadata !92, metadata !DIExpression()), !dbg !84
  %8 = icmp slt i32 %.01, %0, !dbg !96
  br i1 %8, label %9, label %44, !dbg !98

9:                                                ; preds = %7
  %10 = srem i32 %.01, %0, !dbg !99
  %11 = sitofp i32 %10 to double, !dbg !101
  %12 = sitofp i32 %0 to double, !dbg !102
  %13 = fdiv double %11, %12, !dbg !103
  %14 = sext i32 %.01 to i64, !dbg !104
  %15 = getelementptr inbounds double, double* %5, i64 %14, !dbg !104
  store double %13, double* %15, align 8, !dbg !105
  call void @llvm.dbg.value(metadata i32 0, metadata !106, metadata !DIExpression()), !dbg !84
  br label %16, !dbg !107

16:                                               ; preds = %39, %9
  %.0 = phi i32 [ 0, %9 ], [ %40, %39 ], !dbg !109
  call void @llvm.dbg.value(metadata i32 %.0, metadata !106, metadata !DIExpression()), !dbg !84
  %17 = icmp slt i32 %.0, %0, !dbg !110
  br i1 %17, label %18, label %41, !dbg !112

18:                                               ; preds = %16
  %19 = mul nsw i32 %.01, %.0, !dbg !113
  %20 = add nsw i32 %19, 1, !dbg !115
  %21 = srem i32 %20, %0, !dbg !116
  %22 = sitofp i32 %21 to double, !dbg !117
  %23 = sitofp i32 %0 to double, !dbg !118
  %24 = fdiv double %22, %23, !dbg !119
  %25 = sext i32 %.01 to i64, !dbg !120
  %26 = getelementptr inbounds [250 x double], [250 x double]* %3, i64 %25, !dbg !120
  %27 = sext i32 %.0 to i64, !dbg !120
  %28 = getelementptr inbounds [250 x double], [250 x double]* %26, i64 0, i64 %27, !dbg !120
  store double %24, double* %28, align 8, !dbg !121
  %29 = mul nsw i32 %.01, %.0, !dbg !122
  %30 = add nsw i32 %29, 2, !dbg !123
  %31 = srem i32 %30, %0, !dbg !124
  %32 = sitofp i32 %31 to double, !dbg !125
  %33 = sitofp i32 %0 to double, !dbg !126
  %34 = fdiv double %32, %33, !dbg !127
  %35 = sext i32 %.01 to i64, !dbg !128
  %36 = getelementptr inbounds [250 x double], [250 x double]* %4, i64 %35, !dbg !128
  %37 = sext i32 %.0 to i64, !dbg !128
  %38 = getelementptr inbounds [250 x double], [250 x double]* %36, i64 0, i64 %37, !dbg !128
  store double %34, double* %38, align 8, !dbg !129
  br label %39, !dbg !130

39:                                               ; preds = %18
  %40 = add nsw i32 %.0, 1, !dbg !131
  call void @llvm.dbg.value(metadata i32 %40, metadata !106, metadata !DIExpression()), !dbg !84
  br label %16, !dbg !132, !llvm.loop !133

41:                                               ; preds = %16
  br label %42, !dbg !136

42:                                               ; preds = %41
  %43 = add nsw i32 %.01, 1, !dbg !137
  call void @llvm.dbg.value(metadata i32 %43, metadata !92, metadata !DIExpression()), !dbg !84
  br label %7, !dbg !138, !llvm.loop !139

44:                                               ; preds = %7
  ret void, !dbg !141
}

; Function Attrs: noinline nounwind uwtable
define dso_local i32 @task_job_polybench() #0 !dbg !142 {
  %1 = load i32, i32* @n, align 4, !dbg !143
  %2 = load double, double* @alpha, align 8, !dbg !144
  %3 = load double, double* @beta, align 8, !dbg !145
  call void @llvm.dbg.value(metadata i32 %1, metadata !146, metadata !DIExpression()), !dbg !150
  call void @llvm.dbg.value(metadata double %2, metadata !152, metadata !DIExpression()), !dbg !150
  call void @llvm.dbg.value(metadata double %3, metadata !153, metadata !DIExpression()), !dbg !150
  call void @llvm.dbg.value(metadata [250 x double]* getelementptr inbounds ([250 x [250 x double]], [250 x [250 x double]]* @A, i64 0, i64 0), metadata !154, metadata !DIExpression()), !dbg !150
  call void @llvm.dbg.value(metadata [250 x double]* getelementptr inbounds ([250 x [250 x double]], [250 x [250 x double]]* @B, i64 0, i64 0), metadata !155, metadata !DIExpression()), !dbg !150
  call void @llvm.dbg.value(metadata double* getelementptr inbounds ([250 x double], [250 x double]* @tmp, i64 0, i64 0), metadata !156, metadata !DIExpression()), !dbg !150
  call void @llvm.dbg.value(metadata double* getelementptr inbounds ([250 x double], [250 x double]* @x, i64 0, i64 0), metadata !157, metadata !DIExpression()), !dbg !150
  call void @llvm.dbg.value(metadata double* getelementptr inbounds ([250 x double], [250 x double]* @y, i64 0, i64 0), metadata !158, metadata !DIExpression()), !dbg !150
  call void @llvm.dbg.value(metadata i32 0, metadata !159, metadata !DIExpression()), !dbg !150
  br label %4, !dbg !160

4:                                                ; preds = %45, %0
  %.01 = phi i32 [ 0, %0 ], [ %57, %45 ], !dbg !162
  call void @llvm.dbg.value(metadata i32 %.01, metadata !159, metadata !DIExpression()), !dbg !150
  %5 = icmp slt i32 %.01, 250, !dbg !163
  br i1 %5, label %6, label %58, !dbg !165

6:                                                ; preds = %4
  %7 = sext i32 %.01 to i64, !dbg !166
  %8 = getelementptr inbounds double, double* getelementptr inbounds ([250 x double], [250 x double]* @tmp, i64 0, i64 0), i64 %7, !dbg !166
  store double 0.000000e+00, double* %8, align 8, !dbg !168
  %9 = sext i32 %.01 to i64, !dbg !169
  %10 = getelementptr inbounds double, double* getelementptr inbounds ([250 x double], [250 x double]* @y, i64 0, i64 0), i64 %9, !dbg !169
  store double 0.000000e+00, double* %10, align 8, !dbg !170
  call void @llvm.dbg.value(metadata i32 0, metadata !171, metadata !DIExpression()), !dbg !150
  br label %11, !dbg !172

11:                                               ; preds = %13, %6
  %.0 = phi i32 [ 0, %6 ], [ %44, %13 ], !dbg !174
  call void @llvm.dbg.value(metadata i32 %.0, metadata !171, metadata !DIExpression()), !dbg !150
  %12 = icmp slt i32 %.0, 250, !dbg !175
  br i1 %12, label %13, label %45, !dbg !177

13:                                               ; preds = %11
  %14 = sext i32 %.01 to i64, !dbg !178
  %15 = getelementptr inbounds [250 x double], [250 x double]* getelementptr inbounds ([250 x [250 x double]], [250 x [250 x double]]* @A, i64 0, i64 0), i64 %14, !dbg !178
  %16 = sext i32 %.0 to i64, !dbg !178
  %17 = getelementptr inbounds [250 x double], [250 x double]* %15, i64 0, i64 %16, !dbg !178
  %18 = load double, double* %17, align 8, !dbg !178
  %19 = sext i32 %.0 to i64, !dbg !180
  %20 = getelementptr inbounds double, double* getelementptr inbounds ([250 x double], [250 x double]* @x, i64 0, i64 0), i64 %19, !dbg !180
  %21 = load double, double* %20, align 8, !dbg !180
  %22 = fmul double %18, %21, !dbg !181
  %23 = sext i32 %.01 to i64, !dbg !182
  %24 = getelementptr inbounds double, double* getelementptr inbounds ([250 x double], [250 x double]* @tmp, i64 0, i64 0), i64 %23, !dbg !182
  %25 = load double, double* %24, align 8, !dbg !182
  %26 = fadd double %22, %25, !dbg !183
  %27 = sext i32 %.01 to i64, !dbg !184
  %28 = getelementptr inbounds double, double* getelementptr inbounds ([250 x double], [250 x double]* @tmp, i64 0, i64 0), i64 %27, !dbg !184
  store double %26, double* %28, align 8, !dbg !185
  %29 = sext i32 %.01 to i64, !dbg !186
  %30 = getelementptr inbounds [250 x double], [250 x double]* getelementptr inbounds ([250 x [250 x double]], [250 x [250 x double]]* @B, i64 0, i64 0), i64 %29, !dbg !186
  %31 = sext i32 %.0 to i64, !dbg !186
  %32 = getelementptr inbounds [250 x double], [250 x double]* %30, i64 0, i64 %31, !dbg !186
  %33 = load double, double* %32, align 8, !dbg !186
  %34 = sext i32 %.0 to i64, !dbg !187
  %35 = getelementptr inbounds double, double* getelementptr inbounds ([250 x double], [250 x double]* @x, i64 0, i64 0), i64 %34, !dbg !187
  %36 = load double, double* %35, align 8, !dbg !187
  %37 = fmul double %33, %36, !dbg !188
  %38 = sext i32 %.01 to i64, !dbg !189
  %39 = getelementptr inbounds double, double* getelementptr inbounds ([250 x double], [250 x double]* @y, i64 0, i64 0), i64 %38, !dbg !189
  %40 = load double, double* %39, align 8, !dbg !189
  %41 = fadd double %37, %40, !dbg !190
  %42 = sext i32 %.01 to i64, !dbg !191
  %43 = getelementptr inbounds double, double* getelementptr inbounds ([250 x double], [250 x double]* @y, i64 0, i64 0), i64 %42, !dbg !191
  store double %41, double* %43, align 8, !dbg !192
  %44 = add nsw i32 %.0, 1, !dbg !193
  call void @llvm.dbg.value(metadata i32 %44, metadata !171, metadata !DIExpression()), !dbg !150
  br label %11, !dbg !194, !llvm.loop !195

45:                                               ; preds = %11
  %46 = sext i32 %.01 to i64, !dbg !197
  %47 = getelementptr inbounds double, double* getelementptr inbounds ([250 x double], [250 x double]* @tmp, i64 0, i64 0), i64 %46, !dbg !197
  %48 = load double, double* %47, align 8, !dbg !197
  %49 = fmul double %2, %48, !dbg !198
  %50 = sext i32 %.01 to i64, !dbg !199
  %51 = getelementptr inbounds double, double* getelementptr inbounds ([250 x double], [250 x double]* @y, i64 0, i64 0), i64 %50, !dbg !199
  %52 = load double, double* %51, align 8, !dbg !199
  %53 = fmul double %3, %52, !dbg !200
  %54 = fadd double %49, %53, !dbg !201
  %55 = sext i32 %.01 to i64, !dbg !202
  %56 = getelementptr inbounds double, double* getelementptr inbounds ([250 x double], [250 x double]* @y, i64 0, i64 0), i64 %55, !dbg !202
  store double %54, double* %56, align 8, !dbg !203
  %57 = add nsw i32 %.01, 1, !dbg !204
  call void @llvm.dbg.value(metadata i32 %57, metadata !159, metadata !DIExpression()), !dbg !150
  br label %4, !dbg !205, !llvm.loop !206

58:                                               ; preds = %4
  ret i32 0, !dbg !208
}

; Function Attrs: noinline nounwind uwtable
define dso_local i32 @workload_checksum(i32 noundef %0) #0 !dbg !209 {
  call void @llvm.dbg.value(metadata i32 %0, metadata !212, metadata !DIExpression()), !dbg !213
  store i32 -2128831035, i32* @pb_hash, align 4, !dbg !214
  %2 = load i32, i32* @n, align 4, !dbg !215
  call void @print_array(i32 noundef %2, double* noundef getelementptr inbounds ([250 x double], [250 x double]* @y, i64 0, i64 0)), !dbg !216
  %3 = load i32, i32* @pb_hash, align 4, !dbg !217
  ret i32 %3, !dbg !218
}

; Function Attrs: noinline nounwind uwtable
define internal void @print_array(i32 noundef %0, double* noundef %1) #0 !dbg !219 {
  call void @llvm.dbg.value(metadata i32 %0, metadata !222, metadata !DIExpression()), !dbg !223
  call void @llvm.dbg.value(metadata double* %1, metadata !224, metadata !DIExpression()), !dbg !223
  %3 = load %struct._IO_FILE*, %struct._IO_FILE** @stderr, align 8, !dbg !225
  %4 = call i32 (%struct._IO_FILE*, i8*, ...) @pb_fprintf(%struct._IO_FILE* noundef %3, i8* noundef getelementptr inbounds ([23 x i8], [23 x i8]* @.str.2, i64 0, i64 0)), !dbg !225
  %5 = load %struct._IO_FILE*, %struct._IO_FILE** @stderr, align 8, !dbg !226
  %6 = call i32 (%struct._IO_FILE*, i8*, ...) @pb_fprintf(%struct._IO_FILE* noundef %5, i8* noundef getelementptr inbounds ([15 x i8], [15 x i8]* @.str.3, i64 0, i64 0), i8* noundef getelementptr inbounds ([2 x i8], [2 x i8]* @.str.4, i64 0, i64 0)), !dbg !226
  call void @llvm.dbg.value(metadata i32 0, metadata !227, metadata !DIExpression()), !dbg !223
  br label %7, !dbg !228

7:                                                ; preds = %21, %2
  %.0 = phi i32 [ 0, %2 ], [ %22, %21 ], !dbg !230
  call void @llvm.dbg.value(metadata i32 %.0, metadata !227, metadata !DIExpression()), !dbg !223
  %8 = icmp slt i32 %.0, %0, !dbg !231
  br i1 %8, label %9, label %23, !dbg !233

9:                                                ; preds = %7
  %10 = srem i32 %.0, 20, !dbg !234
  %11 = icmp eq i32 %10, 0, !dbg !237
  br i1 %11, label %12, label %15, !dbg !238

12:                                               ; preds = %9
  %13 = load %struct._IO_FILE*, %struct._IO_FILE** @stderr, align 8, !dbg !239
  %14 = call i32 (%struct._IO_FILE*, i8*, ...) @pb_fprintf(%struct._IO_FILE* noundef %13, i8* noundef getelementptr inbounds ([2 x i8], [2 x i8]* @.str.5, i64 0, i64 0)), !dbg !240
  br label %15, !dbg !240

15:                                               ; preds = %12, %9
  %16 = load %struct._IO_FILE*, %struct._IO_FILE** @stderr, align 8, !dbg !241
  %17 = sext i32 %.0 to i64, !dbg !242
  %18 = getelementptr inbounds double, double* %1, i64 %17, !dbg !242
  %19 = load double, double* %18, align 8, !dbg !242
  %20 = call i32 (%struct._IO_FILE*, i8*, ...) @pb_fprintf(%struct._IO_FILE* noundef %16, i8* noundef getelementptr inbounds ([8 x i8], [8 x i8]* @.str.6, i64 0, i64 0), double noundef %19), !dbg !243
  br label %21, !dbg !244

21:                                               ; preds = %15
  %22 = add nsw i32 %.0, 1, !dbg !245
  call void @llvm.dbg.value(metadata i32 %22, metadata !227, metadata !DIExpression()), !dbg !223
  br label %7, !dbg !246, !llvm.loop !247

23:                                               ; preds = %7
  %24 = load %struct._IO_FILE*, %struct._IO_FILE** @stderr, align 8, !dbg !249
  %25 = call i32 (%struct._IO_FILE*, i8*, ...) @pb_fprintf(%struct._IO_FILE* noundef %24, i8* noundef getelementptr inbounds ([17 x i8], [17 x i8]* @.str.7, i64 0, i64 0), i8* noundef getelementptr inbounds ([2 x i8], [2 x i8]* @.str.4, i64 0, i64 0)), !dbg !249
  %26 = load %struct._IO_FILE*, %struct._IO_FILE** @stderr, align 8, !dbg !250
  %27 = call i32 (%struct._IO_FILE*, i8*, ...) @pb_fprintf(%struct._IO_FILE* noundef %26, i8* noundef getelementptr inbounds ([23 x i8], [23 x i8]* @.str.8, i64 0, i64 0)), !dbg !250
  ret void, !dbg !251
}

; Function Attrs: noinline nounwind uwtable
define internal i32 @pb_fprintf(%struct._IO_FILE* noundef %0, i8* noundef %1, ...) #0 !dbg !252 {
  %3 = alloca [768 x i8], align 16
  %4 = alloca [1 x %struct.__va_list_tag], align 16
  call void @llvm.dbg.value(metadata %struct._IO_FILE* %0, metadata !316, metadata !DIExpression()), !dbg !317
  call void @llvm.dbg.value(metadata i8* %1, metadata !318, metadata !DIExpression()), !dbg !317
  call void @llvm.dbg.declare(metadata [768 x i8]* %3, metadata !319, metadata !DIExpression()), !dbg !323
  call void @llvm.dbg.declare(metadata [1 x %struct.__va_list_tag]* %4, metadata !324, metadata !DIExpression()), !dbg !338
  %5 = getelementptr inbounds [1 x %struct.__va_list_tag], [1 x %struct.__va_list_tag]* %4, i64 0, i64 0, !dbg !339
  %6 = bitcast %struct.__va_list_tag* %5 to i8*, !dbg !339
  call void @llvm.va_start(i8* %6), !dbg !339
  %7 = getelementptr inbounds [768 x i8], [768 x i8]* %3, i64 0, i64 0, !dbg !340
  %8 = getelementptr inbounds [1 x %struct.__va_list_tag], [1 x %struct.__va_list_tag]* %4, i64 0, i64 0, !dbg !341
  %9 = call i32 @vsnprintf(i8* noundef %7, i64 noundef 768, i8* noundef %1, %struct.__va_list_tag* noundef %8) #6, !dbg !342
  call void @llvm.dbg.value(metadata i32 %9, metadata !343, metadata !DIExpression()), !dbg !317
  %10 = getelementptr inbounds [1 x %struct.__va_list_tag], [1 x %struct.__va_list_tag]* %4, i64 0, i64 0, !dbg !344
  %11 = bitcast %struct.__va_list_tag* %10 to i8*, !dbg !344
  call void @llvm.va_end(i8* %11), !dbg !344
  %12 = icmp slt i32 %9, 0, !dbg !345
  br i1 %12, label %16, label %13, !dbg !347

13:                                               ; preds = %2
  %14 = zext i32 %9 to i64, !dbg !348
  %15 = icmp uge i64 %14, 768, !dbg !349
  br i1 %15, label %16, label %17, !dbg !350

16:                                               ; preds = %13, %2
  call void @abort() #7, !dbg !351
  unreachable, !dbg !351

17:                                               ; preds = %13
  call void @llvm.dbg.value(metadata i32 0, metadata !352, metadata !DIExpression()), !dbg !354
  br label %18, !dbg !355

18:                                               ; preds = %29, %17
  %.0 = phi i32 [ 0, %17 ], [ %30, %29 ], !dbg !354
  call void @llvm.dbg.value(metadata i32 %.0, metadata !352, metadata !DIExpression()), !dbg !354
  %19 = icmp slt i32 %.0, %9, !dbg !356
  br i1 %19, label %20, label %31, !dbg !358

20:                                               ; preds = %18
  %21 = sext i32 %.0 to i64, !dbg !359
  %22 = getelementptr inbounds [768 x i8], [768 x i8]* %3, i64 0, i64 %21, !dbg !359
  %23 = load i8, i8* %22, align 1, !dbg !359
  %24 = zext i8 %23 to i32, !dbg !361
  %25 = load i32, i32* @pb_hash, align 4, !dbg !362
  %26 = xor i32 %25, %24, !dbg !362
  store i32 %26, i32* @pb_hash, align 4, !dbg !362
  %27 = load i32, i32* @pb_hash, align 4, !dbg !363
  %28 = mul i32 %27, 16777619, !dbg !363
  store i32 %28, i32* @pb_hash, align 4, !dbg !363
  br label %29, !dbg !364

29:                                               ; preds = %20
  %30 = add nsw i32 %.0, 1, !dbg !365
  call void @llvm.dbg.value(metadata i32 %30, metadata !352, metadata !DIExpression()), !dbg !354
  br label %18, !dbg !366, !llvm.loop !367

31:                                               ; preds = %18
  %32 = load i32, i32* @pb_emit, align 4, !dbg !369
  ret i32 %9, !dbg !370
}

; Function Attrs: nofree nosync nounwind willreturn
declare void @llvm.va_start(i8*) #3

; Function Attrs: nounwind
declare i32 @vsnprintf(i8* noundef, i64 noundef, i8* noundef, %struct.__va_list_tag* noundef) #4

; Function Attrs: nofree nosync nounwind willreturn
declare void @llvm.va_end(i8*) #3

; Function Attrs: noreturn nounwind
declare void @abort() #5

; Function Attrs: nofree nosync nounwind readnone speculatable willreturn
declare void @llvm.dbg.value(metadata, metadata, metadata) #1

attributes #0 = { noinline nounwind uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { nofree nosync nounwind readnone speculatable willreturn }
attributes #2 = { argmemonly nofree nounwind willreturn writeonly }
attributes #3 = { nofree nosync nounwind willreturn }
attributes #4 = { nounwind "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #5 = { noreturn nounwind "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #6 = { nounwind }
attributes #7 = { noreturn nounwind }

!llvm.dbg.cu = !{!2}
!llvm.module.flags = !{!52, !53, !54, !55, !56, !57, !58}
!llvm.ident = !{!59}

!0 = !DIGlobalVariableExpression(var: !1, expr: !DIExpression())
!1 = distinct !DIGlobalVariable(name: "n", scope: !2, file: !11, line: 114, type: !51, isLocal: false, isDefinition: true)
!2 = distinct !DICompileUnit(language: DW_LANG_C99, file: !3, producer: "Ubuntu clang version 14.0.0-1ubuntu1.1", isOptimized: false, runtimeVersion: 0, emissionKind: FullDebug, retainedTypes: !4, globals: !8, splitDebugInlining: false, nameTableKind: None)
!3 = !DIFile(filename: "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/triangular-20260929/suite/gesummv/source/workload.c", directory: "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/triangular-20260929/suite/gesummv/analysis-c", checksumkind: CSK_MD5, checksum: "17ed6c5da7bdfa8dc19e6a06ceadf214")
!4 = !{!5, !6, !7}
!5 = !DIBasicType(name: "double", size: 64, encoding: DW_ATE_float)
!6 = !DIBasicType(name: "unsigned int", size: 32, encoding: DW_ATE_unsigned)
!7 = !DIBasicType(name: "unsigned char", size: 8, encoding: DW_ATE_unsigned_char)
!8 = !{!0, !9, !23, !27, !30, !35, !37, !41, !43, !45, !47, !49}
!9 = !DIGlobalVariableExpression(var: !10, expr: !DIExpression())
!10 = distinct !DIGlobalVariable(name: "workload_jobs", scope: !2, file: !11, line: 147, type: !12, isLocal: false, isDefinition: true)
!11 = !DIFile(filename: "source/workload.c", directory: "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/triangular-20260929/suite/gesummv", checksumkind: CSK_MD5, checksum: "17ed6c5da7bdfa8dc19e6a06ceadf214")
!12 = !DICompositeType(tag: DW_TAG_array_type, baseType: !13, size: 64, elements: !21)
!13 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !14)
!14 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !15, size: 64)
!15 = !DISubroutineType(types: !16)
!16 = !{!17}
!17 = !DIDerivedType(tag: DW_TAG_typedef, name: "uint32_t", file: !18, line: 26, baseType: !19)
!18 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/stdint-uintn.h", directory: "", checksumkind: CSK_MD5, checksum: "2bf2ae53c58c01b1a1b9383b5195125c")
!19 = !DIDerivedType(tag: DW_TAG_typedef, name: "__uint32_t", file: !20, line: 42, baseType: !6)
!20 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/types.h", directory: "", checksumkind: CSK_MD5, checksum: "d108b5f93a74c50510d7d9bc0ab36df9")
!21 = !{!22}
!22 = !DISubrange(count: 1)
!23 = !DIGlobalVariableExpression(var: !24, expr: !DIExpression())
!24 = distinct !DIGlobalVariable(name: "workload_expected", scope: !2, file: !11, line: 151, type: !25, isLocal: false, isDefinition: true)
!25 = !DICompositeType(tag: DW_TAG_array_type, baseType: !26, size: 32, elements: !21)
!26 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !17)
!27 = !DIGlobalVariableExpression(var: !28, expr: !DIExpression())
!28 = distinct !DIGlobalVariable(name: "pb_hash", scope: !2, file: !29, line: 9, type: !17, isLocal: true, isDefinition: true)
!29 = !DIFile(filename: "source/adapter.h", directory: "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/triangular-20260929/suite/gesummv", checksumkind: CSK_MD5, checksum: "26a6068928b2092758f244a9d00163d7")
!30 = !DIGlobalVariableExpression(var: !31, expr: !DIExpression())
!31 = distinct !DIGlobalVariable(name: "A", scope: !2, file: !11, line: 34, type: !32, isLocal: false, isDefinition: true, align: 512)
!32 = !DICompositeType(tag: DW_TAG_array_type, baseType: !5, size: 4000000, elements: !33)
!33 = !{!34, !34}
!34 = !DISubrange(count: 250)
!35 = !DIGlobalVariableExpression(var: !36, expr: !DIExpression())
!36 = distinct !DIGlobalVariable(name: "B", scope: !2, file: !11, line: 35, type: !32, isLocal: false, isDefinition: true, align: 512)
!37 = !DIGlobalVariableExpression(var: !38, expr: !DIExpression())
!38 = distinct !DIGlobalVariable(name: "tmp", scope: !2, file: !11, line: 36, type: !39, isLocal: false, isDefinition: true, align: 512)
!39 = !DICompositeType(tag: DW_TAG_array_type, baseType: !5, size: 16000, elements: !40)
!40 = !{!34}
!41 = !DIGlobalVariableExpression(var: !42, expr: !DIExpression())
!42 = distinct !DIGlobalVariable(name: "x", scope: !2, file: !11, line: 37, type: !39, isLocal: false, isDefinition: true, align: 512)
!43 = !DIGlobalVariableExpression(var: !44, expr: !DIExpression())
!44 = distinct !DIGlobalVariable(name: "y", scope: !2, file: !11, line: 38, type: !39, isLocal: false, isDefinition: true, align: 512)
!45 = !DIGlobalVariableExpression(var: !46, expr: !DIExpression())
!46 = distinct !DIGlobalVariable(name: "alpha", scope: !2, file: !11, line: 117, type: !5, isLocal: false, isDefinition: true)
!47 = !DIGlobalVariableExpression(var: !48, expr: !DIExpression())
!48 = distinct !DIGlobalVariable(name: "beta", scope: !2, file: !11, line: 118, type: !5, isLocal: false, isDefinition: true)
!49 = !DIGlobalVariableExpression(var: !50, expr: !DIExpression())
!50 = distinct !DIGlobalVariable(name: "pb_emit", scope: !2, file: !29, line: 10, type: !51, isLocal: true, isDefinition: true)
!51 = !DIBasicType(name: "int", size: 32, encoding: DW_ATE_signed)
!52 = !{i32 7, !"Dwarf Version", i32 5}
!53 = !{i32 2, !"Debug Info Version", i32 3}
!54 = !{i32 1, !"wchar_size", i32 4}
!55 = !{i32 7, !"PIC Level", i32 2}
!56 = !{i32 7, !"PIE Level", i32 2}
!57 = !{i32 7, !"uwtable", i32 1}
!58 = !{i32 7, !"frame-pointer", i32 2}
!59 = !{!"Ubuntu clang version 14.0.0-1ubuntu1.1"}
!60 = distinct !DISubprogram(name: "workload_prepare", scope: !11, file: !11, line: 119, type: !61, scopeLine: 119, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !2, retainedNodes: !63)
!61 = !DISubroutineType(types: !62)
!62 = !{null}
!63 = !{}
!64 = !DILocation(line: 119, column: 30, scope: !60)
!65 = distinct !DISubprogram(name: "workload_reset", scope: !11, file: !11, line: 120, type: !66, scopeLine: 120, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !2, retainedNodes: !63)
!66 = !DISubroutineType(types: !67)
!67 = !{null, !6}
!68 = !DILocalVariable(name: "task", arg: 1, scope: !65, file: !11, line: 120, type: !6)
!69 = !DILocation(line: 0, scope: !65)
!70 = !DILocation(line: 122, column: 3, scope: !65)
!71 = !DILocation(line: 123, column: 3, scope: !65)
!72 = !DILocation(line: 124, column: 3, scope: !65)
!73 = !DILocation(line: 125, column: 3, scope: !65)
!74 = !DILocation(line: 126, column: 3, scope: !65)
!75 = !DILocation(line: 127, column: 15, scope: !65)
!76 = !DILocation(line: 127, column: 3, scope: !65)
!77 = !DILocation(line: 131, column: 1, scope: !65)
!78 = distinct !DISubprogram(name: "init_array", scope: !11, file: !11, line: 40, type: !79, scopeLine: 46, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition, unit: !2, retainedNodes: !63)
!79 = !DISubroutineType(types: !80)
!80 = !{null, !51, !81, !81, !82, !82, !81}
!81 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !5, size: 64)
!82 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !39, size: 64)
!83 = !DILocalVariable(name: "n", arg: 1, scope: !78, file: !11, line: 40, type: !51)
!84 = !DILocation(line: 0, scope: !78)
!85 = !DILocalVariable(name: "alpha", arg: 2, scope: !78, file: !11, line: 41, type: !81)
!86 = !DILocalVariable(name: "beta", arg: 3, scope: !78, file: !11, line: 42, type: !81)
!87 = !DILocalVariable(name: "A", arg: 4, scope: !78, file: !11, line: 43, type: !82)
!88 = !DILocalVariable(name: "B", arg: 5, scope: !78, file: !11, line: 44, type: !82)
!89 = !DILocalVariable(name: "x", arg: 6, scope: !78, file: !11, line: 45, type: !81)
!90 = !DILocation(line: 49, column: 10, scope: !78)
!91 = !DILocation(line: 50, column: 9, scope: !78)
!92 = !DILocalVariable(name: "i", scope: !78, file: !11, line: 47, type: !51)
!93 = !DILocation(line: 51, column: 8, scope: !94)
!94 = distinct !DILexicalBlock(scope: !78, file: !11, line: 51, column: 3)
!95 = !DILocation(line: 0, scope: !94)
!96 = !DILocation(line: 51, column: 17, scope: !97)
!97 = distinct !DILexicalBlock(scope: !94, file: !11, line: 51, column: 3)
!98 = !DILocation(line: 51, column: 3, scope: !94)
!99 = !DILocation(line: 53, column: 29, scope: !100)
!100 = distinct !DILexicalBlock(scope: !97, file: !11, line: 52, column: 5)
!101 = !DILocation(line: 53, column: 14, scope: !100)
!102 = !DILocation(line: 53, column: 36, scope: !100)
!103 = !DILocation(line: 53, column: 34, scope: !100)
!104 = !DILocation(line: 53, column: 7, scope: !100)
!105 = !DILocation(line: 53, column: 12, scope: !100)
!106 = !DILocalVariable(name: "j", scope: !78, file: !11, line: 47, type: !51)
!107 = !DILocation(line: 54, column: 12, scope: !108)
!108 = distinct !DILexicalBlock(scope: !100, file: !11, line: 54, column: 7)
!109 = !DILocation(line: 0, scope: !108)
!110 = !DILocation(line: 54, column: 21, scope: !111)
!111 = distinct !DILexicalBlock(scope: !108, file: !11, line: 54, column: 7)
!112 = !DILocation(line: 54, column: 7, scope: !108)
!113 = !DILocation(line: 55, column: 27, scope: !114)
!114 = distinct !DILexicalBlock(scope: !111, file: !11, line: 54, column: 31)
!115 = !DILocation(line: 55, column: 29, scope: !114)
!116 = !DILocation(line: 55, column: 33, scope: !114)
!117 = !DILocation(line: 55, column: 12, scope: !114)
!118 = !DILocation(line: 55, column: 40, scope: !114)
!119 = !DILocation(line: 55, column: 38, scope: !114)
!120 = !DILocation(line: 55, column: 2, scope: !114)
!121 = !DILocation(line: 55, column: 10, scope: !114)
!122 = !DILocation(line: 56, column: 27, scope: !114)
!123 = !DILocation(line: 56, column: 29, scope: !114)
!124 = !DILocation(line: 56, column: 33, scope: !114)
!125 = !DILocation(line: 56, column: 12, scope: !114)
!126 = !DILocation(line: 56, column: 40, scope: !114)
!127 = !DILocation(line: 56, column: 38, scope: !114)
!128 = !DILocation(line: 56, column: 2, scope: !114)
!129 = !DILocation(line: 56, column: 10, scope: !114)
!130 = !DILocation(line: 57, column: 7, scope: !114)
!131 = !DILocation(line: 54, column: 27, scope: !111)
!132 = !DILocation(line: 54, column: 7, scope: !111)
!133 = distinct !{!133, !112, !134, !135}
!134 = !DILocation(line: 57, column: 7, scope: !108)
!135 = !{!"llvm.loop.mustprogress"}
!136 = !DILocation(line: 58, column: 5, scope: !100)
!137 = !DILocation(line: 51, column: 23, scope: !97)
!138 = !DILocation(line: 51, column: 3, scope: !97)
!139 = distinct !{!139, !98, !140, !135}
!140 = !DILocation(line: 58, column: 5, scope: !94)
!141 = !DILocation(line: 59, column: 1, scope: !78)
!142 = distinct !DISubprogram(name: "task_job_polybench", scope: !11, file: !11, line: 132, type: !15, scopeLine: 132, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !2, retainedNodes: !63)
!143 = !DILocation(line: 133, column: 19, scope: !142)
!144 = !DILocation(line: 133, column: 22, scope: !142)
!145 = !DILocation(line: 133, column: 29, scope: !142)
!146 = !DILocalVariable(name: "n", arg: 1, scope: !147, file: !11, line: 85, type: !51)
!147 = distinct !DISubprogram(name: "kernel_gesummv", scope: !11, file: !11, line: 85, type: !148, scopeLine: 93, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition, unit: !2, retainedNodes: !63)
!148 = !DISubroutineType(types: !149)
!149 = !{null, !51, !5, !5, !82, !82, !81, !81, !81}
!150 = !DILocation(line: 0, scope: !147, inlinedAt: !151)
!151 = distinct !DILocation(line: 133, column: 3, scope: !142)
!152 = !DILocalVariable(name: "alpha", arg: 2, scope: !147, file: !11, line: 86, type: !5)
!153 = !DILocalVariable(name: "beta", arg: 3, scope: !147, file: !11, line: 87, type: !5)
!154 = !DILocalVariable(name: "A", arg: 4, scope: !147, file: !11, line: 88, type: !82)
!155 = !DILocalVariable(name: "B", arg: 5, scope: !147, file: !11, line: 89, type: !82)
!156 = !DILocalVariable(name: "tmp", arg: 6, scope: !147, file: !11, line: 90, type: !81)
!157 = !DILocalVariable(name: "x", arg: 7, scope: !147, file: !11, line: 91, type: !81)
!158 = !DILocalVariable(name: "y", arg: 8, scope: !147, file: !11, line: 92, type: !81)
!159 = !DILocalVariable(name: "i", scope: !147, file: !11, line: 94, type: !51)
!160 = !DILocation(line: 97, column: 8, scope: !161, inlinedAt: !151)
!161 = distinct !DILexicalBlock(scope: !147, file: !11, line: 97, column: 3)
!162 = !DILocation(line: 0, scope: !161, inlinedAt: !151)
!163 = !DILocation(line: 97, column: 17, scope: !164, inlinedAt: !151)
!164 = distinct !DILexicalBlock(scope: !161, file: !11, line: 97, column: 3)
!165 = !DILocation(line: 97, column: 3, scope: !161, inlinedAt: !151)
!166 = !DILocation(line: 99, column: 7, scope: !167, inlinedAt: !151)
!167 = distinct !DILexicalBlock(scope: !164, file: !11, line: 98, column: 5)
!168 = !DILocation(line: 99, column: 14, scope: !167, inlinedAt: !151)
!169 = !DILocation(line: 100, column: 7, scope: !167, inlinedAt: !151)
!170 = !DILocation(line: 100, column: 12, scope: !167, inlinedAt: !151)
!171 = !DILocalVariable(name: "j", scope: !147, file: !11, line: 94, type: !51)
!172 = !DILocation(line: 101, column: 12, scope: !173, inlinedAt: !151)
!173 = distinct !DILexicalBlock(scope: !167, file: !11, line: 101, column: 7)
!174 = !DILocation(line: 0, scope: !173, inlinedAt: !151)
!175 = !DILocation(line: 101, column: 21, scope: !176, inlinedAt: !151)
!176 = distinct !DILexicalBlock(scope: !173, file: !11, line: 101, column: 7)
!177 = !DILocation(line: 101, column: 7, scope: !173, inlinedAt: !151)
!178 = !DILocation(line: 103, column: 13, scope: !179, inlinedAt: !151)
!179 = distinct !DILexicalBlock(scope: !176, file: !11, line: 102, column: 2)
!180 = !DILocation(line: 103, column: 23, scope: !179, inlinedAt: !151)
!181 = !DILocation(line: 103, column: 21, scope: !179, inlinedAt: !151)
!182 = !DILocation(line: 103, column: 30, scope: !179, inlinedAt: !151)
!183 = !DILocation(line: 103, column: 28, scope: !179, inlinedAt: !151)
!184 = !DILocation(line: 103, column: 4, scope: !179, inlinedAt: !151)
!185 = !DILocation(line: 103, column: 11, scope: !179, inlinedAt: !151)
!186 = !DILocation(line: 104, column: 11, scope: !179, inlinedAt: !151)
!187 = !DILocation(line: 104, column: 21, scope: !179, inlinedAt: !151)
!188 = !DILocation(line: 104, column: 19, scope: !179, inlinedAt: !151)
!189 = !DILocation(line: 104, column: 28, scope: !179, inlinedAt: !151)
!190 = !DILocation(line: 104, column: 26, scope: !179, inlinedAt: !151)
!191 = !DILocation(line: 104, column: 4, scope: !179, inlinedAt: !151)
!192 = !DILocation(line: 104, column: 9, scope: !179, inlinedAt: !151)
!193 = !DILocation(line: 101, column: 31, scope: !176, inlinedAt: !151)
!194 = !DILocation(line: 101, column: 7, scope: !176, inlinedAt: !151)
!195 = distinct !{!195, !177, !196, !135}
!196 = !DILocation(line: 105, column: 2, scope: !173, inlinedAt: !151)
!197 = !DILocation(line: 106, column: 22, scope: !167, inlinedAt: !151)
!198 = !DILocation(line: 106, column: 20, scope: !167, inlinedAt: !151)
!199 = !DILocation(line: 106, column: 38, scope: !167, inlinedAt: !151)
!200 = !DILocation(line: 106, column: 36, scope: !167, inlinedAt: !151)
!201 = !DILocation(line: 106, column: 29, scope: !167, inlinedAt: !151)
!202 = !DILocation(line: 106, column: 7, scope: !167, inlinedAt: !151)
!203 = !DILocation(line: 106, column: 12, scope: !167, inlinedAt: !151)
!204 = !DILocation(line: 97, column: 27, scope: !164, inlinedAt: !151)
!205 = !DILocation(line: 97, column: 3, scope: !164, inlinedAt: !151)
!206 = distinct !{!206, !165, !207, !135}
!207 = !DILocation(line: 107, column: 5, scope: !161, inlinedAt: !151)
!208 = !DILocation(line: 139, column: 3, scope: !142)
!209 = distinct !DISubprogram(name: "workload_checksum", scope: !11, file: !11, line: 141, type: !210, scopeLine: 141, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !2, retainedNodes: !63)
!210 = !DISubroutineType(types: !211)
!211 = !{!17, !6}
!212 = !DILocalVariable(name: "task", arg: 1, scope: !209, file: !11, line: 141, type: !6)
!213 = !DILocation(line: 0, scope: !209)
!214 = !DILocation(line: 143, column: 11, scope: !209)
!215 = !DILocation(line: 144, column: 15, scope: !209)
!216 = !DILocation(line: 144, column: 3, scope: !209)
!217 = !DILocation(line: 145, column: 10, scope: !209)
!218 = !DILocation(line: 145, column: 3, scope: !209)
!219 = distinct !DISubprogram(name: "print_array", scope: !11, file: !11, line: 65, type: !220, scopeLine: 68, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition, unit: !2, retainedNodes: !63)
!220 = !DISubroutineType(types: !221)
!221 = !{null, !51, !81}
!222 = !DILocalVariable(name: "n", arg: 1, scope: !219, file: !11, line: 65, type: !51)
!223 = !DILocation(line: 0, scope: !219)
!224 = !DILocalVariable(name: "y", arg: 2, scope: !219, file: !11, line: 66, type: !81)
!225 = !DILocation(line: 71, column: 3, scope: !219)
!226 = !DILocation(line: 72, column: 3, scope: !219)
!227 = !DILocalVariable(name: "i", scope: !219, file: !11, line: 69, type: !51)
!228 = !DILocation(line: 73, column: 8, scope: !229)
!229 = distinct !DILexicalBlock(scope: !219, file: !11, line: 73, column: 3)
!230 = !DILocation(line: 0, scope: !229)
!231 = !DILocation(line: 73, column: 17, scope: !232)
!232 = distinct !DILexicalBlock(scope: !229, file: !11, line: 73, column: 3)
!233 = !DILocation(line: 73, column: 3, scope: !229)
!234 = !DILocation(line: 74, column: 11, scope: !235)
!235 = distinct !DILexicalBlock(scope: !236, file: !11, line: 74, column: 9)
!236 = distinct !DILexicalBlock(scope: !232, file: !11, line: 73, column: 27)
!237 = !DILocation(line: 74, column: 16, scope: !235)
!238 = !DILocation(line: 74, column: 9, scope: !236)
!239 = !DILocation(line: 74, column: 31, scope: !235)
!240 = !DILocation(line: 74, column: 22, scope: !235)
!241 = !DILocation(line: 75, column: 14, scope: !236)
!242 = !DILocation(line: 75, column: 59, scope: !236)
!243 = !DILocation(line: 75, column: 5, scope: !236)
!244 = !DILocation(line: 76, column: 3, scope: !236)
!245 = !DILocation(line: 73, column: 23, scope: !232)
!246 = !DILocation(line: 73, column: 3, scope: !232)
!247 = distinct !{!247, !233, !248, !135}
!248 = !DILocation(line: 76, column: 3, scope: !229)
!249 = !DILocation(line: 77, column: 3, scope: !219)
!250 = !DILocation(line: 78, column: 3, scope: !219)
!251 = !DILocation(line: 79, column: 1, scope: !219)
!252 = distinct !DISubprogram(name: "pb_fprintf", scope: !29, file: !29, line: 13, type: !253, scopeLine: 14, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition, unit: !2, retainedNodes: !63)
!253 = !DISubroutineType(types: !254)
!254 = !{!51, !255, !314, null}
!255 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !256, size: 64)
!256 = !DIDerivedType(tag: DW_TAG_typedef, name: "FILE", file: !257, line: 7, baseType: !258)
!257 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/types/FILE.h", directory: "", checksumkind: CSK_MD5, checksum: "571f9fb6223c42439075fdde11a0de5d")
!258 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "_IO_FILE", file: !259, line: 49, size: 1728, elements: !260)
!259 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/types/struct_FILE.h", directory: "", checksumkind: CSK_MD5, checksum: "1bad07471b7974df4ecc1d1c2ca207e6")
!260 = !{!261, !262, !265, !266, !267, !268, !269, !270, !271, !272, !273, !274, !275, !278, !280, !281, !282, !285, !287, !289, !291, !294, !296, !299, !302, !303, !305, !309, !310}
!261 = !DIDerivedType(tag: DW_TAG_member, name: "_flags", scope: !258, file: !259, line: 51, baseType: !51, size: 32)
!262 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_read_ptr", scope: !258, file: !259, line: 54, baseType: !263, size: 64, offset: 64)
!263 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !264, size: 64)
!264 = !DIBasicType(name: "char", size: 8, encoding: DW_ATE_signed_char)
!265 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_read_end", scope: !258, file: !259, line: 55, baseType: !263, size: 64, offset: 128)
!266 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_read_base", scope: !258, file: !259, line: 56, baseType: !263, size: 64, offset: 192)
!267 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_write_base", scope: !258, file: !259, line: 57, baseType: !263, size: 64, offset: 256)
!268 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_write_ptr", scope: !258, file: !259, line: 58, baseType: !263, size: 64, offset: 320)
!269 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_write_end", scope: !258, file: !259, line: 59, baseType: !263, size: 64, offset: 384)
!270 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_buf_base", scope: !258, file: !259, line: 60, baseType: !263, size: 64, offset: 448)
!271 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_buf_end", scope: !258, file: !259, line: 61, baseType: !263, size: 64, offset: 512)
!272 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_save_base", scope: !258, file: !259, line: 64, baseType: !263, size: 64, offset: 576)
!273 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_backup_base", scope: !258, file: !259, line: 65, baseType: !263, size: 64, offset: 640)
!274 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_save_end", scope: !258, file: !259, line: 66, baseType: !263, size: 64, offset: 704)
!275 = !DIDerivedType(tag: DW_TAG_member, name: "_markers", scope: !258, file: !259, line: 68, baseType: !276, size: 64, offset: 768)
!276 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !277, size: 64)
!277 = !DICompositeType(tag: DW_TAG_structure_type, name: "_IO_marker", file: !259, line: 36, flags: DIFlagFwdDecl)
!278 = !DIDerivedType(tag: DW_TAG_member, name: "_chain", scope: !258, file: !259, line: 70, baseType: !279, size: 64, offset: 832)
!279 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !258, size: 64)
!280 = !DIDerivedType(tag: DW_TAG_member, name: "_fileno", scope: !258, file: !259, line: 72, baseType: !51, size: 32, offset: 896)
!281 = !DIDerivedType(tag: DW_TAG_member, name: "_flags2", scope: !258, file: !259, line: 73, baseType: !51, size: 32, offset: 928)
!282 = !DIDerivedType(tag: DW_TAG_member, name: "_old_offset", scope: !258, file: !259, line: 74, baseType: !283, size: 64, offset: 960)
!283 = !DIDerivedType(tag: DW_TAG_typedef, name: "__off_t", file: !20, line: 152, baseType: !284)
!284 = !DIBasicType(name: "long", size: 64, encoding: DW_ATE_signed)
!285 = !DIDerivedType(tag: DW_TAG_member, name: "_cur_column", scope: !258, file: !259, line: 77, baseType: !286, size: 16, offset: 1024)
!286 = !DIBasicType(name: "unsigned short", size: 16, encoding: DW_ATE_unsigned)
!287 = !DIDerivedType(tag: DW_TAG_member, name: "_vtable_offset", scope: !258, file: !259, line: 78, baseType: !288, size: 8, offset: 1040)
!288 = !DIBasicType(name: "signed char", size: 8, encoding: DW_ATE_signed_char)
!289 = !DIDerivedType(tag: DW_TAG_member, name: "_shortbuf", scope: !258, file: !259, line: 79, baseType: !290, size: 8, offset: 1048)
!290 = !DICompositeType(tag: DW_TAG_array_type, baseType: !264, size: 8, elements: !21)
!291 = !DIDerivedType(tag: DW_TAG_member, name: "_lock", scope: !258, file: !259, line: 81, baseType: !292, size: 64, offset: 1088)
!292 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !293, size: 64)
!293 = !DIDerivedType(tag: DW_TAG_typedef, name: "_IO_lock_t", file: !259, line: 43, baseType: null)
!294 = !DIDerivedType(tag: DW_TAG_member, name: "_offset", scope: !258, file: !259, line: 89, baseType: !295, size: 64, offset: 1152)
!295 = !DIDerivedType(tag: DW_TAG_typedef, name: "__off64_t", file: !20, line: 153, baseType: !284)
!296 = !DIDerivedType(tag: DW_TAG_member, name: "_codecvt", scope: !258, file: !259, line: 91, baseType: !297, size: 64, offset: 1216)
!297 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !298, size: 64)
!298 = !DICompositeType(tag: DW_TAG_structure_type, name: "_IO_codecvt", file: !259, line: 37, flags: DIFlagFwdDecl)
!299 = !DIDerivedType(tag: DW_TAG_member, name: "_wide_data", scope: !258, file: !259, line: 92, baseType: !300, size: 64, offset: 1280)
!300 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !301, size: 64)
!301 = !DICompositeType(tag: DW_TAG_structure_type, name: "_IO_wide_data", file: !259, line: 38, flags: DIFlagFwdDecl)
!302 = !DIDerivedType(tag: DW_TAG_member, name: "_freeres_list", scope: !258, file: !259, line: 93, baseType: !279, size: 64, offset: 1344)
!303 = !DIDerivedType(tag: DW_TAG_member, name: "_freeres_buf", scope: !258, file: !259, line: 94, baseType: !304, size: 64, offset: 1408)
!304 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: null, size: 64)
!305 = !DIDerivedType(tag: DW_TAG_member, name: "__pad5", scope: !258, file: !259, line: 95, baseType: !306, size: 64, offset: 1472)
!306 = !DIDerivedType(tag: DW_TAG_typedef, name: "size_t", file: !307, line: 46, baseType: !308)
!307 = !DIFile(filename: "/usr/lib/llvm-14/lib/clang/14.0.0/include/stddef.h", directory: "", checksumkind: CSK_MD5, checksum: "2499dd2361b915724b073282bea3a7bc")
!308 = !DIBasicType(name: "unsigned long", size: 64, encoding: DW_ATE_unsigned)
!309 = !DIDerivedType(tag: DW_TAG_member, name: "_mode", scope: !258, file: !259, line: 96, baseType: !51, size: 32, offset: 1536)
!310 = !DIDerivedType(tag: DW_TAG_member, name: "_unused2", scope: !258, file: !259, line: 98, baseType: !311, size: 160, offset: 1568)
!311 = !DICompositeType(tag: DW_TAG_array_type, baseType: !264, size: 160, elements: !312)
!312 = !{!313}
!313 = !DISubrange(count: 20)
!314 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !315, size: 64)
!315 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !264)
!316 = !DILocalVariable(name: "stream", arg: 1, scope: !252, file: !29, line: 13, type: !255)
!317 = !DILocation(line: 0, scope: !252)
!318 = !DILocalVariable(name: "format", arg: 2, scope: !252, file: !29, line: 13, type: !314)
!319 = !DILocalVariable(name: "buffer", scope: !252, file: !29, line: 15, type: !320)
!320 = !DICompositeType(tag: DW_TAG_array_type, baseType: !264, size: 6144, elements: !321)
!321 = !{!322}
!322 = !DISubrange(count: 768)
!323 = !DILocation(line: 15, column: 10, scope: !252)
!324 = !DILocalVariable(name: "args", scope: !252, file: !29, line: 16, type: !325)
!325 = !DIDerivedType(tag: DW_TAG_typedef, name: "va_list", file: !326, line: 52, baseType: !327)
!326 = !DIFile(filename: "/usr/include/stdio.h", directory: "", checksumkind: CSK_MD5, checksum: "f31eefcc3f15835fc5a4023a625cf609")
!327 = !DIDerivedType(tag: DW_TAG_typedef, name: "__gnuc_va_list", file: !328, line: 32, baseType: !329)
!328 = !DIFile(filename: "/usr/lib/llvm-14/lib/clang/14.0.0/include/stdarg.h", directory: "", checksumkind: CSK_MD5, checksum: "4de3cbd931b589d291e5c39387aecf82")
!329 = !DIDerivedType(tag: DW_TAG_typedef, name: "__builtin_va_list", file: !330, baseType: !331)
!330 = !DIFile(filename: "source/workload.c", directory: "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/triangular-20260929/suite/gesummv")
!331 = !DICompositeType(tag: DW_TAG_array_type, baseType: !332, size: 192, elements: !21)
!332 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "__va_list_tag", size: 192, elements: !333)
!333 = !{!334, !335, !336, !337}
!334 = !DIDerivedType(tag: DW_TAG_member, name: "gp_offset", scope: !332, file: !330, line: 16, baseType: !6, size: 32)
!335 = !DIDerivedType(tag: DW_TAG_member, name: "fp_offset", scope: !332, file: !330, line: 16, baseType: !6, size: 32, offset: 32)
!336 = !DIDerivedType(tag: DW_TAG_member, name: "overflow_arg_area", scope: !332, file: !330, line: 16, baseType: !304, size: 64, offset: 64)
!337 = !DIDerivedType(tag: DW_TAG_member, name: "reg_save_area", scope: !332, file: !330, line: 16, baseType: !304, size: 64, offset: 128)
!338 = !DILocation(line: 16, column: 13, scope: !252)
!339 = !DILocation(line: 17, column: 5, scope: !252)
!340 = !DILocation(line: 18, column: 27, scope: !252)
!341 = !DILocation(line: 18, column: 59, scope: !252)
!342 = !DILocation(line: 18, column: 17, scope: !252)
!343 = !DILocalVariable(name: "count", scope: !252, file: !29, line: 18, type: !51)
!344 = !DILocation(line: 19, column: 5, scope: !252)
!345 = !DILocation(line: 20, column: 15, scope: !346)
!346 = distinct !DILexicalBlock(scope: !252, file: !29, line: 20, column: 9)
!347 = !DILocation(line: 20, column: 19, scope: !346)
!348 = !DILocation(line: 20, column: 22, scope: !346)
!349 = !DILocation(line: 20, column: 38, scope: !346)
!350 = !DILocation(line: 20, column: 9, scope: !252)
!351 = !DILocation(line: 20, column: 57, scope: !346)
!352 = !DILocalVariable(name: "i", scope: !353, file: !29, line: 21, type: !51)
!353 = distinct !DILexicalBlock(scope: !252, file: !29, line: 21, column: 5)
!354 = !DILocation(line: 0, scope: !353)
!355 = !DILocation(line: 21, column: 10, scope: !353)
!356 = !DILocation(line: 21, column: 23, scope: !357)
!357 = distinct !DILexicalBlock(scope: !353, file: !29, line: 21, column: 5)
!358 = !DILocation(line: 21, column: 5, scope: !353)
!359 = !DILocation(line: 22, column: 35, scope: !360)
!360 = distinct !DILexicalBlock(scope: !357, file: !29, line: 21, column: 37)
!361 = !DILocation(line: 22, column: 20, scope: !360)
!362 = !DILocation(line: 22, column: 17, scope: !360)
!363 = !DILocation(line: 23, column: 17, scope: !360)
!364 = !DILocation(line: 24, column: 5, scope: !360)
!365 = !DILocation(line: 21, column: 32, scope: !357)
!366 = !DILocation(line: 21, column: 5, scope: !357)
!367 = distinct !{!367, !358, !368, !135}
!368 = !DILocation(line: 24, column: 5, scope: !353)
!369 = !DILocation(line: 29, column: 11, scope: !252)
!370 = !DILocation(line: 31, column: 5, scope: !252)
