; ModuleID = 'inlined.ll'
source_filename = "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/triangular-20260929/suite/gesummv/source/workload.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

@n = external dso_local global i32, align 4, !dbg !0
@A = external dso_local global [250 x [250 x double]], section ".chaser_data.A", align 64, !dbg !9
@B = external dso_local global [250 x [250 x double]], section ".chaser_data.B", align 64, !dbg !15
@tmp = external dso_local global [250 x double], section ".chaser_data.tmp", align 64, !dbg !17
@x = external dso_local global [250 x double], section ".chaser_data.x", align 64, !dbg !21
@y = external dso_local global [250 x double], section ".chaser_data.y", align 64, !dbg !23
@alpha = external dso_local global double, align 8, !dbg !25
@beta = external dso_local global double, align 8, !dbg !27
@.str = hidden unnamed_addr constant [12 x i8] c"ape.analyze\00", section "llvm.metadata"
@.str.1 = hidden unnamed_addr constant [122 x i8] c"/workspace/experiments-array-support/chaser/.cache/periodic-polybench/triangular-20260929/suite/gesummv/source/workload.c\00", section "llvm.metadata"
@.str.2 = hidden unnamed_addr constant [23 x i8] c"==BEGIN DUMP_ARRAYS==\0A\00", align 1
@.str.3 = hidden unnamed_addr constant [15 x i8] c"begin dump: %s\00", align 1
@.str.4 = hidden unnamed_addr constant [2 x i8] c"y\00", align 1
@.str.5 = hidden unnamed_addr constant [2 x i8] c"\0A\00", align 1
@.str.6 = hidden unnamed_addr constant [8 x i8] c"%0.2lf \00", align 1
@.str.7 = hidden unnamed_addr constant [17 x i8] c"\0Aend   dump: %s\0A\00", align 1
@.str.8 = hidden unnamed_addr constant [23 x i8] c"==END   DUMP_ARRAYS==\0A\00", align 1
@llvm.global.annotations = appending global [1 x { i8*, i8*, i8*, i32, i8* }] [{ i8*, i8*, i8*, i32, i8* } { i8* bitcast (i32 ()* @task_job_polybench to i8*), i8* getelementptr inbounds ([12 x i8], [12 x i8]* @.str, i32 0, i32 0), i8* getelementptr inbounds ([122 x i8], [122 x i8]* @.str.1, i32 0, i32 0), i32 132, i8* null }], section "llvm.metadata"

; Function Attrs: noinline nounwind uwtable
define dso_local i32 @task_job_polybench() #0 !dbg !38 {
  %1 = load i32, i32* @n, align 4, !dbg !46
  %2 = load double, double* @alpha, align 8, !dbg !47
  %3 = load double, double* @beta, align 8, !dbg !48
  call void @llvm.dbg.value(metadata i32 %1, metadata !49, metadata !DIExpression()), !dbg !55
  call void @llvm.dbg.value(metadata double %2, metadata !57, metadata !DIExpression()), !dbg !55
  call void @llvm.dbg.value(metadata double %3, metadata !58, metadata !DIExpression()), !dbg !55
  call void @llvm.dbg.value(metadata [250 x double]* getelementptr inbounds ([250 x [250 x double]], [250 x [250 x double]]* @A, i64 0, i64 0), metadata !59, metadata !DIExpression()), !dbg !55
  call void @llvm.dbg.value(metadata [250 x double]* getelementptr inbounds ([250 x [250 x double]], [250 x [250 x double]]* @B, i64 0, i64 0), metadata !60, metadata !DIExpression()), !dbg !55
  call void @llvm.dbg.value(metadata double* getelementptr inbounds ([250 x double], [250 x double]* @tmp, i64 0, i64 0), metadata !61, metadata !DIExpression()), !dbg !55
  call void @llvm.dbg.value(metadata double* getelementptr inbounds ([250 x double], [250 x double]* @x, i64 0, i64 0), metadata !62, metadata !DIExpression()), !dbg !55
  call void @llvm.dbg.value(metadata double* getelementptr inbounds ([250 x double], [250 x double]* @y, i64 0, i64 0), metadata !63, metadata !DIExpression()), !dbg !55
  call void @llvm.dbg.value(metadata i32 0, metadata !64, metadata !DIExpression()), !dbg !55
  br label %4, !dbg !65

4:                                                ; preds = %45, %0
  %.01 = phi i32 [ 0, %0 ], [ %57, %45 ], !dbg !67
  call void @llvm.dbg.value(metadata i32 %.01, metadata !64, metadata !DIExpression()), !dbg !55
  %5 = icmp slt i32 %.01, 250, !dbg !68
  br i1 %5, label %6, label %58, !dbg !70

6:                                                ; preds = %4
  %7 = sext i32 %.01 to i64, !dbg !71
  %8 = getelementptr inbounds double, double* getelementptr inbounds ([250 x double], [250 x double]* @tmp, i64 0, i64 0), i64 %7, !dbg !71
  store double 0.000000e+00, double* %8, align 8, !dbg !73
  %9 = sext i32 %.01 to i64, !dbg !74
  %10 = getelementptr inbounds double, double* getelementptr inbounds ([250 x double], [250 x double]* @y, i64 0, i64 0), i64 %9, !dbg !74
  store double 0.000000e+00, double* %10, align 8, !dbg !75
  call void @llvm.dbg.value(metadata i32 0, metadata !76, metadata !DIExpression()), !dbg !55
  br label %11, !dbg !77

11:                                               ; preds = %13, %6
  %.0 = phi i32 [ 0, %6 ], [ %44, %13 ], !dbg !79
  call void @llvm.dbg.value(metadata i32 %.0, metadata !76, metadata !DIExpression()), !dbg !55
  %12 = icmp slt i32 %.0, 250, !dbg !80
  br i1 %12, label %13, label %45, !dbg !82

13:                                               ; preds = %11
  %14 = sext i32 %.01 to i64, !dbg !83
  %15 = getelementptr inbounds [250 x double], [250 x double]* getelementptr inbounds ([250 x [250 x double]], [250 x [250 x double]]* @A, i64 0, i64 0), i64 %14, !dbg !83
  %16 = sext i32 %.0 to i64, !dbg !83
  %17 = getelementptr inbounds [250 x double], [250 x double]* %15, i64 0, i64 %16, !dbg !83
  %18 = load double, double* %17, align 8, !dbg !83
  %19 = sext i32 %.0 to i64, !dbg !85
  %20 = getelementptr inbounds double, double* getelementptr inbounds ([250 x double], [250 x double]* @x, i64 0, i64 0), i64 %19, !dbg !85
  %21 = load double, double* %20, align 8, !dbg !85
  %22 = fmul double %18, %21, !dbg !86
  %23 = sext i32 %.01 to i64, !dbg !87
  %24 = getelementptr inbounds double, double* getelementptr inbounds ([250 x double], [250 x double]* @tmp, i64 0, i64 0), i64 %23, !dbg !87
  %25 = load double, double* %24, align 8, !dbg !87
  %26 = fadd double %22, %25, !dbg !88
  %27 = sext i32 %.01 to i64, !dbg !89
  %28 = getelementptr inbounds double, double* getelementptr inbounds ([250 x double], [250 x double]* @tmp, i64 0, i64 0), i64 %27, !dbg !89
  store double %26, double* %28, align 8, !dbg !90
  %29 = sext i32 %.01 to i64, !dbg !91
  %30 = getelementptr inbounds [250 x double], [250 x double]* getelementptr inbounds ([250 x [250 x double]], [250 x [250 x double]]* @B, i64 0, i64 0), i64 %29, !dbg !91
  %31 = sext i32 %.0 to i64, !dbg !91
  %32 = getelementptr inbounds [250 x double], [250 x double]* %30, i64 0, i64 %31, !dbg !91
  %33 = load double, double* %32, align 8, !dbg !91
  %34 = sext i32 %.0 to i64, !dbg !92
  %35 = getelementptr inbounds double, double* getelementptr inbounds ([250 x double], [250 x double]* @x, i64 0, i64 0), i64 %34, !dbg !92
  %36 = load double, double* %35, align 8, !dbg !92
  %37 = fmul double %33, %36, !dbg !93
  %38 = sext i32 %.01 to i64, !dbg !94
  %39 = getelementptr inbounds double, double* getelementptr inbounds ([250 x double], [250 x double]* @y, i64 0, i64 0), i64 %38, !dbg !94
  %40 = load double, double* %39, align 8, !dbg !94
  %41 = fadd double %37, %40, !dbg !95
  %42 = sext i32 %.01 to i64, !dbg !96
  %43 = getelementptr inbounds double, double* getelementptr inbounds ([250 x double], [250 x double]* @y, i64 0, i64 0), i64 %42, !dbg !96
  store double %41, double* %43, align 8, !dbg !97
  %44 = add nsw i32 %.0, 1, !dbg !98
  call void @llvm.dbg.value(metadata i32 %44, metadata !76, metadata !DIExpression()), !dbg !55
  br label %11, !dbg !99, !llvm.loop !100

45:                                               ; preds = %11
  %46 = sext i32 %.01 to i64, !dbg !103
  %47 = getelementptr inbounds double, double* getelementptr inbounds ([250 x double], [250 x double]* @tmp, i64 0, i64 0), i64 %46, !dbg !103
  %48 = load double, double* %47, align 8, !dbg !103
  %49 = fmul double %2, %48, !dbg !104
  %50 = sext i32 %.01 to i64, !dbg !105
  %51 = getelementptr inbounds double, double* getelementptr inbounds ([250 x double], [250 x double]* @y, i64 0, i64 0), i64 %50, !dbg !105
  %52 = load double, double* %51, align 8, !dbg !105
  %53 = fmul double %3, %52, !dbg !106
  %54 = fadd double %49, %53, !dbg !107
  %55 = sext i32 %.01 to i64, !dbg !108
  %56 = getelementptr inbounds double, double* getelementptr inbounds ([250 x double], [250 x double]* @y, i64 0, i64 0), i64 %55, !dbg !108
  store double %54, double* %56, align 8, !dbg !109
  %57 = add nsw i32 %.01, 1, !dbg !110
  call void @llvm.dbg.value(metadata i32 %57, metadata !64, metadata !DIExpression()), !dbg !55
  br label %4, !dbg !111, !llvm.loop !112

58:                                               ; preds = %4
  ret i32 0, !dbg !114
}

; Function Attrs: nofree nosync nounwind readnone speculatable willreturn
declare void @llvm.dbg.value(metadata, metadata, metadata) #1

attributes #0 = { noinline nounwind uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { nofree nosync nounwind readnone speculatable willreturn }

!llvm.dbg.cu = !{!2}
!llvm.module.flags = !{!30, !31, !32, !33, !34, !35, !36}
!llvm.ident = !{!37}

!0 = !DIGlobalVariableExpression(var: !1, expr: !DIExpression())
!1 = distinct !DIGlobalVariable(name: "n", scope: !2, file: !11, line: 114, type: !29, isLocal: false, isDefinition: true)
!2 = distinct !DICompileUnit(language: DW_LANG_C99, file: !3, producer: "Ubuntu clang version 14.0.0-1ubuntu1.1", isOptimized: false, runtimeVersion: 0, emissionKind: FullDebug, retainedTypes: !4, globals: !8, splitDebugInlining: false, nameTableKind: None)
!3 = !DIFile(filename: "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/triangular-20260929/suite/gesummv/source/workload.c", directory: "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/triangular-20260929/suite/gesummv/analysis-native", checksumkind: CSK_MD5, checksum: "17ed6c5da7bdfa8dc19e6a06ceadf214")
!4 = !{!5, !6, !7}
!5 = !DIBasicType(name: "double", size: 64, encoding: DW_ATE_float)
!6 = !DIBasicType(name: "unsigned int", size: 32, encoding: DW_ATE_unsigned)
!7 = !DIBasicType(name: "unsigned char", size: 8, encoding: DW_ATE_unsigned_char)
!8 = !{!0, !9, !15, !17, !21, !23, !25, !27}
!9 = !DIGlobalVariableExpression(var: !10, expr: !DIExpression())
!10 = distinct !DIGlobalVariable(name: "A", scope: !2, file: !11, line: 34, type: !12, isLocal: false, isDefinition: true, align: 512)
!11 = !DIFile(filename: "source/workload.c", directory: "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/triangular-20260929/suite/gesummv", checksumkind: CSK_MD5, checksum: "17ed6c5da7bdfa8dc19e6a06ceadf214")
!12 = !DICompositeType(tag: DW_TAG_array_type, baseType: !5, size: 4000000, elements: !13)
!13 = !{!14, !14}
!14 = !DISubrange(count: 250)
!15 = !DIGlobalVariableExpression(var: !16, expr: !DIExpression())
!16 = distinct !DIGlobalVariable(name: "B", scope: !2, file: !11, line: 35, type: !12, isLocal: false, isDefinition: true, align: 512)
!17 = !DIGlobalVariableExpression(var: !18, expr: !DIExpression())
!18 = distinct !DIGlobalVariable(name: "tmp", scope: !2, file: !11, line: 36, type: !19, isLocal: false, isDefinition: true, align: 512)
!19 = !DICompositeType(tag: DW_TAG_array_type, baseType: !5, size: 16000, elements: !20)
!20 = !{!14}
!21 = !DIGlobalVariableExpression(var: !22, expr: !DIExpression())
!22 = distinct !DIGlobalVariable(name: "x", scope: !2, file: !11, line: 37, type: !19, isLocal: false, isDefinition: true, align: 512)
!23 = !DIGlobalVariableExpression(var: !24, expr: !DIExpression())
!24 = distinct !DIGlobalVariable(name: "y", scope: !2, file: !11, line: 38, type: !19, isLocal: false, isDefinition: true, align: 512)
!25 = !DIGlobalVariableExpression(var: !26, expr: !DIExpression())
!26 = distinct !DIGlobalVariable(name: "alpha", scope: !2, file: !11, line: 117, type: !5, isLocal: false, isDefinition: true)
!27 = !DIGlobalVariableExpression(var: !28, expr: !DIExpression())
!28 = distinct !DIGlobalVariable(name: "beta", scope: !2, file: !11, line: 118, type: !5, isLocal: false, isDefinition: true)
!29 = !DIBasicType(name: "int", size: 32, encoding: DW_ATE_signed)
!30 = !{i32 7, !"Dwarf Version", i32 5}
!31 = !{i32 2, !"Debug Info Version", i32 3}
!32 = !{i32 1, !"wchar_size", i32 4}
!33 = !{i32 7, !"PIC Level", i32 2}
!34 = !{i32 7, !"PIE Level", i32 2}
!35 = !{i32 7, !"uwtable", i32 1}
!36 = !{i32 7, !"frame-pointer", i32 2}
!37 = !{!"Ubuntu clang version 14.0.0-1ubuntu1.1"}
!38 = distinct !DISubprogram(name: "task_job_polybench", scope: !11, file: !11, line: 132, type: !39, scopeLine: 132, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !2, retainedNodes: !45)
!39 = !DISubroutineType(types: !40)
!40 = !{!41}
!41 = !DIDerivedType(tag: DW_TAG_typedef, name: "uint32_t", file: !42, line: 26, baseType: !43)
!42 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/stdint-uintn.h", directory: "", checksumkind: CSK_MD5, checksum: "2bf2ae53c58c01b1a1b9383b5195125c")
!43 = !DIDerivedType(tag: DW_TAG_typedef, name: "__uint32_t", file: !44, line: 42, baseType: !6)
!44 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/types.h", directory: "", checksumkind: CSK_MD5, checksum: "d108b5f93a74c50510d7d9bc0ab36df9")
!45 = !{}
!46 = !DILocation(line: 133, column: 19, scope: !38)
!47 = !DILocation(line: 133, column: 22, scope: !38)
!48 = !DILocation(line: 133, column: 29, scope: !38)
!49 = !DILocalVariable(name: "n", arg: 1, scope: !50, file: !11, line: 85, type: !29)
!50 = distinct !DISubprogram(name: "kernel_gesummv", scope: !11, file: !11, line: 85, type: !51, scopeLine: 93, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition, unit: !2, retainedNodes: !45)
!51 = !DISubroutineType(types: !52)
!52 = !{null, !29, !5, !5, !53, !53, !54, !54, !54}
!53 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !19, size: 64)
!54 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !5, size: 64)
!55 = !DILocation(line: 0, scope: !50, inlinedAt: !56)
!56 = distinct !DILocation(line: 133, column: 3, scope: !38)
!57 = !DILocalVariable(name: "alpha", arg: 2, scope: !50, file: !11, line: 86, type: !5)
!58 = !DILocalVariable(name: "beta", arg: 3, scope: !50, file: !11, line: 87, type: !5)
!59 = !DILocalVariable(name: "A", arg: 4, scope: !50, file: !11, line: 88, type: !53)
!60 = !DILocalVariable(name: "B", arg: 5, scope: !50, file: !11, line: 89, type: !53)
!61 = !DILocalVariable(name: "tmp", arg: 6, scope: !50, file: !11, line: 90, type: !54)
!62 = !DILocalVariable(name: "x", arg: 7, scope: !50, file: !11, line: 91, type: !54)
!63 = !DILocalVariable(name: "y", arg: 8, scope: !50, file: !11, line: 92, type: !54)
!64 = !DILocalVariable(name: "i", scope: !50, file: !11, line: 94, type: !29)
!65 = !DILocation(line: 97, column: 8, scope: !66, inlinedAt: !56)
!66 = distinct !DILexicalBlock(scope: !50, file: !11, line: 97, column: 3)
!67 = !DILocation(line: 0, scope: !66, inlinedAt: !56)
!68 = !DILocation(line: 97, column: 17, scope: !69, inlinedAt: !56)
!69 = distinct !DILexicalBlock(scope: !66, file: !11, line: 97, column: 3)
!70 = !DILocation(line: 97, column: 3, scope: !66, inlinedAt: !56)
!71 = !DILocation(line: 99, column: 7, scope: !72, inlinedAt: !56)
!72 = distinct !DILexicalBlock(scope: !69, file: !11, line: 98, column: 5)
!73 = !DILocation(line: 99, column: 14, scope: !72, inlinedAt: !56)
!74 = !DILocation(line: 100, column: 7, scope: !72, inlinedAt: !56)
!75 = !DILocation(line: 100, column: 12, scope: !72, inlinedAt: !56)
!76 = !DILocalVariable(name: "j", scope: !50, file: !11, line: 94, type: !29)
!77 = !DILocation(line: 101, column: 12, scope: !78, inlinedAt: !56)
!78 = distinct !DILexicalBlock(scope: !72, file: !11, line: 101, column: 7)
!79 = !DILocation(line: 0, scope: !78, inlinedAt: !56)
!80 = !DILocation(line: 101, column: 21, scope: !81, inlinedAt: !56)
!81 = distinct !DILexicalBlock(scope: !78, file: !11, line: 101, column: 7)
!82 = !DILocation(line: 101, column: 7, scope: !78, inlinedAt: !56)
!83 = !DILocation(line: 103, column: 13, scope: !84, inlinedAt: !56)
!84 = distinct !DILexicalBlock(scope: !81, file: !11, line: 102, column: 2)
!85 = !DILocation(line: 103, column: 23, scope: !84, inlinedAt: !56)
!86 = !DILocation(line: 103, column: 21, scope: !84, inlinedAt: !56)
!87 = !DILocation(line: 103, column: 30, scope: !84, inlinedAt: !56)
!88 = !DILocation(line: 103, column: 28, scope: !84, inlinedAt: !56)
!89 = !DILocation(line: 103, column: 4, scope: !84, inlinedAt: !56)
!90 = !DILocation(line: 103, column: 11, scope: !84, inlinedAt: !56)
!91 = !DILocation(line: 104, column: 11, scope: !84, inlinedAt: !56)
!92 = !DILocation(line: 104, column: 21, scope: !84, inlinedAt: !56)
!93 = !DILocation(line: 104, column: 19, scope: !84, inlinedAt: !56)
!94 = !DILocation(line: 104, column: 28, scope: !84, inlinedAt: !56)
!95 = !DILocation(line: 104, column: 26, scope: !84, inlinedAt: !56)
!96 = !DILocation(line: 104, column: 4, scope: !84, inlinedAt: !56)
!97 = !DILocation(line: 104, column: 9, scope: !84, inlinedAt: !56)
!98 = !DILocation(line: 101, column: 31, scope: !81, inlinedAt: !56)
!99 = !DILocation(line: 101, column: 7, scope: !81, inlinedAt: !56)
!100 = distinct !{!100, !82, !101, !102}
!101 = !DILocation(line: 105, column: 2, scope: !78, inlinedAt: !56)
!102 = !{!"llvm.loop.mustprogress"}
!103 = !DILocation(line: 106, column: 22, scope: !72, inlinedAt: !56)
!104 = !DILocation(line: 106, column: 20, scope: !72, inlinedAt: !56)
!105 = !DILocation(line: 106, column: 38, scope: !72, inlinedAt: !56)
!106 = !DILocation(line: 106, column: 36, scope: !72, inlinedAt: !56)
!107 = !DILocation(line: 106, column: 29, scope: !72, inlinedAt: !56)
!108 = !DILocation(line: 106, column: 7, scope: !72, inlinedAt: !56)
!109 = !DILocation(line: 106, column: 12, scope: !72, inlinedAt: !56)
!110 = !DILocation(line: 97, column: 27, scope: !69, inlinedAt: !56)
!111 = !DILocation(line: 97, column: 3, scope: !69, inlinedAt: !56)
!112 = distinct !{!112, !70, !113, !102}
!113 = !DILocation(line: 107, column: 5, scope: !66, inlinedAt: !56)
!114 = !DILocation(line: 139, column: 3, scope: !38)
