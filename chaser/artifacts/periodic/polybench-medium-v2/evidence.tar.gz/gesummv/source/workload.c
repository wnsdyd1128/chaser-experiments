#define CHASER_EXPECTED 2353779555u
/* Generated driver; original functions follow unchanged except storage. */
#define MEDIUM_DATASET
#define POLYBENCH_USE_SCALAR_LB
#define POLYBENCH_STACK_ARRAYS
#define POLYBENCH_DUMP_ARRAYS
#include "adapter.h"
/**
 * This version is stamped on May 10, 2016
 *
 * Contact:
 *   Louis-Noel Pouchet <pouchet.ohio-state.edu>
 *   Tomofumi Yuki <tomofumi.yuki.fr>
 *
 * Web address: http://polybench.sourceforge.net
 */
/* gesummv.c: this file is part of PolyBench/C */

#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <math.h>

/* Include polybench common header. */
#include <polybench.h>

/* Include benchmark-specific header. */
#include "gesummv.h"


/* Array initialization. */

#define y1 pb_y1
DATA_TYPE A[N][N] PB_STORAGE(A);
DATA_TYPE B[N][N] PB_STORAGE(B);
DATA_TYPE tmp[N] PB_STORAGE(tmp);
DATA_TYPE x[N] PB_STORAGE(x);
DATA_TYPE y[N] PB_STORAGE(y);
static
void init_array(int n,
		DATA_TYPE *alpha,
		DATA_TYPE *beta,
		DATA_TYPE POLYBENCH_2D(A,N,N,n,n),
		DATA_TYPE POLYBENCH_2D(B,N,N,n,n),
		DATA_TYPE POLYBENCH_1D(x,N,n))
{
  int i, j;

  *alpha = 1.5;
  *beta = 1.2;
  for (i = 0; i < n; i++)
    {
      x[i] = (DATA_TYPE)( i % n) / n;
      for (j = 0; j < n; j++) {
	A[i][j] = (DATA_TYPE) ((i*j+1) % n) / n;
	B[i][j] = (DATA_TYPE) ((i*j+2) % n) / n;
      }
    }
}


/* DCE code. Must scan the entire live-out data.
   Can be used also to check the correctness of the output. */
static
void print_array(int n,
		 DATA_TYPE POLYBENCH_1D(y,N,n))

{
  int i;

  POLYBENCH_DUMP_START;
  POLYBENCH_DUMP_BEGIN("y");
  for (i = 0; i < n; i++) {
    if (i % 20 == 0) fprintf (POLYBENCH_DUMP_TARGET, "\n");
    fprintf (POLYBENCH_DUMP_TARGET, DATA_PRINTF_MODIFIER, y[i]);
  }
  POLYBENCH_DUMP_END("y");
  POLYBENCH_DUMP_FINISH;
}


/* Main computational kernel. The whole function will be timed,
   including the call and return. */
static
__attribute__((always_inline)) inline void kernel_gesummv(int n,
		    DATA_TYPE alpha,
		    DATA_TYPE beta,
		    DATA_TYPE POLYBENCH_2D(A,N,N,n,n),
		    DATA_TYPE POLYBENCH_2D(B,N,N,n,n),
		    DATA_TYPE POLYBENCH_1D(tmp,N,n),
		    DATA_TYPE POLYBENCH_1D(x,N,n),
		    DATA_TYPE POLYBENCH_1D(y,N,n))
{
  int i, j;

#pragma scop
  for (i = 0; i < _PB_N; i++)
    {
      tmp[i] = SCALAR_VAL(0.0);
      y[i] = SCALAR_VAL(0.0);
      for (j = 0; j < _PB_N; j++)
	{
	  tmp[i] = A[i][j] * x[j] + tmp[i];
	  y[i] = B[i][j] * x[j] + y[i];
	}
      y[i] = alpha * tmp[i] + beta * y[i];
    }
#pragma endscop

}



int n = N;

  
  DATA_TYPE alpha;
  DATA_TYPE beta;
void workload_prepare(void) {}
void workload_reset(unsigned task) {
  (void)task;
  memset(A, 0, sizeof(A));
  memset(B, 0, sizeof(B));
  memset(tmp, 0, sizeof(tmp));
  memset(x, 0, sizeof(x));
  memset(y, 0, sizeof(y));
  init_array (n, &alpha, &beta,
	      POLYBENCH_ARRAY(A),
	      POLYBENCH_ARRAY(B),
	      POLYBENCH_ARRAY(x));
}
PB_ANALYZE uint32_t task_job_polybench(void) {
  kernel_gesummv (n, alpha, beta,
		  POLYBENCH_ARRAY(A),
		  POLYBENCH_ARRAY(B),
		  POLYBENCH_ARRAY(tmp),
		  POLYBENCH_ARRAY(x),
		  POLYBENCH_ARRAY(y));
  return 0;
}
uint32_t workload_checksum(unsigned task) {
  (void)task;
  pb_hash = 2166136261u;
  print_array(n, POLYBENCH_ARRAY(y));
  return pb_hash;
}
uint32_t (*const workload_jobs[])(void) = {task_job_polybench};
#ifndef CHASER_EXPECTED
#define CHASER_EXPECTED 0u
#endif
const uint32_t workload_expected[] = {CHASER_EXPECTED};
#ifdef CHASER_NATIVE
int main(void) { workload_reset(0); task_job_polybench();
  uint32_t first = workload_checksum(0); pb_emit = 0;
  workload_reset(0); task_job_polybench();
  if (first != workload_checksum(0)) return 1;
  printf("%u\n", first); return 0; }
#endif
