; ModuleID = 'inlined.ll'
source_filename = "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/triangular-20260929/suite/bicg/source/workload.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

@n = external dso_local global i32, align 4, !dbg !0
@m = external dso_local global i32, align 4, !dbg !9
@A = external dso_local global [410 x [390 x double]], section ".chaser_data.A", align 64, !dbg !13
@s = external dso_local global [390 x double], section ".chaser_data.s", align 64, !dbg !19
@q = external dso_local global [410 x double], section ".chaser_data.q", align 64, !dbg !23
@p = external dso_local global [390 x double], section ".chaser_data.p", align 64, !dbg !27
@r = external dso_local global [410 x double], section ".chaser_data.r", align 64, !dbg !29
@.str = hidden unnamed_addr constant [12 x i8] c"ape.analyze\00", section "llvm.metadata"
@.str.1 = hidden unnamed_addr constant [119 x i8] c"/workspace/experiments-array-support/chaser/.cache/periodic-polybench/triangular-20260929/suite/bicg/source/workload.c\00", section "llvm.metadata"
@.str.2 = hidden unnamed_addr constant [23 x i8] c"==BEGIN DUMP_ARRAYS==\0A\00", align 1
@.str.3 = hidden unnamed_addr constant [15 x i8] c"begin dump: %s\00", align 1
@.str.4 = hidden unnamed_addr constant [2 x i8] c"s\00", align 1
@.str.5 = hidden unnamed_addr constant [2 x i8] c"\0A\00", align 1
@.str.6 = hidden unnamed_addr constant [8 x i8] c"%0.2lf \00", align 1
@.str.7 = hidden unnamed_addr constant [17 x i8] c"\0Aend   dump: %s\0A\00", align 1
@.str.8 = hidden unnamed_addr constant [2 x i8] c"q\00", align 1
@.str.9 = hidden unnamed_addr constant [23 x i8] c"==END   DUMP_ARRAYS==\0A\00", align 1
@llvm.global.annotations = appending global [1 x { i8*, i8*, i8*, i32, i8* }] [{ i8*, i8*, i8*, i32, i8* } { i8* bitcast (i32 ()* @task_job_polybench to i8*), i8* getelementptr inbounds ([12 x i8], [12 x i8]* @.str, i32 0, i32 0), i8* getelementptr inbounds ([119 x i8], [119 x i8]* @.str.1, i32 0, i32 0), i32 129, i8* null }], section "llvm.metadata"

; Function Attrs: noinline nounwind uwtable
define dso_local i32 @task_job_polybench() #0 !dbg !39 {
  %1 = load i32, i32* @m, align 4, !dbg !47
  %2 = load i32, i32* @n, align 4, !dbg !48
  call void @llvm.dbg.value(metadata i32 %1, metadata !49, metadata !DIExpression()), !dbg !55
  call void @llvm.dbg.value(metadata i32 %2, metadata !57, metadata !DIExpression()), !dbg !55
  call void @llvm.dbg.value(metadata [390 x double]* getelementptr inbounds ([410 x [390 x double]], [410 x [390 x double]]* @A, i64 0, i64 0), metadata !58, metadata !DIExpression()), !dbg !55
  call void @llvm.dbg.value(metadata double* getelementptr inbounds ([390 x double], [390 x double]* @s, i64 0, i64 0), metadata !59, metadata !DIExpression()), !dbg !55
  call void @llvm.dbg.value(metadata double* getelementptr inbounds ([410 x double], [410 x double]* @q, i64 0, i64 0), metadata !60, metadata !DIExpression()), !dbg !55
  call void @llvm.dbg.value(metadata double* getelementptr inbounds ([390 x double], [390 x double]* @p, i64 0, i64 0), metadata !61, metadata !DIExpression()), !dbg !55
  call void @llvm.dbg.value(metadata double* getelementptr inbounds ([410 x double], [410 x double]* @r, i64 0, i64 0), metadata !62, metadata !DIExpression()), !dbg !55
  call void @llvm.dbg.value(metadata i32 0, metadata !63, metadata !DIExpression()), !dbg !55
  br label %3, !dbg !64

3:                                                ; preds = %5, %0
  %.01 = phi i32 [ 0, %0 ], [ %8, %5 ], !dbg !66
  call void @llvm.dbg.value(metadata i32 %.01, metadata !63, metadata !DIExpression()), !dbg !55
  %4 = icmp slt i32 %.01, 390, !dbg !67
  br i1 %4, label %5, label %9, !dbg !69

5:                                                ; preds = %3
  %6 = sext i32 %.01 to i64, !dbg !70
  %7 = getelementptr inbounds double, double* getelementptr inbounds ([390 x double], [390 x double]* @s, i64 0, i64 0), i64 %6, !dbg !70
  store double 0.000000e+00, double* %7, align 8, !dbg !71
  %8 = add nsw i32 %.01, 1, !dbg !72
  call void @llvm.dbg.value(metadata i32 %8, metadata !63, metadata !DIExpression()), !dbg !55
  br label %3, !dbg !73, !llvm.loop !74

9:                                                ; preds = %3
  call void @llvm.dbg.value(metadata i32 0, metadata !63, metadata !DIExpression()), !dbg !55
  br label %10, !dbg !77

10:                                               ; preds = %49, %9
  %.1 = phi i32 [ 0, %9 ], [ %50, %49 ], !dbg !79
  call void @llvm.dbg.value(metadata i32 %.1, metadata !63, metadata !DIExpression()), !dbg !55
  %11 = icmp slt i32 %.1, 410, !dbg !80
  br i1 %11, label %12, label %51, !dbg !82

12:                                               ; preds = %10
  %13 = sext i32 %.1 to i64, !dbg !83
  %14 = getelementptr inbounds double, double* getelementptr inbounds ([410 x double], [410 x double]* @q, i64 0, i64 0), i64 %13, !dbg !83
  store double 0.000000e+00, double* %14, align 8, !dbg !85
  call void @llvm.dbg.value(metadata i32 0, metadata !86, metadata !DIExpression()), !dbg !55
  br label %15, !dbg !87

15:                                               ; preds = %17, %12
  %.0 = phi i32 [ 0, %12 ], [ %48, %17 ], !dbg !89
  call void @llvm.dbg.value(metadata i32 %.0, metadata !86, metadata !DIExpression()), !dbg !55
  %16 = icmp slt i32 %.0, 390, !dbg !90
  br i1 %16, label %17, label %49, !dbg !92

17:                                               ; preds = %15
  %18 = sext i32 %.0 to i64, !dbg !93
  %19 = getelementptr inbounds double, double* getelementptr inbounds ([390 x double], [390 x double]* @s, i64 0, i64 0), i64 %18, !dbg !93
  %20 = load double, double* %19, align 8, !dbg !93
  %21 = sext i32 %.1 to i64, !dbg !95
  %22 = getelementptr inbounds double, double* getelementptr inbounds ([410 x double], [410 x double]* @r, i64 0, i64 0), i64 %21, !dbg !95
  %23 = load double, double* %22, align 8, !dbg !95
  %24 = sext i32 %.1 to i64, !dbg !96
  %25 = getelementptr inbounds [390 x double], [390 x double]* getelementptr inbounds ([410 x [390 x double]], [410 x [390 x double]]* @A, i64 0, i64 0), i64 %24, !dbg !96
  %26 = sext i32 %.0 to i64, !dbg !96
  %27 = getelementptr inbounds [390 x double], [390 x double]* %25, i64 0, i64 %26, !dbg !96
  %28 = load double, double* %27, align 8, !dbg !96
  %29 = fmul double %23, %28, !dbg !97
  %30 = fadd double %20, %29, !dbg !98
  %31 = sext i32 %.0 to i64, !dbg !99
  %32 = getelementptr inbounds double, double* getelementptr inbounds ([390 x double], [390 x double]* @s, i64 0, i64 0), i64 %31, !dbg !99
  store double %30, double* %32, align 8, !dbg !100
  %33 = sext i32 %.1 to i64, !dbg !101
  %34 = getelementptr inbounds double, double* getelementptr inbounds ([410 x double], [410 x double]* @q, i64 0, i64 0), i64 %33, !dbg !101
  %35 = load double, double* %34, align 8, !dbg !101
  %36 = sext i32 %.1 to i64, !dbg !102
  %37 = getelementptr inbounds [390 x double], [390 x double]* getelementptr inbounds ([410 x [390 x double]], [410 x [390 x double]]* @A, i64 0, i64 0), i64 %36, !dbg !102
  %38 = sext i32 %.0 to i64, !dbg !102
  %39 = getelementptr inbounds [390 x double], [390 x double]* %37, i64 0, i64 %38, !dbg !102
  %40 = load double, double* %39, align 8, !dbg !102
  %41 = sext i32 %.0 to i64, !dbg !103
  %42 = getelementptr inbounds double, double* getelementptr inbounds ([390 x double], [390 x double]* @p, i64 0, i64 0), i64 %41, !dbg !103
  %43 = load double, double* %42, align 8, !dbg !103
  %44 = fmul double %40, %43, !dbg !104
  %45 = fadd double %35, %44, !dbg !105
  %46 = sext i32 %.1 to i64, !dbg !106
  %47 = getelementptr inbounds double, double* getelementptr inbounds ([410 x double], [410 x double]* @q, i64 0, i64 0), i64 %46, !dbg !106
  store double %45, double* %47, align 8, !dbg !107
  %48 = add nsw i32 %.0, 1, !dbg !108
  call void @llvm.dbg.value(metadata i32 %48, metadata !86, metadata !DIExpression()), !dbg !55
  br label %15, !dbg !109, !llvm.loop !110

49:                                               ; preds = %15
  %50 = add nsw i32 %.1, 1, !dbg !112
  call void @llvm.dbg.value(metadata i32 %50, metadata !63, metadata !DIExpression()), !dbg !55
  br label %10, !dbg !113, !llvm.loop !114

51:                                               ; preds = %10
  ret i32 0, !dbg !116
}

; Function Attrs: nofree nosync nounwind readnone speculatable willreturn
declare void @llvm.dbg.value(metadata, metadata, metadata) #1

attributes #0 = { noinline nounwind uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { nofree nosync nounwind readnone speculatable willreturn }

!llvm.dbg.cu = !{!2}
!llvm.module.flags = !{!31, !32, !33, !34, !35, !36, !37}
!llvm.ident = !{!38}

!0 = !DIGlobalVariableExpression(var: !1, expr: !DIExpression())
!1 = distinct !DIGlobalVariable(name: "n", scope: !2, file: !11, line: 114, type: !12, isLocal: false, isDefinition: true)
!2 = distinct !DICompileUnit(language: DW_LANG_C99, file: !3, producer: "Ubuntu clang version 14.0.0-1ubuntu1.1", isOptimized: false, runtimeVersion: 0, emissionKind: FullDebug, retainedTypes: !4, globals: !8, splitDebugInlining: false, nameTableKind: None)
!3 = !DIFile(filename: "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/triangular-20260929/suite/bicg/source/workload.c", directory: "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/triangular-20260929/suite/bicg/analysis-p", checksumkind: CSK_MD5, checksum: "e8f798e8b436f689a83dca6308f17ffb")
!4 = !{!5, !6, !7}
!5 = !DIBasicType(name: "double", size: 64, encoding: DW_ATE_float)
!6 = !DIBasicType(name: "unsigned int", size: 32, encoding: DW_ATE_unsigned)
!7 = !DIBasicType(name: "unsigned char", size: 8, encoding: DW_ATE_unsigned_char)
!8 = !{!0, !9, !13, !19, !23, !27, !29}
!9 = !DIGlobalVariableExpression(var: !10, expr: !DIExpression())
!10 = distinct !DIGlobalVariable(name: "m", scope: !2, file: !11, line: 115, type: !12, isLocal: false, isDefinition: true)
!11 = !DIFile(filename: "source/workload.c", directory: "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/triangular-20260929/suite/bicg", checksumkind: CSK_MD5, checksum: "e8f798e8b436f689a83dca6308f17ffb")
!12 = !DIBasicType(name: "int", size: 32, encoding: DW_ATE_signed)
!13 = !DIGlobalVariableExpression(var: !14, expr: !DIExpression())
!14 = distinct !DIGlobalVariable(name: "A", scope: !2, file: !11, line: 34, type: !15, isLocal: false, isDefinition: true, align: 512)
!15 = !DICompositeType(tag: DW_TAG_array_type, baseType: !5, size: 10233600, elements: !16)
!16 = !{!17, !18}
!17 = !DISubrange(count: 410)
!18 = !DISubrange(count: 390)
!19 = !DIGlobalVariableExpression(var: !20, expr: !DIExpression())
!20 = distinct !DIGlobalVariable(name: "s", scope: !2, file: !11, line: 35, type: !21, isLocal: false, isDefinition: true, align: 512)
!21 = !DICompositeType(tag: DW_TAG_array_type, baseType: !5, size: 24960, elements: !22)
!22 = !{!18}
!23 = !DIGlobalVariableExpression(var: !24, expr: !DIExpression())
!24 = distinct !DIGlobalVariable(name: "q", scope: !2, file: !11, line: 36, type: !25, isLocal: false, isDefinition: true, align: 512)
!25 = !DICompositeType(tag: DW_TAG_array_type, baseType: !5, size: 26240, elements: !26)
!26 = !{!17}
!27 = !DIGlobalVariableExpression(var: !28, expr: !DIExpression())
!28 = distinct !DIGlobalVariable(name: "p", scope: !2, file: !11, line: 37, type: !21, isLocal: false, isDefinition: true, align: 512)
!29 = !DIGlobalVariableExpression(var: !30, expr: !DIExpression())
!30 = distinct !DIGlobalVariable(name: "r", scope: !2, file: !11, line: 38, type: !25, isLocal: false, isDefinition: true, align: 512)
!31 = !{i32 7, !"Dwarf Version", i32 5}
!32 = !{i32 2, !"Debug Info Version", i32 3}
!33 = !{i32 1, !"wchar_size", i32 4}
!34 = !{i32 7, !"PIC Level", i32 2}
!35 = !{i32 7, !"PIE Level", i32 2}
!36 = !{i32 7, !"uwtable", i32 1}
!37 = !{i32 7, !"frame-pointer", i32 2}
!38 = !{!"Ubuntu clang version 14.0.0-1ubuntu1.1"}
!39 = distinct !DISubprogram(name: "task_job_polybench", scope: !11, file: !11, line: 129, type: !40, scopeLine: 129, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !2, retainedNodes: !46)
!40 = !DISubroutineType(types: !41)
!41 = !{!42}
!42 = !DIDerivedType(tag: DW_TAG_typedef, name: "uint32_t", file: !43, line: 26, baseType: !44)
!43 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/stdint-uintn.h", directory: "", checksumkind: CSK_MD5, checksum: "2bf2ae53c58c01b1a1b9383b5195125c")
!44 = !DIDerivedType(tag: DW_TAG_typedef, name: "__uint32_t", file: !45, line: 42, baseType: !6)
!45 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/types.h", directory: "", checksumkind: CSK_MD5, checksum: "d108b5f93a74c50510d7d9bc0ab36df9")
!46 = !{}
!47 = !DILocation(line: 130, column: 16, scope: !39)
!48 = !DILocation(line: 130, column: 19, scope: !39)
!49 = !DILocalVariable(name: "m", arg: 1, scope: !50, file: !11, line: 87, type: !12)
!50 = distinct !DISubprogram(name: "kernel_bicg", scope: !11, file: !11, line: 87, type: !51, scopeLine: 93, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition, unit: !2, retainedNodes: !46)
!51 = !DISubroutineType(types: !52)
!52 = !{null, !12, !12, !53, !54, !54, !54, !54}
!53 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !21, size: 64)
!54 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !5, size: 64)
!55 = !DILocation(line: 0, scope: !50, inlinedAt: !56)
!56 = distinct !DILocation(line: 130, column: 3, scope: !39)
!57 = !DILocalVariable(name: "n", arg: 2, scope: !50, file: !11, line: 87, type: !12)
!58 = !DILocalVariable(name: "A", arg: 3, scope: !50, file: !11, line: 88, type: !53)
!59 = !DILocalVariable(name: "s", arg: 4, scope: !50, file: !11, line: 89, type: !54)
!60 = !DILocalVariable(name: "q", arg: 5, scope: !50, file: !11, line: 90, type: !54)
!61 = !DILocalVariable(name: "p", arg: 6, scope: !50, file: !11, line: 91, type: !54)
!62 = !DILocalVariable(name: "r", arg: 7, scope: !50, file: !11, line: 92, type: !54)
!63 = !DILocalVariable(name: "i", scope: !50, file: !11, line: 94, type: !12)
!64 = !DILocation(line: 97, column: 8, scope: !65, inlinedAt: !56)
!65 = distinct !DILexicalBlock(scope: !50, file: !11, line: 97, column: 3)
!66 = !DILocation(line: 0, scope: !65, inlinedAt: !56)
!67 = !DILocation(line: 97, column: 17, scope: !68, inlinedAt: !56)
!68 = distinct !DILexicalBlock(scope: !65, file: !11, line: 97, column: 3)
!69 = !DILocation(line: 97, column: 3, scope: !65, inlinedAt: !56)
!70 = !DILocation(line: 98, column: 5, scope: !68, inlinedAt: !56)
!71 = !DILocation(line: 98, column: 10, scope: !68, inlinedAt: !56)
!72 = !DILocation(line: 97, column: 27, scope: !68, inlinedAt: !56)
!73 = !DILocation(line: 97, column: 3, scope: !68, inlinedAt: !56)
!74 = distinct !{!74, !69, !75, !76}
!75 = !DILocation(line: 98, column: 12, scope: !65, inlinedAt: !56)
!76 = !{!"llvm.loop.mustprogress"}
!77 = !DILocation(line: 99, column: 8, scope: !78, inlinedAt: !56)
!78 = distinct !DILexicalBlock(scope: !50, file: !11, line: 99, column: 3)
!79 = !DILocation(line: 0, scope: !78, inlinedAt: !56)
!80 = !DILocation(line: 99, column: 17, scope: !81, inlinedAt: !56)
!81 = distinct !DILexicalBlock(scope: !78, file: !11, line: 99, column: 3)
!82 = !DILocation(line: 99, column: 3, scope: !78, inlinedAt: !56)
!83 = !DILocation(line: 101, column: 7, scope: !84, inlinedAt: !56)
!84 = distinct !DILexicalBlock(scope: !81, file: !11, line: 100, column: 5)
!85 = !DILocation(line: 101, column: 12, scope: !84, inlinedAt: !56)
!86 = !DILocalVariable(name: "j", scope: !50, file: !11, line: 94, type: !12)
!87 = !DILocation(line: 102, column: 12, scope: !88, inlinedAt: !56)
!88 = distinct !DILexicalBlock(scope: !84, file: !11, line: 102, column: 7)
!89 = !DILocation(line: 0, scope: !88, inlinedAt: !56)
!90 = !DILocation(line: 102, column: 21, scope: !91, inlinedAt: !56)
!91 = distinct !DILexicalBlock(scope: !88, file: !11, line: 102, column: 7)
!92 = !DILocation(line: 102, column: 7, scope: !88, inlinedAt: !56)
!93 = !DILocation(line: 104, column: 11, scope: !94, inlinedAt: !56)
!94 = distinct !DILexicalBlock(scope: !91, file: !11, line: 103, column: 2)
!95 = !DILocation(line: 104, column: 18, scope: !94, inlinedAt: !56)
!96 = !DILocation(line: 104, column: 25, scope: !94, inlinedAt: !56)
!97 = !DILocation(line: 104, column: 23, scope: !94, inlinedAt: !56)
!98 = !DILocation(line: 104, column: 16, scope: !94, inlinedAt: !56)
!99 = !DILocation(line: 104, column: 4, scope: !94, inlinedAt: !56)
!100 = !DILocation(line: 104, column: 9, scope: !94, inlinedAt: !56)
!101 = !DILocation(line: 105, column: 11, scope: !94, inlinedAt: !56)
!102 = !DILocation(line: 105, column: 18, scope: !94, inlinedAt: !56)
!103 = !DILocation(line: 105, column: 28, scope: !94, inlinedAt: !56)
!104 = !DILocation(line: 105, column: 26, scope: !94, inlinedAt: !56)
!105 = !DILocation(line: 105, column: 16, scope: !94, inlinedAt: !56)
!106 = !DILocation(line: 105, column: 4, scope: !94, inlinedAt: !56)
!107 = !DILocation(line: 105, column: 9, scope: !94, inlinedAt: !56)
!108 = !DILocation(line: 102, column: 31, scope: !91, inlinedAt: !56)
!109 = !DILocation(line: 102, column: 7, scope: !91, inlinedAt: !56)
!110 = distinct !{!110, !92, !111, !76}
!111 = !DILocation(line: 106, column: 2, scope: !88, inlinedAt: !56)
!112 = !DILocation(line: 99, column: 27, scope: !81, inlinedAt: !56)
!113 = !DILocation(line: 99, column: 3, scope: !81, inlinedAt: !56)
!114 = distinct !{!114, !82, !115, !76}
!115 = !DILocation(line: 107, column: 5, scope: !78, inlinedAt: !56)
!116 = !DILocation(line: 136, column: 3, scope: !39)
