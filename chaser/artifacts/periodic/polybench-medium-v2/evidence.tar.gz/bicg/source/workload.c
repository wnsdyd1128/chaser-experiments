#define CHASER_EXPECTED 2707291555u
/* Generated driver; original functions follow unchanged except storage. */
#define MEDIUM_DATASET
#define POLYBENCH_USE_SCALAR_LB
#define POLYBENCH_STACK_ARRAYS
#define POLYBENCH_DUMP_ARRAYS
#include "adapter.h"
/**
 * This version is stamped on May 10, 2016
 *
 * Contact:
 *   Louis-Noel Pouchet <pouchet.ohio-state.edu>
 *   Tomofumi Yuki <tomofumi.yuki.fr>
 *
 * Web address: http://polybench.sourceforge.net
 */
/* bicg.c: this file is part of PolyBench/C */

#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <math.h>

/* Include polybench common header. */
#include <polybench.h>

/* Include benchmark-specific header. */
#include "bicg.h"


/* Array initialization. */

#define y1 pb_y1
DATA_TYPE A[N][M] PB_STORAGE(A);
DATA_TYPE s[M] PB_STORAGE(s);
DATA_TYPE q[N] PB_STORAGE(q);
DATA_TYPE p[M] PB_STORAGE(p);
DATA_TYPE r[N] PB_STORAGE(r);
static
void init_array (int m, int n,
		 DATA_TYPE POLYBENCH_2D(A,N,M,n,m),
		 DATA_TYPE POLYBENCH_1D(r,N,n),
		 DATA_TYPE POLYBENCH_1D(p,M,m))
{
  int i, j;

  for (i = 0; i < m; i++)
    p[i] = (DATA_TYPE)(i % m) / m;
  for (i = 0; i < n; i++) {
    r[i] = (DATA_TYPE)(i % n) / n;
    for (j = 0; j < m; j++)
      A[i][j] = (DATA_TYPE) (i*(j+1) % n)/n;
  }
}


/* DCE code. Must scan the entire live-out data.
   Can be used also to check the correctness of the output. */
static
void print_array(int m, int n,
		 DATA_TYPE POLYBENCH_1D(s,M,m),
		 DATA_TYPE POLYBENCH_1D(q,N,n))

{
  int i;

  POLYBENCH_DUMP_START;
  POLYBENCH_DUMP_BEGIN("s");
  for (i = 0; i < m; i++) {
    if (i % 20 == 0) fprintf (POLYBENCH_DUMP_TARGET, "\n");
    fprintf (POLYBENCH_DUMP_TARGET, DATA_PRINTF_MODIFIER, s[i]);
  }
  POLYBENCH_DUMP_END("s");
  POLYBENCH_DUMP_BEGIN("q");
  for (i = 0; i < n; i++) {
    if (i % 20 == 0) fprintf (POLYBENCH_DUMP_TARGET, "\n");
    fprintf (POLYBENCH_DUMP_TARGET, DATA_PRINTF_MODIFIER, q[i]);
  }
  POLYBENCH_DUMP_END("q");
  POLYBENCH_DUMP_FINISH;
}


/* Main computational kernel. The whole function will be timed,
   including the call and return. */
static
__attribute__((always_inline)) inline void kernel_bicg(int m, int n,
		 DATA_TYPE POLYBENCH_2D(A,N,M,n,m),
		 DATA_TYPE POLYBENCH_1D(s,M,m),
		 DATA_TYPE POLYBENCH_1D(q,N,n),
		 DATA_TYPE POLYBENCH_1D(p,M,m),
		 DATA_TYPE POLYBENCH_1D(r,N,n))
{
  int i, j;

#pragma scop
  for (i = 0; i < _PB_M; i++)
    s[i] = 0;
  for (i = 0; i < _PB_N; i++)
    {
      q[i] = SCALAR_VAL(0.0);
      for (j = 0; j < _PB_M; j++)
	{
	  s[j] = s[j] + r[i] * A[i][j];
	  q[i] = q[i] + A[i][j] * p[j];
	}
    }
#pragma endscop

}



int n = N;
  int m = M;
void workload_prepare(void) {}
void workload_reset(unsigned task) {
  (void)task;
  memset(A, 0, sizeof(A));
  memset(s, 0, sizeof(s));
  memset(q, 0, sizeof(q));
  memset(p, 0, sizeof(p));
  memset(r, 0, sizeof(r));
  init_array (m, n,
	      POLYBENCH_ARRAY(A),
	      POLYBENCH_ARRAY(r),
	      POLYBENCH_ARRAY(p));
}
PB_ANALYZE uint32_t task_job_polybench(void) {
  kernel_bicg (m, n,
	       POLYBENCH_ARRAY(A),
	       POLYBENCH_ARRAY(s),
	       POLYBENCH_ARRAY(q),
	       POLYBENCH_ARRAY(p),
	       POLYBENCH_ARRAY(r));
  return 0;
}
uint32_t workload_checksum(unsigned task) {
  (void)task;
  pb_hash = 2166136261u;
  print_array(m, n, POLYBENCH_ARRAY(s), POLYBENCH_ARRAY(q));
  return pb_hash;
}
uint32_t (*const workload_jobs[])(void) = {task_job_polybench};
#ifndef CHASER_EXPECTED
#define CHASER_EXPECTED 0u
#endif
const uint32_t workload_expected[] = {CHASER_EXPECTED};
#ifdef CHASER_NATIVE
int main(void) { workload_reset(0); task_job_polybench();
  uint32_t first = workload_checksum(0); pb_emit = 0;
  workload_reset(0); task_job_polybench();
  if (first != workload_checksum(0)) return 1;
  printf("%u\n", first); return 0; }
#endif
