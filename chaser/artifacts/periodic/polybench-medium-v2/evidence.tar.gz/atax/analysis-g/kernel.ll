; ModuleID = 'inlined.ll'
source_filename = "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/triangular-20260929/suite/atax/source/workload.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

@m = external dso_local global i32, align 4, !dbg !0
@n = external dso_local global i32, align 4, !dbg !9
@A = external dso_local global [390 x [410 x double]], section ".chaser_data.A", align 64, !dbg !13
@x = external dso_local global [410 x double], section ".chaser_data.x", align 64, !dbg !19
@y = external dso_local global [410 x double], section ".chaser_data.y", align 64, !dbg !23
@tmp = external dso_local global [390 x double], section ".chaser_data.tmp", align 64, !dbg !25
@.str = hidden unnamed_addr constant [12 x i8] c"ape.analyze\00", section "llvm.metadata"
@.str.1 = hidden unnamed_addr constant [119 x i8] c"/workspace/experiments-array-support/chaser/.cache/periodic-polybench/triangular-20260929/suite/atax/source/workload.c\00", section "llvm.metadata"
@.str.2 = hidden unnamed_addr constant [23 x i8] c"==BEGIN DUMP_ARRAYS==\0A\00", align 1
@.str.3 = hidden unnamed_addr constant [15 x i8] c"begin dump: %s\00", align 1
@.str.4 = hidden unnamed_addr constant [2 x i8] c"y\00", align 1
@.str.5 = hidden unnamed_addr constant [2 x i8] c"\0A\00", align 1
@.str.6 = hidden unnamed_addr constant [8 x i8] c"%0.2lf \00", align 1
@.str.7 = hidden unnamed_addr constant [17 x i8] c"\0Aend   dump: %s\0A\00", align 1
@.str.8 = hidden unnamed_addr constant [23 x i8] c"==END   DUMP_ARRAYS==\0A\00", align 1
@llvm.global.annotations = appending global [1 x { i8*, i8*, i8*, i32, i8* }] [{ i8*, i8*, i8*, i32, i8* } { i8* bitcast (i32 ()* @task_job_polybench to i8*), i8* getelementptr inbounds ([12 x i8], [12 x i8]* @.str, i32 0, i32 0), i8* getelementptr inbounds ([119 x i8], [119 x i8]* @.str.1, i32 0, i32 0), i32 114, i8* null }], section "llvm.metadata"

; Function Attrs: noinline nounwind uwtable
define dso_local i32 @task_job_polybench() #0 !dbg !37 {
  %1 = load i32, i32* @m, align 4, !dbg !45
  %2 = load i32, i32* @n, align 4, !dbg !46
  call void @llvm.dbg.value(metadata i32 %1, metadata !47, metadata !DIExpression()), !dbg !53
  call void @llvm.dbg.value(metadata i32 %2, metadata !55, metadata !DIExpression()), !dbg !53
  call void @llvm.dbg.value(metadata [410 x double]* getelementptr inbounds ([390 x [410 x double]], [390 x [410 x double]]* @A, i64 0, i64 0), metadata !56, metadata !DIExpression()), !dbg !53
  call void @llvm.dbg.value(metadata double* getelementptr inbounds ([410 x double], [410 x double]* @x, i64 0, i64 0), metadata !57, metadata !DIExpression()), !dbg !53
  call void @llvm.dbg.value(metadata double* getelementptr inbounds ([410 x double], [410 x double]* @y, i64 0, i64 0), metadata !58, metadata !DIExpression()), !dbg !53
  call void @llvm.dbg.value(metadata double* getelementptr inbounds ([390 x double], [390 x double]* @tmp, i64 0, i64 0), metadata !59, metadata !DIExpression()), !dbg !53
  call void @llvm.dbg.value(metadata i32 0, metadata !60, metadata !DIExpression()), !dbg !53
  br label %3, !dbg !61

3:                                                ; preds = %5, %0
  %.01 = phi i32 [ 0, %0 ], [ %8, %5 ], !dbg !63
  call void @llvm.dbg.value(metadata i32 %.01, metadata !60, metadata !DIExpression()), !dbg !53
  %4 = icmp slt i32 %.01, 410, !dbg !64
  br i1 %4, label %5, label %9, !dbg !66

5:                                                ; preds = %3
  %6 = sext i32 %.01 to i64, !dbg !67
  %7 = getelementptr inbounds double, double* getelementptr inbounds ([410 x double], [410 x double]* @y, i64 0, i64 0), i64 %6, !dbg !67
  store double 0.000000e+00, double* %7, align 8, !dbg !68
  %8 = add nsw i32 %.01, 1, !dbg !69
  call void @llvm.dbg.value(metadata i32 %8, metadata !60, metadata !DIExpression()), !dbg !53
  br label %3, !dbg !70, !llvm.loop !71

9:                                                ; preds = %3
  call void @llvm.dbg.value(metadata i32 0, metadata !60, metadata !DIExpression()), !dbg !53
  br label %10, !dbg !74

10:                                               ; preds = %54, %9
  %.12 = phi i32 [ 0, %9 ], [ %55, %54 ], !dbg !76
  call void @llvm.dbg.value(metadata i32 %.12, metadata !60, metadata !DIExpression()), !dbg !53
  %11 = icmp slt i32 %.12, 390, !dbg !77
  br i1 %11, label %12, label %56, !dbg !79

12:                                               ; preds = %10
  %13 = sext i32 %.12 to i64, !dbg !80
  %14 = getelementptr inbounds double, double* getelementptr inbounds ([390 x double], [390 x double]* @tmp, i64 0, i64 0), i64 %13, !dbg !80
  store double 0.000000e+00, double* %14, align 8, !dbg !82
  call void @llvm.dbg.value(metadata i32 0, metadata !83, metadata !DIExpression()), !dbg !53
  br label %15, !dbg !84

15:                                               ; preds = %17, %12
  %.0 = phi i32 [ 0, %12 ], [ %33, %17 ], !dbg !86
  call void @llvm.dbg.value(metadata i32 %.0, metadata !83, metadata !DIExpression()), !dbg !53
  %16 = icmp slt i32 %.0, 410, !dbg !87
  br i1 %16, label %17, label %34, !dbg !89

17:                                               ; preds = %15
  %18 = sext i32 %.12 to i64, !dbg !90
  %19 = getelementptr inbounds double, double* getelementptr inbounds ([390 x double], [390 x double]* @tmp, i64 0, i64 0), i64 %18, !dbg !90
  %20 = load double, double* %19, align 8, !dbg !90
  %21 = sext i32 %.12 to i64, !dbg !91
  %22 = getelementptr inbounds [410 x double], [410 x double]* getelementptr inbounds ([390 x [410 x double]], [390 x [410 x double]]* @A, i64 0, i64 0), i64 %21, !dbg !91
  %23 = sext i32 %.0 to i64, !dbg !91
  %24 = getelementptr inbounds [410 x double], [410 x double]* %22, i64 0, i64 %23, !dbg !91
  %25 = load double, double* %24, align 8, !dbg !91
  %26 = sext i32 %.0 to i64, !dbg !92
  %27 = getelementptr inbounds double, double* getelementptr inbounds ([410 x double], [410 x double]* @x, i64 0, i64 0), i64 %26, !dbg !92
  %28 = load double, double* %27, align 8, !dbg !92
  %29 = fmul double %25, %28, !dbg !93
  %30 = fadd double %20, %29, !dbg !94
  %31 = sext i32 %.12 to i64, !dbg !95
  %32 = getelementptr inbounds double, double* getelementptr inbounds ([390 x double], [390 x double]* @tmp, i64 0, i64 0), i64 %31, !dbg !95
  store double %30, double* %32, align 8, !dbg !96
  %33 = add nsw i32 %.0, 1, !dbg !97
  call void @llvm.dbg.value(metadata i32 %33, metadata !83, metadata !DIExpression()), !dbg !53
  br label %15, !dbg !98, !llvm.loop !99

34:                                               ; preds = %15
  call void @llvm.dbg.value(metadata i32 0, metadata !83, metadata !DIExpression()), !dbg !53
  br label %35, !dbg !101

35:                                               ; preds = %37, %34
  %.1 = phi i32 [ 0, %34 ], [ %53, %37 ], !dbg !103
  call void @llvm.dbg.value(metadata i32 %.1, metadata !83, metadata !DIExpression()), !dbg !53
  %36 = icmp slt i32 %.1, 410, !dbg !104
  br i1 %36, label %37, label %54, !dbg !106

37:                                               ; preds = %35
  %38 = sext i32 %.1 to i64, !dbg !107
  %39 = getelementptr inbounds double, double* getelementptr inbounds ([410 x double], [410 x double]* @y, i64 0, i64 0), i64 %38, !dbg !107
  %40 = load double, double* %39, align 8, !dbg !107
  %41 = sext i32 %.12 to i64, !dbg !108
  %42 = getelementptr inbounds [410 x double], [410 x double]* getelementptr inbounds ([390 x [410 x double]], [390 x [410 x double]]* @A, i64 0, i64 0), i64 %41, !dbg !108
  %43 = sext i32 %.1 to i64, !dbg !108
  %44 = getelementptr inbounds [410 x double], [410 x double]* %42, i64 0, i64 %43, !dbg !108
  %45 = load double, double* %44, align 8, !dbg !108
  %46 = sext i32 %.12 to i64, !dbg !109
  %47 = getelementptr inbounds double, double* getelementptr inbounds ([390 x double], [390 x double]* @tmp, i64 0, i64 0), i64 %46, !dbg !109
  %48 = load double, double* %47, align 8, !dbg !109
  %49 = fmul double %45, %48, !dbg !110
  %50 = fadd double %40, %49, !dbg !111
  %51 = sext i32 %.1 to i64, !dbg !112
  %52 = getelementptr inbounds double, double* getelementptr inbounds ([410 x double], [410 x double]* @y, i64 0, i64 0), i64 %51, !dbg !112
  store double %50, double* %52, align 8, !dbg !113
  %53 = add nsw i32 %.1, 1, !dbg !114
  call void @llvm.dbg.value(metadata i32 %53, metadata !83, metadata !DIExpression()), !dbg !53
  br label %35, !dbg !115, !llvm.loop !116

54:                                               ; preds = %35
  %55 = add nsw i32 %.12, 1, !dbg !118
  call void @llvm.dbg.value(metadata i32 %55, metadata !60, metadata !DIExpression()), !dbg !53
  br label %10, !dbg !119, !llvm.loop !120

56:                                               ; preds = %10
  ret i32 0, !dbg !122
}

; Function Attrs: nofree nosync nounwind readnone speculatable willreturn
declare void @llvm.dbg.value(metadata, metadata, metadata) #1

attributes #0 = { noinline nounwind uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { nofree nosync nounwind readnone speculatable willreturn }

!llvm.dbg.cu = !{!2}
!llvm.module.flags = !{!29, !30, !31, !32, !33, !34, !35}
!llvm.ident = !{!36}

!0 = !DIGlobalVariableExpression(var: !1, expr: !DIExpression())
!1 = distinct !DIGlobalVariable(name: "m", scope: !2, file: !11, line: 103, type: !12, isLocal: false, isDefinition: true)
!2 = distinct !DICompileUnit(language: DW_LANG_C99, file: !3, producer: "Ubuntu clang version 14.0.0-1ubuntu1.1", isOptimized: false, runtimeVersion: 0, emissionKind: FullDebug, retainedTypes: !4, globals: !8, splitDebugInlining: false, nameTableKind: None)
!3 = !DIFile(filename: "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/triangular-20260929/suite/atax/source/workload.c", directory: "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/triangular-20260929/suite/atax/analysis-g", checksumkind: CSK_MD5, checksum: "1866978266073eb505d85c7a4917d95d")
!4 = !{!5, !6, !7}
!5 = !DIBasicType(name: "double", size: 64, encoding: DW_ATE_float)
!6 = !DIBasicType(name: "unsigned int", size: 32, encoding: DW_ATE_unsigned)
!7 = !DIBasicType(name: "unsigned char", size: 8, encoding: DW_ATE_unsigned_char)
!8 = !{!0, !9, !13, !19, !23, !25}
!9 = !DIGlobalVariableExpression(var: !10, expr: !DIExpression())
!10 = distinct !DIGlobalVariable(name: "n", scope: !2, file: !11, line: 104, type: !12, isLocal: false, isDefinition: true)
!11 = !DIFile(filename: "source/workload.c", directory: "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/triangular-20260929/suite/atax", checksumkind: CSK_MD5, checksum: "1866978266073eb505d85c7a4917d95d")
!12 = !DIBasicType(name: "int", size: 32, encoding: DW_ATE_signed)
!13 = !DIGlobalVariableExpression(var: !14, expr: !DIExpression())
!14 = distinct !DIGlobalVariable(name: "A", scope: !2, file: !11, line: 34, type: !15, isLocal: false, isDefinition: true, align: 512)
!15 = !DICompositeType(tag: DW_TAG_array_type, baseType: !5, size: 10233600, elements: !16)
!16 = !{!17, !18}
!17 = !DISubrange(count: 390)
!18 = !DISubrange(count: 410)
!19 = !DIGlobalVariableExpression(var: !20, expr: !DIExpression())
!20 = distinct !DIGlobalVariable(name: "x", scope: !2, file: !11, line: 35, type: !21, isLocal: false, isDefinition: true, align: 512)
!21 = !DICompositeType(tag: DW_TAG_array_type, baseType: !5, size: 26240, elements: !22)
!22 = !{!18}
!23 = !DIGlobalVariableExpression(var: !24, expr: !DIExpression())
!24 = distinct !DIGlobalVariable(name: "y", scope: !2, file: !11, line: 36, type: !21, isLocal: false, isDefinition: true, align: 512)
!25 = !DIGlobalVariableExpression(var: !26, expr: !DIExpression())
!26 = distinct !DIGlobalVariable(name: "tmp", scope: !2, file: !11, line: 37, type: !27, isLocal: false, isDefinition: true, align: 512)
!27 = !DICompositeType(tag: DW_TAG_array_type, baseType: !5, size: 24960, elements: !28)
!28 = !{!17}
!29 = !{i32 7, !"Dwarf Version", i32 5}
!30 = !{i32 2, !"Debug Info Version", i32 3}
!31 = !{i32 1, !"wchar_size", i32 4}
!32 = !{i32 7, !"PIC Level", i32 2}
!33 = !{i32 7, !"PIE Level", i32 2}
!34 = !{i32 7, !"uwtable", i32 1}
!35 = !{i32 7, !"frame-pointer", i32 2}
!36 = !{!"Ubuntu clang version 14.0.0-1ubuntu1.1"}
!37 = distinct !DISubprogram(name: "task_job_polybench", scope: !11, file: !11, line: 114, type: !38, scopeLine: 114, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !2, retainedNodes: !44)
!38 = !DISubroutineType(types: !39)
!39 = !{!40}
!40 = !DIDerivedType(tag: DW_TAG_typedef, name: "uint32_t", file: !41, line: 26, baseType: !42)
!41 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/stdint-uintn.h", directory: "", checksumkind: CSK_MD5, checksum: "2bf2ae53c58c01b1a1b9383b5195125c")
!42 = !DIDerivedType(tag: DW_TAG_typedef, name: "__uint32_t", file: !43, line: 42, baseType: !6)
!43 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/types.h", directory: "", checksumkind: CSK_MD5, checksum: "d108b5f93a74c50510d7d9bc0ab36df9")
!44 = !{}
!45 = !DILocation(line: 115, column: 16, scope: !37)
!46 = !DILocation(line: 115, column: 19, scope: !37)
!47 = !DILocalVariable(name: "m", arg: 1, scope: !48, file: !11, line: 78, type: !12)
!48 = distinct !DISubprogram(name: "kernel_atax", scope: !11, file: !11, line: 78, type: !49, scopeLine: 83, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition, unit: !2, retainedNodes: !44)
!49 = !DISubroutineType(types: !50)
!50 = !{null, !12, !12, !51, !52, !52, !52}
!51 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !21, size: 64)
!52 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !5, size: 64)
!53 = !DILocation(line: 0, scope: !48, inlinedAt: !54)
!54 = distinct !DILocation(line: 115, column: 3, scope: !37)
!55 = !DILocalVariable(name: "n", arg: 2, scope: !48, file: !11, line: 78, type: !12)
!56 = !DILocalVariable(name: "A", arg: 3, scope: !48, file: !11, line: 79, type: !51)
!57 = !DILocalVariable(name: "x", arg: 4, scope: !48, file: !11, line: 80, type: !52)
!58 = !DILocalVariable(name: "y", arg: 5, scope: !48, file: !11, line: 81, type: !52)
!59 = !DILocalVariable(name: "tmp", arg: 6, scope: !48, file: !11, line: 82, type: !52)
!60 = !DILocalVariable(name: "i", scope: !48, file: !11, line: 84, type: !12)
!61 = !DILocation(line: 87, column: 8, scope: !62, inlinedAt: !54)
!62 = distinct !DILexicalBlock(scope: !48, file: !11, line: 87, column: 3)
!63 = !DILocation(line: 0, scope: !62, inlinedAt: !54)
!64 = !DILocation(line: 87, column: 17, scope: !65, inlinedAt: !54)
!65 = distinct !DILexicalBlock(scope: !62, file: !11, line: 87, column: 3)
!66 = !DILocation(line: 87, column: 3, scope: !62, inlinedAt: !54)
!67 = !DILocation(line: 88, column: 5, scope: !65, inlinedAt: !54)
!68 = !DILocation(line: 88, column: 10, scope: !65, inlinedAt: !54)
!69 = !DILocation(line: 87, column: 27, scope: !65, inlinedAt: !54)
!70 = !DILocation(line: 87, column: 3, scope: !65, inlinedAt: !54)
!71 = distinct !{!71, !66, !72, !73}
!72 = !DILocation(line: 88, column: 12, scope: !62, inlinedAt: !54)
!73 = !{!"llvm.loop.mustprogress"}
!74 = !DILocation(line: 89, column: 8, scope: !75, inlinedAt: !54)
!75 = distinct !DILexicalBlock(scope: !48, file: !11, line: 89, column: 3)
!76 = !DILocation(line: 0, scope: !75, inlinedAt: !54)
!77 = !DILocation(line: 89, column: 17, scope: !78, inlinedAt: !54)
!78 = distinct !DILexicalBlock(scope: !75, file: !11, line: 89, column: 3)
!79 = !DILocation(line: 89, column: 3, scope: !75, inlinedAt: !54)
!80 = !DILocation(line: 91, column: 7, scope: !81, inlinedAt: !54)
!81 = distinct !DILexicalBlock(scope: !78, file: !11, line: 90, column: 5)
!82 = !DILocation(line: 91, column: 14, scope: !81, inlinedAt: !54)
!83 = !DILocalVariable(name: "j", scope: !48, file: !11, line: 84, type: !12)
!84 = !DILocation(line: 92, column: 12, scope: !85, inlinedAt: !54)
!85 = distinct !DILexicalBlock(scope: !81, file: !11, line: 92, column: 7)
!86 = !DILocation(line: 0, scope: !85, inlinedAt: !54)
!87 = !DILocation(line: 92, column: 21, scope: !88, inlinedAt: !54)
!88 = distinct !DILexicalBlock(scope: !85, file: !11, line: 92, column: 7)
!89 = !DILocation(line: 92, column: 7, scope: !85, inlinedAt: !54)
!90 = !DILocation(line: 93, column: 11, scope: !88, inlinedAt: !54)
!91 = !DILocation(line: 93, column: 20, scope: !88, inlinedAt: !54)
!92 = !DILocation(line: 93, column: 30, scope: !88, inlinedAt: !54)
!93 = !DILocation(line: 93, column: 28, scope: !88, inlinedAt: !54)
!94 = !DILocation(line: 93, column: 18, scope: !88, inlinedAt: !54)
!95 = !DILocation(line: 93, column: 2, scope: !88, inlinedAt: !54)
!96 = !DILocation(line: 93, column: 9, scope: !88, inlinedAt: !54)
!97 = !DILocation(line: 92, column: 31, scope: !88, inlinedAt: !54)
!98 = !DILocation(line: 92, column: 7, scope: !88, inlinedAt: !54)
!99 = distinct !{!99, !89, !100, !73}
!100 = !DILocation(line: 93, column: 33, scope: !85, inlinedAt: !54)
!101 = !DILocation(line: 94, column: 12, scope: !102, inlinedAt: !54)
!102 = distinct !DILexicalBlock(scope: !81, file: !11, line: 94, column: 7)
!103 = !DILocation(line: 0, scope: !102, inlinedAt: !54)
!104 = !DILocation(line: 94, column: 21, scope: !105, inlinedAt: !54)
!105 = distinct !DILexicalBlock(scope: !102, file: !11, line: 94, column: 7)
!106 = !DILocation(line: 94, column: 7, scope: !102, inlinedAt: !54)
!107 = !DILocation(line: 95, column: 9, scope: !105, inlinedAt: !54)
!108 = !DILocation(line: 95, column: 16, scope: !105, inlinedAt: !54)
!109 = !DILocation(line: 95, column: 26, scope: !105, inlinedAt: !54)
!110 = !DILocation(line: 95, column: 24, scope: !105, inlinedAt: !54)
!111 = !DILocation(line: 95, column: 14, scope: !105, inlinedAt: !54)
!112 = !DILocation(line: 95, column: 2, scope: !105, inlinedAt: !54)
!113 = !DILocation(line: 95, column: 7, scope: !105, inlinedAt: !54)
!114 = !DILocation(line: 94, column: 31, scope: !105, inlinedAt: !54)
!115 = !DILocation(line: 94, column: 7, scope: !105, inlinedAt: !54)
!116 = distinct !{!116, !106, !117, !73}
!117 = !DILocation(line: 95, column: 31, scope: !102, inlinedAt: !54)
!118 = !DILocation(line: 89, column: 27, scope: !78, inlinedAt: !54)
!119 = !DILocation(line: 89, column: 3, scope: !78, inlinedAt: !54)
!120 = distinct !{!120, !79, !121, !73}
!121 = !DILocation(line: 96, column: 5, scope: !75, inlinedAt: !54)
!122 = !DILocation(line: 120, column: 3, scope: !37)
