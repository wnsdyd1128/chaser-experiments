; ModuleID = 'workload.ll'
source_filename = "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/triangular-20260929/suite/correlation/source/workload.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

%struct._IO_FILE = type { i32, i8*, i8*, i8*, i8*, i8*, i8*, i8*, i8*, i8*, i8*, i8*, %struct._IO_marker*, %struct._IO_FILE*, i32, i32, i64, i16, i8, [1 x i8], i8*, i64, %struct._IO_codecvt*, %struct._IO_wide_data*, %struct._IO_FILE*, i8*, i64, i32, [20 x i8] }
%struct._IO_marker = type opaque
%struct._IO_codecvt = type opaque
%struct._IO_wide_data = type opaque
%struct.__va_list_tag = type { i32, i32, i8*, i8* }

@n = dso_local global i32 260, align 4, !dbg !0
@m = dso_local global i32 240, align 4, !dbg !9
@data = dso_local global [260 x [240 x double]] zeroinitializer, section ".chaser_data.data", align 64, !dbg !33
@corr = dso_local global [240 x [240 x double]] zeroinitializer, section ".chaser_data.corr", align 64, !dbg !39
@mean = dso_local global [240 x double] zeroinitializer, section ".chaser_data.mean", align 64, !dbg !43
@stddev = dso_local global [240 x double] zeroinitializer, section ".chaser_data.stddev", align 64, !dbg !47
@float_n = dso_local global double 0.000000e+00, align 8, !dbg !49
@.str = private unnamed_addr constant [12 x i8] c"ape.analyze\00", section "llvm.metadata"
@.str.1 = private unnamed_addr constant [126 x i8] c"/workspace/experiments-array-support/chaser/.cache/periodic-polybench/triangular-20260929/suite/correlation/source/workload.c\00", section "llvm.metadata"
@pb_hash = internal global i32 0, align 4, !dbg !30
@workload_jobs = dso_local constant [1 x i32 ()*] [i32 ()* @task_job_polybench], align 8, !dbg !13
@workload_expected = dso_local constant [1 x i32] [i32 85030355], align 4, !dbg !26
@stderr = external global %struct._IO_FILE*, align 8
@.str.2 = private unnamed_addr constant [23 x i8] c"==BEGIN DUMP_ARRAYS==\0A\00", align 1
@.str.3 = private unnamed_addr constant [15 x i8] c"begin dump: %s\00", align 1
@.str.4 = private unnamed_addr constant [5 x i8] c"corr\00", align 1
@.str.5 = private unnamed_addr constant [2 x i8] c"\0A\00", align 1
@.str.6 = private unnamed_addr constant [8 x i8] c"%0.2lf \00", align 1
@.str.7 = private unnamed_addr constant [17 x i8] c"\0Aend   dump: %s\0A\00", align 1
@.str.8 = private unnamed_addr constant [23 x i8] c"==END   DUMP_ARRAYS==\0A\00", align 1
@pb_emit = internal global i32 1, align 4, !dbg !51
@llvm.global.annotations = appending global [1 x { i8*, i8*, i8*, i32, i8* }] [{ i8*, i8*, i8*, i32, i8* } { i8* bitcast (i32 ()* @task_job_polybench to i8*), i8* getelementptr inbounds ([12 x i8], [12 x i8]* @.str, i32 0, i32 0), i8* getelementptr inbounds ([126 x i8], [126 x i8]* @.str.1, i32 0, i32 0), i32 155, i8* null }], section "llvm.metadata"

; Function Attrs: noinline nounwind uwtable
define dso_local void @workload_prepare() #0 !dbg !61 {
  ret void, !dbg !65
}

; Function Attrs: noinline nounwind uwtable
define dso_local void @workload_reset(i32 noundef %0) #0 !dbg !66 {
  call void @llvm.dbg.value(metadata i32 %0, metadata !69, metadata !DIExpression()), !dbg !70
  call void @llvm.memset.p0i8.i64(i8* align 64 bitcast ([260 x [240 x double]]* @data to i8*), i8 0, i64 499200, i1 false), !dbg !71
  call void @llvm.memset.p0i8.i64(i8* align 64 bitcast ([240 x [240 x double]]* @corr to i8*), i8 0, i64 460800, i1 false), !dbg !72
  call void @llvm.memset.p0i8.i64(i8* align 64 bitcast ([240 x double]* @mean to i8*), i8 0, i64 1920, i1 false), !dbg !73
  call void @llvm.memset.p0i8.i64(i8* align 64 bitcast ([240 x double]* @stddev to i8*), i8 0, i64 1920, i1 false), !dbg !74
  %2 = load i32, i32* @m, align 4, !dbg !75
  %3 = load i32, i32* @n, align 4, !dbg !76
  call void @init_array(i32 noundef %2, i32 noundef %3, double* noundef @float_n, [240 x double]* noundef getelementptr inbounds ([260 x [240 x double]], [260 x [240 x double]]* @data, i64 0, i64 0)), !dbg !77
  ret void, !dbg !78
}

; Function Attrs: nofree nosync nounwind readnone speculatable willreturn
declare void @llvm.dbg.declare(metadata, metadata, metadata) #1

; Function Attrs: argmemonly nofree nounwind willreturn writeonly
declare void @llvm.memset.p0i8.i64(i8* nocapture writeonly, i8, i64, i1 immarg) #2

; Function Attrs: noinline nounwind uwtable
define internal void @init_array(i32 noundef %0, i32 noundef %1, double* noundef %2, [240 x double]* noundef %3) #0 !dbg !79 {
  call void @llvm.dbg.value(metadata i32 %0, metadata !84, metadata !DIExpression()), !dbg !85
  call void @llvm.dbg.value(metadata i32 %1, metadata !86, metadata !DIExpression()), !dbg !85
  call void @llvm.dbg.value(metadata double* %2, metadata !87, metadata !DIExpression()), !dbg !85
  call void @llvm.dbg.value(metadata [240 x double]* %3, metadata !88, metadata !DIExpression()), !dbg !85
  store double 2.600000e+02, double* %2, align 8, !dbg !89
  call void @llvm.dbg.value(metadata i32 0, metadata !90, metadata !DIExpression()), !dbg !85
  br label %5, !dbg !91

5:                                                ; preds = %23, %4
  %.01 = phi i32 [ 0, %4 ], [ %24, %23 ], !dbg !93
  call void @llvm.dbg.value(metadata i32 %.01, metadata !90, metadata !DIExpression()), !dbg !85
  %6 = icmp slt i32 %.01, 260, !dbg !94
  br i1 %6, label %7, label %25, !dbg !96

7:                                                ; preds = %5
  call void @llvm.dbg.value(metadata i32 0, metadata !97, metadata !DIExpression()), !dbg !85
  br label %8, !dbg !98

8:                                                ; preds = %20, %7
  %.0 = phi i32 [ 0, %7 ], [ %21, %20 ], !dbg !100
  call void @llvm.dbg.value(metadata i32 %.0, metadata !97, metadata !DIExpression()), !dbg !85
  %9 = icmp slt i32 %.0, 240, !dbg !101
  br i1 %9, label %10, label %22, !dbg !103

10:                                               ; preds = %8
  %11 = mul nsw i32 %.01, %.0, !dbg !104
  %12 = sitofp i32 %11 to double, !dbg !105
  %13 = fdiv double %12, 2.400000e+02, !dbg !106
  %14 = sitofp i32 %.01 to double, !dbg !107
  %15 = fadd double %13, %14, !dbg !108
  %16 = sext i32 %.01 to i64, !dbg !109
  %17 = getelementptr inbounds [240 x double], [240 x double]* %3, i64 %16, !dbg !109
  %18 = sext i32 %.0 to i64, !dbg !109
  %19 = getelementptr inbounds [240 x double], [240 x double]* %17, i64 0, i64 %18, !dbg !109
  store double %15, double* %19, align 8, !dbg !110
  br label %20, !dbg !109

20:                                               ; preds = %10
  %21 = add nsw i32 %.0, 1, !dbg !111
  call void @llvm.dbg.value(metadata i32 %21, metadata !97, metadata !DIExpression()), !dbg !85
  br label %8, !dbg !112, !llvm.loop !113

22:                                               ; preds = %8
  br label %23, !dbg !114

23:                                               ; preds = %22
  %24 = add nsw i32 %.01, 1, !dbg !116
  call void @llvm.dbg.value(metadata i32 %24, metadata !90, metadata !DIExpression()), !dbg !85
  br label %5, !dbg !117, !llvm.loop !118

25:                                               ; preds = %5
  ret void, !dbg !120
}

; Function Attrs: noinline nounwind uwtable
define dso_local i32 @task_job_polybench() #0 !dbg !121 {
  %1 = load i32, i32* @m, align 4, !dbg !122
  %2 = load i32, i32* @n, align 4, !dbg !123
  %3 = load double, double* @float_n, align 8, !dbg !124
  call void @llvm.dbg.value(metadata i32 %1, metadata !125, metadata !DIExpression()), !dbg !129
  call void @llvm.dbg.value(metadata i32 %2, metadata !131, metadata !DIExpression()), !dbg !129
  call void @llvm.dbg.value(metadata double %3, metadata !132, metadata !DIExpression()), !dbg !129
  call void @llvm.dbg.value(metadata [240 x double]* getelementptr inbounds ([260 x [240 x double]], [260 x [240 x double]]* @data, i64 0, i64 0), metadata !133, metadata !DIExpression()), !dbg !129
  call void @llvm.dbg.value(metadata [240 x double]* getelementptr inbounds ([240 x [240 x double]], [240 x [240 x double]]* @corr, i64 0, i64 0), metadata !134, metadata !DIExpression()), !dbg !129
  call void @llvm.dbg.value(metadata double* getelementptr inbounds ([240 x double], [240 x double]* @mean, i64 0, i64 0), metadata !135, metadata !DIExpression()), !dbg !129
  call void @llvm.dbg.value(metadata double* getelementptr inbounds ([240 x double], [240 x double]* @stddev, i64 0, i64 0), metadata !136, metadata !DIExpression()), !dbg !129
  call void @llvm.dbg.value(metadata double 1.000000e-01, metadata !137, metadata !DIExpression()), !dbg !129
  call void @llvm.dbg.value(metadata i32 0, metadata !138, metadata !DIExpression()), !dbg !129
  br label %4, !dbg !139

4:                                                ; preds = %22, %0
  %.01 = phi i32 [ 0, %0 ], [ %27, %22 ], !dbg !141
  call void @llvm.dbg.value(metadata i32 %.01, metadata !138, metadata !DIExpression()), !dbg !129
  %5 = icmp slt i32 %.01, 240, !dbg !142
  br i1 %5, label %6, label %28, !dbg !144

6:                                                ; preds = %4
  %7 = sext i32 %.01 to i64, !dbg !145
  %8 = getelementptr inbounds double, double* getelementptr inbounds ([240 x double], [240 x double]* @mean, i64 0, i64 0), i64 %7, !dbg !145
  store double 0.000000e+00, double* %8, align 8, !dbg !147
  call void @llvm.dbg.value(metadata i32 0, metadata !148, metadata !DIExpression()), !dbg !129
  br label %9, !dbg !149

9:                                                ; preds = %11, %6
  %.02 = phi i32 [ 0, %6 ], [ %21, %11 ], !dbg !151
  call void @llvm.dbg.value(metadata i32 %.02, metadata !148, metadata !DIExpression()), !dbg !129
  %10 = icmp slt i32 %.02, 260, !dbg !152
  br i1 %10, label %11, label %22, !dbg !154

11:                                               ; preds = %9
  %12 = sext i32 %.02 to i64, !dbg !155
  %13 = getelementptr inbounds [240 x double], [240 x double]* getelementptr inbounds ([260 x [240 x double]], [260 x [240 x double]]* @data, i64 0, i64 0), i64 %12, !dbg !155
  %14 = sext i32 %.01 to i64, !dbg !155
  %15 = getelementptr inbounds [240 x double], [240 x double]* %13, i64 0, i64 %14, !dbg !155
  %16 = load double, double* %15, align 8, !dbg !155
  %17 = sext i32 %.01 to i64, !dbg !156
  %18 = getelementptr inbounds double, double* getelementptr inbounds ([240 x double], [240 x double]* @mean, i64 0, i64 0), i64 %17, !dbg !156
  %19 = load double, double* %18, align 8, !dbg !157
  %20 = fadd double %19, %16, !dbg !157
  store double %20, double* %18, align 8, !dbg !157
  %21 = add nsw i32 %.02, 1, !dbg !158
  call void @llvm.dbg.value(metadata i32 %21, metadata !148, metadata !DIExpression()), !dbg !129
  br label %9, !dbg !159, !llvm.loop !160

22:                                               ; preds = %9
  %23 = sext i32 %.01 to i64, !dbg !162
  %24 = getelementptr inbounds double, double* getelementptr inbounds ([240 x double], [240 x double]* @mean, i64 0, i64 0), i64 %23, !dbg !162
  %25 = load double, double* %24, align 8, !dbg !163
  %26 = fdiv double %25, %3, !dbg !163
  store double %26, double* %24, align 8, !dbg !163
  %27 = add nsw i32 %.01, 1, !dbg !164
  call void @llvm.dbg.value(metadata i32 %27, metadata !138, metadata !DIExpression()), !dbg !129
  br label %4, !dbg !165, !llvm.loop !166

28:                                               ; preds = %4
  call void @llvm.dbg.value(metadata i32 0, metadata !138, metadata !DIExpression()), !dbg !129
  br label %29, !dbg !168

29:                                               ; preds = %81, %28
  %.1 = phi i32 [ 0, %28 ], [ %85, %81 ], !dbg !170
  call void @llvm.dbg.value(metadata i32 %.1, metadata !138, metadata !DIExpression()), !dbg !129
  %30 = icmp slt i32 %.1, 240, !dbg !171
  br i1 %30, label %31, label %86, !dbg !173

31:                                               ; preds = %29
  %32 = sext i32 %.1 to i64, !dbg !174
  %33 = getelementptr inbounds double, double* getelementptr inbounds ([240 x double], [240 x double]* @stddev, i64 0, i64 0), i64 %32, !dbg !174
  store double 0.000000e+00, double* %33, align 8, !dbg !176
  call void @llvm.dbg.value(metadata i32 0, metadata !148, metadata !DIExpression()), !dbg !129
  br label %34, !dbg !177

34:                                               ; preds = %36, %31
  %.13 = phi i32 [ 0, %31 ], [ %60, %36 ], !dbg !179
  call void @llvm.dbg.value(metadata i32 %.13, metadata !148, metadata !DIExpression()), !dbg !129
  %35 = icmp slt i32 %.13, 260, !dbg !180
  br i1 %35, label %36, label %61, !dbg !182

36:                                               ; preds = %34
  %37 = sext i32 %.13 to i64, !dbg !183
  %38 = getelementptr inbounds [240 x double], [240 x double]* getelementptr inbounds ([260 x [240 x double]], [260 x [240 x double]]* @data, i64 0, i64 0), i64 %37, !dbg !183
  %39 = sext i32 %.1 to i64, !dbg !183
  %40 = getelementptr inbounds [240 x double], [240 x double]* %38, i64 0, i64 %39, !dbg !183
  %41 = load double, double* %40, align 8, !dbg !183
  %42 = sext i32 %.1 to i64, !dbg !184
  %43 = getelementptr inbounds double, double* getelementptr inbounds ([240 x double], [240 x double]* @mean, i64 0, i64 0), i64 %42, !dbg !184
  %44 = load double, double* %43, align 8, !dbg !184
  %45 = fsub double %41, %44, !dbg !185
  %46 = sext i32 %.13 to i64, !dbg !186
  %47 = getelementptr inbounds [240 x double], [240 x double]* getelementptr inbounds ([260 x [240 x double]], [260 x [240 x double]]* @data, i64 0, i64 0), i64 %46, !dbg !186
  %48 = sext i32 %.1 to i64, !dbg !186
  %49 = getelementptr inbounds [240 x double], [240 x double]* %47, i64 0, i64 %48, !dbg !186
  %50 = load double, double* %49, align 8, !dbg !186
  %51 = sext i32 %.1 to i64, !dbg !187
  %52 = getelementptr inbounds double, double* getelementptr inbounds ([240 x double], [240 x double]* @mean, i64 0, i64 0), i64 %51, !dbg !187
  %53 = load double, double* %52, align 8, !dbg !187
  %54 = fsub double %50, %53, !dbg !188
  %55 = fmul double %45, %54, !dbg !189
  %56 = sext i32 %.1 to i64, !dbg !190
  %57 = getelementptr inbounds double, double* getelementptr inbounds ([240 x double], [240 x double]* @stddev, i64 0, i64 0), i64 %56, !dbg !190
  %58 = load double, double* %57, align 8, !dbg !191
  %59 = fadd double %58, %55, !dbg !191
  store double %59, double* %57, align 8, !dbg !191
  %60 = add nsw i32 %.13, 1, !dbg !192
  call void @llvm.dbg.value(metadata i32 %60, metadata !148, metadata !DIExpression()), !dbg !129
  br label %34, !dbg !193, !llvm.loop !194

61:                                               ; preds = %34
  %62 = sext i32 %.1 to i64, !dbg !196
  %63 = getelementptr inbounds double, double* getelementptr inbounds ([240 x double], [240 x double]* @stddev, i64 0, i64 0), i64 %62, !dbg !196
  %64 = load double, double* %63, align 8, !dbg !197
  %65 = fdiv double %64, %3, !dbg !197
  store double %65, double* %63, align 8, !dbg !197
  %66 = sext i32 %.1 to i64, !dbg !198
  %67 = getelementptr inbounds double, double* getelementptr inbounds ([240 x double], [240 x double]* @stddev, i64 0, i64 0), i64 %66, !dbg !198
  %68 = load double, double* %67, align 8, !dbg !198
  %69 = call double @sqrt(double noundef %68) #6, !dbg !198
  %70 = sext i32 %.1 to i64, !dbg !199
  %71 = getelementptr inbounds double, double* getelementptr inbounds ([240 x double], [240 x double]* @stddev, i64 0, i64 0), i64 %70, !dbg !199
  store double %69, double* %71, align 8, !dbg !200
  %72 = sext i32 %.1 to i64, !dbg !201
  %73 = getelementptr inbounds double, double* getelementptr inbounds ([240 x double], [240 x double]* @stddev, i64 0, i64 0), i64 %72, !dbg !201
  %74 = load double, double* %73, align 8, !dbg !201
  %75 = fcmp ole double %74, 1.000000e-01, !dbg !202
  br i1 %75, label %76, label %77, !dbg !201

76:                                               ; preds = %61
  br label %81, !dbg !201

77:                                               ; preds = %61
  %78 = sext i32 %.1 to i64, !dbg !203
  %79 = getelementptr inbounds double, double* getelementptr inbounds ([240 x double], [240 x double]* @stddev, i64 0, i64 0), i64 %78, !dbg !203
  %80 = load double, double* %79, align 8, !dbg !203
  br label %81, !dbg !201

81:                                               ; preds = %77, %76
  %82 = phi double [ 1.000000e+00, %76 ], [ %80, %77 ], !dbg !201
  %83 = sext i32 %.1 to i64, !dbg !204
  %84 = getelementptr inbounds double, double* getelementptr inbounds ([240 x double], [240 x double]* @stddev, i64 0, i64 0), i64 %83, !dbg !204
  store double %82, double* %84, align 8, !dbg !205
  %85 = add nsw i32 %.1, 1, !dbg !206
  call void @llvm.dbg.value(metadata i32 %85, metadata !138, metadata !DIExpression()), !dbg !129
  br label %29, !dbg !207, !llvm.loop !208

86:                                               ; preds = %29
  call void @llvm.dbg.value(metadata i32 0, metadata !148, metadata !DIExpression()), !dbg !129
  br label %87, !dbg !210

87:                                               ; preds = %114, %86
  %.24 = phi i32 [ 0, %86 ], [ %115, %114 ], !dbg !212
  call void @llvm.dbg.value(metadata i32 %.24, metadata !148, metadata !DIExpression()), !dbg !129
  %88 = icmp slt i32 %.24, 260, !dbg !213
  br i1 %88, label %89, label %116, !dbg !215

89:                                               ; preds = %87
  call void @llvm.dbg.value(metadata i32 0, metadata !138, metadata !DIExpression()), !dbg !129
  br label %90, !dbg !216

90:                                               ; preds = %92, %89
  %.2 = phi i32 [ 0, %89 ], [ %113, %92 ], !dbg !218
  call void @llvm.dbg.value(metadata i32 %.2, metadata !138, metadata !DIExpression()), !dbg !129
  %91 = icmp slt i32 %.2, 240, !dbg !219
  br i1 %91, label %92, label %114, !dbg !221

92:                                               ; preds = %90
  %93 = sext i32 %.2 to i64, !dbg !222
  %94 = getelementptr inbounds double, double* getelementptr inbounds ([240 x double], [240 x double]* @mean, i64 0, i64 0), i64 %93, !dbg !222
  %95 = load double, double* %94, align 8, !dbg !222
  %96 = sext i32 %.24 to i64, !dbg !224
  %97 = getelementptr inbounds [240 x double], [240 x double]* getelementptr inbounds ([260 x [240 x double]], [260 x [240 x double]]* @data, i64 0, i64 0), i64 %96, !dbg !224
  %98 = sext i32 %.2 to i64, !dbg !224
  %99 = getelementptr inbounds [240 x double], [240 x double]* %97, i64 0, i64 %98, !dbg !224
  %100 = load double, double* %99, align 8, !dbg !225
  %101 = fsub double %100, %95, !dbg !225
  store double %101, double* %99, align 8, !dbg !225
  %102 = call double @sqrt(double noundef %3) #6, !dbg !226
  %103 = sext i32 %.2 to i64, !dbg !227
  %104 = getelementptr inbounds double, double* getelementptr inbounds ([240 x double], [240 x double]* @stddev, i64 0, i64 0), i64 %103, !dbg !227
  %105 = load double, double* %104, align 8, !dbg !227
  %106 = fmul double %102, %105, !dbg !228
  %107 = sext i32 %.24 to i64, !dbg !229
  %108 = getelementptr inbounds [240 x double], [240 x double]* getelementptr inbounds ([260 x [240 x double]], [260 x [240 x double]]* @data, i64 0, i64 0), i64 %107, !dbg !229
  %109 = sext i32 %.2 to i64, !dbg !229
  %110 = getelementptr inbounds [240 x double], [240 x double]* %108, i64 0, i64 %109, !dbg !229
  %111 = load double, double* %110, align 8, !dbg !230
  %112 = fdiv double %111, %106, !dbg !230
  store double %112, double* %110, align 8, !dbg !230
  %113 = add nsw i32 %.2, 1, !dbg !231
  call void @llvm.dbg.value(metadata i32 %113, metadata !138, metadata !DIExpression()), !dbg !129
  br label %90, !dbg !232, !llvm.loop !233

114:                                              ; preds = %90
  %115 = add nsw i32 %.24, 1, !dbg !235
  call void @llvm.dbg.value(metadata i32 %115, metadata !148, metadata !DIExpression()), !dbg !129
  br label %87, !dbg !236, !llvm.loop !237

116:                                              ; preds = %87
  call void @llvm.dbg.value(metadata i32 0, metadata !148, metadata !DIExpression()), !dbg !129
  br label %117, !dbg !239

117:                                              ; preds = %164, %116
  %.35 = phi i32 [ 0, %116 ], [ %165, %164 ], !dbg !241
  call void @llvm.dbg.value(metadata i32 %.35, metadata !148, metadata !DIExpression()), !dbg !129
  %118 = icmp slt i32 %.35, 239, !dbg !242
  br i1 %118, label %119, label %166, !dbg !244

119:                                              ; preds = %117
  %120 = sext i32 %.35 to i64, !dbg !245
  %121 = getelementptr inbounds [240 x double], [240 x double]* getelementptr inbounds ([240 x [240 x double]], [240 x [240 x double]]* @corr, i64 0, i64 0), i64 %120, !dbg !245
  %122 = sext i32 %.35 to i64, !dbg !245
  %123 = getelementptr inbounds [240 x double], [240 x double]* %121, i64 0, i64 %122, !dbg !245
  store double 1.000000e+00, double* %123, align 8, !dbg !247
  %124 = add nsw i32 %.35, 1, !dbg !248
  call void @llvm.dbg.value(metadata i32 %124, metadata !138, metadata !DIExpression()), !dbg !129
  br label %125, !dbg !250

125:                                              ; preds = %153, %119
  %.3 = phi i32 [ %124, %119 ], [ %163, %153 ], !dbg !251
  call void @llvm.dbg.value(metadata i32 %.3, metadata !138, metadata !DIExpression()), !dbg !129
  %126 = icmp slt i32 %.3, 240, !dbg !252
  br i1 %126, label %127, label %164, !dbg !254

127:                                              ; preds = %125
  %128 = sext i32 %.35 to i64, !dbg !255
  %129 = getelementptr inbounds [240 x double], [240 x double]* getelementptr inbounds ([240 x [240 x double]], [240 x [240 x double]]* @corr, i64 0, i64 0), i64 %128, !dbg !255
  %130 = sext i32 %.3 to i64, !dbg !255
  %131 = getelementptr inbounds [240 x double], [240 x double]* %129, i64 0, i64 %130, !dbg !255
  store double 0.000000e+00, double* %131, align 8, !dbg !257
  call void @llvm.dbg.value(metadata i32 0, metadata !258, metadata !DIExpression()), !dbg !129
  br label %132, !dbg !259

132:                                              ; preds = %134, %127
  %.0 = phi i32 [ 0, %127 ], [ %152, %134 ], !dbg !261
  call void @llvm.dbg.value(metadata i32 %.0, metadata !258, metadata !DIExpression()), !dbg !129
  %133 = icmp slt i32 %.0, 260, !dbg !262
  br i1 %133, label %134, label %153, !dbg !264

134:                                              ; preds = %132
  %135 = sext i32 %.0 to i64, !dbg !265
  %136 = getelementptr inbounds [240 x double], [240 x double]* getelementptr inbounds ([260 x [240 x double]], [260 x [240 x double]]* @data, i64 0, i64 0), i64 %135, !dbg !265
  %137 = sext i32 %.35 to i64, !dbg !265
  %138 = getelementptr inbounds [240 x double], [240 x double]* %136, i64 0, i64 %137, !dbg !265
  %139 = load double, double* %138, align 8, !dbg !265
  %140 = sext i32 %.0 to i64, !dbg !266
  %141 = getelementptr inbounds [240 x double], [240 x double]* getelementptr inbounds ([260 x [240 x double]], [260 x [240 x double]]* @data, i64 0, i64 0), i64 %140, !dbg !266
  %142 = sext i32 %.3 to i64, !dbg !266
  %143 = getelementptr inbounds [240 x double], [240 x double]* %141, i64 0, i64 %142, !dbg !266
  %144 = load double, double* %143, align 8, !dbg !266
  %145 = fmul double %139, %144, !dbg !267
  %146 = sext i32 %.35 to i64, !dbg !268
  %147 = getelementptr inbounds [240 x double], [240 x double]* getelementptr inbounds ([240 x [240 x double]], [240 x [240 x double]]* @corr, i64 0, i64 0), i64 %146, !dbg !268
  %148 = sext i32 %.3 to i64, !dbg !268
  %149 = getelementptr inbounds [240 x double], [240 x double]* %147, i64 0, i64 %148, !dbg !268
  %150 = load double, double* %149, align 8, !dbg !269
  %151 = fadd double %150, %145, !dbg !269
  store double %151, double* %149, align 8, !dbg !269
  %152 = add nsw i32 %.0, 1, !dbg !270
  call void @llvm.dbg.value(metadata i32 %152, metadata !258, metadata !DIExpression()), !dbg !129
  br label %132, !dbg !271, !llvm.loop !272

153:                                              ; preds = %132
  %154 = sext i32 %.35 to i64, !dbg !274
  %155 = getelementptr inbounds [240 x double], [240 x double]* getelementptr inbounds ([240 x [240 x double]], [240 x [240 x double]]* @corr, i64 0, i64 0), i64 %154, !dbg !274
  %156 = sext i32 %.3 to i64, !dbg !274
  %157 = getelementptr inbounds [240 x double], [240 x double]* %155, i64 0, i64 %156, !dbg !274
  %158 = load double, double* %157, align 8, !dbg !274
  %159 = sext i32 %.3 to i64, !dbg !275
  %160 = getelementptr inbounds [240 x double], [240 x double]* getelementptr inbounds ([240 x [240 x double]], [240 x [240 x double]]* @corr, i64 0, i64 0), i64 %159, !dbg !275
  %161 = sext i32 %.35 to i64, !dbg !275
  %162 = getelementptr inbounds [240 x double], [240 x double]* %160, i64 0, i64 %161, !dbg !275
  store double %158, double* %162, align 8, !dbg !276
  %163 = add nsw i32 %.3, 1, !dbg !277
  call void @llvm.dbg.value(metadata i32 %163, metadata !138, metadata !DIExpression()), !dbg !129
  br label %125, !dbg !278, !llvm.loop !279

164:                                              ; preds = %125
  %165 = add nsw i32 %.35, 1, !dbg !281
  call void @llvm.dbg.value(metadata i32 %165, metadata !148, metadata !DIExpression()), !dbg !129
  br label %117, !dbg !282, !llvm.loop !283

166:                                              ; preds = %117
  %167 = getelementptr inbounds [240 x double], [240 x double]* getelementptr inbounds ([240 x [240 x double]], [240 x [240 x double]]* @corr, i64 0, i64 0), i64 239, !dbg !285
  %168 = getelementptr inbounds [240 x double], [240 x double]* %167, i64 0, i64 239, !dbg !285
  store double 1.000000e+00, double* %168, align 8, !dbg !286
  ret i32 0, !dbg !287
}

; Function Attrs: noinline nounwind uwtable
define dso_local i32 @workload_checksum(i32 noundef %0) #0 !dbg !288 {
  call void @llvm.dbg.value(metadata i32 %0, metadata !291, metadata !DIExpression()), !dbg !292
  store i32 -2128831035, i32* @pb_hash, align 4, !dbg !293
  %2 = load i32, i32* @m, align 4, !dbg !294
  call void @print_array(i32 noundef %2, [240 x double]* noundef getelementptr inbounds ([240 x [240 x double]], [240 x [240 x double]]* @corr, i64 0, i64 0)), !dbg !295
  %3 = load i32, i32* @pb_hash, align 4, !dbg !296
  ret i32 %3, !dbg !297
}

; Function Attrs: noinline nounwind uwtable
define internal void @print_array(i32 noundef %0, [240 x double]* noundef %1) #0 !dbg !298 {
  call void @llvm.dbg.value(metadata i32 %0, metadata !301, metadata !DIExpression()), !dbg !302
  call void @llvm.dbg.value(metadata [240 x double]* %1, metadata !303, metadata !DIExpression()), !dbg !302
  %3 = load %struct._IO_FILE*, %struct._IO_FILE** @stderr, align 8, !dbg !304
  %4 = call i32 (%struct._IO_FILE*, i8*, ...) @pb_fprintf(%struct._IO_FILE* noundef %3, i8* noundef getelementptr inbounds ([23 x i8], [23 x i8]* @.str.2, i64 0, i64 0)), !dbg !304
  %5 = load %struct._IO_FILE*, %struct._IO_FILE** @stderr, align 8, !dbg !305
  %6 = call i32 (%struct._IO_FILE*, i8*, ...) @pb_fprintf(%struct._IO_FILE* noundef %5, i8* noundef getelementptr inbounds ([15 x i8], [15 x i8]* @.str.3, i64 0, i64 0), i8* noundef getelementptr inbounds ([5 x i8], [5 x i8]* @.str.4, i64 0, i64 0)), !dbg !305
  call void @llvm.dbg.value(metadata i32 0, metadata !306, metadata !DIExpression()), !dbg !302
  br label %7, !dbg !307

7:                                                ; preds = %31, %2
  %.01 = phi i32 [ 0, %2 ], [ %32, %31 ], !dbg !309
  call void @llvm.dbg.value(metadata i32 %.01, metadata !306, metadata !DIExpression()), !dbg !302
  %8 = icmp slt i32 %.01, %0, !dbg !310
  br i1 %8, label %9, label %33, !dbg !312

9:                                                ; preds = %7
  call void @llvm.dbg.value(metadata i32 0, metadata !313, metadata !DIExpression()), !dbg !302
  br label %10, !dbg !314

10:                                               ; preds = %28, %9
  %.0 = phi i32 [ 0, %9 ], [ %29, %28 ], !dbg !316
  call void @llvm.dbg.value(metadata i32 %.0, metadata !313, metadata !DIExpression()), !dbg !302
  %11 = icmp slt i32 %.0, %0, !dbg !317
  br i1 %11, label %12, label %30, !dbg !319

12:                                               ; preds = %10
  %13 = mul nsw i32 %.01, %0, !dbg !320
  %14 = add nsw i32 %13, %.0, !dbg !323
  %15 = srem i32 %14, 20, !dbg !324
  %16 = icmp eq i32 %15, 0, !dbg !325
  br i1 %16, label %17, label %20, !dbg !326

17:                                               ; preds = %12
  %18 = load %struct._IO_FILE*, %struct._IO_FILE** @stderr, align 8, !dbg !327
  %19 = call i32 (%struct._IO_FILE*, i8*, ...) @pb_fprintf(%struct._IO_FILE* noundef %18, i8* noundef getelementptr inbounds ([2 x i8], [2 x i8]* @.str.5, i64 0, i64 0)), !dbg !328
  br label %20, !dbg !328

20:                                               ; preds = %17, %12
  %21 = load %struct._IO_FILE*, %struct._IO_FILE** @stderr, align 8, !dbg !329
  %22 = sext i32 %.01 to i64, !dbg !330
  %23 = getelementptr inbounds [240 x double], [240 x double]* %1, i64 %22, !dbg !330
  %24 = sext i32 %.0 to i64, !dbg !330
  %25 = getelementptr inbounds [240 x double], [240 x double]* %23, i64 0, i64 %24, !dbg !330
  %26 = load double, double* %25, align 8, !dbg !330
  %27 = call i32 (%struct._IO_FILE*, i8*, ...) @pb_fprintf(%struct._IO_FILE* noundef %21, i8* noundef getelementptr inbounds ([8 x i8], [8 x i8]* @.str.6, i64 0, i64 0), double noundef %26), !dbg !331
  br label %28, !dbg !332

28:                                               ; preds = %20
  %29 = add nsw i32 %.0, 1, !dbg !333
  call void @llvm.dbg.value(metadata i32 %29, metadata !313, metadata !DIExpression()), !dbg !302
  br label %10, !dbg !334, !llvm.loop !335

30:                                               ; preds = %10
  br label %31, !dbg !336

31:                                               ; preds = %30
  %32 = add nsw i32 %.01, 1, !dbg !337
  call void @llvm.dbg.value(metadata i32 %32, metadata !306, metadata !DIExpression()), !dbg !302
  br label %7, !dbg !338, !llvm.loop !339

33:                                               ; preds = %7
  %34 = load %struct._IO_FILE*, %struct._IO_FILE** @stderr, align 8, !dbg !341
  %35 = call i32 (%struct._IO_FILE*, i8*, ...) @pb_fprintf(%struct._IO_FILE* noundef %34, i8* noundef getelementptr inbounds ([17 x i8], [17 x i8]* @.str.7, i64 0, i64 0), i8* noundef getelementptr inbounds ([5 x i8], [5 x i8]* @.str.4, i64 0, i64 0)), !dbg !341
  %36 = load %struct._IO_FILE*, %struct._IO_FILE** @stderr, align 8, !dbg !342
  %37 = call i32 (%struct._IO_FILE*, i8*, ...) @pb_fprintf(%struct._IO_FILE* noundef %36, i8* noundef getelementptr inbounds ([23 x i8], [23 x i8]* @.str.8, i64 0, i64 0)), !dbg !342
  ret void, !dbg !343
}

; Function Attrs: nounwind
declare double @sqrt(double noundef) #3

; Function Attrs: noinline nounwind uwtable
define internal i32 @pb_fprintf(%struct._IO_FILE* noundef %0, i8* noundef %1, ...) #0 !dbg !344 {
  %3 = alloca [768 x i8], align 16
  %4 = alloca [1 x %struct.__va_list_tag], align 16
  call void @llvm.dbg.value(metadata %struct._IO_FILE* %0, metadata !408, metadata !DIExpression()), !dbg !409
  call void @llvm.dbg.value(metadata i8* %1, metadata !410, metadata !DIExpression()), !dbg !409
  call void @llvm.dbg.declare(metadata [768 x i8]* %3, metadata !411, metadata !DIExpression()), !dbg !415
  call void @llvm.dbg.declare(metadata [1 x %struct.__va_list_tag]* %4, metadata !416, metadata !DIExpression()), !dbg !430
  %5 = getelementptr inbounds [1 x %struct.__va_list_tag], [1 x %struct.__va_list_tag]* %4, i64 0, i64 0, !dbg !431
  %6 = bitcast %struct.__va_list_tag* %5 to i8*, !dbg !431
  call void @llvm.va_start(i8* %6), !dbg !431
  %7 = getelementptr inbounds [768 x i8], [768 x i8]* %3, i64 0, i64 0, !dbg !432
  %8 = getelementptr inbounds [1 x %struct.__va_list_tag], [1 x %struct.__va_list_tag]* %4, i64 0, i64 0, !dbg !433
  %9 = call i32 @vsnprintf(i8* noundef %7, i64 noundef 768, i8* noundef %1, %struct.__va_list_tag* noundef %8) #6, !dbg !434
  call void @llvm.dbg.value(metadata i32 %9, metadata !435, metadata !DIExpression()), !dbg !409
  %10 = getelementptr inbounds [1 x %struct.__va_list_tag], [1 x %struct.__va_list_tag]* %4, i64 0, i64 0, !dbg !436
  %11 = bitcast %struct.__va_list_tag* %10 to i8*, !dbg !436
  call void @llvm.va_end(i8* %11), !dbg !436
  %12 = icmp slt i32 %9, 0, !dbg !437
  br i1 %12, label %16, label %13, !dbg !439

13:                                               ; preds = %2
  %14 = zext i32 %9 to i64, !dbg !440
  %15 = icmp uge i64 %14, 768, !dbg !441
  br i1 %15, label %16, label %17, !dbg !442

16:                                               ; preds = %13, %2
  call void @abort() #7, !dbg !443
  unreachable, !dbg !443

17:                                               ; preds = %13
  call void @llvm.dbg.value(metadata i32 0, metadata !444, metadata !DIExpression()), !dbg !446
  br label %18, !dbg !447

18:                                               ; preds = %29, %17
  %.0 = phi i32 [ 0, %17 ], [ %30, %29 ], !dbg !446
  call void @llvm.dbg.value(metadata i32 %.0, metadata !444, metadata !DIExpression()), !dbg !446
  %19 = icmp slt i32 %.0, %9, !dbg !448
  br i1 %19, label %20, label %31, !dbg !450

20:                                               ; preds = %18
  %21 = sext i32 %.0 to i64, !dbg !451
  %22 = getelementptr inbounds [768 x i8], [768 x i8]* %3, i64 0, i64 %21, !dbg !451
  %23 = load i8, i8* %22, align 1, !dbg !451
  %24 = zext i8 %23 to i32, !dbg !453
  %25 = load i32, i32* @pb_hash, align 4, !dbg !454
  %26 = xor i32 %25, %24, !dbg !454
  store i32 %26, i32* @pb_hash, align 4, !dbg !454
  %27 = load i32, i32* @pb_hash, align 4, !dbg !455
  %28 = mul i32 %27, 16777619, !dbg !455
  store i32 %28, i32* @pb_hash, align 4, !dbg !455
  br label %29, !dbg !456

29:                                               ; preds = %20
  %30 = add nsw i32 %.0, 1, !dbg !457
  call void @llvm.dbg.value(metadata i32 %30, metadata !444, metadata !DIExpression()), !dbg !446
  br label %18, !dbg !458, !llvm.loop !459

31:                                               ; preds = %18
  %32 = load i32, i32* @pb_emit, align 4, !dbg !461
  ret i32 %9, !dbg !462
}

; Function Attrs: nofree nosync nounwind willreturn
declare void @llvm.va_start(i8*) #4

; Function Attrs: nounwind
declare i32 @vsnprintf(i8* noundef, i64 noundef, i8* noundef, %struct.__va_list_tag* noundef) #3

; Function Attrs: nofree nosync nounwind willreturn
declare void @llvm.va_end(i8*) #4

; Function Attrs: noreturn nounwind
declare void @abort() #5

; Function Attrs: nofree nosync nounwind readnone speculatable willreturn
declare void @llvm.dbg.value(metadata, metadata, metadata) #1

attributes #0 = { noinline nounwind uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { nofree nosync nounwind readnone speculatable willreturn }
attributes #2 = { argmemonly nofree nounwind willreturn writeonly }
attributes #3 = { nounwind "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #4 = { nofree nosync nounwind willreturn }
attributes #5 = { noreturn nounwind "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #6 = { nounwind }
attributes #7 = { noreturn nounwind }

!llvm.dbg.cu = !{!2}
!llvm.module.flags = !{!53, !54, !55, !56, !57, !58, !59}
!llvm.ident = !{!60}

!0 = !DIGlobalVariableExpression(var: !1, expr: !DIExpression())
!1 = distinct !DIGlobalVariable(name: "n", scope: !2, file: !11, line: 141, type: !12, isLocal: false, isDefinition: true)
!2 = distinct !DICompileUnit(language: DW_LANG_C99, file: !3, producer: "Ubuntu clang version 14.0.0-1ubuntu1.1", isOptimized: false, runtimeVersion: 0, emissionKind: FullDebug, retainedTypes: !4, globals: !8, splitDebugInlining: false, nameTableKind: None)
!3 = !DIFile(filename: "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/triangular-20260929/suite/correlation/source/workload.c", directory: "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/triangular-20260929/suite/correlation/analysis-native", checksumkind: CSK_MD5, checksum: "538f08005fb9f6d535ce0d8ee9534765")
!4 = !{!5, !6, !7}
!5 = !DIBasicType(name: "double", size: 64, encoding: DW_ATE_float)
!6 = !DIBasicType(name: "unsigned int", size: 32, encoding: DW_ATE_unsigned)
!7 = !DIBasicType(name: "unsigned char", size: 8, encoding: DW_ATE_unsigned_char)
!8 = !{!0, !9, !13, !26, !30, !33, !39, !43, !47, !49, !51}
!9 = !DIGlobalVariableExpression(var: !10, expr: !DIExpression())
!10 = distinct !DIGlobalVariable(name: "m", scope: !2, file: !11, line: 142, type: !12, isLocal: false, isDefinition: true)
!11 = !DIFile(filename: "source/workload.c", directory: "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/triangular-20260929/suite/correlation", checksumkind: CSK_MD5, checksum: "538f08005fb9f6d535ce0d8ee9534765")
!12 = !DIBasicType(name: "int", size: 32, encoding: DW_ATE_signed)
!13 = !DIGlobalVariableExpression(var: !14, expr: !DIExpression())
!14 = distinct !DIGlobalVariable(name: "workload_jobs", scope: !2, file: !11, line: 169, type: !15, isLocal: false, isDefinition: true)
!15 = !DICompositeType(tag: DW_TAG_array_type, baseType: !16, size: 64, elements: !24)
!16 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !17)
!17 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !18, size: 64)
!18 = !DISubroutineType(types: !19)
!19 = !{!20}
!20 = !DIDerivedType(tag: DW_TAG_typedef, name: "uint32_t", file: !21, line: 26, baseType: !22)
!21 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/stdint-uintn.h", directory: "", checksumkind: CSK_MD5, checksum: "2bf2ae53c58c01b1a1b9383b5195125c")
!22 = !DIDerivedType(tag: DW_TAG_typedef, name: "__uint32_t", file: !23, line: 42, baseType: !6)
!23 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/types.h", directory: "", checksumkind: CSK_MD5, checksum: "d108b5f93a74c50510d7d9bc0ab36df9")
!24 = !{!25}
!25 = !DISubrange(count: 1)
!26 = !DIGlobalVariableExpression(var: !27, expr: !DIExpression())
!27 = distinct !DIGlobalVariable(name: "workload_expected", scope: !2, file: !11, line: 173, type: !28, isLocal: false, isDefinition: true)
!28 = !DICompositeType(tag: DW_TAG_array_type, baseType: !29, size: 32, elements: !24)
!29 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !20)
!30 = !DIGlobalVariableExpression(var: !31, expr: !DIExpression())
!31 = distinct !DIGlobalVariable(name: "pb_hash", scope: !2, file: !32, line: 9, type: !20, isLocal: true, isDefinition: true)
!32 = !DIFile(filename: "source/adapter.h", directory: "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/triangular-20260929/suite/correlation", checksumkind: CSK_MD5, checksum: "26a6068928b2092758f244a9d00163d7")
!33 = !DIGlobalVariableExpression(var: !34, expr: !DIExpression())
!34 = distinct !DIGlobalVariable(name: "data", scope: !2, file: !11, line: 34, type: !35, isLocal: false, isDefinition: true, align: 512)
!35 = !DICompositeType(tag: DW_TAG_array_type, baseType: !5, size: 3993600, elements: !36)
!36 = !{!37, !38}
!37 = !DISubrange(count: 260)
!38 = !DISubrange(count: 240)
!39 = !DIGlobalVariableExpression(var: !40, expr: !DIExpression())
!40 = distinct !DIGlobalVariable(name: "corr", scope: !2, file: !11, line: 35, type: !41, isLocal: false, isDefinition: true, align: 512)
!41 = !DICompositeType(tag: DW_TAG_array_type, baseType: !5, size: 3686400, elements: !42)
!42 = !{!38, !38}
!43 = !DIGlobalVariableExpression(var: !44, expr: !DIExpression())
!44 = distinct !DIGlobalVariable(name: "mean", scope: !2, file: !11, line: 36, type: !45, isLocal: false, isDefinition: true, align: 512)
!45 = !DICompositeType(tag: DW_TAG_array_type, baseType: !5, size: 15360, elements: !46)
!46 = !{!38}
!47 = !DIGlobalVariableExpression(var: !48, expr: !DIExpression())
!48 = distinct !DIGlobalVariable(name: "stddev", scope: !2, file: !11, line: 37, type: !45, isLocal: false, isDefinition: true, align: 512)
!49 = !DIGlobalVariableExpression(var: !50, expr: !DIExpression())
!50 = distinct !DIGlobalVariable(name: "float_n", scope: !2, file: !11, line: 145, type: !5, isLocal: false, isDefinition: true)
!51 = !DIGlobalVariableExpression(var: !52, expr: !DIExpression())
!52 = distinct !DIGlobalVariable(name: "pb_emit", scope: !2, file: !32, line: 10, type: !12, isLocal: true, isDefinition: true)
!53 = !{i32 7, !"Dwarf Version", i32 5}
!54 = !{i32 2, !"Debug Info Version", i32 3}
!55 = !{i32 1, !"wchar_size", i32 4}
!56 = !{i32 7, !"PIC Level", i32 2}
!57 = !{i32 7, !"PIE Level", i32 2}
!58 = !{i32 7, !"uwtable", i32 1}
!59 = !{i32 7, !"frame-pointer", i32 2}
!60 = !{!"Ubuntu clang version 14.0.0-1ubuntu1.1"}
!61 = distinct !DISubprogram(name: "workload_prepare", scope: !11, file: !11, line: 146, type: !62, scopeLine: 146, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !2, retainedNodes: !64)
!62 = !DISubroutineType(types: !63)
!63 = !{null}
!64 = !{}
!65 = !DILocation(line: 146, column: 30, scope: !61)
!66 = distinct !DISubprogram(name: "workload_reset", scope: !11, file: !11, line: 147, type: !67, scopeLine: 147, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !2, retainedNodes: !64)
!67 = !DISubroutineType(types: !68)
!68 = !{null, !6}
!69 = !DILocalVariable(name: "task", arg: 1, scope: !66, file: !11, line: 147, type: !6)
!70 = !DILocation(line: 0, scope: !66)
!71 = !DILocation(line: 149, column: 3, scope: !66)
!72 = !DILocation(line: 150, column: 3, scope: !66)
!73 = !DILocation(line: 151, column: 3, scope: !66)
!74 = !DILocation(line: 152, column: 3, scope: !66)
!75 = !DILocation(line: 153, column: 15, scope: !66)
!76 = !DILocation(line: 153, column: 18, scope: !66)
!77 = !DILocation(line: 153, column: 3, scope: !66)
!78 = !DILocation(line: 154, column: 1, scope: !66)
!79 = distinct !DISubprogram(name: "init_array", scope: !11, file: !11, line: 39, type: !80, scopeLine: 43, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition, unit: !2, retainedNodes: !64)
!80 = !DISubroutineType(types: !81)
!81 = !{null, !12, !12, !82, !83}
!82 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !5, size: 64)
!83 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !45, size: 64)
!84 = !DILocalVariable(name: "m", arg: 1, scope: !79, file: !11, line: 39, type: !12)
!85 = !DILocation(line: 0, scope: !79)
!86 = !DILocalVariable(name: "n", arg: 2, scope: !79, file: !11, line: 40, type: !12)
!87 = !DILocalVariable(name: "float_n", arg: 3, scope: !79, file: !11, line: 41, type: !82)
!88 = !DILocalVariable(name: "data", arg: 4, scope: !79, file: !11, line: 42, type: !83)
!89 = !DILocation(line: 46, column: 12, scope: !79)
!90 = !DILocalVariable(name: "i", scope: !79, file: !11, line: 44, type: !12)
!91 = !DILocation(line: 48, column: 8, scope: !92)
!92 = distinct !DILexicalBlock(scope: !79, file: !11, line: 48, column: 3)
!93 = !DILocation(line: 0, scope: !92)
!94 = !DILocation(line: 48, column: 17, scope: !95)
!95 = distinct !DILexicalBlock(scope: !92, file: !11, line: 48, column: 3)
!96 = !DILocation(line: 48, column: 3, scope: !92)
!97 = !DILocalVariable(name: "j", scope: !79, file: !11, line: 44, type: !12)
!98 = !DILocation(line: 49, column: 10, scope: !99)
!99 = distinct !DILexicalBlock(scope: !95, file: !11, line: 49, column: 5)
!100 = !DILocation(line: 0, scope: !99)
!101 = !DILocation(line: 49, column: 19, scope: !102)
!102 = distinct !DILexicalBlock(scope: !99, file: !11, line: 49, column: 5)
!103 = !DILocation(line: 49, column: 5, scope: !99)
!104 = !DILocation(line: 50, column: 33, scope: !102)
!105 = !DILocation(line: 50, column: 20, scope: !102)
!106 = !DILocation(line: 50, column: 36, scope: !102)
!107 = !DILocation(line: 50, column: 41, scope: !102)
!108 = !DILocation(line: 50, column: 39, scope: !102)
!109 = !DILocation(line: 50, column: 7, scope: !102)
!110 = !DILocation(line: 50, column: 18, scope: !102)
!111 = !DILocation(line: 49, column: 25, scope: !102)
!112 = !DILocation(line: 49, column: 5, scope: !102)
!113 = distinct !{!113, !103, !114, !115}
!114 = !DILocation(line: 50, column: 41, scope: !99)
!115 = !{!"llvm.loop.mustprogress"}
!116 = !DILocation(line: 48, column: 23, scope: !95)
!117 = !DILocation(line: 48, column: 3, scope: !95)
!118 = distinct !{!118, !96, !119, !115}
!119 = !DILocation(line: 50, column: 41, scope: !92)
!120 = !DILocation(line: 52, column: 1, scope: !79)
!121 = distinct !DISubprogram(name: "task_job_polybench", scope: !11, file: !11, line: 155, type: !18, scopeLine: 155, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !2, retainedNodes: !64)
!122 = !DILocation(line: 156, column: 23, scope: !121)
!123 = !DILocation(line: 156, column: 26, scope: !121)
!124 = !DILocation(line: 156, column: 29, scope: !121)
!125 = !DILocalVariable(name: "m", arg: 1, scope: !126, file: !11, line: 79, type: !12)
!126 = distinct !DISubprogram(name: "kernel_correlation", scope: !11, file: !11, line: 79, type: !127, scopeLine: 85, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition, unit: !2, retainedNodes: !64)
!127 = !DISubroutineType(types: !128)
!128 = !{null, !12, !12, !5, !83, !83, !82, !82}
!129 = !DILocation(line: 0, scope: !126, inlinedAt: !130)
!130 = distinct !DILocation(line: 156, column: 3, scope: !121)
!131 = !DILocalVariable(name: "n", arg: 2, scope: !126, file: !11, line: 79, type: !12)
!132 = !DILocalVariable(name: "float_n", arg: 3, scope: !126, file: !11, line: 80, type: !5)
!133 = !DILocalVariable(name: "data", arg: 4, scope: !126, file: !11, line: 81, type: !83)
!134 = !DILocalVariable(name: "corr", arg: 5, scope: !126, file: !11, line: 82, type: !83)
!135 = !DILocalVariable(name: "mean", arg: 6, scope: !126, file: !11, line: 83, type: !82)
!136 = !DILocalVariable(name: "stddev", arg: 7, scope: !126, file: !11, line: 84, type: !82)
!137 = !DILocalVariable(name: "eps", scope: !126, file: !11, line: 88, type: !5)
!138 = !DILocalVariable(name: "j", scope: !126, file: !11, line: 86, type: !12)
!139 = !DILocation(line: 92, column: 8, scope: !140, inlinedAt: !130)
!140 = distinct !DILexicalBlock(scope: !126, file: !11, line: 92, column: 3)
!141 = !DILocation(line: 0, scope: !140, inlinedAt: !130)
!142 = !DILocation(line: 92, column: 17, scope: !143, inlinedAt: !130)
!143 = distinct !DILexicalBlock(scope: !140, file: !11, line: 92, column: 3)
!144 = !DILocation(line: 92, column: 3, scope: !140, inlinedAt: !130)
!145 = !DILocation(line: 94, column: 7, scope: !146, inlinedAt: !130)
!146 = distinct !DILexicalBlock(scope: !143, file: !11, line: 93, column: 5)
!147 = !DILocation(line: 94, column: 15, scope: !146, inlinedAt: !130)
!148 = !DILocalVariable(name: "i", scope: !126, file: !11, line: 86, type: !12)
!149 = !DILocation(line: 95, column: 12, scope: !150, inlinedAt: !130)
!150 = distinct !DILexicalBlock(scope: !146, file: !11, line: 95, column: 7)
!151 = !DILocation(line: 0, scope: !150, inlinedAt: !130)
!152 = !DILocation(line: 95, column: 21, scope: !153, inlinedAt: !130)
!153 = distinct !DILexicalBlock(scope: !150, file: !11, line: 95, column: 7)
!154 = !DILocation(line: 95, column: 7, scope: !150, inlinedAt: !130)
!155 = !DILocation(line: 96, column: 13, scope: !153, inlinedAt: !130)
!156 = !DILocation(line: 96, column: 2, scope: !153, inlinedAt: !130)
!157 = !DILocation(line: 96, column: 10, scope: !153, inlinedAt: !130)
!158 = !DILocation(line: 95, column: 31, scope: !153, inlinedAt: !130)
!159 = !DILocation(line: 95, column: 7, scope: !153, inlinedAt: !130)
!160 = distinct !{!160, !154, !161, !115}
!161 = !DILocation(line: 96, column: 22, scope: !150, inlinedAt: !130)
!162 = !DILocation(line: 97, column: 7, scope: !146, inlinedAt: !130)
!163 = !DILocation(line: 97, column: 15, scope: !146, inlinedAt: !130)
!164 = !DILocation(line: 92, column: 27, scope: !143, inlinedAt: !130)
!165 = !DILocation(line: 92, column: 3, scope: !143, inlinedAt: !130)
!166 = distinct !{!166, !144, !167, !115}
!167 = !DILocation(line: 98, column: 5, scope: !140, inlinedAt: !130)
!168 = !DILocation(line: 101, column: 9, scope: !169, inlinedAt: !130)
!169 = distinct !DILexicalBlock(scope: !126, file: !11, line: 101, column: 4)
!170 = !DILocation(line: 0, scope: !169, inlinedAt: !130)
!171 = !DILocation(line: 101, column: 18, scope: !172, inlinedAt: !130)
!172 = distinct !DILexicalBlock(scope: !169, file: !11, line: 101, column: 4)
!173 = !DILocation(line: 101, column: 4, scope: !169, inlinedAt: !130)
!174 = !DILocation(line: 103, column: 7, scope: !175, inlinedAt: !130)
!175 = distinct !DILexicalBlock(scope: !172, file: !11, line: 102, column: 5)
!176 = !DILocation(line: 103, column: 17, scope: !175, inlinedAt: !130)
!177 = !DILocation(line: 104, column: 12, scope: !178, inlinedAt: !130)
!178 = distinct !DILexicalBlock(scope: !175, file: !11, line: 104, column: 7)
!179 = !DILocation(line: 0, scope: !178, inlinedAt: !130)
!180 = !DILocation(line: 104, column: 21, scope: !181, inlinedAt: !130)
!181 = distinct !DILexicalBlock(scope: !178, file: !11, line: 104, column: 7)
!182 = !DILocation(line: 104, column: 7, scope: !178, inlinedAt: !130)
!183 = !DILocation(line: 105, column: 23, scope: !181, inlinedAt: !130)
!184 = !DILocation(line: 105, column: 36, scope: !181, inlinedAt: !130)
!185 = !DILocation(line: 105, column: 34, scope: !181, inlinedAt: !130)
!186 = !DILocation(line: 105, column: 48, scope: !181, inlinedAt: !130)
!187 = !DILocation(line: 105, column: 61, scope: !181, inlinedAt: !130)
!188 = !DILocation(line: 105, column: 59, scope: !181, inlinedAt: !130)
!189 = !DILocation(line: 105, column: 45, scope: !181, inlinedAt: !130)
!190 = !DILocation(line: 105, column: 9, scope: !181, inlinedAt: !130)
!191 = !DILocation(line: 105, column: 19, scope: !181, inlinedAt: !130)
!192 = !DILocation(line: 104, column: 31, scope: !181, inlinedAt: !130)
!193 = !DILocation(line: 104, column: 7, scope: !181, inlinedAt: !130)
!194 = distinct !{!194, !182, !195, !115}
!195 = !DILocation(line: 105, column: 68, scope: !178, inlinedAt: !130)
!196 = !DILocation(line: 106, column: 7, scope: !175, inlinedAt: !130)
!197 = !DILocation(line: 106, column: 17, scope: !175, inlinedAt: !130)
!198 = !DILocation(line: 107, column: 19, scope: !175, inlinedAt: !130)
!199 = !DILocation(line: 107, column: 7, scope: !175, inlinedAt: !130)
!200 = !DILocation(line: 107, column: 17, scope: !175, inlinedAt: !130)
!201 = !DILocation(line: 111, column: 19, scope: !175, inlinedAt: !130)
!202 = !DILocation(line: 111, column: 29, scope: !175, inlinedAt: !130)
!203 = !DILocation(line: 111, column: 56, scope: !175, inlinedAt: !130)
!204 = !DILocation(line: 111, column: 7, scope: !175, inlinedAt: !130)
!205 = !DILocation(line: 111, column: 17, scope: !175, inlinedAt: !130)
!206 = !DILocation(line: 101, column: 28, scope: !172, inlinedAt: !130)
!207 = !DILocation(line: 101, column: 4, scope: !172, inlinedAt: !130)
!208 = distinct !{!208, !173, !209, !115}
!209 = !DILocation(line: 112, column: 5, scope: !169, inlinedAt: !130)
!210 = !DILocation(line: 115, column: 8, scope: !211, inlinedAt: !130)
!211 = distinct !DILexicalBlock(scope: !126, file: !11, line: 115, column: 3)
!212 = !DILocation(line: 0, scope: !211, inlinedAt: !130)
!213 = !DILocation(line: 115, column: 17, scope: !214, inlinedAt: !130)
!214 = distinct !DILexicalBlock(scope: !211, file: !11, line: 115, column: 3)
!215 = !DILocation(line: 115, column: 3, scope: !211, inlinedAt: !130)
!216 = !DILocation(line: 116, column: 10, scope: !217, inlinedAt: !130)
!217 = distinct !DILexicalBlock(scope: !214, file: !11, line: 116, column: 5)
!218 = !DILocation(line: 0, scope: !217, inlinedAt: !130)
!219 = !DILocation(line: 116, column: 19, scope: !220, inlinedAt: !130)
!220 = distinct !DILexicalBlock(scope: !217, file: !11, line: 116, column: 5)
!221 = !DILocation(line: 116, column: 5, scope: !217, inlinedAt: !130)
!222 = !DILocation(line: 118, column: 23, scope: !223, inlinedAt: !130)
!223 = distinct !DILexicalBlock(scope: !220, file: !11, line: 117, column: 7)
!224 = !DILocation(line: 118, column: 9, scope: !223, inlinedAt: !130)
!225 = !DILocation(line: 118, column: 20, scope: !223, inlinedAt: !130)
!226 = !DILocation(line: 119, column: 23, scope: !223, inlinedAt: !130)
!227 = !DILocation(line: 119, column: 43, scope: !223, inlinedAt: !130)
!228 = !DILocation(line: 119, column: 41, scope: !223, inlinedAt: !130)
!229 = !DILocation(line: 119, column: 9, scope: !223, inlinedAt: !130)
!230 = !DILocation(line: 119, column: 20, scope: !223, inlinedAt: !130)
!231 = !DILocation(line: 116, column: 29, scope: !220, inlinedAt: !130)
!232 = !DILocation(line: 116, column: 5, scope: !220, inlinedAt: !130)
!233 = distinct !{!233, !221, !234, !115}
!234 = !DILocation(line: 120, column: 7, scope: !217, inlinedAt: !130)
!235 = !DILocation(line: 115, column: 27, scope: !214, inlinedAt: !130)
!236 = !DILocation(line: 115, column: 3, scope: !214, inlinedAt: !130)
!237 = distinct !{!237, !215, !238, !115}
!238 = !DILocation(line: 120, column: 7, scope: !211, inlinedAt: !130)
!239 = !DILocation(line: 123, column: 8, scope: !240, inlinedAt: !130)
!240 = distinct !DILexicalBlock(scope: !126, file: !11, line: 123, column: 3)
!241 = !DILocation(line: 0, scope: !240, inlinedAt: !130)
!242 = !DILocation(line: 123, column: 17, scope: !243, inlinedAt: !130)
!243 = distinct !DILexicalBlock(scope: !240, file: !11, line: 123, column: 3)
!244 = !DILocation(line: 123, column: 3, scope: !240, inlinedAt: !130)
!245 = !DILocation(line: 125, column: 7, scope: !246, inlinedAt: !130)
!246 = distinct !DILexicalBlock(scope: !243, file: !11, line: 124, column: 5)
!247 = !DILocation(line: 125, column: 18, scope: !246, inlinedAt: !130)
!248 = !DILocation(line: 126, column: 17, scope: !249, inlinedAt: !130)
!249 = distinct !DILexicalBlock(scope: !246, file: !11, line: 126, column: 7)
!250 = !DILocation(line: 126, column: 12, scope: !249, inlinedAt: !130)
!251 = !DILocation(line: 0, scope: !249, inlinedAt: !130)
!252 = !DILocation(line: 126, column: 23, scope: !253, inlinedAt: !130)
!253 = distinct !DILexicalBlock(scope: !249, file: !11, line: 126, column: 7)
!254 = !DILocation(line: 126, column: 7, scope: !249, inlinedAt: !130)
!255 = !DILocation(line: 128, column: 11, scope: !256, inlinedAt: !130)
!256 = distinct !DILexicalBlock(scope: !253, file: !11, line: 127, column: 9)
!257 = !DILocation(line: 128, column: 22, scope: !256, inlinedAt: !130)
!258 = !DILocalVariable(name: "k", scope: !126, file: !11, line: 86, type: !12)
!259 = !DILocation(line: 129, column: 16, scope: !260, inlinedAt: !130)
!260 = distinct !DILexicalBlock(scope: !256, file: !11, line: 129, column: 11)
!261 = !DILocation(line: 0, scope: !260, inlinedAt: !130)
!262 = !DILocation(line: 129, column: 25, scope: !263, inlinedAt: !130)
!263 = distinct !DILexicalBlock(scope: !260, file: !11, line: 129, column: 11)
!264 = !DILocation(line: 129, column: 11, scope: !260, inlinedAt: !130)
!265 = !DILocation(line: 130, column: 28, scope: !263, inlinedAt: !130)
!266 = !DILocation(line: 130, column: 41, scope: !263, inlinedAt: !130)
!267 = !DILocation(line: 130, column: 39, scope: !263, inlinedAt: !130)
!268 = !DILocation(line: 130, column: 13, scope: !263, inlinedAt: !130)
!269 = !DILocation(line: 130, column: 24, scope: !263, inlinedAt: !130)
!270 = !DILocation(line: 129, column: 35, scope: !263, inlinedAt: !130)
!271 = !DILocation(line: 129, column: 11, scope: !263, inlinedAt: !130)
!272 = distinct !{!272, !264, !273, !115}
!273 = !DILocation(line: 130, column: 51, scope: !260, inlinedAt: !130)
!274 = !DILocation(line: 131, column: 24, scope: !256, inlinedAt: !130)
!275 = !DILocation(line: 131, column: 11, scope: !256, inlinedAt: !130)
!276 = !DILocation(line: 131, column: 22, scope: !256, inlinedAt: !130)
!277 = !DILocation(line: 126, column: 33, scope: !253, inlinedAt: !130)
!278 = !DILocation(line: 126, column: 7, scope: !253, inlinedAt: !130)
!279 = distinct !{!279, !254, !280, !115}
!280 = !DILocation(line: 132, column: 9, scope: !249, inlinedAt: !130)
!281 = !DILocation(line: 123, column: 29, scope: !243, inlinedAt: !130)
!282 = !DILocation(line: 123, column: 3, scope: !243, inlinedAt: !130)
!283 = distinct !{!283, !244, !284, !115}
!284 = !DILocation(line: 133, column: 5, scope: !240, inlinedAt: !130)
!285 = !DILocation(line: 134, column: 3, scope: !126, inlinedAt: !130)
!286 = !DILocation(line: 134, column: 26, scope: !126, inlinedAt: !130)
!287 = !DILocation(line: 161, column: 3, scope: !121)
!288 = distinct !DISubprogram(name: "workload_checksum", scope: !11, file: !11, line: 163, type: !289, scopeLine: 163, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !2, retainedNodes: !64)
!289 = !DISubroutineType(types: !290)
!290 = !{!20, !6}
!291 = !DILocalVariable(name: "task", arg: 1, scope: !288, file: !11, line: 163, type: !6)
!292 = !DILocation(line: 0, scope: !288)
!293 = !DILocation(line: 165, column: 11, scope: !288)
!294 = !DILocation(line: 166, column: 15, scope: !288)
!295 = !DILocation(line: 166, column: 3, scope: !288)
!296 = !DILocation(line: 167, column: 10, scope: !288)
!297 = !DILocation(line: 167, column: 3, scope: !288)
!298 = distinct !DISubprogram(name: "print_array", scope: !11, file: !11, line: 58, type: !299, scopeLine: 61, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition, unit: !2, retainedNodes: !64)
!299 = !DISubroutineType(types: !300)
!300 = !{null, !12, !83}
!301 = !DILocalVariable(name: "m", arg: 1, scope: !298, file: !11, line: 58, type: !12)
!302 = !DILocation(line: 0, scope: !298)
!303 = !DILocalVariable(name: "corr", arg: 2, scope: !298, file: !11, line: 59, type: !83)
!304 = !DILocation(line: 64, column: 3, scope: !298)
!305 = !DILocation(line: 65, column: 3, scope: !298)
!306 = !DILocalVariable(name: "i", scope: !298, file: !11, line: 62, type: !12)
!307 = !DILocation(line: 66, column: 8, scope: !308)
!308 = distinct !DILexicalBlock(scope: !298, file: !11, line: 66, column: 3)
!309 = !DILocation(line: 0, scope: !308)
!310 = !DILocation(line: 66, column: 17, scope: !311)
!311 = distinct !DILexicalBlock(scope: !308, file: !11, line: 66, column: 3)
!312 = !DILocation(line: 66, column: 3, scope: !308)
!313 = !DILocalVariable(name: "j", scope: !298, file: !11, line: 62, type: !12)
!314 = !DILocation(line: 67, column: 10, scope: !315)
!315 = distinct !DILexicalBlock(scope: !311, file: !11, line: 67, column: 5)
!316 = !DILocation(line: 0, scope: !315)
!317 = !DILocation(line: 67, column: 19, scope: !318)
!318 = distinct !DILexicalBlock(scope: !315, file: !11, line: 67, column: 5)
!319 = !DILocation(line: 67, column: 5, scope: !315)
!320 = !DILocation(line: 68, column: 14, scope: !321)
!321 = distinct !DILexicalBlock(scope: !322, file: !11, line: 68, column: 11)
!322 = distinct !DILexicalBlock(scope: !318, file: !11, line: 67, column: 29)
!323 = !DILocation(line: 68, column: 18, scope: !321)
!324 = !DILocation(line: 68, column: 23, scope: !321)
!325 = !DILocation(line: 68, column: 28, scope: !321)
!326 = !DILocation(line: 68, column: 11, scope: !322)
!327 = !DILocation(line: 68, column: 43, scope: !321)
!328 = !DILocation(line: 68, column: 34, scope: !321)
!329 = !DILocation(line: 69, column: 16, scope: !322)
!330 = !DILocation(line: 69, column: 61, scope: !322)
!331 = !DILocation(line: 69, column: 7, scope: !322)
!332 = !DILocation(line: 70, column: 5, scope: !322)
!333 = !DILocation(line: 67, column: 25, scope: !318)
!334 = !DILocation(line: 67, column: 5, scope: !318)
!335 = distinct !{!335, !319, !336, !115}
!336 = !DILocation(line: 70, column: 5, scope: !315)
!337 = !DILocation(line: 66, column: 23, scope: !311)
!338 = !DILocation(line: 66, column: 3, scope: !311)
!339 = distinct !{!339, !312, !340, !115}
!340 = !DILocation(line: 70, column: 5, scope: !308)
!341 = !DILocation(line: 71, column: 3, scope: !298)
!342 = !DILocation(line: 72, column: 3, scope: !298)
!343 = !DILocation(line: 73, column: 1, scope: !298)
!344 = distinct !DISubprogram(name: "pb_fprintf", scope: !32, file: !32, line: 13, type: !345, scopeLine: 14, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition, unit: !2, retainedNodes: !64)
!345 = !DISubroutineType(types: !346)
!346 = !{!12, !347, !406, null}
!347 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !348, size: 64)
!348 = !DIDerivedType(tag: DW_TAG_typedef, name: "FILE", file: !349, line: 7, baseType: !350)
!349 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/types/FILE.h", directory: "", checksumkind: CSK_MD5, checksum: "571f9fb6223c42439075fdde11a0de5d")
!350 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "_IO_FILE", file: !351, line: 49, size: 1728, elements: !352)
!351 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/types/struct_FILE.h", directory: "", checksumkind: CSK_MD5, checksum: "1bad07471b7974df4ecc1d1c2ca207e6")
!352 = !{!353, !354, !357, !358, !359, !360, !361, !362, !363, !364, !365, !366, !367, !370, !372, !373, !374, !377, !379, !381, !383, !386, !388, !391, !394, !395, !397, !401, !402}
!353 = !DIDerivedType(tag: DW_TAG_member, name: "_flags", scope: !350, file: !351, line: 51, baseType: !12, size: 32)
!354 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_read_ptr", scope: !350, file: !351, line: 54, baseType: !355, size: 64, offset: 64)
!355 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !356, size: 64)
!356 = !DIBasicType(name: "char", size: 8, encoding: DW_ATE_signed_char)
!357 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_read_end", scope: !350, file: !351, line: 55, baseType: !355, size: 64, offset: 128)
!358 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_read_base", scope: !350, file: !351, line: 56, baseType: !355, size: 64, offset: 192)
!359 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_write_base", scope: !350, file: !351, line: 57, baseType: !355, size: 64, offset: 256)
!360 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_write_ptr", scope: !350, file: !351, line: 58, baseType: !355, size: 64, offset: 320)
!361 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_write_end", scope: !350, file: !351, line: 59, baseType: !355, size: 64, offset: 384)
!362 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_buf_base", scope: !350, file: !351, line: 60, baseType: !355, size: 64, offset: 448)
!363 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_buf_end", scope: !350, file: !351, line: 61, baseType: !355, size: 64, offset: 512)
!364 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_save_base", scope: !350, file: !351, line: 64, baseType: !355, size: 64, offset: 576)
!365 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_backup_base", scope: !350, file: !351, line: 65, baseType: !355, size: 64, offset: 640)
!366 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_save_end", scope: !350, file: !351, line: 66, baseType: !355, size: 64, offset: 704)
!367 = !DIDerivedType(tag: DW_TAG_member, name: "_markers", scope: !350, file: !351, line: 68, baseType: !368, size: 64, offset: 768)
!368 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !369, size: 64)
!369 = !DICompositeType(tag: DW_TAG_structure_type, name: "_IO_marker", file: !351, line: 36, flags: DIFlagFwdDecl)
!370 = !DIDerivedType(tag: DW_TAG_member, name: "_chain", scope: !350, file: !351, line: 70, baseType: !371, size: 64, offset: 832)
!371 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !350, size: 64)
!372 = !DIDerivedType(tag: DW_TAG_member, name: "_fileno", scope: !350, file: !351, line: 72, baseType: !12, size: 32, offset: 896)
!373 = !DIDerivedType(tag: DW_TAG_member, name: "_flags2", scope: !350, file: !351, line: 73, baseType: !12, size: 32, offset: 928)
!374 = !DIDerivedType(tag: DW_TAG_member, name: "_old_offset", scope: !350, file: !351, line: 74, baseType: !375, size: 64, offset: 960)
!375 = !DIDerivedType(tag: DW_TAG_typedef, name: "__off_t", file: !23, line: 152, baseType: !376)
!376 = !DIBasicType(name: "long", size: 64, encoding: DW_ATE_signed)
!377 = !DIDerivedType(tag: DW_TAG_member, name: "_cur_column", scope: !350, file: !351, line: 77, baseType: !378, size: 16, offset: 1024)
!378 = !DIBasicType(name: "unsigned short", size: 16, encoding: DW_ATE_unsigned)
!379 = !DIDerivedType(tag: DW_TAG_member, name: "_vtable_offset", scope: !350, file: !351, line: 78, baseType: !380, size: 8, offset: 1040)
!380 = !DIBasicType(name: "signed char", size: 8, encoding: DW_ATE_signed_char)
!381 = !DIDerivedType(tag: DW_TAG_member, name: "_shortbuf", scope: !350, file: !351, line: 79, baseType: !382, size: 8, offset: 1048)
!382 = !DICompositeType(tag: DW_TAG_array_type, baseType: !356, size: 8, elements: !24)
!383 = !DIDerivedType(tag: DW_TAG_member, name: "_lock", scope: !350, file: !351, line: 81, baseType: !384, size: 64, offset: 1088)
!384 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !385, size: 64)
!385 = !DIDerivedType(tag: DW_TAG_typedef, name: "_IO_lock_t", file: !351, line: 43, baseType: null)
!386 = !DIDerivedType(tag: DW_TAG_member, name: "_offset", scope: !350, file: !351, line: 89, baseType: !387, size: 64, offset: 1152)
!387 = !DIDerivedType(tag: DW_TAG_typedef, name: "__off64_t", file: !23, line: 153, baseType: !376)
!388 = !DIDerivedType(tag: DW_TAG_member, name: "_codecvt", scope: !350, file: !351, line: 91, baseType: !389, size: 64, offset: 1216)
!389 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !390, size: 64)
!390 = !DICompositeType(tag: DW_TAG_structure_type, name: "_IO_codecvt", file: !351, line: 37, flags: DIFlagFwdDecl)
!391 = !DIDerivedType(tag: DW_TAG_member, name: "_wide_data", scope: !350, file: !351, line: 92, baseType: !392, size: 64, offset: 1280)
!392 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !393, size: 64)
!393 = !DICompositeType(tag: DW_TAG_structure_type, name: "_IO_wide_data", file: !351, line: 38, flags: DIFlagFwdDecl)
!394 = !DIDerivedType(tag: DW_TAG_member, name: "_freeres_list", scope: !350, file: !351, line: 93, baseType: !371, size: 64, offset: 1344)
!395 = !DIDerivedType(tag: DW_TAG_member, name: "_freeres_buf", scope: !350, file: !351, line: 94, baseType: !396, size: 64, offset: 1408)
!396 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: null, size: 64)
!397 = !DIDerivedType(tag: DW_TAG_member, name: "__pad5", scope: !350, file: !351, line: 95, baseType: !398, size: 64, offset: 1472)
!398 = !DIDerivedType(tag: DW_TAG_typedef, name: "size_t", file: !399, line: 46, baseType: !400)
!399 = !DIFile(filename: "/usr/lib/llvm-14/lib/clang/14.0.0/include/stddef.h", directory: "", checksumkind: CSK_MD5, checksum: "2499dd2361b915724b073282bea3a7bc")
!400 = !DIBasicType(name: "unsigned long", size: 64, encoding: DW_ATE_unsigned)
!401 = !DIDerivedType(tag: DW_TAG_member, name: "_mode", scope: !350, file: !351, line: 96, baseType: !12, size: 32, offset: 1536)
!402 = !DIDerivedType(tag: DW_TAG_member, name: "_unused2", scope: !350, file: !351, line: 98, baseType: !403, size: 160, offset: 1568)
!403 = !DICompositeType(tag: DW_TAG_array_type, baseType: !356, size: 160, elements: !404)
!404 = !{!405}
!405 = !DISubrange(count: 20)
!406 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !407, size: 64)
!407 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !356)
!408 = !DILocalVariable(name: "stream", arg: 1, scope: !344, file: !32, line: 13, type: !347)
!409 = !DILocation(line: 0, scope: !344)
!410 = !DILocalVariable(name: "format", arg: 2, scope: !344, file: !32, line: 13, type: !406)
!411 = !DILocalVariable(name: "buffer", scope: !344, file: !32, line: 15, type: !412)
!412 = !DICompositeType(tag: DW_TAG_array_type, baseType: !356, size: 6144, elements: !413)
!413 = !{!414}
!414 = !DISubrange(count: 768)
!415 = !DILocation(line: 15, column: 10, scope: !344)
!416 = !DILocalVariable(name: "args", scope: !344, file: !32, line: 16, type: !417)
!417 = !DIDerivedType(tag: DW_TAG_typedef, name: "va_list", file: !418, line: 52, baseType: !419)
!418 = !DIFile(filename: "/usr/include/stdio.h", directory: "", checksumkind: CSK_MD5, checksum: "f31eefcc3f15835fc5a4023a625cf609")
!419 = !DIDerivedType(tag: DW_TAG_typedef, name: "__gnuc_va_list", file: !420, line: 32, baseType: !421)
!420 = !DIFile(filename: "/usr/lib/llvm-14/lib/clang/14.0.0/include/stdarg.h", directory: "", checksumkind: CSK_MD5, checksum: "4de3cbd931b589d291e5c39387aecf82")
!421 = !DIDerivedType(tag: DW_TAG_typedef, name: "__builtin_va_list", file: !422, baseType: !423)
!422 = !DIFile(filename: "source/workload.c", directory: "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/triangular-20260929/suite/correlation")
!423 = !DICompositeType(tag: DW_TAG_array_type, baseType: !424, size: 192, elements: !24)
!424 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "__va_list_tag", size: 192, elements: !425)
!425 = !{!426, !427, !428, !429}
!426 = !DIDerivedType(tag: DW_TAG_member, name: "gp_offset", scope: !424, file: !422, line: 16, baseType: !6, size: 32)
!427 = !DIDerivedType(tag: DW_TAG_member, name: "fp_offset", scope: !424, file: !422, line: 16, baseType: !6, size: 32, offset: 32)
!428 = !DIDerivedType(tag: DW_TAG_member, name: "overflow_arg_area", scope: !424, file: !422, line: 16, baseType: !396, size: 64, offset: 64)
!429 = !DIDerivedType(tag: DW_TAG_member, name: "reg_save_area", scope: !424, file: !422, line: 16, baseType: !396, size: 64, offset: 128)
!430 = !DILocation(line: 16, column: 13, scope: !344)
!431 = !DILocation(line: 17, column: 5, scope: !344)
!432 = !DILocation(line: 18, column: 27, scope: !344)
!433 = !DILocation(line: 18, column: 59, scope: !344)
!434 = !DILocation(line: 18, column: 17, scope: !344)
!435 = !DILocalVariable(name: "count", scope: !344, file: !32, line: 18, type: !12)
!436 = !DILocation(line: 19, column: 5, scope: !344)
!437 = !DILocation(line: 20, column: 15, scope: !438)
!438 = distinct !DILexicalBlock(scope: !344, file: !32, line: 20, column: 9)
!439 = !DILocation(line: 20, column: 19, scope: !438)
!440 = !DILocation(line: 20, column: 22, scope: !438)
!441 = !DILocation(line: 20, column: 38, scope: !438)
!442 = !DILocation(line: 20, column: 9, scope: !344)
!443 = !DILocation(line: 20, column: 57, scope: !438)
!444 = !DILocalVariable(name: "i", scope: !445, file: !32, line: 21, type: !12)
!445 = distinct !DILexicalBlock(scope: !344, file: !32, line: 21, column: 5)
!446 = !DILocation(line: 0, scope: !445)
!447 = !DILocation(line: 21, column: 10, scope: !445)
!448 = !DILocation(line: 21, column: 23, scope: !449)
!449 = distinct !DILexicalBlock(scope: !445, file: !32, line: 21, column: 5)
!450 = !DILocation(line: 21, column: 5, scope: !445)
!451 = !DILocation(line: 22, column: 35, scope: !452)
!452 = distinct !DILexicalBlock(scope: !449, file: !32, line: 21, column: 37)
!453 = !DILocation(line: 22, column: 20, scope: !452)
!454 = !DILocation(line: 22, column: 17, scope: !452)
!455 = !DILocation(line: 23, column: 17, scope: !452)
!456 = !DILocation(line: 24, column: 5, scope: !452)
!457 = !DILocation(line: 21, column: 32, scope: !449)
!458 = !DILocation(line: 21, column: 5, scope: !449)
!459 = distinct !{!459, !450, !460, !115}
!460 = !DILocation(line: 24, column: 5, scope: !445)
!461 = !DILocation(line: 29, column: 11, scope: !344)
!462 = !DILocation(line: 31, column: 5, scope: !344)
