; ModuleID = 'inlined.ll'
source_filename = "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/triangular-20260929/suite/deriche/source/workload.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

@w = external dso_local global i32, align 4, !dbg !0
@h = external dso_local global i32, align 4, !dbg !9
@imgIn = external dso_local global [720 x [480 x float]], section ".chaser_data.imgIn", align 64, !dbg !13
@imgOut = external dso_local global [720 x [480 x float]], section ".chaser_data.imgOut", align 64, !dbg !19
@pb_y1 = external dso_local global [720 x [480 x float]], section ".chaser_data.y1", align 64, !dbg !21
@y2 = external dso_local global [720 x [480 x float]], section ".chaser_data.y2", align 64, !dbg !23
@alpha = external dso_local global float, align 4, !dbg !25
@.str = hidden unnamed_addr constant [12 x i8] c"ape.analyze\00", section "llvm.metadata"
@.str.1 = hidden unnamed_addr constant [122 x i8] c"/workspace/experiments-array-support/chaser/.cache/periodic-polybench/triangular-20260929/suite/deriche/source/workload.c\00", section "llvm.metadata"
@.str.2 = hidden unnamed_addr constant [23 x i8] c"==BEGIN DUMP_ARRAYS==\0A\00", align 1
@.str.3 = hidden unnamed_addr constant [15 x i8] c"begin dump: %s\00", align 1
@.str.4 = hidden unnamed_addr constant [7 x i8] c"imgOut\00", align 1
@.str.5 = hidden unnamed_addr constant [2 x i8] c"\0A\00", align 1
@.str.6 = hidden unnamed_addr constant [7 x i8] c"%0.2f \00", align 1
@.str.7 = hidden unnamed_addr constant [17 x i8] c"\0Aend   dump: %s\0A\00", align 1
@.str.8 = hidden unnamed_addr constant [23 x i8] c"==END   DUMP_ARRAYS==\0A\00", align 1
@llvm.global.annotations = appending global [1 x { i8*, i8*, i8*, i32, i8* }] [{ i8*, i8*, i8*, i32, i8* } { i8* bitcast (i32 ()* @task_job_polybench to i8*), i8* getelementptr inbounds ([12 x i8], [12 x i8]* @.str, i32 0, i32 0), i8* getelementptr inbounds ([122 x i8], [122 x i8]* @.str.1, i32 0, i32 0), i32 186, i8* null }], section "llvm.metadata"

; Function Attrs: noinline nounwind uwtable
define dso_local i32 @task_job_polybench() #0 !dbg !35 {
  %1 = load i32, i32* @w, align 4, !dbg !43
  %2 = load i32, i32* @h, align 4, !dbg !44
  %3 = load float, float* @alpha, align 4, !dbg !45
  call void @llvm.dbg.value(metadata i32 %1, metadata !46, metadata !DIExpression()), !dbg !53
  call void @llvm.dbg.value(metadata i32 %2, metadata !55, metadata !DIExpression()), !dbg !53
  call void @llvm.dbg.value(metadata float %3, metadata !56, metadata !DIExpression()), !dbg !53
  call void @llvm.dbg.value(metadata [480 x float]* getelementptr inbounds ([720 x [480 x float]], [720 x [480 x float]]* @imgIn, i64 0, i64 0), metadata !57, metadata !DIExpression()), !dbg !53
  call void @llvm.dbg.value(metadata [480 x float]* getelementptr inbounds ([720 x [480 x float]], [720 x [480 x float]]* @imgOut, i64 0, i64 0), metadata !58, metadata !DIExpression()), !dbg !53
  call void @llvm.dbg.value(metadata [480 x float]* getelementptr inbounds ([720 x [480 x float]], [720 x [480 x float]]* @pb_y1, i64 0, i64 0), metadata !59, metadata !DIExpression()), !dbg !53
  call void @llvm.dbg.value(metadata [480 x float]* getelementptr inbounds ([720 x [480 x float]], [720 x [480 x float]]* @y2, i64 0, i64 0), metadata !60, metadata !DIExpression()), !dbg !53
  %4 = fneg float %3, !dbg !61
  %5 = call float @expf(float noundef %4) #3, !dbg !61
  %6 = fsub float 1.000000e+00, %5, !dbg !62
  %7 = fneg float %3, !dbg !63
  %8 = call float @expf(float noundef %7) #3, !dbg !63
  %9 = fsub float 1.000000e+00, %8, !dbg !64
  %10 = fmul float %6, %9, !dbg !65
  %11 = fmul float 2.000000e+00, %3, !dbg !66
  %12 = fneg float %3, !dbg !67
  %13 = call float @expf(float noundef %12) #3, !dbg !67
  %14 = fmul float %11, %13, !dbg !68
  %15 = fadd float 1.000000e+00, %14, !dbg !69
  %16 = fmul float 2.000000e+00, %3, !dbg !70
  %17 = call float @expf(float noundef %16) #3, !dbg !70
  %18 = fsub float %15, %17, !dbg !71
  %19 = fdiv float %10, %18, !dbg !72
  call void @llvm.dbg.value(metadata float %19, metadata !73, metadata !DIExpression()), !dbg !53
  call void @llvm.dbg.value(metadata float %19, metadata !74, metadata !DIExpression()), !dbg !53
  call void @llvm.dbg.value(metadata float %19, metadata !75, metadata !DIExpression()), !dbg !53
  %20 = fneg float %3, !dbg !76
  %21 = call float @expf(float noundef %20) #3, !dbg !76
  %22 = fmul float %19, %21, !dbg !77
  %23 = fsub float %3, 1.000000e+00, !dbg !78
  %24 = fmul float %22, %23, !dbg !79
  call void @llvm.dbg.value(metadata float %24, metadata !80, metadata !DIExpression()), !dbg !53
  call void @llvm.dbg.value(metadata float %24, metadata !81, metadata !DIExpression()), !dbg !53
  %25 = fneg float %3, !dbg !82
  %26 = call float @expf(float noundef %25) #3, !dbg !82
  %27 = fmul float %19, %26, !dbg !83
  %28 = fadd float %3, 1.000000e+00, !dbg !84
  %29 = fmul float %27, %28, !dbg !85
  call void @llvm.dbg.value(metadata float %29, metadata !86, metadata !DIExpression()), !dbg !53
  call void @llvm.dbg.value(metadata float %29, metadata !87, metadata !DIExpression()), !dbg !53
  %30 = fneg float %19, !dbg !88
  %31 = fmul float -2.000000e+00, %3, !dbg !89
  %32 = call float @expf(float noundef %31) #3, !dbg !89
  %33 = fmul float %30, %32, !dbg !90
  call void @llvm.dbg.value(metadata float %33, metadata !91, metadata !DIExpression()), !dbg !53
  call void @llvm.dbg.value(metadata float %33, metadata !92, metadata !DIExpression()), !dbg !53
  %34 = fneg float %3, !dbg !93
  %35 = call float @powf(float noundef 2.000000e+00, float noundef %34) #3, !dbg !93
  call void @llvm.dbg.value(metadata float %35, metadata !94, metadata !DIExpression()), !dbg !53
  %36 = fmul float -2.000000e+00, %3, !dbg !95
  %37 = call float @expf(float noundef %36) #3, !dbg !95
  %38 = fneg float %37, !dbg !96
  call void @llvm.dbg.value(metadata float %38, metadata !97, metadata !DIExpression()), !dbg !53
  call void @llvm.dbg.value(metadata float 1.000000e+00, metadata !98, metadata !DIExpression()), !dbg !53
  call void @llvm.dbg.value(metadata float 1.000000e+00, metadata !99, metadata !DIExpression()), !dbg !53
  call void @llvm.dbg.value(metadata i32 0, metadata !100, metadata !DIExpression()), !dbg !53
  br label %39, !dbg !101

39:                                               ; preds = %72, %0
  %.09 = phi i32 [ 0, %0 ], [ %73, %72 ], !dbg !103
  call void @llvm.dbg.value(metadata i32 %.09, metadata !100, metadata !DIExpression()), !dbg !53
  %40 = icmp slt i32 %.09, 720, !dbg !104
  br i1 %40, label %41, label %74, !dbg !106

41:                                               ; preds = %39
  call void @llvm.dbg.value(metadata float 0.000000e+00, metadata !107, metadata !DIExpression()), !dbg !53
  call void @llvm.dbg.value(metadata float 0.000000e+00, metadata !108, metadata !DIExpression()), !dbg !53
  call void @llvm.dbg.value(metadata float 0.000000e+00, metadata !109, metadata !DIExpression()), !dbg !53
  call void @llvm.dbg.value(metadata i32 0, metadata !110, metadata !DIExpression()), !dbg !53
  br label %42, !dbg !111

42:                                               ; preds = %44, %41
  %.019 = phi float [ 0.000000e+00, %41 ], [ %70, %44 ], !dbg !114
  %.017 = phi float [ 0.000000e+00, %41 ], [ %65, %44 ], !dbg !114
  %.011 = phi i32 [ 0, %41 ], [ %71, %44 ], !dbg !115
  %.07 = phi float [ 0.000000e+00, %41 ], [ %.019, %44 ], !dbg !114
  call void @llvm.dbg.value(metadata float %.07, metadata !108, metadata !DIExpression()), !dbg !53
  call void @llvm.dbg.value(metadata i32 %.011, metadata !110, metadata !DIExpression()), !dbg !53
  call void @llvm.dbg.value(metadata float %.017, metadata !109, metadata !DIExpression()), !dbg !53
  call void @llvm.dbg.value(metadata float %.019, metadata !107, metadata !DIExpression()), !dbg !53
  %43 = icmp slt i32 %.011, 480, !dbg !116
  br i1 %43, label %44, label %72, !dbg !118

44:                                               ; preds = %42
  %45 = sext i32 %.09 to i64, !dbg !119
  %46 = getelementptr inbounds [480 x float], [480 x float]* getelementptr inbounds ([720 x [480 x float]], [720 x [480 x float]]* @imgIn, i64 0, i64 0), i64 %45, !dbg !119
  %47 = sext i32 %.011 to i64, !dbg !119
  %48 = getelementptr inbounds [480 x float], [480 x float]* %46, i64 0, i64 %47, !dbg !119
  %49 = load float, float* %48, align 4, !dbg !119
  %50 = fmul float %19, %49, !dbg !121
  %51 = fmul float %24, %.017, !dbg !122
  %52 = fadd float %50, %51, !dbg !123
  %53 = fmul float %35, %.019, !dbg !124
  %54 = fadd float %52, %53, !dbg !125
  %55 = fmul float %38, %.07, !dbg !126
  %56 = fadd float %54, %55, !dbg !127
  %57 = sext i32 %.09 to i64, !dbg !128
  %58 = getelementptr inbounds [480 x float], [480 x float]* getelementptr inbounds ([720 x [480 x float]], [720 x [480 x float]]* @pb_y1, i64 0, i64 0), i64 %57, !dbg !128
  %59 = sext i32 %.011 to i64, !dbg !128
  %60 = getelementptr inbounds [480 x float], [480 x float]* %58, i64 0, i64 %59, !dbg !128
  store float %56, float* %60, align 4, !dbg !129
  %61 = sext i32 %.09 to i64, !dbg !130
  %62 = getelementptr inbounds [480 x float], [480 x float]* getelementptr inbounds ([720 x [480 x float]], [720 x [480 x float]]* @imgIn, i64 0, i64 0), i64 %61, !dbg !130
  %63 = sext i32 %.011 to i64, !dbg !130
  %64 = getelementptr inbounds [480 x float], [480 x float]* %62, i64 0, i64 %63, !dbg !130
  %65 = load float, float* %64, align 4, !dbg !130
  call void @llvm.dbg.value(metadata float %65, metadata !109, metadata !DIExpression()), !dbg !53
  call void @llvm.dbg.value(metadata float %.019, metadata !108, metadata !DIExpression()), !dbg !53
  %66 = sext i32 %.09 to i64, !dbg !131
  %67 = getelementptr inbounds [480 x float], [480 x float]* getelementptr inbounds ([720 x [480 x float]], [720 x [480 x float]]* @pb_y1, i64 0, i64 0), i64 %66, !dbg !131
  %68 = sext i32 %.011 to i64, !dbg !131
  %69 = getelementptr inbounds [480 x float], [480 x float]* %67, i64 0, i64 %68, !dbg !131
  %70 = load float, float* %69, align 4, !dbg !131
  call void @llvm.dbg.value(metadata float %70, metadata !107, metadata !DIExpression()), !dbg !53
  %71 = add nsw i32 %.011, 1, !dbg !132
  call void @llvm.dbg.value(metadata i32 %71, metadata !110, metadata !DIExpression()), !dbg !53
  br label %42, !dbg !133, !llvm.loop !134

72:                                               ; preds = %42
  %73 = add nsw i32 %.09, 1, !dbg !137
  call void @llvm.dbg.value(metadata i32 %73, metadata !100, metadata !DIExpression()), !dbg !53
  br label %39, !dbg !138, !llvm.loop !139

74:                                               ; preds = %39
  call void @llvm.dbg.value(metadata i32 0, metadata !100, metadata !DIExpression()), !dbg !53
  br label %75, !dbg !141

75:                                               ; preds = %103, %74
  %.110 = phi i32 [ 0, %74 ], [ %104, %103 ], !dbg !143
  call void @llvm.dbg.value(metadata i32 %.110, metadata !100, metadata !DIExpression()), !dbg !53
  %76 = icmp slt i32 %.110, 720, !dbg !144
  br i1 %76, label %77, label %105, !dbg !146

77:                                               ; preds = %75
  call void @llvm.dbg.value(metadata float 0.000000e+00, metadata !147, metadata !DIExpression()), !dbg !53
  call void @llvm.dbg.value(metadata float 0.000000e+00, metadata !148, metadata !DIExpression()), !dbg !53
  call void @llvm.dbg.value(metadata float 0.000000e+00, metadata !149, metadata !DIExpression()), !dbg !53
  call void @llvm.dbg.value(metadata float 0.000000e+00, metadata !150, metadata !DIExpression()), !dbg !53
  call void @llvm.dbg.value(metadata i32 479, metadata !110, metadata !DIExpression()), !dbg !53
  br label %78, !dbg !151

78:                                               ; preds = %80, %77
  %.112 = phi i32 [ 479, %77 ], [ %102, %80 ], !dbg !154
  %.06 = phi float [ 0.000000e+00, %77 ], [ %96, %80 ], !dbg !155
  %.05 = phi float [ 0.000000e+00, %77 ], [ %.06, %80 ], !dbg !155
  %.01 = phi float [ 0.000000e+00, %77 ], [ %101, %80 ], !dbg !155
  %.0 = phi float [ 0.000000e+00, %77 ], [ %.01, %80 ], !dbg !155
  call void @llvm.dbg.value(metadata float %.0, metadata !148, metadata !DIExpression()), !dbg !53
  call void @llvm.dbg.value(metadata float %.01, metadata !147, metadata !DIExpression()), !dbg !53
  call void @llvm.dbg.value(metadata float %.05, metadata !150, metadata !DIExpression()), !dbg !53
  call void @llvm.dbg.value(metadata float %.06, metadata !149, metadata !DIExpression()), !dbg !53
  call void @llvm.dbg.value(metadata i32 %.112, metadata !110, metadata !DIExpression()), !dbg !53
  %79 = icmp sge i32 %.112, 0, !dbg !156
  br i1 %79, label %80, label %103, !dbg !158

80:                                               ; preds = %78
  %81 = fmul float %29, %.06, !dbg !159
  %82 = fmul float %33, %.05, !dbg !161
  %83 = fadd float %81, %82, !dbg !162
  %84 = fmul float %35, %.01, !dbg !163
  %85 = fadd float %83, %84, !dbg !164
  %86 = fmul float %38, %.0, !dbg !165
  %87 = fadd float %85, %86, !dbg !166
  %88 = sext i32 %.110 to i64, !dbg !167
  %89 = getelementptr inbounds [480 x float], [480 x float]* getelementptr inbounds ([720 x [480 x float]], [720 x [480 x float]]* @y2, i64 0, i64 0), i64 %88, !dbg !167
  %90 = sext i32 %.112 to i64, !dbg !167
  %91 = getelementptr inbounds [480 x float], [480 x float]* %89, i64 0, i64 %90, !dbg !167
  store float %87, float* %91, align 4, !dbg !168
  call void @llvm.dbg.value(metadata float %.06, metadata !150, metadata !DIExpression()), !dbg !53
  %92 = sext i32 %.110 to i64, !dbg !169
  %93 = getelementptr inbounds [480 x float], [480 x float]* getelementptr inbounds ([720 x [480 x float]], [720 x [480 x float]]* @imgIn, i64 0, i64 0), i64 %92, !dbg !169
  %94 = sext i32 %.112 to i64, !dbg !169
  %95 = getelementptr inbounds [480 x float], [480 x float]* %93, i64 0, i64 %94, !dbg !169
  %96 = load float, float* %95, align 4, !dbg !169
  call void @llvm.dbg.value(metadata float %96, metadata !149, metadata !DIExpression()), !dbg !53
  call void @llvm.dbg.value(metadata float %.01, metadata !148, metadata !DIExpression()), !dbg !53
  %97 = sext i32 %.110 to i64, !dbg !170
  %98 = getelementptr inbounds [480 x float], [480 x float]* getelementptr inbounds ([720 x [480 x float]], [720 x [480 x float]]* @y2, i64 0, i64 0), i64 %97, !dbg !170
  %99 = sext i32 %.112 to i64, !dbg !170
  %100 = getelementptr inbounds [480 x float], [480 x float]* %98, i64 0, i64 %99, !dbg !170
  %101 = load float, float* %100, align 4, !dbg !170
  call void @llvm.dbg.value(metadata float %101, metadata !147, metadata !DIExpression()), !dbg !53
  %102 = add nsw i32 %.112, -1, !dbg !171
  call void @llvm.dbg.value(metadata i32 %102, metadata !110, metadata !DIExpression()), !dbg !53
  br label %78, !dbg !172, !llvm.loop !173

103:                                              ; preds = %78
  %104 = add nsw i32 %.110, 1, !dbg !175
  call void @llvm.dbg.value(metadata i32 %104, metadata !100, metadata !DIExpression()), !dbg !53
  br label %75, !dbg !176, !llvm.loop !177

105:                                              ; preds = %75
  call void @llvm.dbg.value(metadata i32 0, metadata !100, metadata !DIExpression()), !dbg !53
  br label %106, !dbg !179

106:                                              ; preds = %129, %105
  %.2 = phi i32 [ 0, %105 ], [ %130, %129 ], !dbg !181
  call void @llvm.dbg.value(metadata i32 %.2, metadata !100, metadata !DIExpression()), !dbg !53
  %107 = icmp slt i32 %.2, 720, !dbg !182
  br i1 %107, label %108, label %131, !dbg !184

108:                                              ; preds = %106
  call void @llvm.dbg.value(metadata i32 0, metadata !110, metadata !DIExpression()), !dbg !53
  br label %109, !dbg !185

109:                                              ; preds = %111, %108
  %.213 = phi i32 [ 0, %108 ], [ %128, %111 ], !dbg !187
  call void @llvm.dbg.value(metadata i32 %.213, metadata !110, metadata !DIExpression()), !dbg !53
  %110 = icmp slt i32 %.213, 480, !dbg !188
  br i1 %110, label %111, label %129, !dbg !190

111:                                              ; preds = %109
  %112 = sext i32 %.2 to i64, !dbg !191
  %113 = getelementptr inbounds [480 x float], [480 x float]* getelementptr inbounds ([720 x [480 x float]], [720 x [480 x float]]* @pb_y1, i64 0, i64 0), i64 %112, !dbg !191
  %114 = sext i32 %.213 to i64, !dbg !191
  %115 = getelementptr inbounds [480 x float], [480 x float]* %113, i64 0, i64 %114, !dbg !191
  %116 = load float, float* %115, align 4, !dbg !191
  %117 = sext i32 %.2 to i64, !dbg !193
  %118 = getelementptr inbounds [480 x float], [480 x float]* getelementptr inbounds ([720 x [480 x float]], [720 x [480 x float]]* @y2, i64 0, i64 0), i64 %117, !dbg !193
  %119 = sext i32 %.213 to i64, !dbg !193
  %120 = getelementptr inbounds [480 x float], [480 x float]* %118, i64 0, i64 %119, !dbg !193
  %121 = load float, float* %120, align 4, !dbg !193
  %122 = fadd float %116, %121, !dbg !194
  %123 = fmul float 1.000000e+00, %122, !dbg !195
  %124 = sext i32 %.2 to i64, !dbg !196
  %125 = getelementptr inbounds [480 x float], [480 x float]* getelementptr inbounds ([720 x [480 x float]], [720 x [480 x float]]* @imgOut, i64 0, i64 0), i64 %124, !dbg !196
  %126 = sext i32 %.213 to i64, !dbg !196
  %127 = getelementptr inbounds [480 x float], [480 x float]* %125, i64 0, i64 %126, !dbg !196
  store float %123, float* %127, align 4, !dbg !197
  %128 = add nsw i32 %.213, 1, !dbg !198
  call void @llvm.dbg.value(metadata i32 %128, metadata !110, metadata !DIExpression()), !dbg !53
  br label %109, !dbg !199, !llvm.loop !200

129:                                              ; preds = %109
  %130 = add nsw i32 %.2, 1, !dbg !202
  call void @llvm.dbg.value(metadata i32 %130, metadata !100, metadata !DIExpression()), !dbg !53
  br label %106, !dbg !203, !llvm.loop !204

131:                                              ; preds = %106
  call void @llvm.dbg.value(metadata i32 0, metadata !110, metadata !DIExpression()), !dbg !53
  br label %132, !dbg !206

132:                                              ; preds = %165, %131
  %.314 = phi i32 [ 0, %131 ], [ %166, %165 ], !dbg !208
  call void @llvm.dbg.value(metadata i32 %.314, metadata !110, metadata !DIExpression()), !dbg !53
  %133 = icmp slt i32 %.314, 480, !dbg !209
  br i1 %133, label %134, label %167, !dbg !211

134:                                              ; preds = %132
  call void @llvm.dbg.value(metadata float 0.000000e+00, metadata !212, metadata !DIExpression()), !dbg !53
  call void @llvm.dbg.value(metadata float 0.000000e+00, metadata !107, metadata !DIExpression()), !dbg !53
  call void @llvm.dbg.value(metadata float 0.000000e+00, metadata !108, metadata !DIExpression()), !dbg !53
  call void @llvm.dbg.value(metadata i32 0, metadata !100, metadata !DIExpression()), !dbg !53
  br label %135, !dbg !213

135:                                              ; preds = %137, %134
  %.120 = phi float [ 0.000000e+00, %134 ], [ %163, %137 ], !dbg !216
  %.018 = phi float [ 0.000000e+00, %134 ], [ %158, %137 ], !dbg !216
  %.3 = phi i32 [ 0, %134 ], [ %164, %137 ], !dbg !217
  %.18 = phi float [ 0.000000e+00, %134 ], [ %.120, %137 ], !dbg !216
  call void @llvm.dbg.value(metadata float %.18, metadata !108, metadata !DIExpression()), !dbg !53
  call void @llvm.dbg.value(metadata i32 %.3, metadata !100, metadata !DIExpression()), !dbg !53
  call void @llvm.dbg.value(metadata float %.018, metadata !212, metadata !DIExpression()), !dbg !53
  call void @llvm.dbg.value(metadata float %.120, metadata !107, metadata !DIExpression()), !dbg !53
  %136 = icmp slt i32 %.3, 720, !dbg !218
  br i1 %136, label %137, label %165, !dbg !220

137:                                              ; preds = %135
  %138 = sext i32 %.3 to i64, !dbg !221
  %139 = getelementptr inbounds [480 x float], [480 x float]* getelementptr inbounds ([720 x [480 x float]], [720 x [480 x float]]* @imgOut, i64 0, i64 0), i64 %138, !dbg !221
  %140 = sext i32 %.314 to i64, !dbg !221
  %141 = getelementptr inbounds [480 x float], [480 x float]* %139, i64 0, i64 %140, !dbg !221
  %142 = load float, float* %141, align 4, !dbg !221
  %143 = fmul float %19, %142, !dbg !223
  %144 = fmul float %24, %.018, !dbg !224
  %145 = fadd float %143, %144, !dbg !225
  %146 = fmul float %35, %.120, !dbg !226
  %147 = fadd float %145, %146, !dbg !227
  %148 = fmul float %38, %.18, !dbg !228
  %149 = fadd float %147, %148, !dbg !229
  %150 = sext i32 %.3 to i64, !dbg !230
  %151 = getelementptr inbounds [480 x float], [480 x float]* getelementptr inbounds ([720 x [480 x float]], [720 x [480 x float]]* @pb_y1, i64 0, i64 0), i64 %150, !dbg !230
  %152 = sext i32 %.314 to i64, !dbg !230
  %153 = getelementptr inbounds [480 x float], [480 x float]* %151, i64 0, i64 %152, !dbg !230
  store float %149, float* %153, align 4, !dbg !231
  %154 = sext i32 %.3 to i64, !dbg !232
  %155 = getelementptr inbounds [480 x float], [480 x float]* getelementptr inbounds ([720 x [480 x float]], [720 x [480 x float]]* @imgOut, i64 0, i64 0), i64 %154, !dbg !232
  %156 = sext i32 %.314 to i64, !dbg !232
  %157 = getelementptr inbounds [480 x float], [480 x float]* %155, i64 0, i64 %156, !dbg !232
  %158 = load float, float* %157, align 4, !dbg !232
  call void @llvm.dbg.value(metadata float %158, metadata !212, metadata !DIExpression()), !dbg !53
  call void @llvm.dbg.value(metadata float %.120, metadata !108, metadata !DIExpression()), !dbg !53
  %159 = sext i32 %.3 to i64, !dbg !233
  %160 = getelementptr inbounds [480 x float], [480 x float]* getelementptr inbounds ([720 x [480 x float]], [720 x [480 x float]]* @pb_y1, i64 0, i64 0), i64 %159, !dbg !233
  %161 = sext i32 %.314 to i64, !dbg !233
  %162 = getelementptr inbounds [480 x float], [480 x float]* %160, i64 0, i64 %161, !dbg !233
  %163 = load float, float* %162, align 4, !dbg !233
  call void @llvm.dbg.value(metadata float %163, metadata !107, metadata !DIExpression()), !dbg !53
  %164 = add nsw i32 %.3, 1, !dbg !234
  call void @llvm.dbg.value(metadata i32 %164, metadata !100, metadata !DIExpression()), !dbg !53
  br label %135, !dbg !235, !llvm.loop !236

165:                                              ; preds = %135
  %166 = add nsw i32 %.314, 1, !dbg !238
  call void @llvm.dbg.value(metadata i32 %166, metadata !110, metadata !DIExpression()), !dbg !53
  br label %132, !dbg !239, !llvm.loop !240

167:                                              ; preds = %132
  call void @llvm.dbg.value(metadata i32 0, metadata !110, metadata !DIExpression()), !dbg !53
  br label %168, !dbg !242

168:                                              ; preds = %196, %167
  %.415 = phi i32 [ 0, %167 ], [ %197, %196 ], !dbg !244
  call void @llvm.dbg.value(metadata i32 %.415, metadata !110, metadata !DIExpression()), !dbg !53
  %169 = icmp slt i32 %.415, 480, !dbg !245
  br i1 %169, label %170, label %198, !dbg !247

170:                                              ; preds = %168
  call void @llvm.dbg.value(metadata float 0.000000e+00, metadata !248, metadata !DIExpression()), !dbg !53
  call void @llvm.dbg.value(metadata float 0.000000e+00, metadata !249, metadata !DIExpression()), !dbg !53
  call void @llvm.dbg.value(metadata float 0.000000e+00, metadata !147, metadata !DIExpression()), !dbg !53
  call void @llvm.dbg.value(metadata float 0.000000e+00, metadata !148, metadata !DIExpression()), !dbg !53
  call void @llvm.dbg.value(metadata i32 719, metadata !100, metadata !DIExpression()), !dbg !53
  br label %171, !dbg !250

171:                                              ; preds = %173, %170
  %.4 = phi i32 [ 719, %170 ], [ %195, %173 ], !dbg !253
  %.04 = phi float [ 0.000000e+00, %170 ], [ %189, %173 ], !dbg !254
  %.03 = phi float [ 0.000000e+00, %170 ], [ %.04, %173 ], !dbg !254
  %.12 = phi float [ 0.000000e+00, %170 ], [ %194, %173 ], !dbg !254
  %.1 = phi float [ 0.000000e+00, %170 ], [ %.12, %173 ], !dbg !254
  call void @llvm.dbg.value(metadata float %.1, metadata !148, metadata !DIExpression()), !dbg !53
  call void @llvm.dbg.value(metadata float %.12, metadata !147, metadata !DIExpression()), !dbg !53
  call void @llvm.dbg.value(metadata float %.03, metadata !249, metadata !DIExpression()), !dbg !53
  call void @llvm.dbg.value(metadata float %.04, metadata !248, metadata !DIExpression()), !dbg !53
  call void @llvm.dbg.value(metadata i32 %.4, metadata !100, metadata !DIExpression()), !dbg !53
  %172 = icmp sge i32 %.4, 0, !dbg !255
  br i1 %172, label %173, label %196, !dbg !257

173:                                              ; preds = %171
  %174 = fmul float %29, %.04, !dbg !258
  %175 = fmul float %33, %.03, !dbg !260
  %176 = fadd float %174, %175, !dbg !261
  %177 = fmul float %35, %.12, !dbg !262
  %178 = fadd float %176, %177, !dbg !263
  %179 = fmul float %38, %.1, !dbg !264
  %180 = fadd float %178, %179, !dbg !265
  %181 = sext i32 %.4 to i64, !dbg !266
  %182 = getelementptr inbounds [480 x float], [480 x float]* getelementptr inbounds ([720 x [480 x float]], [720 x [480 x float]]* @y2, i64 0, i64 0), i64 %181, !dbg !266
  %183 = sext i32 %.415 to i64, !dbg !266
  %184 = getelementptr inbounds [480 x float], [480 x float]* %182, i64 0, i64 %183, !dbg !266
  store float %180, float* %184, align 4, !dbg !267
  call void @llvm.dbg.value(metadata float %.04, metadata !249, metadata !DIExpression()), !dbg !53
  %185 = sext i32 %.4 to i64, !dbg !268
  %186 = getelementptr inbounds [480 x float], [480 x float]* getelementptr inbounds ([720 x [480 x float]], [720 x [480 x float]]* @imgOut, i64 0, i64 0), i64 %185, !dbg !268
  %187 = sext i32 %.415 to i64, !dbg !268
  %188 = getelementptr inbounds [480 x float], [480 x float]* %186, i64 0, i64 %187, !dbg !268
  %189 = load float, float* %188, align 4, !dbg !268
  call void @llvm.dbg.value(metadata float %189, metadata !248, metadata !DIExpression()), !dbg !53
  call void @llvm.dbg.value(metadata float %.12, metadata !148, metadata !DIExpression()), !dbg !53
  %190 = sext i32 %.4 to i64, !dbg !269
  %191 = getelementptr inbounds [480 x float], [480 x float]* getelementptr inbounds ([720 x [480 x float]], [720 x [480 x float]]* @y2, i64 0, i64 0), i64 %190, !dbg !269
  %192 = sext i32 %.415 to i64, !dbg !269
  %193 = getelementptr inbounds [480 x float], [480 x float]* %191, i64 0, i64 %192, !dbg !269
  %194 = load float, float* %193, align 4, !dbg !269
  call void @llvm.dbg.value(metadata float %194, metadata !147, metadata !DIExpression()), !dbg !53
  %195 = add nsw i32 %.4, -1, !dbg !270
  call void @llvm.dbg.value(metadata i32 %195, metadata !100, metadata !DIExpression()), !dbg !53
  br label %171, !dbg !271, !llvm.loop !272

196:                                              ; preds = %171
  %197 = add nsw i32 %.415, 1, !dbg !274
  call void @llvm.dbg.value(metadata i32 %197, metadata !110, metadata !DIExpression()), !dbg !53
  br label %168, !dbg !275, !llvm.loop !276

198:                                              ; preds = %168
  call void @llvm.dbg.value(metadata i32 0, metadata !100, metadata !DIExpression()), !dbg !53
  br label %199, !dbg !278

199:                                              ; preds = %222, %198
  %.5 = phi i32 [ 0, %198 ], [ %223, %222 ], !dbg !280
  call void @llvm.dbg.value(metadata i32 %.5, metadata !100, metadata !DIExpression()), !dbg !53
  %200 = icmp slt i32 %.5, 720, !dbg !281
  br i1 %200, label %201, label %224, !dbg !283

201:                                              ; preds = %199
  call void @llvm.dbg.value(metadata i32 0, metadata !110, metadata !DIExpression()), !dbg !53
  br label %202, !dbg !284

202:                                              ; preds = %204, %201
  %.516 = phi i32 [ 0, %201 ], [ %221, %204 ], !dbg !286
  call void @llvm.dbg.value(metadata i32 %.516, metadata !110, metadata !DIExpression()), !dbg !53
  %203 = icmp slt i32 %.516, 480, !dbg !287
  br i1 %203, label %204, label %222, !dbg !289

204:                                              ; preds = %202
  %205 = sext i32 %.5 to i64, !dbg !290
  %206 = getelementptr inbounds [480 x float], [480 x float]* getelementptr inbounds ([720 x [480 x float]], [720 x [480 x float]]* @pb_y1, i64 0, i64 0), i64 %205, !dbg !290
  %207 = sext i32 %.516 to i64, !dbg !290
  %208 = getelementptr inbounds [480 x float], [480 x float]* %206, i64 0, i64 %207, !dbg !290
  %209 = load float, float* %208, align 4, !dbg !290
  %210 = sext i32 %.5 to i64, !dbg !291
  %211 = getelementptr inbounds [480 x float], [480 x float]* getelementptr inbounds ([720 x [480 x float]], [720 x [480 x float]]* @y2, i64 0, i64 0), i64 %210, !dbg !291
  %212 = sext i32 %.516 to i64, !dbg !291
  %213 = getelementptr inbounds [480 x float], [480 x float]* %211, i64 0, i64 %212, !dbg !291
  %214 = load float, float* %213, align 4, !dbg !291
  %215 = fadd float %209, %214, !dbg !292
  %216 = fmul float 1.000000e+00, %215, !dbg !293
  %217 = sext i32 %.5 to i64, !dbg !294
  %218 = getelementptr inbounds [480 x float], [480 x float]* getelementptr inbounds ([720 x [480 x float]], [720 x [480 x float]]* @imgOut, i64 0, i64 0), i64 %217, !dbg !294
  %219 = sext i32 %.516 to i64, !dbg !294
  %220 = getelementptr inbounds [480 x float], [480 x float]* %218, i64 0, i64 %219, !dbg !294
  store float %216, float* %220, align 4, !dbg !295
  %221 = add nsw i32 %.516, 1, !dbg !296
  call void @llvm.dbg.value(metadata i32 %221, metadata !110, metadata !DIExpression()), !dbg !53
  br label %202, !dbg !297, !llvm.loop !298

222:                                              ; preds = %202
  %223 = add nsw i32 %.5, 1, !dbg !300
  call void @llvm.dbg.value(metadata i32 %223, metadata !100, metadata !DIExpression()), !dbg !53
  br label %199, !dbg !301, !llvm.loop !302

224:                                              ; preds = %199
  ret i32 0, !dbg !304
}

; Function Attrs: nounwind
declare float @expf(float noundef) #1

; Function Attrs: nounwind
declare float @powf(float noundef, float noundef) #1

; Function Attrs: nofree nosync nounwind readnone speculatable willreturn
declare void @llvm.dbg.value(metadata, metadata, metadata) #2

attributes #0 = { noinline nounwind uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { nounwind "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #2 = { nofree nosync nounwind readnone speculatable willreturn }
attributes #3 = { nounwind }

!llvm.dbg.cu = !{!2}
!llvm.module.flags = !{!27, !28, !29, !30, !31, !32, !33}
!llvm.ident = !{!34}

!0 = !DIGlobalVariableExpression(var: !1, expr: !DIExpression())
!1 = distinct !DIGlobalVariable(name: "w", scope: !2, file: !11, line: 172, type: !12, isLocal: false, isDefinition: true)
!2 = distinct !DICompileUnit(language: DW_LANG_C99, file: !3, producer: "Ubuntu clang version 14.0.0-1ubuntu1.1", isOptimized: false, runtimeVersion: 0, emissionKind: FullDebug, retainedTypes: !4, globals: !8, splitDebugInlining: false, nameTableKind: None)
!3 = !DIFile(filename: "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/triangular-20260929/suite/deriche/source/workload.c", directory: "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/triangular-20260929/suite/deriche/analysis-g", checksumkind: CSK_MD5, checksum: "be46e5ab31cb7a5e1325f0c6a0cfccce")
!4 = !{!5, !6, !7}
!5 = !DIBasicType(name: "float", size: 32, encoding: DW_ATE_float)
!6 = !DIBasicType(name: "unsigned int", size: 32, encoding: DW_ATE_unsigned)
!7 = !DIBasicType(name: "unsigned char", size: 8, encoding: DW_ATE_unsigned_char)
!8 = !{!0, !9, !13, !19, !21, !23, !25}
!9 = !DIGlobalVariableExpression(var: !10, expr: !DIExpression())
!10 = distinct !DIGlobalVariable(name: "h", scope: !2, file: !11, line: 173, type: !12, isLocal: false, isDefinition: true)
!11 = !DIFile(filename: "source/workload.c", directory: "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/triangular-20260929/suite/deriche", checksumkind: CSK_MD5, checksum: "be46e5ab31cb7a5e1325f0c6a0cfccce")
!12 = !DIBasicType(name: "int", size: 32, encoding: DW_ATE_signed)
!13 = !DIGlobalVariableExpression(var: !14, expr: !DIExpression())
!14 = distinct !DIGlobalVariable(name: "imgIn", scope: !2, file: !11, line: 34, type: !15, isLocal: false, isDefinition: true, align: 512)
!15 = !DICompositeType(tag: DW_TAG_array_type, baseType: !5, size: 11059200, elements: !16)
!16 = !{!17, !18}
!17 = !DISubrange(count: 720)
!18 = !DISubrange(count: 480)
!19 = !DIGlobalVariableExpression(var: !20, expr: !DIExpression())
!20 = distinct !DIGlobalVariable(name: "imgOut", scope: !2, file: !11, line: 35, type: !15, isLocal: false, isDefinition: true, align: 512)
!21 = !DIGlobalVariableExpression(var: !22, expr: !DIExpression())
!22 = distinct !DIGlobalVariable(name: "pb_y1", scope: !2, file: !11, line: 36, type: !15, isLocal: false, isDefinition: true, align: 512)
!23 = !DIGlobalVariableExpression(var: !24, expr: !DIExpression())
!24 = distinct !DIGlobalVariable(name: "y2", scope: !2, file: !11, line: 37, type: !15, isLocal: false, isDefinition: true, align: 512)
!25 = !DIGlobalVariableExpression(var: !26, expr: !DIExpression())
!26 = distinct !DIGlobalVariable(name: "alpha", scope: !2, file: !11, line: 176, type: !5, isLocal: false, isDefinition: true)
!27 = !{i32 7, !"Dwarf Version", i32 5}
!28 = !{i32 2, !"Debug Info Version", i32 3}
!29 = !{i32 1, !"wchar_size", i32 4}
!30 = !{i32 7, !"PIC Level", i32 2}
!31 = !{i32 7, !"PIE Level", i32 2}
!32 = !{i32 7, !"uwtable", i32 1}
!33 = !{i32 7, !"frame-pointer", i32 2}
!34 = !{!"Ubuntu clang version 14.0.0-1ubuntu1.1"}
!35 = distinct !DISubprogram(name: "task_job_polybench", scope: !11, file: !11, line: 186, type: !36, scopeLine: 186, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !2, retainedNodes: !42)
!36 = !DISubroutineType(types: !37)
!37 = !{!38}
!38 = !DIDerivedType(tag: DW_TAG_typedef, name: "uint32_t", file: !39, line: 26, baseType: !40)
!39 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/stdint-uintn.h", directory: "", checksumkind: CSK_MD5, checksum: "2bf2ae53c58c01b1a1b9383b5195125c")
!40 = !DIDerivedType(tag: DW_TAG_typedef, name: "__uint32_t", file: !41, line: 42, baseType: !6)
!41 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/types.h", directory: "", checksumkind: CSK_MD5, checksum: "d108b5f93a74c50510d7d9bc0ab36df9")
!42 = !{}
!43 = !DILocation(line: 187, column: 19, scope: !35)
!44 = !DILocation(line: 187, column: 22, scope: !35)
!45 = !DILocation(line: 187, column: 25, scope: !35)
!46 = !DILocalVariable(name: "w", arg: 1, scope: !47, file: !11, line: 80, type: !12)
!47 = distinct !DISubprogram(name: "kernel_deriche", scope: !11, file: !11, line: 80, type: !48, scopeLine: 84, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition, unit: !2, retainedNodes: !42)
!48 = !DISubroutineType(types: !49)
!49 = !{null, !12, !12, !5, !50, !50, !50, !50}
!50 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !51, size: 64)
!51 = !DICompositeType(tag: DW_TAG_array_type, baseType: !5, size: 15360, elements: !52)
!52 = !{!18}
!53 = !DILocation(line: 0, scope: !47, inlinedAt: !54)
!54 = distinct !DILocation(line: 187, column: 3, scope: !35)
!55 = !DILocalVariable(name: "h", arg: 2, scope: !47, file: !11, line: 80, type: !12)
!56 = !DILocalVariable(name: "alpha", arg: 3, scope: !47, file: !11, line: 80, type: !5)
!57 = !DILocalVariable(name: "imgIn", arg: 4, scope: !47, file: !11, line: 81, type: !50)
!58 = !DILocalVariable(name: "imgOut", arg: 5, scope: !47, file: !11, line: 82, type: !50)
!59 = !DILocalVariable(name: "pb_y1", arg: 6, scope: !47, file: !11, line: 83, type: !50)
!60 = !DILocalVariable(name: "y2", arg: 7, scope: !47, file: !11, line: 84, type: !50)
!61 = !DILocation(line: 96, column: 25, scope: !47, inlinedAt: !54)
!62 = !DILocation(line: 96, column: 24, scope: !47, inlinedAt: !54)
!63 = !DILocation(line: 96, column: 59, scope: !47, inlinedAt: !54)
!64 = !DILocation(line: 96, column: 58, scope: !47, inlinedAt: !54)
!65 = !DILocation(line: 96, column: 41, scope: !47, inlinedAt: !54)
!66 = !DILocation(line: 96, column: 108, scope: !47, inlinedAt: !54)
!67 = !DILocation(line: 96, column: 115, scope: !47, inlinedAt: !54)
!68 = !DILocation(line: 96, column: 114, scope: !47, inlinedAt: !54)
!69 = !DILocation(line: 96, column: 92, scope: !47, inlinedAt: !54)
!70 = !DILocation(line: 96, column: 131, scope: !47, inlinedAt: !54)
!71 = !DILocation(line: 96, column: 130, scope: !47, inlinedAt: !54)
!72 = !DILocation(line: 96, column: 75, scope: !47, inlinedAt: !54)
!73 = !DILocalVariable(name: "k", scope: !47, file: !11, line: 91, type: !5)
!74 = !DILocalVariable(name: "a5", scope: !47, file: !11, line: 92, type: !5)
!75 = !DILocalVariable(name: "a1", scope: !47, file: !11, line: 92, type: !5)
!76 = !DILocation(line: 98, column: 16, scope: !47, inlinedAt: !54)
!77 = !DILocation(line: 98, column: 15, scope: !47, inlinedAt: !54)
!78 = !DILocation(line: 98, column: 38, scope: !47, inlinedAt: !54)
!79 = !DILocation(line: 98, column: 31, scope: !47, inlinedAt: !54)
!80 = !DILocalVariable(name: "a6", scope: !47, file: !11, line: 92, type: !5)
!81 = !DILocalVariable(name: "a2", scope: !47, file: !11, line: 92, type: !5)
!82 = !DILocation(line: 99, column: 16, scope: !47, inlinedAt: !54)
!83 = !DILocation(line: 99, column: 15, scope: !47, inlinedAt: !54)
!84 = !DILocation(line: 99, column: 38, scope: !47, inlinedAt: !54)
!85 = !DILocation(line: 99, column: 31, scope: !47, inlinedAt: !54)
!86 = !DILocalVariable(name: "a7", scope: !47, file: !11, line: 92, type: !5)
!87 = !DILocalVariable(name: "a3", scope: !47, file: !11, line: 92, type: !5)
!88 = !DILocation(line: 100, column: 14, scope: !47, inlinedAt: !54)
!89 = !DILocation(line: 100, column: 17, scope: !47, inlinedAt: !54)
!90 = !DILocation(line: 100, column: 16, scope: !47, inlinedAt: !54)
!91 = !DILocalVariable(name: "a8", scope: !47, file: !11, line: 92, type: !5)
!92 = !DILocalVariable(name: "a4", scope: !47, file: !11, line: 92, type: !5)
!93 = !DILocation(line: 101, column: 10, scope: !47, inlinedAt: !54)
!94 = !DILocalVariable(name: "b1", scope: !47, file: !11, line: 93, type: !5)
!95 = !DILocation(line: 102, column: 10, scope: !47, inlinedAt: !54)
!96 = !DILocation(line: 102, column: 9, scope: !47, inlinedAt: !54)
!97 = !DILocalVariable(name: "b2", scope: !47, file: !11, line: 93, type: !5)
!98 = !DILocalVariable(name: "c2", scope: !47, file: !11, line: 93, type: !5)
!99 = !DILocalVariable(name: "c1", scope: !47, file: !11, line: 93, type: !5)
!100 = !DILocalVariable(name: "i", scope: !47, file: !11, line: 85, type: !12)
!101 = !DILocation(line: 105, column: 9, scope: !102, inlinedAt: !54)
!102 = distinct !DILexicalBlock(scope: !47, file: !11, line: 105, column: 4)
!103 = !DILocation(line: 0, scope: !102, inlinedAt: !54)
!104 = !DILocation(line: 105, column: 15, scope: !105, inlinedAt: !54)
!105 = distinct !DILexicalBlock(scope: !102, file: !11, line: 105, column: 4)
!106 = !DILocation(line: 105, column: 4, scope: !102, inlinedAt: !54)
!107 = !DILocalVariable(name: "ym1", scope: !47, file: !11, line: 86, type: !5)
!108 = !DILocalVariable(name: "ym2", scope: !47, file: !11, line: 86, type: !5)
!109 = !DILocalVariable(name: "xm1", scope: !47, file: !11, line: 86, type: !5)
!110 = !DILocalVariable(name: "j", scope: !47, file: !11, line: 85, type: !12)
!111 = !DILocation(line: 109, column: 14, scope: !112, inlinedAt: !54)
!112 = distinct !DILexicalBlock(scope: !113, file: !11, line: 109, column: 9)
!113 = distinct !DILexicalBlock(scope: !105, file: !11, line: 105, column: 28)
!114 = !DILocation(line: 0, scope: !113, inlinedAt: !54)
!115 = !DILocation(line: 0, scope: !112, inlinedAt: !54)
!116 = !DILocation(line: 109, column: 20, scope: !117, inlinedAt: !54)
!117 = distinct !DILexicalBlock(scope: !112, file: !11, line: 109, column: 9)
!118 = !DILocation(line: 109, column: 9, scope: !112, inlinedAt: !54)
!119 = !DILocation(line: 110, column: 27, scope: !120, inlinedAt: !54)
!120 = distinct !DILexicalBlock(scope: !117, file: !11, line: 109, column: 33)
!121 = !DILocation(line: 110, column: 26, scope: !120, inlinedAt: !54)
!122 = !DILocation(line: 110, column: 43, scope: !120, inlinedAt: !54)
!123 = !DILocation(line: 110, column: 39, scope: !120, inlinedAt: !54)
!124 = !DILocation(line: 110, column: 52, scope: !120, inlinedAt: !54)
!125 = !DILocation(line: 110, column: 48, scope: !120, inlinedAt: !54)
!126 = !DILocation(line: 110, column: 61, scope: !120, inlinedAt: !54)
!127 = !DILocation(line: 110, column: 57, scope: !120, inlinedAt: !54)
!128 = !DILocation(line: 110, column: 13, scope: !120, inlinedAt: !54)
!129 = !DILocation(line: 110, column: 22, scope: !120, inlinedAt: !54)
!130 = !DILocation(line: 111, column: 19, scope: !120, inlinedAt: !54)
!131 = !DILocation(line: 113, column: 19, scope: !120, inlinedAt: !54)
!132 = !DILocation(line: 109, column: 29, scope: !117, inlinedAt: !54)
!133 = !DILocation(line: 109, column: 9, scope: !117, inlinedAt: !54)
!134 = distinct !{!134, !118, !135, !136}
!135 = !DILocation(line: 114, column: 9, scope: !112, inlinedAt: !54)
!136 = !{!"llvm.loop.mustprogress"}
!137 = !DILocation(line: 105, column: 24, scope: !105, inlinedAt: !54)
!138 = !DILocation(line: 105, column: 4, scope: !105, inlinedAt: !54)
!139 = distinct !{!139, !106, !140, !136}
!140 = !DILocation(line: 115, column: 5, scope: !102, inlinedAt: !54)
!141 = !DILocation(line: 117, column: 10, scope: !142, inlinedAt: !54)
!142 = distinct !DILexicalBlock(scope: !47, file: !11, line: 117, column: 5)
!143 = !DILocation(line: 0, scope: !142, inlinedAt: !54)
!144 = !DILocation(line: 117, column: 16, scope: !145, inlinedAt: !54)
!145 = distinct !DILexicalBlock(scope: !142, file: !11, line: 117, column: 5)
!146 = !DILocation(line: 117, column: 5, scope: !142, inlinedAt: !54)
!147 = !DILocalVariable(name: "yp1", scope: !47, file: !11, line: 89, type: !5)
!148 = !DILocalVariable(name: "yp2", scope: !47, file: !11, line: 89, type: !5)
!149 = !DILocalVariable(name: "xp1", scope: !47, file: !11, line: 87, type: !5)
!150 = !DILocalVariable(name: "xp2", scope: !47, file: !11, line: 87, type: !5)
!151 = !DILocation(line: 122, column: 14, scope: !152, inlinedAt: !54)
!152 = distinct !DILexicalBlock(scope: !153, file: !11, line: 122, column: 9)
!153 = distinct !DILexicalBlock(scope: !145, file: !11, line: 117, column: 29)
!154 = !DILocation(line: 0, scope: !152, inlinedAt: !54)
!155 = !DILocation(line: 0, scope: !153, inlinedAt: !54)
!156 = !DILocation(line: 122, column: 26, scope: !157, inlinedAt: !54)
!157 = distinct !DILexicalBlock(scope: !152, file: !11, line: 122, column: 9)
!158 = !DILocation(line: 122, column: 9, scope: !152, inlinedAt: !54)
!159 = !DILocation(line: 123, column: 26, scope: !160, inlinedAt: !54)
!160 = distinct !DILexicalBlock(scope: !157, file: !11, line: 122, column: 36)
!161 = !DILocation(line: 123, column: 35, scope: !160, inlinedAt: !54)
!162 = !DILocation(line: 123, column: 31, scope: !160, inlinedAt: !54)
!163 = !DILocation(line: 123, column: 44, scope: !160, inlinedAt: !54)
!164 = !DILocation(line: 123, column: 40, scope: !160, inlinedAt: !54)
!165 = !DILocation(line: 123, column: 53, scope: !160, inlinedAt: !54)
!166 = !DILocation(line: 123, column: 49, scope: !160, inlinedAt: !54)
!167 = !DILocation(line: 123, column: 13, scope: !160, inlinedAt: !54)
!168 = !DILocation(line: 123, column: 22, scope: !160, inlinedAt: !54)
!169 = !DILocation(line: 125, column: 19, scope: !160, inlinedAt: !54)
!170 = !DILocation(line: 127, column: 19, scope: !160, inlinedAt: !54)
!171 = !DILocation(line: 122, column: 32, scope: !157, inlinedAt: !54)
!172 = !DILocation(line: 122, column: 9, scope: !157, inlinedAt: !54)
!173 = distinct !{!173, !158, !174, !136}
!174 = !DILocation(line: 128, column: 9, scope: !152, inlinedAt: !54)
!175 = !DILocation(line: 117, column: 25, scope: !145, inlinedAt: !54)
!176 = !DILocation(line: 117, column: 5, scope: !145, inlinedAt: !54)
!177 = distinct !{!177, !146, !178, !136}
!178 = !DILocation(line: 129, column: 5, scope: !142, inlinedAt: !54)
!179 = !DILocation(line: 131, column: 10, scope: !180, inlinedAt: !54)
!180 = distinct !DILexicalBlock(scope: !47, file: !11, line: 131, column: 5)
!181 = !DILocation(line: 0, scope: !180, inlinedAt: !54)
!182 = !DILocation(line: 131, column: 16, scope: !183, inlinedAt: !54)
!183 = distinct !DILexicalBlock(scope: !180, file: !11, line: 131, column: 5)
!184 = !DILocation(line: 131, column: 5, scope: !180, inlinedAt: !54)
!185 = !DILocation(line: 132, column: 14, scope: !186, inlinedAt: !54)
!186 = distinct !DILexicalBlock(scope: !183, file: !11, line: 132, column: 9)
!187 = !DILocation(line: 0, scope: !186, inlinedAt: !54)
!188 = !DILocation(line: 132, column: 20, scope: !189, inlinedAt: !54)
!189 = distinct !DILexicalBlock(scope: !186, file: !11, line: 132, column: 9)
!190 = !DILocation(line: 132, column: 9, scope: !186, inlinedAt: !54)
!191 = !DILocation(line: 133, column: 34, scope: !192, inlinedAt: !54)
!192 = distinct !DILexicalBlock(scope: !189, file: !11, line: 132, column: 33)
!193 = !DILocation(line: 133, column: 45, scope: !192, inlinedAt: !54)
!194 = !DILocation(line: 133, column: 43, scope: !192, inlinedAt: !54)
!195 = !DILocation(line: 133, column: 31, scope: !192, inlinedAt: !54)
!196 = !DILocation(line: 133, column: 13, scope: !192, inlinedAt: !54)
!197 = !DILocation(line: 133, column: 26, scope: !192, inlinedAt: !54)
!198 = !DILocation(line: 132, column: 29, scope: !189, inlinedAt: !54)
!199 = !DILocation(line: 132, column: 9, scope: !189, inlinedAt: !54)
!200 = distinct !{!200, !190, !201, !136}
!201 = !DILocation(line: 134, column: 9, scope: !186, inlinedAt: !54)
!202 = !DILocation(line: 131, column: 25, scope: !183, inlinedAt: !54)
!203 = !DILocation(line: 131, column: 5, scope: !183, inlinedAt: !54)
!204 = distinct !{!204, !184, !205, !136}
!205 = !DILocation(line: 134, column: 9, scope: !180, inlinedAt: !54)
!206 = !DILocation(line: 136, column: 10, scope: !207, inlinedAt: !54)
!207 = distinct !DILexicalBlock(scope: !47, file: !11, line: 136, column: 5)
!208 = !DILocation(line: 0, scope: !207, inlinedAt: !54)
!209 = !DILocation(line: 136, column: 16, scope: !210, inlinedAt: !54)
!210 = distinct !DILexicalBlock(scope: !207, file: !11, line: 136, column: 5)
!211 = !DILocation(line: 136, column: 5, scope: !207, inlinedAt: !54)
!212 = !DILocalVariable(name: "tm1", scope: !47, file: !11, line: 86, type: !5)
!213 = !DILocation(line: 140, column: 14, scope: !214, inlinedAt: !54)
!214 = distinct !DILexicalBlock(scope: !215, file: !11, line: 140, column: 9)
!215 = distinct !DILexicalBlock(scope: !210, file: !11, line: 136, column: 29)
!216 = !DILocation(line: 0, scope: !215, inlinedAt: !54)
!217 = !DILocation(line: 0, scope: !214, inlinedAt: !54)
!218 = !DILocation(line: 140, column: 20, scope: !219, inlinedAt: !54)
!219 = distinct !DILexicalBlock(scope: !214, file: !11, line: 140, column: 9)
!220 = !DILocation(line: 140, column: 9, scope: !214, inlinedAt: !54)
!221 = !DILocation(line: 141, column: 27, scope: !222, inlinedAt: !54)
!222 = distinct !DILexicalBlock(scope: !219, file: !11, line: 140, column: 33)
!223 = !DILocation(line: 141, column: 26, scope: !222, inlinedAt: !54)
!224 = !DILocation(line: 141, column: 44, scope: !222, inlinedAt: !54)
!225 = !DILocation(line: 141, column: 40, scope: !222, inlinedAt: !54)
!226 = !DILocation(line: 141, column: 53, scope: !222, inlinedAt: !54)
!227 = !DILocation(line: 141, column: 49, scope: !222, inlinedAt: !54)
!228 = !DILocation(line: 141, column: 62, scope: !222, inlinedAt: !54)
!229 = !DILocation(line: 141, column: 58, scope: !222, inlinedAt: !54)
!230 = !DILocation(line: 141, column: 13, scope: !222, inlinedAt: !54)
!231 = !DILocation(line: 141, column: 22, scope: !222, inlinedAt: !54)
!232 = !DILocation(line: 142, column: 19, scope: !222, inlinedAt: !54)
!233 = !DILocation(line: 144, column: 19, scope: !222, inlinedAt: !54)
!234 = !DILocation(line: 140, column: 29, scope: !219, inlinedAt: !54)
!235 = !DILocation(line: 140, column: 9, scope: !219, inlinedAt: !54)
!236 = distinct !{!236, !220, !237, !136}
!237 = !DILocation(line: 145, column: 9, scope: !214, inlinedAt: !54)
!238 = !DILocation(line: 136, column: 25, scope: !210, inlinedAt: !54)
!239 = !DILocation(line: 136, column: 5, scope: !210, inlinedAt: !54)
!240 = distinct !{!240, !211, !241, !136}
!241 = !DILocation(line: 146, column: 5, scope: !207, inlinedAt: !54)
!242 = !DILocation(line: 149, column: 10, scope: !243, inlinedAt: !54)
!243 = distinct !DILexicalBlock(scope: !47, file: !11, line: 149, column: 5)
!244 = !DILocation(line: 0, scope: !243, inlinedAt: !54)
!245 = !DILocation(line: 149, column: 16, scope: !246, inlinedAt: !54)
!246 = distinct !DILexicalBlock(scope: !243, file: !11, line: 149, column: 5)
!247 = !DILocation(line: 149, column: 5, scope: !243, inlinedAt: !54)
!248 = !DILocalVariable(name: "tp1", scope: !47, file: !11, line: 88, type: !5)
!249 = !DILocalVariable(name: "tp2", scope: !47, file: !11, line: 88, type: !5)
!250 = !DILocation(line: 154, column: 14, scope: !251, inlinedAt: !54)
!251 = distinct !DILexicalBlock(scope: !252, file: !11, line: 154, column: 9)
!252 = distinct !DILexicalBlock(scope: !246, file: !11, line: 149, column: 29)
!253 = !DILocation(line: 0, scope: !251, inlinedAt: !54)
!254 = !DILocation(line: 0, scope: !252, inlinedAt: !54)
!255 = !DILocation(line: 154, column: 26, scope: !256, inlinedAt: !54)
!256 = distinct !DILexicalBlock(scope: !251, file: !11, line: 154, column: 9)
!257 = !DILocation(line: 154, column: 9, scope: !251, inlinedAt: !54)
!258 = !DILocation(line: 155, column: 26, scope: !259, inlinedAt: !54)
!259 = distinct !DILexicalBlock(scope: !256, file: !11, line: 154, column: 36)
!260 = !DILocation(line: 155, column: 35, scope: !259, inlinedAt: !54)
!261 = !DILocation(line: 155, column: 31, scope: !259, inlinedAt: !54)
!262 = !DILocation(line: 155, column: 44, scope: !259, inlinedAt: !54)
!263 = !DILocation(line: 155, column: 40, scope: !259, inlinedAt: !54)
!264 = !DILocation(line: 155, column: 53, scope: !259, inlinedAt: !54)
!265 = !DILocation(line: 155, column: 49, scope: !259, inlinedAt: !54)
!266 = !DILocation(line: 155, column: 13, scope: !259, inlinedAt: !54)
!267 = !DILocation(line: 155, column: 22, scope: !259, inlinedAt: !54)
!268 = !DILocation(line: 157, column: 19, scope: !259, inlinedAt: !54)
!269 = !DILocation(line: 159, column: 19, scope: !259, inlinedAt: !54)
!270 = !DILocation(line: 154, column: 32, scope: !256, inlinedAt: !54)
!271 = !DILocation(line: 154, column: 9, scope: !256, inlinedAt: !54)
!272 = distinct !{!272, !257, !273, !136}
!273 = !DILocation(line: 160, column: 9, scope: !251, inlinedAt: !54)
!274 = !DILocation(line: 149, column: 25, scope: !246, inlinedAt: !54)
!275 = !DILocation(line: 149, column: 5, scope: !246, inlinedAt: !54)
!276 = distinct !{!276, !247, !277, !136}
!277 = !DILocation(line: 161, column: 5, scope: !243, inlinedAt: !54)
!278 = !DILocation(line: 163, column: 10, scope: !279, inlinedAt: !54)
!279 = distinct !DILexicalBlock(scope: !47, file: !11, line: 163, column: 5)
!280 = !DILocation(line: 0, scope: !279, inlinedAt: !54)
!281 = !DILocation(line: 163, column: 16, scope: !282, inlinedAt: !54)
!282 = distinct !DILexicalBlock(scope: !279, file: !11, line: 163, column: 5)
!283 = !DILocation(line: 163, column: 5, scope: !279, inlinedAt: !54)
!284 = !DILocation(line: 164, column: 14, scope: !285, inlinedAt: !54)
!285 = distinct !DILexicalBlock(scope: !282, file: !11, line: 164, column: 9)
!286 = !DILocation(line: 0, scope: !285, inlinedAt: !54)
!287 = !DILocation(line: 164, column: 20, scope: !288, inlinedAt: !54)
!288 = distinct !DILexicalBlock(scope: !285, file: !11, line: 164, column: 9)
!289 = !DILocation(line: 164, column: 9, scope: !285, inlinedAt: !54)
!290 = !DILocation(line: 165, column: 32, scope: !288, inlinedAt: !54)
!291 = !DILocation(line: 165, column: 43, scope: !288, inlinedAt: !54)
!292 = !DILocation(line: 165, column: 41, scope: !288, inlinedAt: !54)
!293 = !DILocation(line: 165, column: 30, scope: !288, inlinedAt: !54)
!294 = !DILocation(line: 165, column: 13, scope: !288, inlinedAt: !54)
!295 = !DILocation(line: 165, column: 26, scope: !288, inlinedAt: !54)
!296 = !DILocation(line: 164, column: 29, scope: !288, inlinedAt: !54)
!297 = !DILocation(line: 164, column: 9, scope: !288, inlinedAt: !54)
!298 = distinct !{!298, !289, !299, !136}
!299 = !DILocation(line: 165, column: 51, scope: !285, inlinedAt: !54)
!300 = !DILocation(line: 163, column: 25, scope: !282, inlinedAt: !54)
!301 = !DILocation(line: 163, column: 5, scope: !282, inlinedAt: !54)
!302 = distinct !{!302, !283, !303, !136}
!303 = !DILocation(line: 165, column: 51, scope: !279, inlinedAt: !54)
!304 = !DILocation(line: 188, column: 3, scope: !35)
