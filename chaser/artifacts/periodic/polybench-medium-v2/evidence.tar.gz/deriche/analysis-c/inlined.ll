; ModuleID = 'workload.ll'
source_filename = "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/triangular-20260929/suite/deriche/source/workload.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

%struct._IO_FILE = type { i32, i8*, i8*, i8*, i8*, i8*, i8*, i8*, i8*, i8*, i8*, i8*, %struct._IO_marker*, %struct._IO_FILE*, i32, i32, i64, i16, i8, [1 x i8], i8*, i64, %struct._IO_codecvt*, %struct._IO_wide_data*, %struct._IO_FILE*, i8*, i64, i32, [20 x i8] }
%struct._IO_marker = type opaque
%struct._IO_codecvt = type opaque
%struct._IO_wide_data = type opaque
%struct.__va_list_tag = type { i32, i32, i8*, i8* }

@w = dso_local global i32 720, align 4, !dbg !0
@h = dso_local global i32 480, align 4, !dbg !9
@imgIn = dso_local global [720 x [480 x float]] zeroinitializer, section ".chaser_data.imgIn", align 64, !dbg !33
@imgOut = dso_local global [720 x [480 x float]] zeroinitializer, section ".chaser_data.imgOut", align 64, !dbg !39
@pb_y1 = dso_local global [720 x [480 x float]] zeroinitializer, section ".chaser_data.y1", align 64, !dbg !41
@y2 = dso_local global [720 x [480 x float]] zeroinitializer, section ".chaser_data.y2", align 64, !dbg !43
@alpha = dso_local global float 0.000000e+00, align 4, !dbg !45
@.str = private unnamed_addr constant [12 x i8] c"ape.analyze\00", section "llvm.metadata"
@.str.1 = private unnamed_addr constant [122 x i8] c"/workspace/experiments-array-support/chaser/.cache/periodic-polybench/triangular-20260929/suite/deriche/source/workload.c\00", section "llvm.metadata"
@pb_hash = internal global i32 0, align 4, !dbg !30
@workload_jobs = dso_local constant [1 x i32 ()*] [i32 ()* @task_job_polybench], align 8, !dbg !13
@workload_expected = dso_local constant [1 x i32] [i32 -297816044], align 4, !dbg !26
@stderr = external global %struct._IO_FILE*, align 8
@.str.2 = private unnamed_addr constant [23 x i8] c"==BEGIN DUMP_ARRAYS==\0A\00", align 1
@.str.3 = private unnamed_addr constant [15 x i8] c"begin dump: %s\00", align 1
@.str.4 = private unnamed_addr constant [7 x i8] c"imgOut\00", align 1
@.str.5 = private unnamed_addr constant [2 x i8] c"\0A\00", align 1
@.str.6 = private unnamed_addr constant [7 x i8] c"%0.2f \00", align 1
@.str.7 = private unnamed_addr constant [17 x i8] c"\0Aend   dump: %s\0A\00", align 1
@.str.8 = private unnamed_addr constant [23 x i8] c"==END   DUMP_ARRAYS==\0A\00", align 1
@pb_emit = internal global i32 1, align 4, !dbg !47
@llvm.global.annotations = appending global [1 x { i8*, i8*, i8*, i32, i8* }] [{ i8*, i8*, i8*, i32, i8* } { i8* bitcast (i32 ()* @task_job_polybench to i8*), i8* getelementptr inbounds ([12 x i8], [12 x i8]* @.str, i32 0, i32 0), i8* getelementptr inbounds ([122 x i8], [122 x i8]* @.str.1, i32 0, i32 0), i32 186, i8* null }], section "llvm.metadata"

; Function Attrs: noinline nounwind uwtable
define dso_local void @workload_prepare() #0 !dbg !57 {
  ret void, !dbg !61
}

; Function Attrs: noinline nounwind uwtable
define dso_local void @workload_reset(i32 noundef %0) #0 !dbg !62 {
  call void @llvm.dbg.value(metadata i32 %0, metadata !65, metadata !DIExpression()), !dbg !66
  call void @llvm.memset.p0i8.i64(i8* align 64 bitcast ([720 x [480 x float]]* @imgIn to i8*), i8 0, i64 1382400, i1 false), !dbg !67
  call void @llvm.memset.p0i8.i64(i8* align 64 bitcast ([720 x [480 x float]]* @imgOut to i8*), i8 0, i64 1382400, i1 false), !dbg !68
  call void @llvm.memset.p0i8.i64(i8* align 64 bitcast ([720 x [480 x float]]* @pb_y1 to i8*), i8 0, i64 1382400, i1 false), !dbg !69
  call void @llvm.memset.p0i8.i64(i8* align 64 bitcast ([720 x [480 x float]]* @y2 to i8*), i8 0, i64 1382400, i1 false), !dbg !70
  %2 = load i32, i32* @w, align 4, !dbg !71
  %3 = load i32, i32* @h, align 4, !dbg !72
  call void @init_array(i32 noundef %2, i32 noundef %3, float* noundef @alpha, [480 x float]* noundef getelementptr inbounds ([720 x [480 x float]], [720 x [480 x float]]* @imgIn, i64 0, i64 0), [480 x float]* noundef getelementptr inbounds ([720 x [480 x float]], [720 x [480 x float]]* @imgOut, i64 0, i64 0)), !dbg !73
  ret void, !dbg !74
}

; Function Attrs: nofree nosync nounwind readnone speculatable willreturn
declare void @llvm.dbg.declare(metadata, metadata, metadata) #1

; Function Attrs: argmemonly nofree nounwind willreturn writeonly
declare void @llvm.memset.p0i8.i64(i8* nocapture writeonly, i8, i64, i1 immarg) #2

; Function Attrs: noinline nounwind uwtable
define internal void @init_array(i32 noundef %0, i32 noundef %1, float* noundef %2, [480 x float]* noundef %3, [480 x float]* noundef %4) #0 !dbg !75 {
  call void @llvm.dbg.value(metadata i32 %0, metadata !82, metadata !DIExpression()), !dbg !83
  call void @llvm.dbg.value(metadata i32 %1, metadata !84, metadata !DIExpression()), !dbg !83
  call void @llvm.dbg.value(metadata float* %2, metadata !85, metadata !DIExpression()), !dbg !83
  call void @llvm.dbg.value(metadata [480 x float]* %3, metadata !86, metadata !DIExpression()), !dbg !83
  call void @llvm.dbg.value(metadata [480 x float]* %4, metadata !87, metadata !DIExpression()), !dbg !83
  store float 2.500000e-01, float* %2, align 4, !dbg !88
  call void @llvm.dbg.value(metadata i32 0, metadata !89, metadata !DIExpression()), !dbg !83
  br label %6, !dbg !90

6:                                                ; preds = %25, %5
  %.01 = phi i32 [ 0, %5 ], [ %26, %25 ], !dbg !92
  call void @llvm.dbg.value(metadata i32 %.01, metadata !89, metadata !DIExpression()), !dbg !83
  %7 = icmp slt i32 %.01, %0, !dbg !93
  br i1 %7, label %8, label %27, !dbg !95

8:                                                ; preds = %6
  call void @llvm.dbg.value(metadata i32 0, metadata !96, metadata !DIExpression()), !dbg !83
  br label %9, !dbg !97

9:                                                ; preds = %22, %8
  %.0 = phi i32 [ 0, %8 ], [ %23, %22 ], !dbg !99
  call void @llvm.dbg.value(metadata i32 %.0, metadata !96, metadata !DIExpression()), !dbg !83
  %10 = icmp slt i32 %.0, %1, !dbg !100
  br i1 %10, label %11, label %24, !dbg !102

11:                                               ; preds = %9
  %12 = mul nsw i32 313, %.01, !dbg !103
  %13 = mul nsw i32 991, %.0, !dbg !104
  %14 = add nsw i32 %12, %13, !dbg !105
  %15 = srem i32 %14, 65536, !dbg !106
  %16 = sitofp i32 %15 to float, !dbg !107
  %17 = fdiv float %16, 6.553500e+04, !dbg !108
  %18 = sext i32 %.01 to i64, !dbg !109
  %19 = getelementptr inbounds [480 x float], [480 x float]* %3, i64 %18, !dbg !109
  %20 = sext i32 %.0 to i64, !dbg !109
  %21 = getelementptr inbounds [480 x float], [480 x float]* %19, i64 0, i64 %20, !dbg !109
  store float %17, float* %21, align 4, !dbg !110
  br label %22, !dbg !109

22:                                               ; preds = %11
  %23 = add nsw i32 %.0, 1, !dbg !111
  call void @llvm.dbg.value(metadata i32 %23, metadata !96, metadata !DIExpression()), !dbg !83
  br label %9, !dbg !112, !llvm.loop !113

24:                                               ; preds = %9
  br label %25, !dbg !114

25:                                               ; preds = %24
  %26 = add nsw i32 %.01, 1, !dbg !116
  call void @llvm.dbg.value(metadata i32 %26, metadata !89, metadata !DIExpression()), !dbg !83
  br label %6, !dbg !117, !llvm.loop !118

27:                                               ; preds = %6
  ret void, !dbg !120
}

; Function Attrs: noinline nounwind uwtable
define dso_local i32 @task_job_polybench() #0 !dbg !121 {
  %1 = load i32, i32* @w, align 4, !dbg !122
  %2 = load i32, i32* @h, align 4, !dbg !123
  %3 = load float, float* @alpha, align 4, !dbg !124
  call void @llvm.dbg.value(metadata i32 %1, metadata !125, metadata !DIExpression()), !dbg !129
  call void @llvm.dbg.value(metadata i32 %2, metadata !131, metadata !DIExpression()), !dbg !129
  call void @llvm.dbg.value(metadata float %3, metadata !132, metadata !DIExpression()), !dbg !129
  call void @llvm.dbg.value(metadata [480 x float]* getelementptr inbounds ([720 x [480 x float]], [720 x [480 x float]]* @imgIn, i64 0, i64 0), metadata !133, metadata !DIExpression()), !dbg !129
  call void @llvm.dbg.value(metadata [480 x float]* getelementptr inbounds ([720 x [480 x float]], [720 x [480 x float]]* @imgOut, i64 0, i64 0), metadata !134, metadata !DIExpression()), !dbg !129
  call void @llvm.dbg.value(metadata [480 x float]* getelementptr inbounds ([720 x [480 x float]], [720 x [480 x float]]* @pb_y1, i64 0, i64 0), metadata !135, metadata !DIExpression()), !dbg !129
  call void @llvm.dbg.value(metadata [480 x float]* getelementptr inbounds ([720 x [480 x float]], [720 x [480 x float]]* @y2, i64 0, i64 0), metadata !136, metadata !DIExpression()), !dbg !129
  %4 = fneg float %3, !dbg !137
  %5 = call float @expf(float noundef %4) #6, !dbg !137
  %6 = fsub float 1.000000e+00, %5, !dbg !138
  %7 = fneg float %3, !dbg !139
  %8 = call float @expf(float noundef %7) #6, !dbg !139
  %9 = fsub float 1.000000e+00, %8, !dbg !140
  %10 = fmul float %6, %9, !dbg !141
  %11 = fmul float 2.000000e+00, %3, !dbg !142
  %12 = fneg float %3, !dbg !143
  %13 = call float @expf(float noundef %12) #6, !dbg !143
  %14 = fmul float %11, %13, !dbg !144
  %15 = fadd float 1.000000e+00, %14, !dbg !145
  %16 = fmul float 2.000000e+00, %3, !dbg !146
  %17 = call float @expf(float noundef %16) #6, !dbg !146
  %18 = fsub float %15, %17, !dbg !147
  %19 = fdiv float %10, %18, !dbg !148
  call void @llvm.dbg.value(metadata float %19, metadata !149, metadata !DIExpression()), !dbg !129
  call void @llvm.dbg.value(metadata float %19, metadata !150, metadata !DIExpression()), !dbg !129
  call void @llvm.dbg.value(metadata float %19, metadata !151, metadata !DIExpression()), !dbg !129
  %20 = fneg float %3, !dbg !152
  %21 = call float @expf(float noundef %20) #6, !dbg !152
  %22 = fmul float %19, %21, !dbg !153
  %23 = fsub float %3, 1.000000e+00, !dbg !154
  %24 = fmul float %22, %23, !dbg !155
  call void @llvm.dbg.value(metadata float %24, metadata !156, metadata !DIExpression()), !dbg !129
  call void @llvm.dbg.value(metadata float %24, metadata !157, metadata !DIExpression()), !dbg !129
  %25 = fneg float %3, !dbg !158
  %26 = call float @expf(float noundef %25) #6, !dbg !158
  %27 = fmul float %19, %26, !dbg !159
  %28 = fadd float %3, 1.000000e+00, !dbg !160
  %29 = fmul float %27, %28, !dbg !161
  call void @llvm.dbg.value(metadata float %29, metadata !162, metadata !DIExpression()), !dbg !129
  call void @llvm.dbg.value(metadata float %29, metadata !163, metadata !DIExpression()), !dbg !129
  %30 = fneg float %19, !dbg !164
  %31 = fmul float -2.000000e+00, %3, !dbg !165
  %32 = call float @expf(float noundef %31) #6, !dbg !165
  %33 = fmul float %30, %32, !dbg !166
  call void @llvm.dbg.value(metadata float %33, metadata !167, metadata !DIExpression()), !dbg !129
  call void @llvm.dbg.value(metadata float %33, metadata !168, metadata !DIExpression()), !dbg !129
  %34 = fneg float %3, !dbg !169
  %35 = call float @powf(float noundef 2.000000e+00, float noundef %34) #6, !dbg !169
  call void @llvm.dbg.value(metadata float %35, metadata !170, metadata !DIExpression()), !dbg !129
  %36 = fmul float -2.000000e+00, %3, !dbg !171
  %37 = call float @expf(float noundef %36) #6, !dbg !171
  %38 = fneg float %37, !dbg !172
  call void @llvm.dbg.value(metadata float %38, metadata !173, metadata !DIExpression()), !dbg !129
  call void @llvm.dbg.value(metadata float 1.000000e+00, metadata !174, metadata !DIExpression()), !dbg !129
  call void @llvm.dbg.value(metadata float 1.000000e+00, metadata !175, metadata !DIExpression()), !dbg !129
  call void @llvm.dbg.value(metadata i32 0, metadata !176, metadata !DIExpression()), !dbg !129
  br label %39, !dbg !177

39:                                               ; preds = %72, %0
  %.09 = phi i32 [ 0, %0 ], [ %73, %72 ], !dbg !179
  call void @llvm.dbg.value(metadata i32 %.09, metadata !176, metadata !DIExpression()), !dbg !129
  %40 = icmp slt i32 %.09, 720, !dbg !180
  br i1 %40, label %41, label %74, !dbg !182

41:                                               ; preds = %39
  call void @llvm.dbg.value(metadata float 0.000000e+00, metadata !183, metadata !DIExpression()), !dbg !129
  call void @llvm.dbg.value(metadata float 0.000000e+00, metadata !184, metadata !DIExpression()), !dbg !129
  call void @llvm.dbg.value(metadata float 0.000000e+00, metadata !185, metadata !DIExpression()), !dbg !129
  call void @llvm.dbg.value(metadata i32 0, metadata !186, metadata !DIExpression()), !dbg !129
  br label %42, !dbg !187

42:                                               ; preds = %44, %41
  %.019 = phi float [ 0.000000e+00, %41 ], [ %70, %44 ], !dbg !190
  %.017 = phi float [ 0.000000e+00, %41 ], [ %65, %44 ], !dbg !190
  %.011 = phi i32 [ 0, %41 ], [ %71, %44 ], !dbg !191
  %.07 = phi float [ 0.000000e+00, %41 ], [ %.019, %44 ], !dbg !190
  call void @llvm.dbg.value(metadata float %.07, metadata !184, metadata !DIExpression()), !dbg !129
  call void @llvm.dbg.value(metadata i32 %.011, metadata !186, metadata !DIExpression()), !dbg !129
  call void @llvm.dbg.value(metadata float %.017, metadata !185, metadata !DIExpression()), !dbg !129
  call void @llvm.dbg.value(metadata float %.019, metadata !183, metadata !DIExpression()), !dbg !129
  %43 = icmp slt i32 %.011, 480, !dbg !192
  br i1 %43, label %44, label %72, !dbg !194

44:                                               ; preds = %42
  %45 = sext i32 %.09 to i64, !dbg !195
  %46 = getelementptr inbounds [480 x float], [480 x float]* getelementptr inbounds ([720 x [480 x float]], [720 x [480 x float]]* @imgIn, i64 0, i64 0), i64 %45, !dbg !195
  %47 = sext i32 %.011 to i64, !dbg !195
  %48 = getelementptr inbounds [480 x float], [480 x float]* %46, i64 0, i64 %47, !dbg !195
  %49 = load float, float* %48, align 4, !dbg !195
  %50 = fmul float %19, %49, !dbg !197
  %51 = fmul float %24, %.017, !dbg !198
  %52 = fadd float %50, %51, !dbg !199
  %53 = fmul float %35, %.019, !dbg !200
  %54 = fadd float %52, %53, !dbg !201
  %55 = fmul float %38, %.07, !dbg !202
  %56 = fadd float %54, %55, !dbg !203
  %57 = sext i32 %.09 to i64, !dbg !204
  %58 = getelementptr inbounds [480 x float], [480 x float]* getelementptr inbounds ([720 x [480 x float]], [720 x [480 x float]]* @pb_y1, i64 0, i64 0), i64 %57, !dbg !204
  %59 = sext i32 %.011 to i64, !dbg !204
  %60 = getelementptr inbounds [480 x float], [480 x float]* %58, i64 0, i64 %59, !dbg !204
  store float %56, float* %60, align 4, !dbg !205
  %61 = sext i32 %.09 to i64, !dbg !206
  %62 = getelementptr inbounds [480 x float], [480 x float]* getelementptr inbounds ([720 x [480 x float]], [720 x [480 x float]]* @imgIn, i64 0, i64 0), i64 %61, !dbg !206
  %63 = sext i32 %.011 to i64, !dbg !206
  %64 = getelementptr inbounds [480 x float], [480 x float]* %62, i64 0, i64 %63, !dbg !206
  %65 = load float, float* %64, align 4, !dbg !206
  call void @llvm.dbg.value(metadata float %65, metadata !185, metadata !DIExpression()), !dbg !129
  call void @llvm.dbg.value(metadata float %.019, metadata !184, metadata !DIExpression()), !dbg !129
  %66 = sext i32 %.09 to i64, !dbg !207
  %67 = getelementptr inbounds [480 x float], [480 x float]* getelementptr inbounds ([720 x [480 x float]], [720 x [480 x float]]* @pb_y1, i64 0, i64 0), i64 %66, !dbg !207
  %68 = sext i32 %.011 to i64, !dbg !207
  %69 = getelementptr inbounds [480 x float], [480 x float]* %67, i64 0, i64 %68, !dbg !207
  %70 = load float, float* %69, align 4, !dbg !207
  call void @llvm.dbg.value(metadata float %70, metadata !183, metadata !DIExpression()), !dbg !129
  %71 = add nsw i32 %.011, 1, !dbg !208
  call void @llvm.dbg.value(metadata i32 %71, metadata !186, metadata !DIExpression()), !dbg !129
  br label %42, !dbg !209, !llvm.loop !210

72:                                               ; preds = %42
  %73 = add nsw i32 %.09, 1, !dbg !212
  call void @llvm.dbg.value(metadata i32 %73, metadata !176, metadata !DIExpression()), !dbg !129
  br label %39, !dbg !213, !llvm.loop !214

74:                                               ; preds = %39
  call void @llvm.dbg.value(metadata i32 0, metadata !176, metadata !DIExpression()), !dbg !129
  br label %75, !dbg !216

75:                                               ; preds = %103, %74
  %.110 = phi i32 [ 0, %74 ], [ %104, %103 ], !dbg !218
  call void @llvm.dbg.value(metadata i32 %.110, metadata !176, metadata !DIExpression()), !dbg !129
  %76 = icmp slt i32 %.110, 720, !dbg !219
  br i1 %76, label %77, label %105, !dbg !221

77:                                               ; preds = %75
  call void @llvm.dbg.value(metadata float 0.000000e+00, metadata !222, metadata !DIExpression()), !dbg !129
  call void @llvm.dbg.value(metadata float 0.000000e+00, metadata !223, metadata !DIExpression()), !dbg !129
  call void @llvm.dbg.value(metadata float 0.000000e+00, metadata !224, metadata !DIExpression()), !dbg !129
  call void @llvm.dbg.value(metadata float 0.000000e+00, metadata !225, metadata !DIExpression()), !dbg !129
  call void @llvm.dbg.value(metadata i32 479, metadata !186, metadata !DIExpression()), !dbg !129
  br label %78, !dbg !226

78:                                               ; preds = %80, %77
  %.112 = phi i32 [ 479, %77 ], [ %102, %80 ], !dbg !229
  %.06 = phi float [ 0.000000e+00, %77 ], [ %96, %80 ], !dbg !230
  %.05 = phi float [ 0.000000e+00, %77 ], [ %.06, %80 ], !dbg !230
  %.01 = phi float [ 0.000000e+00, %77 ], [ %101, %80 ], !dbg !230
  %.0 = phi float [ 0.000000e+00, %77 ], [ %.01, %80 ], !dbg !230
  call void @llvm.dbg.value(metadata float %.0, metadata !223, metadata !DIExpression()), !dbg !129
  call void @llvm.dbg.value(metadata float %.01, metadata !222, metadata !DIExpression()), !dbg !129
  call void @llvm.dbg.value(metadata float %.05, metadata !225, metadata !DIExpression()), !dbg !129
  call void @llvm.dbg.value(metadata float %.06, metadata !224, metadata !DIExpression()), !dbg !129
  call void @llvm.dbg.value(metadata i32 %.112, metadata !186, metadata !DIExpression()), !dbg !129
  %79 = icmp sge i32 %.112, 0, !dbg !231
  br i1 %79, label %80, label %103, !dbg !233

80:                                               ; preds = %78
  %81 = fmul float %29, %.06, !dbg !234
  %82 = fmul float %33, %.05, !dbg !236
  %83 = fadd float %81, %82, !dbg !237
  %84 = fmul float %35, %.01, !dbg !238
  %85 = fadd float %83, %84, !dbg !239
  %86 = fmul float %38, %.0, !dbg !240
  %87 = fadd float %85, %86, !dbg !241
  %88 = sext i32 %.110 to i64, !dbg !242
  %89 = getelementptr inbounds [480 x float], [480 x float]* getelementptr inbounds ([720 x [480 x float]], [720 x [480 x float]]* @y2, i64 0, i64 0), i64 %88, !dbg !242
  %90 = sext i32 %.112 to i64, !dbg !242
  %91 = getelementptr inbounds [480 x float], [480 x float]* %89, i64 0, i64 %90, !dbg !242
  store float %87, float* %91, align 4, !dbg !243
  call void @llvm.dbg.value(metadata float %.06, metadata !225, metadata !DIExpression()), !dbg !129
  %92 = sext i32 %.110 to i64, !dbg !244
  %93 = getelementptr inbounds [480 x float], [480 x float]* getelementptr inbounds ([720 x [480 x float]], [720 x [480 x float]]* @imgIn, i64 0, i64 0), i64 %92, !dbg !244
  %94 = sext i32 %.112 to i64, !dbg !244
  %95 = getelementptr inbounds [480 x float], [480 x float]* %93, i64 0, i64 %94, !dbg !244
  %96 = load float, float* %95, align 4, !dbg !244
  call void @llvm.dbg.value(metadata float %96, metadata !224, metadata !DIExpression()), !dbg !129
  call void @llvm.dbg.value(metadata float %.01, metadata !223, metadata !DIExpression()), !dbg !129
  %97 = sext i32 %.110 to i64, !dbg !245
  %98 = getelementptr inbounds [480 x float], [480 x float]* getelementptr inbounds ([720 x [480 x float]], [720 x [480 x float]]* @y2, i64 0, i64 0), i64 %97, !dbg !245
  %99 = sext i32 %.112 to i64, !dbg !245
  %100 = getelementptr inbounds [480 x float], [480 x float]* %98, i64 0, i64 %99, !dbg !245
  %101 = load float, float* %100, align 4, !dbg !245
  call void @llvm.dbg.value(metadata float %101, metadata !222, metadata !DIExpression()), !dbg !129
  %102 = add nsw i32 %.112, -1, !dbg !246
  call void @llvm.dbg.value(metadata i32 %102, metadata !186, metadata !DIExpression()), !dbg !129
  br label %78, !dbg !247, !llvm.loop !248

103:                                              ; preds = %78
  %104 = add nsw i32 %.110, 1, !dbg !250
  call void @llvm.dbg.value(metadata i32 %104, metadata !176, metadata !DIExpression()), !dbg !129
  br label %75, !dbg !251, !llvm.loop !252

105:                                              ; preds = %75
  call void @llvm.dbg.value(metadata i32 0, metadata !176, metadata !DIExpression()), !dbg !129
  br label %106, !dbg !254

106:                                              ; preds = %129, %105
  %.2 = phi i32 [ 0, %105 ], [ %130, %129 ], !dbg !256
  call void @llvm.dbg.value(metadata i32 %.2, metadata !176, metadata !DIExpression()), !dbg !129
  %107 = icmp slt i32 %.2, 720, !dbg !257
  br i1 %107, label %108, label %131, !dbg !259

108:                                              ; preds = %106
  call void @llvm.dbg.value(metadata i32 0, metadata !186, metadata !DIExpression()), !dbg !129
  br label %109, !dbg !260

109:                                              ; preds = %111, %108
  %.213 = phi i32 [ 0, %108 ], [ %128, %111 ], !dbg !262
  call void @llvm.dbg.value(metadata i32 %.213, metadata !186, metadata !DIExpression()), !dbg !129
  %110 = icmp slt i32 %.213, 480, !dbg !263
  br i1 %110, label %111, label %129, !dbg !265

111:                                              ; preds = %109
  %112 = sext i32 %.2 to i64, !dbg !266
  %113 = getelementptr inbounds [480 x float], [480 x float]* getelementptr inbounds ([720 x [480 x float]], [720 x [480 x float]]* @pb_y1, i64 0, i64 0), i64 %112, !dbg !266
  %114 = sext i32 %.213 to i64, !dbg !266
  %115 = getelementptr inbounds [480 x float], [480 x float]* %113, i64 0, i64 %114, !dbg !266
  %116 = load float, float* %115, align 4, !dbg !266
  %117 = sext i32 %.2 to i64, !dbg !268
  %118 = getelementptr inbounds [480 x float], [480 x float]* getelementptr inbounds ([720 x [480 x float]], [720 x [480 x float]]* @y2, i64 0, i64 0), i64 %117, !dbg !268
  %119 = sext i32 %.213 to i64, !dbg !268
  %120 = getelementptr inbounds [480 x float], [480 x float]* %118, i64 0, i64 %119, !dbg !268
  %121 = load float, float* %120, align 4, !dbg !268
  %122 = fadd float %116, %121, !dbg !269
  %123 = fmul float 1.000000e+00, %122, !dbg !270
  %124 = sext i32 %.2 to i64, !dbg !271
  %125 = getelementptr inbounds [480 x float], [480 x float]* getelementptr inbounds ([720 x [480 x float]], [720 x [480 x float]]* @imgOut, i64 0, i64 0), i64 %124, !dbg !271
  %126 = sext i32 %.213 to i64, !dbg !271
  %127 = getelementptr inbounds [480 x float], [480 x float]* %125, i64 0, i64 %126, !dbg !271
  store float %123, float* %127, align 4, !dbg !272
  %128 = add nsw i32 %.213, 1, !dbg !273
  call void @llvm.dbg.value(metadata i32 %128, metadata !186, metadata !DIExpression()), !dbg !129
  br label %109, !dbg !274, !llvm.loop !275

129:                                              ; preds = %109
  %130 = add nsw i32 %.2, 1, !dbg !277
  call void @llvm.dbg.value(metadata i32 %130, metadata !176, metadata !DIExpression()), !dbg !129
  br label %106, !dbg !278, !llvm.loop !279

131:                                              ; preds = %106
  call void @llvm.dbg.value(metadata i32 0, metadata !186, metadata !DIExpression()), !dbg !129
  br label %132, !dbg !281

132:                                              ; preds = %165, %131
  %.314 = phi i32 [ 0, %131 ], [ %166, %165 ], !dbg !283
  call void @llvm.dbg.value(metadata i32 %.314, metadata !186, metadata !DIExpression()), !dbg !129
  %133 = icmp slt i32 %.314, 480, !dbg !284
  br i1 %133, label %134, label %167, !dbg !286

134:                                              ; preds = %132
  call void @llvm.dbg.value(metadata float 0.000000e+00, metadata !287, metadata !DIExpression()), !dbg !129
  call void @llvm.dbg.value(metadata float 0.000000e+00, metadata !183, metadata !DIExpression()), !dbg !129
  call void @llvm.dbg.value(metadata float 0.000000e+00, metadata !184, metadata !DIExpression()), !dbg !129
  call void @llvm.dbg.value(metadata i32 0, metadata !176, metadata !DIExpression()), !dbg !129
  br label %135, !dbg !288

135:                                              ; preds = %137, %134
  %.120 = phi float [ 0.000000e+00, %134 ], [ %163, %137 ], !dbg !291
  %.018 = phi float [ 0.000000e+00, %134 ], [ %158, %137 ], !dbg !291
  %.3 = phi i32 [ 0, %134 ], [ %164, %137 ], !dbg !292
  %.18 = phi float [ 0.000000e+00, %134 ], [ %.120, %137 ], !dbg !291
  call void @llvm.dbg.value(metadata float %.18, metadata !184, metadata !DIExpression()), !dbg !129
  call void @llvm.dbg.value(metadata i32 %.3, metadata !176, metadata !DIExpression()), !dbg !129
  call void @llvm.dbg.value(metadata float %.018, metadata !287, metadata !DIExpression()), !dbg !129
  call void @llvm.dbg.value(metadata float %.120, metadata !183, metadata !DIExpression()), !dbg !129
  %136 = icmp slt i32 %.3, 720, !dbg !293
  br i1 %136, label %137, label %165, !dbg !295

137:                                              ; preds = %135
  %138 = sext i32 %.3 to i64, !dbg !296
  %139 = getelementptr inbounds [480 x float], [480 x float]* getelementptr inbounds ([720 x [480 x float]], [720 x [480 x float]]* @imgOut, i64 0, i64 0), i64 %138, !dbg !296
  %140 = sext i32 %.314 to i64, !dbg !296
  %141 = getelementptr inbounds [480 x float], [480 x float]* %139, i64 0, i64 %140, !dbg !296
  %142 = load float, float* %141, align 4, !dbg !296
  %143 = fmul float %19, %142, !dbg !298
  %144 = fmul float %24, %.018, !dbg !299
  %145 = fadd float %143, %144, !dbg !300
  %146 = fmul float %35, %.120, !dbg !301
  %147 = fadd float %145, %146, !dbg !302
  %148 = fmul float %38, %.18, !dbg !303
  %149 = fadd float %147, %148, !dbg !304
  %150 = sext i32 %.3 to i64, !dbg !305
  %151 = getelementptr inbounds [480 x float], [480 x float]* getelementptr inbounds ([720 x [480 x float]], [720 x [480 x float]]* @pb_y1, i64 0, i64 0), i64 %150, !dbg !305
  %152 = sext i32 %.314 to i64, !dbg !305
  %153 = getelementptr inbounds [480 x float], [480 x float]* %151, i64 0, i64 %152, !dbg !305
  store float %149, float* %153, align 4, !dbg !306
  %154 = sext i32 %.3 to i64, !dbg !307
  %155 = getelementptr inbounds [480 x float], [480 x float]* getelementptr inbounds ([720 x [480 x float]], [720 x [480 x float]]* @imgOut, i64 0, i64 0), i64 %154, !dbg !307
  %156 = sext i32 %.314 to i64, !dbg !307
  %157 = getelementptr inbounds [480 x float], [480 x float]* %155, i64 0, i64 %156, !dbg !307
  %158 = load float, float* %157, align 4, !dbg !307
  call void @llvm.dbg.value(metadata float %158, metadata !287, metadata !DIExpression()), !dbg !129
  call void @llvm.dbg.value(metadata float %.120, metadata !184, metadata !DIExpression()), !dbg !129
  %159 = sext i32 %.3 to i64, !dbg !308
  %160 = getelementptr inbounds [480 x float], [480 x float]* getelementptr inbounds ([720 x [480 x float]], [720 x [480 x float]]* @pb_y1, i64 0, i64 0), i64 %159, !dbg !308
  %161 = sext i32 %.314 to i64, !dbg !308
  %162 = getelementptr inbounds [480 x float], [480 x float]* %160, i64 0, i64 %161, !dbg !308
  %163 = load float, float* %162, align 4, !dbg !308
  call void @llvm.dbg.value(metadata float %163, metadata !183, metadata !DIExpression()), !dbg !129
  %164 = add nsw i32 %.3, 1, !dbg !309
  call void @llvm.dbg.value(metadata i32 %164, metadata !176, metadata !DIExpression()), !dbg !129
  br label %135, !dbg !310, !llvm.loop !311

165:                                              ; preds = %135
  %166 = add nsw i32 %.314, 1, !dbg !313
  call void @llvm.dbg.value(metadata i32 %166, metadata !186, metadata !DIExpression()), !dbg !129
  br label %132, !dbg !314, !llvm.loop !315

167:                                              ; preds = %132
  call void @llvm.dbg.value(metadata i32 0, metadata !186, metadata !DIExpression()), !dbg !129
  br label %168, !dbg !317

168:                                              ; preds = %196, %167
  %.415 = phi i32 [ 0, %167 ], [ %197, %196 ], !dbg !319
  call void @llvm.dbg.value(metadata i32 %.415, metadata !186, metadata !DIExpression()), !dbg !129
  %169 = icmp slt i32 %.415, 480, !dbg !320
  br i1 %169, label %170, label %198, !dbg !322

170:                                              ; preds = %168
  call void @llvm.dbg.value(metadata float 0.000000e+00, metadata !323, metadata !DIExpression()), !dbg !129
  call void @llvm.dbg.value(metadata float 0.000000e+00, metadata !324, metadata !DIExpression()), !dbg !129
  call void @llvm.dbg.value(metadata float 0.000000e+00, metadata !222, metadata !DIExpression()), !dbg !129
  call void @llvm.dbg.value(metadata float 0.000000e+00, metadata !223, metadata !DIExpression()), !dbg !129
  call void @llvm.dbg.value(metadata i32 719, metadata !176, metadata !DIExpression()), !dbg !129
  br label %171, !dbg !325

171:                                              ; preds = %173, %170
  %.4 = phi i32 [ 719, %170 ], [ %195, %173 ], !dbg !328
  %.04 = phi float [ 0.000000e+00, %170 ], [ %189, %173 ], !dbg !329
  %.03 = phi float [ 0.000000e+00, %170 ], [ %.04, %173 ], !dbg !329
  %.12 = phi float [ 0.000000e+00, %170 ], [ %194, %173 ], !dbg !329
  %.1 = phi float [ 0.000000e+00, %170 ], [ %.12, %173 ], !dbg !329
  call void @llvm.dbg.value(metadata float %.1, metadata !223, metadata !DIExpression()), !dbg !129
  call void @llvm.dbg.value(metadata float %.12, metadata !222, metadata !DIExpression()), !dbg !129
  call void @llvm.dbg.value(metadata float %.03, metadata !324, metadata !DIExpression()), !dbg !129
  call void @llvm.dbg.value(metadata float %.04, metadata !323, metadata !DIExpression()), !dbg !129
  call void @llvm.dbg.value(metadata i32 %.4, metadata !176, metadata !DIExpression()), !dbg !129
  %172 = icmp sge i32 %.4, 0, !dbg !330
  br i1 %172, label %173, label %196, !dbg !332

173:                                              ; preds = %171
  %174 = fmul float %29, %.04, !dbg !333
  %175 = fmul float %33, %.03, !dbg !335
  %176 = fadd float %174, %175, !dbg !336
  %177 = fmul float %35, %.12, !dbg !337
  %178 = fadd float %176, %177, !dbg !338
  %179 = fmul float %38, %.1, !dbg !339
  %180 = fadd float %178, %179, !dbg !340
  %181 = sext i32 %.4 to i64, !dbg !341
  %182 = getelementptr inbounds [480 x float], [480 x float]* getelementptr inbounds ([720 x [480 x float]], [720 x [480 x float]]* @y2, i64 0, i64 0), i64 %181, !dbg !341
  %183 = sext i32 %.415 to i64, !dbg !341
  %184 = getelementptr inbounds [480 x float], [480 x float]* %182, i64 0, i64 %183, !dbg !341
  store float %180, float* %184, align 4, !dbg !342
  call void @llvm.dbg.value(metadata float %.04, metadata !324, metadata !DIExpression()), !dbg !129
  %185 = sext i32 %.4 to i64, !dbg !343
  %186 = getelementptr inbounds [480 x float], [480 x float]* getelementptr inbounds ([720 x [480 x float]], [720 x [480 x float]]* @imgOut, i64 0, i64 0), i64 %185, !dbg !343
  %187 = sext i32 %.415 to i64, !dbg !343
  %188 = getelementptr inbounds [480 x float], [480 x float]* %186, i64 0, i64 %187, !dbg !343
  %189 = load float, float* %188, align 4, !dbg !343
  call void @llvm.dbg.value(metadata float %189, metadata !323, metadata !DIExpression()), !dbg !129
  call void @llvm.dbg.value(metadata float %.12, metadata !223, metadata !DIExpression()), !dbg !129
  %190 = sext i32 %.4 to i64, !dbg !344
  %191 = getelementptr inbounds [480 x float], [480 x float]* getelementptr inbounds ([720 x [480 x float]], [720 x [480 x float]]* @y2, i64 0, i64 0), i64 %190, !dbg !344
  %192 = sext i32 %.415 to i64, !dbg !344
  %193 = getelementptr inbounds [480 x float], [480 x float]* %191, i64 0, i64 %192, !dbg !344
  %194 = load float, float* %193, align 4, !dbg !344
  call void @llvm.dbg.value(metadata float %194, metadata !222, metadata !DIExpression()), !dbg !129
  %195 = add nsw i32 %.4, -1, !dbg !345
  call void @llvm.dbg.value(metadata i32 %195, metadata !176, metadata !DIExpression()), !dbg !129
  br label %171, !dbg !346, !llvm.loop !347

196:                                              ; preds = %171
  %197 = add nsw i32 %.415, 1, !dbg !349
  call void @llvm.dbg.value(metadata i32 %197, metadata !186, metadata !DIExpression()), !dbg !129
  br label %168, !dbg !350, !llvm.loop !351

198:                                              ; preds = %168
  call void @llvm.dbg.value(metadata i32 0, metadata !176, metadata !DIExpression()), !dbg !129
  br label %199, !dbg !353

199:                                              ; preds = %222, %198
  %.5 = phi i32 [ 0, %198 ], [ %223, %222 ], !dbg !355
  call void @llvm.dbg.value(metadata i32 %.5, metadata !176, metadata !DIExpression()), !dbg !129
  %200 = icmp slt i32 %.5, 720, !dbg !356
  br i1 %200, label %201, label %224, !dbg !358

201:                                              ; preds = %199
  call void @llvm.dbg.value(metadata i32 0, metadata !186, metadata !DIExpression()), !dbg !129
  br label %202, !dbg !359

202:                                              ; preds = %204, %201
  %.516 = phi i32 [ 0, %201 ], [ %221, %204 ], !dbg !361
  call void @llvm.dbg.value(metadata i32 %.516, metadata !186, metadata !DIExpression()), !dbg !129
  %203 = icmp slt i32 %.516, 480, !dbg !362
  br i1 %203, label %204, label %222, !dbg !364

204:                                              ; preds = %202
  %205 = sext i32 %.5 to i64, !dbg !365
  %206 = getelementptr inbounds [480 x float], [480 x float]* getelementptr inbounds ([720 x [480 x float]], [720 x [480 x float]]* @pb_y1, i64 0, i64 0), i64 %205, !dbg !365
  %207 = sext i32 %.516 to i64, !dbg !365
  %208 = getelementptr inbounds [480 x float], [480 x float]* %206, i64 0, i64 %207, !dbg !365
  %209 = load float, float* %208, align 4, !dbg !365
  %210 = sext i32 %.5 to i64, !dbg !366
  %211 = getelementptr inbounds [480 x float], [480 x float]* getelementptr inbounds ([720 x [480 x float]], [720 x [480 x float]]* @y2, i64 0, i64 0), i64 %210, !dbg !366
  %212 = sext i32 %.516 to i64, !dbg !366
  %213 = getelementptr inbounds [480 x float], [480 x float]* %211, i64 0, i64 %212, !dbg !366
  %214 = load float, float* %213, align 4, !dbg !366
  %215 = fadd float %209, %214, !dbg !367
  %216 = fmul float 1.000000e+00, %215, !dbg !368
  %217 = sext i32 %.5 to i64, !dbg !369
  %218 = getelementptr inbounds [480 x float], [480 x float]* getelementptr inbounds ([720 x [480 x float]], [720 x [480 x float]]* @imgOut, i64 0, i64 0), i64 %217, !dbg !369
  %219 = sext i32 %.516 to i64, !dbg !369
  %220 = getelementptr inbounds [480 x float], [480 x float]* %218, i64 0, i64 %219, !dbg !369
  store float %216, float* %220, align 4, !dbg !370
  %221 = add nsw i32 %.516, 1, !dbg !371
  call void @llvm.dbg.value(metadata i32 %221, metadata !186, metadata !DIExpression()), !dbg !129
  br label %202, !dbg !372, !llvm.loop !373

222:                                              ; preds = %202
  %223 = add nsw i32 %.5, 1, !dbg !375
  call void @llvm.dbg.value(metadata i32 %223, metadata !176, metadata !DIExpression()), !dbg !129
  br label %199, !dbg !376, !llvm.loop !377

224:                                              ; preds = %199
  ret i32 0, !dbg !379
}

; Function Attrs: noinline nounwind uwtable
define dso_local i32 @workload_checksum(i32 noundef %0) #0 !dbg !380 {
  call void @llvm.dbg.value(metadata i32 %0, metadata !383, metadata !DIExpression()), !dbg !384
  store i32 -2128831035, i32* @pb_hash, align 4, !dbg !385
  %2 = load i32, i32* @w, align 4, !dbg !386
  %3 = load i32, i32* @h, align 4, !dbg !387
  call void @print_array(i32 noundef %2, i32 noundef %3, [480 x float]* noundef getelementptr inbounds ([720 x [480 x float]], [720 x [480 x float]]* @imgOut, i64 0, i64 0)), !dbg !388
  %4 = load i32, i32* @pb_hash, align 4, !dbg !389
  ret i32 %4, !dbg !390
}

; Function Attrs: noinline nounwind uwtable
define internal void @print_array(i32 noundef %0, i32 noundef %1, [480 x float]* noundef %2) #0 !dbg !391 {
  call void @llvm.dbg.value(metadata i32 %0, metadata !394, metadata !DIExpression()), !dbg !395
  call void @llvm.dbg.value(metadata i32 %1, metadata !396, metadata !DIExpression()), !dbg !395
  call void @llvm.dbg.value(metadata [480 x float]* %2, metadata !397, metadata !DIExpression()), !dbg !395
  %4 = load %struct._IO_FILE*, %struct._IO_FILE** @stderr, align 8, !dbg !398
  %5 = call i32 (%struct._IO_FILE*, i8*, ...) @pb_fprintf(%struct._IO_FILE* noundef %4, i8* noundef getelementptr inbounds ([23 x i8], [23 x i8]* @.str.2, i64 0, i64 0)), !dbg !398
  %6 = load %struct._IO_FILE*, %struct._IO_FILE** @stderr, align 8, !dbg !399
  %7 = call i32 (%struct._IO_FILE*, i8*, ...) @pb_fprintf(%struct._IO_FILE* noundef %6, i8* noundef getelementptr inbounds ([15 x i8], [15 x i8]* @.str.3, i64 0, i64 0), i8* noundef getelementptr inbounds ([7 x i8], [7 x i8]* @.str.4, i64 0, i64 0)), !dbg !399
  call void @llvm.dbg.value(metadata i32 0, metadata !400, metadata !DIExpression()), !dbg !395
  br label %8, !dbg !401

8:                                                ; preds = %33, %3
  %.01 = phi i32 [ 0, %3 ], [ %34, %33 ], !dbg !403
  call void @llvm.dbg.value(metadata i32 %.01, metadata !400, metadata !DIExpression()), !dbg !395
  %9 = icmp slt i32 %.01, %0, !dbg !404
  br i1 %9, label %10, label %35, !dbg !406

10:                                               ; preds = %8
  call void @llvm.dbg.value(metadata i32 0, metadata !407, metadata !DIExpression()), !dbg !395
  br label %11, !dbg !408

11:                                               ; preds = %30, %10
  %.0 = phi i32 [ 0, %10 ], [ %31, %30 ], !dbg !410
  call void @llvm.dbg.value(metadata i32 %.0, metadata !407, metadata !DIExpression()), !dbg !395
  %12 = icmp slt i32 %.0, %1, !dbg !411
  br i1 %12, label %13, label %32, !dbg !413

13:                                               ; preds = %11
  %14 = mul nsw i32 %.01, %1, !dbg !414
  %15 = add nsw i32 %14, %.0, !dbg !417
  %16 = srem i32 %15, 20, !dbg !418
  %17 = icmp eq i32 %16, 0, !dbg !419
  br i1 %17, label %18, label %21, !dbg !420

18:                                               ; preds = %13
  %19 = load %struct._IO_FILE*, %struct._IO_FILE** @stderr, align 8, !dbg !421
  %20 = call i32 (%struct._IO_FILE*, i8*, ...) @pb_fprintf(%struct._IO_FILE* noundef %19, i8* noundef getelementptr inbounds ([2 x i8], [2 x i8]* @.str.5, i64 0, i64 0)), !dbg !422
  br label %21, !dbg !422

21:                                               ; preds = %18, %13
  %22 = load %struct._IO_FILE*, %struct._IO_FILE** @stderr, align 8, !dbg !423
  %23 = sext i32 %.01 to i64, !dbg !424
  %24 = getelementptr inbounds [480 x float], [480 x float]* %2, i64 %23, !dbg !424
  %25 = sext i32 %.0 to i64, !dbg !424
  %26 = getelementptr inbounds [480 x float], [480 x float]* %24, i64 0, i64 %25, !dbg !424
  %27 = load float, float* %26, align 4, !dbg !424
  %28 = fpext float %27 to double, !dbg !424
  %29 = call i32 (%struct._IO_FILE*, i8*, ...) @pb_fprintf(%struct._IO_FILE* noundef %22, i8* noundef getelementptr inbounds ([7 x i8], [7 x i8]* @.str.6, i64 0, i64 0), double noundef %28), !dbg !425
  br label %30, !dbg !426

30:                                               ; preds = %21
  %31 = add nsw i32 %.0, 1, !dbg !427
  call void @llvm.dbg.value(metadata i32 %31, metadata !407, metadata !DIExpression()), !dbg !395
  br label %11, !dbg !428, !llvm.loop !429

32:                                               ; preds = %11
  br label %33, !dbg !430

33:                                               ; preds = %32
  %34 = add nsw i32 %.01, 1, !dbg !431
  call void @llvm.dbg.value(metadata i32 %34, metadata !400, metadata !DIExpression()), !dbg !395
  br label %8, !dbg !432, !llvm.loop !433

35:                                               ; preds = %8
  %36 = load %struct._IO_FILE*, %struct._IO_FILE** @stderr, align 8, !dbg !435
  %37 = call i32 (%struct._IO_FILE*, i8*, ...) @pb_fprintf(%struct._IO_FILE* noundef %36, i8* noundef getelementptr inbounds ([17 x i8], [17 x i8]* @.str.7, i64 0, i64 0), i8* noundef getelementptr inbounds ([7 x i8], [7 x i8]* @.str.4, i64 0, i64 0)), !dbg !435
  %38 = load %struct._IO_FILE*, %struct._IO_FILE** @stderr, align 8, !dbg !436
  %39 = call i32 (%struct._IO_FILE*, i8*, ...) @pb_fprintf(%struct._IO_FILE* noundef %38, i8* noundef getelementptr inbounds ([23 x i8], [23 x i8]* @.str.8, i64 0, i64 0)), !dbg !436
  ret void, !dbg !437
}

; Function Attrs: nounwind
declare float @expf(float noundef) #3

; Function Attrs: nounwind
declare float @powf(float noundef, float noundef) #3

; Function Attrs: noinline nounwind uwtable
define internal i32 @pb_fprintf(%struct._IO_FILE* noundef %0, i8* noundef %1, ...) #0 !dbg !438 {
  %3 = alloca [768 x i8], align 16
  %4 = alloca [1 x %struct.__va_list_tag], align 16
  call void @llvm.dbg.value(metadata %struct._IO_FILE* %0, metadata !502, metadata !DIExpression()), !dbg !503
  call void @llvm.dbg.value(metadata i8* %1, metadata !504, metadata !DIExpression()), !dbg !503
  call void @llvm.dbg.declare(metadata [768 x i8]* %3, metadata !505, metadata !DIExpression()), !dbg !509
  call void @llvm.dbg.declare(metadata [1 x %struct.__va_list_tag]* %4, metadata !510, metadata !DIExpression()), !dbg !524
  %5 = getelementptr inbounds [1 x %struct.__va_list_tag], [1 x %struct.__va_list_tag]* %4, i64 0, i64 0, !dbg !525
  %6 = bitcast %struct.__va_list_tag* %5 to i8*, !dbg !525
  call void @llvm.va_start(i8* %6), !dbg !525
  %7 = getelementptr inbounds [768 x i8], [768 x i8]* %3, i64 0, i64 0, !dbg !526
  %8 = getelementptr inbounds [1 x %struct.__va_list_tag], [1 x %struct.__va_list_tag]* %4, i64 0, i64 0, !dbg !527
  %9 = call i32 @vsnprintf(i8* noundef %7, i64 noundef 768, i8* noundef %1, %struct.__va_list_tag* noundef %8) #6, !dbg !528
  call void @llvm.dbg.value(metadata i32 %9, metadata !529, metadata !DIExpression()), !dbg !503
  %10 = getelementptr inbounds [1 x %struct.__va_list_tag], [1 x %struct.__va_list_tag]* %4, i64 0, i64 0, !dbg !530
  %11 = bitcast %struct.__va_list_tag* %10 to i8*, !dbg !530
  call void @llvm.va_end(i8* %11), !dbg !530
  %12 = icmp slt i32 %9, 0, !dbg !531
  br i1 %12, label %16, label %13, !dbg !533

13:                                               ; preds = %2
  %14 = zext i32 %9 to i64, !dbg !534
  %15 = icmp uge i64 %14, 768, !dbg !535
  br i1 %15, label %16, label %17, !dbg !536

16:                                               ; preds = %13, %2
  call void @abort() #7, !dbg !537
  unreachable, !dbg !537

17:                                               ; preds = %13
  call void @llvm.dbg.value(metadata i32 0, metadata !538, metadata !DIExpression()), !dbg !540
  br label %18, !dbg !541

18:                                               ; preds = %29, %17
  %.0 = phi i32 [ 0, %17 ], [ %30, %29 ], !dbg !540
  call void @llvm.dbg.value(metadata i32 %.0, metadata !538, metadata !DIExpression()), !dbg !540
  %19 = icmp slt i32 %.0, %9, !dbg !542
  br i1 %19, label %20, label %31, !dbg !544

20:                                               ; preds = %18
  %21 = sext i32 %.0 to i64, !dbg !545
  %22 = getelementptr inbounds [768 x i8], [768 x i8]* %3, i64 0, i64 %21, !dbg !545
  %23 = load i8, i8* %22, align 1, !dbg !545
  %24 = zext i8 %23 to i32, !dbg !547
  %25 = load i32, i32* @pb_hash, align 4, !dbg !548
  %26 = xor i32 %25, %24, !dbg !548
  store i32 %26, i32* @pb_hash, align 4, !dbg !548
  %27 = load i32, i32* @pb_hash, align 4, !dbg !549
  %28 = mul i32 %27, 16777619, !dbg !549
  store i32 %28, i32* @pb_hash, align 4, !dbg !549
  br label %29, !dbg !550

29:                                               ; preds = %20
  %30 = add nsw i32 %.0, 1, !dbg !551
  call void @llvm.dbg.value(metadata i32 %30, metadata !538, metadata !DIExpression()), !dbg !540
  br label %18, !dbg !552, !llvm.loop !553

31:                                               ; preds = %18
  %32 = load i32, i32* @pb_emit, align 4, !dbg !555
  ret i32 %9, !dbg !556
}

; Function Attrs: nofree nosync nounwind willreturn
declare void @llvm.va_start(i8*) #4

; Function Attrs: nounwind
declare i32 @vsnprintf(i8* noundef, i64 noundef, i8* noundef, %struct.__va_list_tag* noundef) #3

; Function Attrs: nofree nosync nounwind willreturn
declare void @llvm.va_end(i8*) #4

; Function Attrs: noreturn nounwind
declare void @abort() #5

; Function Attrs: nofree nosync nounwind readnone speculatable willreturn
declare void @llvm.dbg.value(metadata, metadata, metadata) #1

attributes #0 = { noinline nounwind uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { nofree nosync nounwind readnone speculatable willreturn }
attributes #2 = { argmemonly nofree nounwind willreturn writeonly }
attributes #3 = { nounwind "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #4 = { nofree nosync nounwind willreturn }
attributes #5 = { noreturn nounwind "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #6 = { nounwind }
attributes #7 = { noreturn nounwind }

!llvm.dbg.cu = !{!2}
!llvm.module.flags = !{!49, !50, !51, !52, !53, !54, !55}
!llvm.ident = !{!56}

!0 = !DIGlobalVariableExpression(var: !1, expr: !DIExpression())
!1 = distinct !DIGlobalVariable(name: "w", scope: !2, file: !11, line: 172, type: !12, isLocal: false, isDefinition: true)
!2 = distinct !DICompileUnit(language: DW_LANG_C99, file: !3, producer: "Ubuntu clang version 14.0.0-1ubuntu1.1", isOptimized: false, runtimeVersion: 0, emissionKind: FullDebug, retainedTypes: !4, globals: !8, splitDebugInlining: false, nameTableKind: None)
!3 = !DIFile(filename: "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/triangular-20260929/suite/deriche/source/workload.c", directory: "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/triangular-20260929/suite/deriche/analysis-c", checksumkind: CSK_MD5, checksum: "be46e5ab31cb7a5e1325f0c6a0cfccce")
!4 = !{!5, !6, !7}
!5 = !DIBasicType(name: "float", size: 32, encoding: DW_ATE_float)
!6 = !DIBasicType(name: "unsigned int", size: 32, encoding: DW_ATE_unsigned)
!7 = !DIBasicType(name: "unsigned char", size: 8, encoding: DW_ATE_unsigned_char)
!8 = !{!0, !9, !13, !26, !30, !33, !39, !41, !43, !45, !47}
!9 = !DIGlobalVariableExpression(var: !10, expr: !DIExpression())
!10 = distinct !DIGlobalVariable(name: "h", scope: !2, file: !11, line: 173, type: !12, isLocal: false, isDefinition: true)
!11 = !DIFile(filename: "source/workload.c", directory: "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/triangular-20260929/suite/deriche", checksumkind: CSK_MD5, checksum: "be46e5ab31cb7a5e1325f0c6a0cfccce")
!12 = !DIBasicType(name: "int", size: 32, encoding: DW_ATE_signed)
!13 = !DIGlobalVariableExpression(var: !14, expr: !DIExpression())
!14 = distinct !DIGlobalVariable(name: "workload_jobs", scope: !2, file: !11, line: 196, type: !15, isLocal: false, isDefinition: true)
!15 = !DICompositeType(tag: DW_TAG_array_type, baseType: !16, size: 64, elements: !24)
!16 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !17)
!17 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !18, size: 64)
!18 = !DISubroutineType(types: !19)
!19 = !{!20}
!20 = !DIDerivedType(tag: DW_TAG_typedef, name: "uint32_t", file: !21, line: 26, baseType: !22)
!21 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/stdint-uintn.h", directory: "", checksumkind: CSK_MD5, checksum: "2bf2ae53c58c01b1a1b9383b5195125c")
!22 = !DIDerivedType(tag: DW_TAG_typedef, name: "__uint32_t", file: !23, line: 42, baseType: !6)
!23 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/types.h", directory: "", checksumkind: CSK_MD5, checksum: "d108b5f93a74c50510d7d9bc0ab36df9")
!24 = !{!25}
!25 = !DISubrange(count: 1)
!26 = !DIGlobalVariableExpression(var: !27, expr: !DIExpression())
!27 = distinct !DIGlobalVariable(name: "workload_expected", scope: !2, file: !11, line: 200, type: !28, isLocal: false, isDefinition: true)
!28 = !DICompositeType(tag: DW_TAG_array_type, baseType: !29, size: 32, elements: !24)
!29 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !20)
!30 = !DIGlobalVariableExpression(var: !31, expr: !DIExpression())
!31 = distinct !DIGlobalVariable(name: "pb_hash", scope: !2, file: !32, line: 9, type: !20, isLocal: true, isDefinition: true)
!32 = !DIFile(filename: "source/adapter.h", directory: "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/triangular-20260929/suite/deriche", checksumkind: CSK_MD5, checksum: "26a6068928b2092758f244a9d00163d7")
!33 = !DIGlobalVariableExpression(var: !34, expr: !DIExpression())
!34 = distinct !DIGlobalVariable(name: "imgIn", scope: !2, file: !11, line: 34, type: !35, isLocal: false, isDefinition: true, align: 512)
!35 = !DICompositeType(tag: DW_TAG_array_type, baseType: !5, size: 11059200, elements: !36)
!36 = !{!37, !38}
!37 = !DISubrange(count: 720)
!38 = !DISubrange(count: 480)
!39 = !DIGlobalVariableExpression(var: !40, expr: !DIExpression())
!40 = distinct !DIGlobalVariable(name: "imgOut", scope: !2, file: !11, line: 35, type: !35, isLocal: false, isDefinition: true, align: 512)
!41 = !DIGlobalVariableExpression(var: !42, expr: !DIExpression())
!42 = distinct !DIGlobalVariable(name: "pb_y1", scope: !2, file: !11, line: 36, type: !35, isLocal: false, isDefinition: true, align: 512)
!43 = !DIGlobalVariableExpression(var: !44, expr: !DIExpression())
!44 = distinct !DIGlobalVariable(name: "y2", scope: !2, file: !11, line: 37, type: !35, isLocal: false, isDefinition: true, align: 512)
!45 = !DIGlobalVariableExpression(var: !46, expr: !DIExpression())
!46 = distinct !DIGlobalVariable(name: "alpha", scope: !2, file: !11, line: 176, type: !5, isLocal: false, isDefinition: true)
!47 = !DIGlobalVariableExpression(var: !48, expr: !DIExpression())
!48 = distinct !DIGlobalVariable(name: "pb_emit", scope: !2, file: !32, line: 10, type: !12, isLocal: true, isDefinition: true)
!49 = !{i32 7, !"Dwarf Version", i32 5}
!50 = !{i32 2, !"Debug Info Version", i32 3}
!51 = !{i32 1, !"wchar_size", i32 4}
!52 = !{i32 7, !"PIC Level", i32 2}
!53 = !{i32 7, !"PIE Level", i32 2}
!54 = !{i32 7, !"uwtable", i32 1}
!55 = !{i32 7, !"frame-pointer", i32 2}
!56 = !{!"Ubuntu clang version 14.0.0-1ubuntu1.1"}
!57 = distinct !DISubprogram(name: "workload_prepare", scope: !11, file: !11, line: 177, type: !58, scopeLine: 177, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !2, retainedNodes: !60)
!58 = !DISubroutineType(types: !59)
!59 = !{null}
!60 = !{}
!61 = !DILocation(line: 177, column: 30, scope: !57)
!62 = distinct !DISubprogram(name: "workload_reset", scope: !11, file: !11, line: 178, type: !63, scopeLine: 178, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !2, retainedNodes: !60)
!63 = !DISubroutineType(types: !64)
!64 = !{null, !6}
!65 = !DILocalVariable(name: "task", arg: 1, scope: !62, file: !11, line: 178, type: !6)
!66 = !DILocation(line: 0, scope: !62)
!67 = !DILocation(line: 180, column: 3, scope: !62)
!68 = !DILocation(line: 181, column: 3, scope: !62)
!69 = !DILocation(line: 182, column: 3, scope: !62)
!70 = !DILocation(line: 183, column: 3, scope: !62)
!71 = !DILocation(line: 184, column: 15, scope: !62)
!72 = !DILocation(line: 184, column: 18, scope: !62)
!73 = !DILocation(line: 184, column: 3, scope: !62)
!74 = !DILocation(line: 185, column: 1, scope: !62)
!75 = distinct !DISubprogram(name: "init_array", scope: !11, file: !11, line: 39, type: !76, scopeLine: 42, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition, unit: !2, retainedNodes: !60)
!76 = !DISubroutineType(types: !77)
!77 = !{null, !12, !12, !78, !79, !79}
!78 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !5, size: 64)
!79 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !80, size: 64)
!80 = !DICompositeType(tag: DW_TAG_array_type, baseType: !5, size: 15360, elements: !81)
!81 = !{!38}
!82 = !DILocalVariable(name: "w", arg: 1, scope: !75, file: !11, line: 39, type: !12)
!83 = !DILocation(line: 0, scope: !75)
!84 = !DILocalVariable(name: "h", arg: 2, scope: !75, file: !11, line: 39, type: !12)
!85 = !DILocalVariable(name: "alpha", arg: 3, scope: !75, file: !11, line: 39, type: !78)
!86 = !DILocalVariable(name: "imgIn", arg: 4, scope: !75, file: !11, line: 40, type: !79)
!87 = !DILocalVariable(name: "imgOut", arg: 5, scope: !75, file: !11, line: 41, type: !79)
!88 = !DILocation(line: 45, column: 9, scope: !75)
!89 = !DILocalVariable(name: "i", scope: !75, file: !11, line: 43, type: !12)
!90 = !DILocation(line: 48, column: 8, scope: !91)
!91 = distinct !DILexicalBlock(scope: !75, file: !11, line: 48, column: 3)
!92 = !DILocation(line: 0, scope: !91)
!93 = !DILocation(line: 48, column: 17, scope: !94)
!94 = distinct !DILexicalBlock(scope: !91, file: !11, line: 48, column: 3)
!95 = !DILocation(line: 48, column: 3, scope: !91)
!96 = !DILocalVariable(name: "j", scope: !75, file: !11, line: 43, type: !12)
!97 = !DILocation(line: 49, column: 11, scope: !98)
!98 = distinct !DILexicalBlock(scope: !94, file: !11, line: 49, column: 6)
!99 = !DILocation(line: 0, scope: !98)
!100 = !DILocation(line: 49, column: 20, scope: !101)
!101 = distinct !DILexicalBlock(scope: !98, file: !11, line: 49, column: 6)
!102 = !DILocation(line: 49, column: 6, scope: !98)
!103 = !DILocation(line: 50, column: 33, scope: !101)
!104 = !DILocation(line: 50, column: 39, scope: !101)
!105 = !DILocation(line: 50, column: 35, scope: !101)
!106 = !DILocation(line: 50, column: 42, scope: !101)
!107 = !DILocation(line: 50, column: 16, scope: !101)
!108 = !DILocation(line: 50, column: 50, scope: !101)
!109 = !DILocation(line: 50, column: 2, scope: !101)
!110 = !DILocation(line: 50, column: 14, scope: !101)
!111 = !DILocation(line: 49, column: 26, scope: !101)
!112 = !DILocation(line: 49, column: 6, scope: !101)
!113 = distinct !{!113, !102, !114, !115}
!114 = !DILocation(line: 50, column: 52, scope: !98)
!115 = !{!"llvm.loop.mustprogress"}
!116 = !DILocation(line: 48, column: 23, scope: !94)
!117 = !DILocation(line: 48, column: 3, scope: !94)
!118 = distinct !{!118, !95, !119, !115}
!119 = !DILocation(line: 50, column: 52, scope: !91)
!120 = !DILocation(line: 51, column: 1, scope: !75)
!121 = distinct !DISubprogram(name: "task_job_polybench", scope: !11, file: !11, line: 186, type: !18, scopeLine: 186, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !2, retainedNodes: !60)
!122 = !DILocation(line: 187, column: 19, scope: !121)
!123 = !DILocation(line: 187, column: 22, scope: !121)
!124 = !DILocation(line: 187, column: 25, scope: !121)
!125 = !DILocalVariable(name: "w", arg: 1, scope: !126, file: !11, line: 80, type: !12)
!126 = distinct !DISubprogram(name: "kernel_deriche", scope: !11, file: !11, line: 80, type: !127, scopeLine: 84, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition, unit: !2, retainedNodes: !60)
!127 = !DISubroutineType(types: !128)
!128 = !{null, !12, !12, !5, !79, !79, !79, !79}
!129 = !DILocation(line: 0, scope: !126, inlinedAt: !130)
!130 = distinct !DILocation(line: 187, column: 3, scope: !121)
!131 = !DILocalVariable(name: "h", arg: 2, scope: !126, file: !11, line: 80, type: !12)
!132 = !DILocalVariable(name: "alpha", arg: 3, scope: !126, file: !11, line: 80, type: !5)
!133 = !DILocalVariable(name: "imgIn", arg: 4, scope: !126, file: !11, line: 81, type: !79)
!134 = !DILocalVariable(name: "imgOut", arg: 5, scope: !126, file: !11, line: 82, type: !79)
!135 = !DILocalVariable(name: "pb_y1", arg: 6, scope: !126, file: !11, line: 83, type: !79)
!136 = !DILocalVariable(name: "y2", arg: 7, scope: !126, file: !11, line: 84, type: !79)
!137 = !DILocation(line: 96, column: 25, scope: !126, inlinedAt: !130)
!138 = !DILocation(line: 96, column: 24, scope: !126, inlinedAt: !130)
!139 = !DILocation(line: 96, column: 59, scope: !126, inlinedAt: !130)
!140 = !DILocation(line: 96, column: 58, scope: !126, inlinedAt: !130)
!141 = !DILocation(line: 96, column: 41, scope: !126, inlinedAt: !130)
!142 = !DILocation(line: 96, column: 108, scope: !126, inlinedAt: !130)
!143 = !DILocation(line: 96, column: 115, scope: !126, inlinedAt: !130)
!144 = !DILocation(line: 96, column: 114, scope: !126, inlinedAt: !130)
!145 = !DILocation(line: 96, column: 92, scope: !126, inlinedAt: !130)
!146 = !DILocation(line: 96, column: 131, scope: !126, inlinedAt: !130)
!147 = !DILocation(line: 96, column: 130, scope: !126, inlinedAt: !130)
!148 = !DILocation(line: 96, column: 75, scope: !126, inlinedAt: !130)
!149 = !DILocalVariable(name: "k", scope: !126, file: !11, line: 91, type: !5)
!150 = !DILocalVariable(name: "a5", scope: !126, file: !11, line: 92, type: !5)
!151 = !DILocalVariable(name: "a1", scope: !126, file: !11, line: 92, type: !5)
!152 = !DILocation(line: 98, column: 16, scope: !126, inlinedAt: !130)
!153 = !DILocation(line: 98, column: 15, scope: !126, inlinedAt: !130)
!154 = !DILocation(line: 98, column: 38, scope: !126, inlinedAt: !130)
!155 = !DILocation(line: 98, column: 31, scope: !126, inlinedAt: !130)
!156 = !DILocalVariable(name: "a6", scope: !126, file: !11, line: 92, type: !5)
!157 = !DILocalVariable(name: "a2", scope: !126, file: !11, line: 92, type: !5)
!158 = !DILocation(line: 99, column: 16, scope: !126, inlinedAt: !130)
!159 = !DILocation(line: 99, column: 15, scope: !126, inlinedAt: !130)
!160 = !DILocation(line: 99, column: 38, scope: !126, inlinedAt: !130)
!161 = !DILocation(line: 99, column: 31, scope: !126, inlinedAt: !130)
!162 = !DILocalVariable(name: "a7", scope: !126, file: !11, line: 92, type: !5)
!163 = !DILocalVariable(name: "a3", scope: !126, file: !11, line: 92, type: !5)
!164 = !DILocation(line: 100, column: 14, scope: !126, inlinedAt: !130)
!165 = !DILocation(line: 100, column: 17, scope: !126, inlinedAt: !130)
!166 = !DILocation(line: 100, column: 16, scope: !126, inlinedAt: !130)
!167 = !DILocalVariable(name: "a8", scope: !126, file: !11, line: 92, type: !5)
!168 = !DILocalVariable(name: "a4", scope: !126, file: !11, line: 92, type: !5)
!169 = !DILocation(line: 101, column: 10, scope: !126, inlinedAt: !130)
!170 = !DILocalVariable(name: "b1", scope: !126, file: !11, line: 93, type: !5)
!171 = !DILocation(line: 102, column: 10, scope: !126, inlinedAt: !130)
!172 = !DILocation(line: 102, column: 9, scope: !126, inlinedAt: !130)
!173 = !DILocalVariable(name: "b2", scope: !126, file: !11, line: 93, type: !5)
!174 = !DILocalVariable(name: "c2", scope: !126, file: !11, line: 93, type: !5)
!175 = !DILocalVariable(name: "c1", scope: !126, file: !11, line: 93, type: !5)
!176 = !DILocalVariable(name: "i", scope: !126, file: !11, line: 85, type: !12)
!177 = !DILocation(line: 105, column: 9, scope: !178, inlinedAt: !130)
!178 = distinct !DILexicalBlock(scope: !126, file: !11, line: 105, column: 4)
!179 = !DILocation(line: 0, scope: !178, inlinedAt: !130)
!180 = !DILocation(line: 105, column: 15, scope: !181, inlinedAt: !130)
!181 = distinct !DILexicalBlock(scope: !178, file: !11, line: 105, column: 4)
!182 = !DILocation(line: 105, column: 4, scope: !178, inlinedAt: !130)
!183 = !DILocalVariable(name: "ym1", scope: !126, file: !11, line: 86, type: !5)
!184 = !DILocalVariable(name: "ym2", scope: !126, file: !11, line: 86, type: !5)
!185 = !DILocalVariable(name: "xm1", scope: !126, file: !11, line: 86, type: !5)
!186 = !DILocalVariable(name: "j", scope: !126, file: !11, line: 85, type: !12)
!187 = !DILocation(line: 109, column: 14, scope: !188, inlinedAt: !130)
!188 = distinct !DILexicalBlock(scope: !189, file: !11, line: 109, column: 9)
!189 = distinct !DILexicalBlock(scope: !181, file: !11, line: 105, column: 28)
!190 = !DILocation(line: 0, scope: !189, inlinedAt: !130)
!191 = !DILocation(line: 0, scope: !188, inlinedAt: !130)
!192 = !DILocation(line: 109, column: 20, scope: !193, inlinedAt: !130)
!193 = distinct !DILexicalBlock(scope: !188, file: !11, line: 109, column: 9)
!194 = !DILocation(line: 109, column: 9, scope: !188, inlinedAt: !130)
!195 = !DILocation(line: 110, column: 27, scope: !196, inlinedAt: !130)
!196 = distinct !DILexicalBlock(scope: !193, file: !11, line: 109, column: 33)
!197 = !DILocation(line: 110, column: 26, scope: !196, inlinedAt: !130)
!198 = !DILocation(line: 110, column: 43, scope: !196, inlinedAt: !130)
!199 = !DILocation(line: 110, column: 39, scope: !196, inlinedAt: !130)
!200 = !DILocation(line: 110, column: 52, scope: !196, inlinedAt: !130)
!201 = !DILocation(line: 110, column: 48, scope: !196, inlinedAt: !130)
!202 = !DILocation(line: 110, column: 61, scope: !196, inlinedAt: !130)
!203 = !DILocation(line: 110, column: 57, scope: !196, inlinedAt: !130)
!204 = !DILocation(line: 110, column: 13, scope: !196, inlinedAt: !130)
!205 = !DILocation(line: 110, column: 22, scope: !196, inlinedAt: !130)
!206 = !DILocation(line: 111, column: 19, scope: !196, inlinedAt: !130)
!207 = !DILocation(line: 113, column: 19, scope: !196, inlinedAt: !130)
!208 = !DILocation(line: 109, column: 29, scope: !193, inlinedAt: !130)
!209 = !DILocation(line: 109, column: 9, scope: !193, inlinedAt: !130)
!210 = distinct !{!210, !194, !211, !115}
!211 = !DILocation(line: 114, column: 9, scope: !188, inlinedAt: !130)
!212 = !DILocation(line: 105, column: 24, scope: !181, inlinedAt: !130)
!213 = !DILocation(line: 105, column: 4, scope: !181, inlinedAt: !130)
!214 = distinct !{!214, !182, !215, !115}
!215 = !DILocation(line: 115, column: 5, scope: !178, inlinedAt: !130)
!216 = !DILocation(line: 117, column: 10, scope: !217, inlinedAt: !130)
!217 = distinct !DILexicalBlock(scope: !126, file: !11, line: 117, column: 5)
!218 = !DILocation(line: 0, scope: !217, inlinedAt: !130)
!219 = !DILocation(line: 117, column: 16, scope: !220, inlinedAt: !130)
!220 = distinct !DILexicalBlock(scope: !217, file: !11, line: 117, column: 5)
!221 = !DILocation(line: 117, column: 5, scope: !217, inlinedAt: !130)
!222 = !DILocalVariable(name: "yp1", scope: !126, file: !11, line: 89, type: !5)
!223 = !DILocalVariable(name: "yp2", scope: !126, file: !11, line: 89, type: !5)
!224 = !DILocalVariable(name: "xp1", scope: !126, file: !11, line: 87, type: !5)
!225 = !DILocalVariable(name: "xp2", scope: !126, file: !11, line: 87, type: !5)
!226 = !DILocation(line: 122, column: 14, scope: !227, inlinedAt: !130)
!227 = distinct !DILexicalBlock(scope: !228, file: !11, line: 122, column: 9)
!228 = distinct !DILexicalBlock(scope: !220, file: !11, line: 117, column: 29)
!229 = !DILocation(line: 0, scope: !227, inlinedAt: !130)
!230 = !DILocation(line: 0, scope: !228, inlinedAt: !130)
!231 = !DILocation(line: 122, column: 26, scope: !232, inlinedAt: !130)
!232 = distinct !DILexicalBlock(scope: !227, file: !11, line: 122, column: 9)
!233 = !DILocation(line: 122, column: 9, scope: !227, inlinedAt: !130)
!234 = !DILocation(line: 123, column: 26, scope: !235, inlinedAt: !130)
!235 = distinct !DILexicalBlock(scope: !232, file: !11, line: 122, column: 36)
!236 = !DILocation(line: 123, column: 35, scope: !235, inlinedAt: !130)
!237 = !DILocation(line: 123, column: 31, scope: !235, inlinedAt: !130)
!238 = !DILocation(line: 123, column: 44, scope: !235, inlinedAt: !130)
!239 = !DILocation(line: 123, column: 40, scope: !235, inlinedAt: !130)
!240 = !DILocation(line: 123, column: 53, scope: !235, inlinedAt: !130)
!241 = !DILocation(line: 123, column: 49, scope: !235, inlinedAt: !130)
!242 = !DILocation(line: 123, column: 13, scope: !235, inlinedAt: !130)
!243 = !DILocation(line: 123, column: 22, scope: !235, inlinedAt: !130)
!244 = !DILocation(line: 125, column: 19, scope: !235, inlinedAt: !130)
!245 = !DILocation(line: 127, column: 19, scope: !235, inlinedAt: !130)
!246 = !DILocation(line: 122, column: 32, scope: !232, inlinedAt: !130)
!247 = !DILocation(line: 122, column: 9, scope: !232, inlinedAt: !130)
!248 = distinct !{!248, !233, !249, !115}
!249 = !DILocation(line: 128, column: 9, scope: !227, inlinedAt: !130)
!250 = !DILocation(line: 117, column: 25, scope: !220, inlinedAt: !130)
!251 = !DILocation(line: 117, column: 5, scope: !220, inlinedAt: !130)
!252 = distinct !{!252, !221, !253, !115}
!253 = !DILocation(line: 129, column: 5, scope: !217, inlinedAt: !130)
!254 = !DILocation(line: 131, column: 10, scope: !255, inlinedAt: !130)
!255 = distinct !DILexicalBlock(scope: !126, file: !11, line: 131, column: 5)
!256 = !DILocation(line: 0, scope: !255, inlinedAt: !130)
!257 = !DILocation(line: 131, column: 16, scope: !258, inlinedAt: !130)
!258 = distinct !DILexicalBlock(scope: !255, file: !11, line: 131, column: 5)
!259 = !DILocation(line: 131, column: 5, scope: !255, inlinedAt: !130)
!260 = !DILocation(line: 132, column: 14, scope: !261, inlinedAt: !130)
!261 = distinct !DILexicalBlock(scope: !258, file: !11, line: 132, column: 9)
!262 = !DILocation(line: 0, scope: !261, inlinedAt: !130)
!263 = !DILocation(line: 132, column: 20, scope: !264, inlinedAt: !130)
!264 = distinct !DILexicalBlock(scope: !261, file: !11, line: 132, column: 9)
!265 = !DILocation(line: 132, column: 9, scope: !261, inlinedAt: !130)
!266 = !DILocation(line: 133, column: 34, scope: !267, inlinedAt: !130)
!267 = distinct !DILexicalBlock(scope: !264, file: !11, line: 132, column: 33)
!268 = !DILocation(line: 133, column: 45, scope: !267, inlinedAt: !130)
!269 = !DILocation(line: 133, column: 43, scope: !267, inlinedAt: !130)
!270 = !DILocation(line: 133, column: 31, scope: !267, inlinedAt: !130)
!271 = !DILocation(line: 133, column: 13, scope: !267, inlinedAt: !130)
!272 = !DILocation(line: 133, column: 26, scope: !267, inlinedAt: !130)
!273 = !DILocation(line: 132, column: 29, scope: !264, inlinedAt: !130)
!274 = !DILocation(line: 132, column: 9, scope: !264, inlinedAt: !130)
!275 = distinct !{!275, !265, !276, !115}
!276 = !DILocation(line: 134, column: 9, scope: !261, inlinedAt: !130)
!277 = !DILocation(line: 131, column: 25, scope: !258, inlinedAt: !130)
!278 = !DILocation(line: 131, column: 5, scope: !258, inlinedAt: !130)
!279 = distinct !{!279, !259, !280, !115}
!280 = !DILocation(line: 134, column: 9, scope: !255, inlinedAt: !130)
!281 = !DILocation(line: 136, column: 10, scope: !282, inlinedAt: !130)
!282 = distinct !DILexicalBlock(scope: !126, file: !11, line: 136, column: 5)
!283 = !DILocation(line: 0, scope: !282, inlinedAt: !130)
!284 = !DILocation(line: 136, column: 16, scope: !285, inlinedAt: !130)
!285 = distinct !DILexicalBlock(scope: !282, file: !11, line: 136, column: 5)
!286 = !DILocation(line: 136, column: 5, scope: !282, inlinedAt: !130)
!287 = !DILocalVariable(name: "tm1", scope: !126, file: !11, line: 86, type: !5)
!288 = !DILocation(line: 140, column: 14, scope: !289, inlinedAt: !130)
!289 = distinct !DILexicalBlock(scope: !290, file: !11, line: 140, column: 9)
!290 = distinct !DILexicalBlock(scope: !285, file: !11, line: 136, column: 29)
!291 = !DILocation(line: 0, scope: !290, inlinedAt: !130)
!292 = !DILocation(line: 0, scope: !289, inlinedAt: !130)
!293 = !DILocation(line: 140, column: 20, scope: !294, inlinedAt: !130)
!294 = distinct !DILexicalBlock(scope: !289, file: !11, line: 140, column: 9)
!295 = !DILocation(line: 140, column: 9, scope: !289, inlinedAt: !130)
!296 = !DILocation(line: 141, column: 27, scope: !297, inlinedAt: !130)
!297 = distinct !DILexicalBlock(scope: !294, file: !11, line: 140, column: 33)
!298 = !DILocation(line: 141, column: 26, scope: !297, inlinedAt: !130)
!299 = !DILocation(line: 141, column: 44, scope: !297, inlinedAt: !130)
!300 = !DILocation(line: 141, column: 40, scope: !297, inlinedAt: !130)
!301 = !DILocation(line: 141, column: 53, scope: !297, inlinedAt: !130)
!302 = !DILocation(line: 141, column: 49, scope: !297, inlinedAt: !130)
!303 = !DILocation(line: 141, column: 62, scope: !297, inlinedAt: !130)
!304 = !DILocation(line: 141, column: 58, scope: !297, inlinedAt: !130)
!305 = !DILocation(line: 141, column: 13, scope: !297, inlinedAt: !130)
!306 = !DILocation(line: 141, column: 22, scope: !297, inlinedAt: !130)
!307 = !DILocation(line: 142, column: 19, scope: !297, inlinedAt: !130)
!308 = !DILocation(line: 144, column: 19, scope: !297, inlinedAt: !130)
!309 = !DILocation(line: 140, column: 29, scope: !294, inlinedAt: !130)
!310 = !DILocation(line: 140, column: 9, scope: !294, inlinedAt: !130)
!311 = distinct !{!311, !295, !312, !115}
!312 = !DILocation(line: 145, column: 9, scope: !289, inlinedAt: !130)
!313 = !DILocation(line: 136, column: 25, scope: !285, inlinedAt: !130)
!314 = !DILocation(line: 136, column: 5, scope: !285, inlinedAt: !130)
!315 = distinct !{!315, !286, !316, !115}
!316 = !DILocation(line: 146, column: 5, scope: !282, inlinedAt: !130)
!317 = !DILocation(line: 149, column: 10, scope: !318, inlinedAt: !130)
!318 = distinct !DILexicalBlock(scope: !126, file: !11, line: 149, column: 5)
!319 = !DILocation(line: 0, scope: !318, inlinedAt: !130)
!320 = !DILocation(line: 149, column: 16, scope: !321, inlinedAt: !130)
!321 = distinct !DILexicalBlock(scope: !318, file: !11, line: 149, column: 5)
!322 = !DILocation(line: 149, column: 5, scope: !318, inlinedAt: !130)
!323 = !DILocalVariable(name: "tp1", scope: !126, file: !11, line: 88, type: !5)
!324 = !DILocalVariable(name: "tp2", scope: !126, file: !11, line: 88, type: !5)
!325 = !DILocation(line: 154, column: 14, scope: !326, inlinedAt: !130)
!326 = distinct !DILexicalBlock(scope: !327, file: !11, line: 154, column: 9)
!327 = distinct !DILexicalBlock(scope: !321, file: !11, line: 149, column: 29)
!328 = !DILocation(line: 0, scope: !326, inlinedAt: !130)
!329 = !DILocation(line: 0, scope: !327, inlinedAt: !130)
!330 = !DILocation(line: 154, column: 26, scope: !331, inlinedAt: !130)
!331 = distinct !DILexicalBlock(scope: !326, file: !11, line: 154, column: 9)
!332 = !DILocation(line: 154, column: 9, scope: !326, inlinedAt: !130)
!333 = !DILocation(line: 155, column: 26, scope: !334, inlinedAt: !130)
!334 = distinct !DILexicalBlock(scope: !331, file: !11, line: 154, column: 36)
!335 = !DILocation(line: 155, column: 35, scope: !334, inlinedAt: !130)
!336 = !DILocation(line: 155, column: 31, scope: !334, inlinedAt: !130)
!337 = !DILocation(line: 155, column: 44, scope: !334, inlinedAt: !130)
!338 = !DILocation(line: 155, column: 40, scope: !334, inlinedAt: !130)
!339 = !DILocation(line: 155, column: 53, scope: !334, inlinedAt: !130)
!340 = !DILocation(line: 155, column: 49, scope: !334, inlinedAt: !130)
!341 = !DILocation(line: 155, column: 13, scope: !334, inlinedAt: !130)
!342 = !DILocation(line: 155, column: 22, scope: !334, inlinedAt: !130)
!343 = !DILocation(line: 157, column: 19, scope: !334, inlinedAt: !130)
!344 = !DILocation(line: 159, column: 19, scope: !334, inlinedAt: !130)
!345 = !DILocation(line: 154, column: 32, scope: !331, inlinedAt: !130)
!346 = !DILocation(line: 154, column: 9, scope: !331, inlinedAt: !130)
!347 = distinct !{!347, !332, !348, !115}
!348 = !DILocation(line: 160, column: 9, scope: !326, inlinedAt: !130)
!349 = !DILocation(line: 149, column: 25, scope: !321, inlinedAt: !130)
!350 = !DILocation(line: 149, column: 5, scope: !321, inlinedAt: !130)
!351 = distinct !{!351, !322, !352, !115}
!352 = !DILocation(line: 161, column: 5, scope: !318, inlinedAt: !130)
!353 = !DILocation(line: 163, column: 10, scope: !354, inlinedAt: !130)
!354 = distinct !DILexicalBlock(scope: !126, file: !11, line: 163, column: 5)
!355 = !DILocation(line: 0, scope: !354, inlinedAt: !130)
!356 = !DILocation(line: 163, column: 16, scope: !357, inlinedAt: !130)
!357 = distinct !DILexicalBlock(scope: !354, file: !11, line: 163, column: 5)
!358 = !DILocation(line: 163, column: 5, scope: !354, inlinedAt: !130)
!359 = !DILocation(line: 164, column: 14, scope: !360, inlinedAt: !130)
!360 = distinct !DILexicalBlock(scope: !357, file: !11, line: 164, column: 9)
!361 = !DILocation(line: 0, scope: !360, inlinedAt: !130)
!362 = !DILocation(line: 164, column: 20, scope: !363, inlinedAt: !130)
!363 = distinct !DILexicalBlock(scope: !360, file: !11, line: 164, column: 9)
!364 = !DILocation(line: 164, column: 9, scope: !360, inlinedAt: !130)
!365 = !DILocation(line: 165, column: 32, scope: !363, inlinedAt: !130)
!366 = !DILocation(line: 165, column: 43, scope: !363, inlinedAt: !130)
!367 = !DILocation(line: 165, column: 41, scope: !363, inlinedAt: !130)
!368 = !DILocation(line: 165, column: 30, scope: !363, inlinedAt: !130)
!369 = !DILocation(line: 165, column: 13, scope: !363, inlinedAt: !130)
!370 = !DILocation(line: 165, column: 26, scope: !363, inlinedAt: !130)
!371 = !DILocation(line: 164, column: 29, scope: !363, inlinedAt: !130)
!372 = !DILocation(line: 164, column: 9, scope: !363, inlinedAt: !130)
!373 = distinct !{!373, !364, !374, !115}
!374 = !DILocation(line: 165, column: 51, scope: !360, inlinedAt: !130)
!375 = !DILocation(line: 163, column: 25, scope: !357, inlinedAt: !130)
!376 = !DILocation(line: 163, column: 5, scope: !357, inlinedAt: !130)
!377 = distinct !{!377, !358, !378, !115}
!378 = !DILocation(line: 165, column: 51, scope: !354, inlinedAt: !130)
!379 = !DILocation(line: 188, column: 3, scope: !121)
!380 = distinct !DISubprogram(name: "workload_checksum", scope: !11, file: !11, line: 190, type: !381, scopeLine: 190, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !2, retainedNodes: !60)
!381 = !DISubroutineType(types: !382)
!382 = !{!20, !6}
!383 = !DILocalVariable(name: "task", arg: 1, scope: !380, file: !11, line: 190, type: !6)
!384 = !DILocation(line: 0, scope: !380)
!385 = !DILocation(line: 192, column: 11, scope: !380)
!386 = !DILocation(line: 193, column: 15, scope: !380)
!387 = !DILocation(line: 193, column: 18, scope: !380)
!388 = !DILocation(line: 193, column: 3, scope: !380)
!389 = !DILocation(line: 194, column: 10, scope: !380)
!390 = !DILocation(line: 194, column: 3, scope: !380)
!391 = distinct !DISubprogram(name: "print_array", scope: !11, file: !11, line: 57, type: !392, scopeLine: 60, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition, unit: !2, retainedNodes: !60)
!392 = !DISubroutineType(types: !393)
!393 = !{null, !12, !12, !79}
!394 = !DILocalVariable(name: "w", arg: 1, scope: !391, file: !11, line: 57, type: !12)
!395 = !DILocation(line: 0, scope: !391)
!396 = !DILocalVariable(name: "h", arg: 2, scope: !391, file: !11, line: 57, type: !12)
!397 = !DILocalVariable(name: "imgOut", arg: 3, scope: !391, file: !11, line: 58, type: !79)
!398 = !DILocation(line: 63, column: 3, scope: !391)
!399 = !DILocation(line: 64, column: 3, scope: !391)
!400 = !DILocalVariable(name: "i", scope: !391, file: !11, line: 61, type: !12)
!401 = !DILocation(line: 65, column: 8, scope: !402)
!402 = distinct !DILexicalBlock(scope: !391, file: !11, line: 65, column: 3)
!403 = !DILocation(line: 0, scope: !402)
!404 = !DILocation(line: 65, column: 17, scope: !405)
!405 = distinct !DILexicalBlock(scope: !402, file: !11, line: 65, column: 3)
!406 = !DILocation(line: 65, column: 3, scope: !402)
!407 = !DILocalVariable(name: "j", scope: !391, file: !11, line: 61, type: !12)
!408 = !DILocation(line: 66, column: 10, scope: !409)
!409 = distinct !DILexicalBlock(scope: !405, file: !11, line: 66, column: 5)
!410 = !DILocation(line: 0, scope: !409)
!411 = !DILocation(line: 66, column: 19, scope: !412)
!412 = distinct !DILexicalBlock(scope: !409, file: !11, line: 66, column: 5)
!413 = !DILocation(line: 66, column: 5, scope: !409)
!414 = !DILocation(line: 67, column: 14, scope: !415)
!415 = distinct !DILexicalBlock(scope: !416, file: !11, line: 67, column: 11)
!416 = distinct !DILexicalBlock(scope: !412, file: !11, line: 66, column: 29)
!417 = !DILocation(line: 67, column: 18, scope: !415)
!418 = !DILocation(line: 67, column: 23, scope: !415)
!419 = !DILocation(line: 67, column: 28, scope: !415)
!420 = !DILocation(line: 67, column: 11, scope: !416)
!421 = !DILocation(line: 67, column: 42, scope: !415)
!422 = !DILocation(line: 67, column: 34, scope: !415)
!423 = !DILocation(line: 68, column: 15, scope: !416)
!424 = !DILocation(line: 68, column: 60, scope: !416)
!425 = !DILocation(line: 68, column: 7, scope: !416)
!426 = !DILocation(line: 69, column: 5, scope: !416)
!427 = !DILocation(line: 66, column: 25, scope: !412)
!428 = !DILocation(line: 66, column: 5, scope: !412)
!429 = distinct !{!429, !413, !430, !115}
!430 = !DILocation(line: 69, column: 5, scope: !409)
!431 = !DILocation(line: 65, column: 23, scope: !405)
!432 = !DILocation(line: 65, column: 3, scope: !405)
!433 = distinct !{!433, !406, !434, !115}
!434 = !DILocation(line: 69, column: 5, scope: !402)
!435 = !DILocation(line: 70, column: 3, scope: !391)
!436 = !DILocation(line: 71, column: 3, scope: !391)
!437 = !DILocation(line: 72, column: 1, scope: !391)
!438 = distinct !DISubprogram(name: "pb_fprintf", scope: !32, file: !32, line: 13, type: !439, scopeLine: 14, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition, unit: !2, retainedNodes: !60)
!439 = !DISubroutineType(types: !440)
!440 = !{!12, !441, !500, null}
!441 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !442, size: 64)
!442 = !DIDerivedType(tag: DW_TAG_typedef, name: "FILE", file: !443, line: 7, baseType: !444)
!443 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/types/FILE.h", directory: "", checksumkind: CSK_MD5, checksum: "571f9fb6223c42439075fdde11a0de5d")
!444 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "_IO_FILE", file: !445, line: 49, size: 1728, elements: !446)
!445 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/types/struct_FILE.h", directory: "", checksumkind: CSK_MD5, checksum: "1bad07471b7974df4ecc1d1c2ca207e6")
!446 = !{!447, !448, !451, !452, !453, !454, !455, !456, !457, !458, !459, !460, !461, !464, !466, !467, !468, !471, !473, !475, !477, !480, !482, !485, !488, !489, !491, !495, !496}
!447 = !DIDerivedType(tag: DW_TAG_member, name: "_flags", scope: !444, file: !445, line: 51, baseType: !12, size: 32)
!448 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_read_ptr", scope: !444, file: !445, line: 54, baseType: !449, size: 64, offset: 64)
!449 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !450, size: 64)
!450 = !DIBasicType(name: "char", size: 8, encoding: DW_ATE_signed_char)
!451 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_read_end", scope: !444, file: !445, line: 55, baseType: !449, size: 64, offset: 128)
!452 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_read_base", scope: !444, file: !445, line: 56, baseType: !449, size: 64, offset: 192)
!453 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_write_base", scope: !444, file: !445, line: 57, baseType: !449, size: 64, offset: 256)
!454 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_write_ptr", scope: !444, file: !445, line: 58, baseType: !449, size: 64, offset: 320)
!455 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_write_end", scope: !444, file: !445, line: 59, baseType: !449, size: 64, offset: 384)
!456 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_buf_base", scope: !444, file: !445, line: 60, baseType: !449, size: 64, offset: 448)
!457 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_buf_end", scope: !444, file: !445, line: 61, baseType: !449, size: 64, offset: 512)
!458 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_save_base", scope: !444, file: !445, line: 64, baseType: !449, size: 64, offset: 576)
!459 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_backup_base", scope: !444, file: !445, line: 65, baseType: !449, size: 64, offset: 640)
!460 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_save_end", scope: !444, file: !445, line: 66, baseType: !449, size: 64, offset: 704)
!461 = !DIDerivedType(tag: DW_TAG_member, name: "_markers", scope: !444, file: !445, line: 68, baseType: !462, size: 64, offset: 768)
!462 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !463, size: 64)
!463 = !DICompositeType(tag: DW_TAG_structure_type, name: "_IO_marker", file: !445, line: 36, flags: DIFlagFwdDecl)
!464 = !DIDerivedType(tag: DW_TAG_member, name: "_chain", scope: !444, file: !445, line: 70, baseType: !465, size: 64, offset: 832)
!465 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !444, size: 64)
!466 = !DIDerivedType(tag: DW_TAG_member, name: "_fileno", scope: !444, file: !445, line: 72, baseType: !12, size: 32, offset: 896)
!467 = !DIDerivedType(tag: DW_TAG_member, name: "_flags2", scope: !444, file: !445, line: 73, baseType: !12, size: 32, offset: 928)
!468 = !DIDerivedType(tag: DW_TAG_member, name: "_old_offset", scope: !444, file: !445, line: 74, baseType: !469, size: 64, offset: 960)
!469 = !DIDerivedType(tag: DW_TAG_typedef, name: "__off_t", file: !23, line: 152, baseType: !470)
!470 = !DIBasicType(name: "long", size: 64, encoding: DW_ATE_signed)
!471 = !DIDerivedType(tag: DW_TAG_member, name: "_cur_column", scope: !444, file: !445, line: 77, baseType: !472, size: 16, offset: 1024)
!472 = !DIBasicType(name: "unsigned short", size: 16, encoding: DW_ATE_unsigned)
!473 = !DIDerivedType(tag: DW_TAG_member, name: "_vtable_offset", scope: !444, file: !445, line: 78, baseType: !474, size: 8, offset: 1040)
!474 = !DIBasicType(name: "signed char", size: 8, encoding: DW_ATE_signed_char)
!475 = !DIDerivedType(tag: DW_TAG_member, name: "_shortbuf", scope: !444, file: !445, line: 79, baseType: !476, size: 8, offset: 1048)
!476 = !DICompositeType(tag: DW_TAG_array_type, baseType: !450, size: 8, elements: !24)
!477 = !DIDerivedType(tag: DW_TAG_member, name: "_lock", scope: !444, file: !445, line: 81, baseType: !478, size: 64, offset: 1088)
!478 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !479, size: 64)
!479 = !DIDerivedType(tag: DW_TAG_typedef, name: "_IO_lock_t", file: !445, line: 43, baseType: null)
!480 = !DIDerivedType(tag: DW_TAG_member, name: "_offset", scope: !444, file: !445, line: 89, baseType: !481, size: 64, offset: 1152)
!481 = !DIDerivedType(tag: DW_TAG_typedef, name: "__off64_t", file: !23, line: 153, baseType: !470)
!482 = !DIDerivedType(tag: DW_TAG_member, name: "_codecvt", scope: !444, file: !445, line: 91, baseType: !483, size: 64, offset: 1216)
!483 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !484, size: 64)
!484 = !DICompositeType(tag: DW_TAG_structure_type, name: "_IO_codecvt", file: !445, line: 37, flags: DIFlagFwdDecl)
!485 = !DIDerivedType(tag: DW_TAG_member, name: "_wide_data", scope: !444, file: !445, line: 92, baseType: !486, size: 64, offset: 1280)
!486 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !487, size: 64)
!487 = !DICompositeType(tag: DW_TAG_structure_type, name: "_IO_wide_data", file: !445, line: 38, flags: DIFlagFwdDecl)
!488 = !DIDerivedType(tag: DW_TAG_member, name: "_freeres_list", scope: !444, file: !445, line: 93, baseType: !465, size: 64, offset: 1344)
!489 = !DIDerivedType(tag: DW_TAG_member, name: "_freeres_buf", scope: !444, file: !445, line: 94, baseType: !490, size: 64, offset: 1408)
!490 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: null, size: 64)
!491 = !DIDerivedType(tag: DW_TAG_member, name: "__pad5", scope: !444, file: !445, line: 95, baseType: !492, size: 64, offset: 1472)
!492 = !DIDerivedType(tag: DW_TAG_typedef, name: "size_t", file: !493, line: 46, baseType: !494)
!493 = !DIFile(filename: "/usr/lib/llvm-14/lib/clang/14.0.0/include/stddef.h", directory: "", checksumkind: CSK_MD5, checksum: "2499dd2361b915724b073282bea3a7bc")
!494 = !DIBasicType(name: "unsigned long", size: 64, encoding: DW_ATE_unsigned)
!495 = !DIDerivedType(tag: DW_TAG_member, name: "_mode", scope: !444, file: !445, line: 96, baseType: !12, size: 32, offset: 1536)
!496 = !DIDerivedType(tag: DW_TAG_member, name: "_unused2", scope: !444, file: !445, line: 98, baseType: !497, size: 160, offset: 1568)
!497 = !DICompositeType(tag: DW_TAG_array_type, baseType: !450, size: 160, elements: !498)
!498 = !{!499}
!499 = !DISubrange(count: 20)
!500 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !501, size: 64)
!501 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !450)
!502 = !DILocalVariable(name: "stream", arg: 1, scope: !438, file: !32, line: 13, type: !441)
!503 = !DILocation(line: 0, scope: !438)
!504 = !DILocalVariable(name: "format", arg: 2, scope: !438, file: !32, line: 13, type: !500)
!505 = !DILocalVariable(name: "buffer", scope: !438, file: !32, line: 15, type: !506)
!506 = !DICompositeType(tag: DW_TAG_array_type, baseType: !450, size: 6144, elements: !507)
!507 = !{!508}
!508 = !DISubrange(count: 768)
!509 = !DILocation(line: 15, column: 10, scope: !438)
!510 = !DILocalVariable(name: "args", scope: !438, file: !32, line: 16, type: !511)
!511 = !DIDerivedType(tag: DW_TAG_typedef, name: "va_list", file: !512, line: 52, baseType: !513)
!512 = !DIFile(filename: "/usr/include/stdio.h", directory: "", checksumkind: CSK_MD5, checksum: "f31eefcc3f15835fc5a4023a625cf609")
!513 = !DIDerivedType(tag: DW_TAG_typedef, name: "__gnuc_va_list", file: !514, line: 32, baseType: !515)
!514 = !DIFile(filename: "/usr/lib/llvm-14/lib/clang/14.0.0/include/stdarg.h", directory: "", checksumkind: CSK_MD5, checksum: "4de3cbd931b589d291e5c39387aecf82")
!515 = !DIDerivedType(tag: DW_TAG_typedef, name: "__builtin_va_list", file: !516, baseType: !517)
!516 = !DIFile(filename: "source/workload.c", directory: "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/triangular-20260929/suite/deriche")
!517 = !DICompositeType(tag: DW_TAG_array_type, baseType: !518, size: 192, elements: !24)
!518 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "__va_list_tag", size: 192, elements: !519)
!519 = !{!520, !521, !522, !523}
!520 = !DIDerivedType(tag: DW_TAG_member, name: "gp_offset", scope: !518, file: !516, line: 16, baseType: !6, size: 32)
!521 = !DIDerivedType(tag: DW_TAG_member, name: "fp_offset", scope: !518, file: !516, line: 16, baseType: !6, size: 32, offset: 32)
!522 = !DIDerivedType(tag: DW_TAG_member, name: "overflow_arg_area", scope: !518, file: !516, line: 16, baseType: !490, size: 64, offset: 64)
!523 = !DIDerivedType(tag: DW_TAG_member, name: "reg_save_area", scope: !518, file: !516, line: 16, baseType: !490, size: 64, offset: 128)
!524 = !DILocation(line: 16, column: 13, scope: !438)
!525 = !DILocation(line: 17, column: 5, scope: !438)
!526 = !DILocation(line: 18, column: 27, scope: !438)
!527 = !DILocation(line: 18, column: 59, scope: !438)
!528 = !DILocation(line: 18, column: 17, scope: !438)
!529 = !DILocalVariable(name: "count", scope: !438, file: !32, line: 18, type: !12)
!530 = !DILocation(line: 19, column: 5, scope: !438)
!531 = !DILocation(line: 20, column: 15, scope: !532)
!532 = distinct !DILexicalBlock(scope: !438, file: !32, line: 20, column: 9)
!533 = !DILocation(line: 20, column: 19, scope: !532)
!534 = !DILocation(line: 20, column: 22, scope: !532)
!535 = !DILocation(line: 20, column: 38, scope: !532)
!536 = !DILocation(line: 20, column: 9, scope: !438)
!537 = !DILocation(line: 20, column: 57, scope: !532)
!538 = !DILocalVariable(name: "i", scope: !539, file: !32, line: 21, type: !12)
!539 = distinct !DILexicalBlock(scope: !438, file: !32, line: 21, column: 5)
!540 = !DILocation(line: 0, scope: !539)
!541 = !DILocation(line: 21, column: 10, scope: !539)
!542 = !DILocation(line: 21, column: 23, scope: !543)
!543 = distinct !DILexicalBlock(scope: !539, file: !32, line: 21, column: 5)
!544 = !DILocation(line: 21, column: 5, scope: !539)
!545 = !DILocation(line: 22, column: 35, scope: !546)
!546 = distinct !DILexicalBlock(scope: !543, file: !32, line: 21, column: 37)
!547 = !DILocation(line: 22, column: 20, scope: !546)
!548 = !DILocation(line: 22, column: 17, scope: !546)
!549 = !DILocation(line: 23, column: 17, scope: !546)
!550 = !DILocation(line: 24, column: 5, scope: !546)
!551 = !DILocation(line: 21, column: 32, scope: !543)
!552 = !DILocation(line: 21, column: 5, scope: !543)
!553 = distinct !{!553, !544, !554, !115}
!554 = !DILocation(line: 24, column: 5, scope: !539)
!555 = !DILocation(line: 29, column: 11, scope: !438)
!556 = !DILocation(line: 31, column: 5, scope: !438)
