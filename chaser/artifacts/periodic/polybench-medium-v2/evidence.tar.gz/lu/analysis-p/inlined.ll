; ModuleID = 'workload.ll'
source_filename = "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/triangular-20260929/suite/lu/source/workload.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

%struct._IO_FILE = type { i32, i8*, i8*, i8*, i8*, i8*, i8*, i8*, i8*, i8*, i8*, i8*, %struct._IO_marker*, %struct._IO_FILE*, i32, i32, i64, i16, i8, [1 x i8], i8*, i64, %struct._IO_codecvt*, %struct._IO_wide_data*, %struct._IO_FILE*, i8*, i64, i32, [20 x i8] }
%struct._IO_marker = type opaque
%struct._IO_codecvt = type opaque
%struct._IO_wide_data = type opaque
%struct.__va_list_tag = type { i32, i32, i8*, i8* }

@n = dso_local global i32 400, align 4, !dbg !0
@B = dso_local global [400 x [400 x double]] zeroinitializer, section ".chaser_data.B", align 64, !dbg !30
@A = dso_local global [400 x [400 x double]] zeroinitializer, section ".chaser_data.A", align 64, !dbg !35
@.str = private unnamed_addr constant [12 x i8] c"ape.analyze\00", section "llvm.metadata"
@.str.1 = private unnamed_addr constant [117 x i8] c"/workspace/experiments-array-support/chaser/.cache/periodic-polybench/triangular-20260929/suite/lu/source/workload.c\00", section "llvm.metadata"
@pb_hash = internal global i32 0, align 4, !dbg !27
@workload_jobs = dso_local constant [1 x i32 ()*] [i32 ()* @task_job_polybench], align 8, !dbg !9
@workload_expected = dso_local constant [1 x i32] [i32 1444296104], align 4, !dbg !23
@stderr = external global %struct._IO_FILE*, align 8
@.str.2 = private unnamed_addr constant [23 x i8] c"==BEGIN DUMP_ARRAYS==\0A\00", align 1
@.str.3 = private unnamed_addr constant [15 x i8] c"begin dump: %s\00", align 1
@.str.4 = private unnamed_addr constant [2 x i8] c"A\00", align 1
@.str.5 = private unnamed_addr constant [2 x i8] c"\0A\00", align 1
@.str.6 = private unnamed_addr constant [8 x i8] c"%0.2lf \00", align 1
@.str.7 = private unnamed_addr constant [17 x i8] c"\0Aend   dump: %s\0A\00", align 1
@.str.8 = private unnamed_addr constant [23 x i8] c"==END   DUMP_ARRAYS==\0A\00", align 1
@pb_emit = internal global i32 1, align 4, !dbg !37
@llvm.global.annotations = appending global [1 x { i8*, i8*, i8*, i32, i8* }] [{ i8*, i8*, i8*, i32, i8* } { i8* bitcast (i32 ()* @task_job_polybench to i8*), i8* getelementptr inbounds ([12 x i8], [12 x i8]* @.str, i32 0, i32 0), i8* getelementptr inbounds ([117 x i8], [117 x i8]* @.str.1, i32 0, i32 0), i32 127, i8* null }], section "llvm.metadata"

; Function Attrs: noinline nounwind uwtable
define dso_local void @workload_prepare() #0 !dbg !48 {
  ret void, !dbg !52
}

; Function Attrs: noinline nounwind uwtable
define dso_local void @workload_reset(i32 noundef %0) #0 !dbg !53 {
  call void @llvm.dbg.value(metadata i32 %0, metadata !56, metadata !DIExpression()), !dbg !57
  call void @llvm.memset.p0i8.i64(i8* align 64 bitcast ([400 x [400 x double]]* @B to i8*), i8 0, i64 1280000, i1 false), !dbg !58
  call void @llvm.memset.p0i8.i64(i8* align 64 bitcast ([400 x [400 x double]]* @A to i8*), i8 0, i64 1280000, i1 false), !dbg !59
  %2 = load i32, i32* @n, align 4, !dbg !60
  call void @init_array(i32 noundef %2, [400 x double]* noundef getelementptr inbounds ([400 x [400 x double]], [400 x [400 x double]]* @A, i64 0, i64 0)), !dbg !61
  ret void, !dbg !62
}

; Function Attrs: nofree nosync nounwind readnone speculatable willreturn
declare void @llvm.dbg.declare(metadata, metadata, metadata) #1

; Function Attrs: argmemonly nofree nounwind willreturn writeonly
declare void @llvm.memset.p0i8.i64(i8* nocapture writeonly, i8, i64, i1 immarg) #2

; Function Attrs: noinline nounwind uwtable
define internal void @init_array(i32 noundef %0, [400 x double]* noundef %1) #0 !dbg !63 {
  call void @llvm.dbg.value(metadata i32 %0, metadata !69, metadata !DIExpression()), !dbg !70
  call void @llvm.dbg.value(metadata [400 x double]* %1, metadata !71, metadata !DIExpression()), !dbg !70
  call void @llvm.dbg.value(metadata i32 0, metadata !72, metadata !DIExpression()), !dbg !70
  br label %3, !dbg !73

3:                                                ; preds = %37, %2
  %.02 = phi i32 [ 0, %2 ], [ %38, %37 ], !dbg !75
  call void @llvm.dbg.value(metadata i32 %.02, metadata !72, metadata !DIExpression()), !dbg !70
  %4 = icmp slt i32 %.02, %0, !dbg !76
  br i1 %4, label %5, label %39, !dbg !78

5:                                                ; preds = %3
  call void @llvm.dbg.value(metadata i32 0, metadata !79, metadata !DIExpression()), !dbg !70
  br label %6, !dbg !80

6:                                                ; preds = %19, %5
  %.03 = phi i32 [ 0, %5 ], [ %20, %19 ], !dbg !83
  call void @llvm.dbg.value(metadata i32 %.03, metadata !79, metadata !DIExpression()), !dbg !70
  %7 = icmp sle i32 %.03, %.02, !dbg !84
  br i1 %7, label %8, label %21, !dbg !86

8:                                                ; preds = %6
  %9 = sub nsw i32 0, %.03, !dbg !87
  %10 = srem i32 %9, %0, !dbg !88
  %11 = sitofp i32 %10 to double, !dbg !89
  %12 = sitofp i32 %0 to double, !dbg !90
  %13 = fdiv double %11, %12, !dbg !91
  %14 = fadd double %13, 1.000000e+00, !dbg !92
  %15 = sext i32 %.02 to i64, !dbg !93
  %16 = getelementptr inbounds [400 x double], [400 x double]* %1, i64 %15, !dbg !93
  %17 = sext i32 %.03 to i64, !dbg !93
  %18 = getelementptr inbounds [400 x double], [400 x double]* %16, i64 0, i64 %17, !dbg !93
  store double %14, double* %18, align 8, !dbg !94
  br label %19, !dbg !93

19:                                               ; preds = %8
  %20 = add nsw i32 %.03, 1, !dbg !95
  call void @llvm.dbg.value(metadata i32 %20, metadata !79, metadata !DIExpression()), !dbg !70
  br label %6, !dbg !96, !llvm.loop !97

21:                                               ; preds = %6
  %22 = add nsw i32 %.02, 1, !dbg !100
  call void @llvm.dbg.value(metadata i32 %22, metadata !79, metadata !DIExpression()), !dbg !70
  br label %23, !dbg !102

23:                                               ; preds = %30, %21
  %.14 = phi i32 [ %22, %21 ], [ %31, %30 ], !dbg !103
  call void @llvm.dbg.value(metadata i32 %.14, metadata !79, metadata !DIExpression()), !dbg !70
  %24 = icmp slt i32 %.14, %0, !dbg !104
  br i1 %24, label %25, label %32, !dbg !106

25:                                               ; preds = %23
  %26 = sext i32 %.02 to i64, !dbg !107
  %27 = getelementptr inbounds [400 x double], [400 x double]* %1, i64 %26, !dbg !107
  %28 = sext i32 %.14 to i64, !dbg !107
  %29 = getelementptr inbounds [400 x double], [400 x double]* %27, i64 0, i64 %28, !dbg !107
  store double 0.000000e+00, double* %29, align 8, !dbg !109
  br label %30, !dbg !110

30:                                               ; preds = %25
  %31 = add nsw i32 %.14, 1, !dbg !111
  call void @llvm.dbg.value(metadata i32 %31, metadata !79, metadata !DIExpression()), !dbg !70
  br label %23, !dbg !112, !llvm.loop !113

32:                                               ; preds = %23
  %33 = sext i32 %.02 to i64, !dbg !115
  %34 = getelementptr inbounds [400 x double], [400 x double]* %1, i64 %33, !dbg !115
  %35 = sext i32 %.02 to i64, !dbg !115
  %36 = getelementptr inbounds [400 x double], [400 x double]* %34, i64 0, i64 %35, !dbg !115
  store double 1.000000e+00, double* %36, align 8, !dbg !116
  br label %37, !dbg !117

37:                                               ; preds = %32
  %38 = add nsw i32 %.02, 1, !dbg !118
  call void @llvm.dbg.value(metadata i32 %38, metadata !72, metadata !DIExpression()), !dbg !70
  br label %3, !dbg !119, !llvm.loop !120

39:                                               ; preds = %3
  call void @llvm.dbg.value(metadata i32 0, metadata !122, metadata !DIExpression()), !dbg !70
  br label %40, !dbg !123

40:                                               ; preds = %53, %39
  %.05 = phi i32 [ 0, %39 ], [ %54, %53 ], !dbg !125
  call void @llvm.dbg.value(metadata i32 %.05, metadata !122, metadata !DIExpression()), !dbg !70
  %41 = icmp slt i32 %.05, %0, !dbg !126
  br i1 %41, label %42, label %55, !dbg !128

42:                                               ; preds = %40
  call void @llvm.dbg.value(metadata i32 0, metadata !129, metadata !DIExpression()), !dbg !70
  br label %43, !dbg !130

43:                                               ; preds = %50, %42
  %.01 = phi i32 [ 0, %42 ], [ %51, %50 ], !dbg !132
  call void @llvm.dbg.value(metadata i32 %.01, metadata !129, metadata !DIExpression()), !dbg !70
  %44 = icmp slt i32 %.01, %0, !dbg !133
  br i1 %44, label %45, label %52, !dbg !135

45:                                               ; preds = %43
  %46 = sext i32 %.05 to i64, !dbg !136
  %47 = getelementptr inbounds [400 x [400 x double]], [400 x [400 x double]]* @B, i64 0, i64 %46, !dbg !136
  %48 = sext i32 %.01 to i64, !dbg !136
  %49 = getelementptr inbounds [400 x double], [400 x double]* %47, i64 0, i64 %48, !dbg !136
  store double 0.000000e+00, double* %49, align 8, !dbg !137
  br label %50, !dbg !136

50:                                               ; preds = %45
  %51 = add nsw i32 %.01, 1, !dbg !138
  call void @llvm.dbg.value(metadata i32 %51, metadata !129, metadata !DIExpression()), !dbg !70
  br label %43, !dbg !139, !llvm.loop !140

52:                                               ; preds = %43
  br label %53, !dbg !141

53:                                               ; preds = %52
  %54 = add nsw i32 %.05, 1, !dbg !142
  call void @llvm.dbg.value(metadata i32 %54, metadata !122, metadata !DIExpression()), !dbg !70
  br label %40, !dbg !143, !llvm.loop !144

55:                                               ; preds = %40
  call void @llvm.dbg.value(metadata i32 0, metadata !146, metadata !DIExpression()), !dbg !70
  br label %56, !dbg !147

56:                                               ; preds = %88, %55
  %.0 = phi i32 [ 0, %55 ], [ %89, %88 ], !dbg !149
  call void @llvm.dbg.value(metadata i32 %.0, metadata !146, metadata !DIExpression()), !dbg !70
  %57 = icmp slt i32 %.0, %0, !dbg !150
  br i1 %57, label %58, label %90, !dbg !152

58:                                               ; preds = %56
  call void @llvm.dbg.value(metadata i32 0, metadata !122, metadata !DIExpression()), !dbg !70
  br label %59, !dbg !153

59:                                               ; preds = %85, %58
  %.16 = phi i32 [ 0, %58 ], [ %86, %85 ], !dbg !155
  call void @llvm.dbg.value(metadata i32 %.16, metadata !122, metadata !DIExpression()), !dbg !70
  %60 = icmp slt i32 %.16, %0, !dbg !156
  br i1 %60, label %61, label %87, !dbg !158

61:                                               ; preds = %59
  call void @llvm.dbg.value(metadata i32 0, metadata !129, metadata !DIExpression()), !dbg !70
  br label %62, !dbg !159

62:                                               ; preds = %82, %61
  %.1 = phi i32 [ 0, %61 ], [ %83, %82 ], !dbg !161
  call void @llvm.dbg.value(metadata i32 %.1, metadata !129, metadata !DIExpression()), !dbg !70
  %63 = icmp slt i32 %.1, %0, !dbg !162
  br i1 %63, label %64, label %84, !dbg !164

64:                                               ; preds = %62
  %65 = sext i32 %.16 to i64, !dbg !165
  %66 = getelementptr inbounds [400 x double], [400 x double]* %1, i64 %65, !dbg !165
  %67 = sext i32 %.0 to i64, !dbg !165
  %68 = getelementptr inbounds [400 x double], [400 x double]* %66, i64 0, i64 %67, !dbg !165
  %69 = load double, double* %68, align 8, !dbg !165
  %70 = sext i32 %.1 to i64, !dbg !166
  %71 = getelementptr inbounds [400 x double], [400 x double]* %1, i64 %70, !dbg !166
  %72 = sext i32 %.0 to i64, !dbg !166
  %73 = getelementptr inbounds [400 x double], [400 x double]* %71, i64 0, i64 %72, !dbg !166
  %74 = load double, double* %73, align 8, !dbg !166
  %75 = fmul double %69, %74, !dbg !167
  %76 = sext i32 %.16 to i64, !dbg !168
  %77 = getelementptr inbounds [400 x [400 x double]], [400 x [400 x double]]* @B, i64 0, i64 %76, !dbg !168
  %78 = sext i32 %.1 to i64, !dbg !168
  %79 = getelementptr inbounds [400 x double], [400 x double]* %77, i64 0, i64 %78, !dbg !168
  %80 = load double, double* %79, align 8, !dbg !169
  %81 = fadd double %80, %75, !dbg !169
  store double %81, double* %79, align 8, !dbg !169
  br label %82, !dbg !168

82:                                               ; preds = %64
  %83 = add nsw i32 %.1, 1, !dbg !170
  call void @llvm.dbg.value(metadata i32 %83, metadata !129, metadata !DIExpression()), !dbg !70
  br label %62, !dbg !171, !llvm.loop !172

84:                                               ; preds = %62
  br label %85, !dbg !173

85:                                               ; preds = %84
  %86 = add nsw i32 %.16, 1, !dbg !174
  call void @llvm.dbg.value(metadata i32 %86, metadata !122, metadata !DIExpression()), !dbg !70
  br label %59, !dbg !175, !llvm.loop !176

87:                                               ; preds = %59
  br label %88, !dbg !177

88:                                               ; preds = %87
  %89 = add nsw i32 %.0, 1, !dbg !178
  call void @llvm.dbg.value(metadata i32 %89, metadata !146, metadata !DIExpression()), !dbg !70
  br label %56, !dbg !179, !llvm.loop !180

90:                                               ; preds = %56
  call void @llvm.dbg.value(metadata i32 0, metadata !122, metadata !DIExpression()), !dbg !70
  br label %91, !dbg !182

91:                                               ; preds = %109, %90
  %.27 = phi i32 [ 0, %90 ], [ %110, %109 ], !dbg !184
  call void @llvm.dbg.value(metadata i32 %.27, metadata !122, metadata !DIExpression()), !dbg !70
  %92 = icmp slt i32 %.27, %0, !dbg !185
  br i1 %92, label %93, label %111, !dbg !187

93:                                               ; preds = %91
  call void @llvm.dbg.value(metadata i32 0, metadata !129, metadata !DIExpression()), !dbg !70
  br label %94, !dbg !188

94:                                               ; preds = %106, %93
  %.2 = phi i32 [ 0, %93 ], [ %107, %106 ], !dbg !190
  call void @llvm.dbg.value(metadata i32 %.2, metadata !129, metadata !DIExpression()), !dbg !70
  %95 = icmp slt i32 %.2, %0, !dbg !191
  br i1 %95, label %96, label %108, !dbg !193

96:                                               ; preds = %94
  %97 = sext i32 %.27 to i64, !dbg !194
  %98 = getelementptr inbounds [400 x [400 x double]], [400 x [400 x double]]* @B, i64 0, i64 %97, !dbg !194
  %99 = sext i32 %.2 to i64, !dbg !194
  %100 = getelementptr inbounds [400 x double], [400 x double]* %98, i64 0, i64 %99, !dbg !194
  %101 = load double, double* %100, align 8, !dbg !194
  %102 = sext i32 %.27 to i64, !dbg !195
  %103 = getelementptr inbounds [400 x double], [400 x double]* %1, i64 %102, !dbg !195
  %104 = sext i32 %.2 to i64, !dbg !195
  %105 = getelementptr inbounds [400 x double], [400 x double]* %103, i64 0, i64 %104, !dbg !195
  store double %101, double* %105, align 8, !dbg !196
  br label %106, !dbg !195

106:                                              ; preds = %96
  %107 = add nsw i32 %.2, 1, !dbg !197
  call void @llvm.dbg.value(metadata i32 %107, metadata !129, metadata !DIExpression()), !dbg !70
  br label %94, !dbg !198, !llvm.loop !199

108:                                              ; preds = %94
  br label %109, !dbg !200

109:                                              ; preds = %108
  %110 = add nsw i32 %.27, 1, !dbg !201
  call void @llvm.dbg.value(metadata i32 %110, metadata !122, metadata !DIExpression()), !dbg !70
  br label %91, !dbg !202, !llvm.loop !203

111:                                              ; preds = %91
  ret void, !dbg !205
}

; Function Attrs: noinline nounwind uwtable
define dso_local i32 @task_job_polybench() #0 !dbg !206 {
  %1 = load i32, i32* @n, align 4, !dbg !207
  call void @llvm.dbg.value(metadata i32 %1, metadata !208, metadata !DIExpression()), !dbg !210
  call void @llvm.dbg.value(metadata [400 x double]* getelementptr inbounds ([400 x [400 x double]], [400 x [400 x double]]* @A, i64 0, i64 0), metadata !212, metadata !DIExpression()), !dbg !210
  call void @llvm.dbg.value(metadata i32 0, metadata !213, metadata !DIExpression()), !dbg !210
  br label %2, !dbg !214

2:                                                ; preds = %69, %0
  %.03 = phi i32 [ 0, %0 ], [ %70, %69 ], !dbg !216
  call void @llvm.dbg.value(metadata i32 %.03, metadata !213, metadata !DIExpression()), !dbg !210
  %3 = icmp slt i32 %.03, 400, !dbg !217
  br i1 %3, label %4, label %71, !dbg !219

4:                                                ; preds = %2
  call void @llvm.dbg.value(metadata i32 0, metadata !220, metadata !DIExpression()), !dbg !210
  br label %5, !dbg !221

5:                                                ; preds = %29, %4
  %.01 = phi i32 [ 0, %4 ], [ %41, %29 ], !dbg !224
  call void @llvm.dbg.value(metadata i32 %.01, metadata !220, metadata !DIExpression()), !dbg !210
  %6 = icmp slt i32 %.01, %.03, !dbg !225
  br i1 %6, label %7, label %42, !dbg !227

7:                                                ; preds = %5
  call void @llvm.dbg.value(metadata i32 0, metadata !228, metadata !DIExpression()), !dbg !210
  br label %8, !dbg !229

8:                                                ; preds = %10, %7
  %.0 = phi i32 [ 0, %7 ], [ %28, %10 ], !dbg !232
  call void @llvm.dbg.value(metadata i32 %.0, metadata !228, metadata !DIExpression()), !dbg !210
  %9 = icmp slt i32 %.0, %.01, !dbg !233
  br i1 %9, label %10, label %29, !dbg !235

10:                                               ; preds = %8
  %11 = sext i32 %.03 to i64, !dbg !236
  %12 = getelementptr inbounds [400 x double], [400 x double]* getelementptr inbounds ([400 x [400 x double]], [400 x [400 x double]]* @A, i64 0, i64 0), i64 %11, !dbg !236
  %13 = sext i32 %.0 to i64, !dbg !236
  %14 = getelementptr inbounds [400 x double], [400 x double]* %12, i64 0, i64 %13, !dbg !236
  %15 = load double, double* %14, align 8, !dbg !236
  %16 = sext i32 %.0 to i64, !dbg !238
  %17 = getelementptr inbounds [400 x double], [400 x double]* getelementptr inbounds ([400 x [400 x double]], [400 x [400 x double]]* @A, i64 0, i64 0), i64 %16, !dbg !238
  %18 = sext i32 %.01 to i64, !dbg !238
  %19 = getelementptr inbounds [400 x double], [400 x double]* %17, i64 0, i64 %18, !dbg !238
  %20 = load double, double* %19, align 8, !dbg !238
  %21 = fmul double %15, %20, !dbg !239
  %22 = sext i32 %.03 to i64, !dbg !240
  %23 = getelementptr inbounds [400 x double], [400 x double]* getelementptr inbounds ([400 x [400 x double]], [400 x [400 x double]]* @A, i64 0, i64 0), i64 %22, !dbg !240
  %24 = sext i32 %.01 to i64, !dbg !240
  %25 = getelementptr inbounds [400 x double], [400 x double]* %23, i64 0, i64 %24, !dbg !240
  %26 = load double, double* %25, align 8, !dbg !241
  %27 = fsub double %26, %21, !dbg !241
  store double %27, double* %25, align 8, !dbg !241
  %28 = add nsw i32 %.0, 1, !dbg !242
  call void @llvm.dbg.value(metadata i32 %28, metadata !228, metadata !DIExpression()), !dbg !210
  br label %8, !dbg !243, !llvm.loop !244

29:                                               ; preds = %8
  %30 = sext i32 %.01 to i64, !dbg !246
  %31 = getelementptr inbounds [400 x double], [400 x double]* getelementptr inbounds ([400 x [400 x double]], [400 x [400 x double]]* @A, i64 0, i64 0), i64 %30, !dbg !246
  %32 = sext i32 %.01 to i64, !dbg !246
  %33 = getelementptr inbounds [400 x double], [400 x double]* %31, i64 0, i64 %32, !dbg !246
  %34 = load double, double* %33, align 8, !dbg !246
  %35 = sext i32 %.03 to i64, !dbg !247
  %36 = getelementptr inbounds [400 x double], [400 x double]* getelementptr inbounds ([400 x [400 x double]], [400 x [400 x double]]* @A, i64 0, i64 0), i64 %35, !dbg !247
  %37 = sext i32 %.01 to i64, !dbg !247
  %38 = getelementptr inbounds [400 x double], [400 x double]* %36, i64 0, i64 %37, !dbg !247
  %39 = load double, double* %38, align 8, !dbg !248
  %40 = fdiv double %39, %34, !dbg !248
  store double %40, double* %38, align 8, !dbg !248
  %41 = add nsw i32 %.01, 1, !dbg !249
  call void @llvm.dbg.value(metadata i32 %41, metadata !220, metadata !DIExpression()), !dbg !210
  br label %5, !dbg !250, !llvm.loop !251

42:                                               ; preds = %5
  call void @llvm.dbg.value(metadata i32 %.03, metadata !220, metadata !DIExpression()), !dbg !210
  br label %43, !dbg !253

43:                                               ; preds = %67, %42
  %.12 = phi i32 [ %.03, %42 ], [ %68, %67 ], !dbg !255
  call void @llvm.dbg.value(metadata i32 %.12, metadata !220, metadata !DIExpression()), !dbg !210
  %44 = icmp slt i32 %.12, 400, !dbg !256
  br i1 %44, label %45, label %69, !dbg !258

45:                                               ; preds = %43
  call void @llvm.dbg.value(metadata i32 0, metadata !228, metadata !DIExpression()), !dbg !210
  br label %46, !dbg !259

46:                                               ; preds = %48, %45
  %.1 = phi i32 [ 0, %45 ], [ %66, %48 ], !dbg !262
  call void @llvm.dbg.value(metadata i32 %.1, metadata !228, metadata !DIExpression()), !dbg !210
  %47 = icmp slt i32 %.1, %.03, !dbg !263
  br i1 %47, label %48, label %67, !dbg !265

48:                                               ; preds = %46
  %49 = sext i32 %.03 to i64, !dbg !266
  %50 = getelementptr inbounds [400 x double], [400 x double]* getelementptr inbounds ([400 x [400 x double]], [400 x [400 x double]]* @A, i64 0, i64 0), i64 %49, !dbg !266
  %51 = sext i32 %.1 to i64, !dbg !266
  %52 = getelementptr inbounds [400 x double], [400 x double]* %50, i64 0, i64 %51, !dbg !266
  %53 = load double, double* %52, align 8, !dbg !266
  %54 = sext i32 %.1 to i64, !dbg !268
  %55 = getelementptr inbounds [400 x double], [400 x double]* getelementptr inbounds ([400 x [400 x double]], [400 x [400 x double]]* @A, i64 0, i64 0), i64 %54, !dbg !268
  %56 = sext i32 %.12 to i64, !dbg !268
  %57 = getelementptr inbounds [400 x double], [400 x double]* %55, i64 0, i64 %56, !dbg !268
  %58 = load double, double* %57, align 8, !dbg !268
  %59 = fmul double %53, %58, !dbg !269
  %60 = sext i32 %.03 to i64, !dbg !270
  %61 = getelementptr inbounds [400 x double], [400 x double]* getelementptr inbounds ([400 x [400 x double]], [400 x [400 x double]]* @A, i64 0, i64 0), i64 %60, !dbg !270
  %62 = sext i32 %.12 to i64, !dbg !270
  %63 = getelementptr inbounds [400 x double], [400 x double]* %61, i64 0, i64 %62, !dbg !270
  %64 = load double, double* %63, align 8, !dbg !271
  %65 = fsub double %64, %59, !dbg !271
  store double %65, double* %63, align 8, !dbg !271
  %66 = add nsw i32 %.1, 1, !dbg !272
  call void @llvm.dbg.value(metadata i32 %66, metadata !228, metadata !DIExpression()), !dbg !210
  br label %46, !dbg !273, !llvm.loop !274

67:                                               ; preds = %46
  %68 = add nsw i32 %.12, 1, !dbg !276
  call void @llvm.dbg.value(metadata i32 %68, metadata !220, metadata !DIExpression()), !dbg !210
  br label %43, !dbg !277, !llvm.loop !278

69:                                               ; preds = %43
  %70 = add nsw i32 %.03, 1, !dbg !280
  call void @llvm.dbg.value(metadata i32 %70, metadata !213, metadata !DIExpression()), !dbg !210
  br label %2, !dbg !281, !llvm.loop !282

71:                                               ; preds = %2
  ret i32 0, !dbg !284
}

; Function Attrs: noinline nounwind uwtable
define dso_local i32 @workload_checksum(i32 noundef %0) #0 !dbg !285 {
  call void @llvm.dbg.value(metadata i32 %0, metadata !288, metadata !DIExpression()), !dbg !289
  store i32 -2128831035, i32* @pb_hash, align 4, !dbg !290
  %2 = load i32, i32* @n, align 4, !dbg !291
  call void @print_array(i32 noundef %2, [400 x double]* noundef getelementptr inbounds ([400 x [400 x double]], [400 x [400 x double]]* @A, i64 0, i64 0)), !dbg !292
  %3 = load i32, i32* @pb_hash, align 4, !dbg !293
  ret i32 %3, !dbg !294
}

; Function Attrs: noinline nounwind uwtable
define internal void @print_array(i32 noundef %0, [400 x double]* noundef %1) #0 !dbg !295 {
  call void @llvm.dbg.value(metadata i32 %0, metadata !296, metadata !DIExpression()), !dbg !297
  call void @llvm.dbg.value(metadata [400 x double]* %1, metadata !298, metadata !DIExpression()), !dbg !297
  %3 = load %struct._IO_FILE*, %struct._IO_FILE** @stderr, align 8, !dbg !299
  %4 = call i32 (%struct._IO_FILE*, i8*, ...) @pb_fprintf(%struct._IO_FILE* noundef %3, i8* noundef getelementptr inbounds ([23 x i8], [23 x i8]* @.str.2, i64 0, i64 0)), !dbg !299
  %5 = load %struct._IO_FILE*, %struct._IO_FILE** @stderr, align 8, !dbg !300
  %6 = call i32 (%struct._IO_FILE*, i8*, ...) @pb_fprintf(%struct._IO_FILE* noundef %5, i8* noundef getelementptr inbounds ([15 x i8], [15 x i8]* @.str.3, i64 0, i64 0), i8* noundef getelementptr inbounds ([2 x i8], [2 x i8]* @.str.4, i64 0, i64 0)), !dbg !300
  call void @llvm.dbg.value(metadata i32 0, metadata !301, metadata !DIExpression()), !dbg !297
  br label %7, !dbg !302

7:                                                ; preds = %31, %2
  %.01 = phi i32 [ 0, %2 ], [ %32, %31 ], !dbg !304
  call void @llvm.dbg.value(metadata i32 %.01, metadata !301, metadata !DIExpression()), !dbg !297
  %8 = icmp slt i32 %.01, %0, !dbg !305
  br i1 %8, label %9, label %33, !dbg !307

9:                                                ; preds = %7
  call void @llvm.dbg.value(metadata i32 0, metadata !308, metadata !DIExpression()), !dbg !297
  br label %10, !dbg !309

10:                                               ; preds = %28, %9
  %.0 = phi i32 [ 0, %9 ], [ %29, %28 ], !dbg !311
  call void @llvm.dbg.value(metadata i32 %.0, metadata !308, metadata !DIExpression()), !dbg !297
  %11 = icmp slt i32 %.0, %0, !dbg !312
  br i1 %11, label %12, label %30, !dbg !314

12:                                               ; preds = %10
  %13 = mul nsw i32 %.01, %0, !dbg !315
  %14 = add nsw i32 %13, %.0, !dbg !318
  %15 = srem i32 %14, 20, !dbg !319
  %16 = icmp eq i32 %15, 0, !dbg !320
  br i1 %16, label %17, label %20, !dbg !321

17:                                               ; preds = %12
  %18 = load %struct._IO_FILE*, %struct._IO_FILE** @stderr, align 8, !dbg !322
  %19 = call i32 (%struct._IO_FILE*, i8*, ...) @pb_fprintf(%struct._IO_FILE* noundef %18, i8* noundef getelementptr inbounds ([2 x i8], [2 x i8]* @.str.5, i64 0, i64 0)), !dbg !323
  br label %20, !dbg !323

20:                                               ; preds = %17, %12
  %21 = load %struct._IO_FILE*, %struct._IO_FILE** @stderr, align 8, !dbg !324
  %22 = sext i32 %.01 to i64, !dbg !325
  %23 = getelementptr inbounds [400 x double], [400 x double]* %1, i64 %22, !dbg !325
  %24 = sext i32 %.0 to i64, !dbg !325
  %25 = getelementptr inbounds [400 x double], [400 x double]* %23, i64 0, i64 %24, !dbg !325
  %26 = load double, double* %25, align 8, !dbg !325
  %27 = call i32 (%struct._IO_FILE*, i8*, ...) @pb_fprintf(%struct._IO_FILE* noundef %21, i8* noundef getelementptr inbounds ([8 x i8], [8 x i8]* @.str.6, i64 0, i64 0), double noundef %26), !dbg !326
  br label %28, !dbg !327

28:                                               ; preds = %20
  %29 = add nsw i32 %.0, 1, !dbg !328
  call void @llvm.dbg.value(metadata i32 %29, metadata !308, metadata !DIExpression()), !dbg !297
  br label %10, !dbg !329, !llvm.loop !330

30:                                               ; preds = %10
  br label %31, !dbg !331

31:                                               ; preds = %30
  %32 = add nsw i32 %.01, 1, !dbg !332
  call void @llvm.dbg.value(metadata i32 %32, metadata !301, metadata !DIExpression()), !dbg !297
  br label %7, !dbg !333, !llvm.loop !334

33:                                               ; preds = %7
  %34 = load %struct._IO_FILE*, %struct._IO_FILE** @stderr, align 8, !dbg !336
  %35 = call i32 (%struct._IO_FILE*, i8*, ...) @pb_fprintf(%struct._IO_FILE* noundef %34, i8* noundef getelementptr inbounds ([17 x i8], [17 x i8]* @.str.7, i64 0, i64 0), i8* noundef getelementptr inbounds ([2 x i8], [2 x i8]* @.str.4, i64 0, i64 0)), !dbg !336
  %36 = load %struct._IO_FILE*, %struct._IO_FILE** @stderr, align 8, !dbg !337
  %37 = call i32 (%struct._IO_FILE*, i8*, ...) @pb_fprintf(%struct._IO_FILE* noundef %36, i8* noundef getelementptr inbounds ([23 x i8], [23 x i8]* @.str.8, i64 0, i64 0)), !dbg !337
  ret void, !dbg !338
}

; Function Attrs: noinline nounwind uwtable
define internal i32 @pb_fprintf(%struct._IO_FILE* noundef %0, i8* noundef %1, ...) #0 !dbg !339 {
  %3 = alloca [768 x i8], align 16
  %4 = alloca [1 x %struct.__va_list_tag], align 16
  call void @llvm.dbg.value(metadata %struct._IO_FILE* %0, metadata !403, metadata !DIExpression()), !dbg !404
  call void @llvm.dbg.value(metadata i8* %1, metadata !405, metadata !DIExpression()), !dbg !404
  call void @llvm.dbg.declare(metadata [768 x i8]* %3, metadata !406, metadata !DIExpression()), !dbg !410
  call void @llvm.dbg.declare(metadata [1 x %struct.__va_list_tag]* %4, metadata !411, metadata !DIExpression()), !dbg !425
  %5 = getelementptr inbounds [1 x %struct.__va_list_tag], [1 x %struct.__va_list_tag]* %4, i64 0, i64 0, !dbg !426
  %6 = bitcast %struct.__va_list_tag* %5 to i8*, !dbg !426
  call void @llvm.va_start(i8* %6), !dbg !426
  %7 = getelementptr inbounds [768 x i8], [768 x i8]* %3, i64 0, i64 0, !dbg !427
  %8 = getelementptr inbounds [1 x %struct.__va_list_tag], [1 x %struct.__va_list_tag]* %4, i64 0, i64 0, !dbg !428
  %9 = call i32 @vsnprintf(i8* noundef %7, i64 noundef 768, i8* noundef %1, %struct.__va_list_tag* noundef %8) #6, !dbg !429
  call void @llvm.dbg.value(metadata i32 %9, metadata !430, metadata !DIExpression()), !dbg !404
  %10 = getelementptr inbounds [1 x %struct.__va_list_tag], [1 x %struct.__va_list_tag]* %4, i64 0, i64 0, !dbg !431
  %11 = bitcast %struct.__va_list_tag* %10 to i8*, !dbg !431
  call void @llvm.va_end(i8* %11), !dbg !431
  %12 = icmp slt i32 %9, 0, !dbg !432
  br i1 %12, label %16, label %13, !dbg !434

13:                                               ; preds = %2
  %14 = zext i32 %9 to i64, !dbg !435
  %15 = icmp uge i64 %14, 768, !dbg !436
  br i1 %15, label %16, label %17, !dbg !437

16:                                               ; preds = %13, %2
  call void @abort() #7, !dbg !438
  unreachable, !dbg !438

17:                                               ; preds = %13
  call void @llvm.dbg.value(metadata i32 0, metadata !439, metadata !DIExpression()), !dbg !441
  br label %18, !dbg !442

18:                                               ; preds = %29, %17
  %.0 = phi i32 [ 0, %17 ], [ %30, %29 ], !dbg !441
  call void @llvm.dbg.value(metadata i32 %.0, metadata !439, metadata !DIExpression()), !dbg !441
  %19 = icmp slt i32 %.0, %9, !dbg !443
  br i1 %19, label %20, label %31, !dbg !445

20:                                               ; preds = %18
  %21 = sext i32 %.0 to i64, !dbg !446
  %22 = getelementptr inbounds [768 x i8], [768 x i8]* %3, i64 0, i64 %21, !dbg !446
  %23 = load i8, i8* %22, align 1, !dbg !446
  %24 = zext i8 %23 to i32, !dbg !448
  %25 = load i32, i32* @pb_hash, align 4, !dbg !449
  %26 = xor i32 %25, %24, !dbg !449
  store i32 %26, i32* @pb_hash, align 4, !dbg !449
  %27 = load i32, i32* @pb_hash, align 4, !dbg !450
  %28 = mul i32 %27, 16777619, !dbg !450
  store i32 %28, i32* @pb_hash, align 4, !dbg !450
  br label %29, !dbg !451

29:                                               ; preds = %20
  %30 = add nsw i32 %.0, 1, !dbg !452
  call void @llvm.dbg.value(metadata i32 %30, metadata !439, metadata !DIExpression()), !dbg !441
  br label %18, !dbg !453, !llvm.loop !454

31:                                               ; preds = %18
  %32 = load i32, i32* @pb_emit, align 4, !dbg !456
  ret i32 %9, !dbg !457
}

; Function Attrs: nofree nosync nounwind willreturn
declare void @llvm.va_start(i8*) #3

; Function Attrs: nounwind
declare i32 @vsnprintf(i8* noundef, i64 noundef, i8* noundef, %struct.__va_list_tag* noundef) #4

; Function Attrs: nofree nosync nounwind willreturn
declare void @llvm.va_end(i8*) #3

; Function Attrs: noreturn nounwind
declare void @abort() #5

; Function Attrs: nofree nosync nounwind readnone speculatable willreturn
declare void @llvm.dbg.value(metadata, metadata, metadata) #1

attributes #0 = { noinline nounwind uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { nofree nosync nounwind readnone speculatable willreturn }
attributes #2 = { argmemonly nofree nounwind willreturn writeonly }
attributes #3 = { nofree nosync nounwind willreturn }
attributes #4 = { nounwind "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #5 = { noreturn nounwind "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #6 = { nounwind }
attributes #7 = { noreturn nounwind }

!llvm.dbg.cu = !{!2}
!llvm.module.flags = !{!40, !41, !42, !43, !44, !45, !46}
!llvm.ident = !{!47}

!0 = !DIGlobalVariableExpression(var: !1, expr: !DIExpression())
!1 = distinct !DIGlobalVariable(name: "n", scope: !2, file: !11, line: 119, type: !39, isLocal: false, isDefinition: true)
!2 = distinct !DICompileUnit(language: DW_LANG_C99, file: !3, producer: "Ubuntu clang version 14.0.0-1ubuntu1.1", isOptimized: false, runtimeVersion: 0, emissionKind: FullDebug, retainedTypes: !4, globals: !8, splitDebugInlining: false, nameTableKind: None)
!3 = !DIFile(filename: "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/triangular-20260929/suite/lu/source/workload.c", directory: "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/triangular-20260929/suite/lu/analysis-p", checksumkind: CSK_MD5, checksum: "e586c9adff497d7a85517666c4560d4f")
!4 = !{!5, !6, !7}
!5 = !DIBasicType(name: "double", size: 64, encoding: DW_ATE_float)
!6 = !DIBasicType(name: "unsigned int", size: 32, encoding: DW_ATE_unsigned)
!7 = !DIBasicType(name: "unsigned char", size: 8, encoding: DW_ATE_unsigned_char)
!8 = !{!0, !9, !23, !27, !30, !35, !37}
!9 = !DIGlobalVariableExpression(var: !10, expr: !DIExpression())
!10 = distinct !DIGlobalVariable(name: "workload_jobs", scope: !2, file: !11, line: 137, type: !12, isLocal: false, isDefinition: true)
!11 = !DIFile(filename: "source/workload.c", directory: "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/triangular-20260929/suite/lu", checksumkind: CSK_MD5, checksum: "e586c9adff497d7a85517666c4560d4f")
!12 = !DICompositeType(tag: DW_TAG_array_type, baseType: !13, size: 64, elements: !21)
!13 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !14)
!14 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !15, size: 64)
!15 = !DISubroutineType(types: !16)
!16 = !{!17}
!17 = !DIDerivedType(tag: DW_TAG_typedef, name: "uint32_t", file: !18, line: 26, baseType: !19)
!18 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/stdint-uintn.h", directory: "", checksumkind: CSK_MD5, checksum: "2bf2ae53c58c01b1a1b9383b5195125c")
!19 = !DIDerivedType(tag: DW_TAG_typedef, name: "__uint32_t", file: !20, line: 42, baseType: !6)
!20 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/types.h", directory: "", checksumkind: CSK_MD5, checksum: "d108b5f93a74c50510d7d9bc0ab36df9")
!21 = !{!22}
!22 = !DISubrange(count: 1)
!23 = !DIGlobalVariableExpression(var: !24, expr: !DIExpression())
!24 = distinct !DIGlobalVariable(name: "workload_expected", scope: !2, file: !11, line: 141, type: !25, isLocal: false, isDefinition: true)
!25 = !DICompositeType(tag: DW_TAG_array_type, baseType: !26, size: 32, elements: !21)
!26 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !17)
!27 = !DIGlobalVariableExpression(var: !28, expr: !DIExpression())
!28 = distinct !DIGlobalVariable(name: "pb_hash", scope: !2, file: !29, line: 9, type: !17, isLocal: true, isDefinition: true)
!29 = !DIFile(filename: "source/adapter.h", directory: "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/triangular-20260929/suite/lu", checksumkind: CSK_MD5, checksum: "26a6068928b2092758f244a9d00163d7")
!30 = !DIGlobalVariableExpression(var: !31, expr: !DIExpression())
!31 = distinct !DIGlobalVariable(name: "B", scope: !2, file: !11, line: 34, type: !32, isLocal: false, isDefinition: true, align: 512)
!32 = !DICompositeType(tag: DW_TAG_array_type, baseType: !5, size: 10240000, elements: !33)
!33 = !{!34, !34}
!34 = !DISubrange(count: 400)
!35 = !DIGlobalVariableExpression(var: !36, expr: !DIExpression())
!36 = distinct !DIGlobalVariable(name: "A", scope: !2, file: !11, line: 35, type: !32, isLocal: false, isDefinition: true, align: 512)
!37 = !DIGlobalVariableExpression(var: !38, expr: !DIExpression())
!38 = distinct !DIGlobalVariable(name: "pb_emit", scope: !2, file: !29, line: 10, type: !39, isLocal: true, isDefinition: true)
!39 = !DIBasicType(name: "int", size: 32, encoding: DW_ATE_signed)
!40 = !{i32 7, !"Dwarf Version", i32 5}
!41 = !{i32 2, !"Debug Info Version", i32 3}
!42 = !{i32 1, !"wchar_size", i32 4}
!43 = !{i32 7, !"PIC Level", i32 2}
!44 = !{i32 7, !"PIE Level", i32 2}
!45 = !{i32 7, !"uwtable", i32 1}
!46 = !{i32 7, !"frame-pointer", i32 2}
!47 = !{!"Ubuntu clang version 14.0.0-1ubuntu1.1"}
!48 = distinct !DISubprogram(name: "workload_prepare", scope: !11, file: !11, line: 120, type: !49, scopeLine: 120, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !2, retainedNodes: !51)
!49 = !DISubroutineType(types: !50)
!50 = !{null}
!51 = !{}
!52 = !DILocation(line: 120, column: 30, scope: !48)
!53 = distinct !DISubprogram(name: "workload_reset", scope: !11, file: !11, line: 121, type: !54, scopeLine: 121, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !2, retainedNodes: !51)
!54 = !DISubroutineType(types: !55)
!55 = !{null, !6}
!56 = !DILocalVariable(name: "task", arg: 1, scope: !53, file: !11, line: 121, type: !6)
!57 = !DILocation(line: 0, scope: !53)
!58 = !DILocation(line: 123, column: 3, scope: !53)
!59 = !DILocation(line: 124, column: 3, scope: !53)
!60 = !DILocation(line: 125, column: 15, scope: !53)
!61 = !DILocation(line: 125, column: 3, scope: !53)
!62 = !DILocation(line: 126, column: 1, scope: !53)
!63 = distinct !DISubprogram(name: "init_array", scope: !11, file: !11, line: 37, type: !64, scopeLine: 39, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition, unit: !2, retainedNodes: !51)
!64 = !DISubroutineType(types: !65)
!65 = !{null, !39, !66}
!66 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !67, size: 64)
!67 = !DICompositeType(tag: DW_TAG_array_type, baseType: !5, size: 25600, elements: !68)
!68 = !{!34}
!69 = !DILocalVariable(name: "n", arg: 1, scope: !63, file: !11, line: 37, type: !39)
!70 = !DILocation(line: 0, scope: !63)
!71 = !DILocalVariable(name: "A", arg: 2, scope: !63, file: !11, line: 38, type: !66)
!72 = !DILocalVariable(name: "i", scope: !63, file: !11, line: 40, type: !39)
!73 = !DILocation(line: 42, column: 8, scope: !74)
!74 = distinct !DILexicalBlock(scope: !63, file: !11, line: 42, column: 3)
!75 = !DILocation(line: 0, scope: !74)
!76 = !DILocation(line: 42, column: 17, scope: !77)
!77 = distinct !DILexicalBlock(scope: !74, file: !11, line: 42, column: 3)
!78 = !DILocation(line: 42, column: 3, scope: !74)
!79 = !DILocalVariable(name: "j", scope: !63, file: !11, line: 40, type: !39)
!80 = !DILocation(line: 44, column: 12, scope: !81)
!81 = distinct !DILexicalBlock(scope: !82, file: !11, line: 44, column: 7)
!82 = distinct !DILexicalBlock(scope: !77, file: !11, line: 43, column: 5)
!83 = !DILocation(line: 0, scope: !81)
!84 = !DILocation(line: 44, column: 21, scope: !85)
!85 = distinct !DILexicalBlock(scope: !81, file: !11, line: 44, column: 7)
!86 = !DILocation(line: 44, column: 7, scope: !81)
!87 = !DILocation(line: 45, column: 24, scope: !85)
!88 = !DILocation(line: 45, column: 27, scope: !85)
!89 = !DILocation(line: 45, column: 12, scope: !85)
!90 = !DILocation(line: 45, column: 34, scope: !85)
!91 = !DILocation(line: 45, column: 32, scope: !85)
!92 = !DILocation(line: 45, column: 36, scope: !85)
!93 = !DILocation(line: 45, column: 2, scope: !85)
!94 = !DILocation(line: 45, column: 10, scope: !85)
!95 = !DILocation(line: 44, column: 28, scope: !85)
!96 = !DILocation(line: 44, column: 7, scope: !85)
!97 = distinct !{!97, !86, !98, !99}
!98 = !DILocation(line: 45, column: 38, scope: !81)
!99 = !{!"llvm.loop.mustprogress"}
!100 = !DILocation(line: 46, column: 17, scope: !101)
!101 = distinct !DILexicalBlock(scope: !82, file: !11, line: 46, column: 7)
!102 = !DILocation(line: 46, column: 12, scope: !101)
!103 = !DILocation(line: 0, scope: !101)
!104 = !DILocation(line: 46, column: 23, scope: !105)
!105 = distinct !DILexicalBlock(scope: !101, file: !11, line: 46, column: 7)
!106 = !DILocation(line: 46, column: 7, scope: !101)
!107 = !DILocation(line: 47, column: 2, scope: !108)
!108 = distinct !DILexicalBlock(scope: !105, file: !11, line: 46, column: 33)
!109 = !DILocation(line: 47, column: 10, scope: !108)
!110 = !DILocation(line: 48, column: 7, scope: !108)
!111 = !DILocation(line: 46, column: 29, scope: !105)
!112 = !DILocation(line: 46, column: 7, scope: !105)
!113 = distinct !{!113, !106, !114, !99}
!114 = !DILocation(line: 48, column: 7, scope: !101)
!115 = !DILocation(line: 49, column: 7, scope: !82)
!116 = !DILocation(line: 49, column: 15, scope: !82)
!117 = !DILocation(line: 50, column: 5, scope: !82)
!118 = !DILocation(line: 42, column: 23, scope: !77)
!119 = !DILocation(line: 42, column: 3, scope: !77)
!120 = distinct !{!120, !78, !121, !99}
!121 = !DILocation(line: 50, column: 5, scope: !74)
!122 = !DILocalVariable(name: "r", scope: !63, file: !11, line: 54, type: !39)
!123 = !DILocation(line: 56, column: 8, scope: !124)
!124 = distinct !DILexicalBlock(scope: !63, file: !11, line: 56, column: 3)
!125 = !DILocation(line: 0, scope: !124)
!126 = !DILocation(line: 56, column: 17, scope: !127)
!127 = distinct !DILexicalBlock(scope: !124, file: !11, line: 56, column: 3)
!128 = !DILocation(line: 56, column: 3, scope: !124)
!129 = !DILocalVariable(name: "s", scope: !63, file: !11, line: 54, type: !39)
!130 = !DILocation(line: 57, column: 10, scope: !131)
!131 = distinct !DILexicalBlock(scope: !127, file: !11, line: 57, column: 5)
!132 = !DILocation(line: 0, scope: !131)
!133 = !DILocation(line: 57, column: 19, scope: !134)
!134 = distinct !DILexicalBlock(scope: !131, file: !11, line: 57, column: 5)
!135 = !DILocation(line: 57, column: 5, scope: !131)
!136 = !DILocation(line: 58, column: 7, scope: !134)
!137 = !DILocation(line: 58, column: 34, scope: !134)
!138 = !DILocation(line: 57, column: 24, scope: !134)
!139 = !DILocation(line: 57, column: 5, scope: !134)
!140 = distinct !{!140, !135, !141, !99}
!141 = !DILocation(line: 58, column: 36, scope: !131)
!142 = !DILocation(line: 56, column: 22, scope: !127)
!143 = !DILocation(line: 56, column: 3, scope: !127)
!144 = distinct !{!144, !128, !145, !99}
!145 = !DILocation(line: 58, column: 36, scope: !124)
!146 = !DILocalVariable(name: "t", scope: !63, file: !11, line: 54, type: !39)
!147 = !DILocation(line: 59, column: 8, scope: !148)
!148 = distinct !DILexicalBlock(scope: !63, file: !11, line: 59, column: 3)
!149 = !DILocation(line: 0, scope: !148)
!150 = !DILocation(line: 59, column: 17, scope: !151)
!151 = distinct !DILexicalBlock(scope: !148, file: !11, line: 59, column: 3)
!152 = !DILocation(line: 59, column: 3, scope: !148)
!153 = !DILocation(line: 60, column: 10, scope: !154)
!154 = distinct !DILexicalBlock(scope: !151, file: !11, line: 60, column: 5)
!155 = !DILocation(line: 0, scope: !154)
!156 = !DILocation(line: 60, column: 19, scope: !157)
!157 = distinct !DILexicalBlock(scope: !154, file: !11, line: 60, column: 5)
!158 = !DILocation(line: 60, column: 5, scope: !154)
!159 = !DILocation(line: 61, column: 12, scope: !160)
!160 = distinct !DILexicalBlock(scope: !157, file: !11, line: 61, column: 7)
!161 = !DILocation(line: 0, scope: !160)
!162 = !DILocation(line: 61, column: 21, scope: !163)
!163 = distinct !DILexicalBlock(scope: !160, file: !11, line: 61, column: 7)
!164 = !DILocation(line: 61, column: 7, scope: !160)
!165 = !DILocation(line: 62, column: 32, scope: !163)
!166 = !DILocation(line: 62, column: 42, scope: !163)
!167 = !DILocation(line: 62, column: 40, scope: !163)
!168 = !DILocation(line: 62, column: 2, scope: !163)
!169 = !DILocation(line: 62, column: 29, scope: !163)
!170 = !DILocation(line: 61, column: 26, scope: !163)
!171 = !DILocation(line: 61, column: 7, scope: !163)
!172 = distinct !{!172, !164, !173, !99}
!173 = !DILocation(line: 62, column: 48, scope: !160)
!174 = !DILocation(line: 60, column: 24, scope: !157)
!175 = !DILocation(line: 60, column: 5, scope: !157)
!176 = distinct !{!176, !158, !177, !99}
!177 = !DILocation(line: 62, column: 48, scope: !154)
!178 = !DILocation(line: 59, column: 22, scope: !151)
!179 = !DILocation(line: 59, column: 3, scope: !151)
!180 = distinct !{!180, !152, !181, !99}
!181 = !DILocation(line: 62, column: 48, scope: !148)
!182 = !DILocation(line: 63, column: 10, scope: !183)
!183 = distinct !DILexicalBlock(scope: !63, file: !11, line: 63, column: 5)
!184 = !DILocation(line: 0, scope: !183)
!185 = !DILocation(line: 63, column: 19, scope: !186)
!186 = distinct !DILexicalBlock(scope: !183, file: !11, line: 63, column: 5)
!187 = !DILocation(line: 63, column: 5, scope: !183)
!188 = !DILocation(line: 64, column: 12, scope: !189)
!189 = distinct !DILexicalBlock(scope: !186, file: !11, line: 64, column: 7)
!190 = !DILocation(line: 0, scope: !189)
!191 = !DILocation(line: 64, column: 21, scope: !192)
!192 = distinct !DILexicalBlock(scope: !189, file: !11, line: 64, column: 7)
!193 = !DILocation(line: 64, column: 7, scope: !189)
!194 = !DILocation(line: 65, column: 12, scope: !192)
!195 = !DILocation(line: 65, column: 2, scope: !192)
!196 = !DILocation(line: 65, column: 10, scope: !192)
!197 = !DILocation(line: 64, column: 26, scope: !192)
!198 = !DILocation(line: 64, column: 7, scope: !192)
!199 = distinct !{!199, !193, !200, !99}
!200 = !DILocation(line: 65, column: 37, scope: !189)
!201 = !DILocation(line: 63, column: 24, scope: !186)
!202 = !DILocation(line: 63, column: 5, scope: !186)
!203 = distinct !{!203, !187, !204, !99}
!204 = !DILocation(line: 65, column: 37, scope: !183)
!205 = !DILocation(line: 68, column: 1, scope: !63)
!206 = distinct !DISubprogram(name: "task_job_polybench", scope: !11, file: !11, line: 127, type: !15, scopeLine: 127, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !2, retainedNodes: !51)
!207 = !DILocation(line: 128, column: 14, scope: !206)
!208 = !DILocalVariable(name: "n", arg: 1, scope: !209, file: !11, line: 95, type: !39)
!209 = distinct !DISubprogram(name: "kernel_lu", scope: !11, file: !11, line: 95, type: !64, scopeLine: 97, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition, unit: !2, retainedNodes: !51)
!210 = !DILocation(line: 0, scope: !209, inlinedAt: !211)
!211 = distinct !DILocation(line: 128, column: 3, scope: !206)
!212 = !DILocalVariable(name: "A", arg: 2, scope: !209, file: !11, line: 96, type: !66)
!213 = !DILocalVariable(name: "i", scope: !209, file: !11, line: 98, type: !39)
!214 = !DILocation(line: 101, column: 8, scope: !215, inlinedAt: !211)
!215 = distinct !DILexicalBlock(scope: !209, file: !11, line: 101, column: 3)
!216 = !DILocation(line: 0, scope: !215, inlinedAt: !211)
!217 = !DILocation(line: 101, column: 17, scope: !218, inlinedAt: !211)
!218 = distinct !DILexicalBlock(scope: !215, file: !11, line: 101, column: 3)
!219 = !DILocation(line: 101, column: 3, scope: !215, inlinedAt: !211)
!220 = !DILocalVariable(name: "j", scope: !209, file: !11, line: 98, type: !39)
!221 = !DILocation(line: 102, column: 10, scope: !222, inlinedAt: !211)
!222 = distinct !DILexicalBlock(scope: !223, file: !11, line: 102, column: 5)
!223 = distinct !DILexicalBlock(scope: !218, file: !11, line: 101, column: 31)
!224 = !DILocation(line: 0, scope: !222, inlinedAt: !211)
!225 = !DILocation(line: 102, column: 19, scope: !226, inlinedAt: !211)
!226 = distinct !DILexicalBlock(scope: !222, file: !11, line: 102, column: 5)
!227 = !DILocation(line: 102, column: 5, scope: !222, inlinedAt: !211)
!228 = !DILocalVariable(name: "k", scope: !209, file: !11, line: 98, type: !39)
!229 = !DILocation(line: 103, column: 13, scope: !230, inlinedAt: !211)
!230 = distinct !DILexicalBlock(scope: !231, file: !11, line: 103, column: 8)
!231 = distinct !DILexicalBlock(scope: !226, file: !11, line: 102, column: 28)
!232 = !DILocation(line: 0, scope: !230, inlinedAt: !211)
!233 = !DILocation(line: 103, column: 22, scope: !234, inlinedAt: !211)
!234 = distinct !DILexicalBlock(scope: !230, file: !11, line: 103, column: 8)
!235 = !DILocation(line: 103, column: 8, scope: !230, inlinedAt: !211)
!236 = !DILocation(line: 104, column: 22, scope: !237, inlinedAt: !211)
!237 = distinct !DILexicalBlock(scope: !234, file: !11, line: 103, column: 32)
!238 = !DILocation(line: 104, column: 32, scope: !237, inlinedAt: !211)
!239 = !DILocation(line: 104, column: 30, scope: !237, inlinedAt: !211)
!240 = !DILocation(line: 104, column: 11, scope: !237, inlinedAt: !211)
!241 = !DILocation(line: 104, column: 19, scope: !237, inlinedAt: !211)
!242 = !DILocation(line: 103, column: 28, scope: !234, inlinedAt: !211)
!243 = !DILocation(line: 103, column: 8, scope: !234, inlinedAt: !211)
!244 = distinct !{!244, !235, !245, !99}
!245 = !DILocation(line: 105, column: 8, scope: !230, inlinedAt: !211)
!246 = !DILocation(line: 106, column: 20, scope: !231, inlinedAt: !211)
!247 = !DILocation(line: 106, column: 9, scope: !231, inlinedAt: !211)
!248 = !DILocation(line: 106, column: 17, scope: !231, inlinedAt: !211)
!249 = !DILocation(line: 102, column: 24, scope: !226, inlinedAt: !211)
!250 = !DILocation(line: 102, column: 5, scope: !226, inlinedAt: !211)
!251 = distinct !{!251, !227, !252, !99}
!252 = !DILocation(line: 107, column: 5, scope: !222, inlinedAt: !211)
!253 = !DILocation(line: 108, column: 9, scope: !254, inlinedAt: !211)
!254 = distinct !DILexicalBlock(scope: !223, file: !11, line: 108, column: 4)
!255 = !DILocation(line: 0, scope: !254, inlinedAt: !211)
!256 = !DILocation(line: 108, column: 18, scope: !257, inlinedAt: !211)
!257 = distinct !DILexicalBlock(scope: !254, file: !11, line: 108, column: 4)
!258 = !DILocation(line: 108, column: 4, scope: !254, inlinedAt: !211)
!259 = !DILocation(line: 109, column: 13, scope: !260, inlinedAt: !211)
!260 = distinct !DILexicalBlock(scope: !261, file: !11, line: 109, column: 8)
!261 = distinct !DILexicalBlock(scope: !257, file: !11, line: 108, column: 32)
!262 = !DILocation(line: 0, scope: !260, inlinedAt: !211)
!263 = !DILocation(line: 109, column: 22, scope: !264, inlinedAt: !211)
!264 = distinct !DILexicalBlock(scope: !260, file: !11, line: 109, column: 8)
!265 = !DILocation(line: 109, column: 8, scope: !260, inlinedAt: !211)
!266 = !DILocation(line: 110, column: 22, scope: !267, inlinedAt: !211)
!267 = distinct !DILexicalBlock(scope: !264, file: !11, line: 109, column: 32)
!268 = !DILocation(line: 110, column: 32, scope: !267, inlinedAt: !211)
!269 = !DILocation(line: 110, column: 30, scope: !267, inlinedAt: !211)
!270 = !DILocation(line: 110, column: 11, scope: !267, inlinedAt: !211)
!271 = !DILocation(line: 110, column: 19, scope: !267, inlinedAt: !211)
!272 = !DILocation(line: 109, column: 28, scope: !264, inlinedAt: !211)
!273 = !DILocation(line: 109, column: 8, scope: !264, inlinedAt: !211)
!274 = distinct !{!274, !265, !275, !99}
!275 = !DILocation(line: 111, column: 8, scope: !260, inlinedAt: !211)
!276 = !DILocation(line: 108, column: 28, scope: !257, inlinedAt: !211)
!277 = !DILocation(line: 108, column: 4, scope: !257, inlinedAt: !211)
!278 = distinct !{!278, !258, !279, !99}
!279 = !DILocation(line: 112, column: 5, scope: !254, inlinedAt: !211)
!280 = !DILocation(line: 101, column: 27, scope: !218, inlinedAt: !211)
!281 = !DILocation(line: 101, column: 3, scope: !218, inlinedAt: !211)
!282 = distinct !{!282, !219, !283, !99}
!283 = !DILocation(line: 113, column: 3, scope: !215, inlinedAt: !211)
!284 = !DILocation(line: 129, column: 3, scope: !206)
!285 = distinct !DISubprogram(name: "workload_checksum", scope: !11, file: !11, line: 131, type: !286, scopeLine: 131, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !2, retainedNodes: !51)
!286 = !DISubroutineType(types: !287)
!287 = !{!17, !6}
!288 = !DILocalVariable(name: "task", arg: 1, scope: !285, file: !11, line: 131, type: !6)
!289 = !DILocation(line: 0, scope: !285)
!290 = !DILocation(line: 133, column: 11, scope: !285)
!291 = !DILocation(line: 134, column: 15, scope: !285)
!292 = !DILocation(line: 134, column: 3, scope: !285)
!293 = !DILocation(line: 135, column: 10, scope: !285)
!294 = !DILocation(line: 135, column: 3, scope: !285)
!295 = distinct !DISubprogram(name: "print_array", scope: !11, file: !11, line: 74, type: !64, scopeLine: 77, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition, unit: !2, retainedNodes: !51)
!296 = !DILocalVariable(name: "n", arg: 1, scope: !295, file: !11, line: 74, type: !39)
!297 = !DILocation(line: 0, scope: !295)
!298 = !DILocalVariable(name: "A", arg: 2, scope: !295, file: !11, line: 75, type: !66)
!299 = !DILocation(line: 80, column: 3, scope: !295)
!300 = !DILocation(line: 81, column: 3, scope: !295)
!301 = !DILocalVariable(name: "i", scope: !295, file: !11, line: 78, type: !39)
!302 = !DILocation(line: 82, column: 8, scope: !303)
!303 = distinct !DILexicalBlock(scope: !295, file: !11, line: 82, column: 3)
!304 = !DILocation(line: 0, scope: !303)
!305 = !DILocation(line: 82, column: 17, scope: !306)
!306 = distinct !DILexicalBlock(scope: !303, file: !11, line: 82, column: 3)
!307 = !DILocation(line: 82, column: 3, scope: !303)
!308 = !DILocalVariable(name: "j", scope: !295, file: !11, line: 78, type: !39)
!309 = !DILocation(line: 83, column: 10, scope: !310)
!310 = distinct !DILexicalBlock(scope: !306, file: !11, line: 83, column: 5)
!311 = !DILocation(line: 0, scope: !310)
!312 = !DILocation(line: 83, column: 19, scope: !313)
!313 = distinct !DILexicalBlock(scope: !310, file: !11, line: 83, column: 5)
!314 = !DILocation(line: 83, column: 5, scope: !310)
!315 = !DILocation(line: 84, column: 14, scope: !316)
!316 = distinct !DILexicalBlock(scope: !317, file: !11, line: 84, column: 11)
!317 = distinct !DILexicalBlock(scope: !313, file: !11, line: 83, column: 29)
!318 = !DILocation(line: 84, column: 18, scope: !316)
!319 = !DILocation(line: 84, column: 23, scope: !316)
!320 = !DILocation(line: 84, column: 28, scope: !316)
!321 = !DILocation(line: 84, column: 11, scope: !317)
!322 = !DILocation(line: 84, column: 43, scope: !316)
!323 = !DILocation(line: 84, column: 34, scope: !316)
!324 = !DILocation(line: 85, column: 16, scope: !317)
!325 = !DILocation(line: 85, column: 61, scope: !317)
!326 = !DILocation(line: 85, column: 7, scope: !317)
!327 = !DILocation(line: 86, column: 5, scope: !317)
!328 = !DILocation(line: 83, column: 25, scope: !313)
!329 = !DILocation(line: 83, column: 5, scope: !313)
!330 = distinct !{!330, !314, !331, !99}
!331 = !DILocation(line: 86, column: 5, scope: !310)
!332 = !DILocation(line: 82, column: 23, scope: !306)
!333 = !DILocation(line: 82, column: 3, scope: !306)
!334 = distinct !{!334, !307, !335, !99}
!335 = !DILocation(line: 86, column: 5, scope: !303)
!336 = !DILocation(line: 87, column: 3, scope: !295)
!337 = !DILocation(line: 88, column: 3, scope: !295)
!338 = !DILocation(line: 89, column: 1, scope: !295)
!339 = distinct !DISubprogram(name: "pb_fprintf", scope: !29, file: !29, line: 13, type: !340, scopeLine: 14, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition, unit: !2, retainedNodes: !51)
!340 = !DISubroutineType(types: !341)
!341 = !{!39, !342, !401, null}
!342 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !343, size: 64)
!343 = !DIDerivedType(tag: DW_TAG_typedef, name: "FILE", file: !344, line: 7, baseType: !345)
!344 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/types/FILE.h", directory: "", checksumkind: CSK_MD5, checksum: "571f9fb6223c42439075fdde11a0de5d")
!345 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "_IO_FILE", file: !346, line: 49, size: 1728, elements: !347)
!346 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/types/struct_FILE.h", directory: "", checksumkind: CSK_MD5, checksum: "1bad07471b7974df4ecc1d1c2ca207e6")
!347 = !{!348, !349, !352, !353, !354, !355, !356, !357, !358, !359, !360, !361, !362, !365, !367, !368, !369, !372, !374, !376, !378, !381, !383, !386, !389, !390, !392, !396, !397}
!348 = !DIDerivedType(tag: DW_TAG_member, name: "_flags", scope: !345, file: !346, line: 51, baseType: !39, size: 32)
!349 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_read_ptr", scope: !345, file: !346, line: 54, baseType: !350, size: 64, offset: 64)
!350 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !351, size: 64)
!351 = !DIBasicType(name: "char", size: 8, encoding: DW_ATE_signed_char)
!352 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_read_end", scope: !345, file: !346, line: 55, baseType: !350, size: 64, offset: 128)
!353 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_read_base", scope: !345, file: !346, line: 56, baseType: !350, size: 64, offset: 192)
!354 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_write_base", scope: !345, file: !346, line: 57, baseType: !350, size: 64, offset: 256)
!355 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_write_ptr", scope: !345, file: !346, line: 58, baseType: !350, size: 64, offset: 320)
!356 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_write_end", scope: !345, file: !346, line: 59, baseType: !350, size: 64, offset: 384)
!357 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_buf_base", scope: !345, file: !346, line: 60, baseType: !350, size: 64, offset: 448)
!358 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_buf_end", scope: !345, file: !346, line: 61, baseType: !350, size: 64, offset: 512)
!359 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_save_base", scope: !345, file: !346, line: 64, baseType: !350, size: 64, offset: 576)
!360 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_backup_base", scope: !345, file: !346, line: 65, baseType: !350, size: 64, offset: 640)
!361 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_save_end", scope: !345, file: !346, line: 66, baseType: !350, size: 64, offset: 704)
!362 = !DIDerivedType(tag: DW_TAG_member, name: "_markers", scope: !345, file: !346, line: 68, baseType: !363, size: 64, offset: 768)
!363 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !364, size: 64)
!364 = !DICompositeType(tag: DW_TAG_structure_type, name: "_IO_marker", file: !346, line: 36, flags: DIFlagFwdDecl)
!365 = !DIDerivedType(tag: DW_TAG_member, name: "_chain", scope: !345, file: !346, line: 70, baseType: !366, size: 64, offset: 832)
!366 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !345, size: 64)
!367 = !DIDerivedType(tag: DW_TAG_member, name: "_fileno", scope: !345, file: !346, line: 72, baseType: !39, size: 32, offset: 896)
!368 = !DIDerivedType(tag: DW_TAG_member, name: "_flags2", scope: !345, file: !346, line: 73, baseType: !39, size: 32, offset: 928)
!369 = !DIDerivedType(tag: DW_TAG_member, name: "_old_offset", scope: !345, file: !346, line: 74, baseType: !370, size: 64, offset: 960)
!370 = !DIDerivedType(tag: DW_TAG_typedef, name: "__off_t", file: !20, line: 152, baseType: !371)
!371 = !DIBasicType(name: "long", size: 64, encoding: DW_ATE_signed)
!372 = !DIDerivedType(tag: DW_TAG_member, name: "_cur_column", scope: !345, file: !346, line: 77, baseType: !373, size: 16, offset: 1024)
!373 = !DIBasicType(name: "unsigned short", size: 16, encoding: DW_ATE_unsigned)
!374 = !DIDerivedType(tag: DW_TAG_member, name: "_vtable_offset", scope: !345, file: !346, line: 78, baseType: !375, size: 8, offset: 1040)
!375 = !DIBasicType(name: "signed char", size: 8, encoding: DW_ATE_signed_char)
!376 = !DIDerivedType(tag: DW_TAG_member, name: "_shortbuf", scope: !345, file: !346, line: 79, baseType: !377, size: 8, offset: 1048)
!377 = !DICompositeType(tag: DW_TAG_array_type, baseType: !351, size: 8, elements: !21)
!378 = !DIDerivedType(tag: DW_TAG_member, name: "_lock", scope: !345, file: !346, line: 81, baseType: !379, size: 64, offset: 1088)
!379 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !380, size: 64)
!380 = !DIDerivedType(tag: DW_TAG_typedef, name: "_IO_lock_t", file: !346, line: 43, baseType: null)
!381 = !DIDerivedType(tag: DW_TAG_member, name: "_offset", scope: !345, file: !346, line: 89, baseType: !382, size: 64, offset: 1152)
!382 = !DIDerivedType(tag: DW_TAG_typedef, name: "__off64_t", file: !20, line: 153, baseType: !371)
!383 = !DIDerivedType(tag: DW_TAG_member, name: "_codecvt", scope: !345, file: !346, line: 91, baseType: !384, size: 64, offset: 1216)
!384 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !385, size: 64)
!385 = !DICompositeType(tag: DW_TAG_structure_type, name: "_IO_codecvt", file: !346, line: 37, flags: DIFlagFwdDecl)
!386 = !DIDerivedType(tag: DW_TAG_member, name: "_wide_data", scope: !345, file: !346, line: 92, baseType: !387, size: 64, offset: 1280)
!387 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !388, size: 64)
!388 = !DICompositeType(tag: DW_TAG_structure_type, name: "_IO_wide_data", file: !346, line: 38, flags: DIFlagFwdDecl)
!389 = !DIDerivedType(tag: DW_TAG_member, name: "_freeres_list", scope: !345, file: !346, line: 93, baseType: !366, size: 64, offset: 1344)
!390 = !DIDerivedType(tag: DW_TAG_member, name: "_freeres_buf", scope: !345, file: !346, line: 94, baseType: !391, size: 64, offset: 1408)
!391 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: null, size: 64)
!392 = !DIDerivedType(tag: DW_TAG_member, name: "__pad5", scope: !345, file: !346, line: 95, baseType: !393, size: 64, offset: 1472)
!393 = !DIDerivedType(tag: DW_TAG_typedef, name: "size_t", file: !394, line: 46, baseType: !395)
!394 = !DIFile(filename: "/usr/lib/llvm-14/lib/clang/14.0.0/include/stddef.h", directory: "", checksumkind: CSK_MD5, checksum: "2499dd2361b915724b073282bea3a7bc")
!395 = !DIBasicType(name: "unsigned long", size: 64, encoding: DW_ATE_unsigned)
!396 = !DIDerivedType(tag: DW_TAG_member, name: "_mode", scope: !345, file: !346, line: 96, baseType: !39, size: 32, offset: 1536)
!397 = !DIDerivedType(tag: DW_TAG_member, name: "_unused2", scope: !345, file: !346, line: 98, baseType: !398, size: 160, offset: 1568)
!398 = !DICompositeType(tag: DW_TAG_array_type, baseType: !351, size: 160, elements: !399)
!399 = !{!400}
!400 = !DISubrange(count: 20)
!401 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !402, size: 64)
!402 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !351)
!403 = !DILocalVariable(name: "stream", arg: 1, scope: !339, file: !29, line: 13, type: !342)
!404 = !DILocation(line: 0, scope: !339)
!405 = !DILocalVariable(name: "format", arg: 2, scope: !339, file: !29, line: 13, type: !401)
!406 = !DILocalVariable(name: "buffer", scope: !339, file: !29, line: 15, type: !407)
!407 = !DICompositeType(tag: DW_TAG_array_type, baseType: !351, size: 6144, elements: !408)
!408 = !{!409}
!409 = !DISubrange(count: 768)
!410 = !DILocation(line: 15, column: 10, scope: !339)
!411 = !DILocalVariable(name: "args", scope: !339, file: !29, line: 16, type: !412)
!412 = !DIDerivedType(tag: DW_TAG_typedef, name: "va_list", file: !413, line: 52, baseType: !414)
!413 = !DIFile(filename: "/usr/include/stdio.h", directory: "", checksumkind: CSK_MD5, checksum: "f31eefcc3f15835fc5a4023a625cf609")
!414 = !DIDerivedType(tag: DW_TAG_typedef, name: "__gnuc_va_list", file: !415, line: 32, baseType: !416)
!415 = !DIFile(filename: "/usr/lib/llvm-14/lib/clang/14.0.0/include/stdarg.h", directory: "", checksumkind: CSK_MD5, checksum: "4de3cbd931b589d291e5c39387aecf82")
!416 = !DIDerivedType(tag: DW_TAG_typedef, name: "__builtin_va_list", file: !417, baseType: !418)
!417 = !DIFile(filename: "source/workload.c", directory: "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/triangular-20260929/suite/lu")
!418 = !DICompositeType(tag: DW_TAG_array_type, baseType: !419, size: 192, elements: !21)
!419 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "__va_list_tag", size: 192, elements: !420)
!420 = !{!421, !422, !423, !424}
!421 = !DIDerivedType(tag: DW_TAG_member, name: "gp_offset", scope: !419, file: !417, line: 16, baseType: !6, size: 32)
!422 = !DIDerivedType(tag: DW_TAG_member, name: "fp_offset", scope: !419, file: !417, line: 16, baseType: !6, size: 32, offset: 32)
!423 = !DIDerivedType(tag: DW_TAG_member, name: "overflow_arg_area", scope: !419, file: !417, line: 16, baseType: !391, size: 64, offset: 64)
!424 = !DIDerivedType(tag: DW_TAG_member, name: "reg_save_area", scope: !419, file: !417, line: 16, baseType: !391, size: 64, offset: 128)
!425 = !DILocation(line: 16, column: 13, scope: !339)
!426 = !DILocation(line: 17, column: 5, scope: !339)
!427 = !DILocation(line: 18, column: 27, scope: !339)
!428 = !DILocation(line: 18, column: 59, scope: !339)
!429 = !DILocation(line: 18, column: 17, scope: !339)
!430 = !DILocalVariable(name: "count", scope: !339, file: !29, line: 18, type: !39)
!431 = !DILocation(line: 19, column: 5, scope: !339)
!432 = !DILocation(line: 20, column: 15, scope: !433)
!433 = distinct !DILexicalBlock(scope: !339, file: !29, line: 20, column: 9)
!434 = !DILocation(line: 20, column: 19, scope: !433)
!435 = !DILocation(line: 20, column: 22, scope: !433)
!436 = !DILocation(line: 20, column: 38, scope: !433)
!437 = !DILocation(line: 20, column: 9, scope: !339)
!438 = !DILocation(line: 20, column: 57, scope: !433)
!439 = !DILocalVariable(name: "i", scope: !440, file: !29, line: 21, type: !39)
!440 = distinct !DILexicalBlock(scope: !339, file: !29, line: 21, column: 5)
!441 = !DILocation(line: 0, scope: !440)
!442 = !DILocation(line: 21, column: 10, scope: !440)
!443 = !DILocation(line: 21, column: 23, scope: !444)
!444 = distinct !DILexicalBlock(scope: !440, file: !29, line: 21, column: 5)
!445 = !DILocation(line: 21, column: 5, scope: !440)
!446 = !DILocation(line: 22, column: 35, scope: !447)
!447 = distinct !DILexicalBlock(scope: !444, file: !29, line: 21, column: 37)
!448 = !DILocation(line: 22, column: 20, scope: !447)
!449 = !DILocation(line: 22, column: 17, scope: !447)
!450 = !DILocation(line: 23, column: 17, scope: !447)
!451 = !DILocation(line: 24, column: 5, scope: !447)
!452 = !DILocation(line: 21, column: 32, scope: !444)
!453 = !DILocation(line: 21, column: 5, scope: !444)
!454 = distinct !{!454, !445, !455, !99}
!455 = !DILocation(line: 24, column: 5, scope: !440)
!456 = !DILocation(line: 29, column: 11, scope: !339)
!457 = !DILocation(line: 31, column: 5, scope: !339)
