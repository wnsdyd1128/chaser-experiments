; ModuleID = '/workspace/experiments-array-support/chaser/.cache/periodic-polybench/triangular-20260929/suite/covariance/source/workload.c'
source_filename = "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/triangular-20260929/suite/covariance/source/workload.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

%struct._IO_FILE = type { i32, i8*, i8*, i8*, i8*, i8*, i8*, i8*, i8*, i8*, i8*, i8*, %struct._IO_marker*, %struct._IO_FILE*, i32, i32, i64, i16, i8, [1 x i8], i8*, i64, %struct._IO_codecvt*, %struct._IO_wide_data*, %struct._IO_FILE*, i8*, i64, i32, [20 x i8] }
%struct._IO_marker = type opaque
%struct._IO_codecvt = type opaque
%struct._IO_wide_data = type opaque
%struct.__va_list_tag = type { i32, i32, i8*, i8* }

@n = dso_local global i32 260, align 4, !dbg !0
@m = dso_local global i32 240, align 4, !dbg !9
@data = dso_local global [260 x [240 x double]] zeroinitializer, section ".chaser_data.data", align 64, !dbg !33
@cov = dso_local global [240 x [240 x double]] zeroinitializer, section ".chaser_data.cov", align 64, !dbg !39
@mean = dso_local global [240 x double] zeroinitializer, section ".chaser_data.mean", align 64, !dbg !43
@float_n = dso_local global double 0.000000e+00, align 8, !dbg !47
@.str = private unnamed_addr constant [12 x i8] c"ape.analyze\00", section "llvm.metadata"
@.str.1 = private unnamed_addr constant [125 x i8] c"/workspace/experiments-array-support/chaser/.cache/periodic-polybench/triangular-20260929/suite/covariance/source/workload.c\00", section "llvm.metadata"
@pb_hash = internal global i32 0, align 4, !dbg !30
@workload_jobs = dso_local constant [1 x i32 ()*] [i32 ()* @task_job_polybench], align 8, !dbg !13
@workload_expected = dso_local constant [1 x i32] [i32 -1195980795], align 4, !dbg !26
@stderr = external global %struct._IO_FILE*, align 8
@.str.2 = private unnamed_addr constant [23 x i8] c"==BEGIN DUMP_ARRAYS==\0A\00", align 1
@.str.3 = private unnamed_addr constant [15 x i8] c"begin dump: %s\00", align 1
@.str.4 = private unnamed_addr constant [4 x i8] c"cov\00", align 1
@.str.5 = private unnamed_addr constant [2 x i8] c"\0A\00", align 1
@.str.6 = private unnamed_addr constant [8 x i8] c"%0.2lf \00", align 1
@.str.7 = private unnamed_addr constant [17 x i8] c"\0Aend   dump: %s\0A\00", align 1
@.str.8 = private unnamed_addr constant [23 x i8] c"==END   DUMP_ARRAYS==\0A\00", align 1
@pb_emit = internal global i32 1, align 4, !dbg !49
@llvm.global.annotations = appending global [1 x { i8*, i8*, i8*, i32, i8* }] [{ i8*, i8*, i8*, i32, i8* } { i8* bitcast (i32 ()* @task_job_polybench to i8*), i8* getelementptr inbounds ([12 x i8], [12 x i8]* @.str, i32 0, i32 0), i8* getelementptr inbounds ([125 x i8], [125 x i8]* @.str.1, i32 0, i32 0), i32 125, i8* null }], section "llvm.metadata"

; Function Attrs: noinline nounwind uwtable
define dso_local void @workload_prepare() #0 !dbg !59 {
  ret void, !dbg !63
}

; Function Attrs: noinline nounwind uwtable
define dso_local void @workload_reset(i32 noundef %0) #0 !dbg !64 {
  %2 = alloca i32, align 4
  store i32 %0, i32* %2, align 4
  call void @llvm.dbg.declare(metadata i32* %2, metadata !67, metadata !DIExpression()), !dbg !68
  %3 = load i32, i32* %2, align 4, !dbg !69
  call void @llvm.memset.p0i8.i64(i8* align 64 bitcast ([260 x [240 x double]]* @data to i8*), i8 0, i64 499200, i1 false), !dbg !70
  call void @llvm.memset.p0i8.i64(i8* align 64 bitcast ([240 x [240 x double]]* @cov to i8*), i8 0, i64 460800, i1 false), !dbg !71
  call void @llvm.memset.p0i8.i64(i8* align 64 bitcast ([240 x double]* @mean to i8*), i8 0, i64 1920, i1 false), !dbg !72
  %4 = load i32, i32* @m, align 4, !dbg !73
  %5 = load i32, i32* @n, align 4, !dbg !74
  call void @init_array(i32 noundef %4, i32 noundef %5, double* noundef @float_n, [240 x double]* noundef getelementptr inbounds ([260 x [240 x double]], [260 x [240 x double]]* @data, i64 0, i64 0)), !dbg !75
  ret void, !dbg !76
}

; Function Attrs: nofree nosync nounwind readnone speculatable willreturn
declare void @llvm.dbg.declare(metadata, metadata, metadata) #1

; Function Attrs: argmemonly nofree nounwind willreturn writeonly
declare void @llvm.memset.p0i8.i64(i8* nocapture writeonly, i8, i64, i1 immarg) #2

; Function Attrs: noinline nounwind uwtable
define internal void @init_array(i32 noundef %0, i32 noundef %1, double* noundef %2, [240 x double]* noundef %3) #0 !dbg !77 {
  %5 = alloca i32, align 4
  %6 = alloca i32, align 4
  %7 = alloca double*, align 8
  %8 = alloca [240 x double]*, align 8
  %9 = alloca i32, align 4
  %10 = alloca i32, align 4
  store i32 %0, i32* %5, align 4
  call void @llvm.dbg.declare(metadata i32* %5, metadata !82, metadata !DIExpression()), !dbg !83
  store i32 %1, i32* %6, align 4
  call void @llvm.dbg.declare(metadata i32* %6, metadata !84, metadata !DIExpression()), !dbg !85
  store double* %2, double** %7, align 8
  call void @llvm.dbg.declare(metadata double** %7, metadata !86, metadata !DIExpression()), !dbg !87
  store [240 x double]* %3, [240 x double]** %8, align 8
  call void @llvm.dbg.declare(metadata [240 x double]** %8, metadata !88, metadata !DIExpression()), !dbg !89
  call void @llvm.dbg.declare(metadata i32* %9, metadata !90, metadata !DIExpression()), !dbg !91
  call void @llvm.dbg.declare(metadata i32* %10, metadata !92, metadata !DIExpression()), !dbg !93
  %11 = load i32, i32* %6, align 4, !dbg !94
  %12 = sitofp i32 %11 to double, !dbg !95
  %13 = load double*, double** %7, align 8, !dbg !96
  store double %12, double* %13, align 8, !dbg !97
  store i32 0, i32* %9, align 4, !dbg !98
  br label %14, !dbg !100

14:                                               ; preds = %39, %4
  %15 = load i32, i32* %9, align 4, !dbg !101
  %16 = icmp slt i32 %15, 260, !dbg !103
  br i1 %16, label %17, label %42, !dbg !104

17:                                               ; preds = %14
  store i32 0, i32* %10, align 4, !dbg !105
  br label %18, !dbg !107

18:                                               ; preds = %35, %17
  %19 = load i32, i32* %10, align 4, !dbg !108
  %20 = icmp slt i32 %19, 240, !dbg !110
  br i1 %20, label %21, label %38, !dbg !111

21:                                               ; preds = %18
  %22 = load i32, i32* %9, align 4, !dbg !112
  %23 = sitofp i32 %22 to double, !dbg !113
  %24 = load i32, i32* %10, align 4, !dbg !114
  %25 = sitofp i32 %24 to double, !dbg !114
  %26 = fmul double %23, %25, !dbg !115
  %27 = fdiv double %26, 2.400000e+02, !dbg !116
  %28 = load [240 x double]*, [240 x double]** %8, align 8, !dbg !117
  %29 = load i32, i32* %9, align 4, !dbg !118
  %30 = sext i32 %29 to i64, !dbg !117
  %31 = getelementptr inbounds [240 x double], [240 x double]* %28, i64 %30, !dbg !117
  %32 = load i32, i32* %10, align 4, !dbg !119
  %33 = sext i32 %32 to i64, !dbg !117
  %34 = getelementptr inbounds [240 x double], [240 x double]* %31, i64 0, i64 %33, !dbg !117
  store double %27, double* %34, align 8, !dbg !120
  br label %35, !dbg !117

35:                                               ; preds = %21
  %36 = load i32, i32* %10, align 4, !dbg !121
  %37 = add nsw i32 %36, 1, !dbg !121
  store i32 %37, i32* %10, align 4, !dbg !121
  br label %18, !dbg !122, !llvm.loop !123

38:                                               ; preds = %18
  br label %39, !dbg !124

39:                                               ; preds = %38
  %40 = load i32, i32* %9, align 4, !dbg !126
  %41 = add nsw i32 %40, 1, !dbg !126
  store i32 %41, i32* %9, align 4, !dbg !126
  br label %14, !dbg !127, !llvm.loop !128

42:                                               ; preds = %14
  ret void, !dbg !130
}

; Function Attrs: noinline nounwind uwtable
define dso_local i32 @task_job_polybench() #0 !dbg !131 {
  %1 = alloca i32, align 4
  %2 = alloca i32, align 4
  %3 = alloca double, align 8
  %4 = alloca [240 x double]*, align 8
  %5 = alloca [240 x double]*, align 8
  %6 = alloca double*, align 8
  %7 = alloca i32, align 4
  %8 = alloca i32, align 4
  %9 = alloca i32, align 4
  %10 = load i32, i32* @m, align 4, !dbg !132
  %11 = load i32, i32* @n, align 4, !dbg !133
  %12 = load double, double* @float_n, align 8, !dbg !134
  store i32 %10, i32* %1, align 4
  call void @llvm.dbg.declare(metadata i32* %1, metadata !135, metadata !DIExpression()), !dbg !139
  store i32 %11, i32* %2, align 4
  call void @llvm.dbg.declare(metadata i32* %2, metadata !141, metadata !DIExpression()), !dbg !142
  store double %12, double* %3, align 8
  call void @llvm.dbg.declare(metadata double* %3, metadata !143, metadata !DIExpression()), !dbg !144
  store [240 x double]* getelementptr inbounds ([260 x [240 x double]], [260 x [240 x double]]* @data, i64 0, i64 0), [240 x double]** %4, align 8
  call void @llvm.dbg.declare(metadata [240 x double]** %4, metadata !145, metadata !DIExpression()), !dbg !146
  store [240 x double]* getelementptr inbounds ([240 x [240 x double]], [240 x [240 x double]]* @cov, i64 0, i64 0), [240 x double]** %5, align 8
  call void @llvm.dbg.declare(metadata [240 x double]** %5, metadata !147, metadata !DIExpression()), !dbg !148
  store double* getelementptr inbounds ([240 x double], [240 x double]* @mean, i64 0, i64 0), double** %6, align 8
  call void @llvm.dbg.declare(metadata double** %6, metadata !149, metadata !DIExpression()), !dbg !150
  call void @llvm.dbg.declare(metadata i32* %7, metadata !151, metadata !DIExpression()), !dbg !152
  call void @llvm.dbg.declare(metadata i32* %8, metadata !153, metadata !DIExpression()), !dbg !154
  call void @llvm.dbg.declare(metadata i32* %9, metadata !155, metadata !DIExpression()), !dbg !156
  store i32 0, i32* %8, align 4, !dbg !157
  br label %13, !dbg !159

13:                                               ; preds = %41, %0
  %14 = load i32, i32* %8, align 4, !dbg !160
  %15 = icmp slt i32 %14, 240, !dbg !162
  br i1 %15, label %16, label %51, !dbg !163

16:                                               ; preds = %13
  %17 = load double*, double** %6, align 8, !dbg !164
  %18 = load i32, i32* %8, align 4, !dbg !166
  %19 = sext i32 %18 to i64, !dbg !164
  %20 = getelementptr inbounds double, double* %17, i64 %19, !dbg !164
  store double 0.000000e+00, double* %20, align 8, !dbg !167
  store i32 0, i32* %7, align 4, !dbg !168
  br label %21, !dbg !170

21:                                               ; preds = %24, %16
  %22 = load i32, i32* %7, align 4, !dbg !171
  %23 = icmp slt i32 %22, 260, !dbg !173
  br i1 %23, label %24, label %41, !dbg !174

24:                                               ; preds = %21
  %25 = load [240 x double]*, [240 x double]** %4, align 8, !dbg !175
  %26 = load i32, i32* %7, align 4, !dbg !176
  %27 = sext i32 %26 to i64, !dbg !175
  %28 = getelementptr inbounds [240 x double], [240 x double]* %25, i64 %27, !dbg !175
  %29 = load i32, i32* %8, align 4, !dbg !177
  %30 = sext i32 %29 to i64, !dbg !175
  %31 = getelementptr inbounds [240 x double], [240 x double]* %28, i64 0, i64 %30, !dbg !175
  %32 = load double, double* %31, align 8, !dbg !175
  %33 = load double*, double** %6, align 8, !dbg !178
  %34 = load i32, i32* %8, align 4, !dbg !179
  %35 = sext i32 %34 to i64, !dbg !178
  %36 = getelementptr inbounds double, double* %33, i64 %35, !dbg !178
  %37 = load double, double* %36, align 8, !dbg !180
  %38 = fadd double %37, %32, !dbg !180
  store double %38, double* %36, align 8, !dbg !180
  %39 = load i32, i32* %7, align 4, !dbg !181
  %40 = add nsw i32 %39, 1, !dbg !181
  store i32 %40, i32* %7, align 4, !dbg !181
  br label %21, !dbg !182, !llvm.loop !183

41:                                               ; preds = %21
  %42 = load double, double* %3, align 8, !dbg !185
  %43 = load double*, double** %6, align 8, !dbg !186
  %44 = load i32, i32* %8, align 4, !dbg !187
  %45 = sext i32 %44 to i64, !dbg !186
  %46 = getelementptr inbounds double, double* %43, i64 %45, !dbg !186
  %47 = load double, double* %46, align 8, !dbg !188
  %48 = fdiv double %47, %42, !dbg !188
  store double %48, double* %46, align 8, !dbg !188
  %49 = load i32, i32* %8, align 4, !dbg !189
  %50 = add nsw i32 %49, 1, !dbg !189
  store i32 %50, i32* %8, align 4, !dbg !189
  br label %13, !dbg !190, !llvm.loop !191

51:                                               ; preds = %13
  store i32 0, i32* %7, align 4, !dbg !193
  br label %52, !dbg !195

52:                                               ; preds = %76, %51
  %53 = load i32, i32* %7, align 4, !dbg !196
  %54 = icmp slt i32 %53, 260, !dbg !198
  br i1 %54, label %55, label %79, !dbg !199

55:                                               ; preds = %52
  store i32 0, i32* %8, align 4, !dbg !200
  br label %56, !dbg !202

56:                                               ; preds = %59, %55
  %57 = load i32, i32* %8, align 4, !dbg !203
  %58 = icmp slt i32 %57, 240, !dbg !205
  br i1 %58, label %59, label %76, !dbg !206

59:                                               ; preds = %56
  %60 = load double*, double** %6, align 8, !dbg !207
  %61 = load i32, i32* %8, align 4, !dbg !208
  %62 = sext i32 %61 to i64, !dbg !207
  %63 = getelementptr inbounds double, double* %60, i64 %62, !dbg !207
  %64 = load double, double* %63, align 8, !dbg !207
  %65 = load [240 x double]*, [240 x double]** %4, align 8, !dbg !209
  %66 = load i32, i32* %7, align 4, !dbg !210
  %67 = sext i32 %66 to i64, !dbg !209
  %68 = getelementptr inbounds [240 x double], [240 x double]* %65, i64 %67, !dbg !209
  %69 = load i32, i32* %8, align 4, !dbg !211
  %70 = sext i32 %69 to i64, !dbg !209
  %71 = getelementptr inbounds [240 x double], [240 x double]* %68, i64 0, i64 %70, !dbg !209
  %72 = load double, double* %71, align 8, !dbg !212
  %73 = fsub double %72, %64, !dbg !212
  store double %73, double* %71, align 8, !dbg !212
  %74 = load i32, i32* %8, align 4, !dbg !213
  %75 = add nsw i32 %74, 1, !dbg !213
  store i32 %75, i32* %8, align 4, !dbg !213
  br label %56, !dbg !214, !llvm.loop !215

76:                                               ; preds = %56
  %77 = load i32, i32* %7, align 4, !dbg !217
  %78 = add nsw i32 %77, 1, !dbg !217
  store i32 %78, i32* %7, align 4, !dbg !217
  br label %52, !dbg !218, !llvm.loop !219

79:                                               ; preds = %52
  store i32 0, i32* %7, align 4, !dbg !221
  br label %80, !dbg !223

80:                                               ; preds = %157, %79
  %81 = load i32, i32* %7, align 4, !dbg !224
  %82 = icmp slt i32 %81, 240, !dbg !226
  br i1 %82, label %83, label %160, !dbg !227

83:                                               ; preds = %80
  %84 = load i32, i32* %7, align 4, !dbg !228
  store i32 %84, i32* %8, align 4, !dbg !230
  br label %85, !dbg !231

85:                                               ; preds = %128, %83
  %86 = load i32, i32* %8, align 4, !dbg !232
  %87 = icmp slt i32 %86, 240, !dbg !234
  br i1 %87, label %88, label %157, !dbg !235

88:                                               ; preds = %85
  %89 = load [240 x double]*, [240 x double]** %5, align 8, !dbg !236
  %90 = load i32, i32* %7, align 4, !dbg !238
  %91 = sext i32 %90 to i64, !dbg !236
  %92 = getelementptr inbounds [240 x double], [240 x double]* %89, i64 %91, !dbg !236
  %93 = load i32, i32* %8, align 4, !dbg !239
  %94 = sext i32 %93 to i64, !dbg !236
  %95 = getelementptr inbounds [240 x double], [240 x double]* %92, i64 0, i64 %94, !dbg !236
  store double 0.000000e+00, double* %95, align 8, !dbg !240
  store i32 0, i32* %9, align 4, !dbg !241
  br label %96, !dbg !243

96:                                               ; preds = %99, %88
  %97 = load i32, i32* %9, align 4, !dbg !244
  %98 = icmp slt i32 %97, 260, !dbg !246
  br i1 %98, label %99, label %128, !dbg !247

99:                                               ; preds = %96
  %100 = load [240 x double]*, [240 x double]** %4, align 8, !dbg !248
  %101 = load i32, i32* %9, align 4, !dbg !249
  %102 = sext i32 %101 to i64, !dbg !248
  %103 = getelementptr inbounds [240 x double], [240 x double]* %100, i64 %102, !dbg !248
  %104 = load i32, i32* %7, align 4, !dbg !250
  %105 = sext i32 %104 to i64, !dbg !248
  %106 = getelementptr inbounds [240 x double], [240 x double]* %103, i64 0, i64 %105, !dbg !248
  %107 = load double, double* %106, align 8, !dbg !248
  %108 = load [240 x double]*, [240 x double]** %4, align 8, !dbg !251
  %109 = load i32, i32* %9, align 4, !dbg !252
  %110 = sext i32 %109 to i64, !dbg !251
  %111 = getelementptr inbounds [240 x double], [240 x double]* %108, i64 %110, !dbg !251
  %112 = load i32, i32* %8, align 4, !dbg !253
  %113 = sext i32 %112 to i64, !dbg !251
  %114 = getelementptr inbounds [240 x double], [240 x double]* %111, i64 0, i64 %113, !dbg !251
  %115 = load double, double* %114, align 8, !dbg !251
  %116 = fmul double %107, %115, !dbg !254
  %117 = load [240 x double]*, [240 x double]** %5, align 8, !dbg !255
  %118 = load i32, i32* %7, align 4, !dbg !256
  %119 = sext i32 %118 to i64, !dbg !255
  %120 = getelementptr inbounds [240 x double], [240 x double]* %117, i64 %119, !dbg !255
  %121 = load i32, i32* %8, align 4, !dbg !257
  %122 = sext i32 %121 to i64, !dbg !255
  %123 = getelementptr inbounds [240 x double], [240 x double]* %120, i64 0, i64 %122, !dbg !255
  %124 = load double, double* %123, align 8, !dbg !258
  %125 = fadd double %124, %116, !dbg !258
  store double %125, double* %123, align 8, !dbg !258
  %126 = load i32, i32* %9, align 4, !dbg !259
  %127 = add nsw i32 %126, 1, !dbg !259
  store i32 %127, i32* %9, align 4, !dbg !259
  br label %96, !dbg !260, !llvm.loop !261

128:                                              ; preds = %96
  %129 = load double, double* %3, align 8, !dbg !263
  %130 = fsub double %129, 1.000000e+00, !dbg !264
  %131 = load [240 x double]*, [240 x double]** %5, align 8, !dbg !265
  %132 = load i32, i32* %7, align 4, !dbg !266
  %133 = sext i32 %132 to i64, !dbg !265
  %134 = getelementptr inbounds [240 x double], [240 x double]* %131, i64 %133, !dbg !265
  %135 = load i32, i32* %8, align 4, !dbg !267
  %136 = sext i32 %135 to i64, !dbg !265
  %137 = getelementptr inbounds [240 x double], [240 x double]* %134, i64 0, i64 %136, !dbg !265
  %138 = load double, double* %137, align 8, !dbg !268
  %139 = fdiv double %138, %130, !dbg !268
  store double %139, double* %137, align 8, !dbg !268
  %140 = load [240 x double]*, [240 x double]** %5, align 8, !dbg !269
  %141 = load i32, i32* %7, align 4, !dbg !270
  %142 = sext i32 %141 to i64, !dbg !269
  %143 = getelementptr inbounds [240 x double], [240 x double]* %140, i64 %142, !dbg !269
  %144 = load i32, i32* %8, align 4, !dbg !271
  %145 = sext i32 %144 to i64, !dbg !269
  %146 = getelementptr inbounds [240 x double], [240 x double]* %143, i64 0, i64 %145, !dbg !269
  %147 = load double, double* %146, align 8, !dbg !269
  %148 = load [240 x double]*, [240 x double]** %5, align 8, !dbg !272
  %149 = load i32, i32* %8, align 4, !dbg !273
  %150 = sext i32 %149 to i64, !dbg !272
  %151 = getelementptr inbounds [240 x double], [240 x double]* %148, i64 %150, !dbg !272
  %152 = load i32, i32* %7, align 4, !dbg !274
  %153 = sext i32 %152 to i64, !dbg !272
  %154 = getelementptr inbounds [240 x double], [240 x double]* %151, i64 0, i64 %153, !dbg !272
  store double %147, double* %154, align 8, !dbg !275
  %155 = load i32, i32* %8, align 4, !dbg !276
  %156 = add nsw i32 %155, 1, !dbg !276
  store i32 %156, i32* %8, align 4, !dbg !276
  br label %85, !dbg !277, !llvm.loop !278

157:                                              ; preds = %85
  %158 = load i32, i32* %7, align 4, !dbg !280
  %159 = add nsw i32 %158, 1, !dbg !280
  store i32 %159, i32* %7, align 4, !dbg !280
  br label %80, !dbg !281, !llvm.loop !282

160:                                              ; preds = %80
  ret i32 0, !dbg !284
}

; Function Attrs: noinline nounwind uwtable
define dso_local i32 @workload_checksum(i32 noundef %0) #0 !dbg !285 {
  %2 = alloca i32, align 4
  store i32 %0, i32* %2, align 4
  call void @llvm.dbg.declare(metadata i32* %2, metadata !288, metadata !DIExpression()), !dbg !289
  %3 = load i32, i32* %2, align 4, !dbg !290
  store i32 -2128831035, i32* @pb_hash, align 4, !dbg !291
  %4 = load i32, i32* @m, align 4, !dbg !292
  call void @print_array(i32 noundef %4, [240 x double]* noundef getelementptr inbounds ([240 x [240 x double]], [240 x [240 x double]]* @cov, i64 0, i64 0)), !dbg !293
  %5 = load i32, i32* @pb_hash, align 4, !dbg !294
  ret i32 %5, !dbg !295
}

; Function Attrs: noinline nounwind uwtable
define internal void @print_array(i32 noundef %0, [240 x double]* noundef %1) #0 !dbg !296 {
  %3 = alloca i32, align 4
  %4 = alloca [240 x double]*, align 8
  %5 = alloca i32, align 4
  %6 = alloca i32, align 4
  store i32 %0, i32* %3, align 4
  call void @llvm.dbg.declare(metadata i32* %3, metadata !299, metadata !DIExpression()), !dbg !300
  store [240 x double]* %1, [240 x double]** %4, align 8
  call void @llvm.dbg.declare(metadata [240 x double]** %4, metadata !301, metadata !DIExpression()), !dbg !302
  call void @llvm.dbg.declare(metadata i32* %5, metadata !303, metadata !DIExpression()), !dbg !304
  call void @llvm.dbg.declare(metadata i32* %6, metadata !305, metadata !DIExpression()), !dbg !306
  %7 = load %struct._IO_FILE*, %struct._IO_FILE** @stderr, align 8, !dbg !307
  %8 = call i32 (%struct._IO_FILE*, i8*, ...) @pb_fprintf(%struct._IO_FILE* noundef %7, i8* noundef getelementptr inbounds ([23 x i8], [23 x i8]* @.str.2, i64 0, i64 0)), !dbg !307
  %9 = load %struct._IO_FILE*, %struct._IO_FILE** @stderr, align 8, !dbg !308
  %10 = call i32 (%struct._IO_FILE*, i8*, ...) @pb_fprintf(%struct._IO_FILE* noundef %9, i8* noundef getelementptr inbounds ([15 x i8], [15 x i8]* @.str.3, i64 0, i64 0), i8* noundef getelementptr inbounds ([4 x i8], [4 x i8]* @.str.4, i64 0, i64 0)), !dbg !308
  store i32 0, i32* %5, align 4, !dbg !309
  br label %11, !dbg !311

11:                                               ; preds = %46, %2
  %12 = load i32, i32* %5, align 4, !dbg !312
  %13 = load i32, i32* %3, align 4, !dbg !314
  %14 = icmp slt i32 %12, %13, !dbg !315
  br i1 %14, label %15, label %49, !dbg !316

15:                                               ; preds = %11
  store i32 0, i32* %6, align 4, !dbg !317
  br label %16, !dbg !319

16:                                               ; preds = %42, %15
  %17 = load i32, i32* %6, align 4, !dbg !320
  %18 = load i32, i32* %3, align 4, !dbg !322
  %19 = icmp slt i32 %17, %18, !dbg !323
  br i1 %19, label %20, label %45, !dbg !324

20:                                               ; preds = %16
  %21 = load i32, i32* %5, align 4, !dbg !325
  %22 = load i32, i32* %3, align 4, !dbg !328
  %23 = mul nsw i32 %21, %22, !dbg !329
  %24 = load i32, i32* %6, align 4, !dbg !330
  %25 = add nsw i32 %23, %24, !dbg !331
  %26 = srem i32 %25, 20, !dbg !332
  %27 = icmp eq i32 %26, 0, !dbg !333
  br i1 %27, label %28, label %31, !dbg !334

28:                                               ; preds = %20
  %29 = load %struct._IO_FILE*, %struct._IO_FILE** @stderr, align 8, !dbg !335
  %30 = call i32 (%struct._IO_FILE*, i8*, ...) @pb_fprintf(%struct._IO_FILE* noundef %29, i8* noundef getelementptr inbounds ([2 x i8], [2 x i8]* @.str.5, i64 0, i64 0)), !dbg !336
  br label %31, !dbg !336

31:                                               ; preds = %28, %20
  %32 = load %struct._IO_FILE*, %struct._IO_FILE** @stderr, align 8, !dbg !337
  %33 = load [240 x double]*, [240 x double]** %4, align 8, !dbg !338
  %34 = load i32, i32* %5, align 4, !dbg !339
  %35 = sext i32 %34 to i64, !dbg !338
  %36 = getelementptr inbounds [240 x double], [240 x double]* %33, i64 %35, !dbg !338
  %37 = load i32, i32* %6, align 4, !dbg !340
  %38 = sext i32 %37 to i64, !dbg !338
  %39 = getelementptr inbounds [240 x double], [240 x double]* %36, i64 0, i64 %38, !dbg !338
  %40 = load double, double* %39, align 8, !dbg !338
  %41 = call i32 (%struct._IO_FILE*, i8*, ...) @pb_fprintf(%struct._IO_FILE* noundef %32, i8* noundef getelementptr inbounds ([8 x i8], [8 x i8]* @.str.6, i64 0, i64 0), double noundef %40), !dbg !341
  br label %42, !dbg !342

42:                                               ; preds = %31
  %43 = load i32, i32* %6, align 4, !dbg !343
  %44 = add nsw i32 %43, 1, !dbg !343
  store i32 %44, i32* %6, align 4, !dbg !343
  br label %16, !dbg !344, !llvm.loop !345

45:                                               ; preds = %16
  br label %46, !dbg !346

46:                                               ; preds = %45
  %47 = load i32, i32* %5, align 4, !dbg !347
  %48 = add nsw i32 %47, 1, !dbg !347
  store i32 %48, i32* %5, align 4, !dbg !347
  br label %11, !dbg !348, !llvm.loop !349

49:                                               ; preds = %11
  %50 = load %struct._IO_FILE*, %struct._IO_FILE** @stderr, align 8, !dbg !351
  %51 = call i32 (%struct._IO_FILE*, i8*, ...) @pb_fprintf(%struct._IO_FILE* noundef %50, i8* noundef getelementptr inbounds ([17 x i8], [17 x i8]* @.str.7, i64 0, i64 0), i8* noundef getelementptr inbounds ([4 x i8], [4 x i8]* @.str.4, i64 0, i64 0)), !dbg !351
  %52 = load %struct._IO_FILE*, %struct._IO_FILE** @stderr, align 8, !dbg !352
  %53 = call i32 (%struct._IO_FILE*, i8*, ...) @pb_fprintf(%struct._IO_FILE* noundef %52, i8* noundef getelementptr inbounds ([23 x i8], [23 x i8]* @.str.8, i64 0, i64 0)), !dbg !352
  ret void, !dbg !353
}

; Function Attrs: noinline nounwind uwtable
define internal i32 @pb_fprintf(%struct._IO_FILE* noundef %0, i8* noundef %1, ...) #0 !dbg !354 {
  %3 = alloca %struct._IO_FILE*, align 8
  %4 = alloca i8*, align 8
  %5 = alloca [768 x i8], align 16
  %6 = alloca [1 x %struct.__va_list_tag], align 16
  %7 = alloca i32, align 4
  %8 = alloca i32, align 4
  store %struct._IO_FILE* %0, %struct._IO_FILE** %3, align 8
  call void @llvm.dbg.declare(metadata %struct._IO_FILE** %3, metadata !418, metadata !DIExpression()), !dbg !419
  store i8* %1, i8** %4, align 8
  call void @llvm.dbg.declare(metadata i8** %4, metadata !420, metadata !DIExpression()), !dbg !421
  call void @llvm.dbg.declare(metadata [768 x i8]* %5, metadata !422, metadata !DIExpression()), !dbg !426
  call void @llvm.dbg.declare(metadata [1 x %struct.__va_list_tag]* %6, metadata !427, metadata !DIExpression()), !dbg !441
  %9 = getelementptr inbounds [1 x %struct.__va_list_tag], [1 x %struct.__va_list_tag]* %6, i64 0, i64 0, !dbg !442
  %10 = bitcast %struct.__va_list_tag* %9 to i8*, !dbg !442
  call void @llvm.va_start(i8* %10), !dbg !442
  call void @llvm.dbg.declare(metadata i32* %7, metadata !443, metadata !DIExpression()), !dbg !444
  %11 = getelementptr inbounds [768 x i8], [768 x i8]* %5, i64 0, i64 0, !dbg !445
  %12 = load i8*, i8** %4, align 8, !dbg !446
  %13 = getelementptr inbounds [1 x %struct.__va_list_tag], [1 x %struct.__va_list_tag]* %6, i64 0, i64 0, !dbg !447
  %14 = call i32 @vsnprintf(i8* noundef %11, i64 noundef 768, i8* noundef %12, %struct.__va_list_tag* noundef %13) #6, !dbg !448
  store i32 %14, i32* %7, align 4, !dbg !444
  %15 = getelementptr inbounds [1 x %struct.__va_list_tag], [1 x %struct.__va_list_tag]* %6, i64 0, i64 0, !dbg !449
  %16 = bitcast %struct.__va_list_tag* %15 to i8*, !dbg !449
  call void @llvm.va_end(i8* %16), !dbg !449
  %17 = load i32, i32* %7, align 4, !dbg !450
  %18 = icmp slt i32 %17, 0, !dbg !452
  br i1 %18, label %23, label %19, !dbg !453

19:                                               ; preds = %2
  %20 = load i32, i32* %7, align 4, !dbg !454
  %21 = zext i32 %20 to i64, !dbg !455
  %22 = icmp uge i64 %21, 768, !dbg !456
  br i1 %22, label %23, label %24, !dbg !457

23:                                               ; preds = %19, %2
  call void @abort() #7, !dbg !458
  unreachable, !dbg !458

24:                                               ; preds = %19
  call void @llvm.dbg.declare(metadata i32* %8, metadata !459, metadata !DIExpression()), !dbg !461
  store i32 0, i32* %8, align 4, !dbg !461
  br label %25, !dbg !462

25:                                               ; preds = %39, %24
  %26 = load i32, i32* %8, align 4, !dbg !463
  %27 = load i32, i32* %7, align 4, !dbg !465
  %28 = icmp slt i32 %26, %27, !dbg !466
  br i1 %28, label %29, label %42, !dbg !467

29:                                               ; preds = %25
  %30 = load i32, i32* %8, align 4, !dbg !468
  %31 = sext i32 %30 to i64, !dbg !470
  %32 = getelementptr inbounds [768 x i8], [768 x i8]* %5, i64 0, i64 %31, !dbg !470
  %33 = load i8, i8* %32, align 1, !dbg !470
  %34 = zext i8 %33 to i32, !dbg !471
  %35 = load i32, i32* @pb_hash, align 4, !dbg !472
  %36 = xor i32 %35, %34, !dbg !472
  store i32 %36, i32* @pb_hash, align 4, !dbg !472
  %37 = load i32, i32* @pb_hash, align 4, !dbg !473
  %38 = mul i32 %37, 16777619, !dbg !473
  store i32 %38, i32* @pb_hash, align 4, !dbg !473
  br label %39, !dbg !474

39:                                               ; preds = %29
  %40 = load i32, i32* %8, align 4, !dbg !475
  %41 = add nsw i32 %40, 1, !dbg !475
  store i32 %41, i32* %8, align 4, !dbg !475
  br label %25, !dbg !476, !llvm.loop !477

42:                                               ; preds = %25
  %43 = load %struct._IO_FILE*, %struct._IO_FILE** %3, align 8, !dbg !479
  %44 = load i32, i32* @pb_emit, align 4, !dbg !480
  %45 = load i32, i32* %7, align 4, !dbg !481
  ret i32 %45, !dbg !482
}

; Function Attrs: nofree nosync nounwind willreturn
declare void @llvm.va_start(i8*) #3

; Function Attrs: nounwind
declare i32 @vsnprintf(i8* noundef, i64 noundef, i8* noundef, %struct.__va_list_tag* noundef) #4

; Function Attrs: nofree nosync nounwind willreturn
declare void @llvm.va_end(i8*) #3

; Function Attrs: noreturn nounwind
declare void @abort() #5

attributes #0 = { noinline nounwind uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { nofree nosync nounwind readnone speculatable willreturn }
attributes #2 = { argmemonly nofree nounwind willreturn writeonly }
attributes #3 = { nofree nosync nounwind willreturn }
attributes #4 = { nounwind "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #5 = { noreturn nounwind "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #6 = { nounwind }
attributes #7 = { noreturn nounwind }

!llvm.dbg.cu = !{!2}
!llvm.module.flags = !{!51, !52, !53, !54, !55, !56, !57}
!llvm.ident = !{!58}

!0 = !DIGlobalVariableExpression(var: !1, expr: !DIExpression())
!1 = distinct !DIGlobalVariable(name: "n", scope: !2, file: !11, line: 112, type: !12, isLocal: false, isDefinition: true)
!2 = distinct !DICompileUnit(language: DW_LANG_C99, file: !3, producer: "Ubuntu clang version 14.0.0-1ubuntu1.1", isOptimized: false, runtimeVersion: 0, emissionKind: FullDebug, retainedTypes: !4, globals: !8, splitDebugInlining: false, nameTableKind: None)
!3 = !DIFile(filename: "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/triangular-20260929/suite/covariance/source/workload.c", directory: "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/triangular-20260929/suite/covariance/analysis-g", checksumkind: CSK_MD5, checksum: "5266233317551a092f7140d5a93b2e7f")
!4 = !{!5, !6, !7}
!5 = !DIBasicType(name: "double", size: 64, encoding: DW_ATE_float)
!6 = !DIBasicType(name: "unsigned int", size: 32, encoding: DW_ATE_unsigned)
!7 = !DIBasicType(name: "unsigned char", size: 8, encoding: DW_ATE_unsigned_char)
!8 = !{!0, !9, !13, !26, !30, !33, !39, !43, !47, !49}
!9 = !DIGlobalVariableExpression(var: !10, expr: !DIExpression())
!10 = distinct !DIGlobalVariable(name: "m", scope: !2, file: !11, line: 113, type: !12, isLocal: false, isDefinition: true)
!11 = !DIFile(filename: "source/workload.c", directory: "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/triangular-20260929/suite/covariance", checksumkind: CSK_MD5, checksum: "5266233317551a092f7140d5a93b2e7f")
!12 = !DIBasicType(name: "int", size: 32, encoding: DW_ATE_signed)
!13 = !DIGlobalVariableExpression(var: !14, expr: !DIExpression())
!14 = distinct !DIGlobalVariable(name: "workload_jobs", scope: !2, file: !11, line: 138, type: !15, isLocal: false, isDefinition: true)
!15 = !DICompositeType(tag: DW_TAG_array_type, baseType: !16, size: 64, elements: !24)
!16 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !17)
!17 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !18, size: 64)
!18 = !DISubroutineType(types: !19)
!19 = !{!20}
!20 = !DIDerivedType(tag: DW_TAG_typedef, name: "uint32_t", file: !21, line: 26, baseType: !22)
!21 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/stdint-uintn.h", directory: "", checksumkind: CSK_MD5, checksum: "2bf2ae53c58c01b1a1b9383b5195125c")
!22 = !DIDerivedType(tag: DW_TAG_typedef, name: "__uint32_t", file: !23, line: 42, baseType: !6)
!23 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/types.h", directory: "", checksumkind: CSK_MD5, checksum: "d108b5f93a74c50510d7d9bc0ab36df9")
!24 = !{!25}
!25 = !DISubrange(count: 1)
!26 = !DIGlobalVariableExpression(var: !27, expr: !DIExpression())
!27 = distinct !DIGlobalVariable(name: "workload_expected", scope: !2, file: !11, line: 142, type: !28, isLocal: false, isDefinition: true)
!28 = !DICompositeType(tag: DW_TAG_array_type, baseType: !29, size: 32, elements: !24)
!29 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !20)
!30 = !DIGlobalVariableExpression(var: !31, expr: !DIExpression())
!31 = distinct !DIGlobalVariable(name: "pb_hash", scope: !2, file: !32, line: 9, type: !20, isLocal: true, isDefinition: true)
!32 = !DIFile(filename: "source/adapter.h", directory: "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/triangular-20260929/suite/covariance", checksumkind: CSK_MD5, checksum: "26a6068928b2092758f244a9d00163d7")
!33 = !DIGlobalVariableExpression(var: !34, expr: !DIExpression())
!34 = distinct !DIGlobalVariable(name: "data", scope: !2, file: !11, line: 34, type: !35, isLocal: false, isDefinition: true, align: 512)
!35 = !DICompositeType(tag: DW_TAG_array_type, baseType: !5, size: 3993600, elements: !36)
!36 = !{!37, !38}
!37 = !DISubrange(count: 260)
!38 = !DISubrange(count: 240)
!39 = !DIGlobalVariableExpression(var: !40, expr: !DIExpression())
!40 = distinct !DIGlobalVariable(name: "cov", scope: !2, file: !11, line: 35, type: !41, isLocal: false, isDefinition: true, align: 512)
!41 = !DICompositeType(tag: DW_TAG_array_type, baseType: !5, size: 3686400, elements: !42)
!42 = !{!38, !38}
!43 = !DIGlobalVariableExpression(var: !44, expr: !DIExpression())
!44 = distinct !DIGlobalVariable(name: "mean", scope: !2, file: !11, line: 36, type: !45, isLocal: false, isDefinition: true, align: 512)
!45 = !DICompositeType(tag: DW_TAG_array_type, baseType: !5, size: 15360, elements: !46)
!46 = !{!38}
!47 = !DIGlobalVariableExpression(var: !48, expr: !DIExpression())
!48 = distinct !DIGlobalVariable(name: "float_n", scope: !2, file: !11, line: 116, type: !5, isLocal: false, isDefinition: true)
!49 = !DIGlobalVariableExpression(var: !50, expr: !DIExpression())
!50 = distinct !DIGlobalVariable(name: "pb_emit", scope: !2, file: !32, line: 10, type: !12, isLocal: true, isDefinition: true)
!51 = !{i32 7, !"Dwarf Version", i32 5}
!52 = !{i32 2, !"Debug Info Version", i32 3}
!53 = !{i32 1, !"wchar_size", i32 4}
!54 = !{i32 7, !"PIC Level", i32 2}
!55 = !{i32 7, !"PIE Level", i32 2}
!56 = !{i32 7, !"uwtable", i32 1}
!57 = !{i32 7, !"frame-pointer", i32 2}
!58 = !{!"Ubuntu clang version 14.0.0-1ubuntu1.1"}
!59 = distinct !DISubprogram(name: "workload_prepare", scope: !11, file: !11, line: 117, type: !60, scopeLine: 117, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !2, retainedNodes: !62)
!60 = !DISubroutineType(types: !61)
!61 = !{null}
!62 = !{}
!63 = !DILocation(line: 117, column: 30, scope: !59)
!64 = distinct !DISubprogram(name: "workload_reset", scope: !11, file: !11, line: 118, type: !65, scopeLine: 118, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !2, retainedNodes: !62)
!65 = !DISubroutineType(types: !66)
!66 = !{null, !6}
!67 = !DILocalVariable(name: "task", arg: 1, scope: !64, file: !11, line: 118, type: !6)
!68 = !DILocation(line: 118, column: 30, scope: !64)
!69 = !DILocation(line: 119, column: 9, scope: !64)
!70 = !DILocation(line: 120, column: 3, scope: !64)
!71 = !DILocation(line: 121, column: 3, scope: !64)
!72 = !DILocation(line: 122, column: 3, scope: !64)
!73 = !DILocation(line: 123, column: 15, scope: !64)
!74 = !DILocation(line: 123, column: 18, scope: !64)
!75 = !DILocation(line: 123, column: 3, scope: !64)
!76 = !DILocation(line: 124, column: 1, scope: !64)
!77 = distinct !DISubprogram(name: "init_array", scope: !11, file: !11, line: 38, type: !78, scopeLine: 41, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition, unit: !2, retainedNodes: !62)
!78 = !DISubroutineType(types: !79)
!79 = !{null, !12, !12, !80, !81}
!80 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !5, size: 64)
!81 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !45, size: 64)
!82 = !DILocalVariable(name: "m", arg: 1, scope: !77, file: !11, line: 38, type: !12)
!83 = !DILocation(line: 38, column: 22, scope: !77)
!84 = !DILocalVariable(name: "n", arg: 2, scope: !77, file: !11, line: 38, type: !12)
!85 = !DILocation(line: 38, column: 29, scope: !77)
!86 = !DILocalVariable(name: "float_n", arg: 3, scope: !77, file: !11, line: 39, type: !80)
!87 = !DILocation(line: 39, column: 15, scope: !77)
!88 = !DILocalVariable(name: "data", arg: 4, scope: !77, file: !11, line: 40, type: !81)
!89 = !DILocation(line: 40, column: 14, scope: !77)
!90 = !DILocalVariable(name: "i", scope: !77, file: !11, line: 42, type: !12)
!91 = !DILocation(line: 42, column: 7, scope: !77)
!92 = !DILocalVariable(name: "j", scope: !77, file: !11, line: 42, type: !12)
!93 = !DILocation(line: 42, column: 10, scope: !77)
!94 = !DILocation(line: 44, column: 25, scope: !77)
!95 = !DILocation(line: 44, column: 14, scope: !77)
!96 = !DILocation(line: 44, column: 4, scope: !77)
!97 = !DILocation(line: 44, column: 12, scope: !77)
!98 = !DILocation(line: 46, column: 10, scope: !99)
!99 = distinct !DILexicalBlock(scope: !77, file: !11, line: 46, column: 3)
!100 = !DILocation(line: 46, column: 8, scope: !99)
!101 = !DILocation(line: 46, column: 15, scope: !102)
!102 = distinct !DILexicalBlock(scope: !99, file: !11, line: 46, column: 3)
!103 = !DILocation(line: 46, column: 17, scope: !102)
!104 = !DILocation(line: 46, column: 3, scope: !99)
!105 = !DILocation(line: 47, column: 12, scope: !106)
!106 = distinct !DILexicalBlock(scope: !102, file: !11, line: 47, column: 5)
!107 = !DILocation(line: 47, column: 10, scope: !106)
!108 = !DILocation(line: 47, column: 17, scope: !109)
!109 = distinct !DILexicalBlock(scope: !106, file: !11, line: 47, column: 5)
!110 = !DILocation(line: 47, column: 19, scope: !109)
!111 = !DILocation(line: 47, column: 5, scope: !106)
!112 = !DILocation(line: 48, column: 33, scope: !109)
!113 = !DILocation(line: 48, column: 21, scope: !109)
!114 = !DILocation(line: 48, column: 35, scope: !109)
!115 = !DILocation(line: 48, column: 34, scope: !109)
!116 = !DILocation(line: 48, column: 38, scope: !109)
!117 = !DILocation(line: 48, column: 7, scope: !109)
!118 = !DILocation(line: 48, column: 12, scope: !109)
!119 = !DILocation(line: 48, column: 15, scope: !109)
!120 = !DILocation(line: 48, column: 18, scope: !109)
!121 = !DILocation(line: 47, column: 25, scope: !109)
!122 = !DILocation(line: 47, column: 5, scope: !109)
!123 = distinct !{!123, !111, !124, !125}
!124 = !DILocation(line: 48, column: 40, scope: !106)
!125 = !{!"llvm.loop.mustprogress"}
!126 = !DILocation(line: 46, column: 23, scope: !102)
!127 = !DILocation(line: 46, column: 3, scope: !102)
!128 = distinct !{!128, !104, !129, !125}
!129 = !DILocation(line: 48, column: 40, scope: !99)
!130 = !DILocation(line: 49, column: 1, scope: !77)
!131 = distinct !DISubprogram(name: "task_job_polybench", scope: !11, file: !11, line: 125, type: !18, scopeLine: 125, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !2, retainedNodes: !62)
!132 = !DILocation(line: 126, column: 22, scope: !131)
!133 = !DILocation(line: 126, column: 25, scope: !131)
!134 = !DILocation(line: 126, column: 28, scope: !131)
!135 = !DILocalVariable(name: "m", arg: 1, scope: !136, file: !11, line: 76, type: !12)
!136 = distinct !DISubprogram(name: "kernel_covariance", scope: !11, file: !11, line: 76, type: !137, scopeLine: 81, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition, unit: !2, retainedNodes: !62)
!137 = !DISubroutineType(types: !138)
!138 = !{null, !12, !12, !5, !81, !81, !80}
!139 = !DILocation(line: 76, column: 66, scope: !136, inlinedAt: !140)
!140 = distinct !DILocation(line: 126, column: 3, scope: !131)
!141 = !DILocalVariable(name: "n", arg: 2, scope: !136, file: !11, line: 76, type: !12)
!142 = !DILocation(line: 76, column: 73, scope: !136, inlinedAt: !140)
!143 = !DILocalVariable(name: "float_n", arg: 3, scope: !136, file: !11, line: 77, type: !5)
!144 = !DILocation(line: 77, column: 20, scope: !136, inlinedAt: !140)
!145 = !DILocalVariable(name: "data", arg: 4, scope: !136, file: !11, line: 78, type: !81)
!146 = !DILocation(line: 78, column: 20, scope: !136, inlinedAt: !140)
!147 = !DILocalVariable(name: "cov", arg: 5, scope: !136, file: !11, line: 79, type: !81)
!148 = !DILocation(line: 79, column: 20, scope: !136, inlinedAt: !140)
!149 = !DILocalVariable(name: "mean", arg: 6, scope: !136, file: !11, line: 80, type: !80)
!150 = !DILocation(line: 80, column: 20, scope: !136, inlinedAt: !140)
!151 = !DILocalVariable(name: "i", scope: !136, file: !11, line: 82, type: !12)
!152 = !DILocation(line: 82, column: 7, scope: !136, inlinedAt: !140)
!153 = !DILocalVariable(name: "j", scope: !136, file: !11, line: 82, type: !12)
!154 = !DILocation(line: 82, column: 10, scope: !136, inlinedAt: !140)
!155 = !DILocalVariable(name: "k", scope: !136, file: !11, line: 82, type: !12)
!156 = !DILocation(line: 82, column: 13, scope: !136, inlinedAt: !140)
!157 = !DILocation(line: 85, column: 10, scope: !158, inlinedAt: !140)
!158 = distinct !DILexicalBlock(scope: !136, file: !11, line: 85, column: 3)
!159 = !DILocation(line: 85, column: 8, scope: !158, inlinedAt: !140)
!160 = !DILocation(line: 85, column: 15, scope: !161, inlinedAt: !140)
!161 = distinct !DILexicalBlock(scope: !158, file: !11, line: 85, column: 3)
!162 = !DILocation(line: 85, column: 17, scope: !161, inlinedAt: !140)
!163 = !DILocation(line: 85, column: 3, scope: !158, inlinedAt: !140)
!164 = !DILocation(line: 87, column: 7, scope: !165, inlinedAt: !140)
!165 = distinct !DILexicalBlock(scope: !161, file: !11, line: 86, column: 5)
!166 = !DILocation(line: 87, column: 12, scope: !165, inlinedAt: !140)
!167 = !DILocation(line: 87, column: 15, scope: !165, inlinedAt: !140)
!168 = !DILocation(line: 88, column: 14, scope: !169, inlinedAt: !140)
!169 = distinct !DILexicalBlock(scope: !165, file: !11, line: 88, column: 7)
!170 = !DILocation(line: 88, column: 12, scope: !169, inlinedAt: !140)
!171 = !DILocation(line: 88, column: 19, scope: !172, inlinedAt: !140)
!172 = distinct !DILexicalBlock(scope: !169, file: !11, line: 88, column: 7)
!173 = !DILocation(line: 88, column: 21, scope: !172, inlinedAt: !140)
!174 = !DILocation(line: 88, column: 7, scope: !169, inlinedAt: !140)
!175 = !DILocation(line: 89, column: 20, scope: !172, inlinedAt: !140)
!176 = !DILocation(line: 89, column: 25, scope: !172, inlinedAt: !140)
!177 = !DILocation(line: 89, column: 28, scope: !172, inlinedAt: !140)
!178 = !DILocation(line: 89, column: 9, scope: !172, inlinedAt: !140)
!179 = !DILocation(line: 89, column: 14, scope: !172, inlinedAt: !140)
!180 = !DILocation(line: 89, column: 17, scope: !172, inlinedAt: !140)
!181 = !DILocation(line: 88, column: 31, scope: !172, inlinedAt: !140)
!182 = !DILocation(line: 88, column: 7, scope: !172, inlinedAt: !140)
!183 = distinct !{!183, !174, !184, !125}
!184 = !DILocation(line: 89, column: 29, scope: !169, inlinedAt: !140)
!185 = !DILocation(line: 90, column: 18, scope: !165, inlinedAt: !140)
!186 = !DILocation(line: 90, column: 7, scope: !165, inlinedAt: !140)
!187 = !DILocation(line: 90, column: 12, scope: !165, inlinedAt: !140)
!188 = !DILocation(line: 90, column: 15, scope: !165, inlinedAt: !140)
!189 = !DILocation(line: 85, column: 27, scope: !161, inlinedAt: !140)
!190 = !DILocation(line: 85, column: 3, scope: !161, inlinedAt: !140)
!191 = distinct !{!191, !163, !192, !125}
!192 = !DILocation(line: 91, column: 5, scope: !158, inlinedAt: !140)
!193 = !DILocation(line: 93, column: 10, scope: !194, inlinedAt: !140)
!194 = distinct !DILexicalBlock(scope: !136, file: !11, line: 93, column: 3)
!195 = !DILocation(line: 93, column: 8, scope: !194, inlinedAt: !140)
!196 = !DILocation(line: 93, column: 15, scope: !197, inlinedAt: !140)
!197 = distinct !DILexicalBlock(scope: !194, file: !11, line: 93, column: 3)
!198 = !DILocation(line: 93, column: 17, scope: !197, inlinedAt: !140)
!199 = !DILocation(line: 93, column: 3, scope: !194, inlinedAt: !140)
!200 = !DILocation(line: 94, column: 12, scope: !201, inlinedAt: !140)
!201 = distinct !DILexicalBlock(scope: !197, file: !11, line: 94, column: 5)
!202 = !DILocation(line: 94, column: 10, scope: !201, inlinedAt: !140)
!203 = !DILocation(line: 94, column: 17, scope: !204, inlinedAt: !140)
!204 = distinct !DILexicalBlock(scope: !201, file: !11, line: 94, column: 5)
!205 = !DILocation(line: 94, column: 19, scope: !204, inlinedAt: !140)
!206 = !DILocation(line: 94, column: 5, scope: !201, inlinedAt: !140)
!207 = !DILocation(line: 95, column: 21, scope: !204, inlinedAt: !140)
!208 = !DILocation(line: 95, column: 26, scope: !204, inlinedAt: !140)
!209 = !DILocation(line: 95, column: 7, scope: !204, inlinedAt: !140)
!210 = !DILocation(line: 95, column: 12, scope: !204, inlinedAt: !140)
!211 = !DILocation(line: 95, column: 15, scope: !204, inlinedAt: !140)
!212 = !DILocation(line: 95, column: 18, scope: !204, inlinedAt: !140)
!213 = !DILocation(line: 94, column: 29, scope: !204, inlinedAt: !140)
!214 = !DILocation(line: 94, column: 5, scope: !204, inlinedAt: !140)
!215 = distinct !{!215, !206, !216, !125}
!216 = !DILocation(line: 95, column: 27, scope: !201, inlinedAt: !140)
!217 = !DILocation(line: 93, column: 27, scope: !197, inlinedAt: !140)
!218 = !DILocation(line: 93, column: 3, scope: !197, inlinedAt: !140)
!219 = distinct !{!219, !199, !220, !125}
!220 = !DILocation(line: 95, column: 27, scope: !194, inlinedAt: !140)
!221 = !DILocation(line: 97, column: 10, scope: !222, inlinedAt: !140)
!222 = distinct !DILexicalBlock(scope: !136, file: !11, line: 97, column: 3)
!223 = !DILocation(line: 97, column: 8, scope: !222, inlinedAt: !140)
!224 = !DILocation(line: 97, column: 15, scope: !225, inlinedAt: !140)
!225 = distinct !DILexicalBlock(scope: !222, file: !11, line: 97, column: 3)
!226 = !DILocation(line: 97, column: 17, scope: !225, inlinedAt: !140)
!227 = !DILocation(line: 97, column: 3, scope: !222, inlinedAt: !140)
!228 = !DILocation(line: 98, column: 14, scope: !229, inlinedAt: !140)
!229 = distinct !DILexicalBlock(scope: !225, file: !11, line: 98, column: 5)
!230 = !DILocation(line: 98, column: 12, scope: !229, inlinedAt: !140)
!231 = !DILocation(line: 98, column: 10, scope: !229, inlinedAt: !140)
!232 = !DILocation(line: 98, column: 17, scope: !233, inlinedAt: !140)
!233 = distinct !DILexicalBlock(scope: !229, file: !11, line: 98, column: 5)
!234 = !DILocation(line: 98, column: 19, scope: !233, inlinedAt: !140)
!235 = !DILocation(line: 98, column: 5, scope: !229, inlinedAt: !140)
!236 = !DILocation(line: 100, column: 9, scope: !237, inlinedAt: !140)
!237 = distinct !DILexicalBlock(scope: !233, file: !11, line: 99, column: 7)
!238 = !DILocation(line: 100, column: 13, scope: !237, inlinedAt: !140)
!239 = !DILocation(line: 100, column: 16, scope: !237, inlinedAt: !140)
!240 = !DILocation(line: 100, column: 19, scope: !237, inlinedAt: !140)
!241 = !DILocation(line: 101, column: 16, scope: !242, inlinedAt: !140)
!242 = distinct !DILexicalBlock(scope: !237, file: !11, line: 101, column: 9)
!243 = !DILocation(line: 101, column: 14, scope: !242, inlinedAt: !140)
!244 = !DILocation(line: 101, column: 21, scope: !245, inlinedAt: !140)
!245 = distinct !DILexicalBlock(scope: !242, file: !11, line: 101, column: 9)
!246 = !DILocation(line: 101, column: 23, scope: !245, inlinedAt: !140)
!247 = !DILocation(line: 101, column: 9, scope: !242, inlinedAt: !140)
!248 = !DILocation(line: 102, column: 17, scope: !245, inlinedAt: !140)
!249 = !DILocation(line: 102, column: 22, scope: !245, inlinedAt: !140)
!250 = !DILocation(line: 102, column: 25, scope: !245, inlinedAt: !140)
!251 = !DILocation(line: 102, column: 30, scope: !245, inlinedAt: !140)
!252 = !DILocation(line: 102, column: 35, scope: !245, inlinedAt: !140)
!253 = !DILocation(line: 102, column: 38, scope: !245, inlinedAt: !140)
!254 = !DILocation(line: 102, column: 28, scope: !245, inlinedAt: !140)
!255 = !DILocation(line: 102, column: 4, scope: !245, inlinedAt: !140)
!256 = !DILocation(line: 102, column: 8, scope: !245, inlinedAt: !140)
!257 = !DILocation(line: 102, column: 11, scope: !245, inlinedAt: !140)
!258 = !DILocation(line: 102, column: 14, scope: !245, inlinedAt: !140)
!259 = !DILocation(line: 101, column: 33, scope: !245, inlinedAt: !140)
!260 = !DILocation(line: 101, column: 9, scope: !245, inlinedAt: !140)
!261 = distinct !{!261, !247, !262, !125}
!262 = !DILocation(line: 102, column: 39, scope: !242, inlinedAt: !140)
!263 = !DILocation(line: 103, column: 23, scope: !237, inlinedAt: !140)
!264 = !DILocation(line: 103, column: 31, scope: !237, inlinedAt: !140)
!265 = !DILocation(line: 103, column: 9, scope: !237, inlinedAt: !140)
!266 = !DILocation(line: 103, column: 13, scope: !237, inlinedAt: !140)
!267 = !DILocation(line: 103, column: 16, scope: !237, inlinedAt: !140)
!268 = !DILocation(line: 103, column: 19, scope: !237, inlinedAt: !140)
!269 = !DILocation(line: 104, column: 21, scope: !237, inlinedAt: !140)
!270 = !DILocation(line: 104, column: 25, scope: !237, inlinedAt: !140)
!271 = !DILocation(line: 104, column: 28, scope: !237, inlinedAt: !140)
!272 = !DILocation(line: 104, column: 9, scope: !237, inlinedAt: !140)
!273 = !DILocation(line: 104, column: 13, scope: !237, inlinedAt: !140)
!274 = !DILocation(line: 104, column: 16, scope: !237, inlinedAt: !140)
!275 = !DILocation(line: 104, column: 19, scope: !237, inlinedAt: !140)
!276 = !DILocation(line: 98, column: 29, scope: !233, inlinedAt: !140)
!277 = !DILocation(line: 98, column: 5, scope: !233, inlinedAt: !140)
!278 = distinct !{!278, !235, !279, !125}
!279 = !DILocation(line: 105, column: 7, scope: !229, inlinedAt: !140)
!280 = !DILocation(line: 97, column: 27, scope: !225, inlinedAt: !140)
!281 = !DILocation(line: 97, column: 3, scope: !225, inlinedAt: !140)
!282 = distinct !{!282, !227, !283, !125}
!283 = !DILocation(line: 105, column: 7, scope: !222, inlinedAt: !140)
!284 = !DILocation(line: 130, column: 3, scope: !131)
!285 = distinct !DISubprogram(name: "workload_checksum", scope: !11, file: !11, line: 132, type: !286, scopeLine: 132, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !2, retainedNodes: !62)
!286 = !DISubroutineType(types: !287)
!287 = !{!20, !6}
!288 = !DILocalVariable(name: "task", arg: 1, scope: !285, file: !11, line: 132, type: !6)
!289 = !DILocation(line: 132, column: 37, scope: !285)
!290 = !DILocation(line: 133, column: 9, scope: !285)
!291 = !DILocation(line: 134, column: 11, scope: !285)
!292 = !DILocation(line: 135, column: 15, scope: !285)
!293 = !DILocation(line: 135, column: 3, scope: !285)
!294 = !DILocation(line: 136, column: 10, scope: !285)
!295 = !DILocation(line: 136, column: 3, scope: !285)
!296 = distinct !DISubprogram(name: "print_array", scope: !11, file: !11, line: 55, type: !297, scopeLine: 58, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition, unit: !2, retainedNodes: !62)
!297 = !DISubroutineType(types: !298)
!298 = !{null, !12, !81}
!299 = !DILocalVariable(name: "m", arg: 1, scope: !296, file: !11, line: 55, type: !12)
!300 = !DILocation(line: 55, column: 22, scope: !296)
!301 = !DILocalVariable(name: "cov", arg: 2, scope: !296, file: !11, line: 56, type: !81)
!302 = !DILocation(line: 56, column: 14, scope: !296)
!303 = !DILocalVariable(name: "i", scope: !296, file: !11, line: 59, type: !12)
!304 = !DILocation(line: 59, column: 7, scope: !296)
!305 = !DILocalVariable(name: "j", scope: !296, file: !11, line: 59, type: !12)
!306 = !DILocation(line: 59, column: 10, scope: !296)
!307 = !DILocation(line: 61, column: 3, scope: !296)
!308 = !DILocation(line: 62, column: 3, scope: !296)
!309 = !DILocation(line: 63, column: 10, scope: !310)
!310 = distinct !DILexicalBlock(scope: !296, file: !11, line: 63, column: 3)
!311 = !DILocation(line: 63, column: 8, scope: !310)
!312 = !DILocation(line: 63, column: 15, scope: !313)
!313 = distinct !DILexicalBlock(scope: !310, file: !11, line: 63, column: 3)
!314 = !DILocation(line: 63, column: 19, scope: !313)
!315 = !DILocation(line: 63, column: 17, scope: !313)
!316 = !DILocation(line: 63, column: 3, scope: !310)
!317 = !DILocation(line: 64, column: 12, scope: !318)
!318 = distinct !DILexicalBlock(scope: !313, file: !11, line: 64, column: 5)
!319 = !DILocation(line: 64, column: 10, scope: !318)
!320 = !DILocation(line: 64, column: 17, scope: !321)
!321 = distinct !DILexicalBlock(scope: !318, file: !11, line: 64, column: 5)
!322 = !DILocation(line: 64, column: 21, scope: !321)
!323 = !DILocation(line: 64, column: 19, scope: !321)
!324 = !DILocation(line: 64, column: 5, scope: !318)
!325 = !DILocation(line: 65, column: 12, scope: !326)
!326 = distinct !DILexicalBlock(scope: !327, file: !11, line: 65, column: 11)
!327 = distinct !DILexicalBlock(scope: !321, file: !11, line: 64, column: 29)
!328 = !DILocation(line: 65, column: 16, scope: !326)
!329 = !DILocation(line: 65, column: 14, scope: !326)
!330 = !DILocation(line: 65, column: 20, scope: !326)
!331 = !DILocation(line: 65, column: 18, scope: !326)
!332 = !DILocation(line: 65, column: 23, scope: !326)
!333 = !DILocation(line: 65, column: 28, scope: !326)
!334 = !DILocation(line: 65, column: 11, scope: !327)
!335 = !DILocation(line: 65, column: 43, scope: !326)
!336 = !DILocation(line: 65, column: 34, scope: !326)
!337 = !DILocation(line: 66, column: 16, scope: !327)
!338 = !DILocation(line: 66, column: 61, scope: !327)
!339 = !DILocation(line: 66, column: 65, scope: !327)
!340 = !DILocation(line: 66, column: 68, scope: !327)
!341 = !DILocation(line: 66, column: 7, scope: !327)
!342 = !DILocation(line: 67, column: 5, scope: !327)
!343 = !DILocation(line: 64, column: 25, scope: !321)
!344 = !DILocation(line: 64, column: 5, scope: !321)
!345 = distinct !{!345, !324, !346, !125}
!346 = !DILocation(line: 67, column: 5, scope: !318)
!347 = !DILocation(line: 63, column: 23, scope: !313)
!348 = !DILocation(line: 63, column: 3, scope: !313)
!349 = distinct !{!349, !316, !350, !125}
!350 = !DILocation(line: 67, column: 5, scope: !310)
!351 = !DILocation(line: 68, column: 3, scope: !296)
!352 = !DILocation(line: 69, column: 3, scope: !296)
!353 = !DILocation(line: 70, column: 1, scope: !296)
!354 = distinct !DISubprogram(name: "pb_fprintf", scope: !32, file: !32, line: 13, type: !355, scopeLine: 14, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition, unit: !2, retainedNodes: !62)
!355 = !DISubroutineType(types: !356)
!356 = !{!12, !357, !416, null}
!357 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !358, size: 64)
!358 = !DIDerivedType(tag: DW_TAG_typedef, name: "FILE", file: !359, line: 7, baseType: !360)
!359 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/types/FILE.h", directory: "", checksumkind: CSK_MD5, checksum: "571f9fb6223c42439075fdde11a0de5d")
!360 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "_IO_FILE", file: !361, line: 49, size: 1728, elements: !362)
!361 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/types/struct_FILE.h", directory: "", checksumkind: CSK_MD5, checksum: "1bad07471b7974df4ecc1d1c2ca207e6")
!362 = !{!363, !364, !367, !368, !369, !370, !371, !372, !373, !374, !375, !376, !377, !380, !382, !383, !384, !387, !389, !391, !393, !396, !398, !401, !404, !405, !407, !411, !412}
!363 = !DIDerivedType(tag: DW_TAG_member, name: "_flags", scope: !360, file: !361, line: 51, baseType: !12, size: 32)
!364 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_read_ptr", scope: !360, file: !361, line: 54, baseType: !365, size: 64, offset: 64)
!365 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !366, size: 64)
!366 = !DIBasicType(name: "char", size: 8, encoding: DW_ATE_signed_char)
!367 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_read_end", scope: !360, file: !361, line: 55, baseType: !365, size: 64, offset: 128)
!368 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_read_base", scope: !360, file: !361, line: 56, baseType: !365, size: 64, offset: 192)
!369 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_write_base", scope: !360, file: !361, line: 57, baseType: !365, size: 64, offset: 256)
!370 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_write_ptr", scope: !360, file: !361, line: 58, baseType: !365, size: 64, offset: 320)
!371 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_write_end", scope: !360, file: !361, line: 59, baseType: !365, size: 64, offset: 384)
!372 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_buf_base", scope: !360, file: !361, line: 60, baseType: !365, size: 64, offset: 448)
!373 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_buf_end", scope: !360, file: !361, line: 61, baseType: !365, size: 64, offset: 512)
!374 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_save_base", scope: !360, file: !361, line: 64, baseType: !365, size: 64, offset: 576)
!375 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_backup_base", scope: !360, file: !361, line: 65, baseType: !365, size: 64, offset: 640)
!376 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_save_end", scope: !360, file: !361, line: 66, baseType: !365, size: 64, offset: 704)
!377 = !DIDerivedType(tag: DW_TAG_member, name: "_markers", scope: !360, file: !361, line: 68, baseType: !378, size: 64, offset: 768)
!378 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !379, size: 64)
!379 = !DICompositeType(tag: DW_TAG_structure_type, name: "_IO_marker", file: !361, line: 36, flags: DIFlagFwdDecl)
!380 = !DIDerivedType(tag: DW_TAG_member, name: "_chain", scope: !360, file: !361, line: 70, baseType: !381, size: 64, offset: 832)
!381 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !360, size: 64)
!382 = !DIDerivedType(tag: DW_TAG_member, name: "_fileno", scope: !360, file: !361, line: 72, baseType: !12, size: 32, offset: 896)
!383 = !DIDerivedType(tag: DW_TAG_member, name: "_flags2", scope: !360, file: !361, line: 73, baseType: !12, size: 32, offset: 928)
!384 = !DIDerivedType(tag: DW_TAG_member, name: "_old_offset", scope: !360, file: !361, line: 74, baseType: !385, size: 64, offset: 960)
!385 = !DIDerivedType(tag: DW_TAG_typedef, name: "__off_t", file: !23, line: 152, baseType: !386)
!386 = !DIBasicType(name: "long", size: 64, encoding: DW_ATE_signed)
!387 = !DIDerivedType(tag: DW_TAG_member, name: "_cur_column", scope: !360, file: !361, line: 77, baseType: !388, size: 16, offset: 1024)
!388 = !DIBasicType(name: "unsigned short", size: 16, encoding: DW_ATE_unsigned)
!389 = !DIDerivedType(tag: DW_TAG_member, name: "_vtable_offset", scope: !360, file: !361, line: 78, baseType: !390, size: 8, offset: 1040)
!390 = !DIBasicType(name: "signed char", size: 8, encoding: DW_ATE_signed_char)
!391 = !DIDerivedType(tag: DW_TAG_member, name: "_shortbuf", scope: !360, file: !361, line: 79, baseType: !392, size: 8, offset: 1048)
!392 = !DICompositeType(tag: DW_TAG_array_type, baseType: !366, size: 8, elements: !24)
!393 = !DIDerivedType(tag: DW_TAG_member, name: "_lock", scope: !360, file: !361, line: 81, baseType: !394, size: 64, offset: 1088)
!394 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !395, size: 64)
!395 = !DIDerivedType(tag: DW_TAG_typedef, name: "_IO_lock_t", file: !361, line: 43, baseType: null)
!396 = !DIDerivedType(tag: DW_TAG_member, name: "_offset", scope: !360, file: !361, line: 89, baseType: !397, size: 64, offset: 1152)
!397 = !DIDerivedType(tag: DW_TAG_typedef, name: "__off64_t", file: !23, line: 153, baseType: !386)
!398 = !DIDerivedType(tag: DW_TAG_member, name: "_codecvt", scope: !360, file: !361, line: 91, baseType: !399, size: 64, offset: 1216)
!399 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !400, size: 64)
!400 = !DICompositeType(tag: DW_TAG_structure_type, name: "_IO_codecvt", file: !361, line: 37, flags: DIFlagFwdDecl)
!401 = !DIDerivedType(tag: DW_TAG_member, name: "_wide_data", scope: !360, file: !361, line: 92, baseType: !402, size: 64, offset: 1280)
!402 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !403, size: 64)
!403 = !DICompositeType(tag: DW_TAG_structure_type, name: "_IO_wide_data", file: !361, line: 38, flags: DIFlagFwdDecl)
!404 = !DIDerivedType(tag: DW_TAG_member, name: "_freeres_list", scope: !360, file: !361, line: 93, baseType: !381, size: 64, offset: 1344)
!405 = !DIDerivedType(tag: DW_TAG_member, name: "_freeres_buf", scope: !360, file: !361, line: 94, baseType: !406, size: 64, offset: 1408)
!406 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: null, size: 64)
!407 = !DIDerivedType(tag: DW_TAG_member, name: "__pad5", scope: !360, file: !361, line: 95, baseType: !408, size: 64, offset: 1472)
!408 = !DIDerivedType(tag: DW_TAG_typedef, name: "size_t", file: !409, line: 46, baseType: !410)
!409 = !DIFile(filename: "/usr/lib/llvm-14/lib/clang/14.0.0/include/stddef.h", directory: "", checksumkind: CSK_MD5, checksum: "2499dd2361b915724b073282bea3a7bc")
!410 = !DIBasicType(name: "unsigned long", size: 64, encoding: DW_ATE_unsigned)
!411 = !DIDerivedType(tag: DW_TAG_member, name: "_mode", scope: !360, file: !361, line: 96, baseType: !12, size: 32, offset: 1536)
!412 = !DIDerivedType(tag: DW_TAG_member, name: "_unused2", scope: !360, file: !361, line: 98, baseType: !413, size: 160, offset: 1568)
!413 = !DICompositeType(tag: DW_TAG_array_type, baseType: !366, size: 160, elements: !414)
!414 = !{!415}
!415 = !DISubrange(count: 20)
!416 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !417, size: 64)
!417 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !366)
!418 = !DILocalVariable(name: "stream", arg: 1, scope: !354, file: !32, line: 13, type: !357)
!419 = !DILocation(line: 13, column: 29, scope: !354)
!420 = !DILocalVariable(name: "format", arg: 2, scope: !354, file: !32, line: 13, type: !416)
!421 = !DILocation(line: 13, column: 49, scope: !354)
!422 = !DILocalVariable(name: "buffer", scope: !354, file: !32, line: 15, type: !423)
!423 = !DICompositeType(tag: DW_TAG_array_type, baseType: !366, size: 6144, elements: !424)
!424 = !{!425}
!425 = !DISubrange(count: 768)
!426 = !DILocation(line: 15, column: 10, scope: !354)
!427 = !DILocalVariable(name: "args", scope: !354, file: !32, line: 16, type: !428)
!428 = !DIDerivedType(tag: DW_TAG_typedef, name: "va_list", file: !429, line: 52, baseType: !430)
!429 = !DIFile(filename: "/usr/include/stdio.h", directory: "", checksumkind: CSK_MD5, checksum: "f31eefcc3f15835fc5a4023a625cf609")
!430 = !DIDerivedType(tag: DW_TAG_typedef, name: "__gnuc_va_list", file: !431, line: 32, baseType: !432)
!431 = !DIFile(filename: "/usr/lib/llvm-14/lib/clang/14.0.0/include/stdarg.h", directory: "", checksumkind: CSK_MD5, checksum: "4de3cbd931b589d291e5c39387aecf82")
!432 = !DIDerivedType(tag: DW_TAG_typedef, name: "__builtin_va_list", file: !433, baseType: !434)
!433 = !DIFile(filename: "source/workload.c", directory: "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/triangular-20260929/suite/covariance")
!434 = !DICompositeType(tag: DW_TAG_array_type, baseType: !435, size: 192, elements: !24)
!435 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "__va_list_tag", size: 192, elements: !436)
!436 = !{!437, !438, !439, !440}
!437 = !DIDerivedType(tag: DW_TAG_member, name: "gp_offset", scope: !435, file: !433, line: 16, baseType: !6, size: 32)
!438 = !DIDerivedType(tag: DW_TAG_member, name: "fp_offset", scope: !435, file: !433, line: 16, baseType: !6, size: 32, offset: 32)
!439 = !DIDerivedType(tag: DW_TAG_member, name: "overflow_arg_area", scope: !435, file: !433, line: 16, baseType: !406, size: 64, offset: 64)
!440 = !DIDerivedType(tag: DW_TAG_member, name: "reg_save_area", scope: !435, file: !433, line: 16, baseType: !406, size: 64, offset: 128)
!441 = !DILocation(line: 16, column: 13, scope: !354)
!442 = !DILocation(line: 17, column: 5, scope: !354)
!443 = !DILocalVariable(name: "count", scope: !354, file: !32, line: 18, type: !12)
!444 = !DILocation(line: 18, column: 9, scope: !354)
!445 = !DILocation(line: 18, column: 27, scope: !354)
!446 = !DILocation(line: 18, column: 51, scope: !354)
!447 = !DILocation(line: 18, column: 59, scope: !354)
!448 = !DILocation(line: 18, column: 17, scope: !354)
!449 = !DILocation(line: 19, column: 5, scope: !354)
!450 = !DILocation(line: 20, column: 9, scope: !451)
!451 = distinct !DILexicalBlock(scope: !354, file: !32, line: 20, column: 9)
!452 = !DILocation(line: 20, column: 15, scope: !451)
!453 = !DILocation(line: 20, column: 19, scope: !451)
!454 = !DILocation(line: 20, column: 32, scope: !451)
!455 = !DILocation(line: 20, column: 22, scope: !451)
!456 = !DILocation(line: 20, column: 38, scope: !451)
!457 = !DILocation(line: 20, column: 9, scope: !354)
!458 = !DILocation(line: 20, column: 57, scope: !451)
!459 = !DILocalVariable(name: "i", scope: !460, file: !32, line: 21, type: !12)
!460 = distinct !DILexicalBlock(scope: !354, file: !32, line: 21, column: 5)
!461 = !DILocation(line: 21, column: 14, scope: !460)
!462 = !DILocation(line: 21, column: 10, scope: !460)
!463 = !DILocation(line: 21, column: 21, scope: !464)
!464 = distinct !DILexicalBlock(scope: !460, file: !32, line: 21, column: 5)
!465 = !DILocation(line: 21, column: 25, scope: !464)
!466 = !DILocation(line: 21, column: 23, scope: !464)
!467 = !DILocation(line: 21, column: 5, scope: !460)
!468 = !DILocation(line: 22, column: 42, scope: !469)
!469 = distinct !DILexicalBlock(scope: !464, file: !32, line: 21, column: 37)
!470 = !DILocation(line: 22, column: 35, scope: !469)
!471 = !DILocation(line: 22, column: 20, scope: !469)
!472 = !DILocation(line: 22, column: 17, scope: !469)
!473 = !DILocation(line: 23, column: 17, scope: !469)
!474 = !DILocation(line: 24, column: 5, scope: !469)
!475 = !DILocation(line: 21, column: 32, scope: !464)
!476 = !DILocation(line: 21, column: 5, scope: !464)
!477 = distinct !{!477, !467, !478, !125}
!478 = !DILocation(line: 24, column: 5, scope: !460)
!479 = !DILocation(line: 28, column: 11, scope: !354)
!480 = !DILocation(line: 29, column: 11, scope: !354)
!481 = !DILocation(line: 31, column: 12, scope: !354)
!482 = !DILocation(line: 31, column: 5, scope: !354)
