#include <stdint.h>
/** @brief Prepare workload state before workers start; per-job reset is optional. @return None. */
void workload_prepare(void);
extern uint32_t (*const workload_jobs[])(void);
extern const uint32_t workload_expected[];

#define CHASER_WORKLOAD_LIFECYCLE 1
/** @brief Reset original inputs before the bracket.
 * @param task Sole source-suite task index (zero). @return None. */
void workload_reset(unsigned task);
/** @brief Hash live-outs after the bracket at upstream print precision.
 * @param task Sole source-suite task index (zero). @return FNV-1a hash. */
uint32_t workload_checksum(unsigned task);
