; ModuleID = '/workspace/experiments/chaser/.cache/periodic-public-v2-final/pilot-02/source/workload.c'
source_filename = "/workspace/experiments/chaser/.cache/periodic-public-v2-final/pilot-02/source/workload.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

@.str = private unnamed_addr constant [12 x i8] c"ape.analyze\00", section "llvm.metadata"
@.str.1 = private unnamed_addr constant [89 x i8] c"/workspace/experiments/chaser/.cache/periodic-public-v2-final/pilot-02/source/workload.c\00", section "llvm.metadata"
@data_t0 = dso_local global [65536 x i8] zeroinitializer, section ".chaser_data.00", align 4096, !dbg !0
@data_t1 = dso_local global [64 x i8] zeroinitializer, section ".chaser_data.01", align 4096, !dbg !24
@data_t2 = dso_local global [128 x i8] zeroinitializer, section ".chaser_data.02", align 4096, !dbg !33
@data_t3 = dso_local global [32768 x i8] zeroinitializer, section ".chaser_data.03", align 4096, !dbg !38
@data_t4 = dso_local global [16 x i8] zeroinitializer, section ".chaser_data.04", align 4096, !dbg !43
@data_t5 = dso_local global [2048 x i8] zeroinitializer, section ".chaser_data.05", align 4096, !dbg !48
@workload_jobs = dso_local constant [6 x i32 ()*] [i32 ()* @task_job_t0, i32 ()* @task_job_t1, i32 ()* @task_job_t2, i32 ()* @task_job_t3, i32 ()* @task_job_t4, i32 ()* @task_job_t5], align 16, !dbg !5
@workload_expected = dso_local constant [6 x i32] [i32 9600, i32 9600, i32 9600, i32 9600, i32 9600, i32 9600], align 16, !dbg !20
@.str.2 = private unnamed_addr constant [11 x i8] c"ape.inline\00", section "llvm.metadata"
@llvm.global.annotations = appending global [12 x { i8*, i8*, i8*, i32, i8* }] [{ i8*, i8*, i8*, i32, i8* } { i8* bitcast (i32 ()* @task_job_t0 to i8*), i8* getelementptr inbounds ([12 x i8], [12 x i8]* @.str, i32 0, i32 0), i8* getelementptr inbounds ([89 x i8], [89 x i8]* @.str.1, i32 0, i32 0), i32 18, i8* null }, { i8*, i8*, i8*, i32, i8* } { i8* bitcast (i32 ()* @task_job_t1 to i8*), i8* getelementptr inbounds ([12 x i8], [12 x i8]* @.str, i32 0, i32 0), i8* getelementptr inbounds ([89 x i8], [89 x i8]* @.str.1, i32 0, i32 0), i32 33, i8* null }, { i8*, i8*, i8*, i32, i8* } { i8* bitcast (i32 ()* @task_job_t2 to i8*), i8* getelementptr inbounds ([12 x i8], [12 x i8]* @.str, i32 0, i32 0), i8* getelementptr inbounds ([89 x i8], [89 x i8]* @.str.1, i32 0, i32 0), i32 48, i8* null }, { i8*, i8*, i8*, i32, i8* } { i8* bitcast (i32 ()* @task_job_t3 to i8*), i8* getelementptr inbounds ([12 x i8], [12 x i8]* @.str, i32 0, i32 0), i8* getelementptr inbounds ([89 x i8], [89 x i8]* @.str.1, i32 0, i32 0), i32 63, i8* null }, { i8*, i8*, i8*, i32, i8* } { i8* bitcast (i32 ()* @task_job_t4 to i8*), i8* getelementptr inbounds ([12 x i8], [12 x i8]* @.str, i32 0, i32 0), i8* getelementptr inbounds ([89 x i8], [89 x i8]* @.str.1, i32 0, i32 0), i32 78, i8* null }, { i8*, i8*, i8*, i32, i8* } { i8* bitcast (i32 ()* @task_job_t5 to i8*), i8* getelementptr inbounds ([12 x i8], [12 x i8]* @.str, i32 0, i32 0), i8* getelementptr inbounds ([89 x i8], [89 x i8]* @.str.1, i32 0, i32 0), i32 93, i8* null }, { i8*, i8*, i8*, i32, i8* } { i8* bitcast (i32 ()* @kernel_t0 to i8*), i8* getelementptr inbounds ([11 x i8], [11 x i8]* @.str.2, i32 0, i32 0), i8* getelementptr inbounds ([89 x i8], [89 x i8]* @.str.1, i32 0, i32 0), i32 10, i8* null }, { i8*, i8*, i8*, i32, i8* } { i8* bitcast (i32 ()* @kernel_t1 to i8*), i8* getelementptr inbounds ([11 x i8], [11 x i8]* @.str.2, i32 0, i32 0), i8* getelementptr inbounds ([89 x i8], [89 x i8]* @.str.1, i32 0, i32 0), i32 25, i8* null }, { i8*, i8*, i8*, i32, i8* } { i8* bitcast (i32 ()* @kernel_t2 to i8*), i8* getelementptr inbounds ([11 x i8], [11 x i8]* @.str.2, i32 0, i32 0), i8* getelementptr inbounds ([89 x i8], [89 x i8]* @.str.1, i32 0, i32 0), i32 40, i8* null }, { i8*, i8*, i8*, i32, i8* } { i8* bitcast (i32 ()* @kernel_t3 to i8*), i8* getelementptr inbounds ([11 x i8], [11 x i8]* @.str.2, i32 0, i32 0), i8* getelementptr inbounds ([89 x i8], [89 x i8]* @.str.1, i32 0, i32 0), i32 55, i8* null }, { i8*, i8*, i8*, i32, i8* } { i8* bitcast (i32 ()* @kernel_t4 to i8*), i8* getelementptr inbounds ([11 x i8], [11 x i8]* @.str.2, i32 0, i32 0), i8* getelementptr inbounds ([89 x i8], [89 x i8]* @.str.1, i32 0, i32 0), i32 70, i8* null }, { i8*, i8*, i8*, i32, i8* } { i8* bitcast (i32 ()* @kernel_t5 to i8*), i8* getelementptr inbounds ([11 x i8], [11 x i8]* @.str.2, i32 0, i32 0), i8* getelementptr inbounds ([89 x i8], [89 x i8]* @.str.1, i32 0, i32 0), i32 85, i8* null }], section "llvm.metadata"

; Function Attrs: noinline nounwind uwtable
define dso_local i32 @task_job_t0() #0 !dbg !64 {
  %1 = alloca i32, align 4
  %2 = alloca i32, align 4
  call void @llvm.dbg.declare(metadata i32* %1, metadata !66, metadata !DIExpression()), !dbg !67
  store i32 0, i32* %1, align 4, !dbg !67
  call void @llvm.dbg.declare(metadata i32* %2, metadata !68, metadata !DIExpression()), !dbg !71
  store i32 0, i32* %2, align 4, !dbg !71
  br label %3, !dbg !72

3:                                                ; preds = %10, %0
  %4 = load i32, i32* %2, align 4, !dbg !73
  %5 = icmp slt i32 %4, 600, !dbg !75
  br i1 %5, label %6, label %13, !dbg !76

6:                                                ; preds = %3
  %7 = call i32 @kernel_t0(), !dbg !77
  %8 = load i32, i32* %1, align 4, !dbg !78
  %9 = add i32 %8, %7, !dbg !78
  store i32 %9, i32* %1, align 4, !dbg !78
  br label %10, !dbg !79

10:                                               ; preds = %6
  %11 = load i32, i32* %2, align 4, !dbg !80
  %12 = add nsw i32 %11, 1, !dbg !80
  store i32 %12, i32* %2, align 4, !dbg !80
  br label %3, !dbg !81, !llvm.loop !82

13:                                               ; preds = %3
  %14 = load i32, i32* %1, align 4, !dbg !85
  ret i32 %14, !dbg !86
}

; Function Attrs: nofree nosync nounwind readnone speculatable willreturn
declare void @llvm.dbg.declare(metadata, metadata, metadata) #1

; Function Attrs: noinline nounwind uwtable
define internal i32 @kernel_t0() #0 !dbg !87 {
  %1 = alloca i32, align 4
  %2 = alloca i32, align 4
  call void @llvm.dbg.declare(metadata i32* %1, metadata !88, metadata !DIExpression()), !dbg !89
  store i32 0, i32* %1, align 4, !dbg !89
  call void @llvm.dbg.declare(metadata i32* %2, metadata !90, metadata !DIExpression()), !dbg !92
  store i32 0, i32* %2, align 4, !dbg !92
  br label %3, !dbg !93

3:                                                ; preds = %14, %0
  %4 = load i32, i32* %2, align 4, !dbg !94
  %5 = icmp slt i32 %4, 65536, !dbg !96
  br i1 %5, label %6, label %17, !dbg !97

6:                                                ; preds = %3
  %7 = load i32, i32* %2, align 4, !dbg !98
  %8 = sext i32 %7 to i64, !dbg !99
  %9 = getelementptr inbounds [65536 x i8], [65536 x i8]* @data_t0, i64 0, i64 %8, !dbg !99
  %10 = load volatile i8, i8* %9, align 1, !dbg !99
  %11 = zext i8 %10 to i32, !dbg !99
  %12 = load i32, i32* %1, align 4, !dbg !100
  %13 = add i32 %12, %11, !dbg !100
  store i32 %13, i32* %1, align 4, !dbg !100
  br label %14, !dbg !101

14:                                               ; preds = %6
  %15 = load i32, i32* %2, align 4, !dbg !102
  %16 = add nsw i32 %15, 4096, !dbg !102
  store i32 %16, i32* %2, align 4, !dbg !102
  br label %3, !dbg !103, !llvm.loop !104

17:                                               ; preds = %3
  %18 = load i32, i32* %1, align 4, !dbg !106
  ret i32 %18, !dbg !107
}

; Function Attrs: noinline nounwind uwtable
define dso_local i32 @task_job_t1() #0 !dbg !108 {
  %1 = alloca i32, align 4
  %2 = alloca i32, align 4
  call void @llvm.dbg.declare(metadata i32* %1, metadata !109, metadata !DIExpression()), !dbg !110
  store i32 0, i32* %1, align 4, !dbg !110
  call void @llvm.dbg.declare(metadata i32* %2, metadata !111, metadata !DIExpression()), !dbg !113
  store i32 0, i32* %2, align 4, !dbg !113
  br label %3, !dbg !114

3:                                                ; preds = %10, %0
  %4 = load i32, i32* %2, align 4, !dbg !115
  %5 = icmp slt i32 %4, 150, !dbg !117
  br i1 %5, label %6, label %13, !dbg !118

6:                                                ; preds = %3
  %7 = call i32 @kernel_t1(), !dbg !119
  %8 = load i32, i32* %1, align 4, !dbg !120
  %9 = add i32 %8, %7, !dbg !120
  store i32 %9, i32* %1, align 4, !dbg !120
  br label %10, !dbg !121

10:                                               ; preds = %6
  %11 = load i32, i32* %2, align 4, !dbg !122
  %12 = add nsw i32 %11, 1, !dbg !122
  store i32 %12, i32* %2, align 4, !dbg !122
  br label %3, !dbg !123, !llvm.loop !124

13:                                               ; preds = %3
  %14 = load i32, i32* %1, align 4, !dbg !126
  ret i32 %14, !dbg !127
}

; Function Attrs: noinline nounwind uwtable
define internal i32 @kernel_t1() #0 !dbg !128 {
  %1 = alloca i32, align 4
  %2 = alloca i32, align 4
  call void @llvm.dbg.declare(metadata i32* %1, metadata !129, metadata !DIExpression()), !dbg !130
  store i32 0, i32* %1, align 4, !dbg !130
  call void @llvm.dbg.declare(metadata i32* %2, metadata !131, metadata !DIExpression()), !dbg !133
  store i32 0, i32* %2, align 4, !dbg !133
  br label %3, !dbg !134

3:                                                ; preds = %14, %0
  %4 = load i32, i32* %2, align 4, !dbg !135
  %5 = icmp slt i32 %4, 64, !dbg !137
  br i1 %5, label %6, label %17, !dbg !138

6:                                                ; preds = %3
  %7 = load i32, i32* %2, align 4, !dbg !139
  %8 = sext i32 %7 to i64, !dbg !140
  %9 = getelementptr inbounds [64 x i8], [64 x i8]* @data_t1, i64 0, i64 %8, !dbg !140
  %10 = load volatile i8, i8* %9, align 1, !dbg !140
  %11 = zext i8 %10 to i32, !dbg !140
  %12 = load i32, i32* %1, align 4, !dbg !141
  %13 = add i32 %12, %11, !dbg !141
  store i32 %13, i32* %1, align 4, !dbg !141
  br label %14, !dbg !142

14:                                               ; preds = %6
  %15 = load i32, i32* %2, align 4, !dbg !143
  %16 = add nsw i32 %15, 1, !dbg !143
  store i32 %16, i32* %2, align 4, !dbg !143
  br label %3, !dbg !144, !llvm.loop !145

17:                                               ; preds = %3
  %18 = load i32, i32* %1, align 4, !dbg !147
  ret i32 %18, !dbg !148
}

; Function Attrs: noinline nounwind uwtable
define dso_local i32 @task_job_t2() #0 !dbg !149 {
  %1 = alloca i32, align 4
  %2 = alloca i32, align 4
  call void @llvm.dbg.declare(metadata i32* %1, metadata !150, metadata !DIExpression()), !dbg !151
  store i32 0, i32* %1, align 4, !dbg !151
  call void @llvm.dbg.declare(metadata i32* %2, metadata !152, metadata !DIExpression()), !dbg !154
  store i32 0, i32* %2, align 4, !dbg !154
  br label %3, !dbg !155

3:                                                ; preds = %10, %0
  %4 = load i32, i32* %2, align 4, !dbg !156
  %5 = icmp slt i32 %4, 2400, !dbg !158
  br i1 %5, label %6, label %13, !dbg !159

6:                                                ; preds = %3
  %7 = call i32 @kernel_t2(), !dbg !160
  %8 = load i32, i32* %1, align 4, !dbg !161
  %9 = add i32 %8, %7, !dbg !161
  store i32 %9, i32* %1, align 4, !dbg !161
  br label %10, !dbg !162

10:                                               ; preds = %6
  %11 = load i32, i32* %2, align 4, !dbg !163
  %12 = add nsw i32 %11, 1, !dbg !163
  store i32 %12, i32* %2, align 4, !dbg !163
  br label %3, !dbg !164, !llvm.loop !165

13:                                               ; preds = %3
  %14 = load i32, i32* %1, align 4, !dbg !167
  ret i32 %14, !dbg !168
}

; Function Attrs: noinline nounwind uwtable
define internal i32 @kernel_t2() #0 !dbg !169 {
  %1 = alloca i32, align 4
  %2 = alloca i32, align 4
  call void @llvm.dbg.declare(metadata i32* %1, metadata !170, metadata !DIExpression()), !dbg !171
  store i32 0, i32* %1, align 4, !dbg !171
  call void @llvm.dbg.declare(metadata i32* %2, metadata !172, metadata !DIExpression()), !dbg !174
  store i32 0, i32* %2, align 4, !dbg !174
  br label %3, !dbg !175

3:                                                ; preds = %14, %0
  %4 = load i32, i32* %2, align 4, !dbg !176
  %5 = icmp slt i32 %4, 128, !dbg !178
  br i1 %5, label %6, label %17, !dbg !179

6:                                                ; preds = %3
  %7 = load i32, i32* %2, align 4, !dbg !180
  %8 = sext i32 %7 to i64, !dbg !181
  %9 = getelementptr inbounds [128 x i8], [128 x i8]* @data_t2, i64 0, i64 %8, !dbg !181
  %10 = load volatile i8, i8* %9, align 1, !dbg !181
  %11 = zext i8 %10 to i32, !dbg !181
  %12 = load i32, i32* %1, align 4, !dbg !182
  %13 = add i32 %12, %11, !dbg !182
  store i32 %13, i32* %1, align 4, !dbg !182
  br label %14, !dbg !183

14:                                               ; preds = %6
  %15 = load i32, i32* %2, align 4, !dbg !184
  %16 = add nsw i32 %15, 32, !dbg !184
  store i32 %16, i32* %2, align 4, !dbg !184
  br label %3, !dbg !185, !llvm.loop !186

17:                                               ; preds = %3
  %18 = load i32, i32* %1, align 4, !dbg !188
  ret i32 %18, !dbg !189
}

; Function Attrs: noinline nounwind uwtable
define dso_local i32 @task_job_t3() #0 !dbg !190 {
  %1 = alloca i32, align 4
  %2 = alloca i32, align 4
  call void @llvm.dbg.declare(metadata i32* %1, metadata !191, metadata !DIExpression()), !dbg !192
  store i32 0, i32* %1, align 4, !dbg !192
  call void @llvm.dbg.declare(metadata i32* %2, metadata !193, metadata !DIExpression()), !dbg !195
  store i32 0, i32* %2, align 4, !dbg !195
  br label %3, !dbg !196

3:                                                ; preds = %10, %0
  %4 = load i32, i32* %2, align 4, !dbg !197
  %5 = icmp slt i32 %4, 1200, !dbg !199
  br i1 %5, label %6, label %13, !dbg !200

6:                                                ; preds = %3
  %7 = call i32 @kernel_t3(), !dbg !201
  %8 = load i32, i32* %1, align 4, !dbg !202
  %9 = add i32 %8, %7, !dbg !202
  store i32 %9, i32* %1, align 4, !dbg !202
  br label %10, !dbg !203

10:                                               ; preds = %6
  %11 = load i32, i32* %2, align 4, !dbg !204
  %12 = add nsw i32 %11, 1, !dbg !204
  store i32 %12, i32* %2, align 4, !dbg !204
  br label %3, !dbg !205, !llvm.loop !206

13:                                               ; preds = %3
  %14 = load i32, i32* %1, align 4, !dbg !208
  ret i32 %14, !dbg !209
}

; Function Attrs: noinline nounwind uwtable
define internal i32 @kernel_t3() #0 !dbg !210 {
  %1 = alloca i32, align 4
  %2 = alloca i32, align 4
  call void @llvm.dbg.declare(metadata i32* %1, metadata !211, metadata !DIExpression()), !dbg !212
  store i32 0, i32* %1, align 4, !dbg !212
  call void @llvm.dbg.declare(metadata i32* %2, metadata !213, metadata !DIExpression()), !dbg !215
  store i32 0, i32* %2, align 4, !dbg !215
  br label %3, !dbg !216

3:                                                ; preds = %14, %0
  %4 = load i32, i32* %2, align 4, !dbg !217
  %5 = icmp slt i32 %4, 32768, !dbg !219
  br i1 %5, label %6, label %17, !dbg !220

6:                                                ; preds = %3
  %7 = load i32, i32* %2, align 4, !dbg !221
  %8 = sext i32 %7 to i64, !dbg !222
  %9 = getelementptr inbounds [32768 x i8], [32768 x i8]* @data_t3, i64 0, i64 %8, !dbg !222
  %10 = load volatile i8, i8* %9, align 1, !dbg !222
  %11 = zext i8 %10 to i32, !dbg !222
  %12 = load i32, i32* %1, align 4, !dbg !223
  %13 = add i32 %12, %11, !dbg !223
  store i32 %13, i32* %1, align 4, !dbg !223
  br label %14, !dbg !224

14:                                               ; preds = %6
  %15 = load i32, i32* %2, align 4, !dbg !225
  %16 = add nsw i32 %15, 4096, !dbg !225
  store i32 %16, i32* %2, align 4, !dbg !225
  br label %3, !dbg !226, !llvm.loop !227

17:                                               ; preds = %3
  %18 = load i32, i32* %1, align 4, !dbg !229
  ret i32 %18, !dbg !230
}

; Function Attrs: noinline nounwind uwtable
define dso_local i32 @task_job_t4() #0 !dbg !231 {
  %1 = alloca i32, align 4
  %2 = alloca i32, align 4
  call void @llvm.dbg.declare(metadata i32* %1, metadata !232, metadata !DIExpression()), !dbg !233
  store i32 0, i32* %1, align 4, !dbg !233
  call void @llvm.dbg.declare(metadata i32* %2, metadata !234, metadata !DIExpression()), !dbg !236
  store i32 0, i32* %2, align 4, !dbg !236
  br label %3, !dbg !237

3:                                                ; preds = %10, %0
  %4 = load i32, i32* %2, align 4, !dbg !238
  %5 = icmp slt i32 %4, 600, !dbg !240
  br i1 %5, label %6, label %13, !dbg !241

6:                                                ; preds = %3
  %7 = call i32 @kernel_t4(), !dbg !242
  %8 = load i32, i32* %1, align 4, !dbg !243
  %9 = add i32 %8, %7, !dbg !243
  store i32 %9, i32* %1, align 4, !dbg !243
  br label %10, !dbg !244

10:                                               ; preds = %6
  %11 = load i32, i32* %2, align 4, !dbg !245
  %12 = add nsw i32 %11, 1, !dbg !245
  store i32 %12, i32* %2, align 4, !dbg !245
  br label %3, !dbg !246, !llvm.loop !247

13:                                               ; preds = %3
  %14 = load i32, i32* %1, align 4, !dbg !249
  ret i32 %14, !dbg !250
}

; Function Attrs: noinline nounwind uwtable
define internal i32 @kernel_t4() #0 !dbg !251 {
  %1 = alloca i32, align 4
  %2 = alloca i32, align 4
  call void @llvm.dbg.declare(metadata i32* %1, metadata !252, metadata !DIExpression()), !dbg !253
  store i32 0, i32* %1, align 4, !dbg !253
  call void @llvm.dbg.declare(metadata i32* %2, metadata !254, metadata !DIExpression()), !dbg !256
  store i32 0, i32* %2, align 4, !dbg !256
  br label %3, !dbg !257

3:                                                ; preds = %14, %0
  %4 = load i32, i32* %2, align 4, !dbg !258
  %5 = icmp slt i32 %4, 16, !dbg !260
  br i1 %5, label %6, label %17, !dbg !261

6:                                                ; preds = %3
  %7 = load i32, i32* %2, align 4, !dbg !262
  %8 = sext i32 %7 to i64, !dbg !263
  %9 = getelementptr inbounds [16 x i8], [16 x i8]* @data_t4, i64 0, i64 %8, !dbg !263
  %10 = load volatile i8, i8* %9, align 1, !dbg !263
  %11 = zext i8 %10 to i32, !dbg !263
  %12 = load i32, i32* %1, align 4, !dbg !264
  %13 = add i32 %12, %11, !dbg !264
  store i32 %13, i32* %1, align 4, !dbg !264
  br label %14, !dbg !265

14:                                               ; preds = %6
  %15 = load i32, i32* %2, align 4, !dbg !266
  %16 = add nsw i32 %15, 1, !dbg !266
  store i32 %16, i32* %2, align 4, !dbg !266
  br label %3, !dbg !267, !llvm.loop !268

17:                                               ; preds = %3
  %18 = load i32, i32* %1, align 4, !dbg !270
  ret i32 %18, !dbg !271
}

; Function Attrs: noinline nounwind uwtable
define dso_local i32 @task_job_t5() #0 !dbg !272 {
  %1 = alloca i32, align 4
  %2 = alloca i32, align 4
  call void @llvm.dbg.declare(metadata i32* %1, metadata !273, metadata !DIExpression()), !dbg !274
  store i32 0, i32* %1, align 4, !dbg !274
  call void @llvm.dbg.declare(metadata i32* %2, metadata !275, metadata !DIExpression()), !dbg !277
  store i32 0, i32* %2, align 4, !dbg !277
  br label %3, !dbg !278

3:                                                ; preds = %10, %0
  %4 = load i32, i32* %2, align 4, !dbg !279
  %5 = icmp slt i32 %4, 150, !dbg !281
  br i1 %5, label %6, label %13, !dbg !282

6:                                                ; preds = %3
  %7 = call i32 @kernel_t5(), !dbg !283
  %8 = load i32, i32* %1, align 4, !dbg !284
  %9 = add i32 %8, %7, !dbg !284
  store i32 %9, i32* %1, align 4, !dbg !284
  br label %10, !dbg !285

10:                                               ; preds = %6
  %11 = load i32, i32* %2, align 4, !dbg !286
  %12 = add nsw i32 %11, 1, !dbg !286
  store i32 %12, i32* %2, align 4, !dbg !286
  br label %3, !dbg !287, !llvm.loop !288

13:                                               ; preds = %3
  %14 = load i32, i32* %1, align 4, !dbg !290
  ret i32 %14, !dbg !291
}

; Function Attrs: noinline nounwind uwtable
define internal i32 @kernel_t5() #0 !dbg !292 {
  %1 = alloca i32, align 4
  %2 = alloca i32, align 4
  call void @llvm.dbg.declare(metadata i32* %1, metadata !293, metadata !DIExpression()), !dbg !294
  store i32 0, i32* %1, align 4, !dbg !294
  call void @llvm.dbg.declare(metadata i32* %2, metadata !295, metadata !DIExpression()), !dbg !297
  store i32 0, i32* %2, align 4, !dbg !297
  br label %3, !dbg !298

3:                                                ; preds = %14, %0
  %4 = load i32, i32* %2, align 4, !dbg !299
  %5 = icmp slt i32 %4, 2048, !dbg !301
  br i1 %5, label %6, label %17, !dbg !302

6:                                                ; preds = %3
  %7 = load i32, i32* %2, align 4, !dbg !303
  %8 = sext i32 %7 to i64, !dbg !304
  %9 = getelementptr inbounds [2048 x i8], [2048 x i8]* @data_t5, i64 0, i64 %8, !dbg !304
  %10 = load volatile i8, i8* %9, align 1, !dbg !304
  %11 = zext i8 %10 to i32, !dbg !304
  %12 = load i32, i32* %1, align 4, !dbg !305
  %13 = add i32 %12, %11, !dbg !305
  store i32 %13, i32* %1, align 4, !dbg !305
  br label %14, !dbg !306

14:                                               ; preds = %6
  %15 = load i32, i32* %2, align 4, !dbg !307
  %16 = add nsw i32 %15, 32, !dbg !307
  store i32 %16, i32* %2, align 4, !dbg !307
  br label %3, !dbg !308, !llvm.loop !309

17:                                               ; preds = %3
  %18 = load i32, i32* %1, align 4, !dbg !311
  ret i32 %18, !dbg !312
}

; Function Attrs: noinline nounwind uwtable
define dso_local void @workload_prepare() #0 !dbg !313 {
  %1 = alloca i32, align 4
  %2 = alloca i32, align 4
  %3 = alloca i32, align 4
  %4 = alloca i32, align 4
  %5 = alloca i32, align 4
  %6 = alloca i32, align 4
  call void @llvm.dbg.declare(metadata i32* %1, metadata !316, metadata !DIExpression()), !dbg !318
  store i32 0, i32* %1, align 4, !dbg !318
  br label %7, !dbg !319

7:                                                ; preds = %14, %0
  %8 = load i32, i32* %1, align 4, !dbg !320
  %9 = icmp slt i32 %8, 65536, !dbg !322
  br i1 %9, label %10, label %17, !dbg !323

10:                                               ; preds = %7
  %11 = load i32, i32* %1, align 4, !dbg !324
  %12 = sext i32 %11 to i64, !dbg !325
  %13 = getelementptr inbounds [65536 x i8], [65536 x i8]* @data_t0, i64 0, i64 %12, !dbg !325
  store volatile i8 1, i8* %13, align 1, !dbg !326
  br label %14, !dbg !325

14:                                               ; preds = %10
  %15 = load i32, i32* %1, align 4, !dbg !327
  %16 = add nsw i32 %15, 1, !dbg !327
  store i32 %16, i32* %1, align 4, !dbg !327
  br label %7, !dbg !328, !llvm.loop !329

17:                                               ; preds = %7
  call void @llvm.dbg.declare(metadata i32* %2, metadata !331, metadata !DIExpression()), !dbg !333
  store i32 0, i32* %2, align 4, !dbg !333
  br label %18, !dbg !334

18:                                               ; preds = %25, %17
  %19 = load i32, i32* %2, align 4, !dbg !335
  %20 = icmp slt i32 %19, 64, !dbg !337
  br i1 %20, label %21, label %28, !dbg !338

21:                                               ; preds = %18
  %22 = load i32, i32* %2, align 4, !dbg !339
  %23 = sext i32 %22 to i64, !dbg !340
  %24 = getelementptr inbounds [64 x i8], [64 x i8]* @data_t1, i64 0, i64 %23, !dbg !340
  store volatile i8 1, i8* %24, align 1, !dbg !341
  br label %25, !dbg !340

25:                                               ; preds = %21
  %26 = load i32, i32* %2, align 4, !dbg !342
  %27 = add nsw i32 %26, 1, !dbg !342
  store i32 %27, i32* %2, align 4, !dbg !342
  br label %18, !dbg !343, !llvm.loop !344

28:                                               ; preds = %18
  call void @llvm.dbg.declare(metadata i32* %3, metadata !346, metadata !DIExpression()), !dbg !348
  store i32 0, i32* %3, align 4, !dbg !348
  br label %29, !dbg !349

29:                                               ; preds = %36, %28
  %30 = load i32, i32* %3, align 4, !dbg !350
  %31 = icmp slt i32 %30, 128, !dbg !352
  br i1 %31, label %32, label %39, !dbg !353

32:                                               ; preds = %29
  %33 = load i32, i32* %3, align 4, !dbg !354
  %34 = sext i32 %33 to i64, !dbg !355
  %35 = getelementptr inbounds [128 x i8], [128 x i8]* @data_t2, i64 0, i64 %34, !dbg !355
  store volatile i8 1, i8* %35, align 1, !dbg !356
  br label %36, !dbg !355

36:                                               ; preds = %32
  %37 = load i32, i32* %3, align 4, !dbg !357
  %38 = add nsw i32 %37, 1, !dbg !357
  store i32 %38, i32* %3, align 4, !dbg !357
  br label %29, !dbg !358, !llvm.loop !359

39:                                               ; preds = %29
  call void @llvm.dbg.declare(metadata i32* %4, metadata !361, metadata !DIExpression()), !dbg !363
  store i32 0, i32* %4, align 4, !dbg !363
  br label %40, !dbg !364

40:                                               ; preds = %47, %39
  %41 = load i32, i32* %4, align 4, !dbg !365
  %42 = icmp slt i32 %41, 32768, !dbg !367
  br i1 %42, label %43, label %50, !dbg !368

43:                                               ; preds = %40
  %44 = load i32, i32* %4, align 4, !dbg !369
  %45 = sext i32 %44 to i64, !dbg !370
  %46 = getelementptr inbounds [32768 x i8], [32768 x i8]* @data_t3, i64 0, i64 %45, !dbg !370
  store volatile i8 1, i8* %46, align 1, !dbg !371
  br label %47, !dbg !370

47:                                               ; preds = %43
  %48 = load i32, i32* %4, align 4, !dbg !372
  %49 = add nsw i32 %48, 1, !dbg !372
  store i32 %49, i32* %4, align 4, !dbg !372
  br label %40, !dbg !373, !llvm.loop !374

50:                                               ; preds = %40
  call void @llvm.dbg.declare(metadata i32* %5, metadata !376, metadata !DIExpression()), !dbg !378
  store i32 0, i32* %5, align 4, !dbg !378
  br label %51, !dbg !379

51:                                               ; preds = %58, %50
  %52 = load i32, i32* %5, align 4, !dbg !380
  %53 = icmp slt i32 %52, 16, !dbg !382
  br i1 %53, label %54, label %61, !dbg !383

54:                                               ; preds = %51
  %55 = load i32, i32* %5, align 4, !dbg !384
  %56 = sext i32 %55 to i64, !dbg !385
  %57 = getelementptr inbounds [16 x i8], [16 x i8]* @data_t4, i64 0, i64 %56, !dbg !385
  store volatile i8 1, i8* %57, align 1, !dbg !386
  br label %58, !dbg !385

58:                                               ; preds = %54
  %59 = load i32, i32* %5, align 4, !dbg !387
  %60 = add nsw i32 %59, 1, !dbg !387
  store i32 %60, i32* %5, align 4, !dbg !387
  br label %51, !dbg !388, !llvm.loop !389

61:                                               ; preds = %51
  call void @llvm.dbg.declare(metadata i32* %6, metadata !391, metadata !DIExpression()), !dbg !393
  store i32 0, i32* %6, align 4, !dbg !393
  br label %62, !dbg !394

62:                                               ; preds = %69, %61
  %63 = load i32, i32* %6, align 4, !dbg !395
  %64 = icmp slt i32 %63, 2048, !dbg !397
  br i1 %64, label %65, label %72, !dbg !398

65:                                               ; preds = %62
  %66 = load i32, i32* %6, align 4, !dbg !399
  %67 = sext i32 %66 to i64, !dbg !400
  %68 = getelementptr inbounds [2048 x i8], [2048 x i8]* @data_t5, i64 0, i64 %67, !dbg !400
  store volatile i8 1, i8* %68, align 1, !dbg !401
  br label %69, !dbg !400

69:                                               ; preds = %65
  %70 = load i32, i32* %6, align 4, !dbg !402
  %71 = add nsw i32 %70, 1, !dbg !402
  store i32 %71, i32* %6, align 4, !dbg !402
  br label %62, !dbg !403, !llvm.loop !404

72:                                               ; preds = %62
  ret void, !dbg !406
}

attributes #0 = { noinline nounwind uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { nofree nosync nounwind readnone speculatable willreturn }

!llvm.dbg.cu = !{!2}
!llvm.module.flags = !{!56, !57, !58, !59, !60, !61, !62}
!llvm.ident = !{!63}

!0 = !DIGlobalVariableExpression(var: !1, expr: !DIExpression())
!1 = distinct !DIGlobalVariable(name: "data_t0", scope: !2, file: !7, line: 9, type: !53, isLocal: false, isDefinition: true, align: 32768)
!2 = distinct !DICompileUnit(language: DW_LANG_C99, file: !3, producer: "Ubuntu clang version 14.0.0-1ubuntu1.1", isOptimized: false, runtimeVersion: 0, emissionKind: FullDebug, globals: !4, splitDebugInlining: false, nameTableKind: None)
!3 = !DIFile(filename: "/workspace/experiments/chaser/.cache/periodic-public-v2-final/pilot-02/source/workload.c", directory: "/workspace/experiments/chaser/.cache/periodic-public-v2-final/pilot-02/analysis", checksumkind: CSK_MD5, checksum: "518f6946121f4df22ef928af830608f1")
!4 = !{!5, !20, !0, !24, !33, !38, !43, !48}
!5 = !DIGlobalVariableExpression(var: !6, expr: !DIExpression())
!6 = distinct !DIGlobalVariable(name: "workload_jobs", scope: !2, file: !7, line: 107, type: !8, isLocal: false, isDefinition: true)
!7 = !DIFile(filename: "source/workload.c", directory: "/workspace/experiments/chaser/.cache/periodic-public-v2-final/pilot-02", checksumkind: CSK_MD5, checksum: "518f6946121f4df22ef928af830608f1")
!8 = !DICompositeType(tag: DW_TAG_array_type, baseType: !9, size: 384, elements: !18)
!9 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !10)
!10 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !11, size: 64)
!11 = !DISubroutineType(types: !12)
!12 = !{!13}
!13 = !DIDerivedType(tag: DW_TAG_typedef, name: "uint32_t", file: !14, line: 26, baseType: !15)
!14 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/stdint-uintn.h", directory: "", checksumkind: CSK_MD5, checksum: "2bf2ae53c58c01b1a1b9383b5195125c")
!15 = !DIDerivedType(tag: DW_TAG_typedef, name: "__uint32_t", file: !16, line: 42, baseType: !17)
!16 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/types.h", directory: "", checksumkind: CSK_MD5, checksum: "d108b5f93a74c50510d7d9bc0ab36df9")
!17 = !DIBasicType(name: "unsigned int", size: 32, encoding: DW_ATE_unsigned)
!18 = !{!19}
!19 = !DISubrange(count: 6)
!20 = !DIGlobalVariableExpression(var: !21, expr: !DIExpression())
!21 = distinct !DIGlobalVariable(name: "workload_expected", scope: !2, file: !7, line: 115, type: !22, isLocal: false, isDefinition: true)
!22 = !DICompositeType(tag: DW_TAG_array_type, baseType: !23, size: 192, elements: !18)
!23 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !13)
!24 = !DIGlobalVariableExpression(var: !25, expr: !DIExpression())
!25 = distinct !DIGlobalVariable(name: "data_t1", scope: !2, file: !7, line: 24, type: !26, isLocal: false, isDefinition: true, align: 32768)
!26 = !DICompositeType(tag: DW_TAG_array_type, baseType: !27, size: 512, elements: !31)
!27 = !DIDerivedType(tag: DW_TAG_volatile_type, baseType: !28)
!28 = !DIDerivedType(tag: DW_TAG_typedef, name: "uint8_t", file: !14, line: 24, baseType: !29)
!29 = !DIDerivedType(tag: DW_TAG_typedef, name: "__uint8_t", file: !16, line: 38, baseType: !30)
!30 = !DIBasicType(name: "unsigned char", size: 8, encoding: DW_ATE_unsigned_char)
!31 = !{!32}
!32 = !DISubrange(count: 64)
!33 = !DIGlobalVariableExpression(var: !34, expr: !DIExpression())
!34 = distinct !DIGlobalVariable(name: "data_t2", scope: !2, file: !7, line: 39, type: !35, isLocal: false, isDefinition: true, align: 32768)
!35 = !DICompositeType(tag: DW_TAG_array_type, baseType: !27, size: 1024, elements: !36)
!36 = !{!37}
!37 = !DISubrange(count: 128)
!38 = !DIGlobalVariableExpression(var: !39, expr: !DIExpression())
!39 = distinct !DIGlobalVariable(name: "data_t3", scope: !2, file: !7, line: 54, type: !40, isLocal: false, isDefinition: true, align: 32768)
!40 = !DICompositeType(tag: DW_TAG_array_type, baseType: !27, size: 262144, elements: !41)
!41 = !{!42}
!42 = !DISubrange(count: 32768)
!43 = !DIGlobalVariableExpression(var: !44, expr: !DIExpression())
!44 = distinct !DIGlobalVariable(name: "data_t4", scope: !2, file: !7, line: 69, type: !45, isLocal: false, isDefinition: true, align: 32768)
!45 = !DICompositeType(tag: DW_TAG_array_type, baseType: !27, size: 128, elements: !46)
!46 = !{!47}
!47 = !DISubrange(count: 16)
!48 = !DIGlobalVariableExpression(var: !49, expr: !DIExpression())
!49 = distinct !DIGlobalVariable(name: "data_t5", scope: !2, file: !7, line: 84, type: !50, isLocal: false, isDefinition: true, align: 32768)
!50 = !DICompositeType(tag: DW_TAG_array_type, baseType: !27, size: 16384, elements: !51)
!51 = !{!52}
!52 = !DISubrange(count: 2048)
!53 = !DICompositeType(tag: DW_TAG_array_type, baseType: !27, size: 524288, elements: !54)
!54 = !{!55}
!55 = !DISubrange(count: 65536)
!56 = !{i32 7, !"Dwarf Version", i32 5}
!57 = !{i32 2, !"Debug Info Version", i32 3}
!58 = !{i32 1, !"wchar_size", i32 4}
!59 = !{i32 7, !"PIC Level", i32 2}
!60 = !{i32 7, !"PIE Level", i32 2}
!61 = !{i32 7, !"uwtable", i32 1}
!62 = !{i32 7, !"frame-pointer", i32 2}
!63 = !{!"Ubuntu clang version 14.0.0-1ubuntu1.1"}
!64 = distinct !DISubprogram(name: "task_job_t0", scope: !7, file: !7, line: 18, type: !11, scopeLine: 18, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !2, retainedNodes: !65)
!65 = !{}
!66 = !DILocalVariable(name: "sum", scope: !64, file: !7, line: 19, type: !13)
!67 = !DILocation(line: 19, column: 14, scope: !64)
!68 = !DILocalVariable(name: "s", scope: !69, file: !7, line: 20, type: !70)
!69 = distinct !DILexicalBlock(scope: !64, file: !7, line: 20, column: 5)
!70 = !DIBasicType(name: "int", size: 32, encoding: DW_ATE_signed)
!71 = !DILocation(line: 20, column: 14, scope: !69)
!72 = !DILocation(line: 20, column: 10, scope: !69)
!73 = !DILocation(line: 20, column: 21, scope: !74)
!74 = distinct !DILexicalBlock(scope: !69, file: !7, line: 20, column: 5)
!75 = !DILocation(line: 20, column: 23, scope: !74)
!76 = !DILocation(line: 20, column: 5, scope: !69)
!77 = !DILocation(line: 21, column: 16, scope: !74)
!78 = !DILocation(line: 21, column: 13, scope: !74)
!79 = !DILocation(line: 21, column: 9, scope: !74)
!80 = !DILocation(line: 20, column: 30, scope: !74)
!81 = !DILocation(line: 20, column: 5, scope: !74)
!82 = distinct !{!82, !76, !83, !84}
!83 = !DILocation(line: 21, column: 26, scope: !69)
!84 = !{!"llvm.loop.mustprogress"}
!85 = !DILocation(line: 22, column: 12, scope: !64)
!86 = !DILocation(line: 22, column: 5, scope: !64)
!87 = distinct !DISubprogram(name: "kernel_t0", scope: !7, file: !7, line: 10, type: !11, scopeLine: 10, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition, unit: !2, retainedNodes: !65)
!88 = !DILocalVariable(name: "sum", scope: !87, file: !7, line: 11, type: !13)
!89 = !DILocation(line: 11, column: 14, scope: !87)
!90 = !DILocalVariable(name: "i", scope: !91, file: !7, line: 12, type: !70)
!91 = distinct !DILexicalBlock(scope: !87, file: !7, line: 12, column: 5)
!92 = !DILocation(line: 12, column: 14, scope: !91)
!93 = !DILocation(line: 12, column: 10, scope: !91)
!94 = !DILocation(line: 12, column: 21, scope: !95)
!95 = distinct !DILexicalBlock(scope: !91, file: !7, line: 12, column: 5)
!96 = !DILocation(line: 12, column: 23, scope: !95)
!97 = !DILocation(line: 12, column: 5, scope: !91)
!98 = !DILocation(line: 13, column: 24, scope: !95)
!99 = !DILocation(line: 13, column: 16, scope: !95)
!100 = !DILocation(line: 13, column: 13, scope: !95)
!101 = !DILocation(line: 13, column: 9, scope: !95)
!102 = !DILocation(line: 12, column: 34, scope: !95)
!103 = !DILocation(line: 12, column: 5, scope: !95)
!104 = distinct !{!104, !97, !105, !84}
!105 = !DILocation(line: 13, column: 25, scope: !91)
!106 = !DILocation(line: 14, column: 12, scope: !87)
!107 = !DILocation(line: 14, column: 5, scope: !87)
!108 = distinct !DISubprogram(name: "task_job_t1", scope: !7, file: !7, line: 33, type: !11, scopeLine: 33, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !2, retainedNodes: !65)
!109 = !DILocalVariable(name: "sum", scope: !108, file: !7, line: 34, type: !13)
!110 = !DILocation(line: 34, column: 14, scope: !108)
!111 = !DILocalVariable(name: "s", scope: !112, file: !7, line: 35, type: !70)
!112 = distinct !DILexicalBlock(scope: !108, file: !7, line: 35, column: 5)
!113 = !DILocation(line: 35, column: 14, scope: !112)
!114 = !DILocation(line: 35, column: 10, scope: !112)
!115 = !DILocation(line: 35, column: 21, scope: !116)
!116 = distinct !DILexicalBlock(scope: !112, file: !7, line: 35, column: 5)
!117 = !DILocation(line: 35, column: 23, scope: !116)
!118 = !DILocation(line: 35, column: 5, scope: !112)
!119 = !DILocation(line: 36, column: 16, scope: !116)
!120 = !DILocation(line: 36, column: 13, scope: !116)
!121 = !DILocation(line: 36, column: 9, scope: !116)
!122 = !DILocation(line: 35, column: 30, scope: !116)
!123 = !DILocation(line: 35, column: 5, scope: !116)
!124 = distinct !{!124, !118, !125, !84}
!125 = !DILocation(line: 36, column: 26, scope: !112)
!126 = !DILocation(line: 37, column: 12, scope: !108)
!127 = !DILocation(line: 37, column: 5, scope: !108)
!128 = distinct !DISubprogram(name: "kernel_t1", scope: !7, file: !7, line: 25, type: !11, scopeLine: 25, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition, unit: !2, retainedNodes: !65)
!129 = !DILocalVariable(name: "sum", scope: !128, file: !7, line: 26, type: !13)
!130 = !DILocation(line: 26, column: 14, scope: !128)
!131 = !DILocalVariable(name: "i", scope: !132, file: !7, line: 27, type: !70)
!132 = distinct !DILexicalBlock(scope: !128, file: !7, line: 27, column: 5)
!133 = !DILocation(line: 27, column: 14, scope: !132)
!134 = !DILocation(line: 27, column: 10, scope: !132)
!135 = !DILocation(line: 27, column: 21, scope: !136)
!136 = distinct !DILexicalBlock(scope: !132, file: !7, line: 27, column: 5)
!137 = !DILocation(line: 27, column: 23, scope: !136)
!138 = !DILocation(line: 27, column: 5, scope: !132)
!139 = !DILocation(line: 28, column: 24, scope: !136)
!140 = !DILocation(line: 28, column: 16, scope: !136)
!141 = !DILocation(line: 28, column: 13, scope: !136)
!142 = !DILocation(line: 28, column: 9, scope: !136)
!143 = !DILocation(line: 27, column: 31, scope: !136)
!144 = !DILocation(line: 27, column: 5, scope: !136)
!145 = distinct !{!145, !138, !146, !84}
!146 = !DILocation(line: 28, column: 25, scope: !132)
!147 = !DILocation(line: 29, column: 12, scope: !128)
!148 = !DILocation(line: 29, column: 5, scope: !128)
!149 = distinct !DISubprogram(name: "task_job_t2", scope: !7, file: !7, line: 48, type: !11, scopeLine: 48, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !2, retainedNodes: !65)
!150 = !DILocalVariable(name: "sum", scope: !149, file: !7, line: 49, type: !13)
!151 = !DILocation(line: 49, column: 14, scope: !149)
!152 = !DILocalVariable(name: "s", scope: !153, file: !7, line: 50, type: !70)
!153 = distinct !DILexicalBlock(scope: !149, file: !7, line: 50, column: 5)
!154 = !DILocation(line: 50, column: 14, scope: !153)
!155 = !DILocation(line: 50, column: 10, scope: !153)
!156 = !DILocation(line: 50, column: 21, scope: !157)
!157 = distinct !DILexicalBlock(scope: !153, file: !7, line: 50, column: 5)
!158 = !DILocation(line: 50, column: 23, scope: !157)
!159 = !DILocation(line: 50, column: 5, scope: !153)
!160 = !DILocation(line: 51, column: 16, scope: !157)
!161 = !DILocation(line: 51, column: 13, scope: !157)
!162 = !DILocation(line: 51, column: 9, scope: !157)
!163 = !DILocation(line: 50, column: 31, scope: !157)
!164 = !DILocation(line: 50, column: 5, scope: !157)
!165 = distinct !{!165, !159, !166, !84}
!166 = !DILocation(line: 51, column: 26, scope: !153)
!167 = !DILocation(line: 52, column: 12, scope: !149)
!168 = !DILocation(line: 52, column: 5, scope: !149)
!169 = distinct !DISubprogram(name: "kernel_t2", scope: !7, file: !7, line: 40, type: !11, scopeLine: 40, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition, unit: !2, retainedNodes: !65)
!170 = !DILocalVariable(name: "sum", scope: !169, file: !7, line: 41, type: !13)
!171 = !DILocation(line: 41, column: 14, scope: !169)
!172 = !DILocalVariable(name: "i", scope: !173, file: !7, line: 42, type: !70)
!173 = distinct !DILexicalBlock(scope: !169, file: !7, line: 42, column: 5)
!174 = !DILocation(line: 42, column: 14, scope: !173)
!175 = !DILocation(line: 42, column: 10, scope: !173)
!176 = !DILocation(line: 42, column: 21, scope: !177)
!177 = distinct !DILexicalBlock(scope: !173, file: !7, line: 42, column: 5)
!178 = !DILocation(line: 42, column: 23, scope: !177)
!179 = !DILocation(line: 42, column: 5, scope: !173)
!180 = !DILocation(line: 43, column: 24, scope: !177)
!181 = !DILocation(line: 43, column: 16, scope: !177)
!182 = !DILocation(line: 43, column: 13, scope: !177)
!183 = !DILocation(line: 43, column: 9, scope: !177)
!184 = !DILocation(line: 42, column: 32, scope: !177)
!185 = !DILocation(line: 42, column: 5, scope: !177)
!186 = distinct !{!186, !179, !187, !84}
!187 = !DILocation(line: 43, column: 25, scope: !173)
!188 = !DILocation(line: 44, column: 12, scope: !169)
!189 = !DILocation(line: 44, column: 5, scope: !169)
!190 = distinct !DISubprogram(name: "task_job_t3", scope: !7, file: !7, line: 63, type: !11, scopeLine: 63, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !2, retainedNodes: !65)
!191 = !DILocalVariable(name: "sum", scope: !190, file: !7, line: 64, type: !13)
!192 = !DILocation(line: 64, column: 14, scope: !190)
!193 = !DILocalVariable(name: "s", scope: !194, file: !7, line: 65, type: !70)
!194 = distinct !DILexicalBlock(scope: !190, file: !7, line: 65, column: 5)
!195 = !DILocation(line: 65, column: 14, scope: !194)
!196 = !DILocation(line: 65, column: 10, scope: !194)
!197 = !DILocation(line: 65, column: 21, scope: !198)
!198 = distinct !DILexicalBlock(scope: !194, file: !7, line: 65, column: 5)
!199 = !DILocation(line: 65, column: 23, scope: !198)
!200 = !DILocation(line: 65, column: 5, scope: !194)
!201 = !DILocation(line: 66, column: 16, scope: !198)
!202 = !DILocation(line: 66, column: 13, scope: !198)
!203 = !DILocation(line: 66, column: 9, scope: !198)
!204 = !DILocation(line: 65, column: 31, scope: !198)
!205 = !DILocation(line: 65, column: 5, scope: !198)
!206 = distinct !{!206, !200, !207, !84}
!207 = !DILocation(line: 66, column: 26, scope: !194)
!208 = !DILocation(line: 67, column: 12, scope: !190)
!209 = !DILocation(line: 67, column: 5, scope: !190)
!210 = distinct !DISubprogram(name: "kernel_t3", scope: !7, file: !7, line: 55, type: !11, scopeLine: 55, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition, unit: !2, retainedNodes: !65)
!211 = !DILocalVariable(name: "sum", scope: !210, file: !7, line: 56, type: !13)
!212 = !DILocation(line: 56, column: 14, scope: !210)
!213 = !DILocalVariable(name: "i", scope: !214, file: !7, line: 57, type: !70)
!214 = distinct !DILexicalBlock(scope: !210, file: !7, line: 57, column: 5)
!215 = !DILocation(line: 57, column: 14, scope: !214)
!216 = !DILocation(line: 57, column: 10, scope: !214)
!217 = !DILocation(line: 57, column: 21, scope: !218)
!218 = distinct !DILexicalBlock(scope: !214, file: !7, line: 57, column: 5)
!219 = !DILocation(line: 57, column: 23, scope: !218)
!220 = !DILocation(line: 57, column: 5, scope: !214)
!221 = !DILocation(line: 58, column: 24, scope: !218)
!222 = !DILocation(line: 58, column: 16, scope: !218)
!223 = !DILocation(line: 58, column: 13, scope: !218)
!224 = !DILocation(line: 58, column: 9, scope: !218)
!225 = !DILocation(line: 57, column: 34, scope: !218)
!226 = !DILocation(line: 57, column: 5, scope: !218)
!227 = distinct !{!227, !220, !228, !84}
!228 = !DILocation(line: 58, column: 25, scope: !214)
!229 = !DILocation(line: 59, column: 12, scope: !210)
!230 = !DILocation(line: 59, column: 5, scope: !210)
!231 = distinct !DISubprogram(name: "task_job_t4", scope: !7, file: !7, line: 78, type: !11, scopeLine: 78, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !2, retainedNodes: !65)
!232 = !DILocalVariable(name: "sum", scope: !231, file: !7, line: 79, type: !13)
!233 = !DILocation(line: 79, column: 14, scope: !231)
!234 = !DILocalVariable(name: "s", scope: !235, file: !7, line: 80, type: !70)
!235 = distinct !DILexicalBlock(scope: !231, file: !7, line: 80, column: 5)
!236 = !DILocation(line: 80, column: 14, scope: !235)
!237 = !DILocation(line: 80, column: 10, scope: !235)
!238 = !DILocation(line: 80, column: 21, scope: !239)
!239 = distinct !DILexicalBlock(scope: !235, file: !7, line: 80, column: 5)
!240 = !DILocation(line: 80, column: 23, scope: !239)
!241 = !DILocation(line: 80, column: 5, scope: !235)
!242 = !DILocation(line: 81, column: 16, scope: !239)
!243 = !DILocation(line: 81, column: 13, scope: !239)
!244 = !DILocation(line: 81, column: 9, scope: !239)
!245 = !DILocation(line: 80, column: 30, scope: !239)
!246 = !DILocation(line: 80, column: 5, scope: !239)
!247 = distinct !{!247, !241, !248, !84}
!248 = !DILocation(line: 81, column: 26, scope: !235)
!249 = !DILocation(line: 82, column: 12, scope: !231)
!250 = !DILocation(line: 82, column: 5, scope: !231)
!251 = distinct !DISubprogram(name: "kernel_t4", scope: !7, file: !7, line: 70, type: !11, scopeLine: 70, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition, unit: !2, retainedNodes: !65)
!252 = !DILocalVariable(name: "sum", scope: !251, file: !7, line: 71, type: !13)
!253 = !DILocation(line: 71, column: 14, scope: !251)
!254 = !DILocalVariable(name: "i", scope: !255, file: !7, line: 72, type: !70)
!255 = distinct !DILexicalBlock(scope: !251, file: !7, line: 72, column: 5)
!256 = !DILocation(line: 72, column: 14, scope: !255)
!257 = !DILocation(line: 72, column: 10, scope: !255)
!258 = !DILocation(line: 72, column: 21, scope: !259)
!259 = distinct !DILexicalBlock(scope: !255, file: !7, line: 72, column: 5)
!260 = !DILocation(line: 72, column: 23, scope: !259)
!261 = !DILocation(line: 72, column: 5, scope: !255)
!262 = !DILocation(line: 73, column: 24, scope: !259)
!263 = !DILocation(line: 73, column: 16, scope: !259)
!264 = !DILocation(line: 73, column: 13, scope: !259)
!265 = !DILocation(line: 73, column: 9, scope: !259)
!266 = !DILocation(line: 72, column: 31, scope: !259)
!267 = !DILocation(line: 72, column: 5, scope: !259)
!268 = distinct !{!268, !261, !269, !84}
!269 = !DILocation(line: 73, column: 25, scope: !255)
!270 = !DILocation(line: 74, column: 12, scope: !251)
!271 = !DILocation(line: 74, column: 5, scope: !251)
!272 = distinct !DISubprogram(name: "task_job_t5", scope: !7, file: !7, line: 93, type: !11, scopeLine: 93, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !2, retainedNodes: !65)
!273 = !DILocalVariable(name: "sum", scope: !272, file: !7, line: 94, type: !13)
!274 = !DILocation(line: 94, column: 14, scope: !272)
!275 = !DILocalVariable(name: "s", scope: !276, file: !7, line: 95, type: !70)
!276 = distinct !DILexicalBlock(scope: !272, file: !7, line: 95, column: 5)
!277 = !DILocation(line: 95, column: 14, scope: !276)
!278 = !DILocation(line: 95, column: 10, scope: !276)
!279 = !DILocation(line: 95, column: 21, scope: !280)
!280 = distinct !DILexicalBlock(scope: !276, file: !7, line: 95, column: 5)
!281 = !DILocation(line: 95, column: 23, scope: !280)
!282 = !DILocation(line: 95, column: 5, scope: !276)
!283 = !DILocation(line: 96, column: 16, scope: !280)
!284 = !DILocation(line: 96, column: 13, scope: !280)
!285 = !DILocation(line: 96, column: 9, scope: !280)
!286 = !DILocation(line: 95, column: 30, scope: !280)
!287 = !DILocation(line: 95, column: 5, scope: !280)
!288 = distinct !{!288, !282, !289, !84}
!289 = !DILocation(line: 96, column: 26, scope: !276)
!290 = !DILocation(line: 97, column: 12, scope: !272)
!291 = !DILocation(line: 97, column: 5, scope: !272)
!292 = distinct !DISubprogram(name: "kernel_t5", scope: !7, file: !7, line: 85, type: !11, scopeLine: 85, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition, unit: !2, retainedNodes: !65)
!293 = !DILocalVariable(name: "sum", scope: !292, file: !7, line: 86, type: !13)
!294 = !DILocation(line: 86, column: 14, scope: !292)
!295 = !DILocalVariable(name: "i", scope: !296, file: !7, line: 87, type: !70)
!296 = distinct !DILexicalBlock(scope: !292, file: !7, line: 87, column: 5)
!297 = !DILocation(line: 87, column: 14, scope: !296)
!298 = !DILocation(line: 87, column: 10, scope: !296)
!299 = !DILocation(line: 87, column: 21, scope: !300)
!300 = distinct !DILexicalBlock(scope: !296, file: !7, line: 87, column: 5)
!301 = !DILocation(line: 87, column: 23, scope: !300)
!302 = !DILocation(line: 87, column: 5, scope: !296)
!303 = !DILocation(line: 88, column: 24, scope: !300)
!304 = !DILocation(line: 88, column: 16, scope: !300)
!305 = !DILocation(line: 88, column: 13, scope: !300)
!306 = !DILocation(line: 88, column: 9, scope: !300)
!307 = !DILocation(line: 87, column: 33, scope: !300)
!308 = !DILocation(line: 87, column: 5, scope: !300)
!309 = distinct !{!309, !302, !310, !84}
!310 = !DILocation(line: 88, column: 25, scope: !296)
!311 = !DILocation(line: 89, column: 12, scope: !292)
!312 = !DILocation(line: 89, column: 5, scope: !292)
!313 = distinct !DISubprogram(name: "workload_prepare", scope: !7, file: !7, line: 99, type: !314, scopeLine: 99, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !2, retainedNodes: !65)
!314 = !DISubroutineType(types: !315)
!315 = !{null}
!316 = !DILocalVariable(name: "i", scope: !317, file: !7, line: 100, type: !70)
!317 = distinct !DILexicalBlock(scope: !313, file: !7, line: 100, column: 5)
!318 = !DILocation(line: 100, column: 14, scope: !317)
!319 = !DILocation(line: 100, column: 10, scope: !317)
!320 = !DILocation(line: 100, column: 21, scope: !321)
!321 = distinct !DILexicalBlock(scope: !317, file: !7, line: 100, column: 5)
!322 = !DILocation(line: 100, column: 23, scope: !321)
!323 = !DILocation(line: 100, column: 5, scope: !317)
!324 = !DILocation(line: 100, column: 45, scope: !321)
!325 = !DILocation(line: 100, column: 37, scope: !321)
!326 = !DILocation(line: 100, column: 48, scope: !321)
!327 = !DILocation(line: 100, column: 32, scope: !321)
!328 = !DILocation(line: 100, column: 5, scope: !321)
!329 = distinct !{!329, !323, !330, !84}
!330 = !DILocation(line: 100, column: 50, scope: !317)
!331 = !DILocalVariable(name: "i", scope: !332, file: !7, line: 101, type: !70)
!332 = distinct !DILexicalBlock(scope: !313, file: !7, line: 101, column: 5)
!333 = !DILocation(line: 101, column: 14, scope: !332)
!334 = !DILocation(line: 101, column: 10, scope: !332)
!335 = !DILocation(line: 101, column: 21, scope: !336)
!336 = distinct !DILexicalBlock(scope: !332, file: !7, line: 101, column: 5)
!337 = !DILocation(line: 101, column: 23, scope: !336)
!338 = !DILocation(line: 101, column: 5, scope: !332)
!339 = !DILocation(line: 101, column: 42, scope: !336)
!340 = !DILocation(line: 101, column: 34, scope: !336)
!341 = !DILocation(line: 101, column: 45, scope: !336)
!342 = !DILocation(line: 101, column: 29, scope: !336)
!343 = !DILocation(line: 101, column: 5, scope: !336)
!344 = distinct !{!344, !338, !345, !84}
!345 = !DILocation(line: 101, column: 47, scope: !332)
!346 = !DILocalVariable(name: "i", scope: !347, file: !7, line: 102, type: !70)
!347 = distinct !DILexicalBlock(scope: !313, file: !7, line: 102, column: 5)
!348 = !DILocation(line: 102, column: 14, scope: !347)
!349 = !DILocation(line: 102, column: 10, scope: !347)
!350 = !DILocation(line: 102, column: 21, scope: !351)
!351 = distinct !DILexicalBlock(scope: !347, file: !7, line: 102, column: 5)
!352 = !DILocation(line: 102, column: 23, scope: !351)
!353 = !DILocation(line: 102, column: 5, scope: !347)
!354 = !DILocation(line: 102, column: 43, scope: !351)
!355 = !DILocation(line: 102, column: 35, scope: !351)
!356 = !DILocation(line: 102, column: 46, scope: !351)
!357 = !DILocation(line: 102, column: 30, scope: !351)
!358 = !DILocation(line: 102, column: 5, scope: !351)
!359 = distinct !{!359, !353, !360, !84}
!360 = !DILocation(line: 102, column: 48, scope: !347)
!361 = !DILocalVariable(name: "i", scope: !362, file: !7, line: 103, type: !70)
!362 = distinct !DILexicalBlock(scope: !313, file: !7, line: 103, column: 5)
!363 = !DILocation(line: 103, column: 14, scope: !362)
!364 = !DILocation(line: 103, column: 10, scope: !362)
!365 = !DILocation(line: 103, column: 21, scope: !366)
!366 = distinct !DILexicalBlock(scope: !362, file: !7, line: 103, column: 5)
!367 = !DILocation(line: 103, column: 23, scope: !366)
!368 = !DILocation(line: 103, column: 5, scope: !362)
!369 = !DILocation(line: 103, column: 45, scope: !366)
!370 = !DILocation(line: 103, column: 37, scope: !366)
!371 = !DILocation(line: 103, column: 48, scope: !366)
!372 = !DILocation(line: 103, column: 32, scope: !366)
!373 = !DILocation(line: 103, column: 5, scope: !366)
!374 = distinct !{!374, !368, !375, !84}
!375 = !DILocation(line: 103, column: 50, scope: !362)
!376 = !DILocalVariable(name: "i", scope: !377, file: !7, line: 104, type: !70)
!377 = distinct !DILexicalBlock(scope: !313, file: !7, line: 104, column: 5)
!378 = !DILocation(line: 104, column: 14, scope: !377)
!379 = !DILocation(line: 104, column: 10, scope: !377)
!380 = !DILocation(line: 104, column: 21, scope: !381)
!381 = distinct !DILexicalBlock(scope: !377, file: !7, line: 104, column: 5)
!382 = !DILocation(line: 104, column: 23, scope: !381)
!383 = !DILocation(line: 104, column: 5, scope: !377)
!384 = !DILocation(line: 104, column: 42, scope: !381)
!385 = !DILocation(line: 104, column: 34, scope: !381)
!386 = !DILocation(line: 104, column: 45, scope: !381)
!387 = !DILocation(line: 104, column: 29, scope: !381)
!388 = !DILocation(line: 104, column: 5, scope: !381)
!389 = distinct !{!389, !383, !390, !84}
!390 = !DILocation(line: 104, column: 47, scope: !377)
!391 = !DILocalVariable(name: "i", scope: !392, file: !7, line: 105, type: !70)
!392 = distinct !DILexicalBlock(scope: !313, file: !7, line: 105, column: 5)
!393 = !DILocation(line: 105, column: 14, scope: !392)
!394 = !DILocation(line: 105, column: 10, scope: !392)
!395 = !DILocation(line: 105, column: 21, scope: !396)
!396 = distinct !DILexicalBlock(scope: !392, file: !7, line: 105, column: 5)
!397 = !DILocation(line: 105, column: 23, scope: !396)
!398 = !DILocation(line: 105, column: 5, scope: !392)
!399 = !DILocation(line: 105, column: 44, scope: !396)
!400 = !DILocation(line: 105, column: 36, scope: !396)
!401 = !DILocation(line: 105, column: 47, scope: !396)
!402 = !DILocation(line: 105, column: 31, scope: !396)
!403 = !DILocation(line: 105, column: 5, scope: !396)
!404 = distinct !{!404, !398, !405, !84}
!405 = !DILocation(line: 105, column: 49, scope: !392)
!406 = !DILocation(line: 106, column: 1, scope: !313)
