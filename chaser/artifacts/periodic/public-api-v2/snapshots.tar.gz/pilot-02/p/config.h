#define TASK_COUNT 6
#define MAX_JOBS 4
#define ARCHITECTURE 2
#define CHASER_CONTRACT_ID "chaser-periodic-measurement-v2"
#define CHASER_PLAN_HASH "d4177c256f81f47786617bfce169b4fca0c576a841c83a79e53154c51c91f2fd"
#define CHASER_PERIODS {10, 20, 10, 20, 10, 20}
#define CHASER_JOB_COUNTS {4, 2, 4, 2, 4, 2}
#define CHASER_CORES {0, 1, 2, 3, 0, 1}
