#define TASK_COUNT 6
#define MAX_JOBS 4
#define ARCHITECTURE 1
#define CHASER_CONTRACT_ID "chaser-periodic-measurement-v2"
#define CHASER_PLAN_HASH "dbce2c22b1801ae519174090765e4aeb3759146469a2447e675ec4591f9fe91c"
#define CHASER_PERIODS {10, 20, 10, 20, 10, 20}
#define CHASER_JOB_COUNTS {4, 2, 4, 2, 4, 2}
#define CHASER_CORES {0, 1, 2, 3, 0, 1}
