#define TASK_COUNT 6
#define MAX_JOBS 4
#define ARCHITECTURE 0
#define CHASER_CONTRACT_ID "chaser-periodic-measurement-v2"
#define CHASER_PLAN_HASH "1077d5e30c430ae78e72cb8086111ac6a30b55580b49551edd208716c2e1f033"
#define CHASER_PERIODS {10, 20, 10, 20, 10, 20}
#define CHASER_JOB_COUNTS {4, 2, 4, 2, 4, 2}
#define CHASER_CORES {0, 1, 2, 3, 0, 1}
