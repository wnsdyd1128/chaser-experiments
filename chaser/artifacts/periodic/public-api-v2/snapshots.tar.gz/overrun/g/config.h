#define TASK_COUNT 1
#define MAX_JOBS 1
#define ARCHITECTURE 0
#define CHASER_CONTRACT_ID "chaser-periodic-measurement-v2"
#define CHASER_PLAN_HASH "e19560c918389bb0d372cf551f5b15beb2c4c71f8269bf406f6696b8500a457b"
#define CHASER_PERIODS {1}
#define CHASER_JOB_COUNTS {1}
#define CHASER_CORES {0}
