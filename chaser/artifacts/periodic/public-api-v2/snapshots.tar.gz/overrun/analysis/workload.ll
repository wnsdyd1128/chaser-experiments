; ModuleID = '/workspace/experiments/chaser/.cache/periodic-public-v2-final/overrun/source/workload.c'
source_filename = "/workspace/experiments/chaser/.cache/periodic-public-v2-final/overrun/source/workload.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

@.str = private unnamed_addr constant [12 x i8] c"ape.analyze\00", section "llvm.metadata"
@.str.1 = private unnamed_addr constant [88 x i8] c"/workspace/experiments/chaser/.cache/periodic-public-v2-final/overrun/source/workload.c\00", section "llvm.metadata"
@data_overrun = dso_local global [8 x i8] zeroinitializer, section ".chaser_data.00", align 4096, !dbg !0
@workload_jobs = dso_local constant [1 x i32 ()*] [i32 ()* @task_job_overrun], align 8, !dbg !5
@workload_expected = dso_local constant [1 x i32] [i32 80000], align 4, !dbg !20
@.str.2 = private unnamed_addr constant [11 x i8] c"ape.inline\00", section "llvm.metadata"
@llvm.global.annotations = appending global [2 x { i8*, i8*, i8*, i32, i8* }] [{ i8*, i8*, i8*, i32, i8* } { i8* bitcast (i32 ()* @task_job_overrun to i8*), i8* getelementptr inbounds ([12 x i8], [12 x i8]* @.str, i32 0, i32 0), i8* getelementptr inbounds ([88 x i8], [88 x i8]* @.str.1, i32 0, i32 0), i32 18, i8* null }, { i8*, i8*, i8*, i32, i8* } { i8* bitcast (i32 ()* @kernel_overrun to i8*), i8* getelementptr inbounds ([11 x i8], [11 x i8]* @.str.2, i32 0, i32 0), i8* getelementptr inbounds ([88 x i8], [88 x i8]* @.str.1, i32 0, i32 0), i32 10, i8* null }], section "llvm.metadata"

; Function Attrs: noinline nounwind uwtable
define dso_local i32 @task_job_overrun() #0 !dbg !39 {
  %1 = alloca i32, align 4
  %2 = alloca i32, align 4
  call void @llvm.dbg.declare(metadata i32* %1, metadata !41, metadata !DIExpression()), !dbg !42
  store i32 0, i32* %1, align 4, !dbg !42
  call void @llvm.dbg.declare(metadata i32* %2, metadata !43, metadata !DIExpression()), !dbg !46
  store i32 0, i32* %2, align 4, !dbg !46
  br label %3, !dbg !47

3:                                                ; preds = %10, %0
  %4 = load i32, i32* %2, align 4, !dbg !48
  %5 = icmp slt i32 %4, 10000, !dbg !50
  br i1 %5, label %6, label %13, !dbg !51

6:                                                ; preds = %3
  %7 = call i32 @kernel_overrun(), !dbg !52
  %8 = load i32, i32* %1, align 4, !dbg !53
  %9 = add i32 %8, %7, !dbg !53
  store i32 %9, i32* %1, align 4, !dbg !53
  br label %10, !dbg !54

10:                                               ; preds = %6
  %11 = load i32, i32* %2, align 4, !dbg !55
  %12 = add nsw i32 %11, 1, !dbg !55
  store i32 %12, i32* %2, align 4, !dbg !55
  br label %3, !dbg !56, !llvm.loop !57

13:                                               ; preds = %3
  %14 = load i32, i32* %1, align 4, !dbg !60
  ret i32 %14, !dbg !61
}

; Function Attrs: nofree nosync nounwind readnone speculatable willreturn
declare void @llvm.dbg.declare(metadata, metadata, metadata) #1

; Function Attrs: noinline nounwind uwtable
define internal i32 @kernel_overrun() #0 !dbg !62 {
  %1 = alloca i32, align 4
  %2 = alloca i32, align 4
  call void @llvm.dbg.declare(metadata i32* %1, metadata !63, metadata !DIExpression()), !dbg !64
  store i32 0, i32* %1, align 4, !dbg !64
  call void @llvm.dbg.declare(metadata i32* %2, metadata !65, metadata !DIExpression()), !dbg !67
  store i32 0, i32* %2, align 4, !dbg !67
  br label %3, !dbg !68

3:                                                ; preds = %14, %0
  %4 = load i32, i32* %2, align 4, !dbg !69
  %5 = icmp slt i32 %4, 8, !dbg !71
  br i1 %5, label %6, label %17, !dbg !72

6:                                                ; preds = %3
  %7 = load i32, i32* %2, align 4, !dbg !73
  %8 = sext i32 %7 to i64, !dbg !74
  %9 = getelementptr inbounds [8 x i8], [8 x i8]* @data_overrun, i64 0, i64 %8, !dbg !74
  %10 = load volatile i8, i8* %9, align 1, !dbg !74
  %11 = zext i8 %10 to i32, !dbg !74
  %12 = load i32, i32* %1, align 4, !dbg !75
  %13 = add i32 %12, %11, !dbg !75
  store i32 %13, i32* %1, align 4, !dbg !75
  br label %14, !dbg !76

14:                                               ; preds = %6
  %15 = load i32, i32* %2, align 4, !dbg !77
  %16 = add nsw i32 %15, 1, !dbg !77
  store i32 %16, i32* %2, align 4, !dbg !77
  br label %3, !dbg !78, !llvm.loop !79

17:                                               ; preds = %3
  %18 = load i32, i32* %1, align 4, !dbg !81
  ret i32 %18, !dbg !82
}

; Function Attrs: noinline nounwind uwtable
define dso_local void @workload_prepare() #0 !dbg !83 {
  %1 = alloca i32, align 4
  call void @llvm.dbg.declare(metadata i32* %1, metadata !86, metadata !DIExpression()), !dbg !88
  store i32 0, i32* %1, align 4, !dbg !88
  br label %2, !dbg !89

2:                                                ; preds = %9, %0
  %3 = load i32, i32* %1, align 4, !dbg !90
  %4 = icmp slt i32 %3, 8, !dbg !92
  br i1 %4, label %5, label %12, !dbg !93

5:                                                ; preds = %2
  %6 = load i32, i32* %1, align 4, !dbg !94
  %7 = sext i32 %6 to i64, !dbg !95
  %8 = getelementptr inbounds [8 x i8], [8 x i8]* @data_overrun, i64 0, i64 %7, !dbg !95
  store volatile i8 1, i8* %8, align 1, !dbg !96
  br label %9, !dbg !95

9:                                                ; preds = %5
  %10 = load i32, i32* %1, align 4, !dbg !97
  %11 = add nsw i32 %10, 1, !dbg !97
  store i32 %11, i32* %1, align 4, !dbg !97
  br label %2, !dbg !98, !llvm.loop !99

12:                                               ; preds = %2
  ret void, !dbg !101
}

attributes #0 = { noinline nounwind uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { nofree nosync nounwind readnone speculatable willreturn }

!llvm.dbg.cu = !{!2}
!llvm.module.flags = !{!31, !32, !33, !34, !35, !36, !37}
!llvm.ident = !{!38}

!0 = !DIGlobalVariableExpression(var: !1, expr: !DIExpression())
!1 = distinct !DIGlobalVariable(name: "data_overrun", scope: !2, file: !7, line: 9, type: !24, isLocal: false, isDefinition: true, align: 32768)
!2 = distinct !DICompileUnit(language: DW_LANG_C99, file: !3, producer: "Ubuntu clang version 14.0.0-1ubuntu1.1", isOptimized: false, runtimeVersion: 0, emissionKind: FullDebug, globals: !4, splitDebugInlining: false, nameTableKind: None)
!3 = !DIFile(filename: "/workspace/experiments/chaser/.cache/periodic-public-v2-final/overrun/source/workload.c", directory: "/workspace/experiments/chaser/.cache/periodic-public-v2-final/overrun/analysis", checksumkind: CSK_MD5, checksum: "001ce1e327ab94b6ad1953b4e206708e")
!4 = !{!5, !20, !0}
!5 = !DIGlobalVariableExpression(var: !6, expr: !DIExpression())
!6 = distinct !DIGlobalVariable(name: "workload_jobs", scope: !2, file: !7, line: 27, type: !8, isLocal: false, isDefinition: true)
!7 = !DIFile(filename: "source/workload.c", directory: "/workspace/experiments/chaser/.cache/periodic-public-v2-final/overrun", checksumkind: CSK_MD5, checksum: "001ce1e327ab94b6ad1953b4e206708e")
!8 = !DICompositeType(tag: DW_TAG_array_type, baseType: !9, size: 64, elements: !18)
!9 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !10)
!10 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !11, size: 64)
!11 = !DISubroutineType(types: !12)
!12 = !{!13}
!13 = !DIDerivedType(tag: DW_TAG_typedef, name: "uint32_t", file: !14, line: 26, baseType: !15)
!14 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/stdint-uintn.h", directory: "", checksumkind: CSK_MD5, checksum: "2bf2ae53c58c01b1a1b9383b5195125c")
!15 = !DIDerivedType(tag: DW_TAG_typedef, name: "__uint32_t", file: !16, line: 42, baseType: !17)
!16 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/types.h", directory: "", checksumkind: CSK_MD5, checksum: "d108b5f93a74c50510d7d9bc0ab36df9")
!17 = !DIBasicType(name: "unsigned int", size: 32, encoding: DW_ATE_unsigned)
!18 = !{!19}
!19 = !DISubrange(count: 1)
!20 = !DIGlobalVariableExpression(var: !21, expr: !DIExpression())
!21 = distinct !DIGlobalVariable(name: "workload_expected", scope: !2, file: !7, line: 30, type: !22, isLocal: false, isDefinition: true)
!22 = !DICompositeType(tag: DW_TAG_array_type, baseType: !23, size: 32, elements: !18)
!23 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !13)
!24 = !DICompositeType(tag: DW_TAG_array_type, baseType: !25, size: 64, elements: !29)
!25 = !DIDerivedType(tag: DW_TAG_volatile_type, baseType: !26)
!26 = !DIDerivedType(tag: DW_TAG_typedef, name: "uint8_t", file: !14, line: 24, baseType: !27)
!27 = !DIDerivedType(tag: DW_TAG_typedef, name: "__uint8_t", file: !16, line: 38, baseType: !28)
!28 = !DIBasicType(name: "unsigned char", size: 8, encoding: DW_ATE_unsigned_char)
!29 = !{!30}
!30 = !DISubrange(count: 8)
!31 = !{i32 7, !"Dwarf Version", i32 5}
!32 = !{i32 2, !"Debug Info Version", i32 3}
!33 = !{i32 1, !"wchar_size", i32 4}
!34 = !{i32 7, !"PIC Level", i32 2}
!35 = !{i32 7, !"PIE Level", i32 2}
!36 = !{i32 7, !"uwtable", i32 1}
!37 = !{i32 7, !"frame-pointer", i32 2}
!38 = !{!"Ubuntu clang version 14.0.0-1ubuntu1.1"}
!39 = distinct !DISubprogram(name: "task_job_overrun", scope: !7, file: !7, line: 18, type: !11, scopeLine: 18, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !2, retainedNodes: !40)
!40 = !{}
!41 = !DILocalVariable(name: "sum", scope: !39, file: !7, line: 19, type: !13)
!42 = !DILocation(line: 19, column: 14, scope: !39)
!43 = !DILocalVariable(name: "s", scope: !44, file: !7, line: 20, type: !45)
!44 = distinct !DILexicalBlock(scope: !39, file: !7, line: 20, column: 5)
!45 = !DIBasicType(name: "int", size: 32, encoding: DW_ATE_signed)
!46 = !DILocation(line: 20, column: 14, scope: !44)
!47 = !DILocation(line: 20, column: 10, scope: !44)
!48 = !DILocation(line: 20, column: 21, scope: !49)
!49 = distinct !DILexicalBlock(scope: !44, file: !7, line: 20, column: 5)
!50 = !DILocation(line: 20, column: 23, scope: !49)
!51 = !DILocation(line: 20, column: 5, scope: !44)
!52 = !DILocation(line: 21, column: 16, scope: !49)
!53 = !DILocation(line: 21, column: 13, scope: !49)
!54 = !DILocation(line: 21, column: 9, scope: !49)
!55 = !DILocation(line: 20, column: 32, scope: !49)
!56 = !DILocation(line: 20, column: 5, scope: !49)
!57 = distinct !{!57, !51, !58, !59}
!58 = !DILocation(line: 21, column: 31, scope: !44)
!59 = !{!"llvm.loop.mustprogress"}
!60 = !DILocation(line: 22, column: 12, scope: !39)
!61 = !DILocation(line: 22, column: 5, scope: !39)
!62 = distinct !DISubprogram(name: "kernel_overrun", scope: !7, file: !7, line: 10, type: !11, scopeLine: 10, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition, unit: !2, retainedNodes: !40)
!63 = !DILocalVariable(name: "sum", scope: !62, file: !7, line: 11, type: !13)
!64 = !DILocation(line: 11, column: 14, scope: !62)
!65 = !DILocalVariable(name: "i", scope: !66, file: !7, line: 12, type: !45)
!66 = distinct !DILexicalBlock(scope: !62, file: !7, line: 12, column: 5)
!67 = !DILocation(line: 12, column: 14, scope: !66)
!68 = !DILocation(line: 12, column: 10, scope: !66)
!69 = !DILocation(line: 12, column: 21, scope: !70)
!70 = distinct !DILexicalBlock(scope: !66, file: !7, line: 12, column: 5)
!71 = !DILocation(line: 12, column: 23, scope: !70)
!72 = !DILocation(line: 12, column: 5, scope: !66)
!73 = !DILocation(line: 13, column: 29, scope: !70)
!74 = !DILocation(line: 13, column: 16, scope: !70)
!75 = !DILocation(line: 13, column: 13, scope: !70)
!76 = !DILocation(line: 13, column: 9, scope: !70)
!77 = !DILocation(line: 12, column: 30, scope: !70)
!78 = !DILocation(line: 12, column: 5, scope: !70)
!79 = distinct !{!79, !72, !80, !59}
!80 = !DILocation(line: 13, column: 30, scope: !66)
!81 = !DILocation(line: 14, column: 12, scope: !62)
!82 = !DILocation(line: 14, column: 5, scope: !62)
!83 = distinct !DISubprogram(name: "workload_prepare", scope: !7, file: !7, line: 24, type: !84, scopeLine: 24, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !2, retainedNodes: !40)
!84 = !DISubroutineType(types: !85)
!85 = !{null}
!86 = !DILocalVariable(name: "i", scope: !87, file: !7, line: 25, type: !45)
!87 = distinct !DILexicalBlock(scope: !83, file: !7, line: 25, column: 5)
!88 = !DILocation(line: 25, column: 14, scope: !87)
!89 = !DILocation(line: 25, column: 10, scope: !87)
!90 = !DILocation(line: 25, column: 21, scope: !91)
!91 = distinct !DILexicalBlock(scope: !87, file: !7, line: 25, column: 5)
!92 = !DILocation(line: 25, column: 23, scope: !91)
!93 = !DILocation(line: 25, column: 5, scope: !87)
!94 = !DILocation(line: 25, column: 46, scope: !91)
!95 = !DILocation(line: 25, column: 33, scope: !91)
!96 = !DILocation(line: 25, column: 49, scope: !91)
!97 = !DILocation(line: 25, column: 28, scope: !91)
!98 = !DILocation(line: 25, column: 5, scope: !91)
!99 = distinct !{!99, !93, !100, !59}
!100 = !DILocation(line: 25, column: 51, scope: !87)
!101 = !DILocation(line: 26, column: 1, scope: !83)
