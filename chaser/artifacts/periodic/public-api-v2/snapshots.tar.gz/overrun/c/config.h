#define TASK_COUNT 1
#define MAX_JOBS 1
#define ARCHITECTURE 1
#define CHASER_CONTRACT_ID "chaser-periodic-measurement-v2"
#define CHASER_PLAN_HASH "10dfb8fd834f9b70670eb66b06c15903be9193f08d06837038b92cf21b5d8312"
#define CHASER_PERIODS {1}
#define CHASER_JOB_COUNTS {1}
#define CHASER_CORES {0}
