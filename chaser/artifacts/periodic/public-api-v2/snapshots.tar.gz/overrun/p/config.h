#define TASK_COUNT 1
#define MAX_JOBS 1
#define ARCHITECTURE 2
#define CHASER_CONTRACT_ID "chaser-periodic-measurement-v2"
#define CHASER_PLAN_HASH "5625310ca4f4d0cea78a43646c3b23e5f2e94915d9b5e4295299cba8a9927e7f"
#define CHASER_PERIODS {1}
#define CHASER_JOB_COUNTS {1}
#define CHASER_CORES {0}
