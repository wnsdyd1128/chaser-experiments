#define TASK_COUNT 16
#define MAX_JOBS 4
#define ARCHITECTURE 0
#define CHASER_CONTRACT_ID "chaser-periodic-measurement-v2"
#define CHASER_PLAN_HASH "edaeca4c70b5e3b0e0aa46a8f36fe5fafd0b873dde7e42e5b1714b0fca51f4fc"
#define CHASER_PERIODS {324, 648, 1296, 648, 324, 648, 1296, 648, 324, 648, 1296, 648, 324, 648, 1296, 648}
#define CHASER_JOB_COUNTS {4, 2, 1, 2, 4, 2, 1, 2, 4, 2, 1, 2, 4, 2, 1, 2}
#define CHASER_CORES {0, 1, 2, 3, 0, 1, 2, 3, 0, 1, 2, 3, 0, 1, 2, 3}
