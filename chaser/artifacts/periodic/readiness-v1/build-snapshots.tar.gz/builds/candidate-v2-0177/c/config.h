#define TASK_COUNT 16
#define MAX_JOBS 4
#define ARCHITECTURE 1
#define CHASER_CONTRACT_ID "chaser-periodic-measurement-v2"
#define CHASER_PLAN_HASH "b3b3c245eea914cd76cea0cc8405fca1161e63b73ef38b01d6c495670b6a3950"
#define CHASER_PERIODS {324, 648, 1296, 648, 324, 648, 1296, 648, 324, 648, 1296, 648, 324, 648, 1296, 648}
#define CHASER_JOB_COUNTS {4, 2, 1, 2, 4, 2, 1, 2, 4, 2, 1, 2, 4, 2, 1, 2}
#define CHASER_CORES {0, 1, 2, 3, 0, 1, 2, 3, 0, 1, 2, 3, 0, 1, 2, 3}
