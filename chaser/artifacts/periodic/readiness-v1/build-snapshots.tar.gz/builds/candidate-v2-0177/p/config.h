#define TASK_COUNT 16
#define MAX_JOBS 4
#define ARCHITECTURE 2
#define CHASER_CONTRACT_ID "chaser-periodic-measurement-v2"
#define CHASER_PLAN_HASH "4dc93e2428854bbeb0ffbb932f7ce0df75665dbb8ecf220bf14c7c7068536f39"
#define CHASER_PERIODS {324, 648, 1296, 648, 324, 648, 1296, 648, 324, 648, 1296, 648, 324, 648, 1296, 648}
#define CHASER_JOB_COUNTS {4, 2, 1, 2, 4, 2, 1, 2, 4, 2, 1, 2, 4, 2, 1, 2}
#define CHASER_CORES {0, 1, 2, 3, 0, 1, 2, 3, 0, 1, 2, 3, 0, 1, 2, 3}
