#include "workload.h"
#ifdef __clang__
#define ANALYZE __attribute__((annotate("ape.analyze")))
#define INLINE __attribute__((annotate("ape.inline")))
#else
#define ANALYZE
#define INLINE
#endif
volatile uint8_t data_v2w0177_t00[2099200] __attribute__((aligned(4096), section(".chaser_data.00")));
INLINE static uint32_t kernel_v2w0177_t00(void) {
    uint32_t sum = 0;
    for (int b = 0; b < 1025; ++b) {
        for (int r = 0; r < 8; ++r)
            for (int c = 0; c < 8; ++c)
                sum += data_v2w0177_t00[(b * 64 + r * 8 + c) * 32];
        for (int c = 0; c < 8; ++c)
            for (int r = 0; r < 8; ++r)
                sum += data_v2w0177_t00[(b * 64 + r * 8 + c) * 32];
    }
    return sum;
}
/** @brief Execute one fixed job without resetting data or cache.
 * @return Load-count checksum, modulo 2^32. */
ANALYZE uint32_t task_job_v2w0177_t00(void) {
    uint32_t sum = 0;
    for (int s = 0; s < 2; ++s)
        sum += kernel_v2w0177_t00();
    return sum;
}
volatile uint8_t data_v2w0177_t01[2099200] __attribute__((aligned(4096), section(".chaser_data.01")));
INLINE static uint32_t kernel_v2w0177_t01(void) {
    uint32_t sum = 0;
    for (int b = 0; b < 1025; ++b) {
        for (int r = 0; r < 8; ++r)
            for (int i = 0; i < 4; ++i) {
                sum += data_v2w0177_t01[(b * 64 + r * 8 + i) * 32];
                sum += data_v2w0177_t01[(b * 64 + r * 8 + 7 - i) * 32];
            }
        for (int c = 0; c < 8; ++c)
            for (int i = 0; i < 4; ++i) {
                sum += data_v2w0177_t01[(b * 64 + i * 8 + c) * 32];
                sum += data_v2w0177_t01[(b * 64 + (7 - i) * 8 + c) * 32];
            }
    }
    return sum;
}
/** @brief Execute one fixed job without resetting data or cache.
 * @return Load-count checksum, modulo 2^32. */
ANALYZE uint32_t task_job_v2w0177_t01(void) {
    uint32_t sum = 0;
    for (int s = 0; s < 2; ++s)
        sum += kernel_v2w0177_t01();
    return sum;
}
volatile uint8_t data_v2w0177_t02[4096] __attribute__((aligned(4096), section(".chaser_data.02")));
INLINE static uint32_t kernel_v2w0177_t02(void) {
    uint32_t sum = 0;
    for (int b = 0; b < 2; ++b) {
        for (int r = 0; r < 8; ++r)
            for (int c = 0; c < 8; ++c)
                sum += data_v2w0177_t02[(b * 64 + r * 8 + c) * 32];
        for (int c = 0; c < 8; ++c)
            for (int r = 0; r < 8; ++r)
                sum += data_v2w0177_t02[(b * 64 + r * 8 + c) * 32];
    }
    return sum;
}
/** @brief Execute one fixed job without resetting data or cache.
 * @return Load-count checksum, modulo 2^32. */
ANALYZE uint32_t task_job_v2w0177_t02(void) {
    uint32_t sum = 0;
    for (int s = 0; s < 40; ++s)
        sum += kernel_v2w0177_t02();
    return sum;
}
volatile uint8_t data_v2w0177_t03[4096] __attribute__((aligned(4096), section(".chaser_data.03")));
INLINE static uint32_t kernel_v2w0177_t03(void) {
    uint32_t sum = 0;
    for (int b = 0; b < 2; ++b) {
        for (int r = 0; r < 8; ++r)
            for (int i = 0; i < 4; ++i) {
                sum += data_v2w0177_t03[(b * 64 + r * 8 + i) * 32];
                sum += data_v2w0177_t03[(b * 64 + r * 8 + 7 - i) * 32];
            }
        for (int c = 0; c < 8; ++c)
            for (int i = 0; i < 4; ++i) {
                sum += data_v2w0177_t03[(b * 64 + i * 8 + c) * 32];
                sum += data_v2w0177_t03[(b * 64 + (7 - i) * 8 + c) * 32];
            }
    }
    return sum;
}
/** @brief Execute one fixed job without resetting data or cache.
 * @return Load-count checksum, modulo 2^32. */
ANALYZE uint32_t task_job_v2w0177_t03(void) {
    uint32_t sum = 0;
    for (int s = 0; s < 40; ++s)
        sum += kernel_v2w0177_t03();
    return sum;
}
volatile uint8_t data_v2w0177_t04[4096] __attribute__((aligned(4096), section(".chaser_data.04")));
INLINE static uint32_t kernel_v2w0177_t04(void) {
    uint32_t sum = 0;
    for (int b = 0; b < 2; ++b) {
        for (int r = 0; r < 8; ++r)
            for (int c = 0; c < 8; ++c)
                sum += data_v2w0177_t04[(b * 64 + r * 8 + c) * 32];
        for (int c = 0; c < 8; ++c)
            for (int r = 0; r < 8; ++r)
                sum += data_v2w0177_t04[(b * 64 + r * 8 + c) * 32];
    }
    return sum;
}
/** @brief Execute one fixed job without resetting data or cache.
 * @return Load-count checksum, modulo 2^32. */
ANALYZE uint32_t task_job_v2w0177_t04(void) {
    uint32_t sum = 0;
    for (int s = 0; s < 40; ++s)
        sum += kernel_v2w0177_t04();
    return sum;
}
volatile uint8_t data_v2w0177_t05[4096] __attribute__((aligned(4096), section(".chaser_data.05")));
INLINE static uint32_t kernel_v2w0177_t05(void) {
    uint32_t sum = 0;
    for (int b = 0; b < 2; ++b) {
        for (int r = 0; r < 8; ++r)
            for (int i = 0; i < 4; ++i) {
                sum += data_v2w0177_t05[(b * 64 + r * 8 + i) * 32];
                sum += data_v2w0177_t05[(b * 64 + r * 8 + 7 - i) * 32];
            }
        for (int c = 0; c < 8; ++c)
            for (int i = 0; i < 4; ++i) {
                sum += data_v2w0177_t05[(b * 64 + i * 8 + c) * 32];
                sum += data_v2w0177_t05[(b * 64 + (7 - i) * 8 + c) * 32];
            }
    }
    return sum;
}
/** @brief Execute one fixed job without resetting data or cache.
 * @return Load-count checksum, modulo 2^32. */
ANALYZE uint32_t task_job_v2w0177_t05(void) {
    uint32_t sum = 0;
    for (int s = 0; s < 40; ++s)
        sum += kernel_v2w0177_t05();
    return sum;
}
volatile uint8_t data_v2w0177_t06[4096] __attribute__((aligned(4096), section(".chaser_data.06")));
INLINE static uint32_t kernel_v2w0177_t06(void) {
    uint32_t sum = 0;
    for (int b = 0; b < 2; ++b) {
        for (int r = 0; r < 8; ++r)
            for (int c = 0; c < 8; ++c)
                sum += data_v2w0177_t06[(b * 64 + r * 8 + c) * 32];
        for (int c = 0; c < 8; ++c)
            for (int r = 0; r < 8; ++r)
                sum += data_v2w0177_t06[(b * 64 + r * 8 + c) * 32];
    }
    return sum;
}
/** @brief Execute one fixed job without resetting data or cache.
 * @return Load-count checksum, modulo 2^32. */
ANALYZE uint32_t task_job_v2w0177_t06(void) {
    uint32_t sum = 0;
    for (int s = 0; s < 40; ++s)
        sum += kernel_v2w0177_t06();
    return sum;
}
volatile uint8_t data_v2w0177_t07[4096] __attribute__((aligned(4096), section(".chaser_data.07")));
INLINE static uint32_t kernel_v2w0177_t07(void) {
    uint32_t sum = 0;
    for (int b = 0; b < 2; ++b) {
        for (int r = 0; r < 8; ++r)
            for (int i = 0; i < 4; ++i) {
                sum += data_v2w0177_t07[(b * 64 + r * 8 + i) * 32];
                sum += data_v2w0177_t07[(b * 64 + r * 8 + 7 - i) * 32];
            }
        for (int c = 0; c < 8; ++c)
            for (int i = 0; i < 4; ++i) {
                sum += data_v2w0177_t07[(b * 64 + i * 8 + c) * 32];
                sum += data_v2w0177_t07[(b * 64 + (7 - i) * 8 + c) * 32];
            }
    }
    return sum;
}
/** @brief Execute one fixed job without resetting data or cache.
 * @return Load-count checksum, modulo 2^32. */
ANALYZE uint32_t task_job_v2w0177_t07(void) {
    uint32_t sum = 0;
    for (int s = 0; s < 40; ++s)
        sum += kernel_v2w0177_t07();
    return sum;
}
volatile uint8_t data_v2w0177_t08[4096] __attribute__((aligned(4096), section(".chaser_data.08")));
INLINE static uint32_t kernel_v2w0177_t08(void) {
    uint32_t sum = 0;
    for (int b = 0; b < 2; ++b) {
        for (int r = 0; r < 8; ++r)
            for (int c = 0; c < 8; ++c)
                sum += data_v2w0177_t08[(b * 64 + r * 8 + c) * 32];
        for (int c = 0; c < 8; ++c)
            for (int r = 0; r < 8; ++r)
                sum += data_v2w0177_t08[(b * 64 + r * 8 + c) * 32];
    }
    return sum;
}
/** @brief Execute one fixed job without resetting data or cache.
 * @return Load-count checksum, modulo 2^32. */
ANALYZE uint32_t task_job_v2w0177_t08(void) {
    uint32_t sum = 0;
    for (int s = 0; s < 40; ++s)
        sum += kernel_v2w0177_t08();
    return sum;
}
volatile uint8_t data_v2w0177_t09[4096] __attribute__((aligned(4096), section(".chaser_data.09")));
INLINE static uint32_t kernel_v2w0177_t09(void) {
    uint32_t sum = 0;
    for (int b = 0; b < 2; ++b) {
        for (int r = 0; r < 8; ++r)
            for (int i = 0; i < 4; ++i) {
                sum += data_v2w0177_t09[(b * 64 + r * 8 + i) * 32];
                sum += data_v2w0177_t09[(b * 64 + r * 8 + 7 - i) * 32];
            }
        for (int c = 0; c < 8; ++c)
            for (int i = 0; i < 4; ++i) {
                sum += data_v2w0177_t09[(b * 64 + i * 8 + c) * 32];
                sum += data_v2w0177_t09[(b * 64 + (7 - i) * 8 + c) * 32];
            }
    }
    return sum;
}
/** @brief Execute one fixed job without resetting data or cache.
 * @return Load-count checksum, modulo 2^32. */
ANALYZE uint32_t task_job_v2w0177_t09(void) {
    uint32_t sum = 0;
    for (int s = 0; s < 40; ++s)
        sum += kernel_v2w0177_t09();
    return sum;
}
volatile uint8_t data_v2w0177_t10[4096] __attribute__((aligned(4096), section(".chaser_data.10")));
INLINE static uint32_t kernel_v2w0177_t10(void) {
    uint32_t sum = 0;
    for (int b = 0; b < 2; ++b) {
        for (int r = 0; r < 8; ++r)
            for (int c = 0; c < 8; ++c)
                sum += data_v2w0177_t10[(b * 64 + r * 8 + c) * 32];
        for (int c = 0; c < 8; ++c)
            for (int r = 0; r < 8; ++r)
                sum += data_v2w0177_t10[(b * 64 + r * 8 + c) * 32];
    }
    return sum;
}
/** @brief Execute one fixed job without resetting data or cache.
 * @return Load-count checksum, modulo 2^32. */
ANALYZE uint32_t task_job_v2w0177_t10(void) {
    uint32_t sum = 0;
    for (int s = 0; s < 40; ++s)
        sum += kernel_v2w0177_t10();
    return sum;
}
volatile uint8_t data_v2w0177_t11[4096] __attribute__((aligned(4096), section(".chaser_data.11")));
INLINE static uint32_t kernel_v2w0177_t11(void) {
    uint32_t sum = 0;
    for (int b = 0; b < 2; ++b) {
        for (int r = 0; r < 8; ++r)
            for (int i = 0; i < 4; ++i) {
                sum += data_v2w0177_t11[(b * 64 + r * 8 + i) * 32];
                sum += data_v2w0177_t11[(b * 64 + r * 8 + 7 - i) * 32];
            }
        for (int c = 0; c < 8; ++c)
            for (int i = 0; i < 4; ++i) {
                sum += data_v2w0177_t11[(b * 64 + i * 8 + c) * 32];
                sum += data_v2w0177_t11[(b * 64 + (7 - i) * 8 + c) * 32];
            }
    }
    return sum;
}
/** @brief Execute one fixed job without resetting data or cache.
 * @return Load-count checksum, modulo 2^32. */
ANALYZE uint32_t task_job_v2w0177_t11(void) {
    uint32_t sum = 0;
    for (int s = 0; s < 40; ++s)
        sum += kernel_v2w0177_t11();
    return sum;
}
volatile uint8_t data_v2w0177_t12[4096] __attribute__((aligned(4096), section(".chaser_data.12")));
INLINE static uint32_t kernel_v2w0177_t12(void) {
    uint32_t sum = 0;
    for (int b = 0; b < 2; ++b) {
        for (int r = 0; r < 8; ++r)
            for (int c = 0; c < 8; ++c)
                sum += data_v2w0177_t12[(b * 64 + r * 8 + c) * 32];
        for (int c = 0; c < 8; ++c)
            for (int r = 0; r < 8; ++r)
                sum += data_v2w0177_t12[(b * 64 + r * 8 + c) * 32];
    }
    return sum;
}
/** @brief Execute one fixed job without resetting data or cache.
 * @return Load-count checksum, modulo 2^32. */
ANALYZE uint32_t task_job_v2w0177_t12(void) {
    uint32_t sum = 0;
    for (int s = 0; s < 40; ++s)
        sum += kernel_v2w0177_t12();
    return sum;
}
volatile uint8_t data_v2w0177_t13[4096] __attribute__((aligned(4096), section(".chaser_data.13")));
INLINE static uint32_t kernel_v2w0177_t13(void) {
    uint32_t sum = 0;
    for (int b = 0; b < 2; ++b) {
        for (int r = 0; r < 8; ++r)
            for (int i = 0; i < 4; ++i) {
                sum += data_v2w0177_t13[(b * 64 + r * 8 + i) * 32];
                sum += data_v2w0177_t13[(b * 64 + r * 8 + 7 - i) * 32];
            }
        for (int c = 0; c < 8; ++c)
            for (int i = 0; i < 4; ++i) {
                sum += data_v2w0177_t13[(b * 64 + i * 8 + c) * 32];
                sum += data_v2w0177_t13[(b * 64 + (7 - i) * 8 + c) * 32];
            }
    }
    return sum;
}
/** @brief Execute one fixed job without resetting data or cache.
 * @return Load-count checksum, modulo 2^32. */
ANALYZE uint32_t task_job_v2w0177_t13(void) {
    uint32_t sum = 0;
    for (int s = 0; s < 40; ++s)
        sum += kernel_v2w0177_t13();
    return sum;
}
volatile uint8_t data_v2w0177_t14[4096] __attribute__((aligned(4096), section(".chaser_data.14")));
INLINE static uint32_t kernel_v2w0177_t14(void) {
    uint32_t sum = 0;
    for (int b = 0; b < 2; ++b) {
        for (int r = 0; r < 8; ++r)
            for (int c = 0; c < 8; ++c)
                sum += data_v2w0177_t14[(b * 64 + r * 8 + c) * 32];
        for (int c = 0; c < 8; ++c)
            for (int r = 0; r < 8; ++r)
                sum += data_v2w0177_t14[(b * 64 + r * 8 + c) * 32];
    }
    return sum;
}
/** @brief Execute one fixed job without resetting data or cache.
 * @return Load-count checksum, modulo 2^32. */
ANALYZE uint32_t task_job_v2w0177_t14(void) {
    uint32_t sum = 0;
    for (int s = 0; s < 40; ++s)
        sum += kernel_v2w0177_t14();
    return sum;
}
volatile uint8_t data_v2w0177_t15[4096] __attribute__((aligned(4096), section(".chaser_data.15")));
INLINE static uint32_t kernel_v2w0177_t15(void) {
    uint32_t sum = 0;
    for (int b = 0; b < 2; ++b) {
        for (int r = 0; r < 8; ++r)
            for (int i = 0; i < 4; ++i) {
                sum += data_v2w0177_t15[(b * 64 + r * 8 + i) * 32];
                sum += data_v2w0177_t15[(b * 64 + r * 8 + 7 - i) * 32];
            }
        for (int c = 0; c < 8; ++c)
            for (int i = 0; i < 4; ++i) {
                sum += data_v2w0177_t15[(b * 64 + i * 8 + c) * 32];
                sum += data_v2w0177_t15[(b * 64 + (7 - i) * 8 + c) * 32];
            }
    }
    return sum;
}
/** @brief Execute one fixed job without resetting data or cache.
 * @return Load-count checksum, modulo 2^32. */
ANALYZE uint32_t task_job_v2w0177_t15(void) {
    uint32_t sum = 0;
    for (int s = 0; s < 40; ++s)
        sum += kernel_v2w0177_t15();
    return sum;
}
void workload_prepare(void) {
    for (int i = 0; i < 2099200; ++i) data_v2w0177_t00[i] = 1;
    for (int i = 0; i < 2099200; ++i) data_v2w0177_t01[i] = 1;
    for (int i = 0; i < 4096; ++i) data_v2w0177_t02[i] = 1;
    for (int i = 0; i < 4096; ++i) data_v2w0177_t03[i] = 1;
    for (int i = 0; i < 4096; ++i) data_v2w0177_t04[i] = 1;
    for (int i = 0; i < 4096; ++i) data_v2w0177_t05[i] = 1;
    for (int i = 0; i < 4096; ++i) data_v2w0177_t06[i] = 1;
    for (int i = 0; i < 4096; ++i) data_v2w0177_t07[i] = 1;
    for (int i = 0; i < 4096; ++i) data_v2w0177_t08[i] = 1;
    for (int i = 0; i < 4096; ++i) data_v2w0177_t09[i] = 1;
    for (int i = 0; i < 4096; ++i) data_v2w0177_t10[i] = 1;
    for (int i = 0; i < 4096; ++i) data_v2w0177_t11[i] = 1;
    for (int i = 0; i < 4096; ++i) data_v2w0177_t12[i] = 1;
    for (int i = 0; i < 4096; ++i) data_v2w0177_t13[i] = 1;
    for (int i = 0; i < 4096; ++i) data_v2w0177_t14[i] = 1;
    for (int i = 0; i < 4096; ++i) data_v2w0177_t15[i] = 1;
}
uint32_t (*const workload_jobs[])(void) = {
    task_job_v2w0177_t00,
    task_job_v2w0177_t01,
    task_job_v2w0177_t02,
    task_job_v2w0177_t03,
    task_job_v2w0177_t04,
    task_job_v2w0177_t05,
    task_job_v2w0177_t06,
    task_job_v2w0177_t07,
    task_job_v2w0177_t08,
    task_job_v2w0177_t09,
    task_job_v2w0177_t10,
    task_job_v2w0177_t11,
    task_job_v2w0177_t12,
    task_job_v2w0177_t13,
    task_job_v2w0177_t14,
    task_job_v2w0177_t15,
};
const uint32_t workload_expected[] = {
262400U, 262400U, 10240U, 10240U, 10240U, 10240U, 10240U, 10240U, 10240U, 10240U, 10240U, 10240U, 10240U, 10240U, 10240U, 10240U
};
