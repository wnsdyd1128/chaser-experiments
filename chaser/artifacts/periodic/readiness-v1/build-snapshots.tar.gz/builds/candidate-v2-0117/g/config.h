#define TASK_COUNT 16
#define MAX_JOBS 4
#define ARCHITECTURE 0
#define CHASER_CONTRACT_ID "chaser-periodic-measurement-v2"
#define CHASER_PLAN_HASH "2f89688bb3001ca2078a12a2bd88d8bbafc8e7fbea987b9107ed08fba762339b"
#define CHASER_PERIODS {648, 1296, 2592, 1296, 648, 1296, 2592, 1296, 648, 1296, 2592, 1296, 648, 1296, 2592, 1296}
#define CHASER_JOB_COUNTS {4, 2, 1, 2, 4, 2, 1, 2, 4, 2, 1, 2, 4, 2, 1, 2}
#define CHASER_CORES {0, 1, 2, 3, 0, 1, 2, 3, 0, 1, 2, 3, 0, 1, 2, 3}
