#include "workload.h"
#ifdef __clang__
#define ANALYZE __attribute__((annotate("ape.analyze")))
#define INLINE __attribute__((annotate("ape.inline")))
#else
#define ANALYZE
#define INLINE
#endif
volatile uint8_t data_v2w0117_t00[2097664] __attribute__((aligned(4096), section(".chaser_data.00")));
INLINE static uint32_t kernel_v2w0117_t00(void) {
    uint32_t sum = 0;
    for (int b = 0; b < 4097; ++b) {
        for (int r = 0; r < 2; ++r)
            for (int i = 0; i < 8; ++i)
                sum += data_v2w0117_t00[(b * 16 + 0 + i) * 32];
        for (int r = 0; r < 2; ++r)
            for (int i = 0; i < 8; ++i)
                sum += data_v2w0117_t00[(b * 16 + 8 + i) * 32];
        for (int i = 0; i < 8; ++i) {
            sum += data_v2w0117_t00[(b * 16 + i) * 32];
            sum += data_v2w0117_t00[(b * 16 + 8 + i) * 32];
        }
    }
    return sum;
}
/** @brief Execute one fixed job without resetting data or cache.
 * @return Load-count checksum, modulo 2^32. */
ANALYZE uint32_t task_job_v2w0117_t00(void) {
    uint32_t sum = 0;
    for (int s = 0; s < 2; ++s)
        sum += kernel_v2w0117_t00();
    return sum;
}
volatile uint8_t data_v2w0117_t01[2101248] __attribute__((aligned(4096), section(".chaser_data.01")));
INLINE static uint32_t kernel_v2w0117_t01(void) {
    uint32_t sum = 0;
    for (int b = 0; b < 513; ++b) {
        for (int c = 0; c < 8; ++c)
            for (int r = 0; r < 8; ++r)
                for (int i = 0; i < 8; ++i) {
                    sum += data_v2w0117_t01[(b * 128 + r * 8 + i) * 32];
                    sum += data_v2w0117_t01[(b * 128 + 64 + c * 8 + i) * 32];
                }
    }
    return sum;
}
/** @brief Execute one fixed job without resetting data or cache.
 * @return Load-count checksum, modulo 2^32. */
ANALYZE uint32_t task_job_v2w0117_t01(void) {
    uint32_t sum = 0;
    for (int s = 0; s < 2; ++s)
        sum += kernel_v2w0117_t01();
    return sum;
}
volatile uint8_t data_v2w0117_t02[1024] __attribute__((aligned(4096), section(".chaser_data.02")));
INLINE static uint32_t kernel_v2w0117_t02(void) {
    uint32_t sum = 0;
    for (int b = 0; b < 2; ++b) {
        for (int r = 0; r < 2; ++r)
            for (int i = 0; i < 8; ++i)
                sum += data_v2w0117_t02[(b * 16 + 0 + i) * 32];
        for (int r = 0; r < 2; ++r)
            for (int i = 0; i < 8; ++i)
                sum += data_v2w0117_t02[(b * 16 + 8 + i) * 32];
        for (int i = 0; i < 8; ++i) {
            sum += data_v2w0117_t02[(b * 16 + i) * 32];
            sum += data_v2w0117_t02[(b * 16 + 8 + i) * 32];
        }
    }
    return sum;
}
/** @brief Execute one fixed job without resetting data or cache.
 * @return Load-count checksum, modulo 2^32. */
ANALYZE uint32_t task_job_v2w0117_t02(void) {
    uint32_t sum = 0;
    for (int s = 0; s < 107; ++s)
        sum += kernel_v2w0117_t02();
    return sum;
}
volatile uint8_t data_v2w0117_t03[8192] __attribute__((aligned(4096), section(".chaser_data.03")));
INLINE static uint32_t kernel_v2w0117_t03(void) {
    uint32_t sum = 0;
    for (int b = 0; b < 2; ++b) {
        for (int c = 0; c < 8; ++c)
            for (int r = 0; r < 8; ++r)
                for (int i = 0; i < 8; ++i) {
                    sum += data_v2w0117_t03[(b * 128 + r * 8 + i) * 32];
                    sum += data_v2w0117_t03[(b * 128 + 64 + c * 8 + i) * 32];
                }
    }
    return sum;
}
/** @brief Execute one fixed job without resetting data or cache.
 * @return Load-count checksum, modulo 2^32. */
ANALYZE uint32_t task_job_v2w0117_t03(void) {
    uint32_t sum = 0;
    for (int s = 0; s < 5; ++s)
        sum += kernel_v2w0117_t03();
    return sum;
}
volatile uint8_t data_v2w0117_t04[1024] __attribute__((aligned(4096), section(".chaser_data.04")));
INLINE static uint32_t kernel_v2w0117_t04(void) {
    uint32_t sum = 0;
    for (int b = 0; b < 2; ++b) {
        for (int r = 0; r < 2; ++r)
            for (int i = 0; i < 8; ++i)
                sum += data_v2w0117_t04[(b * 16 + 0 + i) * 32];
        for (int r = 0; r < 2; ++r)
            for (int i = 0; i < 8; ++i)
                sum += data_v2w0117_t04[(b * 16 + 8 + i) * 32];
        for (int i = 0; i < 8; ++i) {
            sum += data_v2w0117_t04[(b * 16 + i) * 32];
            sum += data_v2w0117_t04[(b * 16 + 8 + i) * 32];
        }
    }
    return sum;
}
/** @brief Execute one fixed job without resetting data or cache.
 * @return Load-count checksum, modulo 2^32. */
ANALYZE uint32_t task_job_v2w0117_t04(void) {
    uint32_t sum = 0;
    for (int s = 0; s < 107; ++s)
        sum += kernel_v2w0117_t04();
    return sum;
}
volatile uint8_t data_v2w0117_t05[8192] __attribute__((aligned(4096), section(".chaser_data.05")));
INLINE static uint32_t kernel_v2w0117_t05(void) {
    uint32_t sum = 0;
    for (int b = 0; b < 2; ++b) {
        for (int c = 0; c < 8; ++c)
            for (int r = 0; r < 8; ++r)
                for (int i = 0; i < 8; ++i) {
                    sum += data_v2w0117_t05[(b * 128 + r * 8 + i) * 32];
                    sum += data_v2w0117_t05[(b * 128 + 64 + c * 8 + i) * 32];
                }
    }
    return sum;
}
/** @brief Execute one fixed job without resetting data or cache.
 * @return Load-count checksum, modulo 2^32. */
ANALYZE uint32_t task_job_v2w0117_t05(void) {
    uint32_t sum = 0;
    for (int s = 0; s < 5; ++s)
        sum += kernel_v2w0117_t05();
    return sum;
}
volatile uint8_t data_v2w0117_t06[1024] __attribute__((aligned(4096), section(".chaser_data.06")));
INLINE static uint32_t kernel_v2w0117_t06(void) {
    uint32_t sum = 0;
    for (int b = 0; b < 2; ++b) {
        for (int r = 0; r < 2; ++r)
            for (int i = 0; i < 8; ++i)
                sum += data_v2w0117_t06[(b * 16 + 0 + i) * 32];
        for (int r = 0; r < 2; ++r)
            for (int i = 0; i < 8; ++i)
                sum += data_v2w0117_t06[(b * 16 + 8 + i) * 32];
        for (int i = 0; i < 8; ++i) {
            sum += data_v2w0117_t06[(b * 16 + i) * 32];
            sum += data_v2w0117_t06[(b * 16 + 8 + i) * 32];
        }
    }
    return sum;
}
/** @brief Execute one fixed job without resetting data or cache.
 * @return Load-count checksum, modulo 2^32. */
ANALYZE uint32_t task_job_v2w0117_t06(void) {
    uint32_t sum = 0;
    for (int s = 0; s < 107; ++s)
        sum += kernel_v2w0117_t06();
    return sum;
}
volatile uint8_t data_v2w0117_t07[8192] __attribute__((aligned(4096), section(".chaser_data.07")));
INLINE static uint32_t kernel_v2w0117_t07(void) {
    uint32_t sum = 0;
    for (int b = 0; b < 2; ++b) {
        for (int c = 0; c < 8; ++c)
            for (int r = 0; r < 8; ++r)
                for (int i = 0; i < 8; ++i) {
                    sum += data_v2w0117_t07[(b * 128 + r * 8 + i) * 32];
                    sum += data_v2w0117_t07[(b * 128 + 64 + c * 8 + i) * 32];
                }
    }
    return sum;
}
/** @brief Execute one fixed job without resetting data or cache.
 * @return Load-count checksum, modulo 2^32. */
ANALYZE uint32_t task_job_v2w0117_t07(void) {
    uint32_t sum = 0;
    for (int s = 0; s < 5; ++s)
        sum += kernel_v2w0117_t07();
    return sum;
}
volatile uint8_t data_v2w0117_t08[1024] __attribute__((aligned(4096), section(".chaser_data.08")));
INLINE static uint32_t kernel_v2w0117_t08(void) {
    uint32_t sum = 0;
    for (int b = 0; b < 2; ++b) {
        for (int r = 0; r < 2; ++r)
            for (int i = 0; i < 8; ++i)
                sum += data_v2w0117_t08[(b * 16 + 0 + i) * 32];
        for (int r = 0; r < 2; ++r)
            for (int i = 0; i < 8; ++i)
                sum += data_v2w0117_t08[(b * 16 + 8 + i) * 32];
        for (int i = 0; i < 8; ++i) {
            sum += data_v2w0117_t08[(b * 16 + i) * 32];
            sum += data_v2w0117_t08[(b * 16 + 8 + i) * 32];
        }
    }
    return sum;
}
/** @brief Execute one fixed job without resetting data or cache.
 * @return Load-count checksum, modulo 2^32. */
ANALYZE uint32_t task_job_v2w0117_t08(void) {
    uint32_t sum = 0;
    for (int s = 0; s < 107; ++s)
        sum += kernel_v2w0117_t08();
    return sum;
}
volatile uint8_t data_v2w0117_t09[8192] __attribute__((aligned(4096), section(".chaser_data.09")));
INLINE static uint32_t kernel_v2w0117_t09(void) {
    uint32_t sum = 0;
    for (int b = 0; b < 2; ++b) {
        for (int c = 0; c < 8; ++c)
            for (int r = 0; r < 8; ++r)
                for (int i = 0; i < 8; ++i) {
                    sum += data_v2w0117_t09[(b * 128 + r * 8 + i) * 32];
                    sum += data_v2w0117_t09[(b * 128 + 64 + c * 8 + i) * 32];
                }
    }
    return sum;
}
/** @brief Execute one fixed job without resetting data or cache.
 * @return Load-count checksum, modulo 2^32. */
ANALYZE uint32_t task_job_v2w0117_t09(void) {
    uint32_t sum = 0;
    for (int s = 0; s < 5; ++s)
        sum += kernel_v2w0117_t09();
    return sum;
}
volatile uint8_t data_v2w0117_t10[1024] __attribute__((aligned(4096), section(".chaser_data.10")));
INLINE static uint32_t kernel_v2w0117_t10(void) {
    uint32_t sum = 0;
    for (int b = 0; b < 2; ++b) {
        for (int r = 0; r < 2; ++r)
            for (int i = 0; i < 8; ++i)
                sum += data_v2w0117_t10[(b * 16 + 0 + i) * 32];
        for (int r = 0; r < 2; ++r)
            for (int i = 0; i < 8; ++i)
                sum += data_v2w0117_t10[(b * 16 + 8 + i) * 32];
        for (int i = 0; i < 8; ++i) {
            sum += data_v2w0117_t10[(b * 16 + i) * 32];
            sum += data_v2w0117_t10[(b * 16 + 8 + i) * 32];
        }
    }
    return sum;
}
/** @brief Execute one fixed job without resetting data or cache.
 * @return Load-count checksum, modulo 2^32. */
ANALYZE uint32_t task_job_v2w0117_t10(void) {
    uint32_t sum = 0;
    for (int s = 0; s < 107; ++s)
        sum += kernel_v2w0117_t10();
    return sum;
}
volatile uint8_t data_v2w0117_t11[8192] __attribute__((aligned(4096), section(".chaser_data.11")));
INLINE static uint32_t kernel_v2w0117_t11(void) {
    uint32_t sum = 0;
    for (int b = 0; b < 2; ++b) {
        for (int c = 0; c < 8; ++c)
            for (int r = 0; r < 8; ++r)
                for (int i = 0; i < 8; ++i) {
                    sum += data_v2w0117_t11[(b * 128 + r * 8 + i) * 32];
                    sum += data_v2w0117_t11[(b * 128 + 64 + c * 8 + i) * 32];
                }
    }
    return sum;
}
/** @brief Execute one fixed job without resetting data or cache.
 * @return Load-count checksum, modulo 2^32. */
ANALYZE uint32_t task_job_v2w0117_t11(void) {
    uint32_t sum = 0;
    for (int s = 0; s < 5; ++s)
        sum += kernel_v2w0117_t11();
    return sum;
}
volatile uint8_t data_v2w0117_t12[1024] __attribute__((aligned(4096), section(".chaser_data.12")));
INLINE static uint32_t kernel_v2w0117_t12(void) {
    uint32_t sum = 0;
    for (int b = 0; b < 2; ++b) {
        for (int r = 0; r < 2; ++r)
            for (int i = 0; i < 8; ++i)
                sum += data_v2w0117_t12[(b * 16 + 0 + i) * 32];
        for (int r = 0; r < 2; ++r)
            for (int i = 0; i < 8; ++i)
                sum += data_v2w0117_t12[(b * 16 + 8 + i) * 32];
        for (int i = 0; i < 8; ++i) {
            sum += data_v2w0117_t12[(b * 16 + i) * 32];
            sum += data_v2w0117_t12[(b * 16 + 8 + i) * 32];
        }
    }
    return sum;
}
/** @brief Execute one fixed job without resetting data or cache.
 * @return Load-count checksum, modulo 2^32. */
ANALYZE uint32_t task_job_v2w0117_t12(void) {
    uint32_t sum = 0;
    for (int s = 0; s < 107; ++s)
        sum += kernel_v2w0117_t12();
    return sum;
}
volatile uint8_t data_v2w0117_t13[8192] __attribute__((aligned(4096), section(".chaser_data.13")));
INLINE static uint32_t kernel_v2w0117_t13(void) {
    uint32_t sum = 0;
    for (int b = 0; b < 2; ++b) {
        for (int c = 0; c < 8; ++c)
            for (int r = 0; r < 8; ++r)
                for (int i = 0; i < 8; ++i) {
                    sum += data_v2w0117_t13[(b * 128 + r * 8 + i) * 32];
                    sum += data_v2w0117_t13[(b * 128 + 64 + c * 8 + i) * 32];
                }
    }
    return sum;
}
/** @brief Execute one fixed job without resetting data or cache.
 * @return Load-count checksum, modulo 2^32. */
ANALYZE uint32_t task_job_v2w0117_t13(void) {
    uint32_t sum = 0;
    for (int s = 0; s < 5; ++s)
        sum += kernel_v2w0117_t13();
    return sum;
}
volatile uint8_t data_v2w0117_t14[1024] __attribute__((aligned(4096), section(".chaser_data.14")));
INLINE static uint32_t kernel_v2w0117_t14(void) {
    uint32_t sum = 0;
    for (int b = 0; b < 2; ++b) {
        for (int r = 0; r < 2; ++r)
            for (int i = 0; i < 8; ++i)
                sum += data_v2w0117_t14[(b * 16 + 0 + i) * 32];
        for (int r = 0; r < 2; ++r)
            for (int i = 0; i < 8; ++i)
                sum += data_v2w0117_t14[(b * 16 + 8 + i) * 32];
        for (int i = 0; i < 8; ++i) {
            sum += data_v2w0117_t14[(b * 16 + i) * 32];
            sum += data_v2w0117_t14[(b * 16 + 8 + i) * 32];
        }
    }
    return sum;
}
/** @brief Execute one fixed job without resetting data or cache.
 * @return Load-count checksum, modulo 2^32. */
ANALYZE uint32_t task_job_v2w0117_t14(void) {
    uint32_t sum = 0;
    for (int s = 0; s < 107; ++s)
        sum += kernel_v2w0117_t14();
    return sum;
}
volatile uint8_t data_v2w0117_t15[8192] __attribute__((aligned(4096), section(".chaser_data.15")));
INLINE static uint32_t kernel_v2w0117_t15(void) {
    uint32_t sum = 0;
    for (int b = 0; b < 2; ++b) {
        for (int c = 0; c < 8; ++c)
            for (int r = 0; r < 8; ++r)
                for (int i = 0; i < 8; ++i) {
                    sum += data_v2w0117_t15[(b * 128 + r * 8 + i) * 32];
                    sum += data_v2w0117_t15[(b * 128 + 64 + c * 8 + i) * 32];
                }
    }
    return sum;
}
/** @brief Execute one fixed job without resetting data or cache.
 * @return Load-count checksum, modulo 2^32. */
ANALYZE uint32_t task_job_v2w0117_t15(void) {
    uint32_t sum = 0;
    for (int s = 0; s < 5; ++s)
        sum += kernel_v2w0117_t15();
    return sum;
}
void workload_prepare(void) {
    for (int i = 0; i < 2097664; ++i) data_v2w0117_t00[i] = 1;
    for (int i = 0; i < 2101248; ++i) data_v2w0117_t01[i] = 1;
    for (int i = 0; i < 1024; ++i) data_v2w0117_t02[i] = 1;
    for (int i = 0; i < 8192; ++i) data_v2w0117_t03[i] = 1;
    for (int i = 0; i < 1024; ++i) data_v2w0117_t04[i] = 1;
    for (int i = 0; i < 8192; ++i) data_v2w0117_t05[i] = 1;
    for (int i = 0; i < 1024; ++i) data_v2w0117_t06[i] = 1;
    for (int i = 0; i < 8192; ++i) data_v2w0117_t07[i] = 1;
    for (int i = 0; i < 1024; ++i) data_v2w0117_t08[i] = 1;
    for (int i = 0; i < 8192; ++i) data_v2w0117_t09[i] = 1;
    for (int i = 0; i < 1024; ++i) data_v2w0117_t10[i] = 1;
    for (int i = 0; i < 8192; ++i) data_v2w0117_t11[i] = 1;
    for (int i = 0; i < 1024; ++i) data_v2w0117_t12[i] = 1;
    for (int i = 0; i < 8192; ++i) data_v2w0117_t13[i] = 1;
    for (int i = 0; i < 1024; ++i) data_v2w0117_t14[i] = 1;
    for (int i = 0; i < 8192; ++i) data_v2w0117_t15[i] = 1;
}
uint32_t (*const workload_jobs[])(void) = {
    task_job_v2w0117_t00,
    task_job_v2w0117_t01,
    task_job_v2w0117_t02,
    task_job_v2w0117_t03,
    task_job_v2w0117_t04,
    task_job_v2w0117_t05,
    task_job_v2w0117_t06,
    task_job_v2w0117_t07,
    task_job_v2w0117_t08,
    task_job_v2w0117_t09,
    task_job_v2w0117_t10,
    task_job_v2w0117_t11,
    task_job_v2w0117_t12,
    task_job_v2w0117_t13,
    task_job_v2w0117_t14,
    task_job_v2w0117_t15,
};
const uint32_t workload_expected[] = {
393312U, 1050624U, 10272U, 10240U, 10272U, 10240U, 10272U, 10240U, 10272U, 10240U, 10272U, 10240U, 10272U, 10240U, 10272U, 10240U
};
