#define TASK_COUNT 16
#define MAX_JOBS 4
#define ARCHITECTURE 1
#define CHASER_CONTRACT_ID "chaser-periodic-measurement-v2"
#define CHASER_PLAN_HASH "5ee0ac948ae753525ccc7306ed219227b2eeefbe7c0c9fe960403bae5347f959"
#define CHASER_PERIODS {648, 1296, 2592, 1296, 648, 1296, 2592, 1296, 648, 1296, 2592, 1296, 648, 1296, 2592, 1296}
#define CHASER_JOB_COUNTS {4, 2, 1, 2, 4, 2, 1, 2, 4, 2, 1, 2, 4, 2, 1, 2}
#define CHASER_CORES {0, 1, 2, 3, 0, 1, 2, 3, 0, 1, 2, 3, 0, 1, 2, 3}
