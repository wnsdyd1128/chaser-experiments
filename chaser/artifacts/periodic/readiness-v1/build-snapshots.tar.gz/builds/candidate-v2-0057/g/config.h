#define TASK_COUNT 16
#define MAX_JOBS 4
#define ARCHITECTURE 0
#define CHASER_CONTRACT_ID "chaser-periodic-measurement-v2"
#define CHASER_PLAN_HASH "d3ac74b945ea33ff4ba0d595976bd44497c87620f1298520e0376e2177c2e34c"
#define CHASER_PERIODS {969, 1938, 3876, 1938, 969, 1938, 3876, 1938, 969, 1938, 3876, 1938, 969, 1938, 3876, 1938}
#define CHASER_JOB_COUNTS {4, 2, 1, 2, 4, 2, 1, 2, 4, 2, 1, 2, 4, 2, 1, 2}
#define CHASER_CORES {0, 1, 2, 3, 0, 1, 2, 3, 0, 1, 2, 3, 0, 1, 2, 3}
