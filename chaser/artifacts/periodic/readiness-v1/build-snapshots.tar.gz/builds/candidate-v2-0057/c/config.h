#define TASK_COUNT 16
#define MAX_JOBS 4
#define ARCHITECTURE 1
#define CHASER_CONTRACT_ID "chaser-periodic-measurement-v2"
#define CHASER_PLAN_HASH "6a1b19dfd2d5096a8440fb779096e0608aabbd9cb8a88c9aea8fcd2f9d24ef2a"
#define CHASER_PERIODS {969, 1938, 3876, 1938, 969, 1938, 3876, 1938, 969, 1938, 3876, 1938, 969, 1938, 3876, 1938}
#define CHASER_JOB_COUNTS {4, 2, 1, 2, 4, 2, 1, 2, 4, 2, 1, 2, 4, 2, 1, 2}
#define CHASER_CORES {0, 1, 2, 3, 0, 1, 2, 3, 0, 1, 2, 3, 0, 1, 2, 3}
