#define TASK_COUNT 16
#define MAX_JOBS 4
#define ARCHITECTURE 2
#define CHASER_CONTRACT_ID "chaser-periodic-measurement-v2"
#define CHASER_PLAN_HASH "a46c541547f38f87c68387ff2afafeb7cb6f9c26ae78fc09f02ac516151771d5"
#define CHASER_PERIODS {969, 1938, 3876, 1938, 969, 1938, 3876, 1938, 969, 1938, 3876, 1938, 969, 1938, 3876, 1938}
#define CHASER_JOB_COUNTS {4, 2, 1, 2, 4, 2, 1, 2, 4, 2, 1, 2, 4, 2, 1, 2}
#define CHASER_CORES {0, 1, 2, 3, 0, 1, 2, 3, 0, 1, 2, 3, 0, 1, 2, 3}
