; ModuleID = 'workload.ll'
source_filename = "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/affine-bounds-20260929/suite/adi/source/workload.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

%struct._IO_FILE = type { i32, i8*, i8*, i8*, i8*, i8*, i8*, i8*, i8*, i8*, i8*, i8*, %struct._IO_marker*, %struct._IO_FILE*, i32, i32, i64, i16, i8, [1 x i8], i8*, i64, %struct._IO_codecvt*, %struct._IO_wide_data*, %struct._IO_FILE*, i8*, i64, i32, [20 x i8] }
%struct._IO_marker = type opaque
%struct._IO_codecvt = type opaque
%struct._IO_wide_data = type opaque
%struct.__va_list_tag = type { i32, i32, i8*, i8* }

@n = dso_local global i32 200, align 4, !dbg !0
@tsteps = dso_local global i32 100, align 4, !dbg !9
@u = dso_local global [200 x [200 x double]] zeroinitializer, section ".chaser_data.u", align 64, !dbg !33
@v = dso_local global [200 x [200 x double]] zeroinitializer, section ".chaser_data.v", align 64, !dbg !38
@p = dso_local global [200 x [200 x double]] zeroinitializer, section ".chaser_data.p", align 64, !dbg !40
@q = dso_local global [200 x [200 x double]] zeroinitializer, section ".chaser_data.q", align 64, !dbg !42
@.str = private unnamed_addr constant [12 x i8] c"ape.analyze\00", section "llvm.metadata"
@.str.1 = private unnamed_addr constant [121 x i8] c"/workspace/experiments-array-support/chaser/.cache/periodic-polybench/affine-bounds-20260929/suite/adi/source/workload.c\00", section "llvm.metadata"
@pb_hash = internal global i32 0, align 4, !dbg !30
@workload_jobs = dso_local constant [1 x i32 ()*] [i32 ()* @task_job_polybench], align 8, !dbg !13
@workload_expected = dso_local constant [1 x i32] [i32 1545355548], align 4, !dbg !26
@stderr = external global %struct._IO_FILE*, align 8
@.str.2 = private unnamed_addr constant [23 x i8] c"==BEGIN DUMP_ARRAYS==\0A\00", align 1
@.str.3 = private unnamed_addr constant [15 x i8] c"begin dump: %s\00", align 1
@.str.4 = private unnamed_addr constant [2 x i8] c"u\00", align 1
@.str.5 = private unnamed_addr constant [2 x i8] c"\0A\00", align 1
@.str.6 = private unnamed_addr constant [8 x i8] c"%0.2lf \00", align 1
@.str.7 = private unnamed_addr constant [17 x i8] c"\0Aend   dump: %s\0A\00", align 1
@.str.8 = private unnamed_addr constant [23 x i8] c"==END   DUMP_ARRAYS==\0A\00", align 1
@pb_emit = internal global i32 1, align 4, !dbg !44
@llvm.global.annotations = appending global [1 x { i8*, i8*, i8*, i32, i8* }] [{ i8*, i8*, i8*, i32, i8* } { i8* bitcast (i32 ()* @task_job_polybench to i8*), i8* getelementptr inbounds ([12 x i8], [12 x i8]* @.str, i32 0, i32 0), i8* getelementptr inbounds ([121 x i8], [121 x i8]* @.str.1, i32 0, i32 0), i32 156, i8* null }], section "llvm.metadata"

; Function Attrs: noinline nounwind uwtable
define dso_local void @workload_prepare() #0 !dbg !54 {
  ret void, !dbg !58
}

; Function Attrs: noinline nounwind uwtable
define dso_local void @workload_reset(i32 noundef %0) #0 !dbg !59 {
  call void @llvm.dbg.value(metadata i32 %0, metadata !62, metadata !DIExpression()), !dbg !63
  call void @llvm.memset.p0i8.i64(i8* align 64 bitcast ([200 x [200 x double]]* @u to i8*), i8 0, i64 320000, i1 false), !dbg !64
  call void @llvm.memset.p0i8.i64(i8* align 64 bitcast ([200 x [200 x double]]* @v to i8*), i8 0, i64 320000, i1 false), !dbg !65
  call void @llvm.memset.p0i8.i64(i8* align 64 bitcast ([200 x [200 x double]]* @p to i8*), i8 0, i64 320000, i1 false), !dbg !66
  call void @llvm.memset.p0i8.i64(i8* align 64 bitcast ([200 x [200 x double]]* @q to i8*), i8 0, i64 320000, i1 false), !dbg !67
  %2 = load i32, i32* @n, align 4, !dbg !68
  call void @init_array(i32 noundef %2, [200 x double]* noundef getelementptr inbounds ([200 x [200 x double]], [200 x [200 x double]]* @u, i64 0, i64 0)), !dbg !69
  ret void, !dbg !70
}

; Function Attrs: nofree nosync nounwind readnone speculatable willreturn
declare void @llvm.dbg.declare(metadata, metadata, metadata) #1

; Function Attrs: argmemonly nofree nounwind willreturn writeonly
declare void @llvm.memset.p0i8.i64(i8* nocapture writeonly, i8, i64, i1 immarg) #2

; Function Attrs: noinline nounwind uwtable
define internal void @init_array(i32 noundef %0, [200 x double]* noundef %1) #0 !dbg !71 {
  call void @llvm.dbg.value(metadata i32 %0, metadata !77, metadata !DIExpression()), !dbg !78
  call void @llvm.dbg.value(metadata [200 x double]* %1, metadata !79, metadata !DIExpression()), !dbg !78
  call void @llvm.dbg.value(metadata i32 0, metadata !80, metadata !DIExpression()), !dbg !78
  br label %3, !dbg !81

3:                                                ; preds = %21, %2
  %.01 = phi i32 [ 0, %2 ], [ %22, %21 ], !dbg !83
  call void @llvm.dbg.value(metadata i32 %.01, metadata !80, metadata !DIExpression()), !dbg !78
  %4 = icmp slt i32 %.01, %0, !dbg !84
  br i1 %4, label %5, label %23, !dbg !86

5:                                                ; preds = %3
  call void @llvm.dbg.value(metadata i32 0, metadata !87, metadata !DIExpression()), !dbg !78
  br label %6, !dbg !88

6:                                                ; preds = %18, %5
  %.0 = phi i32 [ 0, %5 ], [ %19, %18 ], !dbg !90
  call void @llvm.dbg.value(metadata i32 %.0, metadata !87, metadata !DIExpression()), !dbg !78
  %7 = icmp slt i32 %.0, %0, !dbg !91
  br i1 %7, label %8, label %20, !dbg !93

8:                                                ; preds = %6
  %9 = add nsw i32 %.01, %0, !dbg !94
  %10 = sub nsw i32 %9, %.0, !dbg !96
  %11 = sitofp i32 %10 to double, !dbg !97
  %12 = sitofp i32 %0 to double, !dbg !98
  %13 = fdiv double %11, %12, !dbg !99
  %14 = sext i32 %.01 to i64, !dbg !100
  %15 = getelementptr inbounds [200 x double], [200 x double]* %1, i64 %14, !dbg !100
  %16 = sext i32 %.0 to i64, !dbg !100
  %17 = getelementptr inbounds [200 x double], [200 x double]* %15, i64 0, i64 %16, !dbg !100
  store double %13, double* %17, align 8, !dbg !101
  br label %18, !dbg !102

18:                                               ; preds = %8
  %19 = add nsw i32 %.0, 1, !dbg !103
  call void @llvm.dbg.value(metadata i32 %19, metadata !87, metadata !DIExpression()), !dbg !78
  br label %6, !dbg !104, !llvm.loop !105

20:                                               ; preds = %6
  br label %21, !dbg !106

21:                                               ; preds = %20
  %22 = add nsw i32 %.01, 1, !dbg !108
  call void @llvm.dbg.value(metadata i32 %22, metadata !80, metadata !DIExpression()), !dbg !78
  br label %3, !dbg !109, !llvm.loop !110

23:                                               ; preds = %3
  ret void, !dbg !112
}

; Function Attrs: noinline nounwind uwtable
define dso_local i32 @task_job_polybench() #0 !dbg !113 {
  %1 = load i32, i32* @tsteps, align 4, !dbg !114
  %2 = load i32, i32* @n, align 4, !dbg !115
  call void @llvm.dbg.value(metadata i32 %1, metadata !116, metadata !DIExpression()), !dbg !120
  call void @llvm.dbg.value(metadata i32 %2, metadata !122, metadata !DIExpression()), !dbg !120
  call void @llvm.dbg.value(metadata [200 x double]* getelementptr inbounds ([200 x [200 x double]], [200 x [200 x double]]* @u, i64 0, i64 0), metadata !123, metadata !DIExpression()), !dbg !120
  call void @llvm.dbg.value(metadata [200 x double]* getelementptr inbounds ([200 x [200 x double]], [200 x [200 x double]]* @v, i64 0, i64 0), metadata !124, metadata !DIExpression()), !dbg !120
  call void @llvm.dbg.value(metadata [200 x double]* getelementptr inbounds ([200 x [200 x double]], [200 x [200 x double]]* @p, i64 0, i64 0), metadata !125, metadata !DIExpression()), !dbg !120
  call void @llvm.dbg.value(metadata [200 x double]* getelementptr inbounds ([200 x [200 x double]], [200 x [200 x double]]* @q, i64 0, i64 0), metadata !126, metadata !DIExpression()), !dbg !120
  call void @llvm.dbg.value(metadata double 5.000000e-03, metadata !127, metadata !DIExpression()), !dbg !120
  call void @llvm.dbg.value(metadata double 5.000000e-03, metadata !128, metadata !DIExpression()), !dbg !120
  call void @llvm.dbg.value(metadata double 1.000000e-02, metadata !129, metadata !DIExpression()), !dbg !120
  call void @llvm.dbg.value(metadata double 2.000000e+00, metadata !130, metadata !DIExpression()), !dbg !120
  call void @llvm.dbg.value(metadata double 1.000000e+00, metadata !131, metadata !DIExpression()), !dbg !120
  %3 = fmul double 2.000000e+00, 1.000000e-02, !dbg !132
  %4 = fmul double 5.000000e-03, 5.000000e-03, !dbg !133
  %5 = fdiv double %3, %4, !dbg !134
  call void @llvm.dbg.value(metadata double %5, metadata !135, metadata !DIExpression()), !dbg !120
  %6 = fmul double 1.000000e+00, 1.000000e-02, !dbg !136
  %7 = fmul double 5.000000e-03, 5.000000e-03, !dbg !137
  %8 = fdiv double %6, %7, !dbg !138
  call void @llvm.dbg.value(metadata double %8, metadata !139, metadata !DIExpression()), !dbg !120
  %9 = fneg double %5, !dbg !140
  %10 = fdiv double %9, 2.000000e+00, !dbg !141
  call void @llvm.dbg.value(metadata double %10, metadata !142, metadata !DIExpression()), !dbg !120
  %11 = fadd double 1.000000e+00, %5, !dbg !143
  call void @llvm.dbg.value(metadata double %11, metadata !144, metadata !DIExpression()), !dbg !120
  call void @llvm.dbg.value(metadata double %10, metadata !145, metadata !DIExpression()), !dbg !120
  %12 = fneg double %8, !dbg !146
  %13 = fdiv double %12, 2.000000e+00, !dbg !147
  call void @llvm.dbg.value(metadata double %13, metadata !148, metadata !DIExpression()), !dbg !120
  %14 = fadd double 1.000000e+00, %8, !dbg !149
  call void @llvm.dbg.value(metadata double %14, metadata !150, metadata !DIExpression()), !dbg !120
  call void @llvm.dbg.value(metadata double %13, metadata !151, metadata !DIExpression()), !dbg !120
  call void @llvm.dbg.value(metadata i32 1, metadata !152, metadata !DIExpression()), !dbg !120
  br label %15, !dbg !153

15:                                               ; preds = %241, %0
  %.03 = phi i32 [ 1, %0 ], [ %242, %241 ], !dbg !155
  call void @llvm.dbg.value(metadata i32 %.03, metadata !152, metadata !DIExpression()), !dbg !120
  %16 = icmp sle i32 %.03, 100, !dbg !156
  br i1 %16, label %17, label %243, !dbg !158

17:                                               ; preds = %15
  call void @llvm.dbg.value(metadata i32 1, metadata !159, metadata !DIExpression()), !dbg !120
  br label %18, !dbg !160

18:                                               ; preds = %126, %17
  %.01 = phi i32 [ 1, %17 ], [ %127, %126 ], !dbg !163
  call void @llvm.dbg.value(metadata i32 %.01, metadata !159, metadata !DIExpression()), !dbg !120
  %19 = icmp slt i32 %.01, 199, !dbg !164
  br i1 %19, label %20, label %128, !dbg !166

20:                                               ; preds = %18
  %21 = sext i32 %.01 to i64, !dbg !167
  %22 = getelementptr inbounds [200 x double], [200 x double]* getelementptr inbounds ([200 x [200 x double]], [200 x [200 x double]]* @v, i64 0, i64 0), i64 0, i64 %21, !dbg !167
  store double 1.000000e+00, double* %22, align 8, !dbg !169
  %23 = sext i32 %.01 to i64, !dbg !170
  %24 = getelementptr inbounds [200 x double], [200 x double]* getelementptr inbounds ([200 x [200 x double]], [200 x [200 x double]]* @p, i64 0, i64 0), i64 %23, !dbg !170
  %25 = getelementptr inbounds [200 x double], [200 x double]* %24, i64 0, i64 0, !dbg !170
  store double 0.000000e+00, double* %25, align 8, !dbg !171
  %26 = sext i32 %.01 to i64, !dbg !172
  %27 = getelementptr inbounds [200 x double], [200 x double]* getelementptr inbounds ([200 x [200 x double]], [200 x [200 x double]]* @v, i64 0, i64 0), i64 0, i64 %26, !dbg !172
  %28 = load double, double* %27, align 8, !dbg !172
  %29 = sext i32 %.01 to i64, !dbg !173
  %30 = getelementptr inbounds [200 x double], [200 x double]* getelementptr inbounds ([200 x [200 x double]], [200 x [200 x double]]* @q, i64 0, i64 0), i64 %29, !dbg !173
  %31 = getelementptr inbounds [200 x double], [200 x double]* %30, i64 0, i64 0, !dbg !173
  store double %28, double* %31, align 8, !dbg !174
  call void @llvm.dbg.value(metadata i32 1, metadata !175, metadata !DIExpression()), !dbg !120
  br label %32, !dbg !176

32:                                               ; preds = %34, %20
  %.0 = phi i32 [ 1, %20 ], [ %95, %34 ], !dbg !178
  call void @llvm.dbg.value(metadata i32 %.0, metadata !175, metadata !DIExpression()), !dbg !120
  %33 = icmp slt i32 %.0, 199, !dbg !179
  br i1 %33, label %34, label %96, !dbg !181

34:                                               ; preds = %32
  %35 = fneg double %10, !dbg !182
  %36 = sext i32 %.01 to i64, !dbg !184
  %37 = getelementptr inbounds [200 x double], [200 x double]* getelementptr inbounds ([200 x [200 x double]], [200 x [200 x double]]* @p, i64 0, i64 0), i64 %36, !dbg !184
  %38 = sub nsw i32 %.0, 1, !dbg !185
  %39 = sext i32 %38 to i64, !dbg !184
  %40 = getelementptr inbounds [200 x double], [200 x double]* %37, i64 0, i64 %39, !dbg !184
  %41 = load double, double* %40, align 8, !dbg !184
  %42 = fmul double %10, %41, !dbg !186
  %43 = fadd double %42, %11, !dbg !187
  %44 = fdiv double %35, %43, !dbg !188
  %45 = sext i32 %.01 to i64, !dbg !189
  %46 = getelementptr inbounds [200 x double], [200 x double]* getelementptr inbounds ([200 x [200 x double]], [200 x [200 x double]]* @p, i64 0, i64 0), i64 %45, !dbg !189
  %47 = sext i32 %.0 to i64, !dbg !189
  %48 = getelementptr inbounds [200 x double], [200 x double]* %46, i64 0, i64 %47, !dbg !189
  store double %44, double* %48, align 8, !dbg !190
  %49 = fneg double %13, !dbg !191
  %50 = sext i32 %.0 to i64, !dbg !192
  %51 = getelementptr inbounds [200 x double], [200 x double]* getelementptr inbounds ([200 x [200 x double]], [200 x [200 x double]]* @u, i64 0, i64 0), i64 %50, !dbg !192
  %52 = sub nsw i32 %.01, 1, !dbg !193
  %53 = sext i32 %52 to i64, !dbg !192
  %54 = getelementptr inbounds [200 x double], [200 x double]* %51, i64 0, i64 %53, !dbg !192
  %55 = load double, double* %54, align 8, !dbg !192
  %56 = fmul double %49, %55, !dbg !194
  %57 = fmul double 2.000000e+00, %13, !dbg !195
  %58 = fadd double 1.000000e+00, %57, !dbg !196
  %59 = sext i32 %.0 to i64, !dbg !197
  %60 = getelementptr inbounds [200 x double], [200 x double]* getelementptr inbounds ([200 x [200 x double]], [200 x [200 x double]]* @u, i64 0, i64 0), i64 %59, !dbg !197
  %61 = sext i32 %.01 to i64, !dbg !197
  %62 = getelementptr inbounds [200 x double], [200 x double]* %60, i64 0, i64 %61, !dbg !197
  %63 = load double, double* %62, align 8, !dbg !197
  %64 = fmul double %58, %63, !dbg !198
  %65 = fadd double %56, %64, !dbg !199
  %66 = sext i32 %.0 to i64, !dbg !200
  %67 = getelementptr inbounds [200 x double], [200 x double]* getelementptr inbounds ([200 x [200 x double]], [200 x [200 x double]]* @u, i64 0, i64 0), i64 %66, !dbg !200
  %68 = add nsw i32 %.01, 1, !dbg !201
  %69 = sext i32 %68 to i64, !dbg !200
  %70 = getelementptr inbounds [200 x double], [200 x double]* %67, i64 0, i64 %69, !dbg !200
  %71 = load double, double* %70, align 8, !dbg !200
  %72 = fmul double %13, %71, !dbg !202
  %73 = fsub double %65, %72, !dbg !203
  %74 = sext i32 %.01 to i64, !dbg !204
  %75 = getelementptr inbounds [200 x double], [200 x double]* getelementptr inbounds ([200 x [200 x double]], [200 x [200 x double]]* @q, i64 0, i64 0), i64 %74, !dbg !204
  %76 = sub nsw i32 %.0, 1, !dbg !205
  %77 = sext i32 %76 to i64, !dbg !204
  %78 = getelementptr inbounds [200 x double], [200 x double]* %75, i64 0, i64 %77, !dbg !204
  %79 = load double, double* %78, align 8, !dbg !204
  %80 = fmul double %10, %79, !dbg !206
  %81 = fsub double %73, %80, !dbg !207
  %82 = sext i32 %.01 to i64, !dbg !208
  %83 = getelementptr inbounds [200 x double], [200 x double]* getelementptr inbounds ([200 x [200 x double]], [200 x [200 x double]]* @p, i64 0, i64 0), i64 %82, !dbg !208
  %84 = sub nsw i32 %.0, 1, !dbg !209
  %85 = sext i32 %84 to i64, !dbg !208
  %86 = getelementptr inbounds [200 x double], [200 x double]* %83, i64 0, i64 %85, !dbg !208
  %87 = load double, double* %86, align 8, !dbg !208
  %88 = fmul double %10, %87, !dbg !210
  %89 = fadd double %88, %11, !dbg !211
  %90 = fdiv double %81, %89, !dbg !212
  %91 = sext i32 %.01 to i64, !dbg !213
  %92 = getelementptr inbounds [200 x double], [200 x double]* getelementptr inbounds ([200 x [200 x double]], [200 x [200 x double]]* @q, i64 0, i64 0), i64 %91, !dbg !213
  %93 = sext i32 %.0 to i64, !dbg !213
  %94 = getelementptr inbounds [200 x double], [200 x double]* %92, i64 0, i64 %93, !dbg !213
  store double %90, double* %94, align 8, !dbg !214
  %95 = add nsw i32 %.0, 1, !dbg !215
  call void @llvm.dbg.value(metadata i32 %95, metadata !175, metadata !DIExpression()), !dbg !120
  br label %32, !dbg !216, !llvm.loop !217

96:                                               ; preds = %32
  %97 = getelementptr inbounds [200 x double], [200 x double]* getelementptr inbounds ([200 x [200 x double]], [200 x [200 x double]]* @v, i64 0, i64 0), i64 199, !dbg !219
  %98 = sext i32 %.01 to i64, !dbg !219
  %99 = getelementptr inbounds [200 x double], [200 x double]* %97, i64 0, i64 %98, !dbg !219
  store double 1.000000e+00, double* %99, align 8, !dbg !220
  call void @llvm.dbg.value(metadata i32 198, metadata !175, metadata !DIExpression()), !dbg !120
  br label %100, !dbg !221

100:                                              ; preds = %102, %96
  %.1 = phi i32 [ 198, %96 ], [ %125, %102 ], !dbg !223
  call void @llvm.dbg.value(metadata i32 %.1, metadata !175, metadata !DIExpression()), !dbg !120
  %101 = icmp sge i32 %.1, 1, !dbg !224
  br i1 %101, label %102, label %126, !dbg !226

102:                                              ; preds = %100
  %103 = sext i32 %.01 to i64, !dbg !227
  %104 = getelementptr inbounds [200 x double], [200 x double]* getelementptr inbounds ([200 x [200 x double]], [200 x [200 x double]]* @p, i64 0, i64 0), i64 %103, !dbg !227
  %105 = sext i32 %.1 to i64, !dbg !227
  %106 = getelementptr inbounds [200 x double], [200 x double]* %104, i64 0, i64 %105, !dbg !227
  %107 = load double, double* %106, align 8, !dbg !227
  %108 = add nsw i32 %.1, 1, !dbg !229
  %109 = sext i32 %108 to i64, !dbg !230
  %110 = getelementptr inbounds [200 x double], [200 x double]* getelementptr inbounds ([200 x [200 x double]], [200 x [200 x double]]* @v, i64 0, i64 0), i64 %109, !dbg !230
  %111 = sext i32 %.01 to i64, !dbg !230
  %112 = getelementptr inbounds [200 x double], [200 x double]* %110, i64 0, i64 %111, !dbg !230
  %113 = load double, double* %112, align 8, !dbg !230
  %114 = fmul double %107, %113, !dbg !231
  %115 = sext i32 %.01 to i64, !dbg !232
  %116 = getelementptr inbounds [200 x double], [200 x double]* getelementptr inbounds ([200 x [200 x double]], [200 x [200 x double]]* @q, i64 0, i64 0), i64 %115, !dbg !232
  %117 = sext i32 %.1 to i64, !dbg !232
  %118 = getelementptr inbounds [200 x double], [200 x double]* %116, i64 0, i64 %117, !dbg !232
  %119 = load double, double* %118, align 8, !dbg !232
  %120 = fadd double %114, %119, !dbg !233
  %121 = sext i32 %.1 to i64, !dbg !234
  %122 = getelementptr inbounds [200 x double], [200 x double]* getelementptr inbounds ([200 x [200 x double]], [200 x [200 x double]]* @v, i64 0, i64 0), i64 %121, !dbg !234
  %123 = sext i32 %.01 to i64, !dbg !234
  %124 = getelementptr inbounds [200 x double], [200 x double]* %122, i64 0, i64 %123, !dbg !234
  store double %120, double* %124, align 8, !dbg !235
  %125 = add nsw i32 %.1, -1, !dbg !236
  call void @llvm.dbg.value(metadata i32 %125, metadata !175, metadata !DIExpression()), !dbg !120
  br label %100, !dbg !237, !llvm.loop !238

126:                                              ; preds = %100
  %127 = add nsw i32 %.01, 1, !dbg !240
  call void @llvm.dbg.value(metadata i32 %127, metadata !159, metadata !DIExpression()), !dbg !120
  br label %18, !dbg !241, !llvm.loop !242

128:                                              ; preds = %18
  call void @llvm.dbg.value(metadata i32 1, metadata !159, metadata !DIExpression()), !dbg !120
  br label %129, !dbg !244

129:                                              ; preds = %239, %128
  %.12 = phi i32 [ 1, %128 ], [ %240, %239 ], !dbg !246
  call void @llvm.dbg.value(metadata i32 %.12, metadata !159, metadata !DIExpression()), !dbg !120
  %130 = icmp slt i32 %.12, 199, !dbg !247
  br i1 %130, label %131, label %241, !dbg !249

131:                                              ; preds = %129
  %132 = sext i32 %.12 to i64, !dbg !250
  %133 = getelementptr inbounds [200 x double], [200 x double]* getelementptr inbounds ([200 x [200 x double]], [200 x [200 x double]]* @u, i64 0, i64 0), i64 %132, !dbg !250
  %134 = getelementptr inbounds [200 x double], [200 x double]* %133, i64 0, i64 0, !dbg !250
  store double 1.000000e+00, double* %134, align 8, !dbg !252
  %135 = sext i32 %.12 to i64, !dbg !253
  %136 = getelementptr inbounds [200 x double], [200 x double]* getelementptr inbounds ([200 x [200 x double]], [200 x [200 x double]]* @p, i64 0, i64 0), i64 %135, !dbg !253
  %137 = getelementptr inbounds [200 x double], [200 x double]* %136, i64 0, i64 0, !dbg !253
  store double 0.000000e+00, double* %137, align 8, !dbg !254
  %138 = sext i32 %.12 to i64, !dbg !255
  %139 = getelementptr inbounds [200 x double], [200 x double]* getelementptr inbounds ([200 x [200 x double]], [200 x [200 x double]]* @u, i64 0, i64 0), i64 %138, !dbg !255
  %140 = getelementptr inbounds [200 x double], [200 x double]* %139, i64 0, i64 0, !dbg !255
  %141 = load double, double* %140, align 8, !dbg !255
  %142 = sext i32 %.12 to i64, !dbg !256
  %143 = getelementptr inbounds [200 x double], [200 x double]* getelementptr inbounds ([200 x [200 x double]], [200 x [200 x double]]* @q, i64 0, i64 0), i64 %142, !dbg !256
  %144 = getelementptr inbounds [200 x double], [200 x double]* %143, i64 0, i64 0, !dbg !256
  store double %141, double* %144, align 8, !dbg !257
  call void @llvm.dbg.value(metadata i32 1, metadata !175, metadata !DIExpression()), !dbg !120
  br label %145, !dbg !258

145:                                              ; preds = %147, %131
  %.2 = phi i32 [ 1, %131 ], [ %208, %147 ], !dbg !260
  call void @llvm.dbg.value(metadata i32 %.2, metadata !175, metadata !DIExpression()), !dbg !120
  %146 = icmp slt i32 %.2, 199, !dbg !261
  br i1 %146, label %147, label %209, !dbg !263

147:                                              ; preds = %145
  %148 = fneg double %13, !dbg !264
  %149 = sext i32 %.12 to i64, !dbg !266
  %150 = getelementptr inbounds [200 x double], [200 x double]* getelementptr inbounds ([200 x [200 x double]], [200 x [200 x double]]* @p, i64 0, i64 0), i64 %149, !dbg !266
  %151 = sub nsw i32 %.2, 1, !dbg !267
  %152 = sext i32 %151 to i64, !dbg !266
  %153 = getelementptr inbounds [200 x double], [200 x double]* %150, i64 0, i64 %152, !dbg !266
  %154 = load double, double* %153, align 8, !dbg !266
  %155 = fmul double %13, %154, !dbg !268
  %156 = fadd double %155, %14, !dbg !269
  %157 = fdiv double %148, %156, !dbg !270
  %158 = sext i32 %.12 to i64, !dbg !271
  %159 = getelementptr inbounds [200 x double], [200 x double]* getelementptr inbounds ([200 x [200 x double]], [200 x [200 x double]]* @p, i64 0, i64 0), i64 %158, !dbg !271
  %160 = sext i32 %.2 to i64, !dbg !271
  %161 = getelementptr inbounds [200 x double], [200 x double]* %159, i64 0, i64 %160, !dbg !271
  store double %157, double* %161, align 8, !dbg !272
  %162 = fneg double %10, !dbg !273
  %163 = sub nsw i32 %.12, 1, !dbg !274
  %164 = sext i32 %163 to i64, !dbg !275
  %165 = getelementptr inbounds [200 x double], [200 x double]* getelementptr inbounds ([200 x [200 x double]], [200 x [200 x double]]* @v, i64 0, i64 0), i64 %164, !dbg !275
  %166 = sext i32 %.2 to i64, !dbg !275
  %167 = getelementptr inbounds [200 x double], [200 x double]* %165, i64 0, i64 %166, !dbg !275
  %168 = load double, double* %167, align 8, !dbg !275
  %169 = fmul double %162, %168, !dbg !276
  %170 = fmul double 2.000000e+00, %10, !dbg !277
  %171 = fadd double 1.000000e+00, %170, !dbg !278
  %172 = sext i32 %.12 to i64, !dbg !279
  %173 = getelementptr inbounds [200 x double], [200 x double]* getelementptr inbounds ([200 x [200 x double]], [200 x [200 x double]]* @v, i64 0, i64 0), i64 %172, !dbg !279
  %174 = sext i32 %.2 to i64, !dbg !279
  %175 = getelementptr inbounds [200 x double], [200 x double]* %173, i64 0, i64 %174, !dbg !279
  %176 = load double, double* %175, align 8, !dbg !279
  %177 = fmul double %171, %176, !dbg !280
  %178 = fadd double %169, %177, !dbg !281
  %179 = add nsw i32 %.12, 1, !dbg !282
  %180 = sext i32 %179 to i64, !dbg !283
  %181 = getelementptr inbounds [200 x double], [200 x double]* getelementptr inbounds ([200 x [200 x double]], [200 x [200 x double]]* @v, i64 0, i64 0), i64 %180, !dbg !283
  %182 = sext i32 %.2 to i64, !dbg !283
  %183 = getelementptr inbounds [200 x double], [200 x double]* %181, i64 0, i64 %182, !dbg !283
  %184 = load double, double* %183, align 8, !dbg !283
  %185 = fmul double %10, %184, !dbg !284
  %186 = fsub double %178, %185, !dbg !285
  %187 = sext i32 %.12 to i64, !dbg !286
  %188 = getelementptr inbounds [200 x double], [200 x double]* getelementptr inbounds ([200 x [200 x double]], [200 x [200 x double]]* @q, i64 0, i64 0), i64 %187, !dbg !286
  %189 = sub nsw i32 %.2, 1, !dbg !287
  %190 = sext i32 %189 to i64, !dbg !286
  %191 = getelementptr inbounds [200 x double], [200 x double]* %188, i64 0, i64 %190, !dbg !286
  %192 = load double, double* %191, align 8, !dbg !286
  %193 = fmul double %13, %192, !dbg !288
  %194 = fsub double %186, %193, !dbg !289
  %195 = sext i32 %.12 to i64, !dbg !290
  %196 = getelementptr inbounds [200 x double], [200 x double]* getelementptr inbounds ([200 x [200 x double]], [200 x [200 x double]]* @p, i64 0, i64 0), i64 %195, !dbg !290
  %197 = sub nsw i32 %.2, 1, !dbg !291
  %198 = sext i32 %197 to i64, !dbg !290
  %199 = getelementptr inbounds [200 x double], [200 x double]* %196, i64 0, i64 %198, !dbg !290
  %200 = load double, double* %199, align 8, !dbg !290
  %201 = fmul double %13, %200, !dbg !292
  %202 = fadd double %201, %14, !dbg !293
  %203 = fdiv double %194, %202, !dbg !294
  %204 = sext i32 %.12 to i64, !dbg !295
  %205 = getelementptr inbounds [200 x double], [200 x double]* getelementptr inbounds ([200 x [200 x double]], [200 x [200 x double]]* @q, i64 0, i64 0), i64 %204, !dbg !295
  %206 = sext i32 %.2 to i64, !dbg !295
  %207 = getelementptr inbounds [200 x double], [200 x double]* %205, i64 0, i64 %206, !dbg !295
  store double %203, double* %207, align 8, !dbg !296
  %208 = add nsw i32 %.2, 1, !dbg !297
  call void @llvm.dbg.value(metadata i32 %208, metadata !175, metadata !DIExpression()), !dbg !120
  br label %145, !dbg !298, !llvm.loop !299

209:                                              ; preds = %145
  %210 = sext i32 %.12 to i64, !dbg !301
  %211 = getelementptr inbounds [200 x double], [200 x double]* getelementptr inbounds ([200 x [200 x double]], [200 x [200 x double]]* @u, i64 0, i64 0), i64 %210, !dbg !301
  %212 = getelementptr inbounds [200 x double], [200 x double]* %211, i64 0, i64 199, !dbg !301
  store double 1.000000e+00, double* %212, align 8, !dbg !302
  call void @llvm.dbg.value(metadata i32 198, metadata !175, metadata !DIExpression()), !dbg !120
  br label %213, !dbg !303

213:                                              ; preds = %215, %209
  %.3 = phi i32 [ 198, %209 ], [ %238, %215 ], !dbg !305
  call void @llvm.dbg.value(metadata i32 %.3, metadata !175, metadata !DIExpression()), !dbg !120
  %214 = icmp sge i32 %.3, 1, !dbg !306
  br i1 %214, label %215, label %239, !dbg !308

215:                                              ; preds = %213
  %216 = sext i32 %.12 to i64, !dbg !309
  %217 = getelementptr inbounds [200 x double], [200 x double]* getelementptr inbounds ([200 x [200 x double]], [200 x [200 x double]]* @p, i64 0, i64 0), i64 %216, !dbg !309
  %218 = sext i32 %.3 to i64, !dbg !309
  %219 = getelementptr inbounds [200 x double], [200 x double]* %217, i64 0, i64 %218, !dbg !309
  %220 = load double, double* %219, align 8, !dbg !309
  %221 = sext i32 %.12 to i64, !dbg !311
  %222 = getelementptr inbounds [200 x double], [200 x double]* getelementptr inbounds ([200 x [200 x double]], [200 x [200 x double]]* @u, i64 0, i64 0), i64 %221, !dbg !311
  %223 = add nsw i32 %.3, 1, !dbg !312
  %224 = sext i32 %223 to i64, !dbg !311
  %225 = getelementptr inbounds [200 x double], [200 x double]* %222, i64 0, i64 %224, !dbg !311
  %226 = load double, double* %225, align 8, !dbg !311
  %227 = fmul double %220, %226, !dbg !313
  %228 = sext i32 %.12 to i64, !dbg !314
  %229 = getelementptr inbounds [200 x double], [200 x double]* getelementptr inbounds ([200 x [200 x double]], [200 x [200 x double]]* @q, i64 0, i64 0), i64 %228, !dbg !314
  %230 = sext i32 %.3 to i64, !dbg !314
  %231 = getelementptr inbounds [200 x double], [200 x double]* %229, i64 0, i64 %230, !dbg !314
  %232 = load double, double* %231, align 8, !dbg !314
  %233 = fadd double %227, %232, !dbg !315
  %234 = sext i32 %.12 to i64, !dbg !316
  %235 = getelementptr inbounds [200 x double], [200 x double]* getelementptr inbounds ([200 x [200 x double]], [200 x [200 x double]]* @u, i64 0, i64 0), i64 %234, !dbg !316
  %236 = sext i32 %.3 to i64, !dbg !316
  %237 = getelementptr inbounds [200 x double], [200 x double]* %235, i64 0, i64 %236, !dbg !316
  store double %233, double* %237, align 8, !dbg !317
  %238 = add nsw i32 %.3, -1, !dbg !318
  call void @llvm.dbg.value(metadata i32 %238, metadata !175, metadata !DIExpression()), !dbg !120
  br label %213, !dbg !319, !llvm.loop !320

239:                                              ; preds = %213
  %240 = add nsw i32 %.12, 1, !dbg !322
  call void @llvm.dbg.value(metadata i32 %240, metadata !159, metadata !DIExpression()), !dbg !120
  br label %129, !dbg !323, !llvm.loop !324

241:                                              ; preds = %129
  %242 = add nsw i32 %.03, 1, !dbg !326
  call void @llvm.dbg.value(metadata i32 %242, metadata !152, metadata !DIExpression()), !dbg !120
  br label %15, !dbg !327, !llvm.loop !328

243:                                              ; preds = %15
  ret i32 0, !dbg !330
}

; Function Attrs: noinline nounwind uwtable
define dso_local i32 @workload_checksum(i32 noundef %0) #0 !dbg !331 {
  call void @llvm.dbg.value(metadata i32 %0, metadata !334, metadata !DIExpression()), !dbg !335
  store i32 -2128831035, i32* @pb_hash, align 4, !dbg !336
  %2 = load i32, i32* @n, align 4, !dbg !337
  call void @print_array(i32 noundef %2, [200 x double]* noundef getelementptr inbounds ([200 x [200 x double]], [200 x [200 x double]]* @u, i64 0, i64 0)), !dbg !338
  %3 = load i32, i32* @pb_hash, align 4, !dbg !339
  ret i32 %3, !dbg !340
}

; Function Attrs: noinline nounwind uwtable
define internal void @print_array(i32 noundef %0, [200 x double]* noundef %1) #0 !dbg !341 {
  call void @llvm.dbg.value(metadata i32 %0, metadata !342, metadata !DIExpression()), !dbg !343
  call void @llvm.dbg.value(metadata [200 x double]* %1, metadata !344, metadata !DIExpression()), !dbg !343
  %3 = load %struct._IO_FILE*, %struct._IO_FILE** @stderr, align 8, !dbg !345
  %4 = call i32 (%struct._IO_FILE*, i8*, ...) @pb_fprintf(%struct._IO_FILE* noundef %3, i8* noundef getelementptr inbounds ([23 x i8], [23 x i8]* @.str.2, i64 0, i64 0)), !dbg !345
  %5 = load %struct._IO_FILE*, %struct._IO_FILE** @stderr, align 8, !dbg !346
  %6 = call i32 (%struct._IO_FILE*, i8*, ...) @pb_fprintf(%struct._IO_FILE* noundef %5, i8* noundef getelementptr inbounds ([15 x i8], [15 x i8]* @.str.3, i64 0, i64 0), i8* noundef getelementptr inbounds ([2 x i8], [2 x i8]* @.str.4, i64 0, i64 0)), !dbg !346
  call void @llvm.dbg.value(metadata i32 0, metadata !347, metadata !DIExpression()), !dbg !343
  br label %7, !dbg !348

7:                                                ; preds = %31, %2
  %.01 = phi i32 [ 0, %2 ], [ %32, %31 ], !dbg !350
  call void @llvm.dbg.value(metadata i32 %.01, metadata !347, metadata !DIExpression()), !dbg !343
  %8 = icmp slt i32 %.01, %0, !dbg !351
  br i1 %8, label %9, label %33, !dbg !353

9:                                                ; preds = %7
  call void @llvm.dbg.value(metadata i32 0, metadata !354, metadata !DIExpression()), !dbg !343
  br label %10, !dbg !355

10:                                               ; preds = %28, %9
  %.0 = phi i32 [ 0, %9 ], [ %29, %28 ], !dbg !357
  call void @llvm.dbg.value(metadata i32 %.0, metadata !354, metadata !DIExpression()), !dbg !343
  %11 = icmp slt i32 %.0, %0, !dbg !358
  br i1 %11, label %12, label %30, !dbg !360

12:                                               ; preds = %10
  %13 = mul nsw i32 %.01, %0, !dbg !361
  %14 = add nsw i32 %13, %.0, !dbg !364
  %15 = srem i32 %14, 20, !dbg !365
  %16 = icmp eq i32 %15, 0, !dbg !366
  br i1 %16, label %17, label %20, !dbg !367

17:                                               ; preds = %12
  %18 = load %struct._IO_FILE*, %struct._IO_FILE** @stderr, align 8, !dbg !368
  %19 = call i32 (%struct._IO_FILE*, i8*, ...) @pb_fprintf(%struct._IO_FILE* noundef %18, i8* noundef getelementptr inbounds ([2 x i8], [2 x i8]* @.str.5, i64 0, i64 0)), !dbg !369
  br label %20, !dbg !369

20:                                               ; preds = %17, %12
  %21 = load %struct._IO_FILE*, %struct._IO_FILE** @stderr, align 8, !dbg !370
  %22 = sext i32 %.01 to i64, !dbg !371
  %23 = getelementptr inbounds [200 x double], [200 x double]* %1, i64 %22, !dbg !371
  %24 = sext i32 %.0 to i64, !dbg !371
  %25 = getelementptr inbounds [200 x double], [200 x double]* %23, i64 0, i64 %24, !dbg !371
  %26 = load double, double* %25, align 8, !dbg !371
  %27 = call i32 (%struct._IO_FILE*, i8*, ...) @pb_fprintf(%struct._IO_FILE* noundef %21, i8* noundef getelementptr inbounds ([8 x i8], [8 x i8]* @.str.6, i64 0, i64 0), double noundef %26), !dbg !372
  br label %28, !dbg !373

28:                                               ; preds = %20
  %29 = add nsw i32 %.0, 1, !dbg !374
  call void @llvm.dbg.value(metadata i32 %29, metadata !354, metadata !DIExpression()), !dbg !343
  br label %10, !dbg !375, !llvm.loop !376

30:                                               ; preds = %10
  br label %31, !dbg !377

31:                                               ; preds = %30
  %32 = add nsw i32 %.01, 1, !dbg !378
  call void @llvm.dbg.value(metadata i32 %32, metadata !347, metadata !DIExpression()), !dbg !343
  br label %7, !dbg !379, !llvm.loop !380

33:                                               ; preds = %7
  %34 = load %struct._IO_FILE*, %struct._IO_FILE** @stderr, align 8, !dbg !382
  %35 = call i32 (%struct._IO_FILE*, i8*, ...) @pb_fprintf(%struct._IO_FILE* noundef %34, i8* noundef getelementptr inbounds ([17 x i8], [17 x i8]* @.str.7, i64 0, i64 0), i8* noundef getelementptr inbounds ([2 x i8], [2 x i8]* @.str.4, i64 0, i64 0)), !dbg !382
  %36 = load %struct._IO_FILE*, %struct._IO_FILE** @stderr, align 8, !dbg !383
  %37 = call i32 (%struct._IO_FILE*, i8*, ...) @pb_fprintf(%struct._IO_FILE* noundef %36, i8* noundef getelementptr inbounds ([23 x i8], [23 x i8]* @.str.8, i64 0, i64 0)), !dbg !383
  ret void, !dbg !384
}

; Function Attrs: noinline nounwind uwtable
define internal i32 @pb_fprintf(%struct._IO_FILE* noundef %0, i8* noundef %1, ...) #0 !dbg !385 {
  %3 = alloca [768 x i8], align 16
  %4 = alloca [1 x %struct.__va_list_tag], align 16
  call void @llvm.dbg.value(metadata %struct._IO_FILE* %0, metadata !449, metadata !DIExpression()), !dbg !450
  call void @llvm.dbg.value(metadata i8* %1, metadata !451, metadata !DIExpression()), !dbg !450
  call void @llvm.dbg.declare(metadata [768 x i8]* %3, metadata !452, metadata !DIExpression()), !dbg !456
  call void @llvm.dbg.declare(metadata [1 x %struct.__va_list_tag]* %4, metadata !457, metadata !DIExpression()), !dbg !471
  %5 = getelementptr inbounds [1 x %struct.__va_list_tag], [1 x %struct.__va_list_tag]* %4, i64 0, i64 0, !dbg !472
  %6 = bitcast %struct.__va_list_tag* %5 to i8*, !dbg !472
  call void @llvm.va_start(i8* %6), !dbg !472
  %7 = getelementptr inbounds [768 x i8], [768 x i8]* %3, i64 0, i64 0, !dbg !473
  %8 = getelementptr inbounds [1 x %struct.__va_list_tag], [1 x %struct.__va_list_tag]* %4, i64 0, i64 0, !dbg !474
  %9 = call i32 @vsnprintf(i8* noundef %7, i64 noundef 768, i8* noundef %1, %struct.__va_list_tag* noundef %8) #6, !dbg !475
  call void @llvm.dbg.value(metadata i32 %9, metadata !476, metadata !DIExpression()), !dbg !450
  %10 = getelementptr inbounds [1 x %struct.__va_list_tag], [1 x %struct.__va_list_tag]* %4, i64 0, i64 0, !dbg !477
  %11 = bitcast %struct.__va_list_tag* %10 to i8*, !dbg !477
  call void @llvm.va_end(i8* %11), !dbg !477
  %12 = icmp slt i32 %9, 0, !dbg !478
  br i1 %12, label %16, label %13, !dbg !480

13:                                               ; preds = %2
  %14 = zext i32 %9 to i64, !dbg !481
  %15 = icmp uge i64 %14, 768, !dbg !482
  br i1 %15, label %16, label %17, !dbg !483

16:                                               ; preds = %13, %2
  call void @abort() #7, !dbg !484
  unreachable, !dbg !484

17:                                               ; preds = %13
  call void @llvm.dbg.value(metadata i32 0, metadata !485, metadata !DIExpression()), !dbg !487
  br label %18, !dbg !488

18:                                               ; preds = %29, %17
  %.0 = phi i32 [ 0, %17 ], [ %30, %29 ], !dbg !487
  call void @llvm.dbg.value(metadata i32 %.0, metadata !485, metadata !DIExpression()), !dbg !487
  %19 = icmp slt i32 %.0, %9, !dbg !489
  br i1 %19, label %20, label %31, !dbg !491

20:                                               ; preds = %18
  %21 = sext i32 %.0 to i64, !dbg !492
  %22 = getelementptr inbounds [768 x i8], [768 x i8]* %3, i64 0, i64 %21, !dbg !492
  %23 = load i8, i8* %22, align 1, !dbg !492
  %24 = zext i8 %23 to i32, !dbg !494
  %25 = load i32, i32* @pb_hash, align 4, !dbg !495
  %26 = xor i32 %25, %24, !dbg !495
  store i32 %26, i32* @pb_hash, align 4, !dbg !495
  %27 = load i32, i32* @pb_hash, align 4, !dbg !496
  %28 = mul i32 %27, 16777619, !dbg !496
  store i32 %28, i32* @pb_hash, align 4, !dbg !496
  br label %29, !dbg !497

29:                                               ; preds = %20
  %30 = add nsw i32 %.0, 1, !dbg !498
  call void @llvm.dbg.value(metadata i32 %30, metadata !485, metadata !DIExpression()), !dbg !487
  br label %18, !dbg !499, !llvm.loop !500

31:                                               ; preds = %18
  %32 = load i32, i32* @pb_emit, align 4, !dbg !502
  ret i32 %9, !dbg !503
}

; Function Attrs: nofree nosync nounwind willreturn
declare void @llvm.va_start(i8*) #3

; Function Attrs: nounwind
declare i32 @vsnprintf(i8* noundef, i64 noundef, i8* noundef, %struct.__va_list_tag* noundef) #4

; Function Attrs: nofree nosync nounwind willreturn
declare void @llvm.va_end(i8*) #3

; Function Attrs: noreturn nounwind
declare void @abort() #5

; Function Attrs: nofree nosync nounwind readnone speculatable willreturn
declare void @llvm.dbg.value(metadata, metadata, metadata) #1

attributes #0 = { noinline nounwind uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { nofree nosync nounwind readnone speculatable willreturn }
attributes #2 = { argmemonly nofree nounwind willreturn writeonly }
attributes #3 = { nofree nosync nounwind willreturn }
attributes #4 = { nounwind "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #5 = { noreturn nounwind "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #6 = { nounwind }
attributes #7 = { noreturn nounwind }

!llvm.dbg.cu = !{!2}
!llvm.module.flags = !{!46, !47, !48, !49, !50, !51, !52}
!llvm.ident = !{!53}

!0 = !DIGlobalVariableExpression(var: !1, expr: !DIExpression())
!1 = distinct !DIGlobalVariable(name: "n", scope: !2, file: !11, line: 145, type: !12, isLocal: false, isDefinition: true)
!2 = distinct !DICompileUnit(language: DW_LANG_C99, file: !3, producer: "Ubuntu clang version 14.0.0-1ubuntu1.1", isOptimized: false, runtimeVersion: 0, emissionKind: FullDebug, retainedTypes: !4, globals: !8, splitDebugInlining: false, nameTableKind: None)
!3 = !DIFile(filename: "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/affine-bounds-20260929/suite/adi/source/workload.c", directory: "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/affine-bounds-20260929/suite/adi/analysis-p", checksumkind: CSK_MD5, checksum: "c6e922ce80aaeeca85ac530025af18dd")
!4 = !{!5, !6, !7}
!5 = !DIBasicType(name: "double", size: 64, encoding: DW_ATE_float)
!6 = !DIBasicType(name: "unsigned int", size: 32, encoding: DW_ATE_unsigned)
!7 = !DIBasicType(name: "unsigned char", size: 8, encoding: DW_ATE_unsigned_char)
!8 = !{!0, !9, !13, !26, !30, !33, !38, !40, !42, !44}
!9 = !DIGlobalVariableExpression(var: !10, expr: !DIExpression())
!10 = distinct !DIGlobalVariable(name: "tsteps", scope: !2, file: !11, line: 146, type: !12, isLocal: false, isDefinition: true)
!11 = !DIFile(filename: "source/workload.c", directory: "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/affine-bounds-20260929/suite/adi", checksumkind: CSK_MD5, checksum: "c6e922ce80aaeeca85ac530025af18dd")
!12 = !DIBasicType(name: "int", size: 32, encoding: DW_ATE_signed)
!13 = !DIGlobalVariableExpression(var: !14, expr: !DIExpression())
!14 = distinct !DIGlobalVariable(name: "workload_jobs", scope: !2, file: !11, line: 166, type: !15, isLocal: false, isDefinition: true)
!15 = !DICompositeType(tag: DW_TAG_array_type, baseType: !16, size: 64, elements: !24)
!16 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !17)
!17 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !18, size: 64)
!18 = !DISubroutineType(types: !19)
!19 = !{!20}
!20 = !DIDerivedType(tag: DW_TAG_typedef, name: "uint32_t", file: !21, line: 26, baseType: !22)
!21 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/stdint-uintn.h", directory: "", checksumkind: CSK_MD5, checksum: "2bf2ae53c58c01b1a1b9383b5195125c")
!22 = !DIDerivedType(tag: DW_TAG_typedef, name: "__uint32_t", file: !23, line: 42, baseType: !6)
!23 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/types.h", directory: "", checksumkind: CSK_MD5, checksum: "d108b5f93a74c50510d7d9bc0ab36df9")
!24 = !{!25}
!25 = !DISubrange(count: 1)
!26 = !DIGlobalVariableExpression(var: !27, expr: !DIExpression())
!27 = distinct !DIGlobalVariable(name: "workload_expected", scope: !2, file: !11, line: 170, type: !28, isLocal: false, isDefinition: true)
!28 = !DICompositeType(tag: DW_TAG_array_type, baseType: !29, size: 32, elements: !24)
!29 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !20)
!30 = !DIGlobalVariableExpression(var: !31, expr: !DIExpression())
!31 = distinct !DIGlobalVariable(name: "pb_hash", scope: !2, file: !32, line: 9, type: !20, isLocal: true, isDefinition: true)
!32 = !DIFile(filename: "source/adapter.h", directory: "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/affine-bounds-20260929/suite/adi", checksumkind: CSK_MD5, checksum: "26a6068928b2092758f244a9d00163d7")
!33 = !DIGlobalVariableExpression(var: !34, expr: !DIExpression())
!34 = distinct !DIGlobalVariable(name: "u", scope: !2, file: !11, line: 34, type: !35, isLocal: false, isDefinition: true, align: 512)
!35 = !DICompositeType(tag: DW_TAG_array_type, baseType: !5, size: 2560000, elements: !36)
!36 = !{!37, !37}
!37 = !DISubrange(count: 200)
!38 = !DIGlobalVariableExpression(var: !39, expr: !DIExpression())
!39 = distinct !DIGlobalVariable(name: "v", scope: !2, file: !11, line: 35, type: !35, isLocal: false, isDefinition: true, align: 512)
!40 = !DIGlobalVariableExpression(var: !41, expr: !DIExpression())
!41 = distinct !DIGlobalVariable(name: "p", scope: !2, file: !11, line: 36, type: !35, isLocal: false, isDefinition: true, align: 512)
!42 = !DIGlobalVariableExpression(var: !43, expr: !DIExpression())
!43 = distinct !DIGlobalVariable(name: "q", scope: !2, file: !11, line: 37, type: !35, isLocal: false, isDefinition: true, align: 512)
!44 = !DIGlobalVariableExpression(var: !45, expr: !DIExpression())
!45 = distinct !DIGlobalVariable(name: "pb_emit", scope: !2, file: !32, line: 10, type: !12, isLocal: true, isDefinition: true)
!46 = !{i32 7, !"Dwarf Version", i32 5}
!47 = !{i32 2, !"Debug Info Version", i32 3}
!48 = !{i32 1, !"wchar_size", i32 4}
!49 = !{i32 7, !"PIC Level", i32 2}
!50 = !{i32 7, !"PIE Level", i32 2}
!51 = !{i32 7, !"uwtable", i32 1}
!52 = !{i32 7, !"frame-pointer", i32 2}
!53 = !{!"Ubuntu clang version 14.0.0-1ubuntu1.1"}
!54 = distinct !DISubprogram(name: "workload_prepare", scope: !11, file: !11, line: 147, type: !55, scopeLine: 147, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !2, retainedNodes: !57)
!55 = !DISubroutineType(types: !56)
!56 = !{null}
!57 = !{}
!58 = !DILocation(line: 147, column: 30, scope: !54)
!59 = distinct !DISubprogram(name: "workload_reset", scope: !11, file: !11, line: 148, type: !60, scopeLine: 148, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !2, retainedNodes: !57)
!60 = !DISubroutineType(types: !61)
!61 = !{null, !6}
!62 = !DILocalVariable(name: "task", arg: 1, scope: !59, file: !11, line: 148, type: !6)
!63 = !DILocation(line: 0, scope: !59)
!64 = !DILocation(line: 150, column: 3, scope: !59)
!65 = !DILocation(line: 151, column: 3, scope: !59)
!66 = !DILocation(line: 152, column: 3, scope: !59)
!67 = !DILocation(line: 153, column: 3, scope: !59)
!68 = !DILocation(line: 154, column: 15, scope: !59)
!69 = !DILocation(line: 154, column: 3, scope: !59)
!70 = !DILocation(line: 155, column: 1, scope: !59)
!71 = distinct !DISubprogram(name: "init_array", scope: !11, file: !11, line: 39, type: !72, scopeLine: 41, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition, unit: !2, retainedNodes: !57)
!72 = !DISubroutineType(types: !73)
!73 = !{null, !12, !74}
!74 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !75, size: 64)
!75 = !DICompositeType(tag: DW_TAG_array_type, baseType: !5, size: 12800, elements: !76)
!76 = !{!37}
!77 = !DILocalVariable(name: "n", arg: 1, scope: !71, file: !11, line: 39, type: !12)
!78 = !DILocation(line: 0, scope: !71)
!79 = !DILocalVariable(name: "u", arg: 2, scope: !71, file: !11, line: 40, type: !74)
!80 = !DILocalVariable(name: "i", scope: !71, file: !11, line: 42, type: !12)
!81 = !DILocation(line: 44, column: 8, scope: !82)
!82 = distinct !DILexicalBlock(scope: !71, file: !11, line: 44, column: 3)
!83 = !DILocation(line: 0, scope: !82)
!84 = !DILocation(line: 44, column: 17, scope: !85)
!85 = distinct !DILexicalBlock(scope: !82, file: !11, line: 44, column: 3)
!86 = !DILocation(line: 44, column: 3, scope: !82)
!87 = !DILocalVariable(name: "j", scope: !71, file: !11, line: 42, type: !12)
!88 = !DILocation(line: 45, column: 10, scope: !89)
!89 = distinct !DILexicalBlock(scope: !85, file: !11, line: 45, column: 5)
!90 = !DILocation(line: 0, scope: !89)
!91 = !DILocation(line: 45, column: 19, scope: !92)
!92 = distinct !DILexicalBlock(scope: !89, file: !11, line: 45, column: 5)
!93 = !DILocation(line: 45, column: 5, scope: !89)
!94 = !DILocation(line: 47, column: 27, scope: !95)
!95 = distinct !DILexicalBlock(scope: !92, file: !11, line: 46, column: 7)
!96 = !DILocation(line: 47, column: 30, scope: !95)
!97 = !DILocation(line: 47, column: 13, scope: !95)
!98 = !DILocation(line: 47, column: 36, scope: !95)
!99 = !DILocation(line: 47, column: 34, scope: !95)
!100 = !DILocation(line: 47, column: 2, scope: !95)
!101 = !DILocation(line: 47, column: 10, scope: !95)
!102 = !DILocation(line: 48, column: 7, scope: !95)
!103 = !DILocation(line: 45, column: 25, scope: !92)
!104 = !DILocation(line: 45, column: 5, scope: !92)
!105 = distinct !{!105, !93, !106, !107}
!106 = !DILocation(line: 48, column: 7, scope: !89)
!107 = !{!"llvm.loop.mustprogress"}
!108 = !DILocation(line: 44, column: 23, scope: !85)
!109 = !DILocation(line: 44, column: 3, scope: !85)
!110 = distinct !{!110, !86, !111, !107}
!111 = !DILocation(line: 48, column: 7, scope: !82)
!112 = !DILocation(line: 49, column: 1, scope: !71)
!113 = distinct !DISubprogram(name: "task_job_polybench", scope: !11, file: !11, line: 156, type: !18, scopeLine: 156, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !2, retainedNodes: !57)
!114 = !DILocation(line: 157, column: 15, scope: !113)
!115 = !DILocation(line: 157, column: 23, scope: !113)
!116 = !DILocalVariable(name: "tsteps", arg: 1, scope: !117, file: !11, line: 80, type: !12)
!117 = distinct !DISubprogram(name: "kernel_adi", scope: !11, file: !11, line: 80, type: !118, scopeLine: 85, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition, unit: !2, retainedNodes: !57)
!118 = !DISubroutineType(types: !119)
!119 = !{null, !12, !12, !74, !74, !74, !74}
!120 = !DILocation(line: 0, scope: !117, inlinedAt: !121)
!121 = distinct !DILocation(line: 157, column: 3, scope: !113)
!122 = !DILocalVariable(name: "n", arg: 2, scope: !117, file: !11, line: 80, type: !12)
!123 = !DILocalVariable(name: "u", arg: 3, scope: !117, file: !11, line: 81, type: !74)
!124 = !DILocalVariable(name: "v", arg: 4, scope: !117, file: !11, line: 82, type: !74)
!125 = !DILocalVariable(name: "p", arg: 5, scope: !117, file: !11, line: 83, type: !74)
!126 = !DILocalVariable(name: "q", arg: 6, scope: !117, file: !11, line: 84, type: !74)
!127 = !DILocalVariable(name: "DX", scope: !117, file: !11, line: 87, type: !5)
!128 = !DILocalVariable(name: "DY", scope: !117, file: !11, line: 87, type: !5)
!129 = !DILocalVariable(name: "DT", scope: !117, file: !11, line: 87, type: !5)
!130 = !DILocalVariable(name: "B1", scope: !117, file: !11, line: 88, type: !5)
!131 = !DILocalVariable(name: "B2", scope: !117, file: !11, line: 88, type: !5)
!132 = !DILocation(line: 99, column: 13, scope: !117, inlinedAt: !121)
!133 = !DILocation(line: 99, column: 24, scope: !117, inlinedAt: !121)
!134 = !DILocation(line: 99, column: 18, scope: !117, inlinedAt: !121)
!135 = !DILocalVariable(name: "mul1", scope: !117, file: !11, line: 89, type: !5)
!136 = !DILocation(line: 100, column: 13, scope: !117, inlinedAt: !121)
!137 = !DILocation(line: 100, column: 24, scope: !117, inlinedAt: !121)
!138 = !DILocation(line: 100, column: 18, scope: !117, inlinedAt: !121)
!139 = !DILocalVariable(name: "mul2", scope: !117, file: !11, line: 89, type: !5)
!140 = !DILocation(line: 102, column: 7, scope: !117, inlinedAt: !121)
!141 = !DILocation(line: 102, column: 13, scope: !117, inlinedAt: !121)
!142 = !DILocalVariable(name: "a", scope: !117, file: !11, line: 90, type: !5)
!143 = !DILocation(line: 103, column: 22, scope: !117, inlinedAt: !121)
!144 = !DILocalVariable(name: "b", scope: !117, file: !11, line: 90, type: !5)
!145 = !DILocalVariable(name: "c", scope: !117, file: !11, line: 90, type: !5)
!146 = !DILocation(line: 105, column: 7, scope: !117, inlinedAt: !121)
!147 = !DILocation(line: 105, column: 13, scope: !117, inlinedAt: !121)
!148 = !DILocalVariable(name: "d", scope: !117, file: !11, line: 90, type: !5)
!149 = !DILocation(line: 106, column: 22, scope: !117, inlinedAt: !121)
!150 = !DILocalVariable(name: "e", scope: !117, file: !11, line: 90, type: !5)
!151 = !DILocalVariable(name: "f", scope: !117, file: !11, line: 90, type: !5)
!152 = !DILocalVariable(name: "t", scope: !117, file: !11, line: 86, type: !12)
!153 = !DILocation(line: 109, column: 7, scope: !154, inlinedAt: !121)
!154 = distinct !DILexicalBlock(scope: !117, file: !11, line: 109, column: 2)
!155 = !DILocation(line: 0, scope: !154, inlinedAt: !121)
!156 = !DILocation(line: 109, column: 13, scope: !157, inlinedAt: !121)
!157 = distinct !DILexicalBlock(scope: !154, file: !11, line: 109, column: 2)
!158 = !DILocation(line: 109, column: 2, scope: !154, inlinedAt: !121)
!159 = !DILocalVariable(name: "i", scope: !117, file: !11, line: 86, type: !12)
!160 = !DILocation(line: 111, column: 10, scope: !161, inlinedAt: !121)
!161 = distinct !DILexicalBlock(scope: !162, file: !11, line: 111, column: 5)
!162 = distinct !DILexicalBlock(scope: !157, file: !11, line: 109, column: 32)
!163 = !DILocation(line: 0, scope: !161, inlinedAt: !121)
!164 = !DILocation(line: 111, column: 16, scope: !165, inlinedAt: !121)
!165 = distinct !DILexicalBlock(scope: !161, file: !11, line: 111, column: 5)
!166 = !DILocation(line: 111, column: 5, scope: !161, inlinedAt: !121)
!167 = !DILocation(line: 112, column: 7, scope: !168, inlinedAt: !121)
!168 = distinct !DILexicalBlock(scope: !165, file: !11, line: 111, column: 31)
!169 = !DILocation(line: 112, column: 15, scope: !168, inlinedAt: !121)
!170 = !DILocation(line: 113, column: 7, scope: !168, inlinedAt: !121)
!171 = !DILocation(line: 113, column: 15, scope: !168, inlinedAt: !121)
!172 = !DILocation(line: 114, column: 17, scope: !168, inlinedAt: !121)
!173 = !DILocation(line: 114, column: 7, scope: !168, inlinedAt: !121)
!174 = !DILocation(line: 114, column: 15, scope: !168, inlinedAt: !121)
!175 = !DILocalVariable(name: "j", scope: !117, file: !11, line: 86, type: !12)
!176 = !DILocation(line: 115, column: 12, scope: !177, inlinedAt: !121)
!177 = distinct !DILexicalBlock(scope: !168, file: !11, line: 115, column: 7)
!178 = !DILocation(line: 0, scope: !177, inlinedAt: !121)
!179 = !DILocation(line: 115, column: 18, scope: !180, inlinedAt: !121)
!180 = distinct !DILexicalBlock(scope: !177, file: !11, line: 115, column: 7)
!181 = !DILocation(line: 115, column: 7, scope: !177, inlinedAt: !121)
!182 = !DILocation(line: 116, column: 19, scope: !183, inlinedAt: !121)
!183 = distinct !DILexicalBlock(scope: !180, file: !11, line: 115, column: 33)
!184 = !DILocation(line: 116, column: 27, scope: !183, inlinedAt: !121)
!185 = !DILocation(line: 116, column: 33, scope: !183, inlinedAt: !121)
!186 = !DILocation(line: 116, column: 26, scope: !183, inlinedAt: !121)
!187 = !DILocation(line: 116, column: 36, scope: !183, inlinedAt: !121)
!188 = !DILocation(line: 116, column: 22, scope: !183, inlinedAt: !121)
!189 = !DILocation(line: 116, column: 9, scope: !183, inlinedAt: !121)
!190 = !DILocation(line: 116, column: 17, scope: !183, inlinedAt: !121)
!191 = !DILocation(line: 117, column: 20, scope: !183, inlinedAt: !121)
!192 = !DILocation(line: 117, column: 23, scope: !183, inlinedAt: !121)
!193 = !DILocation(line: 117, column: 29, scope: !183, inlinedAt: !121)
!194 = !DILocation(line: 117, column: 22, scope: !183, inlinedAt: !121)
!195 = !DILocation(line: 117, column: 65, scope: !183, inlinedAt: !121)
!196 = !DILocation(line: 117, column: 49, scope: !183, inlinedAt: !121)
!197 = !DILocation(line: 117, column: 69, scope: !183, inlinedAt: !121)
!198 = !DILocation(line: 117, column: 68, scope: !183, inlinedAt: !121)
!199 = !DILocation(line: 117, column: 32, scope: !183, inlinedAt: !121)
!200 = !DILocation(line: 117, column: 81, scope: !183, inlinedAt: !121)
!201 = !DILocation(line: 117, column: 87, scope: !183, inlinedAt: !121)
!202 = !DILocation(line: 117, column: 80, scope: !183, inlinedAt: !121)
!203 = !DILocation(line: 117, column: 77, scope: !183, inlinedAt: !121)
!204 = !DILocation(line: 117, column: 93, scope: !183, inlinedAt: !121)
!205 = !DILocation(line: 117, column: 99, scope: !183, inlinedAt: !121)
!206 = !DILocation(line: 117, column: 92, scope: !183, inlinedAt: !121)
!207 = !DILocation(line: 117, column: 90, scope: !183, inlinedAt: !121)
!208 = !DILocation(line: 117, column: 107, scope: !183, inlinedAt: !121)
!209 = !DILocation(line: 117, column: 113, scope: !183, inlinedAt: !121)
!210 = !DILocation(line: 117, column: 106, scope: !183, inlinedAt: !121)
!211 = !DILocation(line: 117, column: 116, scope: !183, inlinedAt: !121)
!212 = !DILocation(line: 117, column: 103, scope: !183, inlinedAt: !121)
!213 = !DILocation(line: 117, column: 9, scope: !183, inlinedAt: !121)
!214 = !DILocation(line: 117, column: 17, scope: !183, inlinedAt: !121)
!215 = !DILocation(line: 115, column: 29, scope: !180, inlinedAt: !121)
!216 = !DILocation(line: 115, column: 7, scope: !180, inlinedAt: !121)
!217 = distinct !{!217, !181, !218, !107}
!218 = !DILocation(line: 118, column: 7, scope: !177, inlinedAt: !121)
!219 = !DILocation(line: 120, column: 7, scope: !168, inlinedAt: !121)
!220 = !DILocation(line: 120, column: 21, scope: !168, inlinedAt: !121)
!221 = !DILocation(line: 121, column: 12, scope: !222, inlinedAt: !121)
!222 = distinct !DILexicalBlock(scope: !168, file: !11, line: 121, column: 7)
!223 = !DILocation(line: 0, scope: !222, inlinedAt: !121)
!224 = !DILocation(line: 121, column: 24, scope: !225, inlinedAt: !121)
!225 = distinct !DILexicalBlock(scope: !222, file: !11, line: 121, column: 7)
!226 = !DILocation(line: 121, column: 7, scope: !222, inlinedAt: !121)
!227 = !DILocation(line: 122, column: 19, scope: !228, inlinedAt: !121)
!228 = distinct !DILexicalBlock(scope: !225, file: !11, line: 121, column: 34)
!229 = !DILocation(line: 122, column: 32, scope: !228, inlinedAt: !121)
!230 = !DILocation(line: 122, column: 29, scope: !228, inlinedAt: !121)
!231 = !DILocation(line: 122, column: 27, scope: !228, inlinedAt: !121)
!232 = !DILocation(line: 122, column: 41, scope: !228, inlinedAt: !121)
!233 = !DILocation(line: 122, column: 39, scope: !228, inlinedAt: !121)
!234 = !DILocation(line: 122, column: 9, scope: !228, inlinedAt: !121)
!235 = !DILocation(line: 122, column: 17, scope: !228, inlinedAt: !121)
!236 = !DILocation(line: 121, column: 30, scope: !225, inlinedAt: !121)
!237 = !DILocation(line: 121, column: 7, scope: !225, inlinedAt: !121)
!238 = distinct !{!238, !226, !239, !107}
!239 = !DILocation(line: 123, column: 7, scope: !222, inlinedAt: !121)
!240 = !DILocation(line: 111, column: 27, scope: !165, inlinedAt: !121)
!241 = !DILocation(line: 111, column: 5, scope: !165, inlinedAt: !121)
!242 = distinct !{!242, !166, !243, !107}
!243 = !DILocation(line: 124, column: 5, scope: !161, inlinedAt: !121)
!244 = !DILocation(line: 126, column: 10, scope: !245, inlinedAt: !121)
!245 = distinct !DILexicalBlock(scope: !162, file: !11, line: 126, column: 5)
!246 = !DILocation(line: 0, scope: !245, inlinedAt: !121)
!247 = !DILocation(line: 126, column: 16, scope: !248, inlinedAt: !121)
!248 = distinct !DILexicalBlock(scope: !245, file: !11, line: 126, column: 5)
!249 = !DILocation(line: 126, column: 5, scope: !245, inlinedAt: !121)
!250 = !DILocation(line: 127, column: 7, scope: !251, inlinedAt: !121)
!251 = distinct !DILexicalBlock(scope: !248, file: !11, line: 126, column: 31)
!252 = !DILocation(line: 127, column: 15, scope: !251, inlinedAt: !121)
!253 = !DILocation(line: 128, column: 7, scope: !251, inlinedAt: !121)
!254 = !DILocation(line: 128, column: 15, scope: !251, inlinedAt: !121)
!255 = !DILocation(line: 129, column: 17, scope: !251, inlinedAt: !121)
!256 = !DILocation(line: 129, column: 7, scope: !251, inlinedAt: !121)
!257 = !DILocation(line: 129, column: 15, scope: !251, inlinedAt: !121)
!258 = !DILocation(line: 130, column: 12, scope: !259, inlinedAt: !121)
!259 = distinct !DILexicalBlock(scope: !251, file: !11, line: 130, column: 7)
!260 = !DILocation(line: 0, scope: !259, inlinedAt: !121)
!261 = !DILocation(line: 130, column: 18, scope: !262, inlinedAt: !121)
!262 = distinct !DILexicalBlock(scope: !259, file: !11, line: 130, column: 7)
!263 = !DILocation(line: 130, column: 7, scope: !259, inlinedAt: !121)
!264 = !DILocation(line: 131, column: 19, scope: !265, inlinedAt: !121)
!265 = distinct !DILexicalBlock(scope: !262, file: !11, line: 130, column: 33)
!266 = !DILocation(line: 131, column: 27, scope: !265, inlinedAt: !121)
!267 = !DILocation(line: 131, column: 33, scope: !265, inlinedAt: !121)
!268 = !DILocation(line: 131, column: 26, scope: !265, inlinedAt: !121)
!269 = !DILocation(line: 131, column: 36, scope: !265, inlinedAt: !121)
!270 = !DILocation(line: 131, column: 22, scope: !265, inlinedAt: !121)
!271 = !DILocation(line: 131, column: 9, scope: !265, inlinedAt: !121)
!272 = !DILocation(line: 131, column: 17, scope: !265, inlinedAt: !121)
!273 = !DILocation(line: 132, column: 20, scope: !265, inlinedAt: !121)
!274 = !DILocation(line: 132, column: 26, scope: !265, inlinedAt: !121)
!275 = !DILocation(line: 132, column: 23, scope: !265, inlinedAt: !121)
!276 = !DILocation(line: 132, column: 22, scope: !265, inlinedAt: !121)
!277 = !DILocation(line: 132, column: 65, scope: !265, inlinedAt: !121)
!278 = !DILocation(line: 132, column: 49, scope: !265, inlinedAt: !121)
!279 = !DILocation(line: 132, column: 69, scope: !265, inlinedAt: !121)
!280 = !DILocation(line: 132, column: 68, scope: !265, inlinedAt: !121)
!281 = !DILocation(line: 132, column: 32, scope: !265, inlinedAt: !121)
!282 = !DILocation(line: 132, column: 84, scope: !265, inlinedAt: !121)
!283 = !DILocation(line: 132, column: 81, scope: !265, inlinedAt: !121)
!284 = !DILocation(line: 132, column: 80, scope: !265, inlinedAt: !121)
!285 = !DILocation(line: 132, column: 77, scope: !265, inlinedAt: !121)
!286 = !DILocation(line: 132, column: 93, scope: !265, inlinedAt: !121)
!287 = !DILocation(line: 132, column: 99, scope: !265, inlinedAt: !121)
!288 = !DILocation(line: 132, column: 92, scope: !265, inlinedAt: !121)
!289 = !DILocation(line: 132, column: 90, scope: !265, inlinedAt: !121)
!290 = !DILocation(line: 132, column: 107, scope: !265, inlinedAt: !121)
!291 = !DILocation(line: 132, column: 113, scope: !265, inlinedAt: !121)
!292 = !DILocation(line: 132, column: 106, scope: !265, inlinedAt: !121)
!293 = !DILocation(line: 132, column: 116, scope: !265, inlinedAt: !121)
!294 = !DILocation(line: 132, column: 103, scope: !265, inlinedAt: !121)
!295 = !DILocation(line: 132, column: 9, scope: !265, inlinedAt: !121)
!296 = !DILocation(line: 132, column: 17, scope: !265, inlinedAt: !121)
!297 = !DILocation(line: 130, column: 29, scope: !262, inlinedAt: !121)
!298 = !DILocation(line: 130, column: 7, scope: !262, inlinedAt: !121)
!299 = distinct !{!299, !263, !300, !107}
!300 = !DILocation(line: 133, column: 7, scope: !259, inlinedAt: !121)
!301 = !DILocation(line: 134, column: 7, scope: !251, inlinedAt: !121)
!302 = !DILocation(line: 134, column: 21, scope: !251, inlinedAt: !121)
!303 = !DILocation(line: 135, column: 12, scope: !304, inlinedAt: !121)
!304 = distinct !DILexicalBlock(scope: !251, file: !11, line: 135, column: 7)
!305 = !DILocation(line: 0, scope: !304, inlinedAt: !121)
!306 = !DILocation(line: 135, column: 24, scope: !307, inlinedAt: !121)
!307 = distinct !DILexicalBlock(scope: !304, file: !11, line: 135, column: 7)
!308 = !DILocation(line: 135, column: 7, scope: !304, inlinedAt: !121)
!309 = !DILocation(line: 136, column: 19, scope: !310, inlinedAt: !121)
!310 = distinct !DILexicalBlock(scope: !307, file: !11, line: 135, column: 34)
!311 = !DILocation(line: 136, column: 29, scope: !310, inlinedAt: !121)
!312 = !DILocation(line: 136, column: 35, scope: !310, inlinedAt: !121)
!313 = !DILocation(line: 136, column: 27, scope: !310, inlinedAt: !121)
!314 = !DILocation(line: 136, column: 41, scope: !310, inlinedAt: !121)
!315 = !DILocation(line: 136, column: 39, scope: !310, inlinedAt: !121)
!316 = !DILocation(line: 136, column: 9, scope: !310, inlinedAt: !121)
!317 = !DILocation(line: 136, column: 17, scope: !310, inlinedAt: !121)
!318 = !DILocation(line: 135, column: 30, scope: !307, inlinedAt: !121)
!319 = !DILocation(line: 135, column: 7, scope: !307, inlinedAt: !121)
!320 = distinct !{!320, !308, !321, !107}
!321 = !DILocation(line: 137, column: 7, scope: !304, inlinedAt: !121)
!322 = !DILocation(line: 126, column: 27, scope: !248, inlinedAt: !121)
!323 = !DILocation(line: 126, column: 5, scope: !248, inlinedAt: !121)
!324 = distinct !{!324, !249, !325, !107}
!325 = !DILocation(line: 138, column: 5, scope: !245, inlinedAt: !121)
!326 = !DILocation(line: 109, column: 28, scope: !157, inlinedAt: !121)
!327 = !DILocation(line: 109, column: 2, scope: !157, inlinedAt: !121)
!328 = distinct !{!328, !158, !329, !107}
!329 = !DILocation(line: 139, column: 3, scope: !154, inlinedAt: !121)
!330 = !DILocation(line: 158, column: 3, scope: !113)
!331 = distinct !DISubprogram(name: "workload_checksum", scope: !11, file: !11, line: 160, type: !332, scopeLine: 160, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !2, retainedNodes: !57)
!332 = !DISubroutineType(types: !333)
!333 = !{!20, !6}
!334 = !DILocalVariable(name: "task", arg: 1, scope: !331, file: !11, line: 160, type: !6)
!335 = !DILocation(line: 0, scope: !331)
!336 = !DILocation(line: 162, column: 11, scope: !331)
!337 = !DILocation(line: 163, column: 15, scope: !331)
!338 = !DILocation(line: 163, column: 3, scope: !331)
!339 = !DILocation(line: 164, column: 10, scope: !331)
!340 = !DILocation(line: 164, column: 3, scope: !331)
!341 = distinct !DISubprogram(name: "print_array", scope: !11, file: !11, line: 55, type: !72, scopeLine: 58, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition, unit: !2, retainedNodes: !57)
!342 = !DILocalVariable(name: "n", arg: 1, scope: !341, file: !11, line: 55, type: !12)
!343 = !DILocation(line: 0, scope: !341)
!344 = !DILocalVariable(name: "u", arg: 2, scope: !341, file: !11, line: 56, type: !74)
!345 = !DILocation(line: 61, column: 3, scope: !341)
!346 = !DILocation(line: 62, column: 3, scope: !341)
!347 = !DILocalVariable(name: "i", scope: !341, file: !11, line: 59, type: !12)
!348 = !DILocation(line: 63, column: 8, scope: !349)
!349 = distinct !DILexicalBlock(scope: !341, file: !11, line: 63, column: 3)
!350 = !DILocation(line: 0, scope: !349)
!351 = !DILocation(line: 63, column: 17, scope: !352)
!352 = distinct !DILexicalBlock(scope: !349, file: !11, line: 63, column: 3)
!353 = !DILocation(line: 63, column: 3, scope: !349)
!354 = !DILocalVariable(name: "j", scope: !341, file: !11, line: 59, type: !12)
!355 = !DILocation(line: 64, column: 10, scope: !356)
!356 = distinct !DILexicalBlock(scope: !352, file: !11, line: 64, column: 5)
!357 = !DILocation(line: 0, scope: !356)
!358 = !DILocation(line: 64, column: 19, scope: !359)
!359 = distinct !DILexicalBlock(scope: !356, file: !11, line: 64, column: 5)
!360 = !DILocation(line: 64, column: 5, scope: !356)
!361 = !DILocation(line: 65, column: 14, scope: !362)
!362 = distinct !DILexicalBlock(scope: !363, file: !11, line: 65, column: 11)
!363 = distinct !DILexicalBlock(scope: !359, file: !11, line: 64, column: 29)
!364 = !DILocation(line: 65, column: 18, scope: !362)
!365 = !DILocation(line: 65, column: 23, scope: !362)
!366 = !DILocation(line: 65, column: 28, scope: !362)
!367 = !DILocation(line: 65, column: 11, scope: !363)
!368 = !DILocation(line: 65, column: 42, scope: !362)
!369 = !DILocation(line: 65, column: 34, scope: !362)
!370 = !DILocation(line: 66, column: 16, scope: !363)
!371 = !DILocation(line: 66, column: 61, scope: !363)
!372 = !DILocation(line: 66, column: 7, scope: !363)
!373 = !DILocation(line: 67, column: 5, scope: !363)
!374 = !DILocation(line: 64, column: 25, scope: !359)
!375 = !DILocation(line: 64, column: 5, scope: !359)
!376 = distinct !{!376, !360, !377, !107}
!377 = !DILocation(line: 67, column: 5, scope: !356)
!378 = !DILocation(line: 63, column: 23, scope: !352)
!379 = !DILocation(line: 63, column: 3, scope: !352)
!380 = distinct !{!380, !353, !381, !107}
!381 = !DILocation(line: 67, column: 5, scope: !349)
!382 = !DILocation(line: 68, column: 3, scope: !341)
!383 = !DILocation(line: 69, column: 3, scope: !341)
!384 = !DILocation(line: 70, column: 1, scope: !341)
!385 = distinct !DISubprogram(name: "pb_fprintf", scope: !32, file: !32, line: 13, type: !386, scopeLine: 14, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition, unit: !2, retainedNodes: !57)
!386 = !DISubroutineType(types: !387)
!387 = !{!12, !388, !447, null}
!388 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !389, size: 64)
!389 = !DIDerivedType(tag: DW_TAG_typedef, name: "FILE", file: !390, line: 7, baseType: !391)
!390 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/types/FILE.h", directory: "", checksumkind: CSK_MD5, checksum: "571f9fb6223c42439075fdde11a0de5d")
!391 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "_IO_FILE", file: !392, line: 49, size: 1728, elements: !393)
!392 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/types/struct_FILE.h", directory: "", checksumkind: CSK_MD5, checksum: "1bad07471b7974df4ecc1d1c2ca207e6")
!393 = !{!394, !395, !398, !399, !400, !401, !402, !403, !404, !405, !406, !407, !408, !411, !413, !414, !415, !418, !420, !422, !424, !427, !429, !432, !435, !436, !438, !442, !443}
!394 = !DIDerivedType(tag: DW_TAG_member, name: "_flags", scope: !391, file: !392, line: 51, baseType: !12, size: 32)
!395 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_read_ptr", scope: !391, file: !392, line: 54, baseType: !396, size: 64, offset: 64)
!396 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !397, size: 64)
!397 = !DIBasicType(name: "char", size: 8, encoding: DW_ATE_signed_char)
!398 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_read_end", scope: !391, file: !392, line: 55, baseType: !396, size: 64, offset: 128)
!399 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_read_base", scope: !391, file: !392, line: 56, baseType: !396, size: 64, offset: 192)
!400 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_write_base", scope: !391, file: !392, line: 57, baseType: !396, size: 64, offset: 256)
!401 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_write_ptr", scope: !391, file: !392, line: 58, baseType: !396, size: 64, offset: 320)
!402 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_write_end", scope: !391, file: !392, line: 59, baseType: !396, size: 64, offset: 384)
!403 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_buf_base", scope: !391, file: !392, line: 60, baseType: !396, size: 64, offset: 448)
!404 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_buf_end", scope: !391, file: !392, line: 61, baseType: !396, size: 64, offset: 512)
!405 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_save_base", scope: !391, file: !392, line: 64, baseType: !396, size: 64, offset: 576)
!406 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_backup_base", scope: !391, file: !392, line: 65, baseType: !396, size: 64, offset: 640)
!407 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_save_end", scope: !391, file: !392, line: 66, baseType: !396, size: 64, offset: 704)
!408 = !DIDerivedType(tag: DW_TAG_member, name: "_markers", scope: !391, file: !392, line: 68, baseType: !409, size: 64, offset: 768)
!409 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !410, size: 64)
!410 = !DICompositeType(tag: DW_TAG_structure_type, name: "_IO_marker", file: !392, line: 36, flags: DIFlagFwdDecl)
!411 = !DIDerivedType(tag: DW_TAG_member, name: "_chain", scope: !391, file: !392, line: 70, baseType: !412, size: 64, offset: 832)
!412 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !391, size: 64)
!413 = !DIDerivedType(tag: DW_TAG_member, name: "_fileno", scope: !391, file: !392, line: 72, baseType: !12, size: 32, offset: 896)
!414 = !DIDerivedType(tag: DW_TAG_member, name: "_flags2", scope: !391, file: !392, line: 73, baseType: !12, size: 32, offset: 928)
!415 = !DIDerivedType(tag: DW_TAG_member, name: "_old_offset", scope: !391, file: !392, line: 74, baseType: !416, size: 64, offset: 960)
!416 = !DIDerivedType(tag: DW_TAG_typedef, name: "__off_t", file: !23, line: 152, baseType: !417)
!417 = !DIBasicType(name: "long", size: 64, encoding: DW_ATE_signed)
!418 = !DIDerivedType(tag: DW_TAG_member, name: "_cur_column", scope: !391, file: !392, line: 77, baseType: !419, size: 16, offset: 1024)
!419 = !DIBasicType(name: "unsigned short", size: 16, encoding: DW_ATE_unsigned)
!420 = !DIDerivedType(tag: DW_TAG_member, name: "_vtable_offset", scope: !391, file: !392, line: 78, baseType: !421, size: 8, offset: 1040)
!421 = !DIBasicType(name: "signed char", size: 8, encoding: DW_ATE_signed_char)
!422 = !DIDerivedType(tag: DW_TAG_member, name: "_shortbuf", scope: !391, file: !392, line: 79, baseType: !423, size: 8, offset: 1048)
!423 = !DICompositeType(tag: DW_TAG_array_type, baseType: !397, size: 8, elements: !24)
!424 = !DIDerivedType(tag: DW_TAG_member, name: "_lock", scope: !391, file: !392, line: 81, baseType: !425, size: 64, offset: 1088)
!425 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !426, size: 64)
!426 = !DIDerivedType(tag: DW_TAG_typedef, name: "_IO_lock_t", file: !392, line: 43, baseType: null)
!427 = !DIDerivedType(tag: DW_TAG_member, name: "_offset", scope: !391, file: !392, line: 89, baseType: !428, size: 64, offset: 1152)
!428 = !DIDerivedType(tag: DW_TAG_typedef, name: "__off64_t", file: !23, line: 153, baseType: !417)
!429 = !DIDerivedType(tag: DW_TAG_member, name: "_codecvt", scope: !391, file: !392, line: 91, baseType: !430, size: 64, offset: 1216)
!430 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !431, size: 64)
!431 = !DICompositeType(tag: DW_TAG_structure_type, name: "_IO_codecvt", file: !392, line: 37, flags: DIFlagFwdDecl)
!432 = !DIDerivedType(tag: DW_TAG_member, name: "_wide_data", scope: !391, file: !392, line: 92, baseType: !433, size: 64, offset: 1280)
!433 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !434, size: 64)
!434 = !DICompositeType(tag: DW_TAG_structure_type, name: "_IO_wide_data", file: !392, line: 38, flags: DIFlagFwdDecl)
!435 = !DIDerivedType(tag: DW_TAG_member, name: "_freeres_list", scope: !391, file: !392, line: 93, baseType: !412, size: 64, offset: 1344)
!436 = !DIDerivedType(tag: DW_TAG_member, name: "_freeres_buf", scope: !391, file: !392, line: 94, baseType: !437, size: 64, offset: 1408)
!437 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: null, size: 64)
!438 = !DIDerivedType(tag: DW_TAG_member, name: "__pad5", scope: !391, file: !392, line: 95, baseType: !439, size: 64, offset: 1472)
!439 = !DIDerivedType(tag: DW_TAG_typedef, name: "size_t", file: !440, line: 46, baseType: !441)
!440 = !DIFile(filename: "/usr/lib/llvm-14/lib/clang/14.0.0/include/stddef.h", directory: "", checksumkind: CSK_MD5, checksum: "2499dd2361b915724b073282bea3a7bc")
!441 = !DIBasicType(name: "unsigned long", size: 64, encoding: DW_ATE_unsigned)
!442 = !DIDerivedType(tag: DW_TAG_member, name: "_mode", scope: !391, file: !392, line: 96, baseType: !12, size: 32, offset: 1536)
!443 = !DIDerivedType(tag: DW_TAG_member, name: "_unused2", scope: !391, file: !392, line: 98, baseType: !444, size: 160, offset: 1568)
!444 = !DICompositeType(tag: DW_TAG_array_type, baseType: !397, size: 160, elements: !445)
!445 = !{!446}
!446 = !DISubrange(count: 20)
!447 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !448, size: 64)
!448 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !397)
!449 = !DILocalVariable(name: "stream", arg: 1, scope: !385, file: !32, line: 13, type: !388)
!450 = !DILocation(line: 0, scope: !385)
!451 = !DILocalVariable(name: "format", arg: 2, scope: !385, file: !32, line: 13, type: !447)
!452 = !DILocalVariable(name: "buffer", scope: !385, file: !32, line: 15, type: !453)
!453 = !DICompositeType(tag: DW_TAG_array_type, baseType: !397, size: 6144, elements: !454)
!454 = !{!455}
!455 = !DISubrange(count: 768)
!456 = !DILocation(line: 15, column: 10, scope: !385)
!457 = !DILocalVariable(name: "args", scope: !385, file: !32, line: 16, type: !458)
!458 = !DIDerivedType(tag: DW_TAG_typedef, name: "va_list", file: !459, line: 52, baseType: !460)
!459 = !DIFile(filename: "/usr/include/stdio.h", directory: "", checksumkind: CSK_MD5, checksum: "f31eefcc3f15835fc5a4023a625cf609")
!460 = !DIDerivedType(tag: DW_TAG_typedef, name: "__gnuc_va_list", file: !461, line: 32, baseType: !462)
!461 = !DIFile(filename: "/usr/lib/llvm-14/lib/clang/14.0.0/include/stdarg.h", directory: "", checksumkind: CSK_MD5, checksum: "4de3cbd931b589d291e5c39387aecf82")
!462 = !DIDerivedType(tag: DW_TAG_typedef, name: "__builtin_va_list", file: !463, baseType: !464)
!463 = !DIFile(filename: "source/workload.c", directory: "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/affine-bounds-20260929/suite/adi")
!464 = !DICompositeType(tag: DW_TAG_array_type, baseType: !465, size: 192, elements: !24)
!465 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "__va_list_tag", size: 192, elements: !466)
!466 = !{!467, !468, !469, !470}
!467 = !DIDerivedType(tag: DW_TAG_member, name: "gp_offset", scope: !465, file: !463, line: 16, baseType: !6, size: 32)
!468 = !DIDerivedType(tag: DW_TAG_member, name: "fp_offset", scope: !465, file: !463, line: 16, baseType: !6, size: 32, offset: 32)
!469 = !DIDerivedType(tag: DW_TAG_member, name: "overflow_arg_area", scope: !465, file: !463, line: 16, baseType: !437, size: 64, offset: 64)
!470 = !DIDerivedType(tag: DW_TAG_member, name: "reg_save_area", scope: !465, file: !463, line: 16, baseType: !437, size: 64, offset: 128)
!471 = !DILocation(line: 16, column: 13, scope: !385)
!472 = !DILocation(line: 17, column: 5, scope: !385)
!473 = !DILocation(line: 18, column: 27, scope: !385)
!474 = !DILocation(line: 18, column: 59, scope: !385)
!475 = !DILocation(line: 18, column: 17, scope: !385)
!476 = !DILocalVariable(name: "count", scope: !385, file: !32, line: 18, type: !12)
!477 = !DILocation(line: 19, column: 5, scope: !385)
!478 = !DILocation(line: 20, column: 15, scope: !479)
!479 = distinct !DILexicalBlock(scope: !385, file: !32, line: 20, column: 9)
!480 = !DILocation(line: 20, column: 19, scope: !479)
!481 = !DILocation(line: 20, column: 22, scope: !479)
!482 = !DILocation(line: 20, column: 38, scope: !479)
!483 = !DILocation(line: 20, column: 9, scope: !385)
!484 = !DILocation(line: 20, column: 57, scope: !479)
!485 = !DILocalVariable(name: "i", scope: !486, file: !32, line: 21, type: !12)
!486 = distinct !DILexicalBlock(scope: !385, file: !32, line: 21, column: 5)
!487 = !DILocation(line: 0, scope: !486)
!488 = !DILocation(line: 21, column: 10, scope: !486)
!489 = !DILocation(line: 21, column: 23, scope: !490)
!490 = distinct !DILexicalBlock(scope: !486, file: !32, line: 21, column: 5)
!491 = !DILocation(line: 21, column: 5, scope: !486)
!492 = !DILocation(line: 22, column: 35, scope: !493)
!493 = distinct !DILexicalBlock(scope: !490, file: !32, line: 21, column: 37)
!494 = !DILocation(line: 22, column: 20, scope: !493)
!495 = !DILocation(line: 22, column: 17, scope: !493)
!496 = !DILocation(line: 23, column: 17, scope: !493)
!497 = !DILocation(line: 24, column: 5, scope: !493)
!498 = !DILocation(line: 21, column: 32, scope: !490)
!499 = !DILocation(line: 21, column: 5, scope: !490)
!500 = distinct !{!500, !491, !501, !107}
!501 = !DILocation(line: 24, column: 5, scope: !486)
!502 = !DILocation(line: 29, column: 11, scope: !385)
!503 = !DILocation(line: 31, column: 5, scope: !385)
