; ModuleID = '/workspace/experiments-array-support/chaser/.cache/periodic-polybench/affine-bounds-20260929/suite/gramschmidt/source/workload.c'
source_filename = "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/affine-bounds-20260929/suite/gramschmidt/source/workload.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

%struct._IO_FILE = type { i32, i8*, i8*, i8*, i8*, i8*, i8*, i8*, i8*, i8*, i8*, i8*, %struct._IO_marker*, %struct._IO_FILE*, i32, i32, i64, i16, i8, [1 x i8], i8*, i64, %struct._IO_codecvt*, %struct._IO_wide_data*, %struct._IO_FILE*, i8*, i64, i32, [20 x i8] }
%struct._IO_marker = type opaque
%struct._IO_codecvt = type opaque
%struct._IO_wide_data = type opaque
%struct.__va_list_tag = type { i32, i32, i8*, i8* }

@m = dso_local global i32 200, align 4, !dbg !0
@n = dso_local global i32 240, align 4, !dbg !9
@A = dso_local global [200 x [240 x double]] zeroinitializer, section ".chaser_data.A", align 64, !dbg !33
@R = dso_local global [240 x [240 x double]] zeroinitializer, section ".chaser_data.R", align 64, !dbg !39
@Q = dso_local global [200 x [240 x double]] zeroinitializer, section ".chaser_data.Q", align 64, !dbg !43
@.str = private unnamed_addr constant [12 x i8] c"ape.analyze\00", section "llvm.metadata"
@.str.1 = private unnamed_addr constant [129 x i8] c"/workspace/experiments-array-support/chaser/.cache/periodic-polybench/affine-bounds-20260929/suite/gramschmidt/source/workload.c\00", section "llvm.metadata"
@pb_hash = internal global i32 0, align 4, !dbg !30
@workload_jobs = dso_local constant [1 x i32 ()*] [i32 ()* @task_job_polybench], align 8, !dbg !13
@workload_expected = dso_local constant [1 x i32] [i32 -932879858], align 4, !dbg !26
@stderr = external global %struct._IO_FILE*, align 8
@.str.2 = private unnamed_addr constant [23 x i8] c"==BEGIN DUMP_ARRAYS==\0A\00", align 1
@.str.3 = private unnamed_addr constant [15 x i8] c"begin dump: %s\00", align 1
@.str.4 = private unnamed_addr constant [2 x i8] c"R\00", align 1
@.str.5 = private unnamed_addr constant [2 x i8] c"\0A\00", align 1
@.str.6 = private unnamed_addr constant [8 x i8] c"%0.2lf \00", align 1
@.str.7 = private unnamed_addr constant [17 x i8] c"\0Aend   dump: %s\0A\00", align 1
@.str.8 = private unnamed_addr constant [2 x i8] c"Q\00", align 1
@.str.9 = private unnamed_addr constant [23 x i8] c"==END   DUMP_ARRAYS==\0A\00", align 1
@pb_emit = internal global i32 1, align 4, !dbg !45
@llvm.global.annotations = appending global [1 x { i8*, i8*, i8*, i32, i8* }] [{ i8*, i8*, i8*, i32, i8* } { i8* bitcast (i32 ()* @task_job_polybench to i8*), i8* getelementptr inbounds ([12 x i8], [12 x i8]* @.str, i32 0, i32 0), i8* getelementptr inbounds ([129 x i8], [129 x i8]* @.str.1, i32 0, i32 0), i32 137, i8* null }], section "llvm.metadata"

; Function Attrs: noinline nounwind uwtable
define dso_local void @workload_prepare() #0 !dbg !55 {
  ret void, !dbg !59
}

; Function Attrs: noinline nounwind uwtable
define dso_local void @workload_reset(i32 noundef %0) #0 !dbg !60 {
  %2 = alloca i32, align 4
  store i32 %0, i32* %2, align 4
  call void @llvm.dbg.declare(metadata i32* %2, metadata !63, metadata !DIExpression()), !dbg !64
  %3 = load i32, i32* %2, align 4, !dbg !65
  call void @llvm.memset.p0i8.i64(i8* align 64 bitcast ([200 x [240 x double]]* @A to i8*), i8 0, i64 384000, i1 false), !dbg !66
  call void @llvm.memset.p0i8.i64(i8* align 64 bitcast ([240 x [240 x double]]* @R to i8*), i8 0, i64 460800, i1 false), !dbg !67
  call void @llvm.memset.p0i8.i64(i8* align 64 bitcast ([200 x [240 x double]]* @Q to i8*), i8 0, i64 384000, i1 false), !dbg !68
  %4 = load i32, i32* @m, align 4, !dbg !69
  %5 = load i32, i32* @n, align 4, !dbg !70
  call void @init_array(i32 noundef %4, i32 noundef %5, [240 x double]* noundef getelementptr inbounds ([200 x [240 x double]], [200 x [240 x double]]* @A, i64 0, i64 0), [240 x double]* noundef getelementptr inbounds ([240 x [240 x double]], [240 x [240 x double]]* @R, i64 0, i64 0), [240 x double]* noundef getelementptr inbounds ([200 x [240 x double]], [200 x [240 x double]]* @Q, i64 0, i64 0)), !dbg !71
  ret void, !dbg !72
}

; Function Attrs: nofree nosync nounwind readnone speculatable willreturn
declare void @llvm.dbg.declare(metadata, metadata, metadata) #1

; Function Attrs: argmemonly nofree nounwind willreturn writeonly
declare void @llvm.memset.p0i8.i64(i8* nocapture writeonly, i8, i64, i1 immarg) #2

; Function Attrs: noinline nounwind uwtable
define internal void @init_array(i32 noundef %0, i32 noundef %1, [240 x double]* noundef %2, [240 x double]* noundef %3, [240 x double]* noundef %4) #0 !dbg !73 {
  %6 = alloca i32, align 4
  %7 = alloca i32, align 4
  %8 = alloca [240 x double]*, align 8
  %9 = alloca [240 x double]*, align 8
  %10 = alloca [240 x double]*, align 8
  %11 = alloca i32, align 4
  %12 = alloca i32, align 4
  store i32 %0, i32* %6, align 4
  call void @llvm.dbg.declare(metadata i32* %6, metadata !79, metadata !DIExpression()), !dbg !80
  store i32 %1, i32* %7, align 4
  call void @llvm.dbg.declare(metadata i32* %7, metadata !81, metadata !DIExpression()), !dbg !82
  store [240 x double]* %2, [240 x double]** %8, align 8
  call void @llvm.dbg.declare(metadata [240 x double]** %8, metadata !83, metadata !DIExpression()), !dbg !84
  store [240 x double]* %3, [240 x double]** %9, align 8
  call void @llvm.dbg.declare(metadata [240 x double]** %9, metadata !85, metadata !DIExpression()), !dbg !86
  store [240 x double]* %4, [240 x double]** %10, align 8
  call void @llvm.dbg.declare(metadata [240 x double]** %10, metadata !87, metadata !DIExpression()), !dbg !88
  call void @llvm.dbg.declare(metadata i32* %11, metadata !89, metadata !DIExpression()), !dbg !90
  call void @llvm.dbg.declare(metadata i32* %12, metadata !91, metadata !DIExpression()), !dbg !92
  store i32 0, i32* %11, align 4, !dbg !93
  br label %13, !dbg !95

13:                                               ; preds = %52, %5
  %14 = load i32, i32* %11, align 4, !dbg !96
  %15 = load i32, i32* %6, align 4, !dbg !98
  %16 = icmp slt i32 %14, %15, !dbg !99
  br i1 %16, label %17, label %55, !dbg !100

17:                                               ; preds = %13
  store i32 0, i32* %12, align 4, !dbg !101
  br label %18, !dbg !103

18:                                               ; preds = %48, %17
  %19 = load i32, i32* %12, align 4, !dbg !104
  %20 = load i32, i32* %7, align 4, !dbg !106
  %21 = icmp slt i32 %19, %20, !dbg !107
  br i1 %21, label %22, label %51, !dbg !108

22:                                               ; preds = %18
  %23 = load i32, i32* %11, align 4, !dbg !109
  %24 = load i32, i32* %12, align 4, !dbg !111
  %25 = mul nsw i32 %23, %24, !dbg !112
  %26 = load i32, i32* %6, align 4, !dbg !113
  %27 = srem i32 %25, %26, !dbg !114
  %28 = sitofp i32 %27 to double, !dbg !115
  %29 = load i32, i32* %6, align 4, !dbg !116
  %30 = sitofp i32 %29 to double, !dbg !116
  %31 = fdiv double %28, %30, !dbg !117
  %32 = fmul double %31, 1.000000e+02, !dbg !118
  %33 = fadd double %32, 1.000000e+01, !dbg !119
  %34 = load [240 x double]*, [240 x double]** %8, align 8, !dbg !120
  %35 = load i32, i32* %11, align 4, !dbg !121
  %36 = sext i32 %35 to i64, !dbg !120
  %37 = getelementptr inbounds [240 x double], [240 x double]* %34, i64 %36, !dbg !120
  %38 = load i32, i32* %12, align 4, !dbg !122
  %39 = sext i32 %38 to i64, !dbg !120
  %40 = getelementptr inbounds [240 x double], [240 x double]* %37, i64 0, i64 %39, !dbg !120
  store double %33, double* %40, align 8, !dbg !123
  %41 = load [240 x double]*, [240 x double]** %10, align 8, !dbg !124
  %42 = load i32, i32* %11, align 4, !dbg !125
  %43 = sext i32 %42 to i64, !dbg !124
  %44 = getelementptr inbounds [240 x double], [240 x double]* %41, i64 %43, !dbg !124
  %45 = load i32, i32* %12, align 4, !dbg !126
  %46 = sext i32 %45 to i64, !dbg !124
  %47 = getelementptr inbounds [240 x double], [240 x double]* %44, i64 0, i64 %46, !dbg !124
  store double 0.000000e+00, double* %47, align 8, !dbg !127
  br label %48, !dbg !128

48:                                               ; preds = %22
  %49 = load i32, i32* %12, align 4, !dbg !129
  %50 = add nsw i32 %49, 1, !dbg !129
  store i32 %50, i32* %12, align 4, !dbg !129
  br label %18, !dbg !130, !llvm.loop !131

51:                                               ; preds = %18
  br label %52, !dbg !132

52:                                               ; preds = %51
  %53 = load i32, i32* %11, align 4, !dbg !134
  %54 = add nsw i32 %53, 1, !dbg !134
  store i32 %54, i32* %11, align 4, !dbg !134
  br label %13, !dbg !135, !llvm.loop !136

55:                                               ; preds = %13
  store i32 0, i32* %11, align 4, !dbg !138
  br label %56, !dbg !140

56:                                               ; preds = %77, %55
  %57 = load i32, i32* %11, align 4, !dbg !141
  %58 = load i32, i32* %7, align 4, !dbg !143
  %59 = icmp slt i32 %57, %58, !dbg !144
  br i1 %59, label %60, label %80, !dbg !145

60:                                               ; preds = %56
  store i32 0, i32* %12, align 4, !dbg !146
  br label %61, !dbg !148

61:                                               ; preds = %73, %60
  %62 = load i32, i32* %12, align 4, !dbg !149
  %63 = load i32, i32* %7, align 4, !dbg !151
  %64 = icmp slt i32 %62, %63, !dbg !152
  br i1 %64, label %65, label %76, !dbg !153

65:                                               ; preds = %61
  %66 = load [240 x double]*, [240 x double]** %9, align 8, !dbg !154
  %67 = load i32, i32* %11, align 4, !dbg !155
  %68 = sext i32 %67 to i64, !dbg !154
  %69 = getelementptr inbounds [240 x double], [240 x double]* %66, i64 %68, !dbg !154
  %70 = load i32, i32* %12, align 4, !dbg !156
  %71 = sext i32 %70 to i64, !dbg !154
  %72 = getelementptr inbounds [240 x double], [240 x double]* %69, i64 0, i64 %71, !dbg !154
  store double 0.000000e+00, double* %72, align 8, !dbg !157
  br label %73, !dbg !154

73:                                               ; preds = %65
  %74 = load i32, i32* %12, align 4, !dbg !158
  %75 = add nsw i32 %74, 1, !dbg !158
  store i32 %75, i32* %12, align 4, !dbg !158
  br label %61, !dbg !159, !llvm.loop !160

76:                                               ; preds = %61
  br label %77, !dbg !161

77:                                               ; preds = %76
  %78 = load i32, i32* %11, align 4, !dbg !162
  %79 = add nsw i32 %78, 1, !dbg !162
  store i32 %79, i32* %11, align 4, !dbg !162
  br label %56, !dbg !163, !llvm.loop !164

80:                                               ; preds = %56
  ret void, !dbg !166
}

; Function Attrs: noinline nounwind uwtable
define dso_local i32 @task_job_polybench() #0 !dbg !167 {
  %1 = alloca i32, align 4
  %2 = alloca i32, align 4
  %3 = alloca [240 x double]*, align 8
  %4 = alloca [240 x double]*, align 8
  %5 = alloca [240 x double]*, align 8
  %6 = alloca i32, align 4
  %7 = alloca i32, align 4
  %8 = alloca i32, align 4
  %9 = alloca double, align 8
  %10 = load i32, i32* @m, align 4, !dbg !168
  %11 = load i32, i32* @n, align 4, !dbg !169
  store i32 %10, i32* %1, align 4
  call void @llvm.dbg.declare(metadata i32* %1, metadata !170, metadata !DIExpression()) #6, !dbg !172
  store i32 %11, i32* %2, align 4
  call void @llvm.dbg.declare(metadata i32* %2, metadata !174, metadata !DIExpression()) #6, !dbg !175
  store [240 x double]* getelementptr inbounds ([200 x [240 x double]], [200 x [240 x double]]* @A, i64 0, i64 0), [240 x double]** %3, align 8
  call void @llvm.dbg.declare(metadata [240 x double]** %3, metadata !176, metadata !DIExpression()) #6, !dbg !177
  store [240 x double]* getelementptr inbounds ([240 x [240 x double]], [240 x [240 x double]]* @R, i64 0, i64 0), [240 x double]** %4, align 8
  call void @llvm.dbg.declare(metadata [240 x double]** %4, metadata !178, metadata !DIExpression()) #6, !dbg !179
  store [240 x double]* getelementptr inbounds ([200 x [240 x double]], [200 x [240 x double]]* @Q, i64 0, i64 0), [240 x double]** %5, align 8
  call void @llvm.dbg.declare(metadata [240 x double]** %5, metadata !180, metadata !DIExpression()) #6, !dbg !181
  call void @llvm.dbg.declare(metadata i32* %6, metadata !182, metadata !DIExpression()) #6, !dbg !183
  call void @llvm.dbg.declare(metadata i32* %7, metadata !184, metadata !DIExpression()) #6, !dbg !185
  call void @llvm.dbg.declare(metadata i32* %8, metadata !186, metadata !DIExpression()) #6, !dbg !187
  call void @llvm.dbg.declare(metadata double* %9, metadata !188, metadata !DIExpression()) #6, !dbg !189
  store i32 0, i32* %8, align 4, !dbg !190
  br label %12, !dbg !192

12:                                               ; preds = %170, %0
  %13 = load i32, i32* %8, align 4, !dbg !193
  %14 = icmp slt i32 %13, 240, !dbg !195
  br i1 %14, label %15, label %173, !dbg !196

15:                                               ; preds = %12
  store double 0.000000e+00, double* %9, align 8, !dbg !197
  store i32 0, i32* %6, align 4, !dbg !199
  br label %16, !dbg !201

16:                                               ; preds = %19, %15
  %17 = load i32, i32* %6, align 4, !dbg !202
  %18 = icmp slt i32 %17, 200, !dbg !204
  br i1 %18, label %19, label %41, !dbg !205

19:                                               ; preds = %16
  %20 = load [240 x double]*, [240 x double]** %3, align 8, !dbg !206
  %21 = load i32, i32* %6, align 4, !dbg !207
  %22 = sext i32 %21 to i64, !dbg !206
  %23 = getelementptr inbounds [240 x double], [240 x double]* %20, i64 %22, !dbg !206
  %24 = load i32, i32* %8, align 4, !dbg !208
  %25 = sext i32 %24 to i64, !dbg !206
  %26 = getelementptr inbounds [240 x double], [240 x double]* %23, i64 0, i64 %25, !dbg !206
  %27 = load double, double* %26, align 8, !dbg !206
  %28 = load [240 x double]*, [240 x double]** %3, align 8, !dbg !209
  %29 = load i32, i32* %6, align 4, !dbg !210
  %30 = sext i32 %29 to i64, !dbg !209
  %31 = getelementptr inbounds [240 x double], [240 x double]* %28, i64 %30, !dbg !209
  %32 = load i32, i32* %8, align 4, !dbg !211
  %33 = sext i32 %32 to i64, !dbg !209
  %34 = getelementptr inbounds [240 x double], [240 x double]* %31, i64 0, i64 %33, !dbg !209
  %35 = load double, double* %34, align 8, !dbg !209
  %36 = fmul double %27, %35, !dbg !212
  %37 = load double, double* %9, align 8, !dbg !213
  %38 = fadd double %37, %36, !dbg !213
  store double %38, double* %9, align 8, !dbg !213
  %39 = load i32, i32* %6, align 4, !dbg !214
  %40 = add nsw i32 %39, 1, !dbg !214
  store i32 %40, i32* %6, align 4, !dbg !214
  br label %16, !dbg !215, !llvm.loop !216

41:                                               ; preds = %16
  %42 = load double, double* %9, align 8, !dbg !218
  %43 = call double @sqrt(double noundef %42) #6, !dbg !218
  %44 = load [240 x double]*, [240 x double]** %4, align 8, !dbg !219
  %45 = load i32, i32* %8, align 4, !dbg !220
  %46 = sext i32 %45 to i64, !dbg !219
  %47 = getelementptr inbounds [240 x double], [240 x double]* %44, i64 %46, !dbg !219
  %48 = load i32, i32* %8, align 4, !dbg !221
  %49 = sext i32 %48 to i64, !dbg !219
  %50 = getelementptr inbounds [240 x double], [240 x double]* %47, i64 0, i64 %49, !dbg !219
  store double %43, double* %50, align 8, !dbg !222
  store i32 0, i32* %6, align 4, !dbg !223
  br label %51, !dbg !225

51:                                               ; preds = %54, %41
  %52 = load i32, i32* %6, align 4, !dbg !226
  %53 = icmp slt i32 %52, 200, !dbg !228
  br i1 %53, label %54, label %81, !dbg !229

54:                                               ; preds = %51
  %55 = load [240 x double]*, [240 x double]** %3, align 8, !dbg !230
  %56 = load i32, i32* %6, align 4, !dbg !231
  %57 = sext i32 %56 to i64, !dbg !230
  %58 = getelementptr inbounds [240 x double], [240 x double]* %55, i64 %57, !dbg !230
  %59 = load i32, i32* %8, align 4, !dbg !232
  %60 = sext i32 %59 to i64, !dbg !230
  %61 = getelementptr inbounds [240 x double], [240 x double]* %58, i64 0, i64 %60, !dbg !230
  %62 = load double, double* %61, align 8, !dbg !230
  %63 = load [240 x double]*, [240 x double]** %4, align 8, !dbg !233
  %64 = load i32, i32* %8, align 4, !dbg !234
  %65 = sext i32 %64 to i64, !dbg !233
  %66 = getelementptr inbounds [240 x double], [240 x double]* %63, i64 %65, !dbg !233
  %67 = load i32, i32* %8, align 4, !dbg !235
  %68 = sext i32 %67 to i64, !dbg !233
  %69 = getelementptr inbounds [240 x double], [240 x double]* %66, i64 0, i64 %68, !dbg !233
  %70 = load double, double* %69, align 8, !dbg !233
  %71 = fdiv double %62, %70, !dbg !236
  %72 = load [240 x double]*, [240 x double]** %5, align 8, !dbg !237
  %73 = load i32, i32* %6, align 4, !dbg !238
  %74 = sext i32 %73 to i64, !dbg !237
  %75 = getelementptr inbounds [240 x double], [240 x double]* %72, i64 %74, !dbg !237
  %76 = load i32, i32* %8, align 4, !dbg !239
  %77 = sext i32 %76 to i64, !dbg !237
  %78 = getelementptr inbounds [240 x double], [240 x double]* %75, i64 0, i64 %77, !dbg !237
  store double %71, double* %78, align 8, !dbg !240
  %79 = load i32, i32* %6, align 4, !dbg !241
  %80 = add nsw i32 %79, 1, !dbg !241
  store i32 %80, i32* %6, align 4, !dbg !241
  br label %51, !dbg !242, !llvm.loop !243

81:                                               ; preds = %51
  %82 = load i32, i32* %8, align 4, !dbg !245
  %83 = add nsw i32 %82, 1, !dbg !247
  store i32 %83, i32* %7, align 4, !dbg !248
  br label %84, !dbg !249

84:                                               ; preds = %167, %81
  %85 = load i32, i32* %7, align 4, !dbg !250
  %86 = icmp slt i32 %85, 240, !dbg !252
  br i1 %86, label %87, label %170, !dbg !253

87:                                               ; preds = %84
  %88 = load [240 x double]*, [240 x double]** %4, align 8, !dbg !254
  %89 = load i32, i32* %8, align 4, !dbg !256
  %90 = sext i32 %89 to i64, !dbg !254
  %91 = getelementptr inbounds [240 x double], [240 x double]* %88, i64 %90, !dbg !254
  %92 = load i32, i32* %7, align 4, !dbg !257
  %93 = sext i32 %92 to i64, !dbg !254
  %94 = getelementptr inbounds [240 x double], [240 x double]* %91, i64 0, i64 %93, !dbg !254
  store double 0.000000e+00, double* %94, align 8, !dbg !258
  store i32 0, i32* %6, align 4, !dbg !259
  br label %95, !dbg !261

95:                                               ; preds = %98, %87
  %96 = load i32, i32* %6, align 4, !dbg !262
  %97 = icmp slt i32 %96, 200, !dbg !264
  br i1 %97, label %98, label %127, !dbg !265

98:                                               ; preds = %95
  %99 = load [240 x double]*, [240 x double]** %5, align 8, !dbg !266
  %100 = load i32, i32* %6, align 4, !dbg !267
  %101 = sext i32 %100 to i64, !dbg !266
  %102 = getelementptr inbounds [240 x double], [240 x double]* %99, i64 %101, !dbg !266
  %103 = load i32, i32* %8, align 4, !dbg !268
  %104 = sext i32 %103 to i64, !dbg !266
  %105 = getelementptr inbounds [240 x double], [240 x double]* %102, i64 0, i64 %104, !dbg !266
  %106 = load double, double* %105, align 8, !dbg !266
  %107 = load [240 x double]*, [240 x double]** %3, align 8, !dbg !269
  %108 = load i32, i32* %6, align 4, !dbg !270
  %109 = sext i32 %108 to i64, !dbg !269
  %110 = getelementptr inbounds [240 x double], [240 x double]* %107, i64 %109, !dbg !269
  %111 = load i32, i32* %7, align 4, !dbg !271
  %112 = sext i32 %111 to i64, !dbg !269
  %113 = getelementptr inbounds [240 x double], [240 x double]* %110, i64 0, i64 %112, !dbg !269
  %114 = load double, double* %113, align 8, !dbg !269
  %115 = fmul double %106, %114, !dbg !272
  %116 = load [240 x double]*, [240 x double]** %4, align 8, !dbg !273
  %117 = load i32, i32* %8, align 4, !dbg !274
  %118 = sext i32 %117 to i64, !dbg !273
  %119 = getelementptr inbounds [240 x double], [240 x double]* %116, i64 %118, !dbg !273
  %120 = load i32, i32* %7, align 4, !dbg !275
  %121 = sext i32 %120 to i64, !dbg !273
  %122 = getelementptr inbounds [240 x double], [240 x double]* %119, i64 0, i64 %121, !dbg !273
  %123 = load double, double* %122, align 8, !dbg !276
  %124 = fadd double %123, %115, !dbg !276
  store double %124, double* %122, align 8, !dbg !276
  %125 = load i32, i32* %6, align 4, !dbg !277
  %126 = add nsw i32 %125, 1, !dbg !277
  store i32 %126, i32* %6, align 4, !dbg !277
  br label %95, !dbg !278, !llvm.loop !279

127:                                              ; preds = %95
  store i32 0, i32* %6, align 4, !dbg !281
  br label %128, !dbg !283

128:                                              ; preds = %131, %127
  %129 = load i32, i32* %6, align 4, !dbg !284
  %130 = icmp slt i32 %129, 200, !dbg !286
  br i1 %130, label %131, label %167, !dbg !287

131:                                              ; preds = %128
  %132 = load [240 x double]*, [240 x double]** %3, align 8, !dbg !288
  %133 = load i32, i32* %6, align 4, !dbg !289
  %134 = sext i32 %133 to i64, !dbg !288
  %135 = getelementptr inbounds [240 x double], [240 x double]* %132, i64 %134, !dbg !288
  %136 = load i32, i32* %7, align 4, !dbg !290
  %137 = sext i32 %136 to i64, !dbg !288
  %138 = getelementptr inbounds [240 x double], [240 x double]* %135, i64 0, i64 %137, !dbg !288
  %139 = load double, double* %138, align 8, !dbg !288
  %140 = load [240 x double]*, [240 x double]** %5, align 8, !dbg !291
  %141 = load i32, i32* %6, align 4, !dbg !292
  %142 = sext i32 %141 to i64, !dbg !291
  %143 = getelementptr inbounds [240 x double], [240 x double]* %140, i64 %142, !dbg !291
  %144 = load i32, i32* %8, align 4, !dbg !293
  %145 = sext i32 %144 to i64, !dbg !291
  %146 = getelementptr inbounds [240 x double], [240 x double]* %143, i64 0, i64 %145, !dbg !291
  %147 = load double, double* %146, align 8, !dbg !291
  %148 = load [240 x double]*, [240 x double]** %4, align 8, !dbg !294
  %149 = load i32, i32* %8, align 4, !dbg !295
  %150 = sext i32 %149 to i64, !dbg !294
  %151 = getelementptr inbounds [240 x double], [240 x double]* %148, i64 %150, !dbg !294
  %152 = load i32, i32* %7, align 4, !dbg !296
  %153 = sext i32 %152 to i64, !dbg !294
  %154 = getelementptr inbounds [240 x double], [240 x double]* %151, i64 0, i64 %153, !dbg !294
  %155 = load double, double* %154, align 8, !dbg !294
  %156 = fmul double %147, %155, !dbg !297
  %157 = fsub double %139, %156, !dbg !298
  %158 = load [240 x double]*, [240 x double]** %3, align 8, !dbg !299
  %159 = load i32, i32* %6, align 4, !dbg !300
  %160 = sext i32 %159 to i64, !dbg !299
  %161 = getelementptr inbounds [240 x double], [240 x double]* %158, i64 %160, !dbg !299
  %162 = load i32, i32* %7, align 4, !dbg !301
  %163 = sext i32 %162 to i64, !dbg !299
  %164 = getelementptr inbounds [240 x double], [240 x double]* %161, i64 0, i64 %163, !dbg !299
  store double %157, double* %164, align 8, !dbg !302
  %165 = load i32, i32* %6, align 4, !dbg !303
  %166 = add nsw i32 %165, 1, !dbg !303
  store i32 %166, i32* %6, align 4, !dbg !303
  br label %128, !dbg !304, !llvm.loop !305

167:                                              ; preds = %128
  %168 = load i32, i32* %7, align 4, !dbg !307
  %169 = add nsw i32 %168, 1, !dbg !307
  store i32 %169, i32* %7, align 4, !dbg !307
  br label %84, !dbg !308, !llvm.loop !309

170:                                              ; preds = %84
  %171 = load i32, i32* %8, align 4, !dbg !311
  %172 = add nsw i32 %171, 1, !dbg !311
  store i32 %172, i32* %8, align 4, !dbg !311
  br label %12, !dbg !312, !llvm.loop !313

173:                                              ; preds = %12
  ret i32 0, !dbg !315
}

; Function Attrs: noinline nounwind uwtable
define dso_local i32 @workload_checksum(i32 noundef %0) #0 !dbg !316 {
  %2 = alloca i32, align 4
  store i32 %0, i32* %2, align 4
  call void @llvm.dbg.declare(metadata i32* %2, metadata !319, metadata !DIExpression()), !dbg !320
  %3 = load i32, i32* %2, align 4, !dbg !321
  store i32 -2128831035, i32* @pb_hash, align 4, !dbg !322
  %4 = load i32, i32* @m, align 4, !dbg !323
  %5 = load i32, i32* @n, align 4, !dbg !324
  call void @print_array(i32 noundef %4, i32 noundef %5, [240 x double]* noundef getelementptr inbounds ([200 x [240 x double]], [200 x [240 x double]]* @A, i64 0, i64 0), [240 x double]* noundef getelementptr inbounds ([240 x [240 x double]], [240 x [240 x double]]* @R, i64 0, i64 0), [240 x double]* noundef getelementptr inbounds ([200 x [240 x double]], [200 x [240 x double]]* @Q, i64 0, i64 0)), !dbg !325
  %6 = load i32, i32* @pb_hash, align 4, !dbg !326
  ret i32 %6, !dbg !327
}

; Function Attrs: noinline nounwind uwtable
define internal void @print_array(i32 noundef %0, i32 noundef %1, [240 x double]* noundef %2, [240 x double]* noundef %3, [240 x double]* noundef %4) #0 !dbg !328 {
  %6 = alloca i32, align 4
  %7 = alloca i32, align 4
  %8 = alloca [240 x double]*, align 8
  %9 = alloca [240 x double]*, align 8
  %10 = alloca [240 x double]*, align 8
  %11 = alloca i32, align 4
  %12 = alloca i32, align 4
  store i32 %0, i32* %6, align 4
  call void @llvm.dbg.declare(metadata i32* %6, metadata !329, metadata !DIExpression()), !dbg !330
  store i32 %1, i32* %7, align 4
  call void @llvm.dbg.declare(metadata i32* %7, metadata !331, metadata !DIExpression()), !dbg !332
  store [240 x double]* %2, [240 x double]** %8, align 8
  call void @llvm.dbg.declare(metadata [240 x double]** %8, metadata !333, metadata !DIExpression()), !dbg !334
  store [240 x double]* %3, [240 x double]** %9, align 8
  call void @llvm.dbg.declare(metadata [240 x double]** %9, metadata !335, metadata !DIExpression()), !dbg !336
  store [240 x double]* %4, [240 x double]** %10, align 8
  call void @llvm.dbg.declare(metadata [240 x double]** %10, metadata !337, metadata !DIExpression()), !dbg !338
  call void @llvm.dbg.declare(metadata i32* %11, metadata !339, metadata !DIExpression()), !dbg !340
  call void @llvm.dbg.declare(metadata i32* %12, metadata !341, metadata !DIExpression()), !dbg !342
  %13 = load %struct._IO_FILE*, %struct._IO_FILE** @stderr, align 8, !dbg !343
  %14 = call i32 (%struct._IO_FILE*, i8*, ...) @pb_fprintf(%struct._IO_FILE* noundef %13, i8* noundef getelementptr inbounds ([23 x i8], [23 x i8]* @.str.2, i64 0, i64 0)), !dbg !343
  %15 = load %struct._IO_FILE*, %struct._IO_FILE** @stderr, align 8, !dbg !344
  %16 = call i32 (%struct._IO_FILE*, i8*, ...) @pb_fprintf(%struct._IO_FILE* noundef %15, i8* noundef getelementptr inbounds ([15 x i8], [15 x i8]* @.str.3, i64 0, i64 0), i8* noundef getelementptr inbounds ([2 x i8], [2 x i8]* @.str.4, i64 0, i64 0)), !dbg !344
  store i32 0, i32* %11, align 4, !dbg !345
  br label %17, !dbg !347

17:                                               ; preds = %52, %5
  %18 = load i32, i32* %11, align 4, !dbg !348
  %19 = load i32, i32* %7, align 4, !dbg !350
  %20 = icmp slt i32 %18, %19, !dbg !351
  br i1 %20, label %21, label %55, !dbg !352

21:                                               ; preds = %17
  store i32 0, i32* %12, align 4, !dbg !353
  br label %22, !dbg !355

22:                                               ; preds = %48, %21
  %23 = load i32, i32* %12, align 4, !dbg !356
  %24 = load i32, i32* %7, align 4, !dbg !358
  %25 = icmp slt i32 %23, %24, !dbg !359
  br i1 %25, label %26, label %51, !dbg !360

26:                                               ; preds = %22
  %27 = load i32, i32* %11, align 4, !dbg !361
  %28 = load i32, i32* %7, align 4, !dbg !364
  %29 = mul nsw i32 %27, %28, !dbg !365
  %30 = load i32, i32* %12, align 4, !dbg !366
  %31 = add nsw i32 %29, %30, !dbg !367
  %32 = srem i32 %31, 20, !dbg !368
  %33 = icmp eq i32 %32, 0, !dbg !369
  br i1 %33, label %34, label %37, !dbg !370

34:                                               ; preds = %26
  %35 = load %struct._IO_FILE*, %struct._IO_FILE** @stderr, align 8, !dbg !371
  %36 = call i32 (%struct._IO_FILE*, i8*, ...) @pb_fprintf(%struct._IO_FILE* noundef %35, i8* noundef getelementptr inbounds ([2 x i8], [2 x i8]* @.str.5, i64 0, i64 0)), !dbg !372
  br label %37, !dbg !372

37:                                               ; preds = %34, %26
  %38 = load %struct._IO_FILE*, %struct._IO_FILE** @stderr, align 8, !dbg !373
  %39 = load [240 x double]*, [240 x double]** %9, align 8, !dbg !374
  %40 = load i32, i32* %11, align 4, !dbg !375
  %41 = sext i32 %40 to i64, !dbg !374
  %42 = getelementptr inbounds [240 x double], [240 x double]* %39, i64 %41, !dbg !374
  %43 = load i32, i32* %12, align 4, !dbg !376
  %44 = sext i32 %43 to i64, !dbg !374
  %45 = getelementptr inbounds [240 x double], [240 x double]* %42, i64 0, i64 %44, !dbg !374
  %46 = load double, double* %45, align 8, !dbg !374
  %47 = call i32 (%struct._IO_FILE*, i8*, ...) @pb_fprintf(%struct._IO_FILE* noundef %38, i8* noundef getelementptr inbounds ([8 x i8], [8 x i8]* @.str.6, i64 0, i64 0), double noundef %46), !dbg !377
  br label %48, !dbg !378

48:                                               ; preds = %37
  %49 = load i32, i32* %12, align 4, !dbg !379
  %50 = add nsw i32 %49, 1, !dbg !379
  store i32 %50, i32* %12, align 4, !dbg !379
  br label %22, !dbg !380, !llvm.loop !381

51:                                               ; preds = %22
  br label %52, !dbg !382

52:                                               ; preds = %51
  %53 = load i32, i32* %11, align 4, !dbg !383
  %54 = add nsw i32 %53, 1, !dbg !383
  store i32 %54, i32* %11, align 4, !dbg !383
  br label %17, !dbg !384, !llvm.loop !385

55:                                               ; preds = %17
  %56 = load %struct._IO_FILE*, %struct._IO_FILE** @stderr, align 8, !dbg !387
  %57 = call i32 (%struct._IO_FILE*, i8*, ...) @pb_fprintf(%struct._IO_FILE* noundef %56, i8* noundef getelementptr inbounds ([17 x i8], [17 x i8]* @.str.7, i64 0, i64 0), i8* noundef getelementptr inbounds ([2 x i8], [2 x i8]* @.str.4, i64 0, i64 0)), !dbg !387
  %58 = load %struct._IO_FILE*, %struct._IO_FILE** @stderr, align 8, !dbg !388
  %59 = call i32 (%struct._IO_FILE*, i8*, ...) @pb_fprintf(%struct._IO_FILE* noundef %58, i8* noundef getelementptr inbounds ([15 x i8], [15 x i8]* @.str.3, i64 0, i64 0), i8* noundef getelementptr inbounds ([2 x i8], [2 x i8]* @.str.8, i64 0, i64 0)), !dbg !388
  store i32 0, i32* %11, align 4, !dbg !389
  br label %60, !dbg !391

60:                                               ; preds = %95, %55
  %61 = load i32, i32* %11, align 4, !dbg !392
  %62 = load i32, i32* %6, align 4, !dbg !394
  %63 = icmp slt i32 %61, %62, !dbg !395
  br i1 %63, label %64, label %98, !dbg !396

64:                                               ; preds = %60
  store i32 0, i32* %12, align 4, !dbg !397
  br label %65, !dbg !399

65:                                               ; preds = %91, %64
  %66 = load i32, i32* %12, align 4, !dbg !400
  %67 = load i32, i32* %7, align 4, !dbg !402
  %68 = icmp slt i32 %66, %67, !dbg !403
  br i1 %68, label %69, label %94, !dbg !404

69:                                               ; preds = %65
  %70 = load i32, i32* %11, align 4, !dbg !405
  %71 = load i32, i32* %7, align 4, !dbg !408
  %72 = mul nsw i32 %70, %71, !dbg !409
  %73 = load i32, i32* %12, align 4, !dbg !410
  %74 = add nsw i32 %72, %73, !dbg !411
  %75 = srem i32 %74, 20, !dbg !412
  %76 = icmp eq i32 %75, 0, !dbg !413
  br i1 %76, label %77, label %80, !dbg !414

77:                                               ; preds = %69
  %78 = load %struct._IO_FILE*, %struct._IO_FILE** @stderr, align 8, !dbg !415
  %79 = call i32 (%struct._IO_FILE*, i8*, ...) @pb_fprintf(%struct._IO_FILE* noundef %78, i8* noundef getelementptr inbounds ([2 x i8], [2 x i8]* @.str.5, i64 0, i64 0)), !dbg !416
  br label %80, !dbg !416

80:                                               ; preds = %77, %69
  %81 = load %struct._IO_FILE*, %struct._IO_FILE** @stderr, align 8, !dbg !417
  %82 = load [240 x double]*, [240 x double]** %10, align 8, !dbg !418
  %83 = load i32, i32* %11, align 4, !dbg !419
  %84 = sext i32 %83 to i64, !dbg !418
  %85 = getelementptr inbounds [240 x double], [240 x double]* %82, i64 %84, !dbg !418
  %86 = load i32, i32* %12, align 4, !dbg !420
  %87 = sext i32 %86 to i64, !dbg !418
  %88 = getelementptr inbounds [240 x double], [240 x double]* %85, i64 0, i64 %87, !dbg !418
  %89 = load double, double* %88, align 8, !dbg !418
  %90 = call i32 (%struct._IO_FILE*, i8*, ...) @pb_fprintf(%struct._IO_FILE* noundef %81, i8* noundef getelementptr inbounds ([8 x i8], [8 x i8]* @.str.6, i64 0, i64 0), double noundef %89), !dbg !421
  br label %91, !dbg !422

91:                                               ; preds = %80
  %92 = load i32, i32* %12, align 4, !dbg !423
  %93 = add nsw i32 %92, 1, !dbg !423
  store i32 %93, i32* %12, align 4, !dbg !423
  br label %65, !dbg !424, !llvm.loop !425

94:                                               ; preds = %65
  br label %95, !dbg !426

95:                                               ; preds = %94
  %96 = load i32, i32* %11, align 4, !dbg !427
  %97 = add nsw i32 %96, 1, !dbg !427
  store i32 %97, i32* %11, align 4, !dbg !427
  br label %60, !dbg !428, !llvm.loop !429

98:                                               ; preds = %60
  %99 = load %struct._IO_FILE*, %struct._IO_FILE** @stderr, align 8, !dbg !431
  %100 = call i32 (%struct._IO_FILE*, i8*, ...) @pb_fprintf(%struct._IO_FILE* noundef %99, i8* noundef getelementptr inbounds ([17 x i8], [17 x i8]* @.str.7, i64 0, i64 0), i8* noundef getelementptr inbounds ([2 x i8], [2 x i8]* @.str.8, i64 0, i64 0)), !dbg !431
  %101 = load %struct._IO_FILE*, %struct._IO_FILE** @stderr, align 8, !dbg !432
  %102 = call i32 (%struct._IO_FILE*, i8*, ...) @pb_fprintf(%struct._IO_FILE* noundef %101, i8* noundef getelementptr inbounds ([23 x i8], [23 x i8]* @.str.9, i64 0, i64 0)), !dbg !432
  ret void, !dbg !433
}

; Function Attrs: nounwind
declare double @sqrt(double noundef) #3

; Function Attrs: noinline nounwind uwtable
define internal i32 @pb_fprintf(%struct._IO_FILE* noundef %0, i8* noundef %1, ...) #0 !dbg !434 {
  %3 = alloca %struct._IO_FILE*, align 8
  %4 = alloca i8*, align 8
  %5 = alloca [768 x i8], align 16
  %6 = alloca [1 x %struct.__va_list_tag], align 16
  %7 = alloca i32, align 4
  %8 = alloca i32, align 4
  store %struct._IO_FILE* %0, %struct._IO_FILE** %3, align 8
  call void @llvm.dbg.declare(metadata %struct._IO_FILE** %3, metadata !498, metadata !DIExpression()), !dbg !499
  store i8* %1, i8** %4, align 8
  call void @llvm.dbg.declare(metadata i8** %4, metadata !500, metadata !DIExpression()), !dbg !501
  call void @llvm.dbg.declare(metadata [768 x i8]* %5, metadata !502, metadata !DIExpression()), !dbg !506
  call void @llvm.dbg.declare(metadata [1 x %struct.__va_list_tag]* %6, metadata !507, metadata !DIExpression()), !dbg !521
  %9 = getelementptr inbounds [1 x %struct.__va_list_tag], [1 x %struct.__va_list_tag]* %6, i64 0, i64 0, !dbg !522
  %10 = bitcast %struct.__va_list_tag* %9 to i8*, !dbg !522
  call void @llvm.va_start(i8* %10), !dbg !522
  call void @llvm.dbg.declare(metadata i32* %7, metadata !523, metadata !DIExpression()), !dbg !524
  %11 = getelementptr inbounds [768 x i8], [768 x i8]* %5, i64 0, i64 0, !dbg !525
  %12 = load i8*, i8** %4, align 8, !dbg !526
  %13 = getelementptr inbounds [1 x %struct.__va_list_tag], [1 x %struct.__va_list_tag]* %6, i64 0, i64 0, !dbg !527
  %14 = call i32 @vsnprintf(i8* noundef %11, i64 noundef 768, i8* noundef %12, %struct.__va_list_tag* noundef %13) #6, !dbg !528
  store i32 %14, i32* %7, align 4, !dbg !524
  %15 = getelementptr inbounds [1 x %struct.__va_list_tag], [1 x %struct.__va_list_tag]* %6, i64 0, i64 0, !dbg !529
  %16 = bitcast %struct.__va_list_tag* %15 to i8*, !dbg !529
  call void @llvm.va_end(i8* %16), !dbg !529
  %17 = load i32, i32* %7, align 4, !dbg !530
  %18 = icmp slt i32 %17, 0, !dbg !532
  br i1 %18, label %23, label %19, !dbg !533

19:                                               ; preds = %2
  %20 = load i32, i32* %7, align 4, !dbg !534
  %21 = zext i32 %20 to i64, !dbg !535
  %22 = icmp uge i64 %21, 768, !dbg !536
  br i1 %22, label %23, label %24, !dbg !537

23:                                               ; preds = %19, %2
  call void @abort() #7, !dbg !538
  unreachable, !dbg !538

24:                                               ; preds = %19
  call void @llvm.dbg.declare(metadata i32* %8, metadata !539, metadata !DIExpression()), !dbg !541
  store i32 0, i32* %8, align 4, !dbg !541
  br label %25, !dbg !542

25:                                               ; preds = %39, %24
  %26 = load i32, i32* %8, align 4, !dbg !543
  %27 = load i32, i32* %7, align 4, !dbg !545
  %28 = icmp slt i32 %26, %27, !dbg !546
  br i1 %28, label %29, label %42, !dbg !547

29:                                               ; preds = %25
  %30 = load i32, i32* %8, align 4, !dbg !548
  %31 = sext i32 %30 to i64, !dbg !550
  %32 = getelementptr inbounds [768 x i8], [768 x i8]* %5, i64 0, i64 %31, !dbg !550
  %33 = load i8, i8* %32, align 1, !dbg !550
  %34 = zext i8 %33 to i32, !dbg !551
  %35 = load i32, i32* @pb_hash, align 4, !dbg !552
  %36 = xor i32 %35, %34, !dbg !552
  store i32 %36, i32* @pb_hash, align 4, !dbg !552
  %37 = load i32, i32* @pb_hash, align 4, !dbg !553
  %38 = mul i32 %37, 16777619, !dbg !553
  store i32 %38, i32* @pb_hash, align 4, !dbg !553
  br label %39, !dbg !554

39:                                               ; preds = %29
  %40 = load i32, i32* %8, align 4, !dbg !555
  %41 = add nsw i32 %40, 1, !dbg !555
  store i32 %41, i32* %8, align 4, !dbg !555
  br label %25, !dbg !556, !llvm.loop !557

42:                                               ; preds = %25
  %43 = load %struct._IO_FILE*, %struct._IO_FILE** %3, align 8, !dbg !559
  %44 = load i32, i32* @pb_emit, align 4, !dbg !560
  %45 = load i32, i32* %7, align 4, !dbg !561
  ret i32 %45, !dbg !562
}

; Function Attrs: nofree nosync nounwind willreturn
declare void @llvm.va_start(i8*) #4

; Function Attrs: nounwind
declare i32 @vsnprintf(i8* noundef, i64 noundef, i8* noundef, %struct.__va_list_tag* noundef) #3

; Function Attrs: nofree nosync nounwind willreturn
declare void @llvm.va_end(i8*) #4

; Function Attrs: noreturn nounwind
declare void @abort() #5

attributes #0 = { noinline nounwind uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { nofree nosync nounwind readnone speculatable willreturn }
attributes #2 = { argmemonly nofree nounwind willreturn writeonly }
attributes #3 = { nounwind "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #4 = { nofree nosync nounwind willreturn }
attributes #5 = { noreturn nounwind "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #6 = { nounwind }
attributes #7 = { noreturn nounwind }

!llvm.dbg.cu = !{!2}
!llvm.module.flags = !{!47, !48, !49, !50, !51, !52, !53}
!llvm.ident = !{!54}

!0 = !DIGlobalVariableExpression(var: !1, expr: !DIExpression())
!1 = distinct !DIGlobalVariable(name: "m", scope: !2, file: !11, line: 124, type: !12, isLocal: false, isDefinition: true)
!2 = distinct !DICompileUnit(language: DW_LANG_C99, file: !3, producer: "Ubuntu clang version 14.0.0-1ubuntu1.1", isOptimized: false, runtimeVersion: 0, emissionKind: FullDebug, retainedTypes: !4, globals: !8, splitDebugInlining: false, nameTableKind: None)
!3 = !DIFile(filename: "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/affine-bounds-20260929/suite/gramschmidt/source/workload.c", directory: "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/affine-bounds-20260929/suite/gramschmidt/analysis-g", checksumkind: CSK_MD5, checksum: "eeae836a398c1603585df2c88ebc745e")
!4 = !{!5, !6, !7}
!5 = !DIBasicType(name: "double", size: 64, encoding: DW_ATE_float)
!6 = !DIBasicType(name: "unsigned int", size: 32, encoding: DW_ATE_unsigned)
!7 = !DIBasicType(name: "unsigned char", size: 8, encoding: DW_ATE_unsigned_char)
!8 = !{!0, !9, !13, !26, !30, !33, !39, !43, !45}
!9 = !DIGlobalVariableExpression(var: !10, expr: !DIExpression())
!10 = distinct !DIGlobalVariable(name: "n", scope: !2, file: !11, line: 125, type: !12, isLocal: false, isDefinition: true)
!11 = !DIFile(filename: "source/workload.c", directory: "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/affine-bounds-20260929/suite/gramschmidt", checksumkind: CSK_MD5, checksum: "eeae836a398c1603585df2c88ebc745e")
!12 = !DIBasicType(name: "int", size: 32, encoding: DW_ATE_signed)
!13 = !DIGlobalVariableExpression(var: !14, expr: !DIExpression())
!14 = distinct !DIGlobalVariable(name: "workload_jobs", scope: !2, file: !11, line: 150, type: !15, isLocal: false, isDefinition: true)
!15 = !DICompositeType(tag: DW_TAG_array_type, baseType: !16, size: 64, elements: !24)
!16 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !17)
!17 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !18, size: 64)
!18 = !DISubroutineType(types: !19)
!19 = !{!20}
!20 = !DIDerivedType(tag: DW_TAG_typedef, name: "uint32_t", file: !21, line: 26, baseType: !22)
!21 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/stdint-uintn.h", directory: "", checksumkind: CSK_MD5, checksum: "2bf2ae53c58c01b1a1b9383b5195125c")
!22 = !DIDerivedType(tag: DW_TAG_typedef, name: "__uint32_t", file: !23, line: 42, baseType: !6)
!23 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/types.h", directory: "", checksumkind: CSK_MD5, checksum: "d108b5f93a74c50510d7d9bc0ab36df9")
!24 = !{!25}
!25 = !DISubrange(count: 1)
!26 = !DIGlobalVariableExpression(var: !27, expr: !DIExpression())
!27 = distinct !DIGlobalVariable(name: "workload_expected", scope: !2, file: !11, line: 154, type: !28, isLocal: false, isDefinition: true)
!28 = !DICompositeType(tag: DW_TAG_array_type, baseType: !29, size: 32, elements: !24)
!29 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !20)
!30 = !DIGlobalVariableExpression(var: !31, expr: !DIExpression())
!31 = distinct !DIGlobalVariable(name: "pb_hash", scope: !2, file: !32, line: 9, type: !20, isLocal: true, isDefinition: true)
!32 = !DIFile(filename: "source/adapter.h", directory: "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/affine-bounds-20260929/suite/gramschmidt", checksumkind: CSK_MD5, checksum: "26a6068928b2092758f244a9d00163d7")
!33 = !DIGlobalVariableExpression(var: !34, expr: !DIExpression())
!34 = distinct !DIGlobalVariable(name: "A", scope: !2, file: !11, line: 34, type: !35, isLocal: false, isDefinition: true, align: 512)
!35 = !DICompositeType(tag: DW_TAG_array_type, baseType: !5, size: 3072000, elements: !36)
!36 = !{!37, !38}
!37 = !DISubrange(count: 200)
!38 = !DISubrange(count: 240)
!39 = !DIGlobalVariableExpression(var: !40, expr: !DIExpression())
!40 = distinct !DIGlobalVariable(name: "R", scope: !2, file: !11, line: 35, type: !41, isLocal: false, isDefinition: true, align: 512)
!41 = !DICompositeType(tag: DW_TAG_array_type, baseType: !5, size: 3686400, elements: !42)
!42 = !{!38, !38}
!43 = !DIGlobalVariableExpression(var: !44, expr: !DIExpression())
!44 = distinct !DIGlobalVariable(name: "Q", scope: !2, file: !11, line: 36, type: !35, isLocal: false, isDefinition: true, align: 512)
!45 = !DIGlobalVariableExpression(var: !46, expr: !DIExpression())
!46 = distinct !DIGlobalVariable(name: "pb_emit", scope: !2, file: !32, line: 10, type: !12, isLocal: true, isDefinition: true)
!47 = !{i32 7, !"Dwarf Version", i32 5}
!48 = !{i32 2, !"Debug Info Version", i32 3}
!49 = !{i32 1, !"wchar_size", i32 4}
!50 = !{i32 7, !"PIC Level", i32 2}
!51 = !{i32 7, !"PIE Level", i32 2}
!52 = !{i32 7, !"uwtable", i32 1}
!53 = !{i32 7, !"frame-pointer", i32 2}
!54 = !{!"Ubuntu clang version 14.0.0-1ubuntu1.1"}
!55 = distinct !DISubprogram(name: "workload_prepare", scope: !11, file: !11, line: 126, type: !56, scopeLine: 126, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !2, retainedNodes: !58)
!56 = !DISubroutineType(types: !57)
!57 = !{null}
!58 = !{}
!59 = !DILocation(line: 126, column: 30, scope: !55)
!60 = distinct !DISubprogram(name: "workload_reset", scope: !11, file: !11, line: 127, type: !61, scopeLine: 127, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !2, retainedNodes: !58)
!61 = !DISubroutineType(types: !62)
!62 = !{null, !6}
!63 = !DILocalVariable(name: "task", arg: 1, scope: !60, file: !11, line: 127, type: !6)
!64 = !DILocation(line: 127, column: 30, scope: !60)
!65 = !DILocation(line: 128, column: 9, scope: !60)
!66 = !DILocation(line: 129, column: 3, scope: !60)
!67 = !DILocation(line: 130, column: 3, scope: !60)
!68 = !DILocation(line: 131, column: 3, scope: !60)
!69 = !DILocation(line: 132, column: 15, scope: !60)
!70 = !DILocation(line: 132, column: 18, scope: !60)
!71 = !DILocation(line: 132, column: 3, scope: !60)
!72 = !DILocation(line: 136, column: 1, scope: !60)
!73 = distinct !DISubprogram(name: "init_array", scope: !11, file: !11, line: 38, type: !74, scopeLine: 42, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition, unit: !2, retainedNodes: !58)
!74 = !DISubroutineType(types: !75)
!75 = !{null, !12, !12, !76, !76, !76}
!76 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !77, size: 64)
!77 = !DICompositeType(tag: DW_TAG_array_type, baseType: !5, size: 15360, elements: !78)
!78 = !{!38}
!79 = !DILocalVariable(name: "m", arg: 1, scope: !73, file: !11, line: 38, type: !12)
!80 = !DILocation(line: 38, column: 21, scope: !73)
!81 = !DILocalVariable(name: "n", arg: 2, scope: !73, file: !11, line: 38, type: !12)
!82 = !DILocation(line: 38, column: 28, scope: !73)
!83 = !DILocalVariable(name: "A", arg: 3, scope: !73, file: !11, line: 39, type: !76)
!84 = !DILocation(line: 39, column: 13, scope: !73)
!85 = !DILocalVariable(name: "R", arg: 4, scope: !73, file: !11, line: 40, type: !76)
!86 = !DILocation(line: 40, column: 13, scope: !73)
!87 = !DILocalVariable(name: "Q", arg: 5, scope: !73, file: !11, line: 41, type: !76)
!88 = !DILocation(line: 41, column: 13, scope: !73)
!89 = !DILocalVariable(name: "i", scope: !73, file: !11, line: 43, type: !12)
!90 = !DILocation(line: 43, column: 7, scope: !73)
!91 = !DILocalVariable(name: "j", scope: !73, file: !11, line: 43, type: !12)
!92 = !DILocation(line: 43, column: 10, scope: !73)
!93 = !DILocation(line: 45, column: 10, scope: !94)
!94 = distinct !DILexicalBlock(scope: !73, file: !11, line: 45, column: 3)
!95 = !DILocation(line: 45, column: 8, scope: !94)
!96 = !DILocation(line: 45, column: 15, scope: !97)
!97 = distinct !DILexicalBlock(scope: !94, file: !11, line: 45, column: 3)
!98 = !DILocation(line: 45, column: 19, scope: !97)
!99 = !DILocation(line: 45, column: 17, scope: !97)
!100 = !DILocation(line: 45, column: 3, scope: !94)
!101 = !DILocation(line: 46, column: 12, scope: !102)
!102 = distinct !DILexicalBlock(scope: !97, file: !11, line: 46, column: 5)
!103 = !DILocation(line: 46, column: 10, scope: !102)
!104 = !DILocation(line: 46, column: 17, scope: !105)
!105 = distinct !DILexicalBlock(scope: !102, file: !11, line: 46, column: 5)
!106 = !DILocation(line: 46, column: 21, scope: !105)
!107 = !DILocation(line: 46, column: 19, scope: !105)
!108 = !DILocation(line: 46, column: 5, scope: !102)
!109 = !DILocation(line: 47, column: 33, scope: !110)
!110 = distinct !DILexicalBlock(scope: !105, file: !11, line: 46, column: 29)
!111 = !DILocation(line: 47, column: 35, scope: !110)
!112 = !DILocation(line: 47, column: 34, scope: !110)
!113 = !DILocation(line: 47, column: 40, scope: !110)
!114 = !DILocation(line: 47, column: 38, scope: !110)
!115 = !DILocation(line: 47, column: 19, scope: !110)
!116 = !DILocation(line: 47, column: 45, scope: !110)
!117 = !DILocation(line: 47, column: 43, scope: !110)
!118 = !DILocation(line: 47, column: 48, scope: !110)
!119 = !DILocation(line: 47, column: 54, scope: !110)
!120 = !DILocation(line: 47, column: 7, scope: !110)
!121 = !DILocation(line: 47, column: 9, scope: !110)
!122 = !DILocation(line: 47, column: 12, scope: !110)
!123 = !DILocation(line: 47, column: 15, scope: !110)
!124 = !DILocation(line: 48, column: 7, scope: !110)
!125 = !DILocation(line: 48, column: 9, scope: !110)
!126 = !DILocation(line: 48, column: 12, scope: !110)
!127 = !DILocation(line: 48, column: 15, scope: !110)
!128 = !DILocation(line: 49, column: 5, scope: !110)
!129 = !DILocation(line: 46, column: 25, scope: !105)
!130 = !DILocation(line: 46, column: 5, scope: !105)
!131 = distinct !{!131, !108, !132, !133}
!132 = !DILocation(line: 49, column: 5, scope: !102)
!133 = !{!"llvm.loop.mustprogress"}
!134 = !DILocation(line: 45, column: 23, scope: !97)
!135 = !DILocation(line: 45, column: 3, scope: !97)
!136 = distinct !{!136, !100, !137, !133}
!137 = !DILocation(line: 49, column: 5, scope: !94)
!138 = !DILocation(line: 50, column: 10, scope: !139)
!139 = distinct !DILexicalBlock(scope: !73, file: !11, line: 50, column: 3)
!140 = !DILocation(line: 50, column: 8, scope: !139)
!141 = !DILocation(line: 50, column: 15, scope: !142)
!142 = distinct !DILexicalBlock(scope: !139, file: !11, line: 50, column: 3)
!143 = !DILocation(line: 50, column: 19, scope: !142)
!144 = !DILocation(line: 50, column: 17, scope: !142)
!145 = !DILocation(line: 50, column: 3, scope: !139)
!146 = !DILocation(line: 51, column: 12, scope: !147)
!147 = distinct !DILexicalBlock(scope: !142, file: !11, line: 51, column: 5)
!148 = !DILocation(line: 51, column: 10, scope: !147)
!149 = !DILocation(line: 51, column: 17, scope: !150)
!150 = distinct !DILexicalBlock(scope: !147, file: !11, line: 51, column: 5)
!151 = !DILocation(line: 51, column: 21, scope: !150)
!152 = !DILocation(line: 51, column: 19, scope: !150)
!153 = !DILocation(line: 51, column: 5, scope: !147)
!154 = !DILocation(line: 52, column: 7, scope: !150)
!155 = !DILocation(line: 52, column: 9, scope: !150)
!156 = !DILocation(line: 52, column: 12, scope: !150)
!157 = !DILocation(line: 52, column: 15, scope: !150)
!158 = !DILocation(line: 51, column: 25, scope: !150)
!159 = !DILocation(line: 51, column: 5, scope: !150)
!160 = distinct !{!160, !153, !161, !133}
!161 = !DILocation(line: 52, column: 17, scope: !147)
!162 = !DILocation(line: 50, column: 23, scope: !142)
!163 = !DILocation(line: 50, column: 3, scope: !142)
!164 = distinct !{!164, !145, !165, !133}
!165 = !DILocation(line: 52, column: 17, scope: !139)
!166 = !DILocation(line: 53, column: 1, scope: !73)
!167 = distinct !DISubprogram(name: "task_job_polybench", scope: !11, file: !11, line: 137, type: !18, scopeLine: 137, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !2, retainedNodes: !58)
!168 = !DILocation(line: 138, column: 23, scope: !167)
!169 = !DILocation(line: 138, column: 26, scope: !167)
!170 = !DILocalVariable(name: "m", arg: 1, scope: !171, file: !11, line: 91, type: !12)
!171 = distinct !DISubprogram(name: "kernel_gramschmidt", scope: !11, file: !11, line: 91, type: !74, scopeLine: 95, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition, unit: !2, retainedNodes: !58)
!172 = !DILocation(line: 91, column: 67, scope: !171, inlinedAt: !173)
!173 = distinct !DILocation(line: 138, column: 3, scope: !167)
!174 = !DILocalVariable(name: "n", arg: 2, scope: !171, file: !11, line: 91, type: !12)
!175 = !DILocation(line: 91, column: 74, scope: !171, inlinedAt: !173)
!176 = !DILocalVariable(name: "A", arg: 3, scope: !171, file: !11, line: 92, type: !76)
!177 = !DILocation(line: 92, column: 14, scope: !171, inlinedAt: !173)
!178 = !DILocalVariable(name: "R", arg: 4, scope: !171, file: !11, line: 93, type: !76)
!179 = !DILocation(line: 93, column: 14, scope: !171, inlinedAt: !173)
!180 = !DILocalVariable(name: "Q", arg: 5, scope: !171, file: !11, line: 94, type: !76)
!181 = !DILocation(line: 94, column: 14, scope: !171, inlinedAt: !173)
!182 = !DILocalVariable(name: "i", scope: !171, file: !11, line: 96, type: !12)
!183 = !DILocation(line: 96, column: 7, scope: !171, inlinedAt: !173)
!184 = !DILocalVariable(name: "j", scope: !171, file: !11, line: 96, type: !12)
!185 = !DILocation(line: 96, column: 10, scope: !171, inlinedAt: !173)
!186 = !DILocalVariable(name: "k", scope: !171, file: !11, line: 96, type: !12)
!187 = !DILocation(line: 96, column: 13, scope: !171, inlinedAt: !173)
!188 = !DILocalVariable(name: "nrm", scope: !171, file: !11, line: 98, type: !5)
!189 = !DILocation(line: 98, column: 13, scope: !171, inlinedAt: !173)
!190 = !DILocation(line: 101, column: 10, scope: !191, inlinedAt: !173)
!191 = distinct !DILexicalBlock(scope: !171, file: !11, line: 101, column: 3)
!192 = !DILocation(line: 101, column: 8, scope: !191, inlinedAt: !173)
!193 = !DILocation(line: 101, column: 15, scope: !194, inlinedAt: !173)
!194 = distinct !DILexicalBlock(scope: !191, file: !11, line: 101, column: 3)
!195 = !DILocation(line: 101, column: 17, scope: !194, inlinedAt: !173)
!196 = !DILocation(line: 101, column: 3, scope: !191, inlinedAt: !173)
!197 = !DILocation(line: 103, column: 11, scope: !198, inlinedAt: !173)
!198 = distinct !DILexicalBlock(scope: !194, file: !11, line: 102, column: 5)
!199 = !DILocation(line: 104, column: 14, scope: !200, inlinedAt: !173)
!200 = distinct !DILexicalBlock(scope: !198, file: !11, line: 104, column: 7)
!201 = !DILocation(line: 104, column: 12, scope: !200, inlinedAt: !173)
!202 = !DILocation(line: 104, column: 19, scope: !203, inlinedAt: !173)
!203 = distinct !DILexicalBlock(scope: !200, file: !11, line: 104, column: 7)
!204 = !DILocation(line: 104, column: 21, scope: !203, inlinedAt: !173)
!205 = !DILocation(line: 104, column: 7, scope: !200, inlinedAt: !173)
!206 = !DILocation(line: 105, column: 16, scope: !203, inlinedAt: !173)
!207 = !DILocation(line: 105, column: 18, scope: !203, inlinedAt: !173)
!208 = !DILocation(line: 105, column: 21, scope: !203, inlinedAt: !173)
!209 = !DILocation(line: 105, column: 26, scope: !203, inlinedAt: !173)
!210 = !DILocation(line: 105, column: 28, scope: !203, inlinedAt: !173)
!211 = !DILocation(line: 105, column: 31, scope: !203, inlinedAt: !173)
!212 = !DILocation(line: 105, column: 24, scope: !203, inlinedAt: !173)
!213 = !DILocation(line: 105, column: 13, scope: !203, inlinedAt: !173)
!214 = !DILocation(line: 104, column: 31, scope: !203, inlinedAt: !173)
!215 = !DILocation(line: 104, column: 7, scope: !203, inlinedAt: !173)
!216 = distinct !{!216, !205, !217, !133}
!217 = !DILocation(line: 105, column: 32, scope: !200, inlinedAt: !173)
!218 = !DILocation(line: 106, column: 17, scope: !198, inlinedAt: !173)
!219 = !DILocation(line: 106, column: 7, scope: !198, inlinedAt: !173)
!220 = !DILocation(line: 106, column: 9, scope: !198, inlinedAt: !173)
!221 = !DILocation(line: 106, column: 12, scope: !198, inlinedAt: !173)
!222 = !DILocation(line: 106, column: 15, scope: !198, inlinedAt: !173)
!223 = !DILocation(line: 107, column: 14, scope: !224, inlinedAt: !173)
!224 = distinct !DILexicalBlock(scope: !198, file: !11, line: 107, column: 7)
!225 = !DILocation(line: 107, column: 12, scope: !224, inlinedAt: !173)
!226 = !DILocation(line: 107, column: 19, scope: !227, inlinedAt: !173)
!227 = distinct !DILexicalBlock(scope: !224, file: !11, line: 107, column: 7)
!228 = !DILocation(line: 107, column: 21, scope: !227, inlinedAt: !173)
!229 = !DILocation(line: 107, column: 7, scope: !224, inlinedAt: !173)
!230 = !DILocation(line: 108, column: 19, scope: !227, inlinedAt: !173)
!231 = !DILocation(line: 108, column: 21, scope: !227, inlinedAt: !173)
!232 = !DILocation(line: 108, column: 24, scope: !227, inlinedAt: !173)
!233 = !DILocation(line: 108, column: 29, scope: !227, inlinedAt: !173)
!234 = !DILocation(line: 108, column: 31, scope: !227, inlinedAt: !173)
!235 = !DILocation(line: 108, column: 34, scope: !227, inlinedAt: !173)
!236 = !DILocation(line: 108, column: 27, scope: !227, inlinedAt: !173)
!237 = !DILocation(line: 108, column: 9, scope: !227, inlinedAt: !173)
!238 = !DILocation(line: 108, column: 11, scope: !227, inlinedAt: !173)
!239 = !DILocation(line: 108, column: 14, scope: !227, inlinedAt: !173)
!240 = !DILocation(line: 108, column: 17, scope: !227, inlinedAt: !173)
!241 = !DILocation(line: 107, column: 31, scope: !227, inlinedAt: !173)
!242 = !DILocation(line: 107, column: 7, scope: !227, inlinedAt: !173)
!243 = distinct !{!243, !229, !244, !133}
!244 = !DILocation(line: 108, column: 35, scope: !224, inlinedAt: !173)
!245 = !DILocation(line: 109, column: 16, scope: !246, inlinedAt: !173)
!246 = distinct !DILexicalBlock(scope: !198, file: !11, line: 109, column: 7)
!247 = !DILocation(line: 109, column: 18, scope: !246, inlinedAt: !173)
!248 = !DILocation(line: 109, column: 14, scope: !246, inlinedAt: !173)
!249 = !DILocation(line: 109, column: 12, scope: !246, inlinedAt: !173)
!250 = !DILocation(line: 109, column: 23, scope: !251, inlinedAt: !173)
!251 = distinct !DILexicalBlock(scope: !246, file: !11, line: 109, column: 7)
!252 = !DILocation(line: 109, column: 25, scope: !251, inlinedAt: !173)
!253 = !DILocation(line: 109, column: 7, scope: !246, inlinedAt: !173)
!254 = !DILocation(line: 111, column: 4, scope: !255, inlinedAt: !173)
!255 = distinct !DILexicalBlock(scope: !251, file: !11, line: 110, column: 2)
!256 = !DILocation(line: 111, column: 6, scope: !255, inlinedAt: !173)
!257 = !DILocation(line: 111, column: 9, scope: !255, inlinedAt: !173)
!258 = !DILocation(line: 111, column: 12, scope: !255, inlinedAt: !173)
!259 = !DILocation(line: 112, column: 11, scope: !260, inlinedAt: !173)
!260 = distinct !DILexicalBlock(scope: !255, file: !11, line: 112, column: 4)
!261 = !DILocation(line: 112, column: 9, scope: !260, inlinedAt: !173)
!262 = !DILocation(line: 112, column: 16, scope: !263, inlinedAt: !173)
!263 = distinct !DILexicalBlock(scope: !260, file: !11, line: 112, column: 4)
!264 = !DILocation(line: 112, column: 18, scope: !263, inlinedAt: !173)
!265 = !DILocation(line: 112, column: 4, scope: !260, inlinedAt: !173)
!266 = !DILocation(line: 113, column: 17, scope: !263, inlinedAt: !173)
!267 = !DILocation(line: 113, column: 19, scope: !263, inlinedAt: !173)
!268 = !DILocation(line: 113, column: 22, scope: !263, inlinedAt: !173)
!269 = !DILocation(line: 113, column: 27, scope: !263, inlinedAt: !173)
!270 = !DILocation(line: 113, column: 29, scope: !263, inlinedAt: !173)
!271 = !DILocation(line: 113, column: 32, scope: !263, inlinedAt: !173)
!272 = !DILocation(line: 113, column: 25, scope: !263, inlinedAt: !173)
!273 = !DILocation(line: 113, column: 6, scope: !263, inlinedAt: !173)
!274 = !DILocation(line: 113, column: 8, scope: !263, inlinedAt: !173)
!275 = !DILocation(line: 113, column: 11, scope: !263, inlinedAt: !173)
!276 = !DILocation(line: 113, column: 14, scope: !263, inlinedAt: !173)
!277 = !DILocation(line: 112, column: 28, scope: !263, inlinedAt: !173)
!278 = !DILocation(line: 112, column: 4, scope: !263, inlinedAt: !173)
!279 = distinct !{!279, !265, !280, !133}
!280 = !DILocation(line: 113, column: 33, scope: !260, inlinedAt: !173)
!281 = !DILocation(line: 114, column: 11, scope: !282, inlinedAt: !173)
!282 = distinct !DILexicalBlock(scope: !255, file: !11, line: 114, column: 4)
!283 = !DILocation(line: 114, column: 9, scope: !282, inlinedAt: !173)
!284 = !DILocation(line: 114, column: 16, scope: !285, inlinedAt: !173)
!285 = distinct !DILexicalBlock(scope: !282, file: !11, line: 114, column: 4)
!286 = !DILocation(line: 114, column: 18, scope: !285, inlinedAt: !173)
!287 = !DILocation(line: 114, column: 4, scope: !282, inlinedAt: !173)
!288 = !DILocation(line: 115, column: 16, scope: !285, inlinedAt: !173)
!289 = !DILocation(line: 115, column: 18, scope: !285, inlinedAt: !173)
!290 = !DILocation(line: 115, column: 21, scope: !285, inlinedAt: !173)
!291 = !DILocation(line: 115, column: 26, scope: !285, inlinedAt: !173)
!292 = !DILocation(line: 115, column: 28, scope: !285, inlinedAt: !173)
!293 = !DILocation(line: 115, column: 31, scope: !285, inlinedAt: !173)
!294 = !DILocation(line: 115, column: 36, scope: !285, inlinedAt: !173)
!295 = !DILocation(line: 115, column: 38, scope: !285, inlinedAt: !173)
!296 = !DILocation(line: 115, column: 41, scope: !285, inlinedAt: !173)
!297 = !DILocation(line: 115, column: 34, scope: !285, inlinedAt: !173)
!298 = !DILocation(line: 115, column: 24, scope: !285, inlinedAt: !173)
!299 = !DILocation(line: 115, column: 6, scope: !285, inlinedAt: !173)
!300 = !DILocation(line: 115, column: 8, scope: !285, inlinedAt: !173)
!301 = !DILocation(line: 115, column: 11, scope: !285, inlinedAt: !173)
!302 = !DILocation(line: 115, column: 14, scope: !285, inlinedAt: !173)
!303 = !DILocation(line: 114, column: 28, scope: !285, inlinedAt: !173)
!304 = !DILocation(line: 114, column: 4, scope: !285, inlinedAt: !173)
!305 = distinct !{!305, !287, !306, !133}
!306 = !DILocation(line: 115, column: 42, scope: !282, inlinedAt: !173)
!307 = !DILocation(line: 109, column: 35, scope: !251, inlinedAt: !173)
!308 = !DILocation(line: 109, column: 7, scope: !251, inlinedAt: !173)
!309 = distinct !{!309, !253, !310, !133}
!310 = !DILocation(line: 116, column: 2, scope: !246, inlinedAt: !173)
!311 = !DILocation(line: 101, column: 27, scope: !194, inlinedAt: !173)
!312 = !DILocation(line: 101, column: 3, scope: !194, inlinedAt: !173)
!313 = distinct !{!313, !196, !314, !133}
!314 = !DILocation(line: 117, column: 5, scope: !191, inlinedAt: !173)
!315 = !DILocation(line: 142, column: 3, scope: !167)
!316 = distinct !DISubprogram(name: "workload_checksum", scope: !11, file: !11, line: 144, type: !317, scopeLine: 144, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !2, retainedNodes: !58)
!317 = !DISubroutineType(types: !318)
!318 = !{!20, !6}
!319 = !DILocalVariable(name: "task", arg: 1, scope: !316, file: !11, line: 144, type: !6)
!320 = !DILocation(line: 144, column: 37, scope: !316)
!321 = !DILocation(line: 145, column: 9, scope: !316)
!322 = !DILocation(line: 146, column: 11, scope: !316)
!323 = !DILocation(line: 147, column: 15, scope: !316)
!324 = !DILocation(line: 147, column: 18, scope: !316)
!325 = !DILocation(line: 147, column: 3, scope: !316)
!326 = !DILocation(line: 148, column: 10, scope: !316)
!327 = !DILocation(line: 148, column: 3, scope: !316)
!328 = distinct !DISubprogram(name: "print_array", scope: !11, file: !11, line: 59, type: !74, scopeLine: 63, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition, unit: !2, retainedNodes: !58)
!329 = !DILocalVariable(name: "m", arg: 1, scope: !328, file: !11, line: 59, type: !12)
!330 = !DILocation(line: 59, column: 22, scope: !328)
!331 = !DILocalVariable(name: "n", arg: 2, scope: !328, file: !11, line: 59, type: !12)
!332 = !DILocation(line: 59, column: 29, scope: !328)
!333 = !DILocalVariable(name: "A", arg: 3, scope: !328, file: !11, line: 60, type: !76)
!334 = !DILocation(line: 60, column: 14, scope: !328)
!335 = !DILocalVariable(name: "R", arg: 4, scope: !328, file: !11, line: 61, type: !76)
!336 = !DILocation(line: 61, column: 14, scope: !328)
!337 = !DILocalVariable(name: "Q", arg: 5, scope: !328, file: !11, line: 62, type: !76)
!338 = !DILocation(line: 62, column: 14, scope: !328)
!339 = !DILocalVariable(name: "i", scope: !328, file: !11, line: 64, type: !12)
!340 = !DILocation(line: 64, column: 7, scope: !328)
!341 = !DILocalVariable(name: "j", scope: !328, file: !11, line: 64, type: !12)
!342 = !DILocation(line: 64, column: 10, scope: !328)
!343 = !DILocation(line: 66, column: 3, scope: !328)
!344 = !DILocation(line: 67, column: 3, scope: !328)
!345 = !DILocation(line: 68, column: 10, scope: !346)
!346 = distinct !DILexicalBlock(scope: !328, file: !11, line: 68, column: 3)
!347 = !DILocation(line: 68, column: 8, scope: !346)
!348 = !DILocation(line: 68, column: 15, scope: !349)
!349 = distinct !DILexicalBlock(scope: !346, file: !11, line: 68, column: 3)
!350 = !DILocation(line: 68, column: 19, scope: !349)
!351 = !DILocation(line: 68, column: 17, scope: !349)
!352 = !DILocation(line: 68, column: 3, scope: !346)
!353 = !DILocation(line: 69, column: 12, scope: !354)
!354 = distinct !DILexicalBlock(scope: !349, file: !11, line: 69, column: 5)
!355 = !DILocation(line: 69, column: 10, scope: !354)
!356 = !DILocation(line: 69, column: 17, scope: !357)
!357 = distinct !DILexicalBlock(scope: !354, file: !11, line: 69, column: 5)
!358 = !DILocation(line: 69, column: 21, scope: !357)
!359 = !DILocation(line: 69, column: 19, scope: !357)
!360 = !DILocation(line: 69, column: 5, scope: !354)
!361 = !DILocation(line: 70, column: 7, scope: !362)
!362 = distinct !DILexicalBlock(scope: !363, file: !11, line: 70, column: 6)
!363 = distinct !DILexicalBlock(scope: !357, file: !11, line: 69, column: 29)
!364 = !DILocation(line: 70, column: 9, scope: !362)
!365 = !DILocation(line: 70, column: 8, scope: !362)
!366 = !DILocation(line: 70, column: 11, scope: !362)
!367 = !DILocation(line: 70, column: 10, scope: !362)
!368 = !DILocation(line: 70, column: 14, scope: !362)
!369 = !DILocation(line: 70, column: 19, scope: !362)
!370 = !DILocation(line: 70, column: 6, scope: !363)
!371 = !DILocation(line: 70, column: 34, scope: !362)
!372 = !DILocation(line: 70, column: 25, scope: !362)
!373 = !DILocation(line: 71, column: 11, scope: !363)
!374 = !DILocation(line: 71, column: 56, scope: !363)
!375 = !DILocation(line: 71, column: 58, scope: !363)
!376 = !DILocation(line: 71, column: 61, scope: !363)
!377 = !DILocation(line: 71, column: 2, scope: !363)
!378 = !DILocation(line: 72, column: 5, scope: !363)
!379 = !DILocation(line: 69, column: 25, scope: !357)
!380 = !DILocation(line: 69, column: 5, scope: !357)
!381 = distinct !{!381, !360, !382, !133}
!382 = !DILocation(line: 72, column: 5, scope: !354)
!383 = !DILocation(line: 68, column: 23, scope: !349)
!384 = !DILocation(line: 68, column: 3, scope: !349)
!385 = distinct !{!385, !352, !386, !133}
!386 = !DILocation(line: 72, column: 5, scope: !346)
!387 = !DILocation(line: 73, column: 3, scope: !328)
!388 = !DILocation(line: 75, column: 3, scope: !328)
!389 = !DILocation(line: 76, column: 10, scope: !390)
!390 = distinct !DILexicalBlock(scope: !328, file: !11, line: 76, column: 3)
!391 = !DILocation(line: 76, column: 8, scope: !390)
!392 = !DILocation(line: 76, column: 15, scope: !393)
!393 = distinct !DILexicalBlock(scope: !390, file: !11, line: 76, column: 3)
!394 = !DILocation(line: 76, column: 19, scope: !393)
!395 = !DILocation(line: 76, column: 17, scope: !393)
!396 = !DILocation(line: 76, column: 3, scope: !390)
!397 = !DILocation(line: 77, column: 12, scope: !398)
!398 = distinct !DILexicalBlock(scope: !393, file: !11, line: 77, column: 5)
!399 = !DILocation(line: 77, column: 10, scope: !398)
!400 = !DILocation(line: 77, column: 17, scope: !401)
!401 = distinct !DILexicalBlock(scope: !398, file: !11, line: 77, column: 5)
!402 = !DILocation(line: 77, column: 21, scope: !401)
!403 = !DILocation(line: 77, column: 19, scope: !401)
!404 = !DILocation(line: 77, column: 5, scope: !398)
!405 = !DILocation(line: 78, column: 7, scope: !406)
!406 = distinct !DILexicalBlock(scope: !407, file: !11, line: 78, column: 6)
!407 = distinct !DILexicalBlock(scope: !401, file: !11, line: 77, column: 29)
!408 = !DILocation(line: 78, column: 9, scope: !406)
!409 = !DILocation(line: 78, column: 8, scope: !406)
!410 = !DILocation(line: 78, column: 11, scope: !406)
!411 = !DILocation(line: 78, column: 10, scope: !406)
!412 = !DILocation(line: 78, column: 14, scope: !406)
!413 = !DILocation(line: 78, column: 19, scope: !406)
!414 = !DILocation(line: 78, column: 6, scope: !407)
!415 = !DILocation(line: 78, column: 34, scope: !406)
!416 = !DILocation(line: 78, column: 25, scope: !406)
!417 = !DILocation(line: 79, column: 11, scope: !407)
!418 = !DILocation(line: 79, column: 56, scope: !407)
!419 = !DILocation(line: 79, column: 58, scope: !407)
!420 = !DILocation(line: 79, column: 61, scope: !407)
!421 = !DILocation(line: 79, column: 2, scope: !407)
!422 = !DILocation(line: 80, column: 5, scope: !407)
!423 = !DILocation(line: 77, column: 25, scope: !401)
!424 = !DILocation(line: 77, column: 5, scope: !401)
!425 = distinct !{!425, !404, !426, !133}
!426 = !DILocation(line: 80, column: 5, scope: !398)
!427 = !DILocation(line: 76, column: 23, scope: !393)
!428 = !DILocation(line: 76, column: 3, scope: !393)
!429 = distinct !{!429, !396, !430, !133}
!430 = !DILocation(line: 80, column: 5, scope: !390)
!431 = !DILocation(line: 81, column: 3, scope: !328)
!432 = !DILocation(line: 82, column: 3, scope: !328)
!433 = !DILocation(line: 83, column: 1, scope: !328)
!434 = distinct !DISubprogram(name: "pb_fprintf", scope: !32, file: !32, line: 13, type: !435, scopeLine: 14, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition, unit: !2, retainedNodes: !58)
!435 = !DISubroutineType(types: !436)
!436 = !{!12, !437, !496, null}
!437 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !438, size: 64)
!438 = !DIDerivedType(tag: DW_TAG_typedef, name: "FILE", file: !439, line: 7, baseType: !440)
!439 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/types/FILE.h", directory: "", checksumkind: CSK_MD5, checksum: "571f9fb6223c42439075fdde11a0de5d")
!440 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "_IO_FILE", file: !441, line: 49, size: 1728, elements: !442)
!441 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/types/struct_FILE.h", directory: "", checksumkind: CSK_MD5, checksum: "1bad07471b7974df4ecc1d1c2ca207e6")
!442 = !{!443, !444, !447, !448, !449, !450, !451, !452, !453, !454, !455, !456, !457, !460, !462, !463, !464, !467, !469, !471, !473, !476, !478, !481, !484, !485, !487, !491, !492}
!443 = !DIDerivedType(tag: DW_TAG_member, name: "_flags", scope: !440, file: !441, line: 51, baseType: !12, size: 32)
!444 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_read_ptr", scope: !440, file: !441, line: 54, baseType: !445, size: 64, offset: 64)
!445 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !446, size: 64)
!446 = !DIBasicType(name: "char", size: 8, encoding: DW_ATE_signed_char)
!447 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_read_end", scope: !440, file: !441, line: 55, baseType: !445, size: 64, offset: 128)
!448 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_read_base", scope: !440, file: !441, line: 56, baseType: !445, size: 64, offset: 192)
!449 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_write_base", scope: !440, file: !441, line: 57, baseType: !445, size: 64, offset: 256)
!450 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_write_ptr", scope: !440, file: !441, line: 58, baseType: !445, size: 64, offset: 320)
!451 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_write_end", scope: !440, file: !441, line: 59, baseType: !445, size: 64, offset: 384)
!452 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_buf_base", scope: !440, file: !441, line: 60, baseType: !445, size: 64, offset: 448)
!453 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_buf_end", scope: !440, file: !441, line: 61, baseType: !445, size: 64, offset: 512)
!454 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_save_base", scope: !440, file: !441, line: 64, baseType: !445, size: 64, offset: 576)
!455 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_backup_base", scope: !440, file: !441, line: 65, baseType: !445, size: 64, offset: 640)
!456 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_save_end", scope: !440, file: !441, line: 66, baseType: !445, size: 64, offset: 704)
!457 = !DIDerivedType(tag: DW_TAG_member, name: "_markers", scope: !440, file: !441, line: 68, baseType: !458, size: 64, offset: 768)
!458 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !459, size: 64)
!459 = !DICompositeType(tag: DW_TAG_structure_type, name: "_IO_marker", file: !441, line: 36, flags: DIFlagFwdDecl)
!460 = !DIDerivedType(tag: DW_TAG_member, name: "_chain", scope: !440, file: !441, line: 70, baseType: !461, size: 64, offset: 832)
!461 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !440, size: 64)
!462 = !DIDerivedType(tag: DW_TAG_member, name: "_fileno", scope: !440, file: !441, line: 72, baseType: !12, size: 32, offset: 896)
!463 = !DIDerivedType(tag: DW_TAG_member, name: "_flags2", scope: !440, file: !441, line: 73, baseType: !12, size: 32, offset: 928)
!464 = !DIDerivedType(tag: DW_TAG_member, name: "_old_offset", scope: !440, file: !441, line: 74, baseType: !465, size: 64, offset: 960)
!465 = !DIDerivedType(tag: DW_TAG_typedef, name: "__off_t", file: !23, line: 152, baseType: !466)
!466 = !DIBasicType(name: "long", size: 64, encoding: DW_ATE_signed)
!467 = !DIDerivedType(tag: DW_TAG_member, name: "_cur_column", scope: !440, file: !441, line: 77, baseType: !468, size: 16, offset: 1024)
!468 = !DIBasicType(name: "unsigned short", size: 16, encoding: DW_ATE_unsigned)
!469 = !DIDerivedType(tag: DW_TAG_member, name: "_vtable_offset", scope: !440, file: !441, line: 78, baseType: !470, size: 8, offset: 1040)
!470 = !DIBasicType(name: "signed char", size: 8, encoding: DW_ATE_signed_char)
!471 = !DIDerivedType(tag: DW_TAG_member, name: "_shortbuf", scope: !440, file: !441, line: 79, baseType: !472, size: 8, offset: 1048)
!472 = !DICompositeType(tag: DW_TAG_array_type, baseType: !446, size: 8, elements: !24)
!473 = !DIDerivedType(tag: DW_TAG_member, name: "_lock", scope: !440, file: !441, line: 81, baseType: !474, size: 64, offset: 1088)
!474 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !475, size: 64)
!475 = !DIDerivedType(tag: DW_TAG_typedef, name: "_IO_lock_t", file: !441, line: 43, baseType: null)
!476 = !DIDerivedType(tag: DW_TAG_member, name: "_offset", scope: !440, file: !441, line: 89, baseType: !477, size: 64, offset: 1152)
!477 = !DIDerivedType(tag: DW_TAG_typedef, name: "__off64_t", file: !23, line: 153, baseType: !466)
!478 = !DIDerivedType(tag: DW_TAG_member, name: "_codecvt", scope: !440, file: !441, line: 91, baseType: !479, size: 64, offset: 1216)
!479 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !480, size: 64)
!480 = !DICompositeType(tag: DW_TAG_structure_type, name: "_IO_codecvt", file: !441, line: 37, flags: DIFlagFwdDecl)
!481 = !DIDerivedType(tag: DW_TAG_member, name: "_wide_data", scope: !440, file: !441, line: 92, baseType: !482, size: 64, offset: 1280)
!482 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !483, size: 64)
!483 = !DICompositeType(tag: DW_TAG_structure_type, name: "_IO_wide_data", file: !441, line: 38, flags: DIFlagFwdDecl)
!484 = !DIDerivedType(tag: DW_TAG_member, name: "_freeres_list", scope: !440, file: !441, line: 93, baseType: !461, size: 64, offset: 1344)
!485 = !DIDerivedType(tag: DW_TAG_member, name: "_freeres_buf", scope: !440, file: !441, line: 94, baseType: !486, size: 64, offset: 1408)
!486 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: null, size: 64)
!487 = !DIDerivedType(tag: DW_TAG_member, name: "__pad5", scope: !440, file: !441, line: 95, baseType: !488, size: 64, offset: 1472)
!488 = !DIDerivedType(tag: DW_TAG_typedef, name: "size_t", file: !489, line: 46, baseType: !490)
!489 = !DIFile(filename: "/usr/lib/llvm-14/lib/clang/14.0.0/include/stddef.h", directory: "", checksumkind: CSK_MD5, checksum: "2499dd2361b915724b073282bea3a7bc")
!490 = !DIBasicType(name: "unsigned long", size: 64, encoding: DW_ATE_unsigned)
!491 = !DIDerivedType(tag: DW_TAG_member, name: "_mode", scope: !440, file: !441, line: 96, baseType: !12, size: 32, offset: 1536)
!492 = !DIDerivedType(tag: DW_TAG_member, name: "_unused2", scope: !440, file: !441, line: 98, baseType: !493, size: 160, offset: 1568)
!493 = !DICompositeType(tag: DW_TAG_array_type, baseType: !446, size: 160, elements: !494)
!494 = !{!495}
!495 = !DISubrange(count: 20)
!496 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !497, size: 64)
!497 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !446)
!498 = !DILocalVariable(name: "stream", arg: 1, scope: !434, file: !32, line: 13, type: !437)
!499 = !DILocation(line: 13, column: 29, scope: !434)
!500 = !DILocalVariable(name: "format", arg: 2, scope: !434, file: !32, line: 13, type: !496)
!501 = !DILocation(line: 13, column: 49, scope: !434)
!502 = !DILocalVariable(name: "buffer", scope: !434, file: !32, line: 15, type: !503)
!503 = !DICompositeType(tag: DW_TAG_array_type, baseType: !446, size: 6144, elements: !504)
!504 = !{!505}
!505 = !DISubrange(count: 768)
!506 = !DILocation(line: 15, column: 10, scope: !434)
!507 = !DILocalVariable(name: "args", scope: !434, file: !32, line: 16, type: !508)
!508 = !DIDerivedType(tag: DW_TAG_typedef, name: "va_list", file: !509, line: 52, baseType: !510)
!509 = !DIFile(filename: "/usr/include/stdio.h", directory: "", checksumkind: CSK_MD5, checksum: "f31eefcc3f15835fc5a4023a625cf609")
!510 = !DIDerivedType(tag: DW_TAG_typedef, name: "__gnuc_va_list", file: !511, line: 32, baseType: !512)
!511 = !DIFile(filename: "/usr/lib/llvm-14/lib/clang/14.0.0/include/stdarg.h", directory: "", checksumkind: CSK_MD5, checksum: "4de3cbd931b589d291e5c39387aecf82")
!512 = !DIDerivedType(tag: DW_TAG_typedef, name: "__builtin_va_list", file: !513, baseType: !514)
!513 = !DIFile(filename: "source/workload.c", directory: "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/affine-bounds-20260929/suite/gramschmidt")
!514 = !DICompositeType(tag: DW_TAG_array_type, baseType: !515, size: 192, elements: !24)
!515 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "__va_list_tag", size: 192, elements: !516)
!516 = !{!517, !518, !519, !520}
!517 = !DIDerivedType(tag: DW_TAG_member, name: "gp_offset", scope: !515, file: !513, line: 16, baseType: !6, size: 32)
!518 = !DIDerivedType(tag: DW_TAG_member, name: "fp_offset", scope: !515, file: !513, line: 16, baseType: !6, size: 32, offset: 32)
!519 = !DIDerivedType(tag: DW_TAG_member, name: "overflow_arg_area", scope: !515, file: !513, line: 16, baseType: !486, size: 64, offset: 64)
!520 = !DIDerivedType(tag: DW_TAG_member, name: "reg_save_area", scope: !515, file: !513, line: 16, baseType: !486, size: 64, offset: 128)
!521 = !DILocation(line: 16, column: 13, scope: !434)
!522 = !DILocation(line: 17, column: 5, scope: !434)
!523 = !DILocalVariable(name: "count", scope: !434, file: !32, line: 18, type: !12)
!524 = !DILocation(line: 18, column: 9, scope: !434)
!525 = !DILocation(line: 18, column: 27, scope: !434)
!526 = !DILocation(line: 18, column: 51, scope: !434)
!527 = !DILocation(line: 18, column: 59, scope: !434)
!528 = !DILocation(line: 18, column: 17, scope: !434)
!529 = !DILocation(line: 19, column: 5, scope: !434)
!530 = !DILocation(line: 20, column: 9, scope: !531)
!531 = distinct !DILexicalBlock(scope: !434, file: !32, line: 20, column: 9)
!532 = !DILocation(line: 20, column: 15, scope: !531)
!533 = !DILocation(line: 20, column: 19, scope: !531)
!534 = !DILocation(line: 20, column: 32, scope: !531)
!535 = !DILocation(line: 20, column: 22, scope: !531)
!536 = !DILocation(line: 20, column: 38, scope: !531)
!537 = !DILocation(line: 20, column: 9, scope: !434)
!538 = !DILocation(line: 20, column: 57, scope: !531)
!539 = !DILocalVariable(name: "i", scope: !540, file: !32, line: 21, type: !12)
!540 = distinct !DILexicalBlock(scope: !434, file: !32, line: 21, column: 5)
!541 = !DILocation(line: 21, column: 14, scope: !540)
!542 = !DILocation(line: 21, column: 10, scope: !540)
!543 = !DILocation(line: 21, column: 21, scope: !544)
!544 = distinct !DILexicalBlock(scope: !540, file: !32, line: 21, column: 5)
!545 = !DILocation(line: 21, column: 25, scope: !544)
!546 = !DILocation(line: 21, column: 23, scope: !544)
!547 = !DILocation(line: 21, column: 5, scope: !540)
!548 = !DILocation(line: 22, column: 42, scope: !549)
!549 = distinct !DILexicalBlock(scope: !544, file: !32, line: 21, column: 37)
!550 = !DILocation(line: 22, column: 35, scope: !549)
!551 = !DILocation(line: 22, column: 20, scope: !549)
!552 = !DILocation(line: 22, column: 17, scope: !549)
!553 = !DILocation(line: 23, column: 17, scope: !549)
!554 = !DILocation(line: 24, column: 5, scope: !549)
!555 = !DILocation(line: 21, column: 32, scope: !544)
!556 = !DILocation(line: 21, column: 5, scope: !544)
!557 = distinct !{!557, !547, !558, !133}
!558 = !DILocation(line: 24, column: 5, scope: !540)
!559 = !DILocation(line: 28, column: 11, scope: !434)
!560 = !DILocation(line: 29, column: 11, scope: !434)
!561 = !DILocation(line: 31, column: 12, scope: !434)
!562 = !DILocation(line: 31, column: 5, scope: !434)
