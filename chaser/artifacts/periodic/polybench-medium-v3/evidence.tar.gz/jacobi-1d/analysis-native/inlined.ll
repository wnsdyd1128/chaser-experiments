; ModuleID = 'workload.ll'
source_filename = "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/affine-bounds-20260929/suite/jacobi-1d/source/workload.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

%struct._IO_FILE = type { i32, i8*, i8*, i8*, i8*, i8*, i8*, i8*, i8*, i8*, i8*, i8*, %struct._IO_marker*, %struct._IO_FILE*, i32, i32, i64, i16, i8, [1 x i8], i8*, i64, %struct._IO_codecvt*, %struct._IO_wide_data*, %struct._IO_FILE*, i8*, i64, i32, [20 x i8] }
%struct._IO_marker = type opaque
%struct._IO_codecvt = type opaque
%struct._IO_wide_data = type opaque
%struct.__va_list_tag = type { i32, i32, i8*, i8* }

@n = dso_local global i32 400, align 4, !dbg !0
@tsteps = dso_local global i32 100, align 4, !dbg !9
@A = dso_local global [400 x double] zeroinitializer, section ".chaser_data.A", align 64, !dbg !33
@B = dso_local global [400 x double] zeroinitializer, section ".chaser_data.B", align 64, !dbg !38
@.str = private unnamed_addr constant [12 x i8] c"ape.analyze\00", section "llvm.metadata"
@.str.1 = private unnamed_addr constant [127 x i8] c"/workspace/experiments-array-support/chaser/.cache/periodic-polybench/affine-bounds-20260929/suite/jacobi-1d/source/workload.c\00", section "llvm.metadata"
@pb_hash = internal global i32 0, align 4, !dbg !30
@workload_jobs = dso_local constant [1 x i32 ()*] [i32 ()* @task_job_polybench], align 8, !dbg !13
@workload_expected = dso_local constant [1 x i32] [i32 548581004], align 4, !dbg !26
@stderr = external global %struct._IO_FILE*, align 8
@.str.2 = private unnamed_addr constant [23 x i8] c"==BEGIN DUMP_ARRAYS==\0A\00", align 1
@.str.3 = private unnamed_addr constant [15 x i8] c"begin dump: %s\00", align 1
@.str.4 = private unnamed_addr constant [2 x i8] c"A\00", align 1
@.str.5 = private unnamed_addr constant [2 x i8] c"\0A\00", align 1
@.str.6 = private unnamed_addr constant [8 x i8] c"%0.2lf \00", align 1
@.str.7 = private unnamed_addr constant [17 x i8] c"\0Aend   dump: %s\0A\00", align 1
@.str.8 = private unnamed_addr constant [23 x i8] c"==END   DUMP_ARRAYS==\0A\00", align 1
@pb_emit = internal global i32 1, align 4, !dbg !40
@llvm.global.annotations = appending global [1 x { i8*, i8*, i8*, i32, i8* }] [{ i8*, i8*, i8*, i32, i8* } { i8* bitcast (i32 ()* @task_job_polybench to i8*), i8* getelementptr inbounds ([12 x i8], [12 x i8]* @.str, i32 0, i32 0), i8* getelementptr inbounds ([127 x i8], [127 x i8]* @.str.1, i32 0, i32 0), i32 105, i8* null }], section "llvm.metadata"

; Function Attrs: noinline nounwind uwtable
define dso_local void @workload_prepare() #0 !dbg !50 {
  ret void, !dbg !54
}

; Function Attrs: noinline nounwind uwtable
define dso_local void @workload_reset(i32 noundef %0) #0 !dbg !55 {
  call void @llvm.dbg.value(metadata i32 %0, metadata !58, metadata !DIExpression()), !dbg !59
  call void @llvm.memset.p0i8.i64(i8* align 64 bitcast ([400 x double]* @A to i8*), i8 0, i64 3200, i1 false), !dbg !60
  call void @llvm.memset.p0i8.i64(i8* align 64 bitcast ([400 x double]* @B to i8*), i8 0, i64 3200, i1 false), !dbg !61
  %2 = load i32, i32* @n, align 4, !dbg !62
  call void @init_array(i32 noundef %2, double* noundef getelementptr inbounds ([400 x double], [400 x double]* @A, i64 0, i64 0), double* noundef getelementptr inbounds ([400 x double], [400 x double]* @B, i64 0, i64 0)), !dbg !63
  ret void, !dbg !64
}

; Function Attrs: nofree nosync nounwind readnone speculatable willreturn
declare void @llvm.dbg.declare(metadata, metadata, metadata) #1

; Function Attrs: argmemonly nofree nounwind willreturn writeonly
declare void @llvm.memset.p0i8.i64(i8* nocapture writeonly, i8, i64, i1 immarg) #2

; Function Attrs: noinline nounwind uwtable
define internal void @init_array(i32 noundef %0, double* noundef %1, double* noundef %2) #0 !dbg !65 {
  call void @llvm.dbg.value(metadata i32 %0, metadata !69, metadata !DIExpression()), !dbg !70
  call void @llvm.dbg.value(metadata double* %1, metadata !71, metadata !DIExpression()), !dbg !70
  call void @llvm.dbg.value(metadata double* %2, metadata !72, metadata !DIExpression()), !dbg !70
  call void @llvm.dbg.value(metadata i32 0, metadata !73, metadata !DIExpression()), !dbg !70
  br label %4, !dbg !74

4:                                                ; preds = %19, %3
  %.0 = phi i32 [ 0, %3 ], [ %20, %19 ], !dbg !76
  call void @llvm.dbg.value(metadata i32 %.0, metadata !73, metadata !DIExpression()), !dbg !70
  %5 = icmp slt i32 %.0, %0, !dbg !77
  br i1 %5, label %6, label %21, !dbg !79

6:                                                ; preds = %4
  %7 = sitofp i32 %.0 to double, !dbg !80
  %8 = fadd double %7, 2.000000e+00, !dbg !82
  %9 = sitofp i32 %0 to double, !dbg !83
  %10 = fdiv double %8, %9, !dbg !84
  %11 = sext i32 %.0 to i64, !dbg !85
  %12 = getelementptr inbounds double, double* %1, i64 %11, !dbg !85
  store double %10, double* %12, align 8, !dbg !86
  %13 = sitofp i32 %.0 to double, !dbg !87
  %14 = fadd double %13, 3.000000e+00, !dbg !88
  %15 = sitofp i32 %0 to double, !dbg !89
  %16 = fdiv double %14, %15, !dbg !90
  %17 = sext i32 %.0 to i64, !dbg !91
  %18 = getelementptr inbounds double, double* %2, i64 %17, !dbg !91
  store double %16, double* %18, align 8, !dbg !92
  br label %19, !dbg !93

19:                                               ; preds = %6
  %20 = add nsw i32 %.0, 1, !dbg !94
  call void @llvm.dbg.value(metadata i32 %20, metadata !73, metadata !DIExpression()), !dbg !70
  br label %4, !dbg !95, !llvm.loop !96

21:                                               ; preds = %4
  ret void, !dbg !99
}

; Function Attrs: noinline nounwind uwtable
define dso_local i32 @task_job_polybench() #0 !dbg !100 {
  %1 = load i32, i32* @tsteps, align 4, !dbg !101
  %2 = load i32, i32* @n, align 4, !dbg !102
  call void @llvm.dbg.value(metadata i32 %1, metadata !103, metadata !DIExpression()), !dbg !107
  call void @llvm.dbg.value(metadata i32 %2, metadata !109, metadata !DIExpression()), !dbg !107
  call void @llvm.dbg.value(metadata double* getelementptr inbounds ([400 x double], [400 x double]* @A, i64 0, i64 0), metadata !110, metadata !DIExpression()), !dbg !107
  call void @llvm.dbg.value(metadata double* getelementptr inbounds ([400 x double], [400 x double]* @B, i64 0, i64 0), metadata !111, metadata !DIExpression()), !dbg !107
  call void @llvm.dbg.value(metadata i32 0, metadata !112, metadata !DIExpression()), !dbg !107
  br label %3, !dbg !113

3:                                                ; preds = %47, %0
  %.01 = phi i32 [ 0, %0 ], [ %48, %47 ], !dbg !115
  call void @llvm.dbg.value(metadata i32 %.01, metadata !112, metadata !DIExpression()), !dbg !107
  %4 = icmp slt i32 %.01, 100, !dbg !116
  br i1 %4, label %5, label %49, !dbg !118

5:                                                ; preds = %3
  call void @llvm.dbg.value(metadata i32 1, metadata !119, metadata !DIExpression()), !dbg !107
  br label %6, !dbg !120

6:                                                ; preds = %8, %5
  %.0 = phi i32 [ 1, %5 ], [ %25, %8 ], !dbg !123
  call void @llvm.dbg.value(metadata i32 %.0, metadata !119, metadata !DIExpression()), !dbg !107
  %7 = icmp slt i32 %.0, 399, !dbg !124
  br i1 %7, label %8, label %26, !dbg !126

8:                                                ; preds = %6
  %9 = sub nsw i32 %.0, 1, !dbg !127
  %10 = sext i32 %9 to i64, !dbg !128
  %11 = getelementptr inbounds double, double* getelementptr inbounds ([400 x double], [400 x double]* @A, i64 0, i64 0), i64 %10, !dbg !128
  %12 = load double, double* %11, align 8, !dbg !128
  %13 = sext i32 %.0 to i64, !dbg !129
  %14 = getelementptr inbounds double, double* getelementptr inbounds ([400 x double], [400 x double]* @A, i64 0, i64 0), i64 %13, !dbg !129
  %15 = load double, double* %14, align 8, !dbg !129
  %16 = fadd double %12, %15, !dbg !130
  %17 = add nsw i32 %.0, 1, !dbg !131
  %18 = sext i32 %17 to i64, !dbg !132
  %19 = getelementptr inbounds double, double* getelementptr inbounds ([400 x double], [400 x double]* @A, i64 0, i64 0), i64 %18, !dbg !132
  %20 = load double, double* %19, align 8, !dbg !132
  %21 = fadd double %16, %20, !dbg !133
  %22 = fmul double 3.333300e-01, %21, !dbg !134
  %23 = sext i32 %.0 to i64, !dbg !135
  %24 = getelementptr inbounds double, double* getelementptr inbounds ([400 x double], [400 x double]* @B, i64 0, i64 0), i64 %23, !dbg !135
  store double %22, double* %24, align 8, !dbg !136
  %25 = add nsw i32 %.0, 1, !dbg !137
  call void @llvm.dbg.value(metadata i32 %25, metadata !119, metadata !DIExpression()), !dbg !107
  br label %6, !dbg !138, !llvm.loop !139

26:                                               ; preds = %6
  call void @llvm.dbg.value(metadata i32 1, metadata !119, metadata !DIExpression()), !dbg !107
  br label %27, !dbg !141

27:                                               ; preds = %29, %26
  %.1 = phi i32 [ 1, %26 ], [ %46, %29 ], !dbg !143
  call void @llvm.dbg.value(metadata i32 %.1, metadata !119, metadata !DIExpression()), !dbg !107
  %28 = icmp slt i32 %.1, 399, !dbg !144
  br i1 %28, label %29, label %47, !dbg !146

29:                                               ; preds = %27
  %30 = sub nsw i32 %.1, 1, !dbg !147
  %31 = sext i32 %30 to i64, !dbg !148
  %32 = getelementptr inbounds double, double* getelementptr inbounds ([400 x double], [400 x double]* @B, i64 0, i64 0), i64 %31, !dbg !148
  %33 = load double, double* %32, align 8, !dbg !148
  %34 = sext i32 %.1 to i64, !dbg !149
  %35 = getelementptr inbounds double, double* getelementptr inbounds ([400 x double], [400 x double]* @B, i64 0, i64 0), i64 %34, !dbg !149
  %36 = load double, double* %35, align 8, !dbg !149
  %37 = fadd double %33, %36, !dbg !150
  %38 = add nsw i32 %.1, 1, !dbg !151
  %39 = sext i32 %38 to i64, !dbg !152
  %40 = getelementptr inbounds double, double* getelementptr inbounds ([400 x double], [400 x double]* @B, i64 0, i64 0), i64 %39, !dbg !152
  %41 = load double, double* %40, align 8, !dbg !152
  %42 = fadd double %37, %41, !dbg !153
  %43 = fmul double 3.333300e-01, %42, !dbg !154
  %44 = sext i32 %.1 to i64, !dbg !155
  %45 = getelementptr inbounds double, double* getelementptr inbounds ([400 x double], [400 x double]* @A, i64 0, i64 0), i64 %44, !dbg !155
  store double %43, double* %45, align 8, !dbg !156
  %46 = add nsw i32 %.1, 1, !dbg !157
  call void @llvm.dbg.value(metadata i32 %46, metadata !119, metadata !DIExpression()), !dbg !107
  br label %27, !dbg !158, !llvm.loop !159

47:                                               ; preds = %27
  %48 = add nsw i32 %.01, 1, !dbg !161
  call void @llvm.dbg.value(metadata i32 %48, metadata !112, metadata !DIExpression()), !dbg !107
  br label %3, !dbg !162, !llvm.loop !163

49:                                               ; preds = %3
  ret i32 0, !dbg !165
}

; Function Attrs: noinline nounwind uwtable
define dso_local i32 @workload_checksum(i32 noundef %0) #0 !dbg !166 {
  call void @llvm.dbg.value(metadata i32 %0, metadata !169, metadata !DIExpression()), !dbg !170
  store i32 -2128831035, i32* @pb_hash, align 4, !dbg !171
  %2 = load i32, i32* @n, align 4, !dbg !172
  call void @print_array(i32 noundef %2, double* noundef getelementptr inbounds ([400 x double], [400 x double]* @A, i64 0, i64 0)), !dbg !173
  %3 = load i32, i32* @pb_hash, align 4, !dbg !174
  ret i32 %3, !dbg !175
}

; Function Attrs: noinline nounwind uwtable
define internal void @print_array(i32 noundef %0, double* noundef %1) #0 !dbg !176 {
  call void @llvm.dbg.value(metadata i32 %0, metadata !179, metadata !DIExpression()), !dbg !180
  call void @llvm.dbg.value(metadata double* %1, metadata !181, metadata !DIExpression()), !dbg !180
  %3 = load %struct._IO_FILE*, %struct._IO_FILE** @stderr, align 8, !dbg !182
  %4 = call i32 (%struct._IO_FILE*, i8*, ...) @pb_fprintf(%struct._IO_FILE* noundef %3, i8* noundef getelementptr inbounds ([23 x i8], [23 x i8]* @.str.2, i64 0, i64 0)), !dbg !182
  %5 = load %struct._IO_FILE*, %struct._IO_FILE** @stderr, align 8, !dbg !183
  %6 = call i32 (%struct._IO_FILE*, i8*, ...) @pb_fprintf(%struct._IO_FILE* noundef %5, i8* noundef getelementptr inbounds ([15 x i8], [15 x i8]* @.str.3, i64 0, i64 0), i8* noundef getelementptr inbounds ([2 x i8], [2 x i8]* @.str.4, i64 0, i64 0)), !dbg !183
  call void @llvm.dbg.value(metadata i32 0, metadata !184, metadata !DIExpression()), !dbg !180
  br label %7, !dbg !185

7:                                                ; preds = %21, %2
  %.0 = phi i32 [ 0, %2 ], [ %22, %21 ], !dbg !187
  call void @llvm.dbg.value(metadata i32 %.0, metadata !184, metadata !DIExpression()), !dbg !180
  %8 = icmp slt i32 %.0, %0, !dbg !188
  br i1 %8, label %9, label %23, !dbg !190

9:                                                ; preds = %7
  %10 = srem i32 %.0, 20, !dbg !191
  %11 = icmp eq i32 %10, 0, !dbg !194
  br i1 %11, label %12, label %15, !dbg !195

12:                                               ; preds = %9
  %13 = load %struct._IO_FILE*, %struct._IO_FILE** @stderr, align 8, !dbg !196
  %14 = call i32 (%struct._IO_FILE*, i8*, ...) @pb_fprintf(%struct._IO_FILE* noundef %13, i8* noundef getelementptr inbounds ([2 x i8], [2 x i8]* @.str.5, i64 0, i64 0)), !dbg !197
  br label %15, !dbg !197

15:                                               ; preds = %12, %9
  %16 = load %struct._IO_FILE*, %struct._IO_FILE** @stderr, align 8, !dbg !198
  %17 = sext i32 %.0 to i64, !dbg !199
  %18 = getelementptr inbounds double, double* %1, i64 %17, !dbg !199
  %19 = load double, double* %18, align 8, !dbg !199
  %20 = call i32 (%struct._IO_FILE*, i8*, ...) @pb_fprintf(%struct._IO_FILE* noundef %16, i8* noundef getelementptr inbounds ([8 x i8], [8 x i8]* @.str.6, i64 0, i64 0), double noundef %19), !dbg !200
  br label %21, !dbg !201

21:                                               ; preds = %15
  %22 = add nsw i32 %.0, 1, !dbg !202
  call void @llvm.dbg.value(metadata i32 %22, metadata !184, metadata !DIExpression()), !dbg !180
  br label %7, !dbg !203, !llvm.loop !204

23:                                               ; preds = %7
  %24 = load %struct._IO_FILE*, %struct._IO_FILE** @stderr, align 8, !dbg !206
  %25 = call i32 (%struct._IO_FILE*, i8*, ...) @pb_fprintf(%struct._IO_FILE* noundef %24, i8* noundef getelementptr inbounds ([17 x i8], [17 x i8]* @.str.7, i64 0, i64 0), i8* noundef getelementptr inbounds ([2 x i8], [2 x i8]* @.str.4, i64 0, i64 0)), !dbg !206
  %26 = load %struct._IO_FILE*, %struct._IO_FILE** @stderr, align 8, !dbg !207
  %27 = call i32 (%struct._IO_FILE*, i8*, ...) @pb_fprintf(%struct._IO_FILE* noundef %26, i8* noundef getelementptr inbounds ([23 x i8], [23 x i8]* @.str.8, i64 0, i64 0)), !dbg !207
  ret void, !dbg !208
}

; Function Attrs: noinline nounwind uwtable
define internal i32 @pb_fprintf(%struct._IO_FILE* noundef %0, i8* noundef %1, ...) #0 !dbg !209 {
  %3 = alloca [768 x i8], align 16
  %4 = alloca [1 x %struct.__va_list_tag], align 16
  call void @llvm.dbg.value(metadata %struct._IO_FILE* %0, metadata !273, metadata !DIExpression()), !dbg !274
  call void @llvm.dbg.value(metadata i8* %1, metadata !275, metadata !DIExpression()), !dbg !274
  call void @llvm.dbg.declare(metadata [768 x i8]* %3, metadata !276, metadata !DIExpression()), !dbg !280
  call void @llvm.dbg.declare(metadata [1 x %struct.__va_list_tag]* %4, metadata !281, metadata !DIExpression()), !dbg !295
  %5 = getelementptr inbounds [1 x %struct.__va_list_tag], [1 x %struct.__va_list_tag]* %4, i64 0, i64 0, !dbg !296
  %6 = bitcast %struct.__va_list_tag* %5 to i8*, !dbg !296
  call void @llvm.va_start(i8* %6), !dbg !296
  %7 = getelementptr inbounds [768 x i8], [768 x i8]* %3, i64 0, i64 0, !dbg !297
  %8 = getelementptr inbounds [1 x %struct.__va_list_tag], [1 x %struct.__va_list_tag]* %4, i64 0, i64 0, !dbg !298
  %9 = call i32 @vsnprintf(i8* noundef %7, i64 noundef 768, i8* noundef %1, %struct.__va_list_tag* noundef %8) #6, !dbg !299
  call void @llvm.dbg.value(metadata i32 %9, metadata !300, metadata !DIExpression()), !dbg !274
  %10 = getelementptr inbounds [1 x %struct.__va_list_tag], [1 x %struct.__va_list_tag]* %4, i64 0, i64 0, !dbg !301
  %11 = bitcast %struct.__va_list_tag* %10 to i8*, !dbg !301
  call void @llvm.va_end(i8* %11), !dbg !301
  %12 = icmp slt i32 %9, 0, !dbg !302
  br i1 %12, label %16, label %13, !dbg !304

13:                                               ; preds = %2
  %14 = zext i32 %9 to i64, !dbg !305
  %15 = icmp uge i64 %14, 768, !dbg !306
  br i1 %15, label %16, label %17, !dbg !307

16:                                               ; preds = %13, %2
  call void @abort() #7, !dbg !308
  unreachable, !dbg !308

17:                                               ; preds = %13
  call void @llvm.dbg.value(metadata i32 0, metadata !309, metadata !DIExpression()), !dbg !311
  br label %18, !dbg !312

18:                                               ; preds = %29, %17
  %.0 = phi i32 [ 0, %17 ], [ %30, %29 ], !dbg !311
  call void @llvm.dbg.value(metadata i32 %.0, metadata !309, metadata !DIExpression()), !dbg !311
  %19 = icmp slt i32 %.0, %9, !dbg !313
  br i1 %19, label %20, label %31, !dbg !315

20:                                               ; preds = %18
  %21 = sext i32 %.0 to i64, !dbg !316
  %22 = getelementptr inbounds [768 x i8], [768 x i8]* %3, i64 0, i64 %21, !dbg !316
  %23 = load i8, i8* %22, align 1, !dbg !316
  %24 = zext i8 %23 to i32, !dbg !318
  %25 = load i32, i32* @pb_hash, align 4, !dbg !319
  %26 = xor i32 %25, %24, !dbg !319
  store i32 %26, i32* @pb_hash, align 4, !dbg !319
  %27 = load i32, i32* @pb_hash, align 4, !dbg !320
  %28 = mul i32 %27, 16777619, !dbg !320
  store i32 %28, i32* @pb_hash, align 4, !dbg !320
  br label %29, !dbg !321

29:                                               ; preds = %20
  %30 = add nsw i32 %.0, 1, !dbg !322
  call void @llvm.dbg.value(metadata i32 %30, metadata !309, metadata !DIExpression()), !dbg !311
  br label %18, !dbg !323, !llvm.loop !324

31:                                               ; preds = %18
  %32 = load i32, i32* @pb_emit, align 4, !dbg !326
  ret i32 %9, !dbg !327
}

; Function Attrs: nofree nosync nounwind willreturn
declare void @llvm.va_start(i8*) #3

; Function Attrs: nounwind
declare i32 @vsnprintf(i8* noundef, i64 noundef, i8* noundef, %struct.__va_list_tag* noundef) #4

; Function Attrs: nofree nosync nounwind willreturn
declare void @llvm.va_end(i8*) #3

; Function Attrs: noreturn nounwind
declare void @abort() #5

; Function Attrs: nofree nosync nounwind readnone speculatable willreturn
declare void @llvm.dbg.value(metadata, metadata, metadata) #1

attributes #0 = { noinline nounwind uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { nofree nosync nounwind readnone speculatable willreturn }
attributes #2 = { argmemonly nofree nounwind willreturn writeonly }
attributes #3 = { nofree nosync nounwind willreturn }
attributes #4 = { nounwind "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #5 = { noreturn nounwind "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #6 = { nounwind }
attributes #7 = { noreturn nounwind }

!llvm.dbg.cu = !{!2}
!llvm.module.flags = !{!42, !43, !44, !45, !46, !47, !48}
!llvm.ident = !{!49}

!0 = !DIGlobalVariableExpression(var: !1, expr: !DIExpression())
!1 = distinct !DIGlobalVariable(name: "n", scope: !2, file: !11, line: 96, type: !12, isLocal: false, isDefinition: true)
!2 = distinct !DICompileUnit(language: DW_LANG_C99, file: !3, producer: "Ubuntu clang version 14.0.0-1ubuntu1.1", isOptimized: false, runtimeVersion: 0, emissionKind: FullDebug, retainedTypes: !4, globals: !8, splitDebugInlining: false, nameTableKind: None)
!3 = !DIFile(filename: "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/affine-bounds-20260929/suite/jacobi-1d/source/workload.c", directory: "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/affine-bounds-20260929/suite/jacobi-1d/analysis-native", checksumkind: CSK_MD5, checksum: "32f13b44e0cda1ff9f9c858c735c495e")
!4 = !{!5, !6, !7}
!5 = !DIBasicType(name: "double", size: 64, encoding: DW_ATE_float)
!6 = !DIBasicType(name: "unsigned int", size: 32, encoding: DW_ATE_unsigned)
!7 = !DIBasicType(name: "unsigned char", size: 8, encoding: DW_ATE_unsigned_char)
!8 = !{!0, !9, !13, !26, !30, !33, !38, !40}
!9 = !DIGlobalVariableExpression(var: !10, expr: !DIExpression())
!10 = distinct !DIGlobalVariable(name: "tsteps", scope: !2, file: !11, line: 97, type: !12, isLocal: false, isDefinition: true)
!11 = !DIFile(filename: "source/workload.c", directory: "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/affine-bounds-20260929/suite/jacobi-1d", checksumkind: CSK_MD5, checksum: "32f13b44e0cda1ff9f9c858c735c495e")
!12 = !DIBasicType(name: "int", size: 32, encoding: DW_ATE_signed)
!13 = !DIGlobalVariableExpression(var: !14, expr: !DIExpression())
!14 = distinct !DIGlobalVariable(name: "workload_jobs", scope: !2, file: !11, line: 115, type: !15, isLocal: false, isDefinition: true)
!15 = !DICompositeType(tag: DW_TAG_array_type, baseType: !16, size: 64, elements: !24)
!16 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !17)
!17 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !18, size: 64)
!18 = !DISubroutineType(types: !19)
!19 = !{!20}
!20 = !DIDerivedType(tag: DW_TAG_typedef, name: "uint32_t", file: !21, line: 26, baseType: !22)
!21 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/stdint-uintn.h", directory: "", checksumkind: CSK_MD5, checksum: "2bf2ae53c58c01b1a1b9383b5195125c")
!22 = !DIDerivedType(tag: DW_TAG_typedef, name: "__uint32_t", file: !23, line: 42, baseType: !6)
!23 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/types.h", directory: "", checksumkind: CSK_MD5, checksum: "d108b5f93a74c50510d7d9bc0ab36df9")
!24 = !{!25}
!25 = !DISubrange(count: 1)
!26 = !DIGlobalVariableExpression(var: !27, expr: !DIExpression())
!27 = distinct !DIGlobalVariable(name: "workload_expected", scope: !2, file: !11, line: 119, type: !28, isLocal: false, isDefinition: true)
!28 = !DICompositeType(tag: DW_TAG_array_type, baseType: !29, size: 32, elements: !24)
!29 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !20)
!30 = !DIGlobalVariableExpression(var: !31, expr: !DIExpression())
!31 = distinct !DIGlobalVariable(name: "pb_hash", scope: !2, file: !32, line: 9, type: !20, isLocal: true, isDefinition: true)
!32 = !DIFile(filename: "source/adapter.h", directory: "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/affine-bounds-20260929/suite/jacobi-1d", checksumkind: CSK_MD5, checksum: "26a6068928b2092758f244a9d00163d7")
!33 = !DIGlobalVariableExpression(var: !34, expr: !DIExpression())
!34 = distinct !DIGlobalVariable(name: "A", scope: !2, file: !11, line: 34, type: !35, isLocal: false, isDefinition: true, align: 512)
!35 = !DICompositeType(tag: DW_TAG_array_type, baseType: !5, size: 25600, elements: !36)
!36 = !{!37}
!37 = !DISubrange(count: 400)
!38 = !DIGlobalVariableExpression(var: !39, expr: !DIExpression())
!39 = distinct !DIGlobalVariable(name: "B", scope: !2, file: !11, line: 35, type: !35, isLocal: false, isDefinition: true, align: 512)
!40 = !DIGlobalVariableExpression(var: !41, expr: !DIExpression())
!41 = distinct !DIGlobalVariable(name: "pb_emit", scope: !2, file: !32, line: 10, type: !12, isLocal: true, isDefinition: true)
!42 = !{i32 7, !"Dwarf Version", i32 5}
!43 = !{i32 2, !"Debug Info Version", i32 3}
!44 = !{i32 1, !"wchar_size", i32 4}
!45 = !{i32 7, !"PIC Level", i32 2}
!46 = !{i32 7, !"PIE Level", i32 2}
!47 = !{i32 7, !"uwtable", i32 1}
!48 = !{i32 7, !"frame-pointer", i32 2}
!49 = !{!"Ubuntu clang version 14.0.0-1ubuntu1.1"}
!50 = distinct !DISubprogram(name: "workload_prepare", scope: !11, file: !11, line: 98, type: !51, scopeLine: 98, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !2, retainedNodes: !53)
!51 = !DISubroutineType(types: !52)
!52 = !{null}
!53 = !{}
!54 = !DILocation(line: 98, column: 30, scope: !50)
!55 = distinct !DISubprogram(name: "workload_reset", scope: !11, file: !11, line: 99, type: !56, scopeLine: 99, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !2, retainedNodes: !53)
!56 = !DISubroutineType(types: !57)
!57 = !{null, !6}
!58 = !DILocalVariable(name: "task", arg: 1, scope: !55, file: !11, line: 99, type: !6)
!59 = !DILocation(line: 0, scope: !55)
!60 = !DILocation(line: 101, column: 3, scope: !55)
!61 = !DILocation(line: 102, column: 3, scope: !55)
!62 = !DILocation(line: 103, column: 15, scope: !55)
!63 = !DILocation(line: 103, column: 3, scope: !55)
!64 = !DILocation(line: 104, column: 1, scope: !55)
!65 = distinct !DISubprogram(name: "init_array", scope: !11, file: !11, line: 37, type: !66, scopeLine: 40, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition, unit: !2, retainedNodes: !53)
!66 = !DISubroutineType(types: !67)
!67 = !{null, !12, !68, !68}
!68 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !5, size: 64)
!69 = !DILocalVariable(name: "n", arg: 1, scope: !65, file: !11, line: 37, type: !12)
!70 = !DILocation(line: 0, scope: !65)
!71 = !DILocalVariable(name: "A", arg: 2, scope: !65, file: !11, line: 38, type: !68)
!72 = !DILocalVariable(name: "B", arg: 3, scope: !65, file: !11, line: 39, type: !68)
!73 = !DILocalVariable(name: "i", scope: !65, file: !11, line: 41, type: !12)
!74 = !DILocation(line: 43, column: 8, scope: !75)
!75 = distinct !DILexicalBlock(scope: !65, file: !11, line: 43, column: 3)
!76 = !DILocation(line: 0, scope: !75)
!77 = !DILocation(line: 43, column: 17, scope: !78)
!78 = distinct !DILexicalBlock(scope: !75, file: !11, line: 43, column: 3)
!79 = !DILocation(line: 43, column: 3, scope: !75)
!80 = !DILocation(line: 45, column: 10, scope: !81)
!81 = distinct !DILexicalBlock(scope: !78, file: !11, line: 44, column: 7)
!82 = !DILocation(line: 45, column: 23, scope: !81)
!83 = !DILocation(line: 45, column: 30, scope: !81)
!84 = !DILocation(line: 45, column: 28, scope: !81)
!85 = !DILocation(line: 45, column: 2, scope: !81)
!86 = !DILocation(line: 45, column: 7, scope: !81)
!87 = !DILocation(line: 46, column: 10, scope: !81)
!88 = !DILocation(line: 46, column: 23, scope: !81)
!89 = !DILocation(line: 46, column: 30, scope: !81)
!90 = !DILocation(line: 46, column: 28, scope: !81)
!91 = !DILocation(line: 46, column: 2, scope: !81)
!92 = !DILocation(line: 46, column: 7, scope: !81)
!93 = !DILocation(line: 47, column: 7, scope: !81)
!94 = !DILocation(line: 43, column: 23, scope: !78)
!95 = !DILocation(line: 43, column: 3, scope: !78)
!96 = distinct !{!96, !79, !97, !98}
!97 = !DILocation(line: 47, column: 7, scope: !75)
!98 = !{!"llvm.loop.mustprogress"}
!99 = !DILocation(line: 48, column: 1, scope: !65)
!100 = distinct !DISubprogram(name: "task_job_polybench", scope: !11, file: !11, line: 105, type: !18, scopeLine: 105, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !2, retainedNodes: !53)
!101 = !DILocation(line: 106, column: 20, scope: !100)
!102 = !DILocation(line: 106, column: 28, scope: !100)
!103 = !DILocalVariable(name: "tsteps", arg: 1, scope: !104, file: !11, line: 75, type: !12)
!104 = distinct !DISubprogram(name: "kernel_jacobi_1d", scope: !11, file: !11, line: 75, type: !105, scopeLine: 79, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition, unit: !2, retainedNodes: !53)
!105 = !DISubroutineType(types: !106)
!106 = !{null, !12, !12, !68, !68}
!107 = !DILocation(line: 0, scope: !104, inlinedAt: !108)
!108 = distinct !DILocation(line: 106, column: 3, scope: !100)
!109 = !DILocalVariable(name: "n", arg: 2, scope: !104, file: !11, line: 76, type: !12)
!110 = !DILocalVariable(name: "A", arg: 3, scope: !104, file: !11, line: 77, type: !68)
!111 = !DILocalVariable(name: "B", arg: 4, scope: !104, file: !11, line: 78, type: !68)
!112 = !DILocalVariable(name: "t", scope: !104, file: !11, line: 80, type: !12)
!113 = !DILocation(line: 83, column: 8, scope: !114, inlinedAt: !108)
!114 = distinct !DILexicalBlock(scope: !104, file: !11, line: 83, column: 3)
!115 = !DILocation(line: 0, scope: !114, inlinedAt: !108)
!116 = !DILocation(line: 83, column: 17, scope: !117, inlinedAt: !108)
!117 = distinct !DILexicalBlock(scope: !114, file: !11, line: 83, column: 3)
!118 = !DILocation(line: 83, column: 3, scope: !114, inlinedAt: !108)
!119 = !DILocalVariable(name: "i", scope: !104, file: !11, line: 80, type: !12)
!120 = !DILocation(line: 85, column: 12, scope: !121, inlinedAt: !108)
!121 = distinct !DILexicalBlock(scope: !122, file: !11, line: 85, column: 7)
!122 = distinct !DILexicalBlock(scope: !117, file: !11, line: 84, column: 5)
!123 = !DILocation(line: 0, scope: !121, inlinedAt: !108)
!124 = !DILocation(line: 85, column: 21, scope: !125, inlinedAt: !108)
!125 = distinct !DILexicalBlock(scope: !121, file: !11, line: 85, column: 7)
!126 = !DILocation(line: 85, column: 7, scope: !121, inlinedAt: !108)
!127 = !DILocation(line: 86, column: 23, scope: !125, inlinedAt: !108)
!128 = !DILocation(line: 86, column: 20, scope: !125, inlinedAt: !108)
!129 = !DILocation(line: 86, column: 29, scope: !125, inlinedAt: !108)
!130 = !DILocation(line: 86, column: 27, scope: !125, inlinedAt: !108)
!131 = !DILocation(line: 86, column: 40, scope: !125, inlinedAt: !108)
!132 = !DILocation(line: 86, column: 36, scope: !125, inlinedAt: !108)
!133 = !DILocation(line: 86, column: 34, scope: !125, inlinedAt: !108)
!134 = !DILocation(line: 86, column: 17, scope: !125, inlinedAt: !108)
!135 = !DILocation(line: 86, column: 2, scope: !125, inlinedAt: !108)
!136 = !DILocation(line: 86, column: 7, scope: !125, inlinedAt: !108)
!137 = !DILocation(line: 85, column: 35, scope: !125, inlinedAt: !108)
!138 = !DILocation(line: 85, column: 7, scope: !125, inlinedAt: !108)
!139 = distinct !{!139, !126, !140, !98}
!140 = !DILocation(line: 86, column: 44, scope: !121, inlinedAt: !108)
!141 = !DILocation(line: 87, column: 12, scope: !142, inlinedAt: !108)
!142 = distinct !DILexicalBlock(scope: !122, file: !11, line: 87, column: 7)
!143 = !DILocation(line: 0, scope: !142, inlinedAt: !108)
!144 = !DILocation(line: 87, column: 21, scope: !145, inlinedAt: !108)
!145 = distinct !DILexicalBlock(scope: !142, file: !11, line: 87, column: 7)
!146 = !DILocation(line: 87, column: 7, scope: !142, inlinedAt: !108)
!147 = !DILocation(line: 88, column: 23, scope: !145, inlinedAt: !108)
!148 = !DILocation(line: 88, column: 20, scope: !145, inlinedAt: !108)
!149 = !DILocation(line: 88, column: 29, scope: !145, inlinedAt: !108)
!150 = !DILocation(line: 88, column: 27, scope: !145, inlinedAt: !108)
!151 = !DILocation(line: 88, column: 40, scope: !145, inlinedAt: !108)
!152 = !DILocation(line: 88, column: 36, scope: !145, inlinedAt: !108)
!153 = !DILocation(line: 88, column: 34, scope: !145, inlinedAt: !108)
!154 = !DILocation(line: 88, column: 17, scope: !145, inlinedAt: !108)
!155 = !DILocation(line: 88, column: 2, scope: !145, inlinedAt: !108)
!156 = !DILocation(line: 88, column: 7, scope: !145, inlinedAt: !108)
!157 = !DILocation(line: 87, column: 35, scope: !145, inlinedAt: !108)
!158 = !DILocation(line: 87, column: 7, scope: !145, inlinedAt: !108)
!159 = distinct !{!159, !146, !160, !98}
!160 = !DILocation(line: 88, column: 44, scope: !142, inlinedAt: !108)
!161 = !DILocation(line: 83, column: 32, scope: !117, inlinedAt: !108)
!162 = !DILocation(line: 83, column: 3, scope: !117, inlinedAt: !108)
!163 = distinct !{!163, !118, !164, !98}
!164 = !DILocation(line: 89, column: 5, scope: !114, inlinedAt: !108)
!165 = !DILocation(line: 107, column: 3, scope: !100)
!166 = distinct !DISubprogram(name: "workload_checksum", scope: !11, file: !11, line: 109, type: !167, scopeLine: 109, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !2, retainedNodes: !53)
!167 = !DISubroutineType(types: !168)
!168 = !{!20, !6}
!169 = !DILocalVariable(name: "task", arg: 1, scope: !166, file: !11, line: 109, type: !6)
!170 = !DILocation(line: 0, scope: !166)
!171 = !DILocation(line: 111, column: 11, scope: !166)
!172 = !DILocation(line: 112, column: 15, scope: !166)
!173 = !DILocation(line: 112, column: 3, scope: !166)
!174 = !DILocation(line: 113, column: 10, scope: !166)
!175 = !DILocation(line: 113, column: 3, scope: !166)
!176 = distinct !DISubprogram(name: "print_array", scope: !11, file: !11, line: 54, type: !177, scopeLine: 57, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition, unit: !2, retainedNodes: !53)
!177 = !DISubroutineType(types: !178)
!178 = !{null, !12, !68}
!179 = !DILocalVariable(name: "n", arg: 1, scope: !176, file: !11, line: 54, type: !12)
!180 = !DILocation(line: 0, scope: !176)
!181 = !DILocalVariable(name: "A", arg: 2, scope: !176, file: !11, line: 55, type: !68)
!182 = !DILocation(line: 60, column: 3, scope: !176)
!183 = !DILocation(line: 61, column: 3, scope: !176)
!184 = !DILocalVariable(name: "i", scope: !176, file: !11, line: 58, type: !12)
!185 = !DILocation(line: 62, column: 8, scope: !186)
!186 = distinct !DILexicalBlock(scope: !176, file: !11, line: 62, column: 3)
!187 = !DILocation(line: 0, scope: !186)
!188 = !DILocation(line: 62, column: 17, scope: !189)
!189 = distinct !DILexicalBlock(scope: !186, file: !11, line: 62, column: 3)
!190 = !DILocation(line: 62, column: 3, scope: !186)
!191 = !DILocation(line: 64, column: 13, scope: !192)
!192 = distinct !DILexicalBlock(scope: !193, file: !11, line: 64, column: 11)
!193 = distinct !DILexicalBlock(scope: !189, file: !11, line: 63, column: 5)
!194 = !DILocation(line: 64, column: 18, scope: !192)
!195 = !DILocation(line: 64, column: 11, scope: !193)
!196 = !DILocation(line: 64, column: 32, scope: !192)
!197 = !DILocation(line: 64, column: 24, scope: !192)
!198 = !DILocation(line: 65, column: 15, scope: !193)
!199 = !DILocation(line: 65, column: 60, scope: !193)
!200 = !DILocation(line: 65, column: 7, scope: !193)
!201 = !DILocation(line: 66, column: 5, scope: !193)
!202 = !DILocation(line: 62, column: 23, scope: !189)
!203 = !DILocation(line: 62, column: 3, scope: !189)
!204 = distinct !{!204, !190, !205, !98}
!205 = !DILocation(line: 66, column: 5, scope: !186)
!206 = !DILocation(line: 67, column: 3, scope: !176)
!207 = !DILocation(line: 68, column: 3, scope: !176)
!208 = !DILocation(line: 69, column: 1, scope: !176)
!209 = distinct !DISubprogram(name: "pb_fprintf", scope: !32, file: !32, line: 13, type: !210, scopeLine: 14, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition, unit: !2, retainedNodes: !53)
!210 = !DISubroutineType(types: !211)
!211 = !{!12, !212, !271, null}
!212 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !213, size: 64)
!213 = !DIDerivedType(tag: DW_TAG_typedef, name: "FILE", file: !214, line: 7, baseType: !215)
!214 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/types/FILE.h", directory: "", checksumkind: CSK_MD5, checksum: "571f9fb6223c42439075fdde11a0de5d")
!215 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "_IO_FILE", file: !216, line: 49, size: 1728, elements: !217)
!216 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/types/struct_FILE.h", directory: "", checksumkind: CSK_MD5, checksum: "1bad07471b7974df4ecc1d1c2ca207e6")
!217 = !{!218, !219, !222, !223, !224, !225, !226, !227, !228, !229, !230, !231, !232, !235, !237, !238, !239, !242, !244, !246, !248, !251, !253, !256, !259, !260, !262, !266, !267}
!218 = !DIDerivedType(tag: DW_TAG_member, name: "_flags", scope: !215, file: !216, line: 51, baseType: !12, size: 32)
!219 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_read_ptr", scope: !215, file: !216, line: 54, baseType: !220, size: 64, offset: 64)
!220 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !221, size: 64)
!221 = !DIBasicType(name: "char", size: 8, encoding: DW_ATE_signed_char)
!222 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_read_end", scope: !215, file: !216, line: 55, baseType: !220, size: 64, offset: 128)
!223 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_read_base", scope: !215, file: !216, line: 56, baseType: !220, size: 64, offset: 192)
!224 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_write_base", scope: !215, file: !216, line: 57, baseType: !220, size: 64, offset: 256)
!225 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_write_ptr", scope: !215, file: !216, line: 58, baseType: !220, size: 64, offset: 320)
!226 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_write_end", scope: !215, file: !216, line: 59, baseType: !220, size: 64, offset: 384)
!227 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_buf_base", scope: !215, file: !216, line: 60, baseType: !220, size: 64, offset: 448)
!228 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_buf_end", scope: !215, file: !216, line: 61, baseType: !220, size: 64, offset: 512)
!229 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_save_base", scope: !215, file: !216, line: 64, baseType: !220, size: 64, offset: 576)
!230 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_backup_base", scope: !215, file: !216, line: 65, baseType: !220, size: 64, offset: 640)
!231 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_save_end", scope: !215, file: !216, line: 66, baseType: !220, size: 64, offset: 704)
!232 = !DIDerivedType(tag: DW_TAG_member, name: "_markers", scope: !215, file: !216, line: 68, baseType: !233, size: 64, offset: 768)
!233 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !234, size: 64)
!234 = !DICompositeType(tag: DW_TAG_structure_type, name: "_IO_marker", file: !216, line: 36, flags: DIFlagFwdDecl)
!235 = !DIDerivedType(tag: DW_TAG_member, name: "_chain", scope: !215, file: !216, line: 70, baseType: !236, size: 64, offset: 832)
!236 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !215, size: 64)
!237 = !DIDerivedType(tag: DW_TAG_member, name: "_fileno", scope: !215, file: !216, line: 72, baseType: !12, size: 32, offset: 896)
!238 = !DIDerivedType(tag: DW_TAG_member, name: "_flags2", scope: !215, file: !216, line: 73, baseType: !12, size: 32, offset: 928)
!239 = !DIDerivedType(tag: DW_TAG_member, name: "_old_offset", scope: !215, file: !216, line: 74, baseType: !240, size: 64, offset: 960)
!240 = !DIDerivedType(tag: DW_TAG_typedef, name: "__off_t", file: !23, line: 152, baseType: !241)
!241 = !DIBasicType(name: "long", size: 64, encoding: DW_ATE_signed)
!242 = !DIDerivedType(tag: DW_TAG_member, name: "_cur_column", scope: !215, file: !216, line: 77, baseType: !243, size: 16, offset: 1024)
!243 = !DIBasicType(name: "unsigned short", size: 16, encoding: DW_ATE_unsigned)
!244 = !DIDerivedType(tag: DW_TAG_member, name: "_vtable_offset", scope: !215, file: !216, line: 78, baseType: !245, size: 8, offset: 1040)
!245 = !DIBasicType(name: "signed char", size: 8, encoding: DW_ATE_signed_char)
!246 = !DIDerivedType(tag: DW_TAG_member, name: "_shortbuf", scope: !215, file: !216, line: 79, baseType: !247, size: 8, offset: 1048)
!247 = !DICompositeType(tag: DW_TAG_array_type, baseType: !221, size: 8, elements: !24)
!248 = !DIDerivedType(tag: DW_TAG_member, name: "_lock", scope: !215, file: !216, line: 81, baseType: !249, size: 64, offset: 1088)
!249 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !250, size: 64)
!250 = !DIDerivedType(tag: DW_TAG_typedef, name: "_IO_lock_t", file: !216, line: 43, baseType: null)
!251 = !DIDerivedType(tag: DW_TAG_member, name: "_offset", scope: !215, file: !216, line: 89, baseType: !252, size: 64, offset: 1152)
!252 = !DIDerivedType(tag: DW_TAG_typedef, name: "__off64_t", file: !23, line: 153, baseType: !241)
!253 = !DIDerivedType(tag: DW_TAG_member, name: "_codecvt", scope: !215, file: !216, line: 91, baseType: !254, size: 64, offset: 1216)
!254 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !255, size: 64)
!255 = !DICompositeType(tag: DW_TAG_structure_type, name: "_IO_codecvt", file: !216, line: 37, flags: DIFlagFwdDecl)
!256 = !DIDerivedType(tag: DW_TAG_member, name: "_wide_data", scope: !215, file: !216, line: 92, baseType: !257, size: 64, offset: 1280)
!257 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !258, size: 64)
!258 = !DICompositeType(tag: DW_TAG_structure_type, name: "_IO_wide_data", file: !216, line: 38, flags: DIFlagFwdDecl)
!259 = !DIDerivedType(tag: DW_TAG_member, name: "_freeres_list", scope: !215, file: !216, line: 93, baseType: !236, size: 64, offset: 1344)
!260 = !DIDerivedType(tag: DW_TAG_member, name: "_freeres_buf", scope: !215, file: !216, line: 94, baseType: !261, size: 64, offset: 1408)
!261 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: null, size: 64)
!262 = !DIDerivedType(tag: DW_TAG_member, name: "__pad5", scope: !215, file: !216, line: 95, baseType: !263, size: 64, offset: 1472)
!263 = !DIDerivedType(tag: DW_TAG_typedef, name: "size_t", file: !264, line: 46, baseType: !265)
!264 = !DIFile(filename: "/usr/lib/llvm-14/lib/clang/14.0.0/include/stddef.h", directory: "", checksumkind: CSK_MD5, checksum: "2499dd2361b915724b073282bea3a7bc")
!265 = !DIBasicType(name: "unsigned long", size: 64, encoding: DW_ATE_unsigned)
!266 = !DIDerivedType(tag: DW_TAG_member, name: "_mode", scope: !215, file: !216, line: 96, baseType: !12, size: 32, offset: 1536)
!267 = !DIDerivedType(tag: DW_TAG_member, name: "_unused2", scope: !215, file: !216, line: 98, baseType: !268, size: 160, offset: 1568)
!268 = !DICompositeType(tag: DW_TAG_array_type, baseType: !221, size: 160, elements: !269)
!269 = !{!270}
!270 = !DISubrange(count: 20)
!271 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !272, size: 64)
!272 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !221)
!273 = !DILocalVariable(name: "stream", arg: 1, scope: !209, file: !32, line: 13, type: !212)
!274 = !DILocation(line: 0, scope: !209)
!275 = !DILocalVariable(name: "format", arg: 2, scope: !209, file: !32, line: 13, type: !271)
!276 = !DILocalVariable(name: "buffer", scope: !209, file: !32, line: 15, type: !277)
!277 = !DICompositeType(tag: DW_TAG_array_type, baseType: !221, size: 6144, elements: !278)
!278 = !{!279}
!279 = !DISubrange(count: 768)
!280 = !DILocation(line: 15, column: 10, scope: !209)
!281 = !DILocalVariable(name: "args", scope: !209, file: !32, line: 16, type: !282)
!282 = !DIDerivedType(tag: DW_TAG_typedef, name: "va_list", file: !283, line: 52, baseType: !284)
!283 = !DIFile(filename: "/usr/include/stdio.h", directory: "", checksumkind: CSK_MD5, checksum: "f31eefcc3f15835fc5a4023a625cf609")
!284 = !DIDerivedType(tag: DW_TAG_typedef, name: "__gnuc_va_list", file: !285, line: 32, baseType: !286)
!285 = !DIFile(filename: "/usr/lib/llvm-14/lib/clang/14.0.0/include/stdarg.h", directory: "", checksumkind: CSK_MD5, checksum: "4de3cbd931b589d291e5c39387aecf82")
!286 = !DIDerivedType(tag: DW_TAG_typedef, name: "__builtin_va_list", file: !287, baseType: !288)
!287 = !DIFile(filename: "source/workload.c", directory: "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/affine-bounds-20260929/suite/jacobi-1d")
!288 = !DICompositeType(tag: DW_TAG_array_type, baseType: !289, size: 192, elements: !24)
!289 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "__va_list_tag", size: 192, elements: !290)
!290 = !{!291, !292, !293, !294}
!291 = !DIDerivedType(tag: DW_TAG_member, name: "gp_offset", scope: !289, file: !287, line: 16, baseType: !6, size: 32)
!292 = !DIDerivedType(tag: DW_TAG_member, name: "fp_offset", scope: !289, file: !287, line: 16, baseType: !6, size: 32, offset: 32)
!293 = !DIDerivedType(tag: DW_TAG_member, name: "overflow_arg_area", scope: !289, file: !287, line: 16, baseType: !261, size: 64, offset: 64)
!294 = !DIDerivedType(tag: DW_TAG_member, name: "reg_save_area", scope: !289, file: !287, line: 16, baseType: !261, size: 64, offset: 128)
!295 = !DILocation(line: 16, column: 13, scope: !209)
!296 = !DILocation(line: 17, column: 5, scope: !209)
!297 = !DILocation(line: 18, column: 27, scope: !209)
!298 = !DILocation(line: 18, column: 59, scope: !209)
!299 = !DILocation(line: 18, column: 17, scope: !209)
!300 = !DILocalVariable(name: "count", scope: !209, file: !32, line: 18, type: !12)
!301 = !DILocation(line: 19, column: 5, scope: !209)
!302 = !DILocation(line: 20, column: 15, scope: !303)
!303 = distinct !DILexicalBlock(scope: !209, file: !32, line: 20, column: 9)
!304 = !DILocation(line: 20, column: 19, scope: !303)
!305 = !DILocation(line: 20, column: 22, scope: !303)
!306 = !DILocation(line: 20, column: 38, scope: !303)
!307 = !DILocation(line: 20, column: 9, scope: !209)
!308 = !DILocation(line: 20, column: 57, scope: !303)
!309 = !DILocalVariable(name: "i", scope: !310, file: !32, line: 21, type: !12)
!310 = distinct !DILexicalBlock(scope: !209, file: !32, line: 21, column: 5)
!311 = !DILocation(line: 0, scope: !310)
!312 = !DILocation(line: 21, column: 10, scope: !310)
!313 = !DILocation(line: 21, column: 23, scope: !314)
!314 = distinct !DILexicalBlock(scope: !310, file: !32, line: 21, column: 5)
!315 = !DILocation(line: 21, column: 5, scope: !310)
!316 = !DILocation(line: 22, column: 35, scope: !317)
!317 = distinct !DILexicalBlock(scope: !314, file: !32, line: 21, column: 37)
!318 = !DILocation(line: 22, column: 20, scope: !317)
!319 = !DILocation(line: 22, column: 17, scope: !317)
!320 = !DILocation(line: 23, column: 17, scope: !317)
!321 = !DILocation(line: 24, column: 5, scope: !317)
!322 = !DILocation(line: 21, column: 32, scope: !314)
!323 = !DILocation(line: 21, column: 5, scope: !314)
!324 = distinct !{!324, !315, !325, !98}
!325 = !DILocation(line: 24, column: 5, scope: !310)
!326 = !DILocation(line: 29, column: 11, scope: !209)
!327 = !DILocation(line: 31, column: 5, scope: !209)
