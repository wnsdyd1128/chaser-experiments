; ModuleID = '/workspace/experiments-array-support/chaser/.cache/periodic-polybench/affine-bounds-20260929/suite/atax/source/workload.c'
source_filename = "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/affine-bounds-20260929/suite/atax/source/workload.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

%struct._IO_FILE = type { i32, i8*, i8*, i8*, i8*, i8*, i8*, i8*, i8*, i8*, i8*, i8*, %struct._IO_marker*, %struct._IO_FILE*, i32, i32, i64, i16, i8, [1 x i8], i8*, i64, %struct._IO_codecvt*, %struct._IO_wide_data*, %struct._IO_FILE*, i8*, i64, i32, [20 x i8] }
%struct._IO_marker = type opaque
%struct._IO_codecvt = type opaque
%struct._IO_wide_data = type opaque
%struct.__va_list_tag = type { i32, i32, i8*, i8* }

@m = dso_local global i32 390, align 4, !dbg !0
@n = dso_local global i32 410, align 4, !dbg !9
@A = dso_local global [390 x [410 x double]] zeroinitializer, section ".chaser_data.A", align 64, !dbg !33
@x = dso_local global [410 x double] zeroinitializer, section ".chaser_data.x", align 64, !dbg !39
@y = dso_local global [410 x double] zeroinitializer, section ".chaser_data.y", align 64, !dbg !43
@tmp = dso_local global [390 x double] zeroinitializer, section ".chaser_data.tmp", align 64, !dbg !45
@.str = private unnamed_addr constant [12 x i8] c"ape.analyze\00", section "llvm.metadata"
@.str.1 = private unnamed_addr constant [122 x i8] c"/workspace/experiments-array-support/chaser/.cache/periodic-polybench/affine-bounds-20260929/suite/atax/source/workload.c\00", section "llvm.metadata"
@pb_hash = internal global i32 0, align 4, !dbg !30
@workload_jobs = dso_local constant [1 x i32 ()*] [i32 ()* @task_job_polybench], align 8, !dbg !13
@workload_expected = dso_local constant [1 x i32] [i32 1921650095], align 4, !dbg !26
@stderr = external global %struct._IO_FILE*, align 8
@.str.2 = private unnamed_addr constant [23 x i8] c"==BEGIN DUMP_ARRAYS==\0A\00", align 1
@.str.3 = private unnamed_addr constant [15 x i8] c"begin dump: %s\00", align 1
@.str.4 = private unnamed_addr constant [2 x i8] c"y\00", align 1
@.str.5 = private unnamed_addr constant [2 x i8] c"\0A\00", align 1
@.str.6 = private unnamed_addr constant [8 x i8] c"%0.2lf \00", align 1
@.str.7 = private unnamed_addr constant [17 x i8] c"\0Aend   dump: %s\0A\00", align 1
@.str.8 = private unnamed_addr constant [23 x i8] c"==END   DUMP_ARRAYS==\0A\00", align 1
@pb_emit = internal global i32 1, align 4, !dbg !49
@llvm.global.annotations = appending global [1 x { i8*, i8*, i8*, i32, i8* }] [{ i8*, i8*, i8*, i32, i8* } { i8* bitcast (i32 ()* @task_job_polybench to i8*), i8* getelementptr inbounds ([12 x i8], [12 x i8]* @.str, i32 0, i32 0), i8* getelementptr inbounds ([122 x i8], [122 x i8]* @.str.1, i32 0, i32 0), i32 114, i8* null }], section "llvm.metadata"

; Function Attrs: noinline nounwind uwtable
define dso_local void @workload_prepare() #0 !dbg !59 {
  ret void, !dbg !63
}

; Function Attrs: noinline nounwind uwtable
define dso_local void @workload_reset(i32 noundef %0) #0 !dbg !64 {
  %2 = alloca i32, align 4
  store i32 %0, i32* %2, align 4
  call void @llvm.dbg.declare(metadata i32* %2, metadata !67, metadata !DIExpression()), !dbg !68
  %3 = load i32, i32* %2, align 4, !dbg !69
  call void @llvm.memset.p0i8.i64(i8* align 64 bitcast ([390 x [410 x double]]* @A to i8*), i8 0, i64 1279200, i1 false), !dbg !70
  call void @llvm.memset.p0i8.i64(i8* align 64 bitcast ([410 x double]* @x to i8*), i8 0, i64 3280, i1 false), !dbg !71
  call void @llvm.memset.p0i8.i64(i8* align 64 bitcast ([410 x double]* @y to i8*), i8 0, i64 3280, i1 false), !dbg !72
  call void @llvm.memset.p0i8.i64(i8* align 64 bitcast ([390 x double]* @tmp to i8*), i8 0, i64 3120, i1 false), !dbg !73
  %4 = load i32, i32* @m, align 4, !dbg !74
  %5 = load i32, i32* @n, align 4, !dbg !75
  call void @init_array(i32 noundef %4, i32 noundef %5, [410 x double]* noundef getelementptr inbounds ([390 x [410 x double]], [390 x [410 x double]]* @A, i64 0, i64 0), double* noundef getelementptr inbounds ([410 x double], [410 x double]* @x, i64 0, i64 0)), !dbg !76
  ret void, !dbg !77
}

; Function Attrs: nofree nosync nounwind readnone speculatable willreturn
declare void @llvm.dbg.declare(metadata, metadata, metadata) #1

; Function Attrs: argmemonly nofree nounwind willreturn writeonly
declare void @llvm.memset.p0i8.i64(i8* nocapture writeonly, i8, i64, i1 immarg) #2

; Function Attrs: noinline nounwind uwtable
define internal void @init_array(i32 noundef %0, i32 noundef %1, [410 x double]* noundef %2, double* noundef %3) #0 !dbg !78 {
  %5 = alloca i32, align 4
  %6 = alloca i32, align 4
  %7 = alloca [410 x double]*, align 8
  %8 = alloca double*, align 8
  %9 = alloca i32, align 4
  %10 = alloca i32, align 4
  %11 = alloca double, align 8
  store i32 %0, i32* %5, align 4
  call void @llvm.dbg.declare(metadata i32* %5, metadata !83, metadata !DIExpression()), !dbg !84
  store i32 %1, i32* %6, align 4
  call void @llvm.dbg.declare(metadata i32* %6, metadata !85, metadata !DIExpression()), !dbg !86
  store [410 x double]* %2, [410 x double]** %7, align 8
  call void @llvm.dbg.declare(metadata [410 x double]** %7, metadata !87, metadata !DIExpression()), !dbg !88
  store double* %3, double** %8, align 8
  call void @llvm.dbg.declare(metadata double** %8, metadata !89, metadata !DIExpression()), !dbg !90
  call void @llvm.dbg.declare(metadata i32* %9, metadata !91, metadata !DIExpression()), !dbg !92
  call void @llvm.dbg.declare(metadata i32* %10, metadata !93, metadata !DIExpression()), !dbg !94
  call void @llvm.dbg.declare(metadata double* %11, metadata !95, metadata !DIExpression()), !dbg !96
  %12 = load i32, i32* %6, align 4, !dbg !97
  %13 = sitofp i32 %12 to double, !dbg !98
  store double %13, double* %11, align 8, !dbg !99
  store i32 0, i32* %9, align 4, !dbg !100
  br label %14, !dbg !102

14:                                               ; preds = %28, %4
  %15 = load i32, i32* %9, align 4, !dbg !103
  %16 = load i32, i32* %6, align 4, !dbg !105
  %17 = icmp slt i32 %15, %16, !dbg !106
  br i1 %17, label %18, label %31, !dbg !107

18:                                               ; preds = %14
  %19 = load i32, i32* %9, align 4, !dbg !108
  %20 = sitofp i32 %19 to double, !dbg !108
  %21 = load double, double* %11, align 8, !dbg !109
  %22 = fdiv double %20, %21, !dbg !110
  %23 = fadd double 1.000000e+00, %22, !dbg !111
  %24 = load double*, double** %8, align 8, !dbg !112
  %25 = load i32, i32* %9, align 4, !dbg !113
  %26 = sext i32 %25 to i64, !dbg !112
  %27 = getelementptr inbounds double, double* %24, i64 %26, !dbg !112
  store double %23, double* %27, align 8, !dbg !114
  br label %28, !dbg !112

28:                                               ; preds = %18
  %29 = load i32, i32* %9, align 4, !dbg !115
  %30 = add nsw i32 %29, 1, !dbg !115
  store i32 %30, i32* %9, align 4, !dbg !115
  br label %14, !dbg !116, !llvm.loop !117

31:                                               ; preds = %14
  store i32 0, i32* %9, align 4, !dbg !120
  br label %32, !dbg !122

32:                                               ; preds = %63, %31
  %33 = load i32, i32* %9, align 4, !dbg !123
  %34 = load i32, i32* %5, align 4, !dbg !125
  %35 = icmp slt i32 %33, %34, !dbg !126
  br i1 %35, label %36, label %66, !dbg !127

36:                                               ; preds = %32
  store i32 0, i32* %10, align 4, !dbg !128
  br label %37, !dbg !130

37:                                               ; preds = %59, %36
  %38 = load i32, i32* %10, align 4, !dbg !131
  %39 = load i32, i32* %6, align 4, !dbg !133
  %40 = icmp slt i32 %38, %39, !dbg !134
  br i1 %40, label %41, label %62, !dbg !135

41:                                               ; preds = %37
  %42 = load i32, i32* %9, align 4, !dbg !136
  %43 = load i32, i32* %10, align 4, !dbg !137
  %44 = add nsw i32 %42, %43, !dbg !138
  %45 = load i32, i32* %6, align 4, !dbg !139
  %46 = srem i32 %44, %45, !dbg !140
  %47 = sitofp i32 %46 to double, !dbg !141
  %48 = load i32, i32* %5, align 4, !dbg !142
  %49 = mul nsw i32 5, %48, !dbg !143
  %50 = sitofp i32 %49 to double, !dbg !144
  %51 = fdiv double %47, %50, !dbg !145
  %52 = load [410 x double]*, [410 x double]** %7, align 8, !dbg !146
  %53 = load i32, i32* %9, align 4, !dbg !147
  %54 = sext i32 %53 to i64, !dbg !146
  %55 = getelementptr inbounds [410 x double], [410 x double]* %52, i64 %54, !dbg !146
  %56 = load i32, i32* %10, align 4, !dbg !148
  %57 = sext i32 %56 to i64, !dbg !146
  %58 = getelementptr inbounds [410 x double], [410 x double]* %55, i64 0, i64 %57, !dbg !146
  store double %51, double* %58, align 8, !dbg !149
  br label %59, !dbg !146

59:                                               ; preds = %41
  %60 = load i32, i32* %10, align 4, !dbg !150
  %61 = add nsw i32 %60, 1, !dbg !150
  store i32 %61, i32* %10, align 4, !dbg !150
  br label %37, !dbg !151, !llvm.loop !152

62:                                               ; preds = %37
  br label %63, !dbg !153

63:                                               ; preds = %62
  %64 = load i32, i32* %9, align 4, !dbg !154
  %65 = add nsw i32 %64, 1, !dbg !154
  store i32 %65, i32* %9, align 4, !dbg !154
  br label %32, !dbg !155, !llvm.loop !156

66:                                               ; preds = %32
  ret void, !dbg !158
}

; Function Attrs: noinline nounwind uwtable
define dso_local i32 @task_job_polybench() #0 !dbg !159 {
  %1 = alloca i32, align 4
  %2 = alloca i32, align 4
  %3 = alloca [410 x double]*, align 8
  %4 = alloca double*, align 8
  %5 = alloca double*, align 8
  %6 = alloca double*, align 8
  %7 = alloca i32, align 4
  %8 = alloca i32, align 4
  %9 = load i32, i32* @m, align 4, !dbg !160
  %10 = load i32, i32* @n, align 4, !dbg !161
  store i32 %9, i32* %1, align 4
  call void @llvm.dbg.declare(metadata i32* %1, metadata !162, metadata !DIExpression()), !dbg !166
  store i32 %10, i32* %2, align 4
  call void @llvm.dbg.declare(metadata i32* %2, metadata !168, metadata !DIExpression()), !dbg !169
  store [410 x double]* getelementptr inbounds ([390 x [410 x double]], [390 x [410 x double]]* @A, i64 0, i64 0), [410 x double]** %3, align 8
  call void @llvm.dbg.declare(metadata [410 x double]** %3, metadata !170, metadata !DIExpression()), !dbg !171
  store double* getelementptr inbounds ([410 x double], [410 x double]* @x, i64 0, i64 0), double** %4, align 8
  call void @llvm.dbg.declare(metadata double** %4, metadata !172, metadata !DIExpression()), !dbg !173
  store double* getelementptr inbounds ([410 x double], [410 x double]* @y, i64 0, i64 0), double** %5, align 8
  call void @llvm.dbg.declare(metadata double** %5, metadata !174, metadata !DIExpression()), !dbg !175
  store double* getelementptr inbounds ([390 x double], [390 x double]* @tmp, i64 0, i64 0), double** %6, align 8
  call void @llvm.dbg.declare(metadata double** %6, metadata !176, metadata !DIExpression()), !dbg !177
  call void @llvm.dbg.declare(metadata i32* %7, metadata !178, metadata !DIExpression()), !dbg !179
  call void @llvm.dbg.declare(metadata i32* %8, metadata !180, metadata !DIExpression()), !dbg !181
  store i32 0, i32* %7, align 4, !dbg !182
  br label %11, !dbg !184

11:                                               ; preds = %14, %0
  %12 = load i32, i32* %7, align 4, !dbg !185
  %13 = icmp slt i32 %12, 410, !dbg !187
  br i1 %13, label %14, label %21, !dbg !188

14:                                               ; preds = %11
  %15 = load double*, double** %5, align 8, !dbg !189
  %16 = load i32, i32* %7, align 4, !dbg !190
  %17 = sext i32 %16 to i64, !dbg !189
  %18 = getelementptr inbounds double, double* %15, i64 %17, !dbg !189
  store double 0.000000e+00, double* %18, align 8, !dbg !191
  %19 = load i32, i32* %7, align 4, !dbg !192
  %20 = add nsw i32 %19, 1, !dbg !192
  store i32 %20, i32* %7, align 4, !dbg !192
  br label %11, !dbg !193, !llvm.loop !194

21:                                               ; preds = %11
  store i32 0, i32* %7, align 4, !dbg !196
  br label %22, !dbg !198

22:                                               ; preds = %91, %21
  %23 = load i32, i32* %7, align 4, !dbg !199
  %24 = icmp slt i32 %23, 390, !dbg !201
  br i1 %24, label %25, label %94, !dbg !202

25:                                               ; preds = %22
  %26 = load double*, double** %6, align 8, !dbg !203
  %27 = load i32, i32* %7, align 4, !dbg !205
  %28 = sext i32 %27 to i64, !dbg !203
  %29 = getelementptr inbounds double, double* %26, i64 %28, !dbg !203
  store double 0.000000e+00, double* %29, align 8, !dbg !206
  store i32 0, i32* %8, align 4, !dbg !207
  br label %30, !dbg !209

30:                                               ; preds = %33, %25
  %31 = load i32, i32* %8, align 4, !dbg !210
  %32 = icmp slt i32 %31, 410, !dbg !212
  br i1 %32, label %33, label %60, !dbg !213

33:                                               ; preds = %30
  %34 = load double*, double** %6, align 8, !dbg !214
  %35 = load i32, i32* %7, align 4, !dbg !215
  %36 = sext i32 %35 to i64, !dbg !214
  %37 = getelementptr inbounds double, double* %34, i64 %36, !dbg !214
  %38 = load double, double* %37, align 8, !dbg !214
  %39 = load [410 x double]*, [410 x double]** %3, align 8, !dbg !216
  %40 = load i32, i32* %7, align 4, !dbg !217
  %41 = sext i32 %40 to i64, !dbg !216
  %42 = getelementptr inbounds [410 x double], [410 x double]* %39, i64 %41, !dbg !216
  %43 = load i32, i32* %8, align 4, !dbg !218
  %44 = sext i32 %43 to i64, !dbg !216
  %45 = getelementptr inbounds [410 x double], [410 x double]* %42, i64 0, i64 %44, !dbg !216
  %46 = load double, double* %45, align 8, !dbg !216
  %47 = load double*, double** %4, align 8, !dbg !219
  %48 = load i32, i32* %8, align 4, !dbg !220
  %49 = sext i32 %48 to i64, !dbg !219
  %50 = getelementptr inbounds double, double* %47, i64 %49, !dbg !219
  %51 = load double, double* %50, align 8, !dbg !219
  %52 = fmul double %46, %51, !dbg !221
  %53 = fadd double %38, %52, !dbg !222
  %54 = load double*, double** %6, align 8, !dbg !223
  %55 = load i32, i32* %7, align 4, !dbg !224
  %56 = sext i32 %55 to i64, !dbg !223
  %57 = getelementptr inbounds double, double* %54, i64 %56, !dbg !223
  store double %53, double* %57, align 8, !dbg !225
  %58 = load i32, i32* %8, align 4, !dbg !226
  %59 = add nsw i32 %58, 1, !dbg !226
  store i32 %59, i32* %8, align 4, !dbg !226
  br label %30, !dbg !227, !llvm.loop !228

60:                                               ; preds = %30
  store i32 0, i32* %8, align 4, !dbg !230
  br label %61, !dbg !232

61:                                               ; preds = %64, %60
  %62 = load i32, i32* %8, align 4, !dbg !233
  %63 = icmp slt i32 %62, 410, !dbg !235
  br i1 %63, label %64, label %91, !dbg !236

64:                                               ; preds = %61
  %65 = load double*, double** %5, align 8, !dbg !237
  %66 = load i32, i32* %8, align 4, !dbg !238
  %67 = sext i32 %66 to i64, !dbg !237
  %68 = getelementptr inbounds double, double* %65, i64 %67, !dbg !237
  %69 = load double, double* %68, align 8, !dbg !237
  %70 = load [410 x double]*, [410 x double]** %3, align 8, !dbg !239
  %71 = load i32, i32* %7, align 4, !dbg !240
  %72 = sext i32 %71 to i64, !dbg !239
  %73 = getelementptr inbounds [410 x double], [410 x double]* %70, i64 %72, !dbg !239
  %74 = load i32, i32* %8, align 4, !dbg !241
  %75 = sext i32 %74 to i64, !dbg !239
  %76 = getelementptr inbounds [410 x double], [410 x double]* %73, i64 0, i64 %75, !dbg !239
  %77 = load double, double* %76, align 8, !dbg !239
  %78 = load double*, double** %6, align 8, !dbg !242
  %79 = load i32, i32* %7, align 4, !dbg !243
  %80 = sext i32 %79 to i64, !dbg !242
  %81 = getelementptr inbounds double, double* %78, i64 %80, !dbg !242
  %82 = load double, double* %81, align 8, !dbg !242
  %83 = fmul double %77, %82, !dbg !244
  %84 = fadd double %69, %83, !dbg !245
  %85 = load double*, double** %5, align 8, !dbg !246
  %86 = load i32, i32* %8, align 4, !dbg !247
  %87 = sext i32 %86 to i64, !dbg !246
  %88 = getelementptr inbounds double, double* %85, i64 %87, !dbg !246
  store double %84, double* %88, align 8, !dbg !248
  %89 = load i32, i32* %8, align 4, !dbg !249
  %90 = add nsw i32 %89, 1, !dbg !249
  store i32 %90, i32* %8, align 4, !dbg !249
  br label %61, !dbg !250, !llvm.loop !251

91:                                               ; preds = %61
  %92 = load i32, i32* %7, align 4, !dbg !253
  %93 = add nsw i32 %92, 1, !dbg !253
  store i32 %93, i32* %7, align 4, !dbg !253
  br label %22, !dbg !254, !llvm.loop !255

94:                                               ; preds = %22
  ret i32 0, !dbg !257
}

; Function Attrs: noinline nounwind uwtable
define dso_local i32 @workload_checksum(i32 noundef %0) #0 !dbg !258 {
  %2 = alloca i32, align 4
  store i32 %0, i32* %2, align 4
  call void @llvm.dbg.declare(metadata i32* %2, metadata !261, metadata !DIExpression()), !dbg !262
  %3 = load i32, i32* %2, align 4, !dbg !263
  store i32 -2128831035, i32* @pb_hash, align 4, !dbg !264
  %4 = load i32, i32* @n, align 4, !dbg !265
  call void @print_array(i32 noundef %4, double* noundef getelementptr inbounds ([410 x double], [410 x double]* @y, i64 0, i64 0)), !dbg !266
  %5 = load i32, i32* @pb_hash, align 4, !dbg !267
  ret i32 %5, !dbg !268
}

; Function Attrs: noinline nounwind uwtable
define internal void @print_array(i32 noundef %0, double* noundef %1) #0 !dbg !269 {
  %3 = alloca i32, align 4
  %4 = alloca double*, align 8
  %5 = alloca i32, align 4
  store i32 %0, i32* %3, align 4
  call void @llvm.dbg.declare(metadata i32* %3, metadata !272, metadata !DIExpression()), !dbg !273
  store double* %1, double** %4, align 8
  call void @llvm.dbg.declare(metadata double** %4, metadata !274, metadata !DIExpression()), !dbg !275
  call void @llvm.dbg.declare(metadata i32* %5, metadata !276, metadata !DIExpression()), !dbg !277
  %6 = load %struct._IO_FILE*, %struct._IO_FILE** @stderr, align 8, !dbg !278
  %7 = call i32 (%struct._IO_FILE*, i8*, ...) @pb_fprintf(%struct._IO_FILE* noundef %6, i8* noundef getelementptr inbounds ([23 x i8], [23 x i8]* @.str.2, i64 0, i64 0)), !dbg !278
  %8 = load %struct._IO_FILE*, %struct._IO_FILE** @stderr, align 8, !dbg !279
  %9 = call i32 (%struct._IO_FILE*, i8*, ...) @pb_fprintf(%struct._IO_FILE* noundef %8, i8* noundef getelementptr inbounds ([15 x i8], [15 x i8]* @.str.3, i64 0, i64 0), i8* noundef getelementptr inbounds ([2 x i8], [2 x i8]* @.str.4, i64 0, i64 0)), !dbg !279
  store i32 0, i32* %5, align 4, !dbg !280
  br label %10, !dbg !282

10:                                               ; preds = %29, %2
  %11 = load i32, i32* %5, align 4, !dbg !283
  %12 = load i32, i32* %3, align 4, !dbg !285
  %13 = icmp slt i32 %11, %12, !dbg !286
  br i1 %13, label %14, label %32, !dbg !287

14:                                               ; preds = %10
  %15 = load i32, i32* %5, align 4, !dbg !288
  %16 = srem i32 %15, 20, !dbg !291
  %17 = icmp eq i32 %16, 0, !dbg !292
  br i1 %17, label %18, label %21, !dbg !293

18:                                               ; preds = %14
  %19 = load %struct._IO_FILE*, %struct._IO_FILE** @stderr, align 8, !dbg !294
  %20 = call i32 (%struct._IO_FILE*, i8*, ...) @pb_fprintf(%struct._IO_FILE* noundef %19, i8* noundef getelementptr inbounds ([2 x i8], [2 x i8]* @.str.5, i64 0, i64 0)), !dbg !295
  br label %21, !dbg !295

21:                                               ; preds = %18, %14
  %22 = load %struct._IO_FILE*, %struct._IO_FILE** @stderr, align 8, !dbg !296
  %23 = load double*, double** %4, align 8, !dbg !297
  %24 = load i32, i32* %5, align 4, !dbg !298
  %25 = sext i32 %24 to i64, !dbg !297
  %26 = getelementptr inbounds double, double* %23, i64 %25, !dbg !297
  %27 = load double, double* %26, align 8, !dbg !297
  %28 = call i32 (%struct._IO_FILE*, i8*, ...) @pb_fprintf(%struct._IO_FILE* noundef %22, i8* noundef getelementptr inbounds ([8 x i8], [8 x i8]* @.str.6, i64 0, i64 0), double noundef %27), !dbg !299
  br label %29, !dbg !300

29:                                               ; preds = %21
  %30 = load i32, i32* %5, align 4, !dbg !301
  %31 = add nsw i32 %30, 1, !dbg !301
  store i32 %31, i32* %5, align 4, !dbg !301
  br label %10, !dbg !302, !llvm.loop !303

32:                                               ; preds = %10
  %33 = load %struct._IO_FILE*, %struct._IO_FILE** @stderr, align 8, !dbg !305
  %34 = call i32 (%struct._IO_FILE*, i8*, ...) @pb_fprintf(%struct._IO_FILE* noundef %33, i8* noundef getelementptr inbounds ([17 x i8], [17 x i8]* @.str.7, i64 0, i64 0), i8* noundef getelementptr inbounds ([2 x i8], [2 x i8]* @.str.4, i64 0, i64 0)), !dbg !305
  %35 = load %struct._IO_FILE*, %struct._IO_FILE** @stderr, align 8, !dbg !306
  %36 = call i32 (%struct._IO_FILE*, i8*, ...) @pb_fprintf(%struct._IO_FILE* noundef %35, i8* noundef getelementptr inbounds ([23 x i8], [23 x i8]* @.str.8, i64 0, i64 0)), !dbg !306
  ret void, !dbg !307
}

; Function Attrs: noinline nounwind uwtable
define internal i32 @pb_fprintf(%struct._IO_FILE* noundef %0, i8* noundef %1, ...) #0 !dbg !308 {
  %3 = alloca %struct._IO_FILE*, align 8
  %4 = alloca i8*, align 8
  %5 = alloca [768 x i8], align 16
  %6 = alloca [1 x %struct.__va_list_tag], align 16
  %7 = alloca i32, align 4
  %8 = alloca i32, align 4
  store %struct._IO_FILE* %0, %struct._IO_FILE** %3, align 8
  call void @llvm.dbg.declare(metadata %struct._IO_FILE** %3, metadata !372, metadata !DIExpression()), !dbg !373
  store i8* %1, i8** %4, align 8
  call void @llvm.dbg.declare(metadata i8** %4, metadata !374, metadata !DIExpression()), !dbg !375
  call void @llvm.dbg.declare(metadata [768 x i8]* %5, metadata !376, metadata !DIExpression()), !dbg !380
  call void @llvm.dbg.declare(metadata [1 x %struct.__va_list_tag]* %6, metadata !381, metadata !DIExpression()), !dbg !395
  %9 = getelementptr inbounds [1 x %struct.__va_list_tag], [1 x %struct.__va_list_tag]* %6, i64 0, i64 0, !dbg !396
  %10 = bitcast %struct.__va_list_tag* %9 to i8*, !dbg !396
  call void @llvm.va_start(i8* %10), !dbg !396
  call void @llvm.dbg.declare(metadata i32* %7, metadata !397, metadata !DIExpression()), !dbg !398
  %11 = getelementptr inbounds [768 x i8], [768 x i8]* %5, i64 0, i64 0, !dbg !399
  %12 = load i8*, i8** %4, align 8, !dbg !400
  %13 = getelementptr inbounds [1 x %struct.__va_list_tag], [1 x %struct.__va_list_tag]* %6, i64 0, i64 0, !dbg !401
  %14 = call i32 @vsnprintf(i8* noundef %11, i64 noundef 768, i8* noundef %12, %struct.__va_list_tag* noundef %13) #6, !dbg !402
  store i32 %14, i32* %7, align 4, !dbg !398
  %15 = getelementptr inbounds [1 x %struct.__va_list_tag], [1 x %struct.__va_list_tag]* %6, i64 0, i64 0, !dbg !403
  %16 = bitcast %struct.__va_list_tag* %15 to i8*, !dbg !403
  call void @llvm.va_end(i8* %16), !dbg !403
  %17 = load i32, i32* %7, align 4, !dbg !404
  %18 = icmp slt i32 %17, 0, !dbg !406
  br i1 %18, label %23, label %19, !dbg !407

19:                                               ; preds = %2
  %20 = load i32, i32* %7, align 4, !dbg !408
  %21 = zext i32 %20 to i64, !dbg !409
  %22 = icmp uge i64 %21, 768, !dbg !410
  br i1 %22, label %23, label %24, !dbg !411

23:                                               ; preds = %19, %2
  call void @abort() #7, !dbg !412
  unreachable, !dbg !412

24:                                               ; preds = %19
  call void @llvm.dbg.declare(metadata i32* %8, metadata !413, metadata !DIExpression()), !dbg !415
  store i32 0, i32* %8, align 4, !dbg !415
  br label %25, !dbg !416

25:                                               ; preds = %39, %24
  %26 = load i32, i32* %8, align 4, !dbg !417
  %27 = load i32, i32* %7, align 4, !dbg !419
  %28 = icmp slt i32 %26, %27, !dbg !420
  br i1 %28, label %29, label %42, !dbg !421

29:                                               ; preds = %25
  %30 = load i32, i32* %8, align 4, !dbg !422
  %31 = sext i32 %30 to i64, !dbg !424
  %32 = getelementptr inbounds [768 x i8], [768 x i8]* %5, i64 0, i64 %31, !dbg !424
  %33 = load i8, i8* %32, align 1, !dbg !424
  %34 = zext i8 %33 to i32, !dbg !425
  %35 = load i32, i32* @pb_hash, align 4, !dbg !426
  %36 = xor i32 %35, %34, !dbg !426
  store i32 %36, i32* @pb_hash, align 4, !dbg !426
  %37 = load i32, i32* @pb_hash, align 4, !dbg !427
  %38 = mul i32 %37, 16777619, !dbg !427
  store i32 %38, i32* @pb_hash, align 4, !dbg !427
  br label %39, !dbg !428

39:                                               ; preds = %29
  %40 = load i32, i32* %8, align 4, !dbg !429
  %41 = add nsw i32 %40, 1, !dbg !429
  store i32 %41, i32* %8, align 4, !dbg !429
  br label %25, !dbg !430, !llvm.loop !431

42:                                               ; preds = %25
  %43 = load %struct._IO_FILE*, %struct._IO_FILE** %3, align 8, !dbg !433
  %44 = load i32, i32* @pb_emit, align 4, !dbg !434
  %45 = load i32, i32* %7, align 4, !dbg !435
  ret i32 %45, !dbg !436
}

; Function Attrs: nofree nosync nounwind willreturn
declare void @llvm.va_start(i8*) #3

; Function Attrs: nounwind
declare i32 @vsnprintf(i8* noundef, i64 noundef, i8* noundef, %struct.__va_list_tag* noundef) #4

; Function Attrs: nofree nosync nounwind willreturn
declare void @llvm.va_end(i8*) #3

; Function Attrs: noreturn nounwind
declare void @abort() #5

attributes #0 = { noinline nounwind uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { nofree nosync nounwind readnone speculatable willreturn }
attributes #2 = { argmemonly nofree nounwind willreturn writeonly }
attributes #3 = { nofree nosync nounwind willreturn }
attributes #4 = { nounwind "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #5 = { noreturn nounwind "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #6 = { nounwind }
attributes #7 = { noreturn nounwind }

!llvm.dbg.cu = !{!2}
!llvm.module.flags = !{!51, !52, !53, !54, !55, !56, !57}
!llvm.ident = !{!58}

!0 = !DIGlobalVariableExpression(var: !1, expr: !DIExpression())
!1 = distinct !DIGlobalVariable(name: "m", scope: !2, file: !11, line: 103, type: !12, isLocal: false, isDefinition: true)
!2 = distinct !DICompileUnit(language: DW_LANG_C99, file: !3, producer: "Ubuntu clang version 14.0.0-1ubuntu1.1", isOptimized: false, runtimeVersion: 0, emissionKind: FullDebug, retainedTypes: !4, globals: !8, splitDebugInlining: false, nameTableKind: None)
!3 = !DIFile(filename: "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/affine-bounds-20260929/suite/atax/source/workload.c", directory: "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/affine-bounds-20260929/suite/atax/analysis-p", checksumkind: CSK_MD5, checksum: "1866978266073eb505d85c7a4917d95d")
!4 = !{!5, !6, !7}
!5 = !DIBasicType(name: "double", size: 64, encoding: DW_ATE_float)
!6 = !DIBasicType(name: "unsigned int", size: 32, encoding: DW_ATE_unsigned)
!7 = !DIBasicType(name: "unsigned char", size: 8, encoding: DW_ATE_unsigned_char)
!8 = !{!0, !9, !13, !26, !30, !33, !39, !43, !45, !49}
!9 = !DIGlobalVariableExpression(var: !10, expr: !DIExpression())
!10 = distinct !DIGlobalVariable(name: "n", scope: !2, file: !11, line: 104, type: !12, isLocal: false, isDefinition: true)
!11 = !DIFile(filename: "source/workload.c", directory: "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/affine-bounds-20260929/suite/atax", checksumkind: CSK_MD5, checksum: "1866978266073eb505d85c7a4917d95d")
!12 = !DIBasicType(name: "int", size: 32, encoding: DW_ATE_signed)
!13 = !DIGlobalVariableExpression(var: !14, expr: !DIExpression())
!14 = distinct !DIGlobalVariable(name: "workload_jobs", scope: !2, file: !11, line: 128, type: !15, isLocal: false, isDefinition: true)
!15 = !DICompositeType(tag: DW_TAG_array_type, baseType: !16, size: 64, elements: !24)
!16 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !17)
!17 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !18, size: 64)
!18 = !DISubroutineType(types: !19)
!19 = !{!20}
!20 = !DIDerivedType(tag: DW_TAG_typedef, name: "uint32_t", file: !21, line: 26, baseType: !22)
!21 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/stdint-uintn.h", directory: "", checksumkind: CSK_MD5, checksum: "2bf2ae53c58c01b1a1b9383b5195125c")
!22 = !DIDerivedType(tag: DW_TAG_typedef, name: "__uint32_t", file: !23, line: 42, baseType: !6)
!23 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/types.h", directory: "", checksumkind: CSK_MD5, checksum: "d108b5f93a74c50510d7d9bc0ab36df9")
!24 = !{!25}
!25 = !DISubrange(count: 1)
!26 = !DIGlobalVariableExpression(var: !27, expr: !DIExpression())
!27 = distinct !DIGlobalVariable(name: "workload_expected", scope: !2, file: !11, line: 132, type: !28, isLocal: false, isDefinition: true)
!28 = !DICompositeType(tag: DW_TAG_array_type, baseType: !29, size: 32, elements: !24)
!29 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !20)
!30 = !DIGlobalVariableExpression(var: !31, expr: !DIExpression())
!31 = distinct !DIGlobalVariable(name: "pb_hash", scope: !2, file: !32, line: 9, type: !20, isLocal: true, isDefinition: true)
!32 = !DIFile(filename: "source/adapter.h", directory: "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/affine-bounds-20260929/suite/atax", checksumkind: CSK_MD5, checksum: "26a6068928b2092758f244a9d00163d7")
!33 = !DIGlobalVariableExpression(var: !34, expr: !DIExpression())
!34 = distinct !DIGlobalVariable(name: "A", scope: !2, file: !11, line: 34, type: !35, isLocal: false, isDefinition: true, align: 512)
!35 = !DICompositeType(tag: DW_TAG_array_type, baseType: !5, size: 10233600, elements: !36)
!36 = !{!37, !38}
!37 = !DISubrange(count: 390)
!38 = !DISubrange(count: 410)
!39 = !DIGlobalVariableExpression(var: !40, expr: !DIExpression())
!40 = distinct !DIGlobalVariable(name: "x", scope: !2, file: !11, line: 35, type: !41, isLocal: false, isDefinition: true, align: 512)
!41 = !DICompositeType(tag: DW_TAG_array_type, baseType: !5, size: 26240, elements: !42)
!42 = !{!38}
!43 = !DIGlobalVariableExpression(var: !44, expr: !DIExpression())
!44 = distinct !DIGlobalVariable(name: "y", scope: !2, file: !11, line: 36, type: !41, isLocal: false, isDefinition: true, align: 512)
!45 = !DIGlobalVariableExpression(var: !46, expr: !DIExpression())
!46 = distinct !DIGlobalVariable(name: "tmp", scope: !2, file: !11, line: 37, type: !47, isLocal: false, isDefinition: true, align: 512)
!47 = !DICompositeType(tag: DW_TAG_array_type, baseType: !5, size: 24960, elements: !48)
!48 = !{!37}
!49 = !DIGlobalVariableExpression(var: !50, expr: !DIExpression())
!50 = distinct !DIGlobalVariable(name: "pb_emit", scope: !2, file: !32, line: 10, type: !12, isLocal: true, isDefinition: true)
!51 = !{i32 7, !"Dwarf Version", i32 5}
!52 = !{i32 2, !"Debug Info Version", i32 3}
!53 = !{i32 1, !"wchar_size", i32 4}
!54 = !{i32 7, !"PIC Level", i32 2}
!55 = !{i32 7, !"PIE Level", i32 2}
!56 = !{i32 7, !"uwtable", i32 1}
!57 = !{i32 7, !"frame-pointer", i32 2}
!58 = !{!"Ubuntu clang version 14.0.0-1ubuntu1.1"}
!59 = distinct !DISubprogram(name: "workload_prepare", scope: !11, file: !11, line: 105, type: !60, scopeLine: 105, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !2, retainedNodes: !62)
!60 = !DISubroutineType(types: !61)
!61 = !{null}
!62 = !{}
!63 = !DILocation(line: 105, column: 30, scope: !59)
!64 = distinct !DISubprogram(name: "workload_reset", scope: !11, file: !11, line: 106, type: !65, scopeLine: 106, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !2, retainedNodes: !62)
!65 = !DISubroutineType(types: !66)
!66 = !{null, !6}
!67 = !DILocalVariable(name: "task", arg: 1, scope: !64, file: !11, line: 106, type: !6)
!68 = !DILocation(line: 106, column: 30, scope: !64)
!69 = !DILocation(line: 107, column: 9, scope: !64)
!70 = !DILocation(line: 108, column: 3, scope: !64)
!71 = !DILocation(line: 109, column: 3, scope: !64)
!72 = !DILocation(line: 110, column: 3, scope: !64)
!73 = !DILocation(line: 111, column: 3, scope: !64)
!74 = !DILocation(line: 112, column: 15, scope: !64)
!75 = !DILocation(line: 112, column: 18, scope: !64)
!76 = !DILocation(line: 112, column: 3, scope: !64)
!77 = !DILocation(line: 113, column: 1, scope: !64)
!78 = distinct !DISubprogram(name: "init_array", scope: !11, file: !11, line: 39, type: !79, scopeLine: 42, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition, unit: !2, retainedNodes: !62)
!79 = !DISubroutineType(types: !80)
!80 = !{null, !12, !12, !81, !82}
!81 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !41, size: 64)
!82 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !5, size: 64)
!83 = !DILocalVariable(name: "m", arg: 1, scope: !78, file: !11, line: 39, type: !12)
!84 = !DILocation(line: 39, column: 22, scope: !78)
!85 = !DILocalVariable(name: "n", arg: 2, scope: !78, file: !11, line: 39, type: !12)
!86 = !DILocation(line: 39, column: 29, scope: !78)
!87 = !DILocalVariable(name: "A", arg: 3, scope: !78, file: !11, line: 40, type: !81)
!88 = !DILocation(line: 40, column: 14, scope: !78)
!89 = !DILocalVariable(name: "x", arg: 4, scope: !78, file: !11, line: 41, type: !82)
!90 = !DILocation(line: 41, column: 14, scope: !78)
!91 = !DILocalVariable(name: "i", scope: !78, file: !11, line: 43, type: !12)
!92 = !DILocation(line: 43, column: 7, scope: !78)
!93 = !DILocalVariable(name: "j", scope: !78, file: !11, line: 43, type: !12)
!94 = !DILocation(line: 43, column: 10, scope: !78)
!95 = !DILocalVariable(name: "fn", scope: !78, file: !11, line: 44, type: !5)
!96 = !DILocation(line: 44, column: 13, scope: !78)
!97 = !DILocation(line: 45, column: 19, scope: !78)
!98 = !DILocation(line: 45, column: 8, scope: !78)
!99 = !DILocation(line: 45, column: 6, scope: !78)
!100 = !DILocation(line: 47, column: 10, scope: !101)
!101 = distinct !DILexicalBlock(scope: !78, file: !11, line: 47, column: 3)
!102 = !DILocation(line: 47, column: 8, scope: !101)
!103 = !DILocation(line: 47, column: 15, scope: !104)
!104 = distinct !DILexicalBlock(scope: !101, file: !11, line: 47, column: 3)
!105 = !DILocation(line: 47, column: 19, scope: !104)
!106 = !DILocation(line: 47, column: 17, scope: !104)
!107 = !DILocation(line: 47, column: 3, scope: !101)
!108 = !DILocation(line: 48, column: 19, scope: !104)
!109 = !DILocation(line: 48, column: 23, scope: !104)
!110 = !DILocation(line: 48, column: 21, scope: !104)
!111 = !DILocation(line: 48, column: 16, scope: !104)
!112 = !DILocation(line: 48, column: 7, scope: !104)
!113 = !DILocation(line: 48, column: 9, scope: !104)
!114 = !DILocation(line: 48, column: 12, scope: !104)
!115 = !DILocation(line: 47, column: 23, scope: !104)
!116 = !DILocation(line: 47, column: 3, scope: !104)
!117 = distinct !{!117, !107, !118, !119}
!118 = !DILocation(line: 48, column: 25, scope: !101)
!119 = !{!"llvm.loop.mustprogress"}
!120 = !DILocation(line: 49, column: 10, scope: !121)
!121 = distinct !DILexicalBlock(scope: !78, file: !11, line: 49, column: 3)
!122 = !DILocation(line: 49, column: 8, scope: !121)
!123 = !DILocation(line: 49, column: 15, scope: !124)
!124 = distinct !DILexicalBlock(scope: !121, file: !11, line: 49, column: 3)
!125 = !DILocation(line: 49, column: 19, scope: !124)
!126 = !DILocation(line: 49, column: 17, scope: !124)
!127 = !DILocation(line: 49, column: 3, scope: !121)
!128 = !DILocation(line: 50, column: 12, scope: !129)
!129 = distinct !DILexicalBlock(scope: !124, file: !11, line: 50, column: 5)
!130 = !DILocation(line: 50, column: 10, scope: !129)
!131 = !DILocation(line: 50, column: 17, scope: !132)
!132 = distinct !DILexicalBlock(scope: !129, file: !11, line: 50, column: 5)
!133 = !DILocation(line: 50, column: 21, scope: !132)
!134 = !DILocation(line: 50, column: 19, scope: !132)
!135 = !DILocation(line: 50, column: 5, scope: !129)
!136 = !DILocation(line: 51, column: 31, scope: !132)
!137 = !DILocation(line: 51, column: 33, scope: !132)
!138 = !DILocation(line: 51, column: 32, scope: !132)
!139 = !DILocation(line: 51, column: 38, scope: !132)
!140 = !DILocation(line: 51, column: 36, scope: !132)
!141 = !DILocation(line: 51, column: 17, scope: !132)
!142 = !DILocation(line: 51, column: 46, scope: !132)
!143 = !DILocation(line: 51, column: 45, scope: !132)
!144 = !DILocation(line: 51, column: 43, scope: !132)
!145 = !DILocation(line: 51, column: 41, scope: !132)
!146 = !DILocation(line: 51, column: 7, scope: !132)
!147 = !DILocation(line: 51, column: 9, scope: !132)
!148 = !DILocation(line: 51, column: 12, scope: !132)
!149 = !DILocation(line: 51, column: 15, scope: !132)
!150 = !DILocation(line: 50, column: 25, scope: !132)
!151 = !DILocation(line: 50, column: 5, scope: !132)
!152 = distinct !{!152, !135, !153, !119}
!153 = !DILocation(line: 51, column: 47, scope: !129)
!154 = !DILocation(line: 49, column: 23, scope: !124)
!155 = !DILocation(line: 49, column: 3, scope: !124)
!156 = distinct !{!156, !127, !157, !119}
!157 = !DILocation(line: 51, column: 47, scope: !121)
!158 = !DILocation(line: 52, column: 1, scope: !78)
!159 = distinct !DISubprogram(name: "task_job_polybench", scope: !11, file: !11, line: 114, type: !18, scopeLine: 114, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !2, retainedNodes: !62)
!160 = !DILocation(line: 115, column: 16, scope: !159)
!161 = !DILocation(line: 115, column: 19, scope: !159)
!162 = !DILocalVariable(name: "m", arg: 1, scope: !163, file: !11, line: 78, type: !12)
!163 = distinct !DISubprogram(name: "kernel_atax", scope: !11, file: !11, line: 78, type: !164, scopeLine: 83, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition, unit: !2, retainedNodes: !62)
!164 = !DISubroutineType(types: !165)
!165 = !{null, !12, !12, !81, !82, !82, !82}
!166 = !DILocation(line: 78, column: 60, scope: !163, inlinedAt: !167)
!167 = distinct !DILocation(line: 115, column: 3, scope: !159)
!168 = !DILocalVariable(name: "n", arg: 2, scope: !163, file: !11, line: 78, type: !12)
!169 = !DILocation(line: 78, column: 67, scope: !163, inlinedAt: !167)
!170 = !DILocalVariable(name: "A", arg: 3, scope: !163, file: !11, line: 79, type: !81)
!171 = !DILocation(line: 79, column: 14, scope: !163, inlinedAt: !167)
!172 = !DILocalVariable(name: "x", arg: 4, scope: !163, file: !11, line: 80, type: !82)
!173 = !DILocation(line: 80, column: 14, scope: !163, inlinedAt: !167)
!174 = !DILocalVariable(name: "y", arg: 5, scope: !163, file: !11, line: 81, type: !82)
!175 = !DILocation(line: 81, column: 14, scope: !163, inlinedAt: !167)
!176 = !DILocalVariable(name: "tmp", arg: 6, scope: !163, file: !11, line: 82, type: !82)
!177 = !DILocation(line: 82, column: 14, scope: !163, inlinedAt: !167)
!178 = !DILocalVariable(name: "i", scope: !163, file: !11, line: 84, type: !12)
!179 = !DILocation(line: 84, column: 7, scope: !163, inlinedAt: !167)
!180 = !DILocalVariable(name: "j", scope: !163, file: !11, line: 84, type: !12)
!181 = !DILocation(line: 84, column: 10, scope: !163, inlinedAt: !167)
!182 = !DILocation(line: 87, column: 10, scope: !183, inlinedAt: !167)
!183 = distinct !DILexicalBlock(scope: !163, file: !11, line: 87, column: 3)
!184 = !DILocation(line: 87, column: 8, scope: !183, inlinedAt: !167)
!185 = !DILocation(line: 87, column: 15, scope: !186, inlinedAt: !167)
!186 = distinct !DILexicalBlock(scope: !183, file: !11, line: 87, column: 3)
!187 = !DILocation(line: 87, column: 17, scope: !186, inlinedAt: !167)
!188 = !DILocation(line: 87, column: 3, scope: !183, inlinedAt: !167)
!189 = !DILocation(line: 88, column: 5, scope: !186, inlinedAt: !167)
!190 = !DILocation(line: 88, column: 7, scope: !186, inlinedAt: !167)
!191 = !DILocation(line: 88, column: 10, scope: !186, inlinedAt: !167)
!192 = !DILocation(line: 87, column: 27, scope: !186, inlinedAt: !167)
!193 = !DILocation(line: 87, column: 3, scope: !186, inlinedAt: !167)
!194 = distinct !{!194, !188, !195, !119}
!195 = !DILocation(line: 88, column: 12, scope: !183, inlinedAt: !167)
!196 = !DILocation(line: 89, column: 10, scope: !197, inlinedAt: !167)
!197 = distinct !DILexicalBlock(scope: !163, file: !11, line: 89, column: 3)
!198 = !DILocation(line: 89, column: 8, scope: !197, inlinedAt: !167)
!199 = !DILocation(line: 89, column: 15, scope: !200, inlinedAt: !167)
!200 = distinct !DILexicalBlock(scope: !197, file: !11, line: 89, column: 3)
!201 = !DILocation(line: 89, column: 17, scope: !200, inlinedAt: !167)
!202 = !DILocation(line: 89, column: 3, scope: !197, inlinedAt: !167)
!203 = !DILocation(line: 91, column: 7, scope: !204, inlinedAt: !167)
!204 = distinct !DILexicalBlock(scope: !200, file: !11, line: 90, column: 5)
!205 = !DILocation(line: 91, column: 11, scope: !204, inlinedAt: !167)
!206 = !DILocation(line: 91, column: 14, scope: !204, inlinedAt: !167)
!207 = !DILocation(line: 92, column: 14, scope: !208, inlinedAt: !167)
!208 = distinct !DILexicalBlock(scope: !204, file: !11, line: 92, column: 7)
!209 = !DILocation(line: 92, column: 12, scope: !208, inlinedAt: !167)
!210 = !DILocation(line: 92, column: 19, scope: !211, inlinedAt: !167)
!211 = distinct !DILexicalBlock(scope: !208, file: !11, line: 92, column: 7)
!212 = !DILocation(line: 92, column: 21, scope: !211, inlinedAt: !167)
!213 = !DILocation(line: 92, column: 7, scope: !208, inlinedAt: !167)
!214 = !DILocation(line: 93, column: 11, scope: !211, inlinedAt: !167)
!215 = !DILocation(line: 93, column: 15, scope: !211, inlinedAt: !167)
!216 = !DILocation(line: 93, column: 20, scope: !211, inlinedAt: !167)
!217 = !DILocation(line: 93, column: 22, scope: !211, inlinedAt: !167)
!218 = !DILocation(line: 93, column: 25, scope: !211, inlinedAt: !167)
!219 = !DILocation(line: 93, column: 30, scope: !211, inlinedAt: !167)
!220 = !DILocation(line: 93, column: 32, scope: !211, inlinedAt: !167)
!221 = !DILocation(line: 93, column: 28, scope: !211, inlinedAt: !167)
!222 = !DILocation(line: 93, column: 18, scope: !211, inlinedAt: !167)
!223 = !DILocation(line: 93, column: 2, scope: !211, inlinedAt: !167)
!224 = !DILocation(line: 93, column: 6, scope: !211, inlinedAt: !167)
!225 = !DILocation(line: 93, column: 9, scope: !211, inlinedAt: !167)
!226 = !DILocation(line: 92, column: 31, scope: !211, inlinedAt: !167)
!227 = !DILocation(line: 92, column: 7, scope: !211, inlinedAt: !167)
!228 = distinct !{!228, !213, !229, !119}
!229 = !DILocation(line: 93, column: 33, scope: !208, inlinedAt: !167)
!230 = !DILocation(line: 94, column: 14, scope: !231, inlinedAt: !167)
!231 = distinct !DILexicalBlock(scope: !204, file: !11, line: 94, column: 7)
!232 = !DILocation(line: 94, column: 12, scope: !231, inlinedAt: !167)
!233 = !DILocation(line: 94, column: 19, scope: !234, inlinedAt: !167)
!234 = distinct !DILexicalBlock(scope: !231, file: !11, line: 94, column: 7)
!235 = !DILocation(line: 94, column: 21, scope: !234, inlinedAt: !167)
!236 = !DILocation(line: 94, column: 7, scope: !231, inlinedAt: !167)
!237 = !DILocation(line: 95, column: 9, scope: !234, inlinedAt: !167)
!238 = !DILocation(line: 95, column: 11, scope: !234, inlinedAt: !167)
!239 = !DILocation(line: 95, column: 16, scope: !234, inlinedAt: !167)
!240 = !DILocation(line: 95, column: 18, scope: !234, inlinedAt: !167)
!241 = !DILocation(line: 95, column: 21, scope: !234, inlinedAt: !167)
!242 = !DILocation(line: 95, column: 26, scope: !234, inlinedAt: !167)
!243 = !DILocation(line: 95, column: 30, scope: !234, inlinedAt: !167)
!244 = !DILocation(line: 95, column: 24, scope: !234, inlinedAt: !167)
!245 = !DILocation(line: 95, column: 14, scope: !234, inlinedAt: !167)
!246 = !DILocation(line: 95, column: 2, scope: !234, inlinedAt: !167)
!247 = !DILocation(line: 95, column: 4, scope: !234, inlinedAt: !167)
!248 = !DILocation(line: 95, column: 7, scope: !234, inlinedAt: !167)
!249 = !DILocation(line: 94, column: 31, scope: !234, inlinedAt: !167)
!250 = !DILocation(line: 94, column: 7, scope: !234, inlinedAt: !167)
!251 = distinct !{!251, !236, !252, !119}
!252 = !DILocation(line: 95, column: 31, scope: !231, inlinedAt: !167)
!253 = !DILocation(line: 89, column: 27, scope: !200, inlinedAt: !167)
!254 = !DILocation(line: 89, column: 3, scope: !200, inlinedAt: !167)
!255 = distinct !{!255, !202, !256, !119}
!256 = !DILocation(line: 96, column: 5, scope: !197, inlinedAt: !167)
!257 = !DILocation(line: 120, column: 3, scope: !159)
!258 = distinct !DISubprogram(name: "workload_checksum", scope: !11, file: !11, line: 122, type: !259, scopeLine: 122, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !2, retainedNodes: !62)
!259 = !DISubroutineType(types: !260)
!260 = !{!20, !6}
!261 = !DILocalVariable(name: "task", arg: 1, scope: !258, file: !11, line: 122, type: !6)
!262 = !DILocation(line: 122, column: 37, scope: !258)
!263 = !DILocation(line: 123, column: 9, scope: !258)
!264 = !DILocation(line: 124, column: 11, scope: !258)
!265 = !DILocation(line: 125, column: 15, scope: !258)
!266 = !DILocation(line: 125, column: 3, scope: !258)
!267 = !DILocation(line: 126, column: 10, scope: !258)
!268 = !DILocation(line: 126, column: 3, scope: !258)
!269 = distinct !DISubprogram(name: "print_array", scope: !11, file: !11, line: 58, type: !270, scopeLine: 61, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition, unit: !2, retainedNodes: !62)
!270 = !DISubroutineType(types: !271)
!271 = !{null, !12, !82}
!272 = !DILocalVariable(name: "n", arg: 1, scope: !269, file: !11, line: 58, type: !12)
!273 = !DILocation(line: 58, column: 22, scope: !269)
!274 = !DILocalVariable(name: "y", arg: 2, scope: !269, file: !11, line: 59, type: !82)
!275 = !DILocation(line: 59, column: 14, scope: !269)
!276 = !DILocalVariable(name: "i", scope: !269, file: !11, line: 62, type: !12)
!277 = !DILocation(line: 62, column: 7, scope: !269)
!278 = !DILocation(line: 64, column: 3, scope: !269)
!279 = !DILocation(line: 65, column: 3, scope: !269)
!280 = !DILocation(line: 66, column: 10, scope: !281)
!281 = distinct !DILexicalBlock(scope: !269, file: !11, line: 66, column: 3)
!282 = !DILocation(line: 66, column: 8, scope: !281)
!283 = !DILocation(line: 66, column: 15, scope: !284)
!284 = distinct !DILexicalBlock(scope: !281, file: !11, line: 66, column: 3)
!285 = !DILocation(line: 66, column: 19, scope: !284)
!286 = !DILocation(line: 66, column: 17, scope: !284)
!287 = !DILocation(line: 66, column: 3, scope: !281)
!288 = !DILocation(line: 67, column: 9, scope: !289)
!289 = distinct !DILexicalBlock(scope: !290, file: !11, line: 67, column: 9)
!290 = distinct !DILexicalBlock(scope: !284, file: !11, line: 66, column: 27)
!291 = !DILocation(line: 67, column: 11, scope: !289)
!292 = !DILocation(line: 67, column: 16, scope: !289)
!293 = !DILocation(line: 67, column: 9, scope: !290)
!294 = !DILocation(line: 67, column: 31, scope: !289)
!295 = !DILocation(line: 67, column: 22, scope: !289)
!296 = !DILocation(line: 68, column: 14, scope: !290)
!297 = !DILocation(line: 68, column: 59, scope: !290)
!298 = !DILocation(line: 68, column: 61, scope: !290)
!299 = !DILocation(line: 68, column: 5, scope: !290)
!300 = !DILocation(line: 69, column: 3, scope: !290)
!301 = !DILocation(line: 66, column: 23, scope: !284)
!302 = !DILocation(line: 66, column: 3, scope: !284)
!303 = distinct !{!303, !287, !304, !119}
!304 = !DILocation(line: 69, column: 3, scope: !281)
!305 = !DILocation(line: 70, column: 3, scope: !269)
!306 = !DILocation(line: 71, column: 3, scope: !269)
!307 = !DILocation(line: 72, column: 1, scope: !269)
!308 = distinct !DISubprogram(name: "pb_fprintf", scope: !32, file: !32, line: 13, type: !309, scopeLine: 14, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition, unit: !2, retainedNodes: !62)
!309 = !DISubroutineType(types: !310)
!310 = !{!12, !311, !370, null}
!311 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !312, size: 64)
!312 = !DIDerivedType(tag: DW_TAG_typedef, name: "FILE", file: !313, line: 7, baseType: !314)
!313 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/types/FILE.h", directory: "", checksumkind: CSK_MD5, checksum: "571f9fb6223c42439075fdde11a0de5d")
!314 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "_IO_FILE", file: !315, line: 49, size: 1728, elements: !316)
!315 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/types/struct_FILE.h", directory: "", checksumkind: CSK_MD5, checksum: "1bad07471b7974df4ecc1d1c2ca207e6")
!316 = !{!317, !318, !321, !322, !323, !324, !325, !326, !327, !328, !329, !330, !331, !334, !336, !337, !338, !341, !343, !345, !347, !350, !352, !355, !358, !359, !361, !365, !366}
!317 = !DIDerivedType(tag: DW_TAG_member, name: "_flags", scope: !314, file: !315, line: 51, baseType: !12, size: 32)
!318 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_read_ptr", scope: !314, file: !315, line: 54, baseType: !319, size: 64, offset: 64)
!319 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !320, size: 64)
!320 = !DIBasicType(name: "char", size: 8, encoding: DW_ATE_signed_char)
!321 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_read_end", scope: !314, file: !315, line: 55, baseType: !319, size: 64, offset: 128)
!322 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_read_base", scope: !314, file: !315, line: 56, baseType: !319, size: 64, offset: 192)
!323 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_write_base", scope: !314, file: !315, line: 57, baseType: !319, size: 64, offset: 256)
!324 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_write_ptr", scope: !314, file: !315, line: 58, baseType: !319, size: 64, offset: 320)
!325 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_write_end", scope: !314, file: !315, line: 59, baseType: !319, size: 64, offset: 384)
!326 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_buf_base", scope: !314, file: !315, line: 60, baseType: !319, size: 64, offset: 448)
!327 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_buf_end", scope: !314, file: !315, line: 61, baseType: !319, size: 64, offset: 512)
!328 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_save_base", scope: !314, file: !315, line: 64, baseType: !319, size: 64, offset: 576)
!329 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_backup_base", scope: !314, file: !315, line: 65, baseType: !319, size: 64, offset: 640)
!330 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_save_end", scope: !314, file: !315, line: 66, baseType: !319, size: 64, offset: 704)
!331 = !DIDerivedType(tag: DW_TAG_member, name: "_markers", scope: !314, file: !315, line: 68, baseType: !332, size: 64, offset: 768)
!332 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !333, size: 64)
!333 = !DICompositeType(tag: DW_TAG_structure_type, name: "_IO_marker", file: !315, line: 36, flags: DIFlagFwdDecl)
!334 = !DIDerivedType(tag: DW_TAG_member, name: "_chain", scope: !314, file: !315, line: 70, baseType: !335, size: 64, offset: 832)
!335 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !314, size: 64)
!336 = !DIDerivedType(tag: DW_TAG_member, name: "_fileno", scope: !314, file: !315, line: 72, baseType: !12, size: 32, offset: 896)
!337 = !DIDerivedType(tag: DW_TAG_member, name: "_flags2", scope: !314, file: !315, line: 73, baseType: !12, size: 32, offset: 928)
!338 = !DIDerivedType(tag: DW_TAG_member, name: "_old_offset", scope: !314, file: !315, line: 74, baseType: !339, size: 64, offset: 960)
!339 = !DIDerivedType(tag: DW_TAG_typedef, name: "__off_t", file: !23, line: 152, baseType: !340)
!340 = !DIBasicType(name: "long", size: 64, encoding: DW_ATE_signed)
!341 = !DIDerivedType(tag: DW_TAG_member, name: "_cur_column", scope: !314, file: !315, line: 77, baseType: !342, size: 16, offset: 1024)
!342 = !DIBasicType(name: "unsigned short", size: 16, encoding: DW_ATE_unsigned)
!343 = !DIDerivedType(tag: DW_TAG_member, name: "_vtable_offset", scope: !314, file: !315, line: 78, baseType: !344, size: 8, offset: 1040)
!344 = !DIBasicType(name: "signed char", size: 8, encoding: DW_ATE_signed_char)
!345 = !DIDerivedType(tag: DW_TAG_member, name: "_shortbuf", scope: !314, file: !315, line: 79, baseType: !346, size: 8, offset: 1048)
!346 = !DICompositeType(tag: DW_TAG_array_type, baseType: !320, size: 8, elements: !24)
!347 = !DIDerivedType(tag: DW_TAG_member, name: "_lock", scope: !314, file: !315, line: 81, baseType: !348, size: 64, offset: 1088)
!348 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !349, size: 64)
!349 = !DIDerivedType(tag: DW_TAG_typedef, name: "_IO_lock_t", file: !315, line: 43, baseType: null)
!350 = !DIDerivedType(tag: DW_TAG_member, name: "_offset", scope: !314, file: !315, line: 89, baseType: !351, size: 64, offset: 1152)
!351 = !DIDerivedType(tag: DW_TAG_typedef, name: "__off64_t", file: !23, line: 153, baseType: !340)
!352 = !DIDerivedType(tag: DW_TAG_member, name: "_codecvt", scope: !314, file: !315, line: 91, baseType: !353, size: 64, offset: 1216)
!353 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !354, size: 64)
!354 = !DICompositeType(tag: DW_TAG_structure_type, name: "_IO_codecvt", file: !315, line: 37, flags: DIFlagFwdDecl)
!355 = !DIDerivedType(tag: DW_TAG_member, name: "_wide_data", scope: !314, file: !315, line: 92, baseType: !356, size: 64, offset: 1280)
!356 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !357, size: 64)
!357 = !DICompositeType(tag: DW_TAG_structure_type, name: "_IO_wide_data", file: !315, line: 38, flags: DIFlagFwdDecl)
!358 = !DIDerivedType(tag: DW_TAG_member, name: "_freeres_list", scope: !314, file: !315, line: 93, baseType: !335, size: 64, offset: 1344)
!359 = !DIDerivedType(tag: DW_TAG_member, name: "_freeres_buf", scope: !314, file: !315, line: 94, baseType: !360, size: 64, offset: 1408)
!360 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: null, size: 64)
!361 = !DIDerivedType(tag: DW_TAG_member, name: "__pad5", scope: !314, file: !315, line: 95, baseType: !362, size: 64, offset: 1472)
!362 = !DIDerivedType(tag: DW_TAG_typedef, name: "size_t", file: !363, line: 46, baseType: !364)
!363 = !DIFile(filename: "/usr/lib/llvm-14/lib/clang/14.0.0/include/stddef.h", directory: "", checksumkind: CSK_MD5, checksum: "2499dd2361b915724b073282bea3a7bc")
!364 = !DIBasicType(name: "unsigned long", size: 64, encoding: DW_ATE_unsigned)
!365 = !DIDerivedType(tag: DW_TAG_member, name: "_mode", scope: !314, file: !315, line: 96, baseType: !12, size: 32, offset: 1536)
!366 = !DIDerivedType(tag: DW_TAG_member, name: "_unused2", scope: !314, file: !315, line: 98, baseType: !367, size: 160, offset: 1568)
!367 = !DICompositeType(tag: DW_TAG_array_type, baseType: !320, size: 160, elements: !368)
!368 = !{!369}
!369 = !DISubrange(count: 20)
!370 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !371, size: 64)
!371 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !320)
!372 = !DILocalVariable(name: "stream", arg: 1, scope: !308, file: !32, line: 13, type: !311)
!373 = !DILocation(line: 13, column: 29, scope: !308)
!374 = !DILocalVariable(name: "format", arg: 2, scope: !308, file: !32, line: 13, type: !370)
!375 = !DILocation(line: 13, column: 49, scope: !308)
!376 = !DILocalVariable(name: "buffer", scope: !308, file: !32, line: 15, type: !377)
!377 = !DICompositeType(tag: DW_TAG_array_type, baseType: !320, size: 6144, elements: !378)
!378 = !{!379}
!379 = !DISubrange(count: 768)
!380 = !DILocation(line: 15, column: 10, scope: !308)
!381 = !DILocalVariable(name: "args", scope: !308, file: !32, line: 16, type: !382)
!382 = !DIDerivedType(tag: DW_TAG_typedef, name: "va_list", file: !383, line: 52, baseType: !384)
!383 = !DIFile(filename: "/usr/include/stdio.h", directory: "", checksumkind: CSK_MD5, checksum: "f31eefcc3f15835fc5a4023a625cf609")
!384 = !DIDerivedType(tag: DW_TAG_typedef, name: "__gnuc_va_list", file: !385, line: 32, baseType: !386)
!385 = !DIFile(filename: "/usr/lib/llvm-14/lib/clang/14.0.0/include/stdarg.h", directory: "", checksumkind: CSK_MD5, checksum: "4de3cbd931b589d291e5c39387aecf82")
!386 = !DIDerivedType(tag: DW_TAG_typedef, name: "__builtin_va_list", file: !387, baseType: !388)
!387 = !DIFile(filename: "source/workload.c", directory: "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/affine-bounds-20260929/suite/atax")
!388 = !DICompositeType(tag: DW_TAG_array_type, baseType: !389, size: 192, elements: !24)
!389 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "__va_list_tag", size: 192, elements: !390)
!390 = !{!391, !392, !393, !394}
!391 = !DIDerivedType(tag: DW_TAG_member, name: "gp_offset", scope: !389, file: !387, line: 16, baseType: !6, size: 32)
!392 = !DIDerivedType(tag: DW_TAG_member, name: "fp_offset", scope: !389, file: !387, line: 16, baseType: !6, size: 32, offset: 32)
!393 = !DIDerivedType(tag: DW_TAG_member, name: "overflow_arg_area", scope: !389, file: !387, line: 16, baseType: !360, size: 64, offset: 64)
!394 = !DIDerivedType(tag: DW_TAG_member, name: "reg_save_area", scope: !389, file: !387, line: 16, baseType: !360, size: 64, offset: 128)
!395 = !DILocation(line: 16, column: 13, scope: !308)
!396 = !DILocation(line: 17, column: 5, scope: !308)
!397 = !DILocalVariable(name: "count", scope: !308, file: !32, line: 18, type: !12)
!398 = !DILocation(line: 18, column: 9, scope: !308)
!399 = !DILocation(line: 18, column: 27, scope: !308)
!400 = !DILocation(line: 18, column: 51, scope: !308)
!401 = !DILocation(line: 18, column: 59, scope: !308)
!402 = !DILocation(line: 18, column: 17, scope: !308)
!403 = !DILocation(line: 19, column: 5, scope: !308)
!404 = !DILocation(line: 20, column: 9, scope: !405)
!405 = distinct !DILexicalBlock(scope: !308, file: !32, line: 20, column: 9)
!406 = !DILocation(line: 20, column: 15, scope: !405)
!407 = !DILocation(line: 20, column: 19, scope: !405)
!408 = !DILocation(line: 20, column: 32, scope: !405)
!409 = !DILocation(line: 20, column: 22, scope: !405)
!410 = !DILocation(line: 20, column: 38, scope: !405)
!411 = !DILocation(line: 20, column: 9, scope: !308)
!412 = !DILocation(line: 20, column: 57, scope: !405)
!413 = !DILocalVariable(name: "i", scope: !414, file: !32, line: 21, type: !12)
!414 = distinct !DILexicalBlock(scope: !308, file: !32, line: 21, column: 5)
!415 = !DILocation(line: 21, column: 14, scope: !414)
!416 = !DILocation(line: 21, column: 10, scope: !414)
!417 = !DILocation(line: 21, column: 21, scope: !418)
!418 = distinct !DILexicalBlock(scope: !414, file: !32, line: 21, column: 5)
!419 = !DILocation(line: 21, column: 25, scope: !418)
!420 = !DILocation(line: 21, column: 23, scope: !418)
!421 = !DILocation(line: 21, column: 5, scope: !414)
!422 = !DILocation(line: 22, column: 42, scope: !423)
!423 = distinct !DILexicalBlock(scope: !418, file: !32, line: 21, column: 37)
!424 = !DILocation(line: 22, column: 35, scope: !423)
!425 = !DILocation(line: 22, column: 20, scope: !423)
!426 = !DILocation(line: 22, column: 17, scope: !423)
!427 = !DILocation(line: 23, column: 17, scope: !423)
!428 = !DILocation(line: 24, column: 5, scope: !423)
!429 = !DILocation(line: 21, column: 32, scope: !418)
!430 = !DILocation(line: 21, column: 5, scope: !418)
!431 = distinct !{!431, !421, !432, !119}
!432 = !DILocation(line: 24, column: 5, scope: !414)
!433 = !DILocation(line: 28, column: 11, scope: !308)
!434 = !DILocation(line: 29, column: 11, scope: !308)
!435 = !DILocation(line: 31, column: 12, scope: !308)
!436 = !DILocation(line: 31, column: 5, scope: !308)
