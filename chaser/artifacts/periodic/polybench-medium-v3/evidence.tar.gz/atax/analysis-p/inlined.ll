; ModuleID = 'workload.ll'
source_filename = "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/affine-bounds-20260929/suite/atax/source/workload.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

%struct._IO_FILE = type { i32, i8*, i8*, i8*, i8*, i8*, i8*, i8*, i8*, i8*, i8*, i8*, %struct._IO_marker*, %struct._IO_FILE*, i32, i32, i64, i16, i8, [1 x i8], i8*, i64, %struct._IO_codecvt*, %struct._IO_wide_data*, %struct._IO_FILE*, i8*, i64, i32, [20 x i8] }
%struct._IO_marker = type opaque
%struct._IO_codecvt = type opaque
%struct._IO_wide_data = type opaque
%struct.__va_list_tag = type { i32, i32, i8*, i8* }

@m = dso_local global i32 390, align 4, !dbg !0
@n = dso_local global i32 410, align 4, !dbg !9
@A = dso_local global [390 x [410 x double]] zeroinitializer, section ".chaser_data.A", align 64, !dbg !33
@x = dso_local global [410 x double] zeroinitializer, section ".chaser_data.x", align 64, !dbg !39
@y = dso_local global [410 x double] zeroinitializer, section ".chaser_data.y", align 64, !dbg !43
@tmp = dso_local global [390 x double] zeroinitializer, section ".chaser_data.tmp", align 64, !dbg !45
@.str = private unnamed_addr constant [12 x i8] c"ape.analyze\00", section "llvm.metadata"
@.str.1 = private unnamed_addr constant [122 x i8] c"/workspace/experiments-array-support/chaser/.cache/periodic-polybench/affine-bounds-20260929/suite/atax/source/workload.c\00", section "llvm.metadata"
@pb_hash = internal global i32 0, align 4, !dbg !30
@workload_jobs = dso_local constant [1 x i32 ()*] [i32 ()* @task_job_polybench], align 8, !dbg !13
@workload_expected = dso_local constant [1 x i32] [i32 1921650095], align 4, !dbg !26
@stderr = external global %struct._IO_FILE*, align 8
@.str.2 = private unnamed_addr constant [23 x i8] c"==BEGIN DUMP_ARRAYS==\0A\00", align 1
@.str.3 = private unnamed_addr constant [15 x i8] c"begin dump: %s\00", align 1
@.str.4 = private unnamed_addr constant [2 x i8] c"y\00", align 1
@.str.5 = private unnamed_addr constant [2 x i8] c"\0A\00", align 1
@.str.6 = private unnamed_addr constant [8 x i8] c"%0.2lf \00", align 1
@.str.7 = private unnamed_addr constant [17 x i8] c"\0Aend   dump: %s\0A\00", align 1
@.str.8 = private unnamed_addr constant [23 x i8] c"==END   DUMP_ARRAYS==\0A\00", align 1
@pb_emit = internal global i32 1, align 4, !dbg !49
@llvm.global.annotations = appending global [1 x { i8*, i8*, i8*, i32, i8* }] [{ i8*, i8*, i8*, i32, i8* } { i8* bitcast (i32 ()* @task_job_polybench to i8*), i8* getelementptr inbounds ([12 x i8], [12 x i8]* @.str, i32 0, i32 0), i8* getelementptr inbounds ([122 x i8], [122 x i8]* @.str.1, i32 0, i32 0), i32 114, i8* null }], section "llvm.metadata"

; Function Attrs: noinline nounwind uwtable
define dso_local void @workload_prepare() #0 !dbg !59 {
  ret void, !dbg !63
}

; Function Attrs: noinline nounwind uwtable
define dso_local void @workload_reset(i32 noundef %0) #0 !dbg !64 {
  call void @llvm.dbg.value(metadata i32 %0, metadata !67, metadata !DIExpression()), !dbg !68
  call void @llvm.memset.p0i8.i64(i8* align 64 bitcast ([390 x [410 x double]]* @A to i8*), i8 0, i64 1279200, i1 false), !dbg !69
  call void @llvm.memset.p0i8.i64(i8* align 64 bitcast ([410 x double]* @x to i8*), i8 0, i64 3280, i1 false), !dbg !70
  call void @llvm.memset.p0i8.i64(i8* align 64 bitcast ([410 x double]* @y to i8*), i8 0, i64 3280, i1 false), !dbg !71
  call void @llvm.memset.p0i8.i64(i8* align 64 bitcast ([390 x double]* @tmp to i8*), i8 0, i64 3120, i1 false), !dbg !72
  %2 = load i32, i32* @m, align 4, !dbg !73
  %3 = load i32, i32* @n, align 4, !dbg !74
  call void @init_array(i32 noundef %2, i32 noundef %3, [410 x double]* noundef getelementptr inbounds ([390 x [410 x double]], [390 x [410 x double]]* @A, i64 0, i64 0), double* noundef getelementptr inbounds ([410 x double], [410 x double]* @x, i64 0, i64 0)), !dbg !75
  ret void, !dbg !76
}

; Function Attrs: nofree nosync nounwind readnone speculatable willreturn
declare void @llvm.dbg.declare(metadata, metadata, metadata) #1

; Function Attrs: argmemonly nofree nounwind willreturn writeonly
declare void @llvm.memset.p0i8.i64(i8* nocapture writeonly, i8, i64, i1 immarg) #2

; Function Attrs: noinline nounwind uwtable
define internal void @init_array(i32 noundef %0, i32 noundef %1, [410 x double]* noundef %2, double* noundef %3) #0 !dbg !77 {
  call void @llvm.dbg.value(metadata i32 %0, metadata !82, metadata !DIExpression()), !dbg !83
  call void @llvm.dbg.value(metadata i32 %1, metadata !84, metadata !DIExpression()), !dbg !83
  call void @llvm.dbg.value(metadata [410 x double]* %2, metadata !85, metadata !DIExpression()), !dbg !83
  call void @llvm.dbg.value(metadata double* %3, metadata !86, metadata !DIExpression()), !dbg !83
  %5 = sitofp i32 %1 to double, !dbg !87
  call void @llvm.dbg.value(metadata double %5, metadata !88, metadata !DIExpression()), !dbg !83
  call void @llvm.dbg.value(metadata i32 0, metadata !89, metadata !DIExpression()), !dbg !83
  br label %6, !dbg !90

6:                                                ; preds = %14, %4
  %.01 = phi i32 [ 0, %4 ], [ %15, %14 ], !dbg !92
  call void @llvm.dbg.value(metadata i32 %.01, metadata !89, metadata !DIExpression()), !dbg !83
  %7 = icmp slt i32 %.01, %1, !dbg !93
  br i1 %7, label %8, label %16, !dbg !95

8:                                                ; preds = %6
  %9 = sitofp i32 %.01 to double, !dbg !96
  %10 = fdiv double %9, %5, !dbg !97
  %11 = fadd double 1.000000e+00, %10, !dbg !98
  %12 = sext i32 %.01 to i64, !dbg !99
  %13 = getelementptr inbounds double, double* %3, i64 %12, !dbg !99
  store double %11, double* %13, align 8, !dbg !100
  br label %14, !dbg !99

14:                                               ; preds = %8
  %15 = add nsw i32 %.01, 1, !dbg !101
  call void @llvm.dbg.value(metadata i32 %15, metadata !89, metadata !DIExpression()), !dbg !83
  br label %6, !dbg !102, !llvm.loop !103

16:                                               ; preds = %6
  call void @llvm.dbg.value(metadata i32 0, metadata !89, metadata !DIExpression()), !dbg !83
  br label %17, !dbg !106

17:                                               ; preds = %36, %16
  %.1 = phi i32 [ 0, %16 ], [ %37, %36 ], !dbg !108
  call void @llvm.dbg.value(metadata i32 %.1, metadata !89, metadata !DIExpression()), !dbg !83
  %18 = icmp slt i32 %.1, %0, !dbg !109
  br i1 %18, label %19, label %38, !dbg !111

19:                                               ; preds = %17
  call void @llvm.dbg.value(metadata i32 0, metadata !112, metadata !DIExpression()), !dbg !83
  br label %20, !dbg !113

20:                                               ; preds = %33, %19
  %.0 = phi i32 [ 0, %19 ], [ %34, %33 ], !dbg !115
  call void @llvm.dbg.value(metadata i32 %.0, metadata !112, metadata !DIExpression()), !dbg !83
  %21 = icmp slt i32 %.0, %1, !dbg !116
  br i1 %21, label %22, label %35, !dbg !118

22:                                               ; preds = %20
  %23 = add nsw i32 %.1, %.0, !dbg !119
  %24 = srem i32 %23, %1, !dbg !120
  %25 = sitofp i32 %24 to double, !dbg !121
  %26 = mul nsw i32 5, %0, !dbg !122
  %27 = sitofp i32 %26 to double, !dbg !123
  %28 = fdiv double %25, %27, !dbg !124
  %29 = sext i32 %.1 to i64, !dbg !125
  %30 = getelementptr inbounds [410 x double], [410 x double]* %2, i64 %29, !dbg !125
  %31 = sext i32 %.0 to i64, !dbg !125
  %32 = getelementptr inbounds [410 x double], [410 x double]* %30, i64 0, i64 %31, !dbg !125
  store double %28, double* %32, align 8, !dbg !126
  br label %33, !dbg !125

33:                                               ; preds = %22
  %34 = add nsw i32 %.0, 1, !dbg !127
  call void @llvm.dbg.value(metadata i32 %34, metadata !112, metadata !DIExpression()), !dbg !83
  br label %20, !dbg !128, !llvm.loop !129

35:                                               ; preds = %20
  br label %36, !dbg !130

36:                                               ; preds = %35
  %37 = add nsw i32 %.1, 1, !dbg !131
  call void @llvm.dbg.value(metadata i32 %37, metadata !89, metadata !DIExpression()), !dbg !83
  br label %17, !dbg !132, !llvm.loop !133

38:                                               ; preds = %17
  ret void, !dbg !135
}

; Function Attrs: noinline nounwind uwtable
define dso_local i32 @task_job_polybench() #0 !dbg !136 {
  %1 = load i32, i32* @m, align 4, !dbg !137
  %2 = load i32, i32* @n, align 4, !dbg !138
  call void @llvm.dbg.value(metadata i32 %1, metadata !139, metadata !DIExpression()), !dbg !143
  call void @llvm.dbg.value(metadata i32 %2, metadata !145, metadata !DIExpression()), !dbg !143
  call void @llvm.dbg.value(metadata [410 x double]* getelementptr inbounds ([390 x [410 x double]], [390 x [410 x double]]* @A, i64 0, i64 0), metadata !146, metadata !DIExpression()), !dbg !143
  call void @llvm.dbg.value(metadata double* getelementptr inbounds ([410 x double], [410 x double]* @x, i64 0, i64 0), metadata !147, metadata !DIExpression()), !dbg !143
  call void @llvm.dbg.value(metadata double* getelementptr inbounds ([410 x double], [410 x double]* @y, i64 0, i64 0), metadata !148, metadata !DIExpression()), !dbg !143
  call void @llvm.dbg.value(metadata double* getelementptr inbounds ([390 x double], [390 x double]* @tmp, i64 0, i64 0), metadata !149, metadata !DIExpression()), !dbg !143
  call void @llvm.dbg.value(metadata i32 0, metadata !150, metadata !DIExpression()), !dbg !143
  br label %3, !dbg !151

3:                                                ; preds = %5, %0
  %.01 = phi i32 [ 0, %0 ], [ %8, %5 ], !dbg !153
  call void @llvm.dbg.value(metadata i32 %.01, metadata !150, metadata !DIExpression()), !dbg !143
  %4 = icmp slt i32 %.01, 410, !dbg !154
  br i1 %4, label %5, label %9, !dbg !156

5:                                                ; preds = %3
  %6 = sext i32 %.01 to i64, !dbg !157
  %7 = getelementptr inbounds double, double* getelementptr inbounds ([410 x double], [410 x double]* @y, i64 0, i64 0), i64 %6, !dbg !157
  store double 0.000000e+00, double* %7, align 8, !dbg !158
  %8 = add nsw i32 %.01, 1, !dbg !159
  call void @llvm.dbg.value(metadata i32 %8, metadata !150, metadata !DIExpression()), !dbg !143
  br label %3, !dbg !160, !llvm.loop !161

9:                                                ; preds = %3
  call void @llvm.dbg.value(metadata i32 0, metadata !150, metadata !DIExpression()), !dbg !143
  br label %10, !dbg !163

10:                                               ; preds = %54, %9
  %.12 = phi i32 [ 0, %9 ], [ %55, %54 ], !dbg !165
  call void @llvm.dbg.value(metadata i32 %.12, metadata !150, metadata !DIExpression()), !dbg !143
  %11 = icmp slt i32 %.12, 390, !dbg !166
  br i1 %11, label %12, label %56, !dbg !168

12:                                               ; preds = %10
  %13 = sext i32 %.12 to i64, !dbg !169
  %14 = getelementptr inbounds double, double* getelementptr inbounds ([390 x double], [390 x double]* @tmp, i64 0, i64 0), i64 %13, !dbg !169
  store double 0.000000e+00, double* %14, align 8, !dbg !171
  call void @llvm.dbg.value(metadata i32 0, metadata !172, metadata !DIExpression()), !dbg !143
  br label %15, !dbg !173

15:                                               ; preds = %17, %12
  %.0 = phi i32 [ 0, %12 ], [ %33, %17 ], !dbg !175
  call void @llvm.dbg.value(metadata i32 %.0, metadata !172, metadata !DIExpression()), !dbg !143
  %16 = icmp slt i32 %.0, 410, !dbg !176
  br i1 %16, label %17, label %34, !dbg !178

17:                                               ; preds = %15
  %18 = sext i32 %.12 to i64, !dbg !179
  %19 = getelementptr inbounds double, double* getelementptr inbounds ([390 x double], [390 x double]* @tmp, i64 0, i64 0), i64 %18, !dbg !179
  %20 = load double, double* %19, align 8, !dbg !179
  %21 = sext i32 %.12 to i64, !dbg !180
  %22 = getelementptr inbounds [410 x double], [410 x double]* getelementptr inbounds ([390 x [410 x double]], [390 x [410 x double]]* @A, i64 0, i64 0), i64 %21, !dbg !180
  %23 = sext i32 %.0 to i64, !dbg !180
  %24 = getelementptr inbounds [410 x double], [410 x double]* %22, i64 0, i64 %23, !dbg !180
  %25 = load double, double* %24, align 8, !dbg !180
  %26 = sext i32 %.0 to i64, !dbg !181
  %27 = getelementptr inbounds double, double* getelementptr inbounds ([410 x double], [410 x double]* @x, i64 0, i64 0), i64 %26, !dbg !181
  %28 = load double, double* %27, align 8, !dbg !181
  %29 = fmul double %25, %28, !dbg !182
  %30 = fadd double %20, %29, !dbg !183
  %31 = sext i32 %.12 to i64, !dbg !184
  %32 = getelementptr inbounds double, double* getelementptr inbounds ([390 x double], [390 x double]* @tmp, i64 0, i64 0), i64 %31, !dbg !184
  store double %30, double* %32, align 8, !dbg !185
  %33 = add nsw i32 %.0, 1, !dbg !186
  call void @llvm.dbg.value(metadata i32 %33, metadata !172, metadata !DIExpression()), !dbg !143
  br label %15, !dbg !187, !llvm.loop !188

34:                                               ; preds = %15
  call void @llvm.dbg.value(metadata i32 0, metadata !172, metadata !DIExpression()), !dbg !143
  br label %35, !dbg !190

35:                                               ; preds = %37, %34
  %.1 = phi i32 [ 0, %34 ], [ %53, %37 ], !dbg !192
  call void @llvm.dbg.value(metadata i32 %.1, metadata !172, metadata !DIExpression()), !dbg !143
  %36 = icmp slt i32 %.1, 410, !dbg !193
  br i1 %36, label %37, label %54, !dbg !195

37:                                               ; preds = %35
  %38 = sext i32 %.1 to i64, !dbg !196
  %39 = getelementptr inbounds double, double* getelementptr inbounds ([410 x double], [410 x double]* @y, i64 0, i64 0), i64 %38, !dbg !196
  %40 = load double, double* %39, align 8, !dbg !196
  %41 = sext i32 %.12 to i64, !dbg !197
  %42 = getelementptr inbounds [410 x double], [410 x double]* getelementptr inbounds ([390 x [410 x double]], [390 x [410 x double]]* @A, i64 0, i64 0), i64 %41, !dbg !197
  %43 = sext i32 %.1 to i64, !dbg !197
  %44 = getelementptr inbounds [410 x double], [410 x double]* %42, i64 0, i64 %43, !dbg !197
  %45 = load double, double* %44, align 8, !dbg !197
  %46 = sext i32 %.12 to i64, !dbg !198
  %47 = getelementptr inbounds double, double* getelementptr inbounds ([390 x double], [390 x double]* @tmp, i64 0, i64 0), i64 %46, !dbg !198
  %48 = load double, double* %47, align 8, !dbg !198
  %49 = fmul double %45, %48, !dbg !199
  %50 = fadd double %40, %49, !dbg !200
  %51 = sext i32 %.1 to i64, !dbg !201
  %52 = getelementptr inbounds double, double* getelementptr inbounds ([410 x double], [410 x double]* @y, i64 0, i64 0), i64 %51, !dbg !201
  store double %50, double* %52, align 8, !dbg !202
  %53 = add nsw i32 %.1, 1, !dbg !203
  call void @llvm.dbg.value(metadata i32 %53, metadata !172, metadata !DIExpression()), !dbg !143
  br label %35, !dbg !204, !llvm.loop !205

54:                                               ; preds = %35
  %55 = add nsw i32 %.12, 1, !dbg !207
  call void @llvm.dbg.value(metadata i32 %55, metadata !150, metadata !DIExpression()), !dbg !143
  br label %10, !dbg !208, !llvm.loop !209

56:                                               ; preds = %10
  ret i32 0, !dbg !211
}

; Function Attrs: noinline nounwind uwtable
define dso_local i32 @workload_checksum(i32 noundef %0) #0 !dbg !212 {
  call void @llvm.dbg.value(metadata i32 %0, metadata !215, metadata !DIExpression()), !dbg !216
  store i32 -2128831035, i32* @pb_hash, align 4, !dbg !217
  %2 = load i32, i32* @n, align 4, !dbg !218
  call void @print_array(i32 noundef %2, double* noundef getelementptr inbounds ([410 x double], [410 x double]* @y, i64 0, i64 0)), !dbg !219
  %3 = load i32, i32* @pb_hash, align 4, !dbg !220
  ret i32 %3, !dbg !221
}

; Function Attrs: noinline nounwind uwtable
define internal void @print_array(i32 noundef %0, double* noundef %1) #0 !dbg !222 {
  call void @llvm.dbg.value(metadata i32 %0, metadata !225, metadata !DIExpression()), !dbg !226
  call void @llvm.dbg.value(metadata double* %1, metadata !227, metadata !DIExpression()), !dbg !226
  %3 = load %struct._IO_FILE*, %struct._IO_FILE** @stderr, align 8, !dbg !228
  %4 = call i32 (%struct._IO_FILE*, i8*, ...) @pb_fprintf(%struct._IO_FILE* noundef %3, i8* noundef getelementptr inbounds ([23 x i8], [23 x i8]* @.str.2, i64 0, i64 0)), !dbg !228
  %5 = load %struct._IO_FILE*, %struct._IO_FILE** @stderr, align 8, !dbg !229
  %6 = call i32 (%struct._IO_FILE*, i8*, ...) @pb_fprintf(%struct._IO_FILE* noundef %5, i8* noundef getelementptr inbounds ([15 x i8], [15 x i8]* @.str.3, i64 0, i64 0), i8* noundef getelementptr inbounds ([2 x i8], [2 x i8]* @.str.4, i64 0, i64 0)), !dbg !229
  call void @llvm.dbg.value(metadata i32 0, metadata !230, metadata !DIExpression()), !dbg !226
  br label %7, !dbg !231

7:                                                ; preds = %21, %2
  %.0 = phi i32 [ 0, %2 ], [ %22, %21 ], !dbg !233
  call void @llvm.dbg.value(metadata i32 %.0, metadata !230, metadata !DIExpression()), !dbg !226
  %8 = icmp slt i32 %.0, %0, !dbg !234
  br i1 %8, label %9, label %23, !dbg !236

9:                                                ; preds = %7
  %10 = srem i32 %.0, 20, !dbg !237
  %11 = icmp eq i32 %10, 0, !dbg !240
  br i1 %11, label %12, label %15, !dbg !241

12:                                               ; preds = %9
  %13 = load %struct._IO_FILE*, %struct._IO_FILE** @stderr, align 8, !dbg !242
  %14 = call i32 (%struct._IO_FILE*, i8*, ...) @pb_fprintf(%struct._IO_FILE* noundef %13, i8* noundef getelementptr inbounds ([2 x i8], [2 x i8]* @.str.5, i64 0, i64 0)), !dbg !243
  br label %15, !dbg !243

15:                                               ; preds = %12, %9
  %16 = load %struct._IO_FILE*, %struct._IO_FILE** @stderr, align 8, !dbg !244
  %17 = sext i32 %.0 to i64, !dbg !245
  %18 = getelementptr inbounds double, double* %1, i64 %17, !dbg !245
  %19 = load double, double* %18, align 8, !dbg !245
  %20 = call i32 (%struct._IO_FILE*, i8*, ...) @pb_fprintf(%struct._IO_FILE* noundef %16, i8* noundef getelementptr inbounds ([8 x i8], [8 x i8]* @.str.6, i64 0, i64 0), double noundef %19), !dbg !246
  br label %21, !dbg !247

21:                                               ; preds = %15
  %22 = add nsw i32 %.0, 1, !dbg !248
  call void @llvm.dbg.value(metadata i32 %22, metadata !230, metadata !DIExpression()), !dbg !226
  br label %7, !dbg !249, !llvm.loop !250

23:                                               ; preds = %7
  %24 = load %struct._IO_FILE*, %struct._IO_FILE** @stderr, align 8, !dbg !252
  %25 = call i32 (%struct._IO_FILE*, i8*, ...) @pb_fprintf(%struct._IO_FILE* noundef %24, i8* noundef getelementptr inbounds ([17 x i8], [17 x i8]* @.str.7, i64 0, i64 0), i8* noundef getelementptr inbounds ([2 x i8], [2 x i8]* @.str.4, i64 0, i64 0)), !dbg !252
  %26 = load %struct._IO_FILE*, %struct._IO_FILE** @stderr, align 8, !dbg !253
  %27 = call i32 (%struct._IO_FILE*, i8*, ...) @pb_fprintf(%struct._IO_FILE* noundef %26, i8* noundef getelementptr inbounds ([23 x i8], [23 x i8]* @.str.8, i64 0, i64 0)), !dbg !253
  ret void, !dbg !254
}

; Function Attrs: noinline nounwind uwtable
define internal i32 @pb_fprintf(%struct._IO_FILE* noundef %0, i8* noundef %1, ...) #0 !dbg !255 {
  %3 = alloca [768 x i8], align 16
  %4 = alloca [1 x %struct.__va_list_tag], align 16
  call void @llvm.dbg.value(metadata %struct._IO_FILE* %0, metadata !319, metadata !DIExpression()), !dbg !320
  call void @llvm.dbg.value(metadata i8* %1, metadata !321, metadata !DIExpression()), !dbg !320
  call void @llvm.dbg.declare(metadata [768 x i8]* %3, metadata !322, metadata !DIExpression()), !dbg !326
  call void @llvm.dbg.declare(metadata [1 x %struct.__va_list_tag]* %4, metadata !327, metadata !DIExpression()), !dbg !341
  %5 = getelementptr inbounds [1 x %struct.__va_list_tag], [1 x %struct.__va_list_tag]* %4, i64 0, i64 0, !dbg !342
  %6 = bitcast %struct.__va_list_tag* %5 to i8*, !dbg !342
  call void @llvm.va_start(i8* %6), !dbg !342
  %7 = getelementptr inbounds [768 x i8], [768 x i8]* %3, i64 0, i64 0, !dbg !343
  %8 = getelementptr inbounds [1 x %struct.__va_list_tag], [1 x %struct.__va_list_tag]* %4, i64 0, i64 0, !dbg !344
  %9 = call i32 @vsnprintf(i8* noundef %7, i64 noundef 768, i8* noundef %1, %struct.__va_list_tag* noundef %8) #6, !dbg !345
  call void @llvm.dbg.value(metadata i32 %9, metadata !346, metadata !DIExpression()), !dbg !320
  %10 = getelementptr inbounds [1 x %struct.__va_list_tag], [1 x %struct.__va_list_tag]* %4, i64 0, i64 0, !dbg !347
  %11 = bitcast %struct.__va_list_tag* %10 to i8*, !dbg !347
  call void @llvm.va_end(i8* %11), !dbg !347
  %12 = icmp slt i32 %9, 0, !dbg !348
  br i1 %12, label %16, label %13, !dbg !350

13:                                               ; preds = %2
  %14 = zext i32 %9 to i64, !dbg !351
  %15 = icmp uge i64 %14, 768, !dbg !352
  br i1 %15, label %16, label %17, !dbg !353

16:                                               ; preds = %13, %2
  call void @abort() #7, !dbg !354
  unreachable, !dbg !354

17:                                               ; preds = %13
  call void @llvm.dbg.value(metadata i32 0, metadata !355, metadata !DIExpression()), !dbg !357
  br label %18, !dbg !358

18:                                               ; preds = %29, %17
  %.0 = phi i32 [ 0, %17 ], [ %30, %29 ], !dbg !357
  call void @llvm.dbg.value(metadata i32 %.0, metadata !355, metadata !DIExpression()), !dbg !357
  %19 = icmp slt i32 %.0, %9, !dbg !359
  br i1 %19, label %20, label %31, !dbg !361

20:                                               ; preds = %18
  %21 = sext i32 %.0 to i64, !dbg !362
  %22 = getelementptr inbounds [768 x i8], [768 x i8]* %3, i64 0, i64 %21, !dbg !362
  %23 = load i8, i8* %22, align 1, !dbg !362
  %24 = zext i8 %23 to i32, !dbg !364
  %25 = load i32, i32* @pb_hash, align 4, !dbg !365
  %26 = xor i32 %25, %24, !dbg !365
  store i32 %26, i32* @pb_hash, align 4, !dbg !365
  %27 = load i32, i32* @pb_hash, align 4, !dbg !366
  %28 = mul i32 %27, 16777619, !dbg !366
  store i32 %28, i32* @pb_hash, align 4, !dbg !366
  br label %29, !dbg !367

29:                                               ; preds = %20
  %30 = add nsw i32 %.0, 1, !dbg !368
  call void @llvm.dbg.value(metadata i32 %30, metadata !355, metadata !DIExpression()), !dbg !357
  br label %18, !dbg !369, !llvm.loop !370

31:                                               ; preds = %18
  %32 = load i32, i32* @pb_emit, align 4, !dbg !372
  ret i32 %9, !dbg !373
}

; Function Attrs: nofree nosync nounwind willreturn
declare void @llvm.va_start(i8*) #3

; Function Attrs: nounwind
declare i32 @vsnprintf(i8* noundef, i64 noundef, i8* noundef, %struct.__va_list_tag* noundef) #4

; Function Attrs: nofree nosync nounwind willreturn
declare void @llvm.va_end(i8*) #3

; Function Attrs: noreturn nounwind
declare void @abort() #5

; Function Attrs: nofree nosync nounwind readnone speculatable willreturn
declare void @llvm.dbg.value(metadata, metadata, metadata) #1

attributes #0 = { noinline nounwind uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { nofree nosync nounwind readnone speculatable willreturn }
attributes #2 = { argmemonly nofree nounwind willreturn writeonly }
attributes #3 = { nofree nosync nounwind willreturn }
attributes #4 = { nounwind "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #5 = { noreturn nounwind "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #6 = { nounwind }
attributes #7 = { noreturn nounwind }

!llvm.dbg.cu = !{!2}
!llvm.module.flags = !{!51, !52, !53, !54, !55, !56, !57}
!llvm.ident = !{!58}

!0 = !DIGlobalVariableExpression(var: !1, expr: !DIExpression())
!1 = distinct !DIGlobalVariable(name: "m", scope: !2, file: !11, line: 103, type: !12, isLocal: false, isDefinition: true)
!2 = distinct !DICompileUnit(language: DW_LANG_C99, file: !3, producer: "Ubuntu clang version 14.0.0-1ubuntu1.1", isOptimized: false, runtimeVersion: 0, emissionKind: FullDebug, retainedTypes: !4, globals: !8, splitDebugInlining: false, nameTableKind: None)
!3 = !DIFile(filename: "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/affine-bounds-20260929/suite/atax/source/workload.c", directory: "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/affine-bounds-20260929/suite/atax/analysis-p", checksumkind: CSK_MD5, checksum: "1866978266073eb505d85c7a4917d95d")
!4 = !{!5, !6, !7}
!5 = !DIBasicType(name: "double", size: 64, encoding: DW_ATE_float)
!6 = !DIBasicType(name: "unsigned int", size: 32, encoding: DW_ATE_unsigned)
!7 = !DIBasicType(name: "unsigned char", size: 8, encoding: DW_ATE_unsigned_char)
!8 = !{!0, !9, !13, !26, !30, !33, !39, !43, !45, !49}
!9 = !DIGlobalVariableExpression(var: !10, expr: !DIExpression())
!10 = distinct !DIGlobalVariable(name: "n", scope: !2, file: !11, line: 104, type: !12, isLocal: false, isDefinition: true)
!11 = !DIFile(filename: "source/workload.c", directory: "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/affine-bounds-20260929/suite/atax", checksumkind: CSK_MD5, checksum: "1866978266073eb505d85c7a4917d95d")
!12 = !DIBasicType(name: "int", size: 32, encoding: DW_ATE_signed)
!13 = !DIGlobalVariableExpression(var: !14, expr: !DIExpression())
!14 = distinct !DIGlobalVariable(name: "workload_jobs", scope: !2, file: !11, line: 128, type: !15, isLocal: false, isDefinition: true)
!15 = !DICompositeType(tag: DW_TAG_array_type, baseType: !16, size: 64, elements: !24)
!16 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !17)
!17 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !18, size: 64)
!18 = !DISubroutineType(types: !19)
!19 = !{!20}
!20 = !DIDerivedType(tag: DW_TAG_typedef, name: "uint32_t", file: !21, line: 26, baseType: !22)
!21 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/stdint-uintn.h", directory: "", checksumkind: CSK_MD5, checksum: "2bf2ae53c58c01b1a1b9383b5195125c")
!22 = !DIDerivedType(tag: DW_TAG_typedef, name: "__uint32_t", file: !23, line: 42, baseType: !6)
!23 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/types.h", directory: "", checksumkind: CSK_MD5, checksum: "d108b5f93a74c50510d7d9bc0ab36df9")
!24 = !{!25}
!25 = !DISubrange(count: 1)
!26 = !DIGlobalVariableExpression(var: !27, expr: !DIExpression())
!27 = distinct !DIGlobalVariable(name: "workload_expected", scope: !2, file: !11, line: 132, type: !28, isLocal: false, isDefinition: true)
!28 = !DICompositeType(tag: DW_TAG_array_type, baseType: !29, size: 32, elements: !24)
!29 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !20)
!30 = !DIGlobalVariableExpression(var: !31, expr: !DIExpression())
!31 = distinct !DIGlobalVariable(name: "pb_hash", scope: !2, file: !32, line: 9, type: !20, isLocal: true, isDefinition: true)
!32 = !DIFile(filename: "source/adapter.h", directory: "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/affine-bounds-20260929/suite/atax", checksumkind: CSK_MD5, checksum: "26a6068928b2092758f244a9d00163d7")
!33 = !DIGlobalVariableExpression(var: !34, expr: !DIExpression())
!34 = distinct !DIGlobalVariable(name: "A", scope: !2, file: !11, line: 34, type: !35, isLocal: false, isDefinition: true, align: 512)
!35 = !DICompositeType(tag: DW_TAG_array_type, baseType: !5, size: 10233600, elements: !36)
!36 = !{!37, !38}
!37 = !DISubrange(count: 390)
!38 = !DISubrange(count: 410)
!39 = !DIGlobalVariableExpression(var: !40, expr: !DIExpression())
!40 = distinct !DIGlobalVariable(name: "x", scope: !2, file: !11, line: 35, type: !41, isLocal: false, isDefinition: true, align: 512)
!41 = !DICompositeType(tag: DW_TAG_array_type, baseType: !5, size: 26240, elements: !42)
!42 = !{!38}
!43 = !DIGlobalVariableExpression(var: !44, expr: !DIExpression())
!44 = distinct !DIGlobalVariable(name: "y", scope: !2, file: !11, line: 36, type: !41, isLocal: false, isDefinition: true, align: 512)
!45 = !DIGlobalVariableExpression(var: !46, expr: !DIExpression())
!46 = distinct !DIGlobalVariable(name: "tmp", scope: !2, file: !11, line: 37, type: !47, isLocal: false, isDefinition: true, align: 512)
!47 = !DICompositeType(tag: DW_TAG_array_type, baseType: !5, size: 24960, elements: !48)
!48 = !{!37}
!49 = !DIGlobalVariableExpression(var: !50, expr: !DIExpression())
!50 = distinct !DIGlobalVariable(name: "pb_emit", scope: !2, file: !32, line: 10, type: !12, isLocal: true, isDefinition: true)
!51 = !{i32 7, !"Dwarf Version", i32 5}
!52 = !{i32 2, !"Debug Info Version", i32 3}
!53 = !{i32 1, !"wchar_size", i32 4}
!54 = !{i32 7, !"PIC Level", i32 2}
!55 = !{i32 7, !"PIE Level", i32 2}
!56 = !{i32 7, !"uwtable", i32 1}
!57 = !{i32 7, !"frame-pointer", i32 2}
!58 = !{!"Ubuntu clang version 14.0.0-1ubuntu1.1"}
!59 = distinct !DISubprogram(name: "workload_prepare", scope: !11, file: !11, line: 105, type: !60, scopeLine: 105, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !2, retainedNodes: !62)
!60 = !DISubroutineType(types: !61)
!61 = !{null}
!62 = !{}
!63 = !DILocation(line: 105, column: 30, scope: !59)
!64 = distinct !DISubprogram(name: "workload_reset", scope: !11, file: !11, line: 106, type: !65, scopeLine: 106, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !2, retainedNodes: !62)
!65 = !DISubroutineType(types: !66)
!66 = !{null, !6}
!67 = !DILocalVariable(name: "task", arg: 1, scope: !64, file: !11, line: 106, type: !6)
!68 = !DILocation(line: 0, scope: !64)
!69 = !DILocation(line: 108, column: 3, scope: !64)
!70 = !DILocation(line: 109, column: 3, scope: !64)
!71 = !DILocation(line: 110, column: 3, scope: !64)
!72 = !DILocation(line: 111, column: 3, scope: !64)
!73 = !DILocation(line: 112, column: 15, scope: !64)
!74 = !DILocation(line: 112, column: 18, scope: !64)
!75 = !DILocation(line: 112, column: 3, scope: !64)
!76 = !DILocation(line: 113, column: 1, scope: !64)
!77 = distinct !DISubprogram(name: "init_array", scope: !11, file: !11, line: 39, type: !78, scopeLine: 42, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition, unit: !2, retainedNodes: !62)
!78 = !DISubroutineType(types: !79)
!79 = !{null, !12, !12, !80, !81}
!80 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !41, size: 64)
!81 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !5, size: 64)
!82 = !DILocalVariable(name: "m", arg: 1, scope: !77, file: !11, line: 39, type: !12)
!83 = !DILocation(line: 0, scope: !77)
!84 = !DILocalVariable(name: "n", arg: 2, scope: !77, file: !11, line: 39, type: !12)
!85 = !DILocalVariable(name: "A", arg: 3, scope: !77, file: !11, line: 40, type: !80)
!86 = !DILocalVariable(name: "x", arg: 4, scope: !77, file: !11, line: 41, type: !81)
!87 = !DILocation(line: 45, column: 8, scope: !77)
!88 = !DILocalVariable(name: "fn", scope: !77, file: !11, line: 44, type: !5)
!89 = !DILocalVariable(name: "i", scope: !77, file: !11, line: 43, type: !12)
!90 = !DILocation(line: 47, column: 8, scope: !91)
!91 = distinct !DILexicalBlock(scope: !77, file: !11, line: 47, column: 3)
!92 = !DILocation(line: 0, scope: !91)
!93 = !DILocation(line: 47, column: 17, scope: !94)
!94 = distinct !DILexicalBlock(scope: !91, file: !11, line: 47, column: 3)
!95 = !DILocation(line: 47, column: 3, scope: !91)
!96 = !DILocation(line: 48, column: 19, scope: !94)
!97 = !DILocation(line: 48, column: 21, scope: !94)
!98 = !DILocation(line: 48, column: 16, scope: !94)
!99 = !DILocation(line: 48, column: 7, scope: !94)
!100 = !DILocation(line: 48, column: 12, scope: !94)
!101 = !DILocation(line: 47, column: 23, scope: !94)
!102 = !DILocation(line: 47, column: 3, scope: !94)
!103 = distinct !{!103, !95, !104, !105}
!104 = !DILocation(line: 48, column: 25, scope: !91)
!105 = !{!"llvm.loop.mustprogress"}
!106 = !DILocation(line: 49, column: 8, scope: !107)
!107 = distinct !DILexicalBlock(scope: !77, file: !11, line: 49, column: 3)
!108 = !DILocation(line: 0, scope: !107)
!109 = !DILocation(line: 49, column: 17, scope: !110)
!110 = distinct !DILexicalBlock(scope: !107, file: !11, line: 49, column: 3)
!111 = !DILocation(line: 49, column: 3, scope: !107)
!112 = !DILocalVariable(name: "j", scope: !77, file: !11, line: 43, type: !12)
!113 = !DILocation(line: 50, column: 10, scope: !114)
!114 = distinct !DILexicalBlock(scope: !110, file: !11, line: 50, column: 5)
!115 = !DILocation(line: 0, scope: !114)
!116 = !DILocation(line: 50, column: 19, scope: !117)
!117 = distinct !DILexicalBlock(scope: !114, file: !11, line: 50, column: 5)
!118 = !DILocation(line: 50, column: 5, scope: !114)
!119 = !DILocation(line: 51, column: 32, scope: !117)
!120 = !DILocation(line: 51, column: 36, scope: !117)
!121 = !DILocation(line: 51, column: 17, scope: !117)
!122 = !DILocation(line: 51, column: 45, scope: !117)
!123 = !DILocation(line: 51, column: 43, scope: !117)
!124 = !DILocation(line: 51, column: 41, scope: !117)
!125 = !DILocation(line: 51, column: 7, scope: !117)
!126 = !DILocation(line: 51, column: 15, scope: !117)
!127 = !DILocation(line: 50, column: 25, scope: !117)
!128 = !DILocation(line: 50, column: 5, scope: !117)
!129 = distinct !{!129, !118, !130, !105}
!130 = !DILocation(line: 51, column: 47, scope: !114)
!131 = !DILocation(line: 49, column: 23, scope: !110)
!132 = !DILocation(line: 49, column: 3, scope: !110)
!133 = distinct !{!133, !111, !134, !105}
!134 = !DILocation(line: 51, column: 47, scope: !107)
!135 = !DILocation(line: 52, column: 1, scope: !77)
!136 = distinct !DISubprogram(name: "task_job_polybench", scope: !11, file: !11, line: 114, type: !18, scopeLine: 114, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !2, retainedNodes: !62)
!137 = !DILocation(line: 115, column: 16, scope: !136)
!138 = !DILocation(line: 115, column: 19, scope: !136)
!139 = !DILocalVariable(name: "m", arg: 1, scope: !140, file: !11, line: 78, type: !12)
!140 = distinct !DISubprogram(name: "kernel_atax", scope: !11, file: !11, line: 78, type: !141, scopeLine: 83, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition, unit: !2, retainedNodes: !62)
!141 = !DISubroutineType(types: !142)
!142 = !{null, !12, !12, !80, !81, !81, !81}
!143 = !DILocation(line: 0, scope: !140, inlinedAt: !144)
!144 = distinct !DILocation(line: 115, column: 3, scope: !136)
!145 = !DILocalVariable(name: "n", arg: 2, scope: !140, file: !11, line: 78, type: !12)
!146 = !DILocalVariable(name: "A", arg: 3, scope: !140, file: !11, line: 79, type: !80)
!147 = !DILocalVariable(name: "x", arg: 4, scope: !140, file: !11, line: 80, type: !81)
!148 = !DILocalVariable(name: "y", arg: 5, scope: !140, file: !11, line: 81, type: !81)
!149 = !DILocalVariable(name: "tmp", arg: 6, scope: !140, file: !11, line: 82, type: !81)
!150 = !DILocalVariable(name: "i", scope: !140, file: !11, line: 84, type: !12)
!151 = !DILocation(line: 87, column: 8, scope: !152, inlinedAt: !144)
!152 = distinct !DILexicalBlock(scope: !140, file: !11, line: 87, column: 3)
!153 = !DILocation(line: 0, scope: !152, inlinedAt: !144)
!154 = !DILocation(line: 87, column: 17, scope: !155, inlinedAt: !144)
!155 = distinct !DILexicalBlock(scope: !152, file: !11, line: 87, column: 3)
!156 = !DILocation(line: 87, column: 3, scope: !152, inlinedAt: !144)
!157 = !DILocation(line: 88, column: 5, scope: !155, inlinedAt: !144)
!158 = !DILocation(line: 88, column: 10, scope: !155, inlinedAt: !144)
!159 = !DILocation(line: 87, column: 27, scope: !155, inlinedAt: !144)
!160 = !DILocation(line: 87, column: 3, scope: !155, inlinedAt: !144)
!161 = distinct !{!161, !156, !162, !105}
!162 = !DILocation(line: 88, column: 12, scope: !152, inlinedAt: !144)
!163 = !DILocation(line: 89, column: 8, scope: !164, inlinedAt: !144)
!164 = distinct !DILexicalBlock(scope: !140, file: !11, line: 89, column: 3)
!165 = !DILocation(line: 0, scope: !164, inlinedAt: !144)
!166 = !DILocation(line: 89, column: 17, scope: !167, inlinedAt: !144)
!167 = distinct !DILexicalBlock(scope: !164, file: !11, line: 89, column: 3)
!168 = !DILocation(line: 89, column: 3, scope: !164, inlinedAt: !144)
!169 = !DILocation(line: 91, column: 7, scope: !170, inlinedAt: !144)
!170 = distinct !DILexicalBlock(scope: !167, file: !11, line: 90, column: 5)
!171 = !DILocation(line: 91, column: 14, scope: !170, inlinedAt: !144)
!172 = !DILocalVariable(name: "j", scope: !140, file: !11, line: 84, type: !12)
!173 = !DILocation(line: 92, column: 12, scope: !174, inlinedAt: !144)
!174 = distinct !DILexicalBlock(scope: !170, file: !11, line: 92, column: 7)
!175 = !DILocation(line: 0, scope: !174, inlinedAt: !144)
!176 = !DILocation(line: 92, column: 21, scope: !177, inlinedAt: !144)
!177 = distinct !DILexicalBlock(scope: !174, file: !11, line: 92, column: 7)
!178 = !DILocation(line: 92, column: 7, scope: !174, inlinedAt: !144)
!179 = !DILocation(line: 93, column: 11, scope: !177, inlinedAt: !144)
!180 = !DILocation(line: 93, column: 20, scope: !177, inlinedAt: !144)
!181 = !DILocation(line: 93, column: 30, scope: !177, inlinedAt: !144)
!182 = !DILocation(line: 93, column: 28, scope: !177, inlinedAt: !144)
!183 = !DILocation(line: 93, column: 18, scope: !177, inlinedAt: !144)
!184 = !DILocation(line: 93, column: 2, scope: !177, inlinedAt: !144)
!185 = !DILocation(line: 93, column: 9, scope: !177, inlinedAt: !144)
!186 = !DILocation(line: 92, column: 31, scope: !177, inlinedAt: !144)
!187 = !DILocation(line: 92, column: 7, scope: !177, inlinedAt: !144)
!188 = distinct !{!188, !178, !189, !105}
!189 = !DILocation(line: 93, column: 33, scope: !174, inlinedAt: !144)
!190 = !DILocation(line: 94, column: 12, scope: !191, inlinedAt: !144)
!191 = distinct !DILexicalBlock(scope: !170, file: !11, line: 94, column: 7)
!192 = !DILocation(line: 0, scope: !191, inlinedAt: !144)
!193 = !DILocation(line: 94, column: 21, scope: !194, inlinedAt: !144)
!194 = distinct !DILexicalBlock(scope: !191, file: !11, line: 94, column: 7)
!195 = !DILocation(line: 94, column: 7, scope: !191, inlinedAt: !144)
!196 = !DILocation(line: 95, column: 9, scope: !194, inlinedAt: !144)
!197 = !DILocation(line: 95, column: 16, scope: !194, inlinedAt: !144)
!198 = !DILocation(line: 95, column: 26, scope: !194, inlinedAt: !144)
!199 = !DILocation(line: 95, column: 24, scope: !194, inlinedAt: !144)
!200 = !DILocation(line: 95, column: 14, scope: !194, inlinedAt: !144)
!201 = !DILocation(line: 95, column: 2, scope: !194, inlinedAt: !144)
!202 = !DILocation(line: 95, column: 7, scope: !194, inlinedAt: !144)
!203 = !DILocation(line: 94, column: 31, scope: !194, inlinedAt: !144)
!204 = !DILocation(line: 94, column: 7, scope: !194, inlinedAt: !144)
!205 = distinct !{!205, !195, !206, !105}
!206 = !DILocation(line: 95, column: 31, scope: !191, inlinedAt: !144)
!207 = !DILocation(line: 89, column: 27, scope: !167, inlinedAt: !144)
!208 = !DILocation(line: 89, column: 3, scope: !167, inlinedAt: !144)
!209 = distinct !{!209, !168, !210, !105}
!210 = !DILocation(line: 96, column: 5, scope: !164, inlinedAt: !144)
!211 = !DILocation(line: 120, column: 3, scope: !136)
!212 = distinct !DISubprogram(name: "workload_checksum", scope: !11, file: !11, line: 122, type: !213, scopeLine: 122, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !2, retainedNodes: !62)
!213 = !DISubroutineType(types: !214)
!214 = !{!20, !6}
!215 = !DILocalVariable(name: "task", arg: 1, scope: !212, file: !11, line: 122, type: !6)
!216 = !DILocation(line: 0, scope: !212)
!217 = !DILocation(line: 124, column: 11, scope: !212)
!218 = !DILocation(line: 125, column: 15, scope: !212)
!219 = !DILocation(line: 125, column: 3, scope: !212)
!220 = !DILocation(line: 126, column: 10, scope: !212)
!221 = !DILocation(line: 126, column: 3, scope: !212)
!222 = distinct !DISubprogram(name: "print_array", scope: !11, file: !11, line: 58, type: !223, scopeLine: 61, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition, unit: !2, retainedNodes: !62)
!223 = !DISubroutineType(types: !224)
!224 = !{null, !12, !81}
!225 = !DILocalVariable(name: "n", arg: 1, scope: !222, file: !11, line: 58, type: !12)
!226 = !DILocation(line: 0, scope: !222)
!227 = !DILocalVariable(name: "y", arg: 2, scope: !222, file: !11, line: 59, type: !81)
!228 = !DILocation(line: 64, column: 3, scope: !222)
!229 = !DILocation(line: 65, column: 3, scope: !222)
!230 = !DILocalVariable(name: "i", scope: !222, file: !11, line: 62, type: !12)
!231 = !DILocation(line: 66, column: 8, scope: !232)
!232 = distinct !DILexicalBlock(scope: !222, file: !11, line: 66, column: 3)
!233 = !DILocation(line: 0, scope: !232)
!234 = !DILocation(line: 66, column: 17, scope: !235)
!235 = distinct !DILexicalBlock(scope: !232, file: !11, line: 66, column: 3)
!236 = !DILocation(line: 66, column: 3, scope: !232)
!237 = !DILocation(line: 67, column: 11, scope: !238)
!238 = distinct !DILexicalBlock(scope: !239, file: !11, line: 67, column: 9)
!239 = distinct !DILexicalBlock(scope: !235, file: !11, line: 66, column: 27)
!240 = !DILocation(line: 67, column: 16, scope: !238)
!241 = !DILocation(line: 67, column: 9, scope: !239)
!242 = !DILocation(line: 67, column: 31, scope: !238)
!243 = !DILocation(line: 67, column: 22, scope: !238)
!244 = !DILocation(line: 68, column: 14, scope: !239)
!245 = !DILocation(line: 68, column: 59, scope: !239)
!246 = !DILocation(line: 68, column: 5, scope: !239)
!247 = !DILocation(line: 69, column: 3, scope: !239)
!248 = !DILocation(line: 66, column: 23, scope: !235)
!249 = !DILocation(line: 66, column: 3, scope: !235)
!250 = distinct !{!250, !236, !251, !105}
!251 = !DILocation(line: 69, column: 3, scope: !232)
!252 = !DILocation(line: 70, column: 3, scope: !222)
!253 = !DILocation(line: 71, column: 3, scope: !222)
!254 = !DILocation(line: 72, column: 1, scope: !222)
!255 = distinct !DISubprogram(name: "pb_fprintf", scope: !32, file: !32, line: 13, type: !256, scopeLine: 14, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition, unit: !2, retainedNodes: !62)
!256 = !DISubroutineType(types: !257)
!257 = !{!12, !258, !317, null}
!258 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !259, size: 64)
!259 = !DIDerivedType(tag: DW_TAG_typedef, name: "FILE", file: !260, line: 7, baseType: !261)
!260 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/types/FILE.h", directory: "", checksumkind: CSK_MD5, checksum: "571f9fb6223c42439075fdde11a0de5d")
!261 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "_IO_FILE", file: !262, line: 49, size: 1728, elements: !263)
!262 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/types/struct_FILE.h", directory: "", checksumkind: CSK_MD5, checksum: "1bad07471b7974df4ecc1d1c2ca207e6")
!263 = !{!264, !265, !268, !269, !270, !271, !272, !273, !274, !275, !276, !277, !278, !281, !283, !284, !285, !288, !290, !292, !294, !297, !299, !302, !305, !306, !308, !312, !313}
!264 = !DIDerivedType(tag: DW_TAG_member, name: "_flags", scope: !261, file: !262, line: 51, baseType: !12, size: 32)
!265 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_read_ptr", scope: !261, file: !262, line: 54, baseType: !266, size: 64, offset: 64)
!266 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !267, size: 64)
!267 = !DIBasicType(name: "char", size: 8, encoding: DW_ATE_signed_char)
!268 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_read_end", scope: !261, file: !262, line: 55, baseType: !266, size: 64, offset: 128)
!269 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_read_base", scope: !261, file: !262, line: 56, baseType: !266, size: 64, offset: 192)
!270 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_write_base", scope: !261, file: !262, line: 57, baseType: !266, size: 64, offset: 256)
!271 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_write_ptr", scope: !261, file: !262, line: 58, baseType: !266, size: 64, offset: 320)
!272 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_write_end", scope: !261, file: !262, line: 59, baseType: !266, size: 64, offset: 384)
!273 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_buf_base", scope: !261, file: !262, line: 60, baseType: !266, size: 64, offset: 448)
!274 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_buf_end", scope: !261, file: !262, line: 61, baseType: !266, size: 64, offset: 512)
!275 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_save_base", scope: !261, file: !262, line: 64, baseType: !266, size: 64, offset: 576)
!276 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_backup_base", scope: !261, file: !262, line: 65, baseType: !266, size: 64, offset: 640)
!277 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_save_end", scope: !261, file: !262, line: 66, baseType: !266, size: 64, offset: 704)
!278 = !DIDerivedType(tag: DW_TAG_member, name: "_markers", scope: !261, file: !262, line: 68, baseType: !279, size: 64, offset: 768)
!279 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !280, size: 64)
!280 = !DICompositeType(tag: DW_TAG_structure_type, name: "_IO_marker", file: !262, line: 36, flags: DIFlagFwdDecl)
!281 = !DIDerivedType(tag: DW_TAG_member, name: "_chain", scope: !261, file: !262, line: 70, baseType: !282, size: 64, offset: 832)
!282 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !261, size: 64)
!283 = !DIDerivedType(tag: DW_TAG_member, name: "_fileno", scope: !261, file: !262, line: 72, baseType: !12, size: 32, offset: 896)
!284 = !DIDerivedType(tag: DW_TAG_member, name: "_flags2", scope: !261, file: !262, line: 73, baseType: !12, size: 32, offset: 928)
!285 = !DIDerivedType(tag: DW_TAG_member, name: "_old_offset", scope: !261, file: !262, line: 74, baseType: !286, size: 64, offset: 960)
!286 = !DIDerivedType(tag: DW_TAG_typedef, name: "__off_t", file: !23, line: 152, baseType: !287)
!287 = !DIBasicType(name: "long", size: 64, encoding: DW_ATE_signed)
!288 = !DIDerivedType(tag: DW_TAG_member, name: "_cur_column", scope: !261, file: !262, line: 77, baseType: !289, size: 16, offset: 1024)
!289 = !DIBasicType(name: "unsigned short", size: 16, encoding: DW_ATE_unsigned)
!290 = !DIDerivedType(tag: DW_TAG_member, name: "_vtable_offset", scope: !261, file: !262, line: 78, baseType: !291, size: 8, offset: 1040)
!291 = !DIBasicType(name: "signed char", size: 8, encoding: DW_ATE_signed_char)
!292 = !DIDerivedType(tag: DW_TAG_member, name: "_shortbuf", scope: !261, file: !262, line: 79, baseType: !293, size: 8, offset: 1048)
!293 = !DICompositeType(tag: DW_TAG_array_type, baseType: !267, size: 8, elements: !24)
!294 = !DIDerivedType(tag: DW_TAG_member, name: "_lock", scope: !261, file: !262, line: 81, baseType: !295, size: 64, offset: 1088)
!295 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !296, size: 64)
!296 = !DIDerivedType(tag: DW_TAG_typedef, name: "_IO_lock_t", file: !262, line: 43, baseType: null)
!297 = !DIDerivedType(tag: DW_TAG_member, name: "_offset", scope: !261, file: !262, line: 89, baseType: !298, size: 64, offset: 1152)
!298 = !DIDerivedType(tag: DW_TAG_typedef, name: "__off64_t", file: !23, line: 153, baseType: !287)
!299 = !DIDerivedType(tag: DW_TAG_member, name: "_codecvt", scope: !261, file: !262, line: 91, baseType: !300, size: 64, offset: 1216)
!300 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !301, size: 64)
!301 = !DICompositeType(tag: DW_TAG_structure_type, name: "_IO_codecvt", file: !262, line: 37, flags: DIFlagFwdDecl)
!302 = !DIDerivedType(tag: DW_TAG_member, name: "_wide_data", scope: !261, file: !262, line: 92, baseType: !303, size: 64, offset: 1280)
!303 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !304, size: 64)
!304 = !DICompositeType(tag: DW_TAG_structure_type, name: "_IO_wide_data", file: !262, line: 38, flags: DIFlagFwdDecl)
!305 = !DIDerivedType(tag: DW_TAG_member, name: "_freeres_list", scope: !261, file: !262, line: 93, baseType: !282, size: 64, offset: 1344)
!306 = !DIDerivedType(tag: DW_TAG_member, name: "_freeres_buf", scope: !261, file: !262, line: 94, baseType: !307, size: 64, offset: 1408)
!307 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: null, size: 64)
!308 = !DIDerivedType(tag: DW_TAG_member, name: "__pad5", scope: !261, file: !262, line: 95, baseType: !309, size: 64, offset: 1472)
!309 = !DIDerivedType(tag: DW_TAG_typedef, name: "size_t", file: !310, line: 46, baseType: !311)
!310 = !DIFile(filename: "/usr/lib/llvm-14/lib/clang/14.0.0/include/stddef.h", directory: "", checksumkind: CSK_MD5, checksum: "2499dd2361b915724b073282bea3a7bc")
!311 = !DIBasicType(name: "unsigned long", size: 64, encoding: DW_ATE_unsigned)
!312 = !DIDerivedType(tag: DW_TAG_member, name: "_mode", scope: !261, file: !262, line: 96, baseType: !12, size: 32, offset: 1536)
!313 = !DIDerivedType(tag: DW_TAG_member, name: "_unused2", scope: !261, file: !262, line: 98, baseType: !314, size: 160, offset: 1568)
!314 = !DICompositeType(tag: DW_TAG_array_type, baseType: !267, size: 160, elements: !315)
!315 = !{!316}
!316 = !DISubrange(count: 20)
!317 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !318, size: 64)
!318 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !267)
!319 = !DILocalVariable(name: "stream", arg: 1, scope: !255, file: !32, line: 13, type: !258)
!320 = !DILocation(line: 0, scope: !255)
!321 = !DILocalVariable(name: "format", arg: 2, scope: !255, file: !32, line: 13, type: !317)
!322 = !DILocalVariable(name: "buffer", scope: !255, file: !32, line: 15, type: !323)
!323 = !DICompositeType(tag: DW_TAG_array_type, baseType: !267, size: 6144, elements: !324)
!324 = !{!325}
!325 = !DISubrange(count: 768)
!326 = !DILocation(line: 15, column: 10, scope: !255)
!327 = !DILocalVariable(name: "args", scope: !255, file: !32, line: 16, type: !328)
!328 = !DIDerivedType(tag: DW_TAG_typedef, name: "va_list", file: !329, line: 52, baseType: !330)
!329 = !DIFile(filename: "/usr/include/stdio.h", directory: "", checksumkind: CSK_MD5, checksum: "f31eefcc3f15835fc5a4023a625cf609")
!330 = !DIDerivedType(tag: DW_TAG_typedef, name: "__gnuc_va_list", file: !331, line: 32, baseType: !332)
!331 = !DIFile(filename: "/usr/lib/llvm-14/lib/clang/14.0.0/include/stdarg.h", directory: "", checksumkind: CSK_MD5, checksum: "4de3cbd931b589d291e5c39387aecf82")
!332 = !DIDerivedType(tag: DW_TAG_typedef, name: "__builtin_va_list", file: !333, baseType: !334)
!333 = !DIFile(filename: "source/workload.c", directory: "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/affine-bounds-20260929/suite/atax")
!334 = !DICompositeType(tag: DW_TAG_array_type, baseType: !335, size: 192, elements: !24)
!335 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "__va_list_tag", size: 192, elements: !336)
!336 = !{!337, !338, !339, !340}
!337 = !DIDerivedType(tag: DW_TAG_member, name: "gp_offset", scope: !335, file: !333, line: 16, baseType: !6, size: 32)
!338 = !DIDerivedType(tag: DW_TAG_member, name: "fp_offset", scope: !335, file: !333, line: 16, baseType: !6, size: 32, offset: 32)
!339 = !DIDerivedType(tag: DW_TAG_member, name: "overflow_arg_area", scope: !335, file: !333, line: 16, baseType: !307, size: 64, offset: 64)
!340 = !DIDerivedType(tag: DW_TAG_member, name: "reg_save_area", scope: !335, file: !333, line: 16, baseType: !307, size: 64, offset: 128)
!341 = !DILocation(line: 16, column: 13, scope: !255)
!342 = !DILocation(line: 17, column: 5, scope: !255)
!343 = !DILocation(line: 18, column: 27, scope: !255)
!344 = !DILocation(line: 18, column: 59, scope: !255)
!345 = !DILocation(line: 18, column: 17, scope: !255)
!346 = !DILocalVariable(name: "count", scope: !255, file: !32, line: 18, type: !12)
!347 = !DILocation(line: 19, column: 5, scope: !255)
!348 = !DILocation(line: 20, column: 15, scope: !349)
!349 = distinct !DILexicalBlock(scope: !255, file: !32, line: 20, column: 9)
!350 = !DILocation(line: 20, column: 19, scope: !349)
!351 = !DILocation(line: 20, column: 22, scope: !349)
!352 = !DILocation(line: 20, column: 38, scope: !349)
!353 = !DILocation(line: 20, column: 9, scope: !255)
!354 = !DILocation(line: 20, column: 57, scope: !349)
!355 = !DILocalVariable(name: "i", scope: !356, file: !32, line: 21, type: !12)
!356 = distinct !DILexicalBlock(scope: !255, file: !32, line: 21, column: 5)
!357 = !DILocation(line: 0, scope: !356)
!358 = !DILocation(line: 21, column: 10, scope: !356)
!359 = !DILocation(line: 21, column: 23, scope: !360)
!360 = distinct !DILexicalBlock(scope: !356, file: !32, line: 21, column: 5)
!361 = !DILocation(line: 21, column: 5, scope: !356)
!362 = !DILocation(line: 22, column: 35, scope: !363)
!363 = distinct !DILexicalBlock(scope: !360, file: !32, line: 21, column: 37)
!364 = !DILocation(line: 22, column: 20, scope: !363)
!365 = !DILocation(line: 22, column: 17, scope: !363)
!366 = !DILocation(line: 23, column: 17, scope: !363)
!367 = !DILocation(line: 24, column: 5, scope: !363)
!368 = !DILocation(line: 21, column: 32, scope: !360)
!369 = !DILocation(line: 21, column: 5, scope: !360)
!370 = distinct !{!370, !361, !371, !105}
!371 = !DILocation(line: 24, column: 5, scope: !356)
!372 = !DILocation(line: 29, column: 11, scope: !255)
!373 = !DILocation(line: 31, column: 5, scope: !255)
