; ModuleID = 'workload.ll'
source_filename = "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/affine-bounds-20260929/suite/jacobi-2d/source/workload.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

%struct._IO_FILE = type { i32, i8*, i8*, i8*, i8*, i8*, i8*, i8*, i8*, i8*, i8*, i8*, %struct._IO_marker*, %struct._IO_FILE*, i32, i32, i64, i16, i8, [1 x i8], i8*, i64, %struct._IO_codecvt*, %struct._IO_wide_data*, %struct._IO_FILE*, i8*, i64, i32, [20 x i8] }
%struct._IO_marker = type opaque
%struct._IO_codecvt = type opaque
%struct._IO_wide_data = type opaque
%struct.__va_list_tag = type { i32, i32, i8*, i8* }

@n = dso_local global i32 250, align 4, !dbg !0
@tsteps = dso_local global i32 100, align 4, !dbg !9
@A = dso_local global [250 x [250 x double]] zeroinitializer, section ".chaser_data.A", align 64, !dbg !33
@B = dso_local global [250 x [250 x double]] zeroinitializer, section ".chaser_data.B", align 64, !dbg !38
@.str = private unnamed_addr constant [12 x i8] c"ape.analyze\00", section "llvm.metadata"
@.str.1 = private unnamed_addr constant [127 x i8] c"/workspace/experiments-array-support/chaser/.cache/periodic-polybench/affine-bounds-20260929/suite/jacobi-2d/source/workload.c\00", section "llvm.metadata"
@pb_hash = internal global i32 0, align 4, !dbg !30
@workload_jobs = dso_local constant [1 x i32 ()*] [i32 ()* @task_job_polybench], align 8, !dbg !13
@workload_expected = dso_local constant [1 x i32] [i32 -1612902674], align 4, !dbg !26
@stderr = external global %struct._IO_FILE*, align 8
@.str.2 = private unnamed_addr constant [23 x i8] c"==BEGIN DUMP_ARRAYS==\0A\00", align 1
@.str.3 = private unnamed_addr constant [15 x i8] c"begin dump: %s\00", align 1
@.str.4 = private unnamed_addr constant [2 x i8] c"A\00", align 1
@.str.5 = private unnamed_addr constant [2 x i8] c"\0A\00", align 1
@.str.6 = private unnamed_addr constant [8 x i8] c"%0.2lf \00", align 1
@.str.7 = private unnamed_addr constant [17 x i8] c"\0Aend   dump: %s\0A\00", align 1
@.str.8 = private unnamed_addr constant [23 x i8] c"==END   DUMP_ARRAYS==\0A\00", align 1
@pb_emit = internal global i32 1, align 4, !dbg !40
@llvm.global.annotations = appending global [1 x { i8*, i8*, i8*, i32, i8* }] [{ i8*, i8*, i8*, i32, i8* } { i8* bitcast (i32 ()* @task_job_polybench to i8*), i8* getelementptr inbounds ([12 x i8], [12 x i8]* @.str, i32 0, i32 0), i8* getelementptr inbounds ([127 x i8], [127 x i8]* @.str.1, i32 0, i32 0), i32 108, i8* null }], section "llvm.metadata"

; Function Attrs: noinline nounwind uwtable
define dso_local void @workload_prepare() #0 !dbg !50 {
  ret void, !dbg !54
}

; Function Attrs: noinline nounwind uwtable
define dso_local void @workload_reset(i32 noundef %0) #0 !dbg !55 {
  call void @llvm.dbg.value(metadata i32 %0, metadata !58, metadata !DIExpression()), !dbg !59
  call void @llvm.memset.p0i8.i64(i8* align 64 bitcast ([250 x [250 x double]]* @A to i8*), i8 0, i64 500000, i1 false), !dbg !60
  call void @llvm.memset.p0i8.i64(i8* align 64 bitcast ([250 x [250 x double]]* @B to i8*), i8 0, i64 500000, i1 false), !dbg !61
  %2 = load i32, i32* @n, align 4, !dbg !62
  call void @init_array(i32 noundef %2, [250 x double]* noundef getelementptr inbounds ([250 x [250 x double]], [250 x [250 x double]]* @A, i64 0, i64 0), [250 x double]* noundef getelementptr inbounds ([250 x [250 x double]], [250 x [250 x double]]* @B, i64 0, i64 0)), !dbg !63
  ret void, !dbg !64
}

; Function Attrs: nofree nosync nounwind readnone speculatable willreturn
declare void @llvm.dbg.declare(metadata, metadata, metadata) #1

; Function Attrs: argmemonly nofree nounwind willreturn writeonly
declare void @llvm.memset.p0i8.i64(i8* nocapture writeonly, i8, i64, i1 immarg) #2

; Function Attrs: noinline nounwind uwtable
define internal void @init_array(i32 noundef %0, [250 x double]* noundef %1, [250 x double]* noundef %2) #0 !dbg !65 {
  call void @llvm.dbg.value(metadata i32 %0, metadata !71, metadata !DIExpression()), !dbg !72
  call void @llvm.dbg.value(metadata [250 x double]* %1, metadata !73, metadata !DIExpression()), !dbg !72
  call void @llvm.dbg.value(metadata [250 x double]* %2, metadata !74, metadata !DIExpression()), !dbg !72
  call void @llvm.dbg.value(metadata i32 0, metadata !75, metadata !DIExpression()), !dbg !72
  br label %4, !dbg !76

4:                                                ; preds = %35, %3
  %.01 = phi i32 [ 0, %3 ], [ %36, %35 ], !dbg !78
  call void @llvm.dbg.value(metadata i32 %.01, metadata !75, metadata !DIExpression()), !dbg !72
  %5 = icmp slt i32 %.01, %0, !dbg !79
  br i1 %5, label %6, label %37, !dbg !81

6:                                                ; preds = %4
  call void @llvm.dbg.value(metadata i32 0, metadata !82, metadata !DIExpression()), !dbg !72
  br label %7, !dbg !83

7:                                                ; preds = %32, %6
  %.0 = phi i32 [ 0, %6 ], [ %33, %32 ], !dbg !85
  call void @llvm.dbg.value(metadata i32 %.0, metadata !82, metadata !DIExpression()), !dbg !72
  %8 = icmp slt i32 %.0, %0, !dbg !86
  br i1 %8, label %9, label %34, !dbg !88

9:                                                ; preds = %7
  %10 = sitofp i32 %.01 to double, !dbg !89
  %11 = add nsw i32 %.0, 2, !dbg !91
  %12 = sitofp i32 %11 to double, !dbg !92
  %13 = fmul double %10, %12, !dbg !93
  %14 = fadd double %13, 2.000000e+00, !dbg !94
  %15 = sitofp i32 %0 to double, !dbg !95
  %16 = fdiv double %14, %15, !dbg !96
  %17 = sext i32 %.01 to i64, !dbg !97
  %18 = getelementptr inbounds [250 x double], [250 x double]* %1, i64 %17, !dbg !97
  %19 = sext i32 %.0 to i64, !dbg !97
  %20 = getelementptr inbounds [250 x double], [250 x double]* %18, i64 0, i64 %19, !dbg !97
  store double %16, double* %20, align 8, !dbg !98
  %21 = sitofp i32 %.01 to double, !dbg !99
  %22 = add nsw i32 %.0, 3, !dbg !100
  %23 = sitofp i32 %22 to double, !dbg !101
  %24 = fmul double %21, %23, !dbg !102
  %25 = fadd double %24, 3.000000e+00, !dbg !103
  %26 = sitofp i32 %0 to double, !dbg !104
  %27 = fdiv double %25, %26, !dbg !105
  %28 = sext i32 %.01 to i64, !dbg !106
  %29 = getelementptr inbounds [250 x double], [250 x double]* %2, i64 %28, !dbg !106
  %30 = sext i32 %.0 to i64, !dbg !106
  %31 = getelementptr inbounds [250 x double], [250 x double]* %29, i64 0, i64 %30, !dbg !106
  store double %27, double* %31, align 8, !dbg !107
  br label %32, !dbg !108

32:                                               ; preds = %9
  %33 = add nsw i32 %.0, 1, !dbg !109
  call void @llvm.dbg.value(metadata i32 %33, metadata !82, metadata !DIExpression()), !dbg !72
  br label %7, !dbg !110, !llvm.loop !111

34:                                               ; preds = %7
  br label %35, !dbg !112

35:                                               ; preds = %34
  %36 = add nsw i32 %.01, 1, !dbg !114
  call void @llvm.dbg.value(metadata i32 %36, metadata !75, metadata !DIExpression()), !dbg !72
  br label %4, !dbg !115, !llvm.loop !116

37:                                               ; preds = %4
  ret void, !dbg !118
}

; Function Attrs: noinline nounwind uwtable
define dso_local i32 @task_job_polybench() #0 !dbg !119 {
  %1 = load i32, i32* @tsteps, align 4, !dbg !120
  %2 = load i32, i32* @n, align 4, !dbg !121
  call void @llvm.dbg.value(metadata i32 %1, metadata !122, metadata !DIExpression()), !dbg !126
  call void @llvm.dbg.value(metadata i32 %2, metadata !128, metadata !DIExpression()), !dbg !126
  call void @llvm.dbg.value(metadata [250 x double]* getelementptr inbounds ([250 x [250 x double]], [250 x [250 x double]]* @A, i64 0, i64 0), metadata !129, metadata !DIExpression()), !dbg !126
  call void @llvm.dbg.value(metadata [250 x double]* getelementptr inbounds ([250 x [250 x double]], [250 x [250 x double]]* @B, i64 0, i64 0), metadata !130, metadata !DIExpression()), !dbg !126
  call void @llvm.dbg.value(metadata i32 0, metadata !131, metadata !DIExpression()), !dbg !126
  br label %3, !dbg !132

3:                                                ; preds = %101, %0
  %.03 = phi i32 [ 0, %0 ], [ %102, %101 ], !dbg !134
  call void @llvm.dbg.value(metadata i32 %.03, metadata !131, metadata !DIExpression()), !dbg !126
  %4 = icmp slt i32 %.03, 100, !dbg !135
  br i1 %4, label %5, label %103, !dbg !137

5:                                                ; preds = %3
  call void @llvm.dbg.value(metadata i32 1, metadata !138, metadata !DIExpression()), !dbg !126
  br label %6, !dbg !139

6:                                                ; preds = %51, %5
  %.01 = phi i32 [ 1, %5 ], [ %52, %51 ], !dbg !142
  call void @llvm.dbg.value(metadata i32 %.01, metadata !138, metadata !DIExpression()), !dbg !126
  %7 = icmp slt i32 %.01, 249, !dbg !143
  br i1 %7, label %8, label %53, !dbg !145

8:                                                ; preds = %6
  call void @llvm.dbg.value(metadata i32 1, metadata !146, metadata !DIExpression()), !dbg !126
  br label %9, !dbg !147

9:                                                ; preds = %11, %8
  %.0 = phi i32 [ 1, %8 ], [ %50, %11 ], !dbg !149
  call void @llvm.dbg.value(metadata i32 %.0, metadata !146, metadata !DIExpression()), !dbg !126
  %10 = icmp slt i32 %.0, 249, !dbg !150
  br i1 %10, label %11, label %51, !dbg !152

11:                                               ; preds = %9
  %12 = sext i32 %.01 to i64, !dbg !153
  %13 = getelementptr inbounds [250 x double], [250 x double]* getelementptr inbounds ([250 x [250 x double]], [250 x [250 x double]]* @A, i64 0, i64 0), i64 %12, !dbg !153
  %14 = sext i32 %.0 to i64, !dbg !153
  %15 = getelementptr inbounds [250 x double], [250 x double]* %13, i64 0, i64 %14, !dbg !153
  %16 = load double, double* %15, align 8, !dbg !153
  %17 = sext i32 %.01 to i64, !dbg !154
  %18 = getelementptr inbounds [250 x double], [250 x double]* getelementptr inbounds ([250 x [250 x double]], [250 x [250 x double]]* @A, i64 0, i64 0), i64 %17, !dbg !154
  %19 = sub nsw i32 %.0, 1, !dbg !155
  %20 = sext i32 %19 to i64, !dbg !154
  %21 = getelementptr inbounds [250 x double], [250 x double]* %18, i64 0, i64 %20, !dbg !154
  %22 = load double, double* %21, align 8, !dbg !154
  %23 = fadd double %16, %22, !dbg !156
  %24 = sext i32 %.01 to i64, !dbg !157
  %25 = getelementptr inbounds [250 x double], [250 x double]* getelementptr inbounds ([250 x [250 x double]], [250 x [250 x double]]* @A, i64 0, i64 0), i64 %24, !dbg !157
  %26 = add nsw i32 1, %.0, !dbg !158
  %27 = sext i32 %26 to i64, !dbg !157
  %28 = getelementptr inbounds [250 x double], [250 x double]* %25, i64 0, i64 %27, !dbg !157
  %29 = load double, double* %28, align 8, !dbg !157
  %30 = fadd double %23, %29, !dbg !159
  %31 = add nsw i32 1, %.01, !dbg !160
  %32 = sext i32 %31 to i64, !dbg !161
  %33 = getelementptr inbounds [250 x double], [250 x double]* getelementptr inbounds ([250 x [250 x double]], [250 x [250 x double]]* @A, i64 0, i64 0), i64 %32, !dbg !161
  %34 = sext i32 %.0 to i64, !dbg !161
  %35 = getelementptr inbounds [250 x double], [250 x double]* %33, i64 0, i64 %34, !dbg !161
  %36 = load double, double* %35, align 8, !dbg !161
  %37 = fadd double %30, %36, !dbg !162
  %38 = sub nsw i32 %.01, 1, !dbg !163
  %39 = sext i32 %38 to i64, !dbg !164
  %40 = getelementptr inbounds [250 x double], [250 x double]* getelementptr inbounds ([250 x [250 x double]], [250 x [250 x double]]* @A, i64 0, i64 0), i64 %39, !dbg !164
  %41 = sext i32 %.0 to i64, !dbg !164
  %42 = getelementptr inbounds [250 x double], [250 x double]* %40, i64 0, i64 %41, !dbg !164
  %43 = load double, double* %42, align 8, !dbg !164
  %44 = fadd double %37, %43, !dbg !165
  %45 = fmul double 2.000000e-01, %44, !dbg !166
  %46 = sext i32 %.01 to i64, !dbg !167
  %47 = getelementptr inbounds [250 x double], [250 x double]* getelementptr inbounds ([250 x [250 x double]], [250 x [250 x double]]* @B, i64 0, i64 0), i64 %46, !dbg !167
  %48 = sext i32 %.0 to i64, !dbg !167
  %49 = getelementptr inbounds [250 x double], [250 x double]* %47, i64 0, i64 %48, !dbg !167
  store double %45, double* %49, align 8, !dbg !168
  %50 = add nsw i32 %.0, 1, !dbg !169
  call void @llvm.dbg.value(metadata i32 %50, metadata !146, metadata !DIExpression()), !dbg !126
  br label %9, !dbg !170, !llvm.loop !171

51:                                               ; preds = %9
  %52 = add nsw i32 %.01, 1, !dbg !173
  call void @llvm.dbg.value(metadata i32 %52, metadata !138, metadata !DIExpression()), !dbg !126
  br label %6, !dbg !174, !llvm.loop !175

53:                                               ; preds = %6
  call void @llvm.dbg.value(metadata i32 1, metadata !138, metadata !DIExpression()), !dbg !126
  br label %54, !dbg !177

54:                                               ; preds = %99, %53
  %.12 = phi i32 [ 1, %53 ], [ %100, %99 ], !dbg !179
  call void @llvm.dbg.value(metadata i32 %.12, metadata !138, metadata !DIExpression()), !dbg !126
  %55 = icmp slt i32 %.12, 249, !dbg !180
  br i1 %55, label %56, label %101, !dbg !182

56:                                               ; preds = %54
  call void @llvm.dbg.value(metadata i32 1, metadata !146, metadata !DIExpression()), !dbg !126
  br label %57, !dbg !183

57:                                               ; preds = %59, %56
  %.1 = phi i32 [ 1, %56 ], [ %98, %59 ], !dbg !185
  call void @llvm.dbg.value(metadata i32 %.1, metadata !146, metadata !DIExpression()), !dbg !126
  %58 = icmp slt i32 %.1, 249, !dbg !186
  br i1 %58, label %59, label %99, !dbg !188

59:                                               ; preds = %57
  %60 = sext i32 %.12 to i64, !dbg !189
  %61 = getelementptr inbounds [250 x double], [250 x double]* getelementptr inbounds ([250 x [250 x double]], [250 x [250 x double]]* @B, i64 0, i64 0), i64 %60, !dbg !189
  %62 = sext i32 %.1 to i64, !dbg !189
  %63 = getelementptr inbounds [250 x double], [250 x double]* %61, i64 0, i64 %62, !dbg !189
  %64 = load double, double* %63, align 8, !dbg !189
  %65 = sext i32 %.12 to i64, !dbg !190
  %66 = getelementptr inbounds [250 x double], [250 x double]* getelementptr inbounds ([250 x [250 x double]], [250 x [250 x double]]* @B, i64 0, i64 0), i64 %65, !dbg !190
  %67 = sub nsw i32 %.1, 1, !dbg !191
  %68 = sext i32 %67 to i64, !dbg !190
  %69 = getelementptr inbounds [250 x double], [250 x double]* %66, i64 0, i64 %68, !dbg !190
  %70 = load double, double* %69, align 8, !dbg !190
  %71 = fadd double %64, %70, !dbg !192
  %72 = sext i32 %.12 to i64, !dbg !193
  %73 = getelementptr inbounds [250 x double], [250 x double]* getelementptr inbounds ([250 x [250 x double]], [250 x [250 x double]]* @B, i64 0, i64 0), i64 %72, !dbg !193
  %74 = add nsw i32 1, %.1, !dbg !194
  %75 = sext i32 %74 to i64, !dbg !193
  %76 = getelementptr inbounds [250 x double], [250 x double]* %73, i64 0, i64 %75, !dbg !193
  %77 = load double, double* %76, align 8, !dbg !193
  %78 = fadd double %71, %77, !dbg !195
  %79 = add nsw i32 1, %.12, !dbg !196
  %80 = sext i32 %79 to i64, !dbg !197
  %81 = getelementptr inbounds [250 x double], [250 x double]* getelementptr inbounds ([250 x [250 x double]], [250 x [250 x double]]* @B, i64 0, i64 0), i64 %80, !dbg !197
  %82 = sext i32 %.1 to i64, !dbg !197
  %83 = getelementptr inbounds [250 x double], [250 x double]* %81, i64 0, i64 %82, !dbg !197
  %84 = load double, double* %83, align 8, !dbg !197
  %85 = fadd double %78, %84, !dbg !198
  %86 = sub nsw i32 %.12, 1, !dbg !199
  %87 = sext i32 %86 to i64, !dbg !200
  %88 = getelementptr inbounds [250 x double], [250 x double]* getelementptr inbounds ([250 x [250 x double]], [250 x [250 x double]]* @B, i64 0, i64 0), i64 %87, !dbg !200
  %89 = sext i32 %.1 to i64, !dbg !200
  %90 = getelementptr inbounds [250 x double], [250 x double]* %88, i64 0, i64 %89, !dbg !200
  %91 = load double, double* %90, align 8, !dbg !200
  %92 = fadd double %85, %91, !dbg !201
  %93 = fmul double 2.000000e-01, %92, !dbg !202
  %94 = sext i32 %.12 to i64, !dbg !203
  %95 = getelementptr inbounds [250 x double], [250 x double]* getelementptr inbounds ([250 x [250 x double]], [250 x [250 x double]]* @A, i64 0, i64 0), i64 %94, !dbg !203
  %96 = sext i32 %.1 to i64, !dbg !203
  %97 = getelementptr inbounds [250 x double], [250 x double]* %95, i64 0, i64 %96, !dbg !203
  store double %93, double* %97, align 8, !dbg !204
  %98 = add nsw i32 %.1, 1, !dbg !205
  call void @llvm.dbg.value(metadata i32 %98, metadata !146, metadata !DIExpression()), !dbg !126
  br label %57, !dbg !206, !llvm.loop !207

99:                                               ; preds = %57
  %100 = add nsw i32 %.12, 1, !dbg !209
  call void @llvm.dbg.value(metadata i32 %100, metadata !138, metadata !DIExpression()), !dbg !126
  br label %54, !dbg !210, !llvm.loop !211

101:                                              ; preds = %54
  %102 = add nsw i32 %.03, 1, !dbg !213
  call void @llvm.dbg.value(metadata i32 %102, metadata !131, metadata !DIExpression()), !dbg !126
  br label %3, !dbg !214, !llvm.loop !215

103:                                              ; preds = %3
  ret i32 0, !dbg !217
}

; Function Attrs: noinline nounwind uwtable
define dso_local i32 @workload_checksum(i32 noundef %0) #0 !dbg !218 {
  call void @llvm.dbg.value(metadata i32 %0, metadata !221, metadata !DIExpression()), !dbg !222
  store i32 -2128831035, i32* @pb_hash, align 4, !dbg !223
  %2 = load i32, i32* @n, align 4, !dbg !224
  call void @print_array(i32 noundef %2, [250 x double]* noundef getelementptr inbounds ([250 x [250 x double]], [250 x [250 x double]]* @A, i64 0, i64 0)), !dbg !225
  %3 = load i32, i32* @pb_hash, align 4, !dbg !226
  ret i32 %3, !dbg !227
}

; Function Attrs: noinline nounwind uwtable
define internal void @print_array(i32 noundef %0, [250 x double]* noundef %1) #0 !dbg !228 {
  call void @llvm.dbg.value(metadata i32 %0, metadata !231, metadata !DIExpression()), !dbg !232
  call void @llvm.dbg.value(metadata [250 x double]* %1, metadata !233, metadata !DIExpression()), !dbg !232
  %3 = load %struct._IO_FILE*, %struct._IO_FILE** @stderr, align 8, !dbg !234
  %4 = call i32 (%struct._IO_FILE*, i8*, ...) @pb_fprintf(%struct._IO_FILE* noundef %3, i8* noundef getelementptr inbounds ([23 x i8], [23 x i8]* @.str.2, i64 0, i64 0)), !dbg !234
  %5 = load %struct._IO_FILE*, %struct._IO_FILE** @stderr, align 8, !dbg !235
  %6 = call i32 (%struct._IO_FILE*, i8*, ...) @pb_fprintf(%struct._IO_FILE* noundef %5, i8* noundef getelementptr inbounds ([15 x i8], [15 x i8]* @.str.3, i64 0, i64 0), i8* noundef getelementptr inbounds ([2 x i8], [2 x i8]* @.str.4, i64 0, i64 0)), !dbg !235
  call void @llvm.dbg.value(metadata i32 0, metadata !236, metadata !DIExpression()), !dbg !232
  br label %7, !dbg !237

7:                                                ; preds = %31, %2
  %.01 = phi i32 [ 0, %2 ], [ %32, %31 ], !dbg !239
  call void @llvm.dbg.value(metadata i32 %.01, metadata !236, metadata !DIExpression()), !dbg !232
  %8 = icmp slt i32 %.01, %0, !dbg !240
  br i1 %8, label %9, label %33, !dbg !242

9:                                                ; preds = %7
  call void @llvm.dbg.value(metadata i32 0, metadata !243, metadata !DIExpression()), !dbg !232
  br label %10, !dbg !244

10:                                               ; preds = %28, %9
  %.0 = phi i32 [ 0, %9 ], [ %29, %28 ], !dbg !246
  call void @llvm.dbg.value(metadata i32 %.0, metadata !243, metadata !DIExpression()), !dbg !232
  %11 = icmp slt i32 %.0, %0, !dbg !247
  br i1 %11, label %12, label %30, !dbg !249

12:                                               ; preds = %10
  %13 = mul nsw i32 %.01, %0, !dbg !250
  %14 = add nsw i32 %13, %.0, !dbg !253
  %15 = srem i32 %14, 20, !dbg !254
  %16 = icmp eq i32 %15, 0, !dbg !255
  br i1 %16, label %17, label %20, !dbg !256

17:                                               ; preds = %12
  %18 = load %struct._IO_FILE*, %struct._IO_FILE** @stderr, align 8, !dbg !257
  %19 = call i32 (%struct._IO_FILE*, i8*, ...) @pb_fprintf(%struct._IO_FILE* noundef %18, i8* noundef getelementptr inbounds ([2 x i8], [2 x i8]* @.str.5, i64 0, i64 0)), !dbg !258
  br label %20, !dbg !258

20:                                               ; preds = %17, %12
  %21 = load %struct._IO_FILE*, %struct._IO_FILE** @stderr, align 8, !dbg !259
  %22 = sext i32 %.01 to i64, !dbg !260
  %23 = getelementptr inbounds [250 x double], [250 x double]* %1, i64 %22, !dbg !260
  %24 = sext i32 %.0 to i64, !dbg !260
  %25 = getelementptr inbounds [250 x double], [250 x double]* %23, i64 0, i64 %24, !dbg !260
  %26 = load double, double* %25, align 8, !dbg !260
  %27 = call i32 (%struct._IO_FILE*, i8*, ...) @pb_fprintf(%struct._IO_FILE* noundef %21, i8* noundef getelementptr inbounds ([8 x i8], [8 x i8]* @.str.6, i64 0, i64 0), double noundef %26), !dbg !261
  br label %28, !dbg !262

28:                                               ; preds = %20
  %29 = add nsw i32 %.0, 1, !dbg !263
  call void @llvm.dbg.value(metadata i32 %29, metadata !243, metadata !DIExpression()), !dbg !232
  br label %10, !dbg !264, !llvm.loop !265

30:                                               ; preds = %10
  br label %31, !dbg !266

31:                                               ; preds = %30
  %32 = add nsw i32 %.01, 1, !dbg !267
  call void @llvm.dbg.value(metadata i32 %32, metadata !236, metadata !DIExpression()), !dbg !232
  br label %7, !dbg !268, !llvm.loop !269

33:                                               ; preds = %7
  %34 = load %struct._IO_FILE*, %struct._IO_FILE** @stderr, align 8, !dbg !271
  %35 = call i32 (%struct._IO_FILE*, i8*, ...) @pb_fprintf(%struct._IO_FILE* noundef %34, i8* noundef getelementptr inbounds ([17 x i8], [17 x i8]* @.str.7, i64 0, i64 0), i8* noundef getelementptr inbounds ([2 x i8], [2 x i8]* @.str.4, i64 0, i64 0)), !dbg !271
  %36 = load %struct._IO_FILE*, %struct._IO_FILE** @stderr, align 8, !dbg !272
  %37 = call i32 (%struct._IO_FILE*, i8*, ...) @pb_fprintf(%struct._IO_FILE* noundef %36, i8* noundef getelementptr inbounds ([23 x i8], [23 x i8]* @.str.8, i64 0, i64 0)), !dbg !272
  ret void, !dbg !273
}

; Function Attrs: noinline nounwind uwtable
define internal i32 @pb_fprintf(%struct._IO_FILE* noundef %0, i8* noundef %1, ...) #0 !dbg !274 {
  %3 = alloca [768 x i8], align 16
  %4 = alloca [1 x %struct.__va_list_tag], align 16
  call void @llvm.dbg.value(metadata %struct._IO_FILE* %0, metadata !338, metadata !DIExpression()), !dbg !339
  call void @llvm.dbg.value(metadata i8* %1, metadata !340, metadata !DIExpression()), !dbg !339
  call void @llvm.dbg.declare(metadata [768 x i8]* %3, metadata !341, metadata !DIExpression()), !dbg !345
  call void @llvm.dbg.declare(metadata [1 x %struct.__va_list_tag]* %4, metadata !346, metadata !DIExpression()), !dbg !360
  %5 = getelementptr inbounds [1 x %struct.__va_list_tag], [1 x %struct.__va_list_tag]* %4, i64 0, i64 0, !dbg !361
  %6 = bitcast %struct.__va_list_tag* %5 to i8*, !dbg !361
  call void @llvm.va_start(i8* %6), !dbg !361
  %7 = getelementptr inbounds [768 x i8], [768 x i8]* %3, i64 0, i64 0, !dbg !362
  %8 = getelementptr inbounds [1 x %struct.__va_list_tag], [1 x %struct.__va_list_tag]* %4, i64 0, i64 0, !dbg !363
  %9 = call i32 @vsnprintf(i8* noundef %7, i64 noundef 768, i8* noundef %1, %struct.__va_list_tag* noundef %8) #6, !dbg !364
  call void @llvm.dbg.value(metadata i32 %9, metadata !365, metadata !DIExpression()), !dbg !339
  %10 = getelementptr inbounds [1 x %struct.__va_list_tag], [1 x %struct.__va_list_tag]* %4, i64 0, i64 0, !dbg !366
  %11 = bitcast %struct.__va_list_tag* %10 to i8*, !dbg !366
  call void @llvm.va_end(i8* %11), !dbg !366
  %12 = icmp slt i32 %9, 0, !dbg !367
  br i1 %12, label %16, label %13, !dbg !369

13:                                               ; preds = %2
  %14 = zext i32 %9 to i64, !dbg !370
  %15 = icmp uge i64 %14, 768, !dbg !371
  br i1 %15, label %16, label %17, !dbg !372

16:                                               ; preds = %13, %2
  call void @abort() #7, !dbg !373
  unreachable, !dbg !373

17:                                               ; preds = %13
  call void @llvm.dbg.value(metadata i32 0, metadata !374, metadata !DIExpression()), !dbg !376
  br label %18, !dbg !377

18:                                               ; preds = %29, %17
  %.0 = phi i32 [ 0, %17 ], [ %30, %29 ], !dbg !376
  call void @llvm.dbg.value(metadata i32 %.0, metadata !374, metadata !DIExpression()), !dbg !376
  %19 = icmp slt i32 %.0, %9, !dbg !378
  br i1 %19, label %20, label %31, !dbg !380

20:                                               ; preds = %18
  %21 = sext i32 %.0 to i64, !dbg !381
  %22 = getelementptr inbounds [768 x i8], [768 x i8]* %3, i64 0, i64 %21, !dbg !381
  %23 = load i8, i8* %22, align 1, !dbg !381
  %24 = zext i8 %23 to i32, !dbg !383
  %25 = load i32, i32* @pb_hash, align 4, !dbg !384
  %26 = xor i32 %25, %24, !dbg !384
  store i32 %26, i32* @pb_hash, align 4, !dbg !384
  %27 = load i32, i32* @pb_hash, align 4, !dbg !385
  %28 = mul i32 %27, 16777619, !dbg !385
  store i32 %28, i32* @pb_hash, align 4, !dbg !385
  br label %29, !dbg !386

29:                                               ; preds = %20
  %30 = add nsw i32 %.0, 1, !dbg !387
  call void @llvm.dbg.value(metadata i32 %30, metadata !374, metadata !DIExpression()), !dbg !376
  br label %18, !dbg !388, !llvm.loop !389

31:                                               ; preds = %18
  %32 = load i32, i32* @pb_emit, align 4, !dbg !391
  ret i32 %9, !dbg !392
}

; Function Attrs: nofree nosync nounwind willreturn
declare void @llvm.va_start(i8*) #3

; Function Attrs: nounwind
declare i32 @vsnprintf(i8* noundef, i64 noundef, i8* noundef, %struct.__va_list_tag* noundef) #4

; Function Attrs: nofree nosync nounwind willreturn
declare void @llvm.va_end(i8*) #3

; Function Attrs: noreturn nounwind
declare void @abort() #5

; Function Attrs: nofree nosync nounwind readnone speculatable willreturn
declare void @llvm.dbg.value(metadata, metadata, metadata) #1

attributes #0 = { noinline nounwind uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { nofree nosync nounwind readnone speculatable willreturn }
attributes #2 = { argmemonly nofree nounwind willreturn writeonly }
attributes #3 = { nofree nosync nounwind willreturn }
attributes #4 = { nounwind "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #5 = { noreturn nounwind "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #6 = { nounwind }
attributes #7 = { noreturn nounwind }

!llvm.dbg.cu = !{!2}
!llvm.module.flags = !{!42, !43, !44, !45, !46, !47, !48}
!llvm.ident = !{!49}

!0 = !DIGlobalVariableExpression(var: !1, expr: !DIExpression())
!1 = distinct !DIGlobalVariable(name: "n", scope: !2, file: !11, line: 99, type: !12, isLocal: false, isDefinition: true)
!2 = distinct !DICompileUnit(language: DW_LANG_C99, file: !3, producer: "Ubuntu clang version 14.0.0-1ubuntu1.1", isOptimized: false, runtimeVersion: 0, emissionKind: FullDebug, retainedTypes: !4, globals: !8, splitDebugInlining: false, nameTableKind: None)
!3 = !DIFile(filename: "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/affine-bounds-20260929/suite/jacobi-2d/source/workload.c", directory: "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/affine-bounds-20260929/suite/jacobi-2d/analysis-p", checksumkind: CSK_MD5, checksum: "ad98425665ad06f3b4a4de6b7f6bb223")
!4 = !{!5, !6, !7}
!5 = !DIBasicType(name: "double", size: 64, encoding: DW_ATE_float)
!6 = !DIBasicType(name: "unsigned int", size: 32, encoding: DW_ATE_unsigned)
!7 = !DIBasicType(name: "unsigned char", size: 8, encoding: DW_ATE_unsigned_char)
!8 = !{!0, !9, !13, !26, !30, !33, !38, !40}
!9 = !DIGlobalVariableExpression(var: !10, expr: !DIExpression())
!10 = distinct !DIGlobalVariable(name: "tsteps", scope: !2, file: !11, line: 100, type: !12, isLocal: false, isDefinition: true)
!11 = !DIFile(filename: "source/workload.c", directory: "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/affine-bounds-20260929/suite/jacobi-2d", checksumkind: CSK_MD5, checksum: "ad98425665ad06f3b4a4de6b7f6bb223")
!12 = !DIBasicType(name: "int", size: 32, encoding: DW_ATE_signed)
!13 = !DIGlobalVariableExpression(var: !14, expr: !DIExpression())
!14 = distinct !DIGlobalVariable(name: "workload_jobs", scope: !2, file: !11, line: 118, type: !15, isLocal: false, isDefinition: true)
!15 = !DICompositeType(tag: DW_TAG_array_type, baseType: !16, size: 64, elements: !24)
!16 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !17)
!17 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !18, size: 64)
!18 = !DISubroutineType(types: !19)
!19 = !{!20}
!20 = !DIDerivedType(tag: DW_TAG_typedef, name: "uint32_t", file: !21, line: 26, baseType: !22)
!21 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/stdint-uintn.h", directory: "", checksumkind: CSK_MD5, checksum: "2bf2ae53c58c01b1a1b9383b5195125c")
!22 = !DIDerivedType(tag: DW_TAG_typedef, name: "__uint32_t", file: !23, line: 42, baseType: !6)
!23 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/types.h", directory: "", checksumkind: CSK_MD5, checksum: "d108b5f93a74c50510d7d9bc0ab36df9")
!24 = !{!25}
!25 = !DISubrange(count: 1)
!26 = !DIGlobalVariableExpression(var: !27, expr: !DIExpression())
!27 = distinct !DIGlobalVariable(name: "workload_expected", scope: !2, file: !11, line: 122, type: !28, isLocal: false, isDefinition: true)
!28 = !DICompositeType(tag: DW_TAG_array_type, baseType: !29, size: 32, elements: !24)
!29 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !20)
!30 = !DIGlobalVariableExpression(var: !31, expr: !DIExpression())
!31 = distinct !DIGlobalVariable(name: "pb_hash", scope: !2, file: !32, line: 9, type: !20, isLocal: true, isDefinition: true)
!32 = !DIFile(filename: "source/adapter.h", directory: "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/affine-bounds-20260929/suite/jacobi-2d", checksumkind: CSK_MD5, checksum: "26a6068928b2092758f244a9d00163d7")
!33 = !DIGlobalVariableExpression(var: !34, expr: !DIExpression())
!34 = distinct !DIGlobalVariable(name: "A", scope: !2, file: !11, line: 34, type: !35, isLocal: false, isDefinition: true, align: 512)
!35 = !DICompositeType(tag: DW_TAG_array_type, baseType: !5, size: 4000000, elements: !36)
!36 = !{!37, !37}
!37 = !DISubrange(count: 250)
!38 = !DIGlobalVariableExpression(var: !39, expr: !DIExpression())
!39 = distinct !DIGlobalVariable(name: "B", scope: !2, file: !11, line: 35, type: !35, isLocal: false, isDefinition: true, align: 512)
!40 = !DIGlobalVariableExpression(var: !41, expr: !DIExpression())
!41 = distinct !DIGlobalVariable(name: "pb_emit", scope: !2, file: !32, line: 10, type: !12, isLocal: true, isDefinition: true)
!42 = !{i32 7, !"Dwarf Version", i32 5}
!43 = !{i32 2, !"Debug Info Version", i32 3}
!44 = !{i32 1, !"wchar_size", i32 4}
!45 = !{i32 7, !"PIC Level", i32 2}
!46 = !{i32 7, !"PIE Level", i32 2}
!47 = !{i32 7, !"uwtable", i32 1}
!48 = !{i32 7, !"frame-pointer", i32 2}
!49 = !{!"Ubuntu clang version 14.0.0-1ubuntu1.1"}
!50 = distinct !DISubprogram(name: "workload_prepare", scope: !11, file: !11, line: 101, type: !51, scopeLine: 101, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !2, retainedNodes: !53)
!51 = !DISubroutineType(types: !52)
!52 = !{null}
!53 = !{}
!54 = !DILocation(line: 101, column: 30, scope: !50)
!55 = distinct !DISubprogram(name: "workload_reset", scope: !11, file: !11, line: 102, type: !56, scopeLine: 102, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !2, retainedNodes: !53)
!56 = !DISubroutineType(types: !57)
!57 = !{null, !6}
!58 = !DILocalVariable(name: "task", arg: 1, scope: !55, file: !11, line: 102, type: !6)
!59 = !DILocation(line: 0, scope: !55)
!60 = !DILocation(line: 104, column: 3, scope: !55)
!61 = !DILocation(line: 105, column: 3, scope: !55)
!62 = !DILocation(line: 106, column: 15, scope: !55)
!63 = !DILocation(line: 106, column: 3, scope: !55)
!64 = !DILocation(line: 107, column: 1, scope: !55)
!65 = distinct !DISubprogram(name: "init_array", scope: !11, file: !11, line: 37, type: !66, scopeLine: 40, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition, unit: !2, retainedNodes: !53)
!66 = !DISubroutineType(types: !67)
!67 = !{null, !12, !68, !68}
!68 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !69, size: 64)
!69 = !DICompositeType(tag: DW_TAG_array_type, baseType: !5, size: 16000, elements: !70)
!70 = !{!37}
!71 = !DILocalVariable(name: "n", arg: 1, scope: !65, file: !11, line: 37, type: !12)
!72 = !DILocation(line: 0, scope: !65)
!73 = !DILocalVariable(name: "A", arg: 2, scope: !65, file: !11, line: 38, type: !68)
!74 = !DILocalVariable(name: "B", arg: 3, scope: !65, file: !11, line: 39, type: !68)
!75 = !DILocalVariable(name: "i", scope: !65, file: !11, line: 41, type: !12)
!76 = !DILocation(line: 43, column: 8, scope: !77)
!77 = distinct !DILexicalBlock(scope: !65, file: !11, line: 43, column: 3)
!78 = !DILocation(line: 0, scope: !77)
!79 = !DILocation(line: 43, column: 17, scope: !80)
!80 = distinct !DILexicalBlock(scope: !77, file: !11, line: 43, column: 3)
!81 = !DILocation(line: 43, column: 3, scope: !77)
!82 = !DILocalVariable(name: "j", scope: !65, file: !11, line: 41, type: !12)
!83 = !DILocation(line: 44, column: 10, scope: !84)
!84 = distinct !DILexicalBlock(scope: !80, file: !11, line: 44, column: 5)
!85 = !DILocation(line: 0, scope: !84)
!86 = !DILocation(line: 44, column: 19, scope: !87)
!87 = distinct !DILexicalBlock(scope: !84, file: !11, line: 44, column: 5)
!88 = !DILocation(line: 44, column: 5, scope: !84)
!89 = !DILocation(line: 46, column: 13, scope: !90)
!90 = distinct !DILexicalBlock(scope: !87, file: !11, line: 45, column: 7)
!91 = !DILocation(line: 46, column: 29, scope: !90)
!92 = !DILocation(line: 46, column: 27, scope: !90)
!93 = !DILocation(line: 46, column: 26, scope: !90)
!94 = !DILocation(line: 46, column: 33, scope: !90)
!95 = !DILocation(line: 46, column: 40, scope: !90)
!96 = !DILocation(line: 46, column: 38, scope: !90)
!97 = !DILocation(line: 46, column: 2, scope: !90)
!98 = !DILocation(line: 46, column: 10, scope: !90)
!99 = !DILocation(line: 47, column: 13, scope: !90)
!100 = !DILocation(line: 47, column: 29, scope: !90)
!101 = !DILocation(line: 47, column: 27, scope: !90)
!102 = !DILocation(line: 47, column: 26, scope: !90)
!103 = !DILocation(line: 47, column: 33, scope: !90)
!104 = !DILocation(line: 47, column: 40, scope: !90)
!105 = !DILocation(line: 47, column: 38, scope: !90)
!106 = !DILocation(line: 47, column: 2, scope: !90)
!107 = !DILocation(line: 47, column: 10, scope: !90)
!108 = !DILocation(line: 48, column: 7, scope: !90)
!109 = !DILocation(line: 44, column: 25, scope: !87)
!110 = !DILocation(line: 44, column: 5, scope: !87)
!111 = distinct !{!111, !88, !112, !113}
!112 = !DILocation(line: 48, column: 7, scope: !84)
!113 = !{!"llvm.loop.mustprogress"}
!114 = !DILocation(line: 43, column: 23, scope: !80)
!115 = !DILocation(line: 43, column: 3, scope: !80)
!116 = distinct !{!116, !81, !117, !113}
!117 = !DILocation(line: 48, column: 7, scope: !77)
!118 = !DILocation(line: 49, column: 1, scope: !65)
!119 = distinct !DISubprogram(name: "task_job_polybench", scope: !11, file: !11, line: 108, type: !18, scopeLine: 108, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !2, retainedNodes: !53)
!120 = !DILocation(line: 109, column: 20, scope: !119)
!121 = !DILocation(line: 109, column: 28, scope: !119)
!122 = !DILocalVariable(name: "tsteps", arg: 1, scope: !123, file: !11, line: 76, type: !12)
!123 = distinct !DISubprogram(name: "kernel_jacobi_2d", scope: !11, file: !11, line: 76, type: !124, scopeLine: 80, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition, unit: !2, retainedNodes: !53)
!124 = !DISubroutineType(types: !125)
!125 = !{null, !12, !12, !68, !68}
!126 = !DILocation(line: 0, scope: !123, inlinedAt: !127)
!127 = distinct !DILocation(line: 109, column: 3, scope: !119)
!128 = !DILocalVariable(name: "n", arg: 2, scope: !123, file: !11, line: 77, type: !12)
!129 = !DILocalVariable(name: "A", arg: 3, scope: !123, file: !11, line: 78, type: !68)
!130 = !DILocalVariable(name: "B", arg: 4, scope: !123, file: !11, line: 79, type: !68)
!131 = !DILocalVariable(name: "t", scope: !123, file: !11, line: 81, type: !12)
!132 = !DILocation(line: 84, column: 8, scope: !133, inlinedAt: !127)
!133 = distinct !DILexicalBlock(scope: !123, file: !11, line: 84, column: 3)
!134 = !DILocation(line: 0, scope: !133, inlinedAt: !127)
!135 = !DILocation(line: 84, column: 17, scope: !136, inlinedAt: !127)
!136 = distinct !DILexicalBlock(scope: !133, file: !11, line: 84, column: 3)
!137 = !DILocation(line: 84, column: 3, scope: !133, inlinedAt: !127)
!138 = !DILocalVariable(name: "i", scope: !123, file: !11, line: 81, type: !12)
!139 = !DILocation(line: 86, column: 12, scope: !140, inlinedAt: !127)
!140 = distinct !DILexicalBlock(scope: !141, file: !11, line: 86, column: 7)
!141 = distinct !DILexicalBlock(scope: !136, file: !11, line: 85, column: 5)
!142 = !DILocation(line: 0, scope: !140, inlinedAt: !127)
!143 = !DILocation(line: 86, column: 21, scope: !144, inlinedAt: !127)
!144 = distinct !DILexicalBlock(scope: !140, file: !11, line: 86, column: 7)
!145 = !DILocation(line: 86, column: 7, scope: !140, inlinedAt: !127)
!146 = !DILocalVariable(name: "j", scope: !123, file: !11, line: 81, type: !12)
!147 = !DILocation(line: 87, column: 7, scope: !148, inlinedAt: !127)
!148 = distinct !DILexicalBlock(scope: !144, file: !11, line: 87, column: 2)
!149 = !DILocation(line: 0, scope: !148, inlinedAt: !127)
!150 = !DILocation(line: 87, column: 16, scope: !151, inlinedAt: !127)
!151 = distinct !DILexicalBlock(scope: !148, file: !11, line: 87, column: 2)
!152 = !DILocation(line: 87, column: 2, scope: !148, inlinedAt: !127)
!153 = !DILocation(line: 88, column: 33, scope: !151, inlinedAt: !127)
!154 = !DILocation(line: 88, column: 43, scope: !151, inlinedAt: !127)
!155 = !DILocation(line: 88, column: 49, scope: !151, inlinedAt: !127)
!156 = !DILocation(line: 88, column: 41, scope: !151, inlinedAt: !127)
!157 = !DILocation(line: 88, column: 55, scope: !151, inlinedAt: !127)
!158 = !DILocation(line: 88, column: 61, scope: !151, inlinedAt: !127)
!159 = !DILocation(line: 88, column: 53, scope: !151, inlinedAt: !127)
!160 = !DILocation(line: 88, column: 70, scope: !151, inlinedAt: !127)
!161 = !DILocation(line: 88, column: 67, scope: !151, inlinedAt: !127)
!162 = !DILocation(line: 88, column: 65, scope: !151, inlinedAt: !127)
!163 = !DILocation(line: 88, column: 82, scope: !151, inlinedAt: !127)
!164 = !DILocation(line: 88, column: 79, scope: !151, inlinedAt: !127)
!165 = !DILocation(line: 88, column: 77, scope: !151, inlinedAt: !127)
!166 = !DILocation(line: 88, column: 30, scope: !151, inlinedAt: !127)
!167 = !DILocation(line: 88, column: 4, scope: !151, inlinedAt: !127)
!168 = !DILocation(line: 88, column: 12, scope: !151, inlinedAt: !127)
!169 = !DILocation(line: 87, column: 30, scope: !151, inlinedAt: !127)
!170 = !DILocation(line: 87, column: 2, scope: !151, inlinedAt: !127)
!171 = distinct !{!171, !152, !172, !113}
!172 = !DILocation(line: 88, column: 88, scope: !148, inlinedAt: !127)
!173 = !DILocation(line: 86, column: 35, scope: !144, inlinedAt: !127)
!174 = !DILocation(line: 86, column: 7, scope: !144, inlinedAt: !127)
!175 = distinct !{!175, !145, !176, !113}
!176 = !DILocation(line: 88, column: 88, scope: !140, inlinedAt: !127)
!177 = !DILocation(line: 89, column: 12, scope: !178, inlinedAt: !127)
!178 = distinct !DILexicalBlock(scope: !141, file: !11, line: 89, column: 7)
!179 = !DILocation(line: 0, scope: !178, inlinedAt: !127)
!180 = !DILocation(line: 89, column: 21, scope: !181, inlinedAt: !127)
!181 = distinct !DILexicalBlock(scope: !178, file: !11, line: 89, column: 7)
!182 = !DILocation(line: 89, column: 7, scope: !178, inlinedAt: !127)
!183 = !DILocation(line: 90, column: 7, scope: !184, inlinedAt: !127)
!184 = distinct !DILexicalBlock(scope: !181, file: !11, line: 90, column: 2)
!185 = !DILocation(line: 0, scope: !184, inlinedAt: !127)
!186 = !DILocation(line: 90, column: 16, scope: !187, inlinedAt: !127)
!187 = distinct !DILexicalBlock(scope: !184, file: !11, line: 90, column: 2)
!188 = !DILocation(line: 90, column: 2, scope: !184, inlinedAt: !127)
!189 = !DILocation(line: 91, column: 33, scope: !187, inlinedAt: !127)
!190 = !DILocation(line: 91, column: 43, scope: !187, inlinedAt: !127)
!191 = !DILocation(line: 91, column: 49, scope: !187, inlinedAt: !127)
!192 = !DILocation(line: 91, column: 41, scope: !187, inlinedAt: !127)
!193 = !DILocation(line: 91, column: 55, scope: !187, inlinedAt: !127)
!194 = !DILocation(line: 91, column: 61, scope: !187, inlinedAt: !127)
!195 = !DILocation(line: 91, column: 53, scope: !187, inlinedAt: !127)
!196 = !DILocation(line: 91, column: 70, scope: !187, inlinedAt: !127)
!197 = !DILocation(line: 91, column: 67, scope: !187, inlinedAt: !127)
!198 = !DILocation(line: 91, column: 65, scope: !187, inlinedAt: !127)
!199 = !DILocation(line: 91, column: 82, scope: !187, inlinedAt: !127)
!200 = !DILocation(line: 91, column: 79, scope: !187, inlinedAt: !127)
!201 = !DILocation(line: 91, column: 77, scope: !187, inlinedAt: !127)
!202 = !DILocation(line: 91, column: 30, scope: !187, inlinedAt: !127)
!203 = !DILocation(line: 91, column: 4, scope: !187, inlinedAt: !127)
!204 = !DILocation(line: 91, column: 12, scope: !187, inlinedAt: !127)
!205 = !DILocation(line: 90, column: 30, scope: !187, inlinedAt: !127)
!206 = !DILocation(line: 90, column: 2, scope: !187, inlinedAt: !127)
!207 = distinct !{!207, !188, !208, !113}
!208 = !DILocation(line: 91, column: 88, scope: !184, inlinedAt: !127)
!209 = !DILocation(line: 89, column: 35, scope: !181, inlinedAt: !127)
!210 = !DILocation(line: 89, column: 7, scope: !181, inlinedAt: !127)
!211 = distinct !{!211, !182, !212, !113}
!212 = !DILocation(line: 91, column: 88, scope: !178, inlinedAt: !127)
!213 = !DILocation(line: 84, column: 32, scope: !136, inlinedAt: !127)
!214 = !DILocation(line: 84, column: 3, scope: !136, inlinedAt: !127)
!215 = distinct !{!215, !137, !216, !113}
!216 = !DILocation(line: 92, column: 5, scope: !133, inlinedAt: !127)
!217 = !DILocation(line: 110, column: 3, scope: !119)
!218 = distinct !DISubprogram(name: "workload_checksum", scope: !11, file: !11, line: 112, type: !219, scopeLine: 112, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !2, retainedNodes: !53)
!219 = !DISubroutineType(types: !220)
!220 = !{!20, !6}
!221 = !DILocalVariable(name: "task", arg: 1, scope: !218, file: !11, line: 112, type: !6)
!222 = !DILocation(line: 0, scope: !218)
!223 = !DILocation(line: 114, column: 11, scope: !218)
!224 = !DILocation(line: 115, column: 15, scope: !218)
!225 = !DILocation(line: 115, column: 3, scope: !218)
!226 = !DILocation(line: 116, column: 10, scope: !218)
!227 = !DILocation(line: 116, column: 3, scope: !218)
!228 = distinct !DISubprogram(name: "print_array", scope: !11, file: !11, line: 55, type: !229, scopeLine: 58, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition, unit: !2, retainedNodes: !53)
!229 = !DISubroutineType(types: !230)
!230 = !{null, !12, !68}
!231 = !DILocalVariable(name: "n", arg: 1, scope: !228, file: !11, line: 55, type: !12)
!232 = !DILocation(line: 0, scope: !228)
!233 = !DILocalVariable(name: "A", arg: 2, scope: !228, file: !11, line: 56, type: !68)
!234 = !DILocation(line: 61, column: 3, scope: !228)
!235 = !DILocation(line: 62, column: 3, scope: !228)
!236 = !DILocalVariable(name: "i", scope: !228, file: !11, line: 59, type: !12)
!237 = !DILocation(line: 63, column: 8, scope: !238)
!238 = distinct !DILexicalBlock(scope: !228, file: !11, line: 63, column: 3)
!239 = !DILocation(line: 0, scope: !238)
!240 = !DILocation(line: 63, column: 17, scope: !241)
!241 = distinct !DILexicalBlock(scope: !238, file: !11, line: 63, column: 3)
!242 = !DILocation(line: 63, column: 3, scope: !238)
!243 = !DILocalVariable(name: "j", scope: !228, file: !11, line: 59, type: !12)
!244 = !DILocation(line: 64, column: 10, scope: !245)
!245 = distinct !DILexicalBlock(scope: !241, file: !11, line: 64, column: 5)
!246 = !DILocation(line: 0, scope: !245)
!247 = !DILocation(line: 64, column: 19, scope: !248)
!248 = distinct !DILexicalBlock(scope: !245, file: !11, line: 64, column: 5)
!249 = !DILocation(line: 64, column: 5, scope: !245)
!250 = !DILocation(line: 65, column: 14, scope: !251)
!251 = distinct !DILexicalBlock(scope: !252, file: !11, line: 65, column: 11)
!252 = distinct !DILexicalBlock(scope: !248, file: !11, line: 64, column: 29)
!253 = !DILocation(line: 65, column: 18, scope: !251)
!254 = !DILocation(line: 65, column: 23, scope: !251)
!255 = !DILocation(line: 65, column: 28, scope: !251)
!256 = !DILocation(line: 65, column: 11, scope: !252)
!257 = !DILocation(line: 65, column: 42, scope: !251)
!258 = !DILocation(line: 65, column: 34, scope: !251)
!259 = !DILocation(line: 66, column: 15, scope: !252)
!260 = !DILocation(line: 66, column: 60, scope: !252)
!261 = !DILocation(line: 66, column: 7, scope: !252)
!262 = !DILocation(line: 67, column: 5, scope: !252)
!263 = !DILocation(line: 64, column: 25, scope: !248)
!264 = !DILocation(line: 64, column: 5, scope: !248)
!265 = distinct !{!265, !249, !266, !113}
!266 = !DILocation(line: 67, column: 5, scope: !245)
!267 = !DILocation(line: 63, column: 23, scope: !241)
!268 = !DILocation(line: 63, column: 3, scope: !241)
!269 = distinct !{!269, !242, !270, !113}
!270 = !DILocation(line: 67, column: 5, scope: !238)
!271 = !DILocation(line: 68, column: 3, scope: !228)
!272 = !DILocation(line: 69, column: 3, scope: !228)
!273 = !DILocation(line: 70, column: 1, scope: !228)
!274 = distinct !DISubprogram(name: "pb_fprintf", scope: !32, file: !32, line: 13, type: !275, scopeLine: 14, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition, unit: !2, retainedNodes: !53)
!275 = !DISubroutineType(types: !276)
!276 = !{!12, !277, !336, null}
!277 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !278, size: 64)
!278 = !DIDerivedType(tag: DW_TAG_typedef, name: "FILE", file: !279, line: 7, baseType: !280)
!279 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/types/FILE.h", directory: "", checksumkind: CSK_MD5, checksum: "571f9fb6223c42439075fdde11a0de5d")
!280 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "_IO_FILE", file: !281, line: 49, size: 1728, elements: !282)
!281 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/types/struct_FILE.h", directory: "", checksumkind: CSK_MD5, checksum: "1bad07471b7974df4ecc1d1c2ca207e6")
!282 = !{!283, !284, !287, !288, !289, !290, !291, !292, !293, !294, !295, !296, !297, !300, !302, !303, !304, !307, !309, !311, !313, !316, !318, !321, !324, !325, !327, !331, !332}
!283 = !DIDerivedType(tag: DW_TAG_member, name: "_flags", scope: !280, file: !281, line: 51, baseType: !12, size: 32)
!284 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_read_ptr", scope: !280, file: !281, line: 54, baseType: !285, size: 64, offset: 64)
!285 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !286, size: 64)
!286 = !DIBasicType(name: "char", size: 8, encoding: DW_ATE_signed_char)
!287 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_read_end", scope: !280, file: !281, line: 55, baseType: !285, size: 64, offset: 128)
!288 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_read_base", scope: !280, file: !281, line: 56, baseType: !285, size: 64, offset: 192)
!289 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_write_base", scope: !280, file: !281, line: 57, baseType: !285, size: 64, offset: 256)
!290 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_write_ptr", scope: !280, file: !281, line: 58, baseType: !285, size: 64, offset: 320)
!291 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_write_end", scope: !280, file: !281, line: 59, baseType: !285, size: 64, offset: 384)
!292 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_buf_base", scope: !280, file: !281, line: 60, baseType: !285, size: 64, offset: 448)
!293 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_buf_end", scope: !280, file: !281, line: 61, baseType: !285, size: 64, offset: 512)
!294 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_save_base", scope: !280, file: !281, line: 64, baseType: !285, size: 64, offset: 576)
!295 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_backup_base", scope: !280, file: !281, line: 65, baseType: !285, size: 64, offset: 640)
!296 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_save_end", scope: !280, file: !281, line: 66, baseType: !285, size: 64, offset: 704)
!297 = !DIDerivedType(tag: DW_TAG_member, name: "_markers", scope: !280, file: !281, line: 68, baseType: !298, size: 64, offset: 768)
!298 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !299, size: 64)
!299 = !DICompositeType(tag: DW_TAG_structure_type, name: "_IO_marker", file: !281, line: 36, flags: DIFlagFwdDecl)
!300 = !DIDerivedType(tag: DW_TAG_member, name: "_chain", scope: !280, file: !281, line: 70, baseType: !301, size: 64, offset: 832)
!301 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !280, size: 64)
!302 = !DIDerivedType(tag: DW_TAG_member, name: "_fileno", scope: !280, file: !281, line: 72, baseType: !12, size: 32, offset: 896)
!303 = !DIDerivedType(tag: DW_TAG_member, name: "_flags2", scope: !280, file: !281, line: 73, baseType: !12, size: 32, offset: 928)
!304 = !DIDerivedType(tag: DW_TAG_member, name: "_old_offset", scope: !280, file: !281, line: 74, baseType: !305, size: 64, offset: 960)
!305 = !DIDerivedType(tag: DW_TAG_typedef, name: "__off_t", file: !23, line: 152, baseType: !306)
!306 = !DIBasicType(name: "long", size: 64, encoding: DW_ATE_signed)
!307 = !DIDerivedType(tag: DW_TAG_member, name: "_cur_column", scope: !280, file: !281, line: 77, baseType: !308, size: 16, offset: 1024)
!308 = !DIBasicType(name: "unsigned short", size: 16, encoding: DW_ATE_unsigned)
!309 = !DIDerivedType(tag: DW_TAG_member, name: "_vtable_offset", scope: !280, file: !281, line: 78, baseType: !310, size: 8, offset: 1040)
!310 = !DIBasicType(name: "signed char", size: 8, encoding: DW_ATE_signed_char)
!311 = !DIDerivedType(tag: DW_TAG_member, name: "_shortbuf", scope: !280, file: !281, line: 79, baseType: !312, size: 8, offset: 1048)
!312 = !DICompositeType(tag: DW_TAG_array_type, baseType: !286, size: 8, elements: !24)
!313 = !DIDerivedType(tag: DW_TAG_member, name: "_lock", scope: !280, file: !281, line: 81, baseType: !314, size: 64, offset: 1088)
!314 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !315, size: 64)
!315 = !DIDerivedType(tag: DW_TAG_typedef, name: "_IO_lock_t", file: !281, line: 43, baseType: null)
!316 = !DIDerivedType(tag: DW_TAG_member, name: "_offset", scope: !280, file: !281, line: 89, baseType: !317, size: 64, offset: 1152)
!317 = !DIDerivedType(tag: DW_TAG_typedef, name: "__off64_t", file: !23, line: 153, baseType: !306)
!318 = !DIDerivedType(tag: DW_TAG_member, name: "_codecvt", scope: !280, file: !281, line: 91, baseType: !319, size: 64, offset: 1216)
!319 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !320, size: 64)
!320 = !DICompositeType(tag: DW_TAG_structure_type, name: "_IO_codecvt", file: !281, line: 37, flags: DIFlagFwdDecl)
!321 = !DIDerivedType(tag: DW_TAG_member, name: "_wide_data", scope: !280, file: !281, line: 92, baseType: !322, size: 64, offset: 1280)
!322 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !323, size: 64)
!323 = !DICompositeType(tag: DW_TAG_structure_type, name: "_IO_wide_data", file: !281, line: 38, flags: DIFlagFwdDecl)
!324 = !DIDerivedType(tag: DW_TAG_member, name: "_freeres_list", scope: !280, file: !281, line: 93, baseType: !301, size: 64, offset: 1344)
!325 = !DIDerivedType(tag: DW_TAG_member, name: "_freeres_buf", scope: !280, file: !281, line: 94, baseType: !326, size: 64, offset: 1408)
!326 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: null, size: 64)
!327 = !DIDerivedType(tag: DW_TAG_member, name: "__pad5", scope: !280, file: !281, line: 95, baseType: !328, size: 64, offset: 1472)
!328 = !DIDerivedType(tag: DW_TAG_typedef, name: "size_t", file: !329, line: 46, baseType: !330)
!329 = !DIFile(filename: "/usr/lib/llvm-14/lib/clang/14.0.0/include/stddef.h", directory: "", checksumkind: CSK_MD5, checksum: "2499dd2361b915724b073282bea3a7bc")
!330 = !DIBasicType(name: "unsigned long", size: 64, encoding: DW_ATE_unsigned)
!331 = !DIDerivedType(tag: DW_TAG_member, name: "_mode", scope: !280, file: !281, line: 96, baseType: !12, size: 32, offset: 1536)
!332 = !DIDerivedType(tag: DW_TAG_member, name: "_unused2", scope: !280, file: !281, line: 98, baseType: !333, size: 160, offset: 1568)
!333 = !DICompositeType(tag: DW_TAG_array_type, baseType: !286, size: 160, elements: !334)
!334 = !{!335}
!335 = !DISubrange(count: 20)
!336 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !337, size: 64)
!337 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !286)
!338 = !DILocalVariable(name: "stream", arg: 1, scope: !274, file: !32, line: 13, type: !277)
!339 = !DILocation(line: 0, scope: !274)
!340 = !DILocalVariable(name: "format", arg: 2, scope: !274, file: !32, line: 13, type: !336)
!341 = !DILocalVariable(name: "buffer", scope: !274, file: !32, line: 15, type: !342)
!342 = !DICompositeType(tag: DW_TAG_array_type, baseType: !286, size: 6144, elements: !343)
!343 = !{!344}
!344 = !DISubrange(count: 768)
!345 = !DILocation(line: 15, column: 10, scope: !274)
!346 = !DILocalVariable(name: "args", scope: !274, file: !32, line: 16, type: !347)
!347 = !DIDerivedType(tag: DW_TAG_typedef, name: "va_list", file: !348, line: 52, baseType: !349)
!348 = !DIFile(filename: "/usr/include/stdio.h", directory: "", checksumkind: CSK_MD5, checksum: "f31eefcc3f15835fc5a4023a625cf609")
!349 = !DIDerivedType(tag: DW_TAG_typedef, name: "__gnuc_va_list", file: !350, line: 32, baseType: !351)
!350 = !DIFile(filename: "/usr/lib/llvm-14/lib/clang/14.0.0/include/stdarg.h", directory: "", checksumkind: CSK_MD5, checksum: "4de3cbd931b589d291e5c39387aecf82")
!351 = !DIDerivedType(tag: DW_TAG_typedef, name: "__builtin_va_list", file: !352, baseType: !353)
!352 = !DIFile(filename: "source/workload.c", directory: "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/affine-bounds-20260929/suite/jacobi-2d")
!353 = !DICompositeType(tag: DW_TAG_array_type, baseType: !354, size: 192, elements: !24)
!354 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "__va_list_tag", size: 192, elements: !355)
!355 = !{!356, !357, !358, !359}
!356 = !DIDerivedType(tag: DW_TAG_member, name: "gp_offset", scope: !354, file: !352, line: 16, baseType: !6, size: 32)
!357 = !DIDerivedType(tag: DW_TAG_member, name: "fp_offset", scope: !354, file: !352, line: 16, baseType: !6, size: 32, offset: 32)
!358 = !DIDerivedType(tag: DW_TAG_member, name: "overflow_arg_area", scope: !354, file: !352, line: 16, baseType: !326, size: 64, offset: 64)
!359 = !DIDerivedType(tag: DW_TAG_member, name: "reg_save_area", scope: !354, file: !352, line: 16, baseType: !326, size: 64, offset: 128)
!360 = !DILocation(line: 16, column: 13, scope: !274)
!361 = !DILocation(line: 17, column: 5, scope: !274)
!362 = !DILocation(line: 18, column: 27, scope: !274)
!363 = !DILocation(line: 18, column: 59, scope: !274)
!364 = !DILocation(line: 18, column: 17, scope: !274)
!365 = !DILocalVariable(name: "count", scope: !274, file: !32, line: 18, type: !12)
!366 = !DILocation(line: 19, column: 5, scope: !274)
!367 = !DILocation(line: 20, column: 15, scope: !368)
!368 = distinct !DILexicalBlock(scope: !274, file: !32, line: 20, column: 9)
!369 = !DILocation(line: 20, column: 19, scope: !368)
!370 = !DILocation(line: 20, column: 22, scope: !368)
!371 = !DILocation(line: 20, column: 38, scope: !368)
!372 = !DILocation(line: 20, column: 9, scope: !274)
!373 = !DILocation(line: 20, column: 57, scope: !368)
!374 = !DILocalVariable(name: "i", scope: !375, file: !32, line: 21, type: !12)
!375 = distinct !DILexicalBlock(scope: !274, file: !32, line: 21, column: 5)
!376 = !DILocation(line: 0, scope: !375)
!377 = !DILocation(line: 21, column: 10, scope: !375)
!378 = !DILocation(line: 21, column: 23, scope: !379)
!379 = distinct !DILexicalBlock(scope: !375, file: !32, line: 21, column: 5)
!380 = !DILocation(line: 21, column: 5, scope: !375)
!381 = !DILocation(line: 22, column: 35, scope: !382)
!382 = distinct !DILexicalBlock(scope: !379, file: !32, line: 21, column: 37)
!383 = !DILocation(line: 22, column: 20, scope: !382)
!384 = !DILocation(line: 22, column: 17, scope: !382)
!385 = !DILocation(line: 23, column: 17, scope: !382)
!386 = !DILocation(line: 24, column: 5, scope: !382)
!387 = !DILocation(line: 21, column: 32, scope: !379)
!388 = !DILocation(line: 21, column: 5, scope: !379)
!389 = distinct !{!389, !380, !390, !113}
!390 = !DILocation(line: 24, column: 5, scope: !375)
!391 = !DILocation(line: 29, column: 11, scope: !274)
!392 = !DILocation(line: 31, column: 5, scope: !274)
