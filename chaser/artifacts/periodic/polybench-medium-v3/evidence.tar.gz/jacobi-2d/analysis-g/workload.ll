; ModuleID = '/workspace/experiments-array-support/chaser/.cache/periodic-polybench/affine-bounds-20260929/suite/jacobi-2d/source/workload.c'
source_filename = "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/affine-bounds-20260929/suite/jacobi-2d/source/workload.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

%struct._IO_FILE = type { i32, i8*, i8*, i8*, i8*, i8*, i8*, i8*, i8*, i8*, i8*, i8*, %struct._IO_marker*, %struct._IO_FILE*, i32, i32, i64, i16, i8, [1 x i8], i8*, i64, %struct._IO_codecvt*, %struct._IO_wide_data*, %struct._IO_FILE*, i8*, i64, i32, [20 x i8] }
%struct._IO_marker = type opaque
%struct._IO_codecvt = type opaque
%struct._IO_wide_data = type opaque
%struct.__va_list_tag = type { i32, i32, i8*, i8* }

@n = dso_local global i32 250, align 4, !dbg !0
@tsteps = dso_local global i32 100, align 4, !dbg !9
@A = dso_local global [250 x [250 x double]] zeroinitializer, section ".chaser_data.A", align 64, !dbg !33
@B = dso_local global [250 x [250 x double]] zeroinitializer, section ".chaser_data.B", align 64, !dbg !38
@.str = private unnamed_addr constant [12 x i8] c"ape.analyze\00", section "llvm.metadata"
@.str.1 = private unnamed_addr constant [127 x i8] c"/workspace/experiments-array-support/chaser/.cache/periodic-polybench/affine-bounds-20260929/suite/jacobi-2d/source/workload.c\00", section "llvm.metadata"
@pb_hash = internal global i32 0, align 4, !dbg !30
@workload_jobs = dso_local constant [1 x i32 ()*] [i32 ()* @task_job_polybench], align 8, !dbg !13
@workload_expected = dso_local constant [1 x i32] [i32 -1612902674], align 4, !dbg !26
@stderr = external global %struct._IO_FILE*, align 8
@.str.2 = private unnamed_addr constant [23 x i8] c"==BEGIN DUMP_ARRAYS==\0A\00", align 1
@.str.3 = private unnamed_addr constant [15 x i8] c"begin dump: %s\00", align 1
@.str.4 = private unnamed_addr constant [2 x i8] c"A\00", align 1
@.str.5 = private unnamed_addr constant [2 x i8] c"\0A\00", align 1
@.str.6 = private unnamed_addr constant [8 x i8] c"%0.2lf \00", align 1
@.str.7 = private unnamed_addr constant [17 x i8] c"\0Aend   dump: %s\0A\00", align 1
@.str.8 = private unnamed_addr constant [23 x i8] c"==END   DUMP_ARRAYS==\0A\00", align 1
@pb_emit = internal global i32 1, align 4, !dbg !40
@llvm.global.annotations = appending global [1 x { i8*, i8*, i8*, i32, i8* }] [{ i8*, i8*, i8*, i32, i8* } { i8* bitcast (i32 ()* @task_job_polybench to i8*), i8* getelementptr inbounds ([12 x i8], [12 x i8]* @.str, i32 0, i32 0), i8* getelementptr inbounds ([127 x i8], [127 x i8]* @.str.1, i32 0, i32 0), i32 108, i8* null }], section "llvm.metadata"

; Function Attrs: noinline nounwind uwtable
define dso_local void @workload_prepare() #0 !dbg !50 {
  ret void, !dbg !54
}

; Function Attrs: noinline nounwind uwtable
define dso_local void @workload_reset(i32 noundef %0) #0 !dbg !55 {
  %2 = alloca i32, align 4
  store i32 %0, i32* %2, align 4
  call void @llvm.dbg.declare(metadata i32* %2, metadata !58, metadata !DIExpression()), !dbg !59
  %3 = load i32, i32* %2, align 4, !dbg !60
  call void @llvm.memset.p0i8.i64(i8* align 64 bitcast ([250 x [250 x double]]* @A to i8*), i8 0, i64 500000, i1 false), !dbg !61
  call void @llvm.memset.p0i8.i64(i8* align 64 bitcast ([250 x [250 x double]]* @B to i8*), i8 0, i64 500000, i1 false), !dbg !62
  %4 = load i32, i32* @n, align 4, !dbg !63
  call void @init_array(i32 noundef %4, [250 x double]* noundef getelementptr inbounds ([250 x [250 x double]], [250 x [250 x double]]* @A, i64 0, i64 0), [250 x double]* noundef getelementptr inbounds ([250 x [250 x double]], [250 x [250 x double]]* @B, i64 0, i64 0)), !dbg !64
  ret void, !dbg !65
}

; Function Attrs: nofree nosync nounwind readnone speculatable willreturn
declare void @llvm.dbg.declare(metadata, metadata, metadata) #1

; Function Attrs: argmemonly nofree nounwind willreturn writeonly
declare void @llvm.memset.p0i8.i64(i8* nocapture writeonly, i8, i64, i1 immarg) #2

; Function Attrs: noinline nounwind uwtable
define internal void @init_array(i32 noundef %0, [250 x double]* noundef %1, [250 x double]* noundef %2) #0 !dbg !66 {
  %4 = alloca i32, align 4
  %5 = alloca [250 x double]*, align 8
  %6 = alloca [250 x double]*, align 8
  %7 = alloca i32, align 4
  %8 = alloca i32, align 4
  store i32 %0, i32* %4, align 4
  call void @llvm.dbg.declare(metadata i32* %4, metadata !72, metadata !DIExpression()), !dbg !73
  store [250 x double]* %1, [250 x double]** %5, align 8
  call void @llvm.dbg.declare(metadata [250 x double]** %5, metadata !74, metadata !DIExpression()), !dbg !75
  store [250 x double]* %2, [250 x double]** %6, align 8
  call void @llvm.dbg.declare(metadata [250 x double]** %6, metadata !76, metadata !DIExpression()), !dbg !77
  call void @llvm.dbg.declare(metadata i32* %7, metadata !78, metadata !DIExpression()), !dbg !79
  call void @llvm.dbg.declare(metadata i32* %8, metadata !80, metadata !DIExpression()), !dbg !81
  store i32 0, i32* %7, align 4, !dbg !82
  br label %9, !dbg !84

9:                                                ; preds = %57, %3
  %10 = load i32, i32* %7, align 4, !dbg !85
  %11 = load i32, i32* %4, align 4, !dbg !87
  %12 = icmp slt i32 %10, %11, !dbg !88
  br i1 %12, label %13, label %60, !dbg !89

13:                                               ; preds = %9
  store i32 0, i32* %8, align 4, !dbg !90
  br label %14, !dbg !92

14:                                               ; preds = %53, %13
  %15 = load i32, i32* %8, align 4, !dbg !93
  %16 = load i32, i32* %4, align 4, !dbg !95
  %17 = icmp slt i32 %15, %16, !dbg !96
  br i1 %17, label %18, label %56, !dbg !97

18:                                               ; preds = %14
  %19 = load i32, i32* %7, align 4, !dbg !98
  %20 = sitofp i32 %19 to double, !dbg !100
  %21 = load i32, i32* %8, align 4, !dbg !101
  %22 = add nsw i32 %21, 2, !dbg !102
  %23 = sitofp i32 %22 to double, !dbg !103
  %24 = fmul double %20, %23, !dbg !104
  %25 = fadd double %24, 2.000000e+00, !dbg !105
  %26 = load i32, i32* %4, align 4, !dbg !106
  %27 = sitofp i32 %26 to double, !dbg !106
  %28 = fdiv double %25, %27, !dbg !107
  %29 = load [250 x double]*, [250 x double]** %5, align 8, !dbg !108
  %30 = load i32, i32* %7, align 4, !dbg !109
  %31 = sext i32 %30 to i64, !dbg !108
  %32 = getelementptr inbounds [250 x double], [250 x double]* %29, i64 %31, !dbg !108
  %33 = load i32, i32* %8, align 4, !dbg !110
  %34 = sext i32 %33 to i64, !dbg !108
  %35 = getelementptr inbounds [250 x double], [250 x double]* %32, i64 0, i64 %34, !dbg !108
  store double %28, double* %35, align 8, !dbg !111
  %36 = load i32, i32* %7, align 4, !dbg !112
  %37 = sitofp i32 %36 to double, !dbg !113
  %38 = load i32, i32* %8, align 4, !dbg !114
  %39 = add nsw i32 %38, 3, !dbg !115
  %40 = sitofp i32 %39 to double, !dbg !116
  %41 = fmul double %37, %40, !dbg !117
  %42 = fadd double %41, 3.000000e+00, !dbg !118
  %43 = load i32, i32* %4, align 4, !dbg !119
  %44 = sitofp i32 %43 to double, !dbg !119
  %45 = fdiv double %42, %44, !dbg !120
  %46 = load [250 x double]*, [250 x double]** %6, align 8, !dbg !121
  %47 = load i32, i32* %7, align 4, !dbg !122
  %48 = sext i32 %47 to i64, !dbg !121
  %49 = getelementptr inbounds [250 x double], [250 x double]* %46, i64 %48, !dbg !121
  %50 = load i32, i32* %8, align 4, !dbg !123
  %51 = sext i32 %50 to i64, !dbg !121
  %52 = getelementptr inbounds [250 x double], [250 x double]* %49, i64 0, i64 %51, !dbg !121
  store double %45, double* %52, align 8, !dbg !124
  br label %53, !dbg !125

53:                                               ; preds = %18
  %54 = load i32, i32* %8, align 4, !dbg !126
  %55 = add nsw i32 %54, 1, !dbg !126
  store i32 %55, i32* %8, align 4, !dbg !126
  br label %14, !dbg !127, !llvm.loop !128

56:                                               ; preds = %14
  br label %57, !dbg !129

57:                                               ; preds = %56
  %58 = load i32, i32* %7, align 4, !dbg !131
  %59 = add nsw i32 %58, 1, !dbg !131
  store i32 %59, i32* %7, align 4, !dbg !131
  br label %9, !dbg !132, !llvm.loop !133

60:                                               ; preds = %9
  ret void, !dbg !135
}

; Function Attrs: noinline nounwind uwtable
define dso_local i32 @task_job_polybench() #0 !dbg !136 {
  %1 = alloca i32, align 4
  %2 = alloca i32, align 4
  %3 = alloca [250 x double]*, align 8
  %4 = alloca [250 x double]*, align 8
  %5 = alloca i32, align 4
  %6 = alloca i32, align 4
  %7 = alloca i32, align 4
  %8 = load i32, i32* @tsteps, align 4, !dbg !137
  %9 = load i32, i32* @n, align 4, !dbg !138
  store i32 %8, i32* %1, align 4
  call void @llvm.dbg.declare(metadata i32* %1, metadata !139, metadata !DIExpression()), !dbg !143
  store i32 %9, i32* %2, align 4
  call void @llvm.dbg.declare(metadata i32* %2, metadata !145, metadata !DIExpression()), !dbg !146
  store [250 x double]* getelementptr inbounds ([250 x [250 x double]], [250 x [250 x double]]* @A, i64 0, i64 0), [250 x double]** %3, align 8
  call void @llvm.dbg.declare(metadata [250 x double]** %3, metadata !147, metadata !DIExpression()), !dbg !148
  store [250 x double]* getelementptr inbounds ([250 x [250 x double]], [250 x [250 x double]]* @B, i64 0, i64 0), [250 x double]** %4, align 8
  call void @llvm.dbg.declare(metadata [250 x double]** %4, metadata !149, metadata !DIExpression()), !dbg !150
  call void @llvm.dbg.declare(metadata i32* %5, metadata !151, metadata !DIExpression()), !dbg !152
  call void @llvm.dbg.declare(metadata i32* %6, metadata !153, metadata !DIExpression()), !dbg !154
  call void @llvm.dbg.declare(metadata i32* %7, metadata !155, metadata !DIExpression()), !dbg !156
  store i32 0, i32* %5, align 4, !dbg !157
  br label %10, !dbg !159

10:                                               ; preds = %153, %0
  %11 = load i32, i32* %5, align 4, !dbg !160
  %12 = icmp slt i32 %11, 100, !dbg !162
  br i1 %12, label %13, label %156, !dbg !163

13:                                               ; preds = %10
  store i32 1, i32* %6, align 4, !dbg !164
  br label %14, !dbg !167

14:                                               ; preds = %80, %13
  %15 = load i32, i32* %6, align 4, !dbg !168
  %16 = icmp slt i32 %15, 249, !dbg !170
  br i1 %16, label %17, label %83, !dbg !171

17:                                               ; preds = %14
  store i32 1, i32* %7, align 4, !dbg !172
  br label %18, !dbg !174

18:                                               ; preds = %21, %17
  %19 = load i32, i32* %7, align 4, !dbg !175
  %20 = icmp slt i32 %19, 249, !dbg !177
  br i1 %20, label %21, label %80, !dbg !178

21:                                               ; preds = %18
  %22 = load [250 x double]*, [250 x double]** %3, align 8, !dbg !179
  %23 = load i32, i32* %6, align 4, !dbg !180
  %24 = sext i32 %23 to i64, !dbg !179
  %25 = getelementptr inbounds [250 x double], [250 x double]* %22, i64 %24, !dbg !179
  %26 = load i32, i32* %7, align 4, !dbg !181
  %27 = sext i32 %26 to i64, !dbg !179
  %28 = getelementptr inbounds [250 x double], [250 x double]* %25, i64 0, i64 %27, !dbg !179
  %29 = load double, double* %28, align 8, !dbg !179
  %30 = load [250 x double]*, [250 x double]** %3, align 8, !dbg !182
  %31 = load i32, i32* %6, align 4, !dbg !183
  %32 = sext i32 %31 to i64, !dbg !182
  %33 = getelementptr inbounds [250 x double], [250 x double]* %30, i64 %32, !dbg !182
  %34 = load i32, i32* %7, align 4, !dbg !184
  %35 = sub nsw i32 %34, 1, !dbg !185
  %36 = sext i32 %35 to i64, !dbg !182
  %37 = getelementptr inbounds [250 x double], [250 x double]* %33, i64 0, i64 %36, !dbg !182
  %38 = load double, double* %37, align 8, !dbg !182
  %39 = fadd double %29, %38, !dbg !186
  %40 = load [250 x double]*, [250 x double]** %3, align 8, !dbg !187
  %41 = load i32, i32* %6, align 4, !dbg !188
  %42 = sext i32 %41 to i64, !dbg !187
  %43 = getelementptr inbounds [250 x double], [250 x double]* %40, i64 %42, !dbg !187
  %44 = load i32, i32* %7, align 4, !dbg !189
  %45 = add nsw i32 1, %44, !dbg !190
  %46 = sext i32 %45 to i64, !dbg !187
  %47 = getelementptr inbounds [250 x double], [250 x double]* %43, i64 0, i64 %46, !dbg !187
  %48 = load double, double* %47, align 8, !dbg !187
  %49 = fadd double %39, %48, !dbg !191
  %50 = load [250 x double]*, [250 x double]** %3, align 8, !dbg !192
  %51 = load i32, i32* %6, align 4, !dbg !193
  %52 = add nsw i32 1, %51, !dbg !194
  %53 = sext i32 %52 to i64, !dbg !192
  %54 = getelementptr inbounds [250 x double], [250 x double]* %50, i64 %53, !dbg !192
  %55 = load i32, i32* %7, align 4, !dbg !195
  %56 = sext i32 %55 to i64, !dbg !192
  %57 = getelementptr inbounds [250 x double], [250 x double]* %54, i64 0, i64 %56, !dbg !192
  %58 = load double, double* %57, align 8, !dbg !192
  %59 = fadd double %49, %58, !dbg !196
  %60 = load [250 x double]*, [250 x double]** %3, align 8, !dbg !197
  %61 = load i32, i32* %6, align 4, !dbg !198
  %62 = sub nsw i32 %61, 1, !dbg !199
  %63 = sext i32 %62 to i64, !dbg !197
  %64 = getelementptr inbounds [250 x double], [250 x double]* %60, i64 %63, !dbg !197
  %65 = load i32, i32* %7, align 4, !dbg !200
  %66 = sext i32 %65 to i64, !dbg !197
  %67 = getelementptr inbounds [250 x double], [250 x double]* %64, i64 0, i64 %66, !dbg !197
  %68 = load double, double* %67, align 8, !dbg !197
  %69 = fadd double %59, %68, !dbg !201
  %70 = fmul double 2.000000e-01, %69, !dbg !202
  %71 = load [250 x double]*, [250 x double]** %4, align 8, !dbg !203
  %72 = load i32, i32* %6, align 4, !dbg !204
  %73 = sext i32 %72 to i64, !dbg !203
  %74 = getelementptr inbounds [250 x double], [250 x double]* %71, i64 %73, !dbg !203
  %75 = load i32, i32* %7, align 4, !dbg !205
  %76 = sext i32 %75 to i64, !dbg !203
  %77 = getelementptr inbounds [250 x double], [250 x double]* %74, i64 0, i64 %76, !dbg !203
  store double %70, double* %77, align 8, !dbg !206
  %78 = load i32, i32* %7, align 4, !dbg !207
  %79 = add nsw i32 %78, 1, !dbg !207
  store i32 %79, i32* %7, align 4, !dbg !207
  br label %18, !dbg !208, !llvm.loop !209

80:                                               ; preds = %18
  %81 = load i32, i32* %6, align 4, !dbg !211
  %82 = add nsw i32 %81, 1, !dbg !211
  store i32 %82, i32* %6, align 4, !dbg !211
  br label %14, !dbg !212, !llvm.loop !213

83:                                               ; preds = %14
  store i32 1, i32* %6, align 4, !dbg !215
  br label %84, !dbg !217

84:                                               ; preds = %150, %83
  %85 = load i32, i32* %6, align 4, !dbg !218
  %86 = icmp slt i32 %85, 249, !dbg !220
  br i1 %86, label %87, label %153, !dbg !221

87:                                               ; preds = %84
  store i32 1, i32* %7, align 4, !dbg !222
  br label %88, !dbg !224

88:                                               ; preds = %91, %87
  %89 = load i32, i32* %7, align 4, !dbg !225
  %90 = icmp slt i32 %89, 249, !dbg !227
  br i1 %90, label %91, label %150, !dbg !228

91:                                               ; preds = %88
  %92 = load [250 x double]*, [250 x double]** %4, align 8, !dbg !229
  %93 = load i32, i32* %6, align 4, !dbg !230
  %94 = sext i32 %93 to i64, !dbg !229
  %95 = getelementptr inbounds [250 x double], [250 x double]* %92, i64 %94, !dbg !229
  %96 = load i32, i32* %7, align 4, !dbg !231
  %97 = sext i32 %96 to i64, !dbg !229
  %98 = getelementptr inbounds [250 x double], [250 x double]* %95, i64 0, i64 %97, !dbg !229
  %99 = load double, double* %98, align 8, !dbg !229
  %100 = load [250 x double]*, [250 x double]** %4, align 8, !dbg !232
  %101 = load i32, i32* %6, align 4, !dbg !233
  %102 = sext i32 %101 to i64, !dbg !232
  %103 = getelementptr inbounds [250 x double], [250 x double]* %100, i64 %102, !dbg !232
  %104 = load i32, i32* %7, align 4, !dbg !234
  %105 = sub nsw i32 %104, 1, !dbg !235
  %106 = sext i32 %105 to i64, !dbg !232
  %107 = getelementptr inbounds [250 x double], [250 x double]* %103, i64 0, i64 %106, !dbg !232
  %108 = load double, double* %107, align 8, !dbg !232
  %109 = fadd double %99, %108, !dbg !236
  %110 = load [250 x double]*, [250 x double]** %4, align 8, !dbg !237
  %111 = load i32, i32* %6, align 4, !dbg !238
  %112 = sext i32 %111 to i64, !dbg !237
  %113 = getelementptr inbounds [250 x double], [250 x double]* %110, i64 %112, !dbg !237
  %114 = load i32, i32* %7, align 4, !dbg !239
  %115 = add nsw i32 1, %114, !dbg !240
  %116 = sext i32 %115 to i64, !dbg !237
  %117 = getelementptr inbounds [250 x double], [250 x double]* %113, i64 0, i64 %116, !dbg !237
  %118 = load double, double* %117, align 8, !dbg !237
  %119 = fadd double %109, %118, !dbg !241
  %120 = load [250 x double]*, [250 x double]** %4, align 8, !dbg !242
  %121 = load i32, i32* %6, align 4, !dbg !243
  %122 = add nsw i32 1, %121, !dbg !244
  %123 = sext i32 %122 to i64, !dbg !242
  %124 = getelementptr inbounds [250 x double], [250 x double]* %120, i64 %123, !dbg !242
  %125 = load i32, i32* %7, align 4, !dbg !245
  %126 = sext i32 %125 to i64, !dbg !242
  %127 = getelementptr inbounds [250 x double], [250 x double]* %124, i64 0, i64 %126, !dbg !242
  %128 = load double, double* %127, align 8, !dbg !242
  %129 = fadd double %119, %128, !dbg !246
  %130 = load [250 x double]*, [250 x double]** %4, align 8, !dbg !247
  %131 = load i32, i32* %6, align 4, !dbg !248
  %132 = sub nsw i32 %131, 1, !dbg !249
  %133 = sext i32 %132 to i64, !dbg !247
  %134 = getelementptr inbounds [250 x double], [250 x double]* %130, i64 %133, !dbg !247
  %135 = load i32, i32* %7, align 4, !dbg !250
  %136 = sext i32 %135 to i64, !dbg !247
  %137 = getelementptr inbounds [250 x double], [250 x double]* %134, i64 0, i64 %136, !dbg !247
  %138 = load double, double* %137, align 8, !dbg !247
  %139 = fadd double %129, %138, !dbg !251
  %140 = fmul double 2.000000e-01, %139, !dbg !252
  %141 = load [250 x double]*, [250 x double]** %3, align 8, !dbg !253
  %142 = load i32, i32* %6, align 4, !dbg !254
  %143 = sext i32 %142 to i64, !dbg !253
  %144 = getelementptr inbounds [250 x double], [250 x double]* %141, i64 %143, !dbg !253
  %145 = load i32, i32* %7, align 4, !dbg !255
  %146 = sext i32 %145 to i64, !dbg !253
  %147 = getelementptr inbounds [250 x double], [250 x double]* %144, i64 0, i64 %146, !dbg !253
  store double %140, double* %147, align 8, !dbg !256
  %148 = load i32, i32* %7, align 4, !dbg !257
  %149 = add nsw i32 %148, 1, !dbg !257
  store i32 %149, i32* %7, align 4, !dbg !257
  br label %88, !dbg !258, !llvm.loop !259

150:                                              ; preds = %88
  %151 = load i32, i32* %6, align 4, !dbg !261
  %152 = add nsw i32 %151, 1, !dbg !261
  store i32 %152, i32* %6, align 4, !dbg !261
  br label %84, !dbg !262, !llvm.loop !263

153:                                              ; preds = %84
  %154 = load i32, i32* %5, align 4, !dbg !265
  %155 = add nsw i32 %154, 1, !dbg !265
  store i32 %155, i32* %5, align 4, !dbg !265
  br label %10, !dbg !266, !llvm.loop !267

156:                                              ; preds = %10
  ret i32 0, !dbg !269
}

; Function Attrs: noinline nounwind uwtable
define dso_local i32 @workload_checksum(i32 noundef %0) #0 !dbg !270 {
  %2 = alloca i32, align 4
  store i32 %0, i32* %2, align 4
  call void @llvm.dbg.declare(metadata i32* %2, metadata !273, metadata !DIExpression()), !dbg !274
  %3 = load i32, i32* %2, align 4, !dbg !275
  store i32 -2128831035, i32* @pb_hash, align 4, !dbg !276
  %4 = load i32, i32* @n, align 4, !dbg !277
  call void @print_array(i32 noundef %4, [250 x double]* noundef getelementptr inbounds ([250 x [250 x double]], [250 x [250 x double]]* @A, i64 0, i64 0)), !dbg !278
  %5 = load i32, i32* @pb_hash, align 4, !dbg !279
  ret i32 %5, !dbg !280
}

; Function Attrs: noinline nounwind uwtable
define internal void @print_array(i32 noundef %0, [250 x double]* noundef %1) #0 !dbg !281 {
  %3 = alloca i32, align 4
  %4 = alloca [250 x double]*, align 8
  %5 = alloca i32, align 4
  %6 = alloca i32, align 4
  store i32 %0, i32* %3, align 4
  call void @llvm.dbg.declare(metadata i32* %3, metadata !284, metadata !DIExpression()), !dbg !285
  store [250 x double]* %1, [250 x double]** %4, align 8
  call void @llvm.dbg.declare(metadata [250 x double]** %4, metadata !286, metadata !DIExpression()), !dbg !287
  call void @llvm.dbg.declare(metadata i32* %5, metadata !288, metadata !DIExpression()), !dbg !289
  call void @llvm.dbg.declare(metadata i32* %6, metadata !290, metadata !DIExpression()), !dbg !291
  %7 = load %struct._IO_FILE*, %struct._IO_FILE** @stderr, align 8, !dbg !292
  %8 = call i32 (%struct._IO_FILE*, i8*, ...) @pb_fprintf(%struct._IO_FILE* noundef %7, i8* noundef getelementptr inbounds ([23 x i8], [23 x i8]* @.str.2, i64 0, i64 0)), !dbg !292
  %9 = load %struct._IO_FILE*, %struct._IO_FILE** @stderr, align 8, !dbg !293
  %10 = call i32 (%struct._IO_FILE*, i8*, ...) @pb_fprintf(%struct._IO_FILE* noundef %9, i8* noundef getelementptr inbounds ([15 x i8], [15 x i8]* @.str.3, i64 0, i64 0), i8* noundef getelementptr inbounds ([2 x i8], [2 x i8]* @.str.4, i64 0, i64 0)), !dbg !293
  store i32 0, i32* %5, align 4, !dbg !294
  br label %11, !dbg !296

11:                                               ; preds = %46, %2
  %12 = load i32, i32* %5, align 4, !dbg !297
  %13 = load i32, i32* %3, align 4, !dbg !299
  %14 = icmp slt i32 %12, %13, !dbg !300
  br i1 %14, label %15, label %49, !dbg !301

15:                                               ; preds = %11
  store i32 0, i32* %6, align 4, !dbg !302
  br label %16, !dbg !304

16:                                               ; preds = %42, %15
  %17 = load i32, i32* %6, align 4, !dbg !305
  %18 = load i32, i32* %3, align 4, !dbg !307
  %19 = icmp slt i32 %17, %18, !dbg !308
  br i1 %19, label %20, label %45, !dbg !309

20:                                               ; preds = %16
  %21 = load i32, i32* %5, align 4, !dbg !310
  %22 = load i32, i32* %3, align 4, !dbg !313
  %23 = mul nsw i32 %21, %22, !dbg !314
  %24 = load i32, i32* %6, align 4, !dbg !315
  %25 = add nsw i32 %23, %24, !dbg !316
  %26 = srem i32 %25, 20, !dbg !317
  %27 = icmp eq i32 %26, 0, !dbg !318
  br i1 %27, label %28, label %31, !dbg !319

28:                                               ; preds = %20
  %29 = load %struct._IO_FILE*, %struct._IO_FILE** @stderr, align 8, !dbg !320
  %30 = call i32 (%struct._IO_FILE*, i8*, ...) @pb_fprintf(%struct._IO_FILE* noundef %29, i8* noundef getelementptr inbounds ([2 x i8], [2 x i8]* @.str.5, i64 0, i64 0)), !dbg !321
  br label %31, !dbg !321

31:                                               ; preds = %28, %20
  %32 = load %struct._IO_FILE*, %struct._IO_FILE** @stderr, align 8, !dbg !322
  %33 = load [250 x double]*, [250 x double]** %4, align 8, !dbg !323
  %34 = load i32, i32* %5, align 4, !dbg !324
  %35 = sext i32 %34 to i64, !dbg !323
  %36 = getelementptr inbounds [250 x double], [250 x double]* %33, i64 %35, !dbg !323
  %37 = load i32, i32* %6, align 4, !dbg !325
  %38 = sext i32 %37 to i64, !dbg !323
  %39 = getelementptr inbounds [250 x double], [250 x double]* %36, i64 0, i64 %38, !dbg !323
  %40 = load double, double* %39, align 8, !dbg !323
  %41 = call i32 (%struct._IO_FILE*, i8*, ...) @pb_fprintf(%struct._IO_FILE* noundef %32, i8* noundef getelementptr inbounds ([8 x i8], [8 x i8]* @.str.6, i64 0, i64 0), double noundef %40), !dbg !326
  br label %42, !dbg !327

42:                                               ; preds = %31
  %43 = load i32, i32* %6, align 4, !dbg !328
  %44 = add nsw i32 %43, 1, !dbg !328
  store i32 %44, i32* %6, align 4, !dbg !328
  br label %16, !dbg !329, !llvm.loop !330

45:                                               ; preds = %16
  br label %46, !dbg !331

46:                                               ; preds = %45
  %47 = load i32, i32* %5, align 4, !dbg !332
  %48 = add nsw i32 %47, 1, !dbg !332
  store i32 %48, i32* %5, align 4, !dbg !332
  br label %11, !dbg !333, !llvm.loop !334

49:                                               ; preds = %11
  %50 = load %struct._IO_FILE*, %struct._IO_FILE** @stderr, align 8, !dbg !336
  %51 = call i32 (%struct._IO_FILE*, i8*, ...) @pb_fprintf(%struct._IO_FILE* noundef %50, i8* noundef getelementptr inbounds ([17 x i8], [17 x i8]* @.str.7, i64 0, i64 0), i8* noundef getelementptr inbounds ([2 x i8], [2 x i8]* @.str.4, i64 0, i64 0)), !dbg !336
  %52 = load %struct._IO_FILE*, %struct._IO_FILE** @stderr, align 8, !dbg !337
  %53 = call i32 (%struct._IO_FILE*, i8*, ...) @pb_fprintf(%struct._IO_FILE* noundef %52, i8* noundef getelementptr inbounds ([23 x i8], [23 x i8]* @.str.8, i64 0, i64 0)), !dbg !337
  ret void, !dbg !338
}

; Function Attrs: noinline nounwind uwtable
define internal i32 @pb_fprintf(%struct._IO_FILE* noundef %0, i8* noundef %1, ...) #0 !dbg !339 {
  %3 = alloca %struct._IO_FILE*, align 8
  %4 = alloca i8*, align 8
  %5 = alloca [768 x i8], align 16
  %6 = alloca [1 x %struct.__va_list_tag], align 16
  %7 = alloca i32, align 4
  %8 = alloca i32, align 4
  store %struct._IO_FILE* %0, %struct._IO_FILE** %3, align 8
  call void @llvm.dbg.declare(metadata %struct._IO_FILE** %3, metadata !403, metadata !DIExpression()), !dbg !404
  store i8* %1, i8** %4, align 8
  call void @llvm.dbg.declare(metadata i8** %4, metadata !405, metadata !DIExpression()), !dbg !406
  call void @llvm.dbg.declare(metadata [768 x i8]* %5, metadata !407, metadata !DIExpression()), !dbg !411
  call void @llvm.dbg.declare(metadata [1 x %struct.__va_list_tag]* %6, metadata !412, metadata !DIExpression()), !dbg !426
  %9 = getelementptr inbounds [1 x %struct.__va_list_tag], [1 x %struct.__va_list_tag]* %6, i64 0, i64 0, !dbg !427
  %10 = bitcast %struct.__va_list_tag* %9 to i8*, !dbg !427
  call void @llvm.va_start(i8* %10), !dbg !427
  call void @llvm.dbg.declare(metadata i32* %7, metadata !428, metadata !DIExpression()), !dbg !429
  %11 = getelementptr inbounds [768 x i8], [768 x i8]* %5, i64 0, i64 0, !dbg !430
  %12 = load i8*, i8** %4, align 8, !dbg !431
  %13 = getelementptr inbounds [1 x %struct.__va_list_tag], [1 x %struct.__va_list_tag]* %6, i64 0, i64 0, !dbg !432
  %14 = call i32 @vsnprintf(i8* noundef %11, i64 noundef 768, i8* noundef %12, %struct.__va_list_tag* noundef %13) #6, !dbg !433
  store i32 %14, i32* %7, align 4, !dbg !429
  %15 = getelementptr inbounds [1 x %struct.__va_list_tag], [1 x %struct.__va_list_tag]* %6, i64 0, i64 0, !dbg !434
  %16 = bitcast %struct.__va_list_tag* %15 to i8*, !dbg !434
  call void @llvm.va_end(i8* %16), !dbg !434
  %17 = load i32, i32* %7, align 4, !dbg !435
  %18 = icmp slt i32 %17, 0, !dbg !437
  br i1 %18, label %23, label %19, !dbg !438

19:                                               ; preds = %2
  %20 = load i32, i32* %7, align 4, !dbg !439
  %21 = zext i32 %20 to i64, !dbg !440
  %22 = icmp uge i64 %21, 768, !dbg !441
  br i1 %22, label %23, label %24, !dbg !442

23:                                               ; preds = %19, %2
  call void @abort() #7, !dbg !443
  unreachable, !dbg !443

24:                                               ; preds = %19
  call void @llvm.dbg.declare(metadata i32* %8, metadata !444, metadata !DIExpression()), !dbg !446
  store i32 0, i32* %8, align 4, !dbg !446
  br label %25, !dbg !447

25:                                               ; preds = %39, %24
  %26 = load i32, i32* %8, align 4, !dbg !448
  %27 = load i32, i32* %7, align 4, !dbg !450
  %28 = icmp slt i32 %26, %27, !dbg !451
  br i1 %28, label %29, label %42, !dbg !452

29:                                               ; preds = %25
  %30 = load i32, i32* %8, align 4, !dbg !453
  %31 = sext i32 %30 to i64, !dbg !455
  %32 = getelementptr inbounds [768 x i8], [768 x i8]* %5, i64 0, i64 %31, !dbg !455
  %33 = load i8, i8* %32, align 1, !dbg !455
  %34 = zext i8 %33 to i32, !dbg !456
  %35 = load i32, i32* @pb_hash, align 4, !dbg !457
  %36 = xor i32 %35, %34, !dbg !457
  store i32 %36, i32* @pb_hash, align 4, !dbg !457
  %37 = load i32, i32* @pb_hash, align 4, !dbg !458
  %38 = mul i32 %37, 16777619, !dbg !458
  store i32 %38, i32* @pb_hash, align 4, !dbg !458
  br label %39, !dbg !459

39:                                               ; preds = %29
  %40 = load i32, i32* %8, align 4, !dbg !460
  %41 = add nsw i32 %40, 1, !dbg !460
  store i32 %41, i32* %8, align 4, !dbg !460
  br label %25, !dbg !461, !llvm.loop !462

42:                                               ; preds = %25
  %43 = load %struct._IO_FILE*, %struct._IO_FILE** %3, align 8, !dbg !464
  %44 = load i32, i32* @pb_emit, align 4, !dbg !465
  %45 = load i32, i32* %7, align 4, !dbg !466
  ret i32 %45, !dbg !467
}

; Function Attrs: nofree nosync nounwind willreturn
declare void @llvm.va_start(i8*) #3

; Function Attrs: nounwind
declare i32 @vsnprintf(i8* noundef, i64 noundef, i8* noundef, %struct.__va_list_tag* noundef) #4

; Function Attrs: nofree nosync nounwind willreturn
declare void @llvm.va_end(i8*) #3

; Function Attrs: noreturn nounwind
declare void @abort() #5

attributes #0 = { noinline nounwind uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { nofree nosync nounwind readnone speculatable willreturn }
attributes #2 = { argmemonly nofree nounwind willreturn writeonly }
attributes #3 = { nofree nosync nounwind willreturn }
attributes #4 = { nounwind "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #5 = { noreturn nounwind "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #6 = { nounwind }
attributes #7 = { noreturn nounwind }

!llvm.dbg.cu = !{!2}
!llvm.module.flags = !{!42, !43, !44, !45, !46, !47, !48}
!llvm.ident = !{!49}

!0 = !DIGlobalVariableExpression(var: !1, expr: !DIExpression())
!1 = distinct !DIGlobalVariable(name: "n", scope: !2, file: !11, line: 99, type: !12, isLocal: false, isDefinition: true)
!2 = distinct !DICompileUnit(language: DW_LANG_C99, file: !3, producer: "Ubuntu clang version 14.0.0-1ubuntu1.1", isOptimized: false, runtimeVersion: 0, emissionKind: FullDebug, retainedTypes: !4, globals: !8, splitDebugInlining: false, nameTableKind: None)
!3 = !DIFile(filename: "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/affine-bounds-20260929/suite/jacobi-2d/source/workload.c", directory: "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/affine-bounds-20260929/suite/jacobi-2d/analysis-g", checksumkind: CSK_MD5, checksum: "ad98425665ad06f3b4a4de6b7f6bb223")
!4 = !{!5, !6, !7}
!5 = !DIBasicType(name: "double", size: 64, encoding: DW_ATE_float)
!6 = !DIBasicType(name: "unsigned int", size: 32, encoding: DW_ATE_unsigned)
!7 = !DIBasicType(name: "unsigned char", size: 8, encoding: DW_ATE_unsigned_char)
!8 = !{!0, !9, !13, !26, !30, !33, !38, !40}
!9 = !DIGlobalVariableExpression(var: !10, expr: !DIExpression())
!10 = distinct !DIGlobalVariable(name: "tsteps", scope: !2, file: !11, line: 100, type: !12, isLocal: false, isDefinition: true)
!11 = !DIFile(filename: "source/workload.c", directory: "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/affine-bounds-20260929/suite/jacobi-2d", checksumkind: CSK_MD5, checksum: "ad98425665ad06f3b4a4de6b7f6bb223")
!12 = !DIBasicType(name: "int", size: 32, encoding: DW_ATE_signed)
!13 = !DIGlobalVariableExpression(var: !14, expr: !DIExpression())
!14 = distinct !DIGlobalVariable(name: "workload_jobs", scope: !2, file: !11, line: 118, type: !15, isLocal: false, isDefinition: true)
!15 = !DICompositeType(tag: DW_TAG_array_type, baseType: !16, size: 64, elements: !24)
!16 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !17)
!17 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !18, size: 64)
!18 = !DISubroutineType(types: !19)
!19 = !{!20}
!20 = !DIDerivedType(tag: DW_TAG_typedef, name: "uint32_t", file: !21, line: 26, baseType: !22)
!21 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/stdint-uintn.h", directory: "", checksumkind: CSK_MD5, checksum: "2bf2ae53c58c01b1a1b9383b5195125c")
!22 = !DIDerivedType(tag: DW_TAG_typedef, name: "__uint32_t", file: !23, line: 42, baseType: !6)
!23 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/types.h", directory: "", checksumkind: CSK_MD5, checksum: "d108b5f93a74c50510d7d9bc0ab36df9")
!24 = !{!25}
!25 = !DISubrange(count: 1)
!26 = !DIGlobalVariableExpression(var: !27, expr: !DIExpression())
!27 = distinct !DIGlobalVariable(name: "workload_expected", scope: !2, file: !11, line: 122, type: !28, isLocal: false, isDefinition: true)
!28 = !DICompositeType(tag: DW_TAG_array_type, baseType: !29, size: 32, elements: !24)
!29 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !20)
!30 = !DIGlobalVariableExpression(var: !31, expr: !DIExpression())
!31 = distinct !DIGlobalVariable(name: "pb_hash", scope: !2, file: !32, line: 9, type: !20, isLocal: true, isDefinition: true)
!32 = !DIFile(filename: "source/adapter.h", directory: "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/affine-bounds-20260929/suite/jacobi-2d", checksumkind: CSK_MD5, checksum: "26a6068928b2092758f244a9d00163d7")
!33 = !DIGlobalVariableExpression(var: !34, expr: !DIExpression())
!34 = distinct !DIGlobalVariable(name: "A", scope: !2, file: !11, line: 34, type: !35, isLocal: false, isDefinition: true, align: 512)
!35 = !DICompositeType(tag: DW_TAG_array_type, baseType: !5, size: 4000000, elements: !36)
!36 = !{!37, !37}
!37 = !DISubrange(count: 250)
!38 = !DIGlobalVariableExpression(var: !39, expr: !DIExpression())
!39 = distinct !DIGlobalVariable(name: "B", scope: !2, file: !11, line: 35, type: !35, isLocal: false, isDefinition: true, align: 512)
!40 = !DIGlobalVariableExpression(var: !41, expr: !DIExpression())
!41 = distinct !DIGlobalVariable(name: "pb_emit", scope: !2, file: !32, line: 10, type: !12, isLocal: true, isDefinition: true)
!42 = !{i32 7, !"Dwarf Version", i32 5}
!43 = !{i32 2, !"Debug Info Version", i32 3}
!44 = !{i32 1, !"wchar_size", i32 4}
!45 = !{i32 7, !"PIC Level", i32 2}
!46 = !{i32 7, !"PIE Level", i32 2}
!47 = !{i32 7, !"uwtable", i32 1}
!48 = !{i32 7, !"frame-pointer", i32 2}
!49 = !{!"Ubuntu clang version 14.0.0-1ubuntu1.1"}
!50 = distinct !DISubprogram(name: "workload_prepare", scope: !11, file: !11, line: 101, type: !51, scopeLine: 101, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !2, retainedNodes: !53)
!51 = !DISubroutineType(types: !52)
!52 = !{null}
!53 = !{}
!54 = !DILocation(line: 101, column: 30, scope: !50)
!55 = distinct !DISubprogram(name: "workload_reset", scope: !11, file: !11, line: 102, type: !56, scopeLine: 102, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !2, retainedNodes: !53)
!56 = !DISubroutineType(types: !57)
!57 = !{null, !6}
!58 = !DILocalVariable(name: "task", arg: 1, scope: !55, file: !11, line: 102, type: !6)
!59 = !DILocation(line: 102, column: 30, scope: !55)
!60 = !DILocation(line: 103, column: 9, scope: !55)
!61 = !DILocation(line: 104, column: 3, scope: !55)
!62 = !DILocation(line: 105, column: 3, scope: !55)
!63 = !DILocation(line: 106, column: 15, scope: !55)
!64 = !DILocation(line: 106, column: 3, scope: !55)
!65 = !DILocation(line: 107, column: 1, scope: !55)
!66 = distinct !DISubprogram(name: "init_array", scope: !11, file: !11, line: 37, type: !67, scopeLine: 40, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition, unit: !2, retainedNodes: !53)
!67 = !DISubroutineType(types: !68)
!68 = !{null, !12, !69, !69}
!69 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !70, size: 64)
!70 = !DICompositeType(tag: DW_TAG_array_type, baseType: !5, size: 16000, elements: !71)
!71 = !{!37}
!72 = !DILocalVariable(name: "n", arg: 1, scope: !66, file: !11, line: 37, type: !12)
!73 = !DILocation(line: 37, column: 22, scope: !66)
!74 = !DILocalVariable(name: "A", arg: 2, scope: !66, file: !11, line: 38, type: !69)
!75 = !DILocation(line: 38, column: 14, scope: !66)
!76 = !DILocalVariable(name: "B", arg: 3, scope: !66, file: !11, line: 39, type: !69)
!77 = !DILocation(line: 39, column: 14, scope: !66)
!78 = !DILocalVariable(name: "i", scope: !66, file: !11, line: 41, type: !12)
!79 = !DILocation(line: 41, column: 7, scope: !66)
!80 = !DILocalVariable(name: "j", scope: !66, file: !11, line: 41, type: !12)
!81 = !DILocation(line: 41, column: 10, scope: !66)
!82 = !DILocation(line: 43, column: 10, scope: !83)
!83 = distinct !DILexicalBlock(scope: !66, file: !11, line: 43, column: 3)
!84 = !DILocation(line: 43, column: 8, scope: !83)
!85 = !DILocation(line: 43, column: 15, scope: !86)
!86 = distinct !DILexicalBlock(scope: !83, file: !11, line: 43, column: 3)
!87 = !DILocation(line: 43, column: 19, scope: !86)
!88 = !DILocation(line: 43, column: 17, scope: !86)
!89 = !DILocation(line: 43, column: 3, scope: !83)
!90 = !DILocation(line: 44, column: 12, scope: !91)
!91 = distinct !DILexicalBlock(scope: !86, file: !11, line: 44, column: 5)
!92 = !DILocation(line: 44, column: 10, scope: !91)
!93 = !DILocation(line: 44, column: 17, scope: !94)
!94 = distinct !DILexicalBlock(scope: !91, file: !11, line: 44, column: 5)
!95 = !DILocation(line: 44, column: 21, scope: !94)
!96 = !DILocation(line: 44, column: 19, scope: !94)
!97 = !DILocation(line: 44, column: 5, scope: !91)
!98 = !DILocation(line: 46, column: 25, scope: !99)
!99 = distinct !DILexicalBlock(scope: !94, file: !11, line: 45, column: 7)
!100 = !DILocation(line: 46, column: 13, scope: !99)
!101 = !DILocation(line: 46, column: 28, scope: !99)
!102 = !DILocation(line: 46, column: 29, scope: !99)
!103 = !DILocation(line: 46, column: 27, scope: !99)
!104 = !DILocation(line: 46, column: 26, scope: !99)
!105 = !DILocation(line: 46, column: 33, scope: !99)
!106 = !DILocation(line: 46, column: 40, scope: !99)
!107 = !DILocation(line: 46, column: 38, scope: !99)
!108 = !DILocation(line: 46, column: 2, scope: !99)
!109 = !DILocation(line: 46, column: 4, scope: !99)
!110 = !DILocation(line: 46, column: 7, scope: !99)
!111 = !DILocation(line: 46, column: 10, scope: !99)
!112 = !DILocation(line: 47, column: 25, scope: !99)
!113 = !DILocation(line: 47, column: 13, scope: !99)
!114 = !DILocation(line: 47, column: 28, scope: !99)
!115 = !DILocation(line: 47, column: 29, scope: !99)
!116 = !DILocation(line: 47, column: 27, scope: !99)
!117 = !DILocation(line: 47, column: 26, scope: !99)
!118 = !DILocation(line: 47, column: 33, scope: !99)
!119 = !DILocation(line: 47, column: 40, scope: !99)
!120 = !DILocation(line: 47, column: 38, scope: !99)
!121 = !DILocation(line: 47, column: 2, scope: !99)
!122 = !DILocation(line: 47, column: 4, scope: !99)
!123 = !DILocation(line: 47, column: 7, scope: !99)
!124 = !DILocation(line: 47, column: 10, scope: !99)
!125 = !DILocation(line: 48, column: 7, scope: !99)
!126 = !DILocation(line: 44, column: 25, scope: !94)
!127 = !DILocation(line: 44, column: 5, scope: !94)
!128 = distinct !{!128, !97, !129, !130}
!129 = !DILocation(line: 48, column: 7, scope: !91)
!130 = !{!"llvm.loop.mustprogress"}
!131 = !DILocation(line: 43, column: 23, scope: !86)
!132 = !DILocation(line: 43, column: 3, scope: !86)
!133 = distinct !{!133, !89, !134, !130}
!134 = !DILocation(line: 48, column: 7, scope: !83)
!135 = !DILocation(line: 49, column: 1, scope: !66)
!136 = distinct !DISubprogram(name: "task_job_polybench", scope: !11, file: !11, line: 108, type: !18, scopeLine: 108, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !2, retainedNodes: !53)
!137 = !DILocation(line: 109, column: 20, scope: !136)
!138 = !DILocation(line: 109, column: 28, scope: !136)
!139 = !DILocalVariable(name: "tsteps", arg: 1, scope: !140, file: !11, line: 76, type: !12)
!140 = distinct !DISubprogram(name: "kernel_jacobi_2d", scope: !11, file: !11, line: 76, type: !141, scopeLine: 80, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition, unit: !2, retainedNodes: !53)
!141 = !DISubroutineType(types: !142)
!142 = !{null, !12, !12, !69, !69}
!143 = !DILocation(line: 76, column: 65, scope: !140, inlinedAt: !144)
!144 = distinct !DILocation(line: 109, column: 3, scope: !136)
!145 = !DILocalVariable(name: "n", arg: 2, scope: !140, file: !11, line: 77, type: !12)
!146 = !DILocation(line: 77, column: 12, scope: !140, inlinedAt: !144)
!147 = !DILocalVariable(name: "A", arg: 3, scope: !140, file: !11, line: 78, type: !69)
!148 = !DILocation(line: 78, column: 18, scope: !140, inlinedAt: !144)
!149 = !DILocalVariable(name: "B", arg: 4, scope: !140, file: !11, line: 79, type: !69)
!150 = !DILocation(line: 79, column: 18, scope: !140, inlinedAt: !144)
!151 = !DILocalVariable(name: "t", scope: !140, file: !11, line: 81, type: !12)
!152 = !DILocation(line: 81, column: 7, scope: !140, inlinedAt: !144)
!153 = !DILocalVariable(name: "i", scope: !140, file: !11, line: 81, type: !12)
!154 = !DILocation(line: 81, column: 10, scope: !140, inlinedAt: !144)
!155 = !DILocalVariable(name: "j", scope: !140, file: !11, line: 81, type: !12)
!156 = !DILocation(line: 81, column: 13, scope: !140, inlinedAt: !144)
!157 = !DILocation(line: 84, column: 10, scope: !158, inlinedAt: !144)
!158 = distinct !DILexicalBlock(scope: !140, file: !11, line: 84, column: 3)
!159 = !DILocation(line: 84, column: 8, scope: !158, inlinedAt: !144)
!160 = !DILocation(line: 84, column: 15, scope: !161, inlinedAt: !144)
!161 = distinct !DILexicalBlock(scope: !158, file: !11, line: 84, column: 3)
!162 = !DILocation(line: 84, column: 17, scope: !161, inlinedAt: !144)
!163 = !DILocation(line: 84, column: 3, scope: !158, inlinedAt: !144)
!164 = !DILocation(line: 86, column: 14, scope: !165, inlinedAt: !144)
!165 = distinct !DILexicalBlock(scope: !166, file: !11, line: 86, column: 7)
!166 = distinct !DILexicalBlock(scope: !161, file: !11, line: 85, column: 5)
!167 = !DILocation(line: 86, column: 12, scope: !165, inlinedAt: !144)
!168 = !DILocation(line: 86, column: 19, scope: !169, inlinedAt: !144)
!169 = distinct !DILexicalBlock(scope: !165, file: !11, line: 86, column: 7)
!170 = !DILocation(line: 86, column: 21, scope: !169, inlinedAt: !144)
!171 = !DILocation(line: 86, column: 7, scope: !165, inlinedAt: !144)
!172 = !DILocation(line: 87, column: 9, scope: !173, inlinedAt: !144)
!173 = distinct !DILexicalBlock(scope: !169, file: !11, line: 87, column: 2)
!174 = !DILocation(line: 87, column: 7, scope: !173, inlinedAt: !144)
!175 = !DILocation(line: 87, column: 14, scope: !176, inlinedAt: !144)
!176 = distinct !DILexicalBlock(scope: !173, file: !11, line: 87, column: 2)
!177 = !DILocation(line: 87, column: 16, scope: !176, inlinedAt: !144)
!178 = !DILocation(line: 87, column: 2, scope: !173, inlinedAt: !144)
!179 = !DILocation(line: 88, column: 33, scope: !176, inlinedAt: !144)
!180 = !DILocation(line: 88, column: 35, scope: !176, inlinedAt: !144)
!181 = !DILocation(line: 88, column: 38, scope: !176, inlinedAt: !144)
!182 = !DILocation(line: 88, column: 43, scope: !176, inlinedAt: !144)
!183 = !DILocation(line: 88, column: 45, scope: !176, inlinedAt: !144)
!184 = !DILocation(line: 88, column: 48, scope: !176, inlinedAt: !144)
!185 = !DILocation(line: 88, column: 49, scope: !176, inlinedAt: !144)
!186 = !DILocation(line: 88, column: 41, scope: !176, inlinedAt: !144)
!187 = !DILocation(line: 88, column: 55, scope: !176, inlinedAt: !144)
!188 = !DILocation(line: 88, column: 57, scope: !176, inlinedAt: !144)
!189 = !DILocation(line: 88, column: 62, scope: !176, inlinedAt: !144)
!190 = !DILocation(line: 88, column: 61, scope: !176, inlinedAt: !144)
!191 = !DILocation(line: 88, column: 53, scope: !176, inlinedAt: !144)
!192 = !DILocation(line: 88, column: 67, scope: !176, inlinedAt: !144)
!193 = !DILocation(line: 88, column: 71, scope: !176, inlinedAt: !144)
!194 = !DILocation(line: 88, column: 70, scope: !176, inlinedAt: !144)
!195 = !DILocation(line: 88, column: 74, scope: !176, inlinedAt: !144)
!196 = !DILocation(line: 88, column: 65, scope: !176, inlinedAt: !144)
!197 = !DILocation(line: 88, column: 79, scope: !176, inlinedAt: !144)
!198 = !DILocation(line: 88, column: 81, scope: !176, inlinedAt: !144)
!199 = !DILocation(line: 88, column: 82, scope: !176, inlinedAt: !144)
!200 = !DILocation(line: 88, column: 86, scope: !176, inlinedAt: !144)
!201 = !DILocation(line: 88, column: 77, scope: !176, inlinedAt: !144)
!202 = !DILocation(line: 88, column: 30, scope: !176, inlinedAt: !144)
!203 = !DILocation(line: 88, column: 4, scope: !176, inlinedAt: !144)
!204 = !DILocation(line: 88, column: 6, scope: !176, inlinedAt: !144)
!205 = !DILocation(line: 88, column: 9, scope: !176, inlinedAt: !144)
!206 = !DILocation(line: 88, column: 12, scope: !176, inlinedAt: !144)
!207 = !DILocation(line: 87, column: 30, scope: !176, inlinedAt: !144)
!208 = !DILocation(line: 87, column: 2, scope: !176, inlinedAt: !144)
!209 = distinct !{!209, !178, !210, !130}
!210 = !DILocation(line: 88, column: 88, scope: !173, inlinedAt: !144)
!211 = !DILocation(line: 86, column: 35, scope: !169, inlinedAt: !144)
!212 = !DILocation(line: 86, column: 7, scope: !169, inlinedAt: !144)
!213 = distinct !{!213, !171, !214, !130}
!214 = !DILocation(line: 88, column: 88, scope: !165, inlinedAt: !144)
!215 = !DILocation(line: 89, column: 14, scope: !216, inlinedAt: !144)
!216 = distinct !DILexicalBlock(scope: !166, file: !11, line: 89, column: 7)
!217 = !DILocation(line: 89, column: 12, scope: !216, inlinedAt: !144)
!218 = !DILocation(line: 89, column: 19, scope: !219, inlinedAt: !144)
!219 = distinct !DILexicalBlock(scope: !216, file: !11, line: 89, column: 7)
!220 = !DILocation(line: 89, column: 21, scope: !219, inlinedAt: !144)
!221 = !DILocation(line: 89, column: 7, scope: !216, inlinedAt: !144)
!222 = !DILocation(line: 90, column: 9, scope: !223, inlinedAt: !144)
!223 = distinct !DILexicalBlock(scope: !219, file: !11, line: 90, column: 2)
!224 = !DILocation(line: 90, column: 7, scope: !223, inlinedAt: !144)
!225 = !DILocation(line: 90, column: 14, scope: !226, inlinedAt: !144)
!226 = distinct !DILexicalBlock(scope: !223, file: !11, line: 90, column: 2)
!227 = !DILocation(line: 90, column: 16, scope: !226, inlinedAt: !144)
!228 = !DILocation(line: 90, column: 2, scope: !223, inlinedAt: !144)
!229 = !DILocation(line: 91, column: 33, scope: !226, inlinedAt: !144)
!230 = !DILocation(line: 91, column: 35, scope: !226, inlinedAt: !144)
!231 = !DILocation(line: 91, column: 38, scope: !226, inlinedAt: !144)
!232 = !DILocation(line: 91, column: 43, scope: !226, inlinedAt: !144)
!233 = !DILocation(line: 91, column: 45, scope: !226, inlinedAt: !144)
!234 = !DILocation(line: 91, column: 48, scope: !226, inlinedAt: !144)
!235 = !DILocation(line: 91, column: 49, scope: !226, inlinedAt: !144)
!236 = !DILocation(line: 91, column: 41, scope: !226, inlinedAt: !144)
!237 = !DILocation(line: 91, column: 55, scope: !226, inlinedAt: !144)
!238 = !DILocation(line: 91, column: 57, scope: !226, inlinedAt: !144)
!239 = !DILocation(line: 91, column: 62, scope: !226, inlinedAt: !144)
!240 = !DILocation(line: 91, column: 61, scope: !226, inlinedAt: !144)
!241 = !DILocation(line: 91, column: 53, scope: !226, inlinedAt: !144)
!242 = !DILocation(line: 91, column: 67, scope: !226, inlinedAt: !144)
!243 = !DILocation(line: 91, column: 71, scope: !226, inlinedAt: !144)
!244 = !DILocation(line: 91, column: 70, scope: !226, inlinedAt: !144)
!245 = !DILocation(line: 91, column: 74, scope: !226, inlinedAt: !144)
!246 = !DILocation(line: 91, column: 65, scope: !226, inlinedAt: !144)
!247 = !DILocation(line: 91, column: 79, scope: !226, inlinedAt: !144)
!248 = !DILocation(line: 91, column: 81, scope: !226, inlinedAt: !144)
!249 = !DILocation(line: 91, column: 82, scope: !226, inlinedAt: !144)
!250 = !DILocation(line: 91, column: 86, scope: !226, inlinedAt: !144)
!251 = !DILocation(line: 91, column: 77, scope: !226, inlinedAt: !144)
!252 = !DILocation(line: 91, column: 30, scope: !226, inlinedAt: !144)
!253 = !DILocation(line: 91, column: 4, scope: !226, inlinedAt: !144)
!254 = !DILocation(line: 91, column: 6, scope: !226, inlinedAt: !144)
!255 = !DILocation(line: 91, column: 9, scope: !226, inlinedAt: !144)
!256 = !DILocation(line: 91, column: 12, scope: !226, inlinedAt: !144)
!257 = !DILocation(line: 90, column: 30, scope: !226, inlinedAt: !144)
!258 = !DILocation(line: 90, column: 2, scope: !226, inlinedAt: !144)
!259 = distinct !{!259, !228, !260, !130}
!260 = !DILocation(line: 91, column: 88, scope: !223, inlinedAt: !144)
!261 = !DILocation(line: 89, column: 35, scope: !219, inlinedAt: !144)
!262 = !DILocation(line: 89, column: 7, scope: !219, inlinedAt: !144)
!263 = distinct !{!263, !221, !264, !130}
!264 = !DILocation(line: 91, column: 88, scope: !216, inlinedAt: !144)
!265 = !DILocation(line: 84, column: 32, scope: !161, inlinedAt: !144)
!266 = !DILocation(line: 84, column: 3, scope: !161, inlinedAt: !144)
!267 = distinct !{!267, !163, !268, !130}
!268 = !DILocation(line: 92, column: 5, scope: !158, inlinedAt: !144)
!269 = !DILocation(line: 110, column: 3, scope: !136)
!270 = distinct !DISubprogram(name: "workload_checksum", scope: !11, file: !11, line: 112, type: !271, scopeLine: 112, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !2, retainedNodes: !53)
!271 = !DISubroutineType(types: !272)
!272 = !{!20, !6}
!273 = !DILocalVariable(name: "task", arg: 1, scope: !270, file: !11, line: 112, type: !6)
!274 = !DILocation(line: 112, column: 37, scope: !270)
!275 = !DILocation(line: 113, column: 9, scope: !270)
!276 = !DILocation(line: 114, column: 11, scope: !270)
!277 = !DILocation(line: 115, column: 15, scope: !270)
!278 = !DILocation(line: 115, column: 3, scope: !270)
!279 = !DILocation(line: 116, column: 10, scope: !270)
!280 = !DILocation(line: 116, column: 3, scope: !270)
!281 = distinct !DISubprogram(name: "print_array", scope: !11, file: !11, line: 55, type: !282, scopeLine: 58, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition, unit: !2, retainedNodes: !53)
!282 = !DISubroutineType(types: !283)
!283 = !{null, !12, !69}
!284 = !DILocalVariable(name: "n", arg: 1, scope: !281, file: !11, line: 55, type: !12)
!285 = !DILocation(line: 55, column: 22, scope: !281)
!286 = !DILocalVariable(name: "A", arg: 2, scope: !281, file: !11, line: 56, type: !69)
!287 = !DILocation(line: 56, column: 14, scope: !281)
!288 = !DILocalVariable(name: "i", scope: !281, file: !11, line: 59, type: !12)
!289 = !DILocation(line: 59, column: 7, scope: !281)
!290 = !DILocalVariable(name: "j", scope: !281, file: !11, line: 59, type: !12)
!291 = !DILocation(line: 59, column: 10, scope: !281)
!292 = !DILocation(line: 61, column: 3, scope: !281)
!293 = !DILocation(line: 62, column: 3, scope: !281)
!294 = !DILocation(line: 63, column: 10, scope: !295)
!295 = distinct !DILexicalBlock(scope: !281, file: !11, line: 63, column: 3)
!296 = !DILocation(line: 63, column: 8, scope: !295)
!297 = !DILocation(line: 63, column: 15, scope: !298)
!298 = distinct !DILexicalBlock(scope: !295, file: !11, line: 63, column: 3)
!299 = !DILocation(line: 63, column: 19, scope: !298)
!300 = !DILocation(line: 63, column: 17, scope: !298)
!301 = !DILocation(line: 63, column: 3, scope: !295)
!302 = !DILocation(line: 64, column: 12, scope: !303)
!303 = distinct !DILexicalBlock(scope: !298, file: !11, line: 64, column: 5)
!304 = !DILocation(line: 64, column: 10, scope: !303)
!305 = !DILocation(line: 64, column: 17, scope: !306)
!306 = distinct !DILexicalBlock(scope: !303, file: !11, line: 64, column: 5)
!307 = !DILocation(line: 64, column: 21, scope: !306)
!308 = !DILocation(line: 64, column: 19, scope: !306)
!309 = !DILocation(line: 64, column: 5, scope: !303)
!310 = !DILocation(line: 65, column: 12, scope: !311)
!311 = distinct !DILexicalBlock(scope: !312, file: !11, line: 65, column: 11)
!312 = distinct !DILexicalBlock(scope: !306, file: !11, line: 64, column: 29)
!313 = !DILocation(line: 65, column: 16, scope: !311)
!314 = !DILocation(line: 65, column: 14, scope: !311)
!315 = !DILocation(line: 65, column: 20, scope: !311)
!316 = !DILocation(line: 65, column: 18, scope: !311)
!317 = !DILocation(line: 65, column: 23, scope: !311)
!318 = !DILocation(line: 65, column: 28, scope: !311)
!319 = !DILocation(line: 65, column: 11, scope: !312)
!320 = !DILocation(line: 65, column: 42, scope: !311)
!321 = !DILocation(line: 65, column: 34, scope: !311)
!322 = !DILocation(line: 66, column: 15, scope: !312)
!323 = !DILocation(line: 66, column: 60, scope: !312)
!324 = !DILocation(line: 66, column: 62, scope: !312)
!325 = !DILocation(line: 66, column: 65, scope: !312)
!326 = !DILocation(line: 66, column: 7, scope: !312)
!327 = !DILocation(line: 67, column: 5, scope: !312)
!328 = !DILocation(line: 64, column: 25, scope: !306)
!329 = !DILocation(line: 64, column: 5, scope: !306)
!330 = distinct !{!330, !309, !331, !130}
!331 = !DILocation(line: 67, column: 5, scope: !303)
!332 = !DILocation(line: 63, column: 23, scope: !298)
!333 = !DILocation(line: 63, column: 3, scope: !298)
!334 = distinct !{!334, !301, !335, !130}
!335 = !DILocation(line: 67, column: 5, scope: !295)
!336 = !DILocation(line: 68, column: 3, scope: !281)
!337 = !DILocation(line: 69, column: 3, scope: !281)
!338 = !DILocation(line: 70, column: 1, scope: !281)
!339 = distinct !DISubprogram(name: "pb_fprintf", scope: !32, file: !32, line: 13, type: !340, scopeLine: 14, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition, unit: !2, retainedNodes: !53)
!340 = !DISubroutineType(types: !341)
!341 = !{!12, !342, !401, null}
!342 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !343, size: 64)
!343 = !DIDerivedType(tag: DW_TAG_typedef, name: "FILE", file: !344, line: 7, baseType: !345)
!344 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/types/FILE.h", directory: "", checksumkind: CSK_MD5, checksum: "571f9fb6223c42439075fdde11a0de5d")
!345 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "_IO_FILE", file: !346, line: 49, size: 1728, elements: !347)
!346 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/types/struct_FILE.h", directory: "", checksumkind: CSK_MD5, checksum: "1bad07471b7974df4ecc1d1c2ca207e6")
!347 = !{!348, !349, !352, !353, !354, !355, !356, !357, !358, !359, !360, !361, !362, !365, !367, !368, !369, !372, !374, !376, !378, !381, !383, !386, !389, !390, !392, !396, !397}
!348 = !DIDerivedType(tag: DW_TAG_member, name: "_flags", scope: !345, file: !346, line: 51, baseType: !12, size: 32)
!349 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_read_ptr", scope: !345, file: !346, line: 54, baseType: !350, size: 64, offset: 64)
!350 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !351, size: 64)
!351 = !DIBasicType(name: "char", size: 8, encoding: DW_ATE_signed_char)
!352 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_read_end", scope: !345, file: !346, line: 55, baseType: !350, size: 64, offset: 128)
!353 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_read_base", scope: !345, file: !346, line: 56, baseType: !350, size: 64, offset: 192)
!354 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_write_base", scope: !345, file: !346, line: 57, baseType: !350, size: 64, offset: 256)
!355 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_write_ptr", scope: !345, file: !346, line: 58, baseType: !350, size: 64, offset: 320)
!356 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_write_end", scope: !345, file: !346, line: 59, baseType: !350, size: 64, offset: 384)
!357 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_buf_base", scope: !345, file: !346, line: 60, baseType: !350, size: 64, offset: 448)
!358 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_buf_end", scope: !345, file: !346, line: 61, baseType: !350, size: 64, offset: 512)
!359 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_save_base", scope: !345, file: !346, line: 64, baseType: !350, size: 64, offset: 576)
!360 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_backup_base", scope: !345, file: !346, line: 65, baseType: !350, size: 64, offset: 640)
!361 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_save_end", scope: !345, file: !346, line: 66, baseType: !350, size: 64, offset: 704)
!362 = !DIDerivedType(tag: DW_TAG_member, name: "_markers", scope: !345, file: !346, line: 68, baseType: !363, size: 64, offset: 768)
!363 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !364, size: 64)
!364 = !DICompositeType(tag: DW_TAG_structure_type, name: "_IO_marker", file: !346, line: 36, flags: DIFlagFwdDecl)
!365 = !DIDerivedType(tag: DW_TAG_member, name: "_chain", scope: !345, file: !346, line: 70, baseType: !366, size: 64, offset: 832)
!366 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !345, size: 64)
!367 = !DIDerivedType(tag: DW_TAG_member, name: "_fileno", scope: !345, file: !346, line: 72, baseType: !12, size: 32, offset: 896)
!368 = !DIDerivedType(tag: DW_TAG_member, name: "_flags2", scope: !345, file: !346, line: 73, baseType: !12, size: 32, offset: 928)
!369 = !DIDerivedType(tag: DW_TAG_member, name: "_old_offset", scope: !345, file: !346, line: 74, baseType: !370, size: 64, offset: 960)
!370 = !DIDerivedType(tag: DW_TAG_typedef, name: "__off_t", file: !23, line: 152, baseType: !371)
!371 = !DIBasicType(name: "long", size: 64, encoding: DW_ATE_signed)
!372 = !DIDerivedType(tag: DW_TAG_member, name: "_cur_column", scope: !345, file: !346, line: 77, baseType: !373, size: 16, offset: 1024)
!373 = !DIBasicType(name: "unsigned short", size: 16, encoding: DW_ATE_unsigned)
!374 = !DIDerivedType(tag: DW_TAG_member, name: "_vtable_offset", scope: !345, file: !346, line: 78, baseType: !375, size: 8, offset: 1040)
!375 = !DIBasicType(name: "signed char", size: 8, encoding: DW_ATE_signed_char)
!376 = !DIDerivedType(tag: DW_TAG_member, name: "_shortbuf", scope: !345, file: !346, line: 79, baseType: !377, size: 8, offset: 1048)
!377 = !DICompositeType(tag: DW_TAG_array_type, baseType: !351, size: 8, elements: !24)
!378 = !DIDerivedType(tag: DW_TAG_member, name: "_lock", scope: !345, file: !346, line: 81, baseType: !379, size: 64, offset: 1088)
!379 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !380, size: 64)
!380 = !DIDerivedType(tag: DW_TAG_typedef, name: "_IO_lock_t", file: !346, line: 43, baseType: null)
!381 = !DIDerivedType(tag: DW_TAG_member, name: "_offset", scope: !345, file: !346, line: 89, baseType: !382, size: 64, offset: 1152)
!382 = !DIDerivedType(tag: DW_TAG_typedef, name: "__off64_t", file: !23, line: 153, baseType: !371)
!383 = !DIDerivedType(tag: DW_TAG_member, name: "_codecvt", scope: !345, file: !346, line: 91, baseType: !384, size: 64, offset: 1216)
!384 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !385, size: 64)
!385 = !DICompositeType(tag: DW_TAG_structure_type, name: "_IO_codecvt", file: !346, line: 37, flags: DIFlagFwdDecl)
!386 = !DIDerivedType(tag: DW_TAG_member, name: "_wide_data", scope: !345, file: !346, line: 92, baseType: !387, size: 64, offset: 1280)
!387 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !388, size: 64)
!388 = !DICompositeType(tag: DW_TAG_structure_type, name: "_IO_wide_data", file: !346, line: 38, flags: DIFlagFwdDecl)
!389 = !DIDerivedType(tag: DW_TAG_member, name: "_freeres_list", scope: !345, file: !346, line: 93, baseType: !366, size: 64, offset: 1344)
!390 = !DIDerivedType(tag: DW_TAG_member, name: "_freeres_buf", scope: !345, file: !346, line: 94, baseType: !391, size: 64, offset: 1408)
!391 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: null, size: 64)
!392 = !DIDerivedType(tag: DW_TAG_member, name: "__pad5", scope: !345, file: !346, line: 95, baseType: !393, size: 64, offset: 1472)
!393 = !DIDerivedType(tag: DW_TAG_typedef, name: "size_t", file: !394, line: 46, baseType: !395)
!394 = !DIFile(filename: "/usr/lib/llvm-14/lib/clang/14.0.0/include/stddef.h", directory: "", checksumkind: CSK_MD5, checksum: "2499dd2361b915724b073282bea3a7bc")
!395 = !DIBasicType(name: "unsigned long", size: 64, encoding: DW_ATE_unsigned)
!396 = !DIDerivedType(tag: DW_TAG_member, name: "_mode", scope: !345, file: !346, line: 96, baseType: !12, size: 32, offset: 1536)
!397 = !DIDerivedType(tag: DW_TAG_member, name: "_unused2", scope: !345, file: !346, line: 98, baseType: !398, size: 160, offset: 1568)
!398 = !DICompositeType(tag: DW_TAG_array_type, baseType: !351, size: 160, elements: !399)
!399 = !{!400}
!400 = !DISubrange(count: 20)
!401 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !402, size: 64)
!402 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !351)
!403 = !DILocalVariable(name: "stream", arg: 1, scope: !339, file: !32, line: 13, type: !342)
!404 = !DILocation(line: 13, column: 29, scope: !339)
!405 = !DILocalVariable(name: "format", arg: 2, scope: !339, file: !32, line: 13, type: !401)
!406 = !DILocation(line: 13, column: 49, scope: !339)
!407 = !DILocalVariable(name: "buffer", scope: !339, file: !32, line: 15, type: !408)
!408 = !DICompositeType(tag: DW_TAG_array_type, baseType: !351, size: 6144, elements: !409)
!409 = !{!410}
!410 = !DISubrange(count: 768)
!411 = !DILocation(line: 15, column: 10, scope: !339)
!412 = !DILocalVariable(name: "args", scope: !339, file: !32, line: 16, type: !413)
!413 = !DIDerivedType(tag: DW_TAG_typedef, name: "va_list", file: !414, line: 52, baseType: !415)
!414 = !DIFile(filename: "/usr/include/stdio.h", directory: "", checksumkind: CSK_MD5, checksum: "f31eefcc3f15835fc5a4023a625cf609")
!415 = !DIDerivedType(tag: DW_TAG_typedef, name: "__gnuc_va_list", file: !416, line: 32, baseType: !417)
!416 = !DIFile(filename: "/usr/lib/llvm-14/lib/clang/14.0.0/include/stdarg.h", directory: "", checksumkind: CSK_MD5, checksum: "4de3cbd931b589d291e5c39387aecf82")
!417 = !DIDerivedType(tag: DW_TAG_typedef, name: "__builtin_va_list", file: !418, baseType: !419)
!418 = !DIFile(filename: "source/workload.c", directory: "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/affine-bounds-20260929/suite/jacobi-2d")
!419 = !DICompositeType(tag: DW_TAG_array_type, baseType: !420, size: 192, elements: !24)
!420 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "__va_list_tag", size: 192, elements: !421)
!421 = !{!422, !423, !424, !425}
!422 = !DIDerivedType(tag: DW_TAG_member, name: "gp_offset", scope: !420, file: !418, line: 16, baseType: !6, size: 32)
!423 = !DIDerivedType(tag: DW_TAG_member, name: "fp_offset", scope: !420, file: !418, line: 16, baseType: !6, size: 32, offset: 32)
!424 = !DIDerivedType(tag: DW_TAG_member, name: "overflow_arg_area", scope: !420, file: !418, line: 16, baseType: !391, size: 64, offset: 64)
!425 = !DIDerivedType(tag: DW_TAG_member, name: "reg_save_area", scope: !420, file: !418, line: 16, baseType: !391, size: 64, offset: 128)
!426 = !DILocation(line: 16, column: 13, scope: !339)
!427 = !DILocation(line: 17, column: 5, scope: !339)
!428 = !DILocalVariable(name: "count", scope: !339, file: !32, line: 18, type: !12)
!429 = !DILocation(line: 18, column: 9, scope: !339)
!430 = !DILocation(line: 18, column: 27, scope: !339)
!431 = !DILocation(line: 18, column: 51, scope: !339)
!432 = !DILocation(line: 18, column: 59, scope: !339)
!433 = !DILocation(line: 18, column: 17, scope: !339)
!434 = !DILocation(line: 19, column: 5, scope: !339)
!435 = !DILocation(line: 20, column: 9, scope: !436)
!436 = distinct !DILexicalBlock(scope: !339, file: !32, line: 20, column: 9)
!437 = !DILocation(line: 20, column: 15, scope: !436)
!438 = !DILocation(line: 20, column: 19, scope: !436)
!439 = !DILocation(line: 20, column: 32, scope: !436)
!440 = !DILocation(line: 20, column: 22, scope: !436)
!441 = !DILocation(line: 20, column: 38, scope: !436)
!442 = !DILocation(line: 20, column: 9, scope: !339)
!443 = !DILocation(line: 20, column: 57, scope: !436)
!444 = !DILocalVariable(name: "i", scope: !445, file: !32, line: 21, type: !12)
!445 = distinct !DILexicalBlock(scope: !339, file: !32, line: 21, column: 5)
!446 = !DILocation(line: 21, column: 14, scope: !445)
!447 = !DILocation(line: 21, column: 10, scope: !445)
!448 = !DILocation(line: 21, column: 21, scope: !449)
!449 = distinct !DILexicalBlock(scope: !445, file: !32, line: 21, column: 5)
!450 = !DILocation(line: 21, column: 25, scope: !449)
!451 = !DILocation(line: 21, column: 23, scope: !449)
!452 = !DILocation(line: 21, column: 5, scope: !445)
!453 = !DILocation(line: 22, column: 42, scope: !454)
!454 = distinct !DILexicalBlock(scope: !449, file: !32, line: 21, column: 37)
!455 = !DILocation(line: 22, column: 35, scope: !454)
!456 = !DILocation(line: 22, column: 20, scope: !454)
!457 = !DILocation(line: 22, column: 17, scope: !454)
!458 = !DILocation(line: 23, column: 17, scope: !454)
!459 = !DILocation(line: 24, column: 5, scope: !454)
!460 = !DILocation(line: 21, column: 32, scope: !449)
!461 = !DILocation(line: 21, column: 5, scope: !449)
!462 = distinct !{!462, !452, !463, !130}
!463 = !DILocation(line: 24, column: 5, scope: !445)
!464 = !DILocation(line: 28, column: 11, scope: !339)
!465 = !DILocation(line: 29, column: 11, scope: !339)
!466 = !DILocation(line: 31, column: 12, scope: !339)
!467 = !DILocation(line: 31, column: 5, scope: !339)
