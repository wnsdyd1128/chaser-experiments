; ModuleID = '/workspace/experiments-array-support/chaser/.cache/periodic-polybench/affine-bounds-20260929/suite/gemm/source/workload.c'
source_filename = "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/affine-bounds-20260929/suite/gemm/source/workload.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

%struct._IO_FILE = type { i32, i8*, i8*, i8*, i8*, i8*, i8*, i8*, i8*, i8*, i8*, i8*, %struct._IO_marker*, %struct._IO_FILE*, i32, i32, i64, i16, i8, [1 x i8], i8*, i64, %struct._IO_codecvt*, %struct._IO_wide_data*, %struct._IO_FILE*, i8*, i64, i32, [20 x i8] }
%struct._IO_marker = type opaque
%struct._IO_codecvt = type opaque
%struct._IO_wide_data = type opaque
%struct.__va_list_tag = type { i32, i32, i8*, i8* }

@ni = dso_local global i32 200, align 4, !dbg !0
@nj = dso_local global i32 220, align 4, !dbg !9
@nk = dso_local global i32 240, align 4, !dbg !13
@C = dso_local global [200 x [220 x double]] zeroinitializer, section ".chaser_data.C", align 64, !dbg !35
@A = dso_local global [200 x [240 x double]] zeroinitializer, section ".chaser_data.A", align 64, !dbg !41
@B = dso_local global [240 x [220 x double]] zeroinitializer, section ".chaser_data.B", align 64, !dbg !46
@alpha = dso_local global double 0.000000e+00, align 8, !dbg !50
@beta = dso_local global double 0.000000e+00, align 8, !dbg !52
@.str = private unnamed_addr constant [12 x i8] c"ape.analyze\00", section "llvm.metadata"
@.str.1 = private unnamed_addr constant [122 x i8] c"/workspace/experiments-array-support/chaser/.cache/periodic-polybench/affine-bounds-20260929/suite/gemm/source/workload.c\00", section "llvm.metadata"
@pb_hash = internal global i32 0, align 4, !dbg !32
@workload_jobs = dso_local constant [1 x i32 ()*] [i32 ()* @task_job_polybench], align 8, !dbg !15
@workload_expected = dso_local constant [1 x i32] [i32 -1515378797], align 4, !dbg !28
@stderr = external global %struct._IO_FILE*, align 8
@.str.2 = private unnamed_addr constant [23 x i8] c"==BEGIN DUMP_ARRAYS==\0A\00", align 1
@.str.3 = private unnamed_addr constant [15 x i8] c"begin dump: %s\00", align 1
@.str.4 = private unnamed_addr constant [2 x i8] c"C\00", align 1
@.str.5 = private unnamed_addr constant [2 x i8] c"\0A\00", align 1
@.str.6 = private unnamed_addr constant [8 x i8] c"%0.2lf \00", align 1
@.str.7 = private unnamed_addr constant [17 x i8] c"\0Aend   dump: %s\0A\00", align 1
@.str.8 = private unnamed_addr constant [23 x i8] c"==END   DUMP_ARRAYS==\0A\00", align 1
@pb_emit = internal global i32 1, align 4, !dbg !54
@llvm.global.annotations = appending global [1 x { i8*, i8*, i8*, i32, i8* }] [{ i8*, i8*, i8*, i32, i8* } { i8* bitcast (i32 ()* @task_job_polybench to i8*), i8* getelementptr inbounds ([12 x i8], [12 x i8]* @.str, i32 0, i32 0), i8* getelementptr inbounds ([122 x i8], [122 x i8]* @.str.1, i32 0, i32 0), i32 133, i8* null }], section "llvm.metadata"

; Function Attrs: noinline nounwind uwtable
define dso_local void @workload_prepare() #0 !dbg !64 {
  ret void, !dbg !68
}

; Function Attrs: noinline nounwind uwtable
define dso_local void @workload_reset(i32 noundef %0) #0 !dbg !69 {
  %2 = alloca i32, align 4
  store i32 %0, i32* %2, align 4
  call void @llvm.dbg.declare(metadata i32* %2, metadata !72, metadata !DIExpression()), !dbg !73
  %3 = load i32, i32* %2, align 4, !dbg !74
  call void @llvm.memset.p0i8.i64(i8* align 64 bitcast ([200 x [220 x double]]* @C to i8*), i8 0, i64 352000, i1 false), !dbg !75
  call void @llvm.memset.p0i8.i64(i8* align 64 bitcast ([200 x [240 x double]]* @A to i8*), i8 0, i64 384000, i1 false), !dbg !76
  call void @llvm.memset.p0i8.i64(i8* align 64 bitcast ([240 x [220 x double]]* @B to i8*), i8 0, i64 422400, i1 false), !dbg !77
  %4 = load i32, i32* @ni, align 4, !dbg !78
  %5 = load i32, i32* @nj, align 4, !dbg !79
  %6 = load i32, i32* @nk, align 4, !dbg !80
  call void @init_array(i32 noundef %4, i32 noundef %5, i32 noundef %6, double* noundef @alpha, double* noundef @beta, [220 x double]* noundef getelementptr inbounds ([200 x [220 x double]], [200 x [220 x double]]* @C, i64 0, i64 0), [240 x double]* noundef getelementptr inbounds ([200 x [240 x double]], [200 x [240 x double]]* @A, i64 0, i64 0), [220 x double]* noundef getelementptr inbounds ([240 x [220 x double]], [240 x [220 x double]]* @B, i64 0, i64 0)), !dbg !81
  ret void, !dbg !82
}

; Function Attrs: nofree nosync nounwind readnone speculatable willreturn
declare void @llvm.dbg.declare(metadata, metadata, metadata) #1

; Function Attrs: argmemonly nofree nounwind willreturn writeonly
declare void @llvm.memset.p0i8.i64(i8* nocapture writeonly, i8, i64, i1 immarg) #2

; Function Attrs: noinline nounwind uwtable
define internal void @init_array(i32 noundef %0, i32 noundef %1, i32 noundef %2, double* noundef %3, double* noundef %4, [220 x double]* noundef %5, [240 x double]* noundef %6, [220 x double]* noundef %7) #0 !dbg !83 {
  %9 = alloca i32, align 4
  %10 = alloca i32, align 4
  %11 = alloca i32, align 4
  %12 = alloca double*, align 8
  %13 = alloca double*, align 8
  %14 = alloca [220 x double]*, align 8
  %15 = alloca [240 x double]*, align 8
  %16 = alloca [220 x double]*, align 8
  %17 = alloca i32, align 4
  %18 = alloca i32, align 4
  store i32 %0, i32* %9, align 4
  call void @llvm.dbg.declare(metadata i32* %9, metadata !93, metadata !DIExpression()), !dbg !94
  store i32 %1, i32* %10, align 4
  call void @llvm.dbg.declare(metadata i32* %10, metadata !95, metadata !DIExpression()), !dbg !96
  store i32 %2, i32* %11, align 4
  call void @llvm.dbg.declare(metadata i32* %11, metadata !97, metadata !DIExpression()), !dbg !98
  store double* %3, double** %12, align 8
  call void @llvm.dbg.declare(metadata double** %12, metadata !99, metadata !DIExpression()), !dbg !100
  store double* %4, double** %13, align 8
  call void @llvm.dbg.declare(metadata double** %13, metadata !101, metadata !DIExpression()), !dbg !102
  store [220 x double]* %5, [220 x double]** %14, align 8
  call void @llvm.dbg.declare(metadata [220 x double]** %14, metadata !103, metadata !DIExpression()), !dbg !104
  store [240 x double]* %6, [240 x double]** %15, align 8
  call void @llvm.dbg.declare(metadata [240 x double]** %15, metadata !105, metadata !DIExpression()), !dbg !106
  store [220 x double]* %7, [220 x double]** %16, align 8
  call void @llvm.dbg.declare(metadata [220 x double]** %16, metadata !107, metadata !DIExpression()), !dbg !108
  call void @llvm.dbg.declare(metadata i32* %17, metadata !109, metadata !DIExpression()), !dbg !110
  call void @llvm.dbg.declare(metadata i32* %18, metadata !111, metadata !DIExpression()), !dbg !112
  %19 = load double*, double** %12, align 8, !dbg !113
  store double 1.500000e+00, double* %19, align 8, !dbg !114
  %20 = load double*, double** %13, align 8, !dbg !115
  store double 1.200000e+00, double* %20, align 8, !dbg !116
  store i32 0, i32* %17, align 4, !dbg !117
  br label %21, !dbg !119

21:                                               ; preds = %52, %8
  %22 = load i32, i32* %17, align 4, !dbg !120
  %23 = load i32, i32* %9, align 4, !dbg !122
  %24 = icmp slt i32 %22, %23, !dbg !123
  br i1 %24, label %25, label %55, !dbg !124

25:                                               ; preds = %21
  store i32 0, i32* %18, align 4, !dbg !125
  br label %26, !dbg !127

26:                                               ; preds = %48, %25
  %27 = load i32, i32* %18, align 4, !dbg !128
  %28 = load i32, i32* %10, align 4, !dbg !130
  %29 = icmp slt i32 %27, %28, !dbg !131
  br i1 %29, label %30, label %51, !dbg !132

30:                                               ; preds = %26
  %31 = load i32, i32* %17, align 4, !dbg !133
  %32 = load i32, i32* %18, align 4, !dbg !134
  %33 = mul nsw i32 %31, %32, !dbg !135
  %34 = add nsw i32 %33, 1, !dbg !136
  %35 = load i32, i32* %9, align 4, !dbg !137
  %36 = srem i32 %34, %35, !dbg !138
  %37 = sitofp i32 %36 to double, !dbg !139
  %38 = load i32, i32* %9, align 4, !dbg !140
  %39 = sitofp i32 %38 to double, !dbg !140
  %40 = fdiv double %37, %39, !dbg !141
  %41 = load [220 x double]*, [220 x double]** %14, align 8, !dbg !142
  %42 = load i32, i32* %17, align 4, !dbg !143
  %43 = sext i32 %42 to i64, !dbg !142
  %44 = getelementptr inbounds [220 x double], [220 x double]* %41, i64 %43, !dbg !142
  %45 = load i32, i32* %18, align 4, !dbg !144
  %46 = sext i32 %45 to i64, !dbg !142
  %47 = getelementptr inbounds [220 x double], [220 x double]* %44, i64 0, i64 %46, !dbg !142
  store double %40, double* %47, align 8, !dbg !145
  br label %48, !dbg !142

48:                                               ; preds = %30
  %49 = load i32, i32* %18, align 4, !dbg !146
  %50 = add nsw i32 %49, 1, !dbg !146
  store i32 %50, i32* %18, align 4, !dbg !146
  br label %26, !dbg !147, !llvm.loop !148

51:                                               ; preds = %26
  br label %52, !dbg !149

52:                                               ; preds = %51
  %53 = load i32, i32* %17, align 4, !dbg !151
  %54 = add nsw i32 %53, 1, !dbg !151
  store i32 %54, i32* %17, align 4, !dbg !151
  br label %21, !dbg !152, !llvm.loop !153

55:                                               ; preds = %21
  store i32 0, i32* %17, align 4, !dbg !155
  br label %56, !dbg !157

56:                                               ; preds = %87, %55
  %57 = load i32, i32* %17, align 4, !dbg !158
  %58 = load i32, i32* %9, align 4, !dbg !160
  %59 = icmp slt i32 %57, %58, !dbg !161
  br i1 %59, label %60, label %90, !dbg !162

60:                                               ; preds = %56
  store i32 0, i32* %18, align 4, !dbg !163
  br label %61, !dbg !165

61:                                               ; preds = %83, %60
  %62 = load i32, i32* %18, align 4, !dbg !166
  %63 = load i32, i32* %11, align 4, !dbg !168
  %64 = icmp slt i32 %62, %63, !dbg !169
  br i1 %64, label %65, label %86, !dbg !170

65:                                               ; preds = %61
  %66 = load i32, i32* %17, align 4, !dbg !171
  %67 = load i32, i32* %18, align 4, !dbg !172
  %68 = add nsw i32 %67, 1, !dbg !173
  %69 = mul nsw i32 %66, %68, !dbg !174
  %70 = load i32, i32* %11, align 4, !dbg !175
  %71 = srem i32 %69, %70, !dbg !176
  %72 = sitofp i32 %71 to double, !dbg !177
  %73 = load i32, i32* %11, align 4, !dbg !178
  %74 = sitofp i32 %73 to double, !dbg !178
  %75 = fdiv double %72, %74, !dbg !179
  %76 = load [240 x double]*, [240 x double]** %15, align 8, !dbg !180
  %77 = load i32, i32* %17, align 4, !dbg !181
  %78 = sext i32 %77 to i64, !dbg !180
  %79 = getelementptr inbounds [240 x double], [240 x double]* %76, i64 %78, !dbg !180
  %80 = load i32, i32* %18, align 4, !dbg !182
  %81 = sext i32 %80 to i64, !dbg !180
  %82 = getelementptr inbounds [240 x double], [240 x double]* %79, i64 0, i64 %81, !dbg !180
  store double %75, double* %82, align 8, !dbg !183
  br label %83, !dbg !180

83:                                               ; preds = %65
  %84 = load i32, i32* %18, align 4, !dbg !184
  %85 = add nsw i32 %84, 1, !dbg !184
  store i32 %85, i32* %18, align 4, !dbg !184
  br label %61, !dbg !185, !llvm.loop !186

86:                                               ; preds = %61
  br label %87, !dbg !187

87:                                               ; preds = %86
  %88 = load i32, i32* %17, align 4, !dbg !188
  %89 = add nsw i32 %88, 1, !dbg !188
  store i32 %89, i32* %17, align 4, !dbg !188
  br label %56, !dbg !189, !llvm.loop !190

90:                                               ; preds = %56
  store i32 0, i32* %17, align 4, !dbg !192
  br label %91, !dbg !194

91:                                               ; preds = %122, %90
  %92 = load i32, i32* %17, align 4, !dbg !195
  %93 = load i32, i32* %11, align 4, !dbg !197
  %94 = icmp slt i32 %92, %93, !dbg !198
  br i1 %94, label %95, label %125, !dbg !199

95:                                               ; preds = %91
  store i32 0, i32* %18, align 4, !dbg !200
  br label %96, !dbg !202

96:                                               ; preds = %118, %95
  %97 = load i32, i32* %18, align 4, !dbg !203
  %98 = load i32, i32* %10, align 4, !dbg !205
  %99 = icmp slt i32 %97, %98, !dbg !206
  br i1 %99, label %100, label %121, !dbg !207

100:                                              ; preds = %96
  %101 = load i32, i32* %17, align 4, !dbg !208
  %102 = load i32, i32* %18, align 4, !dbg !209
  %103 = add nsw i32 %102, 2, !dbg !210
  %104 = mul nsw i32 %101, %103, !dbg !211
  %105 = load i32, i32* %10, align 4, !dbg !212
  %106 = srem i32 %104, %105, !dbg !213
  %107 = sitofp i32 %106 to double, !dbg !214
  %108 = load i32, i32* %10, align 4, !dbg !215
  %109 = sitofp i32 %108 to double, !dbg !215
  %110 = fdiv double %107, %109, !dbg !216
  %111 = load [220 x double]*, [220 x double]** %16, align 8, !dbg !217
  %112 = load i32, i32* %17, align 4, !dbg !218
  %113 = sext i32 %112 to i64, !dbg !217
  %114 = getelementptr inbounds [220 x double], [220 x double]* %111, i64 %113, !dbg !217
  %115 = load i32, i32* %18, align 4, !dbg !219
  %116 = sext i32 %115 to i64, !dbg !217
  %117 = getelementptr inbounds [220 x double], [220 x double]* %114, i64 0, i64 %116, !dbg !217
  store double %110, double* %117, align 8, !dbg !220
  br label %118, !dbg !217

118:                                              ; preds = %100
  %119 = load i32, i32* %18, align 4, !dbg !221
  %120 = add nsw i32 %119, 1, !dbg !221
  store i32 %120, i32* %18, align 4, !dbg !221
  br label %96, !dbg !222, !llvm.loop !223

121:                                              ; preds = %96
  br label %122, !dbg !224

122:                                              ; preds = %121
  %123 = load i32, i32* %17, align 4, !dbg !225
  %124 = add nsw i32 %123, 1, !dbg !225
  store i32 %124, i32* %17, align 4, !dbg !225
  br label %91, !dbg !226, !llvm.loop !227

125:                                              ; preds = %91
  ret void, !dbg !229
}

; Function Attrs: noinline nounwind uwtable
define dso_local i32 @task_job_polybench() #0 !dbg !230 {
  %1 = alloca i32, align 4
  %2 = alloca i32, align 4
  %3 = alloca i32, align 4
  %4 = alloca double, align 8
  %5 = alloca double, align 8
  %6 = alloca [220 x double]*, align 8
  %7 = alloca [240 x double]*, align 8
  %8 = alloca [220 x double]*, align 8
  %9 = alloca i32, align 4
  %10 = alloca i32, align 4
  %11 = alloca i32, align 4
  %12 = load i32, i32* @ni, align 4, !dbg !231
  %13 = load i32, i32* @nj, align 4, !dbg !232
  %14 = load i32, i32* @nk, align 4, !dbg !233
  %15 = load double, double* @alpha, align 8, !dbg !234
  %16 = load double, double* @beta, align 8, !dbg !235
  store i32 %12, i32* %1, align 4
  call void @llvm.dbg.declare(metadata i32* %1, metadata !236, metadata !DIExpression()), !dbg !240
  store i32 %13, i32* %2, align 4
  call void @llvm.dbg.declare(metadata i32* %2, metadata !242, metadata !DIExpression()), !dbg !243
  store i32 %14, i32* %3, align 4
  call void @llvm.dbg.declare(metadata i32* %3, metadata !244, metadata !DIExpression()), !dbg !245
  store double %15, double* %4, align 8
  call void @llvm.dbg.declare(metadata double* %4, metadata !246, metadata !DIExpression()), !dbg !247
  store double %16, double* %5, align 8
  call void @llvm.dbg.declare(metadata double* %5, metadata !248, metadata !DIExpression()), !dbg !249
  store [220 x double]* getelementptr inbounds ([200 x [220 x double]], [200 x [220 x double]]* @C, i64 0, i64 0), [220 x double]** %6, align 8
  call void @llvm.dbg.declare(metadata [220 x double]** %6, metadata !250, metadata !DIExpression()), !dbg !251
  store [240 x double]* getelementptr inbounds ([200 x [240 x double]], [200 x [240 x double]]* @A, i64 0, i64 0), [240 x double]** %7, align 8
  call void @llvm.dbg.declare(metadata [240 x double]** %7, metadata !252, metadata !DIExpression()), !dbg !253
  store [220 x double]* getelementptr inbounds ([240 x [220 x double]], [240 x [220 x double]]* @B, i64 0, i64 0), [220 x double]** %8, align 8
  call void @llvm.dbg.declare(metadata [220 x double]** %8, metadata !254, metadata !DIExpression()), !dbg !255
  call void @llvm.dbg.declare(metadata i32* %9, metadata !256, metadata !DIExpression()), !dbg !257
  call void @llvm.dbg.declare(metadata i32* %10, metadata !258, metadata !DIExpression()), !dbg !259
  call void @llvm.dbg.declare(metadata i32* %11, metadata !260, metadata !DIExpression()), !dbg !261
  store i32 0, i32* %9, align 4, !dbg !262
  br label %17, !dbg !264

17:                                               ; preds = %79, %0
  %18 = load i32, i32* %9, align 4, !dbg !265
  %19 = icmp slt i32 %18, 200, !dbg !267
  br i1 %19, label %20, label %82, !dbg !268

20:                                               ; preds = %17
  store i32 0, i32* %10, align 4, !dbg !269
  br label %21, !dbg !272

21:                                               ; preds = %24, %20
  %22 = load i32, i32* %10, align 4, !dbg !273
  %23 = icmp slt i32 %22, 220, !dbg !275
  br i1 %23, label %24, label %37, !dbg !276

24:                                               ; preds = %21
  %25 = load double, double* %5, align 8, !dbg !277
  %26 = load [220 x double]*, [220 x double]** %6, align 8, !dbg !278
  %27 = load i32, i32* %9, align 4, !dbg !279
  %28 = sext i32 %27 to i64, !dbg !278
  %29 = getelementptr inbounds [220 x double], [220 x double]* %26, i64 %28, !dbg !278
  %30 = load i32, i32* %10, align 4, !dbg !280
  %31 = sext i32 %30 to i64, !dbg !278
  %32 = getelementptr inbounds [220 x double], [220 x double]* %29, i64 0, i64 %31, !dbg !278
  %33 = load double, double* %32, align 8, !dbg !281
  %34 = fmul double %33, %25, !dbg !281
  store double %34, double* %32, align 8, !dbg !281
  %35 = load i32, i32* %10, align 4, !dbg !282
  %36 = add nsw i32 %35, 1, !dbg !282
  store i32 %36, i32* %10, align 4, !dbg !282
  br label %21, !dbg !283, !llvm.loop !284

37:                                               ; preds = %21
  store i32 0, i32* %11, align 4, !dbg !286
  br label %38, !dbg !288

38:                                               ; preds = %76, %37
  %39 = load i32, i32* %11, align 4, !dbg !289
  %40 = icmp slt i32 %39, 240, !dbg !291
  br i1 %40, label %41, label %79, !dbg !292

41:                                               ; preds = %38
  store i32 0, i32* %10, align 4, !dbg !293
  br label %42, !dbg !296

42:                                               ; preds = %45, %41
  %43 = load i32, i32* %10, align 4, !dbg !297
  %44 = icmp slt i32 %43, 220, !dbg !299
  br i1 %44, label %45, label %76, !dbg !300

45:                                               ; preds = %42
  %46 = load double, double* %4, align 8, !dbg !301
  %47 = load [240 x double]*, [240 x double]** %7, align 8, !dbg !302
  %48 = load i32, i32* %9, align 4, !dbg !303
  %49 = sext i32 %48 to i64, !dbg !302
  %50 = getelementptr inbounds [240 x double], [240 x double]* %47, i64 %49, !dbg !302
  %51 = load i32, i32* %11, align 4, !dbg !304
  %52 = sext i32 %51 to i64, !dbg !302
  %53 = getelementptr inbounds [240 x double], [240 x double]* %50, i64 0, i64 %52, !dbg !302
  %54 = load double, double* %53, align 8, !dbg !302
  %55 = fmul double %46, %54, !dbg !305
  %56 = load [220 x double]*, [220 x double]** %8, align 8, !dbg !306
  %57 = load i32, i32* %11, align 4, !dbg !307
  %58 = sext i32 %57 to i64, !dbg !306
  %59 = getelementptr inbounds [220 x double], [220 x double]* %56, i64 %58, !dbg !306
  %60 = load i32, i32* %10, align 4, !dbg !308
  %61 = sext i32 %60 to i64, !dbg !306
  %62 = getelementptr inbounds [220 x double], [220 x double]* %59, i64 0, i64 %61, !dbg !306
  %63 = load double, double* %62, align 8, !dbg !306
  %64 = fmul double %55, %63, !dbg !309
  %65 = load [220 x double]*, [220 x double]** %6, align 8, !dbg !310
  %66 = load i32, i32* %9, align 4, !dbg !311
  %67 = sext i32 %66 to i64, !dbg !310
  %68 = getelementptr inbounds [220 x double], [220 x double]* %65, i64 %67, !dbg !310
  %69 = load i32, i32* %10, align 4, !dbg !312
  %70 = sext i32 %69 to i64, !dbg !310
  %71 = getelementptr inbounds [220 x double], [220 x double]* %68, i64 0, i64 %70, !dbg !310
  %72 = load double, double* %71, align 8, !dbg !313
  %73 = fadd double %72, %64, !dbg !313
  store double %73, double* %71, align 8, !dbg !313
  %74 = load i32, i32* %10, align 4, !dbg !314
  %75 = add nsw i32 %74, 1, !dbg !314
  store i32 %75, i32* %10, align 4, !dbg !314
  br label %42, !dbg !315, !llvm.loop !316

76:                                               ; preds = %42
  %77 = load i32, i32* %11, align 4, !dbg !318
  %78 = add nsw i32 %77, 1, !dbg !318
  store i32 %78, i32* %11, align 4, !dbg !318
  br label %38, !dbg !319, !llvm.loop !320

79:                                               ; preds = %38
  %80 = load i32, i32* %9, align 4, !dbg !322
  %81 = add nsw i32 %80, 1, !dbg !322
  store i32 %81, i32* %9, align 4, !dbg !322
  br label %17, !dbg !323, !llvm.loop !324

82:                                               ; preds = %17
  ret i32 0, !dbg !326
}

; Function Attrs: noinline nounwind uwtable
define dso_local i32 @workload_checksum(i32 noundef %0) #0 !dbg !327 {
  %2 = alloca i32, align 4
  store i32 %0, i32* %2, align 4
  call void @llvm.dbg.declare(metadata i32* %2, metadata !330, metadata !DIExpression()), !dbg !331
  %3 = load i32, i32* %2, align 4, !dbg !332
  store i32 -2128831035, i32* @pb_hash, align 4, !dbg !333
  %4 = load i32, i32* @ni, align 4, !dbg !334
  %5 = load i32, i32* @nj, align 4, !dbg !335
  call void @print_array(i32 noundef %4, i32 noundef %5, [220 x double]* noundef getelementptr inbounds ([200 x [220 x double]], [200 x [220 x double]]* @C, i64 0, i64 0)), !dbg !336
  %6 = load i32, i32* @pb_hash, align 4, !dbg !337
  ret i32 %6, !dbg !338
}

; Function Attrs: noinline nounwind uwtable
define internal void @print_array(i32 noundef %0, i32 noundef %1, [220 x double]* noundef %2) #0 !dbg !339 {
  %4 = alloca i32, align 4
  %5 = alloca i32, align 4
  %6 = alloca [220 x double]*, align 8
  %7 = alloca i32, align 4
  %8 = alloca i32, align 4
  store i32 %0, i32* %4, align 4
  call void @llvm.dbg.declare(metadata i32* %4, metadata !342, metadata !DIExpression()), !dbg !343
  store i32 %1, i32* %5, align 4
  call void @llvm.dbg.declare(metadata i32* %5, metadata !344, metadata !DIExpression()), !dbg !345
  store [220 x double]* %2, [220 x double]** %6, align 8
  call void @llvm.dbg.declare(metadata [220 x double]** %6, metadata !346, metadata !DIExpression()), !dbg !347
  call void @llvm.dbg.declare(metadata i32* %7, metadata !348, metadata !DIExpression()), !dbg !349
  call void @llvm.dbg.declare(metadata i32* %8, metadata !350, metadata !DIExpression()), !dbg !351
  %9 = load %struct._IO_FILE*, %struct._IO_FILE** @stderr, align 8, !dbg !352
  %10 = call i32 (%struct._IO_FILE*, i8*, ...) @pb_fprintf(%struct._IO_FILE* noundef %9, i8* noundef getelementptr inbounds ([23 x i8], [23 x i8]* @.str.2, i64 0, i64 0)), !dbg !352
  %11 = load %struct._IO_FILE*, %struct._IO_FILE** @stderr, align 8, !dbg !353
  %12 = call i32 (%struct._IO_FILE*, i8*, ...) @pb_fprintf(%struct._IO_FILE* noundef %11, i8* noundef getelementptr inbounds ([15 x i8], [15 x i8]* @.str.3, i64 0, i64 0), i8* noundef getelementptr inbounds ([2 x i8], [2 x i8]* @.str.4, i64 0, i64 0)), !dbg !353
  store i32 0, i32* %7, align 4, !dbg !354
  br label %13, !dbg !356

13:                                               ; preds = %48, %3
  %14 = load i32, i32* %7, align 4, !dbg !357
  %15 = load i32, i32* %4, align 4, !dbg !359
  %16 = icmp slt i32 %14, %15, !dbg !360
  br i1 %16, label %17, label %51, !dbg !361

17:                                               ; preds = %13
  store i32 0, i32* %8, align 4, !dbg !362
  br label %18, !dbg !364

18:                                               ; preds = %44, %17
  %19 = load i32, i32* %8, align 4, !dbg !365
  %20 = load i32, i32* %5, align 4, !dbg !367
  %21 = icmp slt i32 %19, %20, !dbg !368
  br i1 %21, label %22, label %47, !dbg !369

22:                                               ; preds = %18
  %23 = load i32, i32* %7, align 4, !dbg !370
  %24 = load i32, i32* %4, align 4, !dbg !373
  %25 = mul nsw i32 %23, %24, !dbg !374
  %26 = load i32, i32* %8, align 4, !dbg !375
  %27 = add nsw i32 %25, %26, !dbg !376
  %28 = srem i32 %27, 20, !dbg !377
  %29 = icmp eq i32 %28, 0, !dbg !378
  br i1 %29, label %30, label %33, !dbg !379

30:                                               ; preds = %22
  %31 = load %struct._IO_FILE*, %struct._IO_FILE** @stderr, align 8, !dbg !380
  %32 = call i32 (%struct._IO_FILE*, i8*, ...) @pb_fprintf(%struct._IO_FILE* noundef %31, i8* noundef getelementptr inbounds ([2 x i8], [2 x i8]* @.str.5, i64 0, i64 0)), !dbg !381
  br label %33, !dbg !381

33:                                               ; preds = %30, %22
  %34 = load %struct._IO_FILE*, %struct._IO_FILE** @stderr, align 8, !dbg !382
  %35 = load [220 x double]*, [220 x double]** %6, align 8, !dbg !383
  %36 = load i32, i32* %7, align 4, !dbg !384
  %37 = sext i32 %36 to i64, !dbg !383
  %38 = getelementptr inbounds [220 x double], [220 x double]* %35, i64 %37, !dbg !383
  %39 = load i32, i32* %8, align 4, !dbg !385
  %40 = sext i32 %39 to i64, !dbg !383
  %41 = getelementptr inbounds [220 x double], [220 x double]* %38, i64 0, i64 %40, !dbg !383
  %42 = load double, double* %41, align 8, !dbg !383
  %43 = call i32 (%struct._IO_FILE*, i8*, ...) @pb_fprintf(%struct._IO_FILE* noundef %34, i8* noundef getelementptr inbounds ([8 x i8], [8 x i8]* @.str.6, i64 0, i64 0), double noundef %42), !dbg !386
  br label %44, !dbg !387

44:                                               ; preds = %33
  %45 = load i32, i32* %8, align 4, !dbg !388
  %46 = add nsw i32 %45, 1, !dbg !388
  store i32 %46, i32* %8, align 4, !dbg !388
  br label %18, !dbg !389, !llvm.loop !390

47:                                               ; preds = %18
  br label %48, !dbg !391

48:                                               ; preds = %47
  %49 = load i32, i32* %7, align 4, !dbg !392
  %50 = add nsw i32 %49, 1, !dbg !392
  store i32 %50, i32* %7, align 4, !dbg !392
  br label %13, !dbg !393, !llvm.loop !394

51:                                               ; preds = %13
  %52 = load %struct._IO_FILE*, %struct._IO_FILE** @stderr, align 8, !dbg !396
  %53 = call i32 (%struct._IO_FILE*, i8*, ...) @pb_fprintf(%struct._IO_FILE* noundef %52, i8* noundef getelementptr inbounds ([17 x i8], [17 x i8]* @.str.7, i64 0, i64 0), i8* noundef getelementptr inbounds ([2 x i8], [2 x i8]* @.str.4, i64 0, i64 0)), !dbg !396
  %54 = load %struct._IO_FILE*, %struct._IO_FILE** @stderr, align 8, !dbg !397
  %55 = call i32 (%struct._IO_FILE*, i8*, ...) @pb_fprintf(%struct._IO_FILE* noundef %54, i8* noundef getelementptr inbounds ([23 x i8], [23 x i8]* @.str.8, i64 0, i64 0)), !dbg !397
  ret void, !dbg !398
}

; Function Attrs: noinline nounwind uwtable
define internal i32 @pb_fprintf(%struct._IO_FILE* noundef %0, i8* noundef %1, ...) #0 !dbg !399 {
  %3 = alloca %struct._IO_FILE*, align 8
  %4 = alloca i8*, align 8
  %5 = alloca [768 x i8], align 16
  %6 = alloca [1 x %struct.__va_list_tag], align 16
  %7 = alloca i32, align 4
  %8 = alloca i32, align 4
  store %struct._IO_FILE* %0, %struct._IO_FILE** %3, align 8
  call void @llvm.dbg.declare(metadata %struct._IO_FILE** %3, metadata !463, metadata !DIExpression()), !dbg !464
  store i8* %1, i8** %4, align 8
  call void @llvm.dbg.declare(metadata i8** %4, metadata !465, metadata !DIExpression()), !dbg !466
  call void @llvm.dbg.declare(metadata [768 x i8]* %5, metadata !467, metadata !DIExpression()), !dbg !471
  call void @llvm.dbg.declare(metadata [1 x %struct.__va_list_tag]* %6, metadata !472, metadata !DIExpression()), !dbg !486
  %9 = getelementptr inbounds [1 x %struct.__va_list_tag], [1 x %struct.__va_list_tag]* %6, i64 0, i64 0, !dbg !487
  %10 = bitcast %struct.__va_list_tag* %9 to i8*, !dbg !487
  call void @llvm.va_start(i8* %10), !dbg !487
  call void @llvm.dbg.declare(metadata i32* %7, metadata !488, metadata !DIExpression()), !dbg !489
  %11 = getelementptr inbounds [768 x i8], [768 x i8]* %5, i64 0, i64 0, !dbg !490
  %12 = load i8*, i8** %4, align 8, !dbg !491
  %13 = getelementptr inbounds [1 x %struct.__va_list_tag], [1 x %struct.__va_list_tag]* %6, i64 0, i64 0, !dbg !492
  %14 = call i32 @vsnprintf(i8* noundef %11, i64 noundef 768, i8* noundef %12, %struct.__va_list_tag* noundef %13) #6, !dbg !493
  store i32 %14, i32* %7, align 4, !dbg !489
  %15 = getelementptr inbounds [1 x %struct.__va_list_tag], [1 x %struct.__va_list_tag]* %6, i64 0, i64 0, !dbg !494
  %16 = bitcast %struct.__va_list_tag* %15 to i8*, !dbg !494
  call void @llvm.va_end(i8* %16), !dbg !494
  %17 = load i32, i32* %7, align 4, !dbg !495
  %18 = icmp slt i32 %17, 0, !dbg !497
  br i1 %18, label %23, label %19, !dbg !498

19:                                               ; preds = %2
  %20 = load i32, i32* %7, align 4, !dbg !499
  %21 = zext i32 %20 to i64, !dbg !500
  %22 = icmp uge i64 %21, 768, !dbg !501
  br i1 %22, label %23, label %24, !dbg !502

23:                                               ; preds = %19, %2
  call void @abort() #7, !dbg !503
  unreachable, !dbg !503

24:                                               ; preds = %19
  call void @llvm.dbg.declare(metadata i32* %8, metadata !504, metadata !DIExpression()), !dbg !506
  store i32 0, i32* %8, align 4, !dbg !506
  br label %25, !dbg !507

25:                                               ; preds = %39, %24
  %26 = load i32, i32* %8, align 4, !dbg !508
  %27 = load i32, i32* %7, align 4, !dbg !510
  %28 = icmp slt i32 %26, %27, !dbg !511
  br i1 %28, label %29, label %42, !dbg !512

29:                                               ; preds = %25
  %30 = load i32, i32* %8, align 4, !dbg !513
  %31 = sext i32 %30 to i64, !dbg !515
  %32 = getelementptr inbounds [768 x i8], [768 x i8]* %5, i64 0, i64 %31, !dbg !515
  %33 = load i8, i8* %32, align 1, !dbg !515
  %34 = zext i8 %33 to i32, !dbg !516
  %35 = load i32, i32* @pb_hash, align 4, !dbg !517
  %36 = xor i32 %35, %34, !dbg !517
  store i32 %36, i32* @pb_hash, align 4, !dbg !517
  %37 = load i32, i32* @pb_hash, align 4, !dbg !518
  %38 = mul i32 %37, 16777619, !dbg !518
  store i32 %38, i32* @pb_hash, align 4, !dbg !518
  br label %39, !dbg !519

39:                                               ; preds = %29
  %40 = load i32, i32* %8, align 4, !dbg !520
  %41 = add nsw i32 %40, 1, !dbg !520
  store i32 %41, i32* %8, align 4, !dbg !520
  br label %25, !dbg !521, !llvm.loop !522

42:                                               ; preds = %25
  %43 = load %struct._IO_FILE*, %struct._IO_FILE** %3, align 8, !dbg !524
  %44 = load i32, i32* @pb_emit, align 4, !dbg !525
  %45 = load i32, i32* %7, align 4, !dbg !526
  ret i32 %45, !dbg !527
}

; Function Attrs: nofree nosync nounwind willreturn
declare void @llvm.va_start(i8*) #3

; Function Attrs: nounwind
declare i32 @vsnprintf(i8* noundef, i64 noundef, i8* noundef, %struct.__va_list_tag* noundef) #4

; Function Attrs: nofree nosync nounwind willreturn
declare void @llvm.va_end(i8*) #3

; Function Attrs: noreturn nounwind
declare void @abort() #5

attributes #0 = { noinline nounwind uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { nofree nosync nounwind readnone speculatable willreturn }
attributes #2 = { argmemonly nofree nounwind willreturn writeonly }
attributes #3 = { nofree nosync nounwind willreturn }
attributes #4 = { nounwind "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #5 = { noreturn nounwind "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #6 = { nounwind }
attributes #7 = { noreturn nounwind }

!llvm.dbg.cu = !{!2}
!llvm.module.flags = !{!56, !57, !58, !59, !60, !61, !62}
!llvm.ident = !{!63}

!0 = !DIGlobalVariableExpression(var: !1, expr: !DIExpression())
!1 = distinct !DIGlobalVariable(name: "ni", scope: !2, file: !11, line: 115, type: !12, isLocal: false, isDefinition: true)
!2 = distinct !DICompileUnit(language: DW_LANG_C99, file: !3, producer: "Ubuntu clang version 14.0.0-1ubuntu1.1", isOptimized: false, runtimeVersion: 0, emissionKind: FullDebug, retainedTypes: !4, globals: !8, splitDebugInlining: false, nameTableKind: None)
!3 = !DIFile(filename: "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/affine-bounds-20260929/suite/gemm/source/workload.c", directory: "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/affine-bounds-20260929/suite/gemm/analysis-c", checksumkind: CSK_MD5, checksum: "72ef21b4d85cdd36847c106bef7285d7")
!4 = !{!5, !6, !7}
!5 = !DIBasicType(name: "double", size: 64, encoding: DW_ATE_float)
!6 = !DIBasicType(name: "unsigned int", size: 32, encoding: DW_ATE_unsigned)
!7 = !DIBasicType(name: "unsigned char", size: 8, encoding: DW_ATE_unsigned_char)
!8 = !{!0, !9, !13, !15, !28, !32, !35, !41, !46, !50, !52, !54}
!9 = !DIGlobalVariableExpression(var: !10, expr: !DIExpression())
!10 = distinct !DIGlobalVariable(name: "nj", scope: !2, file: !11, line: 116, type: !12, isLocal: false, isDefinition: true)
!11 = !DIFile(filename: "source/workload.c", directory: "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/affine-bounds-20260929/suite/gemm", checksumkind: CSK_MD5, checksum: "72ef21b4d85cdd36847c106bef7285d7")
!12 = !DIBasicType(name: "int", size: 32, encoding: DW_ATE_signed)
!13 = !DIGlobalVariableExpression(var: !14, expr: !DIExpression())
!14 = distinct !DIGlobalVariable(name: "nk", scope: !2, file: !11, line: 117, type: !12, isLocal: false, isDefinition: true)
!15 = !DIGlobalVariableExpression(var: !16, expr: !DIExpression())
!16 = distinct !DIGlobalVariable(name: "workload_jobs", scope: !2, file: !11, line: 147, type: !17, isLocal: false, isDefinition: true)
!17 = !DICompositeType(tag: DW_TAG_array_type, baseType: !18, size: 64, elements: !26)
!18 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !19)
!19 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !20, size: 64)
!20 = !DISubroutineType(types: !21)
!21 = !{!22}
!22 = !DIDerivedType(tag: DW_TAG_typedef, name: "uint32_t", file: !23, line: 26, baseType: !24)
!23 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/stdint-uintn.h", directory: "", checksumkind: CSK_MD5, checksum: "2bf2ae53c58c01b1a1b9383b5195125c")
!24 = !DIDerivedType(tag: DW_TAG_typedef, name: "__uint32_t", file: !25, line: 42, baseType: !6)
!25 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/types.h", directory: "", checksumkind: CSK_MD5, checksum: "d108b5f93a74c50510d7d9bc0ab36df9")
!26 = !{!27}
!27 = !DISubrange(count: 1)
!28 = !DIGlobalVariableExpression(var: !29, expr: !DIExpression())
!29 = distinct !DIGlobalVariable(name: "workload_expected", scope: !2, file: !11, line: 151, type: !30, isLocal: false, isDefinition: true)
!30 = !DICompositeType(tag: DW_TAG_array_type, baseType: !31, size: 32, elements: !26)
!31 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !22)
!32 = !DIGlobalVariableExpression(var: !33, expr: !DIExpression())
!33 = distinct !DIGlobalVariable(name: "pb_hash", scope: !2, file: !34, line: 9, type: !22, isLocal: true, isDefinition: true)
!34 = !DIFile(filename: "source/adapter.h", directory: "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/affine-bounds-20260929/suite/gemm", checksumkind: CSK_MD5, checksum: "26a6068928b2092758f244a9d00163d7")
!35 = !DIGlobalVariableExpression(var: !36, expr: !DIExpression())
!36 = distinct !DIGlobalVariable(name: "C", scope: !2, file: !11, line: 34, type: !37, isLocal: false, isDefinition: true, align: 512)
!37 = !DICompositeType(tag: DW_TAG_array_type, baseType: !5, size: 2816000, elements: !38)
!38 = !{!39, !40}
!39 = !DISubrange(count: 200)
!40 = !DISubrange(count: 220)
!41 = !DIGlobalVariableExpression(var: !42, expr: !DIExpression())
!42 = distinct !DIGlobalVariable(name: "A", scope: !2, file: !11, line: 35, type: !43, isLocal: false, isDefinition: true, align: 512)
!43 = !DICompositeType(tag: DW_TAG_array_type, baseType: !5, size: 3072000, elements: !44)
!44 = !{!39, !45}
!45 = !DISubrange(count: 240)
!46 = !DIGlobalVariableExpression(var: !47, expr: !DIExpression())
!47 = distinct !DIGlobalVariable(name: "B", scope: !2, file: !11, line: 36, type: !48, isLocal: false, isDefinition: true, align: 512)
!48 = !DICompositeType(tag: DW_TAG_array_type, baseType: !5, size: 3379200, elements: !49)
!49 = !{!45, !40}
!50 = !DIGlobalVariableExpression(var: !51, expr: !DIExpression())
!51 = distinct !DIGlobalVariable(name: "alpha", scope: !2, file: !11, line: 120, type: !5, isLocal: false, isDefinition: true)
!52 = !DIGlobalVariableExpression(var: !53, expr: !DIExpression())
!53 = distinct !DIGlobalVariable(name: "beta", scope: !2, file: !11, line: 121, type: !5, isLocal: false, isDefinition: true)
!54 = !DIGlobalVariableExpression(var: !55, expr: !DIExpression())
!55 = distinct !DIGlobalVariable(name: "pb_emit", scope: !2, file: !34, line: 10, type: !12, isLocal: true, isDefinition: true)
!56 = !{i32 7, !"Dwarf Version", i32 5}
!57 = !{i32 2, !"Debug Info Version", i32 3}
!58 = !{i32 1, !"wchar_size", i32 4}
!59 = !{i32 7, !"PIC Level", i32 2}
!60 = !{i32 7, !"PIE Level", i32 2}
!61 = !{i32 7, !"uwtable", i32 1}
!62 = !{i32 7, !"frame-pointer", i32 2}
!63 = !{!"Ubuntu clang version 14.0.0-1ubuntu1.1"}
!64 = distinct !DISubprogram(name: "workload_prepare", scope: !11, file: !11, line: 122, type: !65, scopeLine: 122, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !2, retainedNodes: !67)
!65 = !DISubroutineType(types: !66)
!66 = !{null}
!67 = !{}
!68 = !DILocation(line: 122, column: 30, scope: !64)
!69 = distinct !DISubprogram(name: "workload_reset", scope: !11, file: !11, line: 123, type: !70, scopeLine: 123, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !2, retainedNodes: !67)
!70 = !DISubroutineType(types: !71)
!71 = !{null, !6}
!72 = !DILocalVariable(name: "task", arg: 1, scope: !69, file: !11, line: 123, type: !6)
!73 = !DILocation(line: 123, column: 30, scope: !69)
!74 = !DILocation(line: 124, column: 9, scope: !69)
!75 = !DILocation(line: 125, column: 3, scope: !69)
!76 = !DILocation(line: 126, column: 3, scope: !69)
!77 = !DILocation(line: 127, column: 3, scope: !69)
!78 = !DILocation(line: 128, column: 15, scope: !69)
!79 = !DILocation(line: 128, column: 19, scope: !69)
!80 = !DILocation(line: 128, column: 23, scope: !69)
!81 = !DILocation(line: 128, column: 3, scope: !69)
!82 = !DILocation(line: 132, column: 1, scope: !69)
!83 = distinct !DISubprogram(name: "init_array", scope: !11, file: !11, line: 38, type: !84, scopeLine: 44, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition, unit: !2, retainedNodes: !67)
!84 = !DISubroutineType(types: !85)
!85 = !{null, !12, !12, !12, !86, !86, !87, !90, !87}
!86 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !5, size: 64)
!87 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !88, size: 64)
!88 = !DICompositeType(tag: DW_TAG_array_type, baseType: !5, size: 14080, elements: !89)
!89 = !{!40}
!90 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !91, size: 64)
!91 = !DICompositeType(tag: DW_TAG_array_type, baseType: !5, size: 15360, elements: !92)
!92 = !{!45}
!93 = !DILocalVariable(name: "ni", arg: 1, scope: !83, file: !11, line: 38, type: !12)
!94 = !DILocation(line: 38, column: 21, scope: !83)
!95 = !DILocalVariable(name: "nj", arg: 2, scope: !83, file: !11, line: 38, type: !12)
!96 = !DILocation(line: 38, column: 29, scope: !83)
!97 = !DILocalVariable(name: "nk", arg: 3, scope: !83, file: !11, line: 38, type: !12)
!98 = !DILocation(line: 38, column: 37, scope: !83)
!99 = !DILocalVariable(name: "alpha", arg: 4, scope: !83, file: !11, line: 39, type: !86)
!100 = !DILocation(line: 39, column: 14, scope: !83)
!101 = !DILocalVariable(name: "beta", arg: 5, scope: !83, file: !11, line: 40, type: !86)
!102 = !DILocation(line: 40, column: 14, scope: !83)
!103 = !DILocalVariable(name: "C", arg: 6, scope: !83, file: !11, line: 41, type: !87)
!104 = !DILocation(line: 41, column: 13, scope: !83)
!105 = !DILocalVariable(name: "A", arg: 7, scope: !83, file: !11, line: 42, type: !90)
!106 = !DILocation(line: 42, column: 13, scope: !83)
!107 = !DILocalVariable(name: "B", arg: 8, scope: !83, file: !11, line: 43, type: !87)
!108 = !DILocation(line: 43, column: 13, scope: !83)
!109 = !DILocalVariable(name: "i", scope: !83, file: !11, line: 45, type: !12)
!110 = !DILocation(line: 45, column: 7, scope: !83)
!111 = !DILocalVariable(name: "j", scope: !83, file: !11, line: 45, type: !12)
!112 = !DILocation(line: 45, column: 10, scope: !83)
!113 = !DILocation(line: 47, column: 4, scope: !83)
!114 = !DILocation(line: 47, column: 10, scope: !83)
!115 = !DILocation(line: 48, column: 4, scope: !83)
!116 = !DILocation(line: 48, column: 9, scope: !83)
!117 = !DILocation(line: 49, column: 10, scope: !118)
!118 = distinct !DILexicalBlock(scope: !83, file: !11, line: 49, column: 3)
!119 = !DILocation(line: 49, column: 8, scope: !118)
!120 = !DILocation(line: 49, column: 15, scope: !121)
!121 = distinct !DILexicalBlock(scope: !118, file: !11, line: 49, column: 3)
!122 = !DILocation(line: 49, column: 19, scope: !121)
!123 = !DILocation(line: 49, column: 17, scope: !121)
!124 = !DILocation(line: 49, column: 3, scope: !118)
!125 = !DILocation(line: 50, column: 12, scope: !126)
!126 = distinct !DILexicalBlock(scope: !121, file: !11, line: 50, column: 5)
!127 = !DILocation(line: 50, column: 10, scope: !126)
!128 = !DILocation(line: 50, column: 17, scope: !129)
!129 = distinct !DILexicalBlock(scope: !126, file: !11, line: 50, column: 5)
!130 = !DILocation(line: 50, column: 21, scope: !129)
!131 = !DILocation(line: 50, column: 19, scope: !129)
!132 = !DILocation(line: 50, column: 5, scope: !126)
!133 = !DILocation(line: 51, column: 31, scope: !129)
!134 = !DILocation(line: 51, column: 33, scope: !129)
!135 = !DILocation(line: 51, column: 32, scope: !129)
!136 = !DILocation(line: 51, column: 34, scope: !129)
!137 = !DILocation(line: 51, column: 40, scope: !129)
!138 = !DILocation(line: 51, column: 38, scope: !129)
!139 = !DILocation(line: 51, column: 17, scope: !129)
!140 = !DILocation(line: 51, column: 46, scope: !129)
!141 = !DILocation(line: 51, column: 44, scope: !129)
!142 = !DILocation(line: 51, column: 7, scope: !129)
!143 = !DILocation(line: 51, column: 9, scope: !129)
!144 = !DILocation(line: 51, column: 12, scope: !129)
!145 = !DILocation(line: 51, column: 15, scope: !129)
!146 = !DILocation(line: 50, column: 26, scope: !129)
!147 = !DILocation(line: 50, column: 5, scope: !129)
!148 = distinct !{!148, !132, !149, !150}
!149 = !DILocation(line: 51, column: 46, scope: !126)
!150 = !{!"llvm.loop.mustprogress"}
!151 = !DILocation(line: 49, column: 24, scope: !121)
!152 = !DILocation(line: 49, column: 3, scope: !121)
!153 = distinct !{!153, !124, !154, !150}
!154 = !DILocation(line: 51, column: 46, scope: !118)
!155 = !DILocation(line: 52, column: 10, scope: !156)
!156 = distinct !DILexicalBlock(scope: !83, file: !11, line: 52, column: 3)
!157 = !DILocation(line: 52, column: 8, scope: !156)
!158 = !DILocation(line: 52, column: 15, scope: !159)
!159 = distinct !DILexicalBlock(scope: !156, file: !11, line: 52, column: 3)
!160 = !DILocation(line: 52, column: 19, scope: !159)
!161 = !DILocation(line: 52, column: 17, scope: !159)
!162 = !DILocation(line: 52, column: 3, scope: !156)
!163 = !DILocation(line: 53, column: 12, scope: !164)
!164 = distinct !DILexicalBlock(scope: !159, file: !11, line: 53, column: 5)
!165 = !DILocation(line: 53, column: 10, scope: !164)
!166 = !DILocation(line: 53, column: 17, scope: !167)
!167 = distinct !DILexicalBlock(scope: !164, file: !11, line: 53, column: 5)
!168 = !DILocation(line: 53, column: 21, scope: !167)
!169 = !DILocation(line: 53, column: 19, scope: !167)
!170 = !DILocation(line: 53, column: 5, scope: !164)
!171 = !DILocation(line: 54, column: 30, scope: !167)
!172 = !DILocation(line: 54, column: 33, scope: !167)
!173 = !DILocation(line: 54, column: 34, scope: !167)
!174 = !DILocation(line: 54, column: 31, scope: !167)
!175 = !DILocation(line: 54, column: 40, scope: !167)
!176 = !DILocation(line: 54, column: 38, scope: !167)
!177 = !DILocation(line: 54, column: 17, scope: !167)
!178 = !DILocation(line: 54, column: 46, scope: !167)
!179 = !DILocation(line: 54, column: 44, scope: !167)
!180 = !DILocation(line: 54, column: 7, scope: !167)
!181 = !DILocation(line: 54, column: 9, scope: !167)
!182 = !DILocation(line: 54, column: 12, scope: !167)
!183 = !DILocation(line: 54, column: 15, scope: !167)
!184 = !DILocation(line: 53, column: 26, scope: !167)
!185 = !DILocation(line: 53, column: 5, scope: !167)
!186 = distinct !{!186, !170, !187, !150}
!187 = !DILocation(line: 54, column: 46, scope: !164)
!188 = !DILocation(line: 52, column: 24, scope: !159)
!189 = !DILocation(line: 52, column: 3, scope: !159)
!190 = distinct !{!190, !162, !191, !150}
!191 = !DILocation(line: 54, column: 46, scope: !156)
!192 = !DILocation(line: 55, column: 10, scope: !193)
!193 = distinct !DILexicalBlock(scope: !83, file: !11, line: 55, column: 3)
!194 = !DILocation(line: 55, column: 8, scope: !193)
!195 = !DILocation(line: 55, column: 15, scope: !196)
!196 = distinct !DILexicalBlock(scope: !193, file: !11, line: 55, column: 3)
!197 = !DILocation(line: 55, column: 19, scope: !196)
!198 = !DILocation(line: 55, column: 17, scope: !196)
!199 = !DILocation(line: 55, column: 3, scope: !193)
!200 = !DILocation(line: 56, column: 12, scope: !201)
!201 = distinct !DILexicalBlock(scope: !196, file: !11, line: 56, column: 5)
!202 = !DILocation(line: 56, column: 10, scope: !201)
!203 = !DILocation(line: 56, column: 17, scope: !204)
!204 = distinct !DILexicalBlock(scope: !201, file: !11, line: 56, column: 5)
!205 = !DILocation(line: 56, column: 21, scope: !204)
!206 = !DILocation(line: 56, column: 19, scope: !204)
!207 = !DILocation(line: 56, column: 5, scope: !201)
!208 = !DILocation(line: 57, column: 30, scope: !204)
!209 = !DILocation(line: 57, column: 33, scope: !204)
!210 = !DILocation(line: 57, column: 34, scope: !204)
!211 = !DILocation(line: 57, column: 31, scope: !204)
!212 = !DILocation(line: 57, column: 40, scope: !204)
!213 = !DILocation(line: 57, column: 38, scope: !204)
!214 = !DILocation(line: 57, column: 17, scope: !204)
!215 = !DILocation(line: 57, column: 46, scope: !204)
!216 = !DILocation(line: 57, column: 44, scope: !204)
!217 = !DILocation(line: 57, column: 7, scope: !204)
!218 = !DILocation(line: 57, column: 9, scope: !204)
!219 = !DILocation(line: 57, column: 12, scope: !204)
!220 = !DILocation(line: 57, column: 15, scope: !204)
!221 = !DILocation(line: 56, column: 26, scope: !204)
!222 = !DILocation(line: 56, column: 5, scope: !204)
!223 = distinct !{!223, !207, !224, !150}
!224 = !DILocation(line: 57, column: 46, scope: !201)
!225 = !DILocation(line: 55, column: 24, scope: !196)
!226 = !DILocation(line: 55, column: 3, scope: !196)
!227 = distinct !{!227, !199, !228, !150}
!228 = !DILocation(line: 57, column: 46, scope: !193)
!229 = !DILocation(line: 58, column: 1, scope: !83)
!230 = distinct !DISubprogram(name: "task_job_polybench", scope: !11, file: !11, line: 133, type: !20, scopeLine: 133, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !2, retainedNodes: !67)
!231 = !DILocation(line: 134, column: 16, scope: !230)
!232 = !DILocation(line: 134, column: 20, scope: !230)
!233 = !DILocation(line: 134, column: 24, scope: !230)
!234 = !DILocation(line: 135, column: 9, scope: !230)
!235 = !DILocation(line: 135, column: 16, scope: !230)
!236 = !DILocalVariable(name: "ni", arg: 1, scope: !237, file: !11, line: 84, type: !12)
!237 = distinct !DISubprogram(name: "kernel_gemm", scope: !11, file: !11, line: 84, type: !238, scopeLine: 90, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition, unit: !2, retainedNodes: !67)
!238 = !DISubroutineType(types: !239)
!239 = !{null, !12, !12, !12, !5, !5, !87, !90, !87}
!240 = !DILocation(line: 84, column: 60, scope: !237, inlinedAt: !241)
!241 = distinct !DILocation(line: 134, column: 3, scope: !230)
!242 = !DILocalVariable(name: "nj", arg: 2, scope: !237, file: !11, line: 84, type: !12)
!243 = !DILocation(line: 84, column: 68, scope: !237, inlinedAt: !241)
!244 = !DILocalVariable(name: "nk", arg: 3, scope: !237, file: !11, line: 84, type: !12)
!245 = !DILocation(line: 84, column: 76, scope: !237, inlinedAt: !241)
!246 = !DILocalVariable(name: "alpha", arg: 4, scope: !237, file: !11, line: 85, type: !5)
!247 = !DILocation(line: 85, column: 14, scope: !237, inlinedAt: !241)
!248 = !DILocalVariable(name: "beta", arg: 5, scope: !237, file: !11, line: 86, type: !5)
!249 = !DILocation(line: 86, column: 14, scope: !237, inlinedAt: !241)
!250 = !DILocalVariable(name: "C", arg: 6, scope: !237, file: !11, line: 87, type: !87)
!251 = !DILocation(line: 87, column: 14, scope: !237, inlinedAt: !241)
!252 = !DILocalVariable(name: "A", arg: 7, scope: !237, file: !11, line: 88, type: !90)
!253 = !DILocation(line: 88, column: 14, scope: !237, inlinedAt: !241)
!254 = !DILocalVariable(name: "B", arg: 8, scope: !237, file: !11, line: 89, type: !87)
!255 = !DILocation(line: 89, column: 14, scope: !237, inlinedAt: !241)
!256 = !DILocalVariable(name: "i", scope: !237, file: !11, line: 91, type: !12)
!257 = !DILocation(line: 91, column: 7, scope: !237, inlinedAt: !241)
!258 = !DILocalVariable(name: "j", scope: !237, file: !11, line: 91, type: !12)
!259 = !DILocation(line: 91, column: 10, scope: !237, inlinedAt: !241)
!260 = !DILocalVariable(name: "k", scope: !237, file: !11, line: 91, type: !12)
!261 = !DILocation(line: 91, column: 13, scope: !237, inlinedAt: !241)
!262 = !DILocation(line: 101, column: 10, scope: !263, inlinedAt: !241)
!263 = distinct !DILexicalBlock(scope: !237, file: !11, line: 101, column: 3)
!264 = !DILocation(line: 101, column: 8, scope: !263, inlinedAt: !241)
!265 = !DILocation(line: 101, column: 15, scope: !266, inlinedAt: !241)
!266 = distinct !DILexicalBlock(scope: !263, file: !11, line: 101, column: 3)
!267 = !DILocation(line: 101, column: 17, scope: !266, inlinedAt: !241)
!268 = !DILocation(line: 101, column: 3, scope: !263, inlinedAt: !241)
!269 = !DILocation(line: 102, column: 12, scope: !270, inlinedAt: !241)
!270 = distinct !DILexicalBlock(scope: !271, file: !11, line: 102, column: 5)
!271 = distinct !DILexicalBlock(scope: !266, file: !11, line: 101, column: 32)
!272 = !DILocation(line: 102, column: 10, scope: !270, inlinedAt: !241)
!273 = !DILocation(line: 102, column: 17, scope: !274, inlinedAt: !241)
!274 = distinct !DILexicalBlock(scope: !270, file: !11, line: 102, column: 5)
!275 = !DILocation(line: 102, column: 19, scope: !274, inlinedAt: !241)
!276 = !DILocation(line: 102, column: 5, scope: !270, inlinedAt: !241)
!277 = !DILocation(line: 103, column: 13, scope: !274, inlinedAt: !241)
!278 = !DILocation(line: 103, column: 2, scope: !274, inlinedAt: !241)
!279 = !DILocation(line: 103, column: 4, scope: !274, inlinedAt: !241)
!280 = !DILocation(line: 103, column: 7, scope: !274, inlinedAt: !241)
!281 = !DILocation(line: 103, column: 10, scope: !274, inlinedAt: !241)
!282 = !DILocation(line: 102, column: 30, scope: !274, inlinedAt: !241)
!283 = !DILocation(line: 102, column: 5, scope: !274, inlinedAt: !241)
!284 = distinct !{!284, !276, !285, !150}
!285 = !DILocation(line: 103, column: 13, scope: !270, inlinedAt: !241)
!286 = !DILocation(line: 104, column: 12, scope: !287, inlinedAt: !241)
!287 = distinct !DILexicalBlock(scope: !271, file: !11, line: 104, column: 5)
!288 = !DILocation(line: 104, column: 10, scope: !287, inlinedAt: !241)
!289 = !DILocation(line: 104, column: 17, scope: !290, inlinedAt: !241)
!290 = distinct !DILexicalBlock(scope: !287, file: !11, line: 104, column: 5)
!291 = !DILocation(line: 104, column: 19, scope: !290, inlinedAt: !241)
!292 = !DILocation(line: 104, column: 5, scope: !287, inlinedAt: !241)
!293 = !DILocation(line: 105, column: 15, scope: !294, inlinedAt: !241)
!294 = distinct !DILexicalBlock(scope: !295, file: !11, line: 105, column: 8)
!295 = distinct !DILexicalBlock(scope: !290, file: !11, line: 104, column: 34)
!296 = !DILocation(line: 105, column: 13, scope: !294, inlinedAt: !241)
!297 = !DILocation(line: 105, column: 20, scope: !298, inlinedAt: !241)
!298 = distinct !DILexicalBlock(scope: !294, file: !11, line: 105, column: 8)
!299 = !DILocation(line: 105, column: 22, scope: !298, inlinedAt: !241)
!300 = !DILocation(line: 105, column: 8, scope: !294, inlinedAt: !241)
!301 = !DILocation(line: 106, column: 15, scope: !298, inlinedAt: !241)
!302 = !DILocation(line: 106, column: 23, scope: !298, inlinedAt: !241)
!303 = !DILocation(line: 106, column: 25, scope: !298, inlinedAt: !241)
!304 = !DILocation(line: 106, column: 28, scope: !298, inlinedAt: !241)
!305 = !DILocation(line: 106, column: 21, scope: !298, inlinedAt: !241)
!306 = !DILocation(line: 106, column: 33, scope: !298, inlinedAt: !241)
!307 = !DILocation(line: 106, column: 35, scope: !298, inlinedAt: !241)
!308 = !DILocation(line: 106, column: 38, scope: !298, inlinedAt: !241)
!309 = !DILocation(line: 106, column: 31, scope: !298, inlinedAt: !241)
!310 = !DILocation(line: 106, column: 4, scope: !298, inlinedAt: !241)
!311 = !DILocation(line: 106, column: 6, scope: !298, inlinedAt: !241)
!312 = !DILocation(line: 106, column: 9, scope: !298, inlinedAt: !241)
!313 = !DILocation(line: 106, column: 12, scope: !298, inlinedAt: !241)
!314 = !DILocation(line: 105, column: 33, scope: !298, inlinedAt: !241)
!315 = !DILocation(line: 105, column: 8, scope: !298, inlinedAt: !241)
!316 = distinct !{!316, !300, !317, !150}
!317 = !DILocation(line: 106, column: 39, scope: !294, inlinedAt: !241)
!318 = !DILocation(line: 104, column: 30, scope: !290, inlinedAt: !241)
!319 = !DILocation(line: 104, column: 5, scope: !290, inlinedAt: !241)
!320 = distinct !{!320, !292, !321, !150}
!321 = !DILocation(line: 107, column: 5, scope: !287, inlinedAt: !241)
!322 = !DILocation(line: 101, column: 28, scope: !266, inlinedAt: !241)
!323 = !DILocation(line: 101, column: 3, scope: !266, inlinedAt: !241)
!324 = distinct !{!324, !268, !325, !150}
!325 = !DILocation(line: 108, column: 3, scope: !263, inlinedAt: !241)
!326 = !DILocation(line: 139, column: 3, scope: !230)
!327 = distinct !DISubprogram(name: "workload_checksum", scope: !11, file: !11, line: 141, type: !328, scopeLine: 141, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !2, retainedNodes: !67)
!328 = !DISubroutineType(types: !329)
!329 = !{!22, !6}
!330 = !DILocalVariable(name: "task", arg: 1, scope: !327, file: !11, line: 141, type: !6)
!331 = !DILocation(line: 141, column: 37, scope: !327)
!332 = !DILocation(line: 142, column: 9, scope: !327)
!333 = !DILocation(line: 143, column: 11, scope: !327)
!334 = !DILocation(line: 144, column: 15, scope: !327)
!335 = !DILocation(line: 144, column: 19, scope: !327)
!336 = !DILocation(line: 144, column: 3, scope: !327)
!337 = !DILocation(line: 145, column: 10, scope: !327)
!338 = !DILocation(line: 145, column: 3, scope: !327)
!339 = distinct !DISubprogram(name: "print_array", scope: !11, file: !11, line: 64, type: !340, scopeLine: 66, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition, unit: !2, retainedNodes: !67)
!340 = !DISubroutineType(types: !341)
!341 = !{null, !12, !12, !87}
!342 = !DILocalVariable(name: "ni", arg: 1, scope: !339, file: !11, line: 64, type: !12)
!343 = !DILocation(line: 64, column: 22, scope: !339)
!344 = !DILocalVariable(name: "nj", arg: 2, scope: !339, file: !11, line: 64, type: !12)
!345 = !DILocation(line: 64, column: 30, scope: !339)
!346 = !DILocalVariable(name: "C", arg: 3, scope: !339, file: !11, line: 65, type: !87)
!347 = !DILocation(line: 65, column: 14, scope: !339)
!348 = !DILocalVariable(name: "i", scope: !339, file: !11, line: 67, type: !12)
!349 = !DILocation(line: 67, column: 7, scope: !339)
!350 = !DILocalVariable(name: "j", scope: !339, file: !11, line: 67, type: !12)
!351 = !DILocation(line: 67, column: 10, scope: !339)
!352 = !DILocation(line: 69, column: 3, scope: !339)
!353 = !DILocation(line: 70, column: 3, scope: !339)
!354 = !DILocation(line: 71, column: 10, scope: !355)
!355 = distinct !DILexicalBlock(scope: !339, file: !11, line: 71, column: 3)
!356 = !DILocation(line: 71, column: 8, scope: !355)
!357 = !DILocation(line: 71, column: 15, scope: !358)
!358 = distinct !DILexicalBlock(scope: !355, file: !11, line: 71, column: 3)
!359 = !DILocation(line: 71, column: 19, scope: !358)
!360 = !DILocation(line: 71, column: 17, scope: !358)
!361 = !DILocation(line: 71, column: 3, scope: !355)
!362 = !DILocation(line: 72, column: 12, scope: !363)
!363 = distinct !DILexicalBlock(scope: !358, file: !11, line: 72, column: 5)
!364 = !DILocation(line: 72, column: 10, scope: !363)
!365 = !DILocation(line: 72, column: 17, scope: !366)
!366 = distinct !DILexicalBlock(scope: !363, file: !11, line: 72, column: 5)
!367 = !DILocation(line: 72, column: 21, scope: !366)
!368 = !DILocation(line: 72, column: 19, scope: !366)
!369 = !DILocation(line: 72, column: 5, scope: !363)
!370 = !DILocation(line: 73, column: 7, scope: !371)
!371 = distinct !DILexicalBlock(scope: !372, file: !11, line: 73, column: 6)
!372 = distinct !DILexicalBlock(scope: !366, file: !11, line: 72, column: 30)
!373 = !DILocation(line: 73, column: 11, scope: !371)
!374 = !DILocation(line: 73, column: 9, scope: !371)
!375 = !DILocation(line: 73, column: 16, scope: !371)
!376 = !DILocation(line: 73, column: 14, scope: !371)
!377 = !DILocation(line: 73, column: 19, scope: !371)
!378 = !DILocation(line: 73, column: 24, scope: !371)
!379 = !DILocation(line: 73, column: 6, scope: !372)
!380 = !DILocation(line: 73, column: 39, scope: !371)
!381 = !DILocation(line: 73, column: 30, scope: !371)
!382 = !DILocation(line: 74, column: 11, scope: !372)
!383 = !DILocation(line: 74, column: 56, scope: !372)
!384 = !DILocation(line: 74, column: 58, scope: !372)
!385 = !DILocation(line: 74, column: 61, scope: !372)
!386 = !DILocation(line: 74, column: 2, scope: !372)
!387 = !DILocation(line: 75, column: 5, scope: !372)
!388 = !DILocation(line: 72, column: 26, scope: !366)
!389 = !DILocation(line: 72, column: 5, scope: !366)
!390 = distinct !{!390, !369, !391, !150}
!391 = !DILocation(line: 75, column: 5, scope: !363)
!392 = !DILocation(line: 71, column: 24, scope: !358)
!393 = !DILocation(line: 71, column: 3, scope: !358)
!394 = distinct !{!394, !361, !395, !150}
!395 = !DILocation(line: 75, column: 5, scope: !355)
!396 = !DILocation(line: 76, column: 3, scope: !339)
!397 = !DILocation(line: 77, column: 3, scope: !339)
!398 = !DILocation(line: 78, column: 1, scope: !339)
!399 = distinct !DISubprogram(name: "pb_fprintf", scope: !34, file: !34, line: 13, type: !400, scopeLine: 14, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition, unit: !2, retainedNodes: !67)
!400 = !DISubroutineType(types: !401)
!401 = !{!12, !402, !461, null}
!402 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !403, size: 64)
!403 = !DIDerivedType(tag: DW_TAG_typedef, name: "FILE", file: !404, line: 7, baseType: !405)
!404 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/types/FILE.h", directory: "", checksumkind: CSK_MD5, checksum: "571f9fb6223c42439075fdde11a0de5d")
!405 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "_IO_FILE", file: !406, line: 49, size: 1728, elements: !407)
!406 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/types/struct_FILE.h", directory: "", checksumkind: CSK_MD5, checksum: "1bad07471b7974df4ecc1d1c2ca207e6")
!407 = !{!408, !409, !412, !413, !414, !415, !416, !417, !418, !419, !420, !421, !422, !425, !427, !428, !429, !432, !434, !436, !438, !441, !443, !446, !449, !450, !452, !456, !457}
!408 = !DIDerivedType(tag: DW_TAG_member, name: "_flags", scope: !405, file: !406, line: 51, baseType: !12, size: 32)
!409 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_read_ptr", scope: !405, file: !406, line: 54, baseType: !410, size: 64, offset: 64)
!410 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !411, size: 64)
!411 = !DIBasicType(name: "char", size: 8, encoding: DW_ATE_signed_char)
!412 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_read_end", scope: !405, file: !406, line: 55, baseType: !410, size: 64, offset: 128)
!413 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_read_base", scope: !405, file: !406, line: 56, baseType: !410, size: 64, offset: 192)
!414 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_write_base", scope: !405, file: !406, line: 57, baseType: !410, size: 64, offset: 256)
!415 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_write_ptr", scope: !405, file: !406, line: 58, baseType: !410, size: 64, offset: 320)
!416 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_write_end", scope: !405, file: !406, line: 59, baseType: !410, size: 64, offset: 384)
!417 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_buf_base", scope: !405, file: !406, line: 60, baseType: !410, size: 64, offset: 448)
!418 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_buf_end", scope: !405, file: !406, line: 61, baseType: !410, size: 64, offset: 512)
!419 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_save_base", scope: !405, file: !406, line: 64, baseType: !410, size: 64, offset: 576)
!420 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_backup_base", scope: !405, file: !406, line: 65, baseType: !410, size: 64, offset: 640)
!421 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_save_end", scope: !405, file: !406, line: 66, baseType: !410, size: 64, offset: 704)
!422 = !DIDerivedType(tag: DW_TAG_member, name: "_markers", scope: !405, file: !406, line: 68, baseType: !423, size: 64, offset: 768)
!423 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !424, size: 64)
!424 = !DICompositeType(tag: DW_TAG_structure_type, name: "_IO_marker", file: !406, line: 36, flags: DIFlagFwdDecl)
!425 = !DIDerivedType(tag: DW_TAG_member, name: "_chain", scope: !405, file: !406, line: 70, baseType: !426, size: 64, offset: 832)
!426 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !405, size: 64)
!427 = !DIDerivedType(tag: DW_TAG_member, name: "_fileno", scope: !405, file: !406, line: 72, baseType: !12, size: 32, offset: 896)
!428 = !DIDerivedType(tag: DW_TAG_member, name: "_flags2", scope: !405, file: !406, line: 73, baseType: !12, size: 32, offset: 928)
!429 = !DIDerivedType(tag: DW_TAG_member, name: "_old_offset", scope: !405, file: !406, line: 74, baseType: !430, size: 64, offset: 960)
!430 = !DIDerivedType(tag: DW_TAG_typedef, name: "__off_t", file: !25, line: 152, baseType: !431)
!431 = !DIBasicType(name: "long", size: 64, encoding: DW_ATE_signed)
!432 = !DIDerivedType(tag: DW_TAG_member, name: "_cur_column", scope: !405, file: !406, line: 77, baseType: !433, size: 16, offset: 1024)
!433 = !DIBasicType(name: "unsigned short", size: 16, encoding: DW_ATE_unsigned)
!434 = !DIDerivedType(tag: DW_TAG_member, name: "_vtable_offset", scope: !405, file: !406, line: 78, baseType: !435, size: 8, offset: 1040)
!435 = !DIBasicType(name: "signed char", size: 8, encoding: DW_ATE_signed_char)
!436 = !DIDerivedType(tag: DW_TAG_member, name: "_shortbuf", scope: !405, file: !406, line: 79, baseType: !437, size: 8, offset: 1048)
!437 = !DICompositeType(tag: DW_TAG_array_type, baseType: !411, size: 8, elements: !26)
!438 = !DIDerivedType(tag: DW_TAG_member, name: "_lock", scope: !405, file: !406, line: 81, baseType: !439, size: 64, offset: 1088)
!439 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !440, size: 64)
!440 = !DIDerivedType(tag: DW_TAG_typedef, name: "_IO_lock_t", file: !406, line: 43, baseType: null)
!441 = !DIDerivedType(tag: DW_TAG_member, name: "_offset", scope: !405, file: !406, line: 89, baseType: !442, size: 64, offset: 1152)
!442 = !DIDerivedType(tag: DW_TAG_typedef, name: "__off64_t", file: !25, line: 153, baseType: !431)
!443 = !DIDerivedType(tag: DW_TAG_member, name: "_codecvt", scope: !405, file: !406, line: 91, baseType: !444, size: 64, offset: 1216)
!444 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !445, size: 64)
!445 = !DICompositeType(tag: DW_TAG_structure_type, name: "_IO_codecvt", file: !406, line: 37, flags: DIFlagFwdDecl)
!446 = !DIDerivedType(tag: DW_TAG_member, name: "_wide_data", scope: !405, file: !406, line: 92, baseType: !447, size: 64, offset: 1280)
!447 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !448, size: 64)
!448 = !DICompositeType(tag: DW_TAG_structure_type, name: "_IO_wide_data", file: !406, line: 38, flags: DIFlagFwdDecl)
!449 = !DIDerivedType(tag: DW_TAG_member, name: "_freeres_list", scope: !405, file: !406, line: 93, baseType: !426, size: 64, offset: 1344)
!450 = !DIDerivedType(tag: DW_TAG_member, name: "_freeres_buf", scope: !405, file: !406, line: 94, baseType: !451, size: 64, offset: 1408)
!451 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: null, size: 64)
!452 = !DIDerivedType(tag: DW_TAG_member, name: "__pad5", scope: !405, file: !406, line: 95, baseType: !453, size: 64, offset: 1472)
!453 = !DIDerivedType(tag: DW_TAG_typedef, name: "size_t", file: !454, line: 46, baseType: !455)
!454 = !DIFile(filename: "/usr/lib/llvm-14/lib/clang/14.0.0/include/stddef.h", directory: "", checksumkind: CSK_MD5, checksum: "2499dd2361b915724b073282bea3a7bc")
!455 = !DIBasicType(name: "unsigned long", size: 64, encoding: DW_ATE_unsigned)
!456 = !DIDerivedType(tag: DW_TAG_member, name: "_mode", scope: !405, file: !406, line: 96, baseType: !12, size: 32, offset: 1536)
!457 = !DIDerivedType(tag: DW_TAG_member, name: "_unused2", scope: !405, file: !406, line: 98, baseType: !458, size: 160, offset: 1568)
!458 = !DICompositeType(tag: DW_TAG_array_type, baseType: !411, size: 160, elements: !459)
!459 = !{!460}
!460 = !DISubrange(count: 20)
!461 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !462, size: 64)
!462 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !411)
!463 = !DILocalVariable(name: "stream", arg: 1, scope: !399, file: !34, line: 13, type: !402)
!464 = !DILocation(line: 13, column: 29, scope: !399)
!465 = !DILocalVariable(name: "format", arg: 2, scope: !399, file: !34, line: 13, type: !461)
!466 = !DILocation(line: 13, column: 49, scope: !399)
!467 = !DILocalVariable(name: "buffer", scope: !399, file: !34, line: 15, type: !468)
!468 = !DICompositeType(tag: DW_TAG_array_type, baseType: !411, size: 6144, elements: !469)
!469 = !{!470}
!470 = !DISubrange(count: 768)
!471 = !DILocation(line: 15, column: 10, scope: !399)
!472 = !DILocalVariable(name: "args", scope: !399, file: !34, line: 16, type: !473)
!473 = !DIDerivedType(tag: DW_TAG_typedef, name: "va_list", file: !474, line: 52, baseType: !475)
!474 = !DIFile(filename: "/usr/include/stdio.h", directory: "", checksumkind: CSK_MD5, checksum: "f31eefcc3f15835fc5a4023a625cf609")
!475 = !DIDerivedType(tag: DW_TAG_typedef, name: "__gnuc_va_list", file: !476, line: 32, baseType: !477)
!476 = !DIFile(filename: "/usr/lib/llvm-14/lib/clang/14.0.0/include/stdarg.h", directory: "", checksumkind: CSK_MD5, checksum: "4de3cbd931b589d291e5c39387aecf82")
!477 = !DIDerivedType(tag: DW_TAG_typedef, name: "__builtin_va_list", file: !478, baseType: !479)
!478 = !DIFile(filename: "source/workload.c", directory: "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/affine-bounds-20260929/suite/gemm")
!479 = !DICompositeType(tag: DW_TAG_array_type, baseType: !480, size: 192, elements: !26)
!480 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "__va_list_tag", size: 192, elements: !481)
!481 = !{!482, !483, !484, !485}
!482 = !DIDerivedType(tag: DW_TAG_member, name: "gp_offset", scope: !480, file: !478, line: 16, baseType: !6, size: 32)
!483 = !DIDerivedType(tag: DW_TAG_member, name: "fp_offset", scope: !480, file: !478, line: 16, baseType: !6, size: 32, offset: 32)
!484 = !DIDerivedType(tag: DW_TAG_member, name: "overflow_arg_area", scope: !480, file: !478, line: 16, baseType: !451, size: 64, offset: 64)
!485 = !DIDerivedType(tag: DW_TAG_member, name: "reg_save_area", scope: !480, file: !478, line: 16, baseType: !451, size: 64, offset: 128)
!486 = !DILocation(line: 16, column: 13, scope: !399)
!487 = !DILocation(line: 17, column: 5, scope: !399)
!488 = !DILocalVariable(name: "count", scope: !399, file: !34, line: 18, type: !12)
!489 = !DILocation(line: 18, column: 9, scope: !399)
!490 = !DILocation(line: 18, column: 27, scope: !399)
!491 = !DILocation(line: 18, column: 51, scope: !399)
!492 = !DILocation(line: 18, column: 59, scope: !399)
!493 = !DILocation(line: 18, column: 17, scope: !399)
!494 = !DILocation(line: 19, column: 5, scope: !399)
!495 = !DILocation(line: 20, column: 9, scope: !496)
!496 = distinct !DILexicalBlock(scope: !399, file: !34, line: 20, column: 9)
!497 = !DILocation(line: 20, column: 15, scope: !496)
!498 = !DILocation(line: 20, column: 19, scope: !496)
!499 = !DILocation(line: 20, column: 32, scope: !496)
!500 = !DILocation(line: 20, column: 22, scope: !496)
!501 = !DILocation(line: 20, column: 38, scope: !496)
!502 = !DILocation(line: 20, column: 9, scope: !399)
!503 = !DILocation(line: 20, column: 57, scope: !496)
!504 = !DILocalVariable(name: "i", scope: !505, file: !34, line: 21, type: !12)
!505 = distinct !DILexicalBlock(scope: !399, file: !34, line: 21, column: 5)
!506 = !DILocation(line: 21, column: 14, scope: !505)
!507 = !DILocation(line: 21, column: 10, scope: !505)
!508 = !DILocation(line: 21, column: 21, scope: !509)
!509 = distinct !DILexicalBlock(scope: !505, file: !34, line: 21, column: 5)
!510 = !DILocation(line: 21, column: 25, scope: !509)
!511 = !DILocation(line: 21, column: 23, scope: !509)
!512 = !DILocation(line: 21, column: 5, scope: !505)
!513 = !DILocation(line: 22, column: 42, scope: !514)
!514 = distinct !DILexicalBlock(scope: !509, file: !34, line: 21, column: 37)
!515 = !DILocation(line: 22, column: 35, scope: !514)
!516 = !DILocation(line: 22, column: 20, scope: !514)
!517 = !DILocation(line: 22, column: 17, scope: !514)
!518 = !DILocation(line: 23, column: 17, scope: !514)
!519 = !DILocation(line: 24, column: 5, scope: !514)
!520 = !DILocation(line: 21, column: 32, scope: !509)
!521 = !DILocation(line: 21, column: 5, scope: !509)
!522 = distinct !{!522, !512, !523, !150}
!523 = !DILocation(line: 24, column: 5, scope: !505)
!524 = !DILocation(line: 28, column: 11, scope: !399)
!525 = !DILocation(line: 29, column: 11, scope: !399)
!526 = !DILocation(line: 31, column: 12, scope: !399)
!527 = !DILocation(line: 31, column: 5, scope: !399)
