; ModuleID = 'inlined.ll'
source_filename = "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/affine-bounds-20260929/suite/3mm/source/workload.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

@ni = external dso_local global i32, align 4, !dbg !0
@nj = external dso_local global i32, align 4, !dbg !9
@nk = external dso_local global i32, align 4, !dbg !13
@nl = external dso_local global i32, align 4, !dbg !15
@nm = external dso_local global i32, align 4, !dbg !17
@E = external dso_local global [180 x [190 x double]], section ".chaser_data.E", align 64, !dbg !19
@A = external dso_local global [180 x [200 x double]], section ".chaser_data.A", align 64, !dbg !25
@B = external dso_local global [200 x [190 x double]], section ".chaser_data.B", align 64, !dbg !30
@F = external dso_local global [190 x [210 x double]], section ".chaser_data.F", align 64, !dbg !34
@C = external dso_local global [190 x [220 x double]], section ".chaser_data.C", align 64, !dbg !39
@D = external dso_local global [220 x [210 x double]], section ".chaser_data.D", align 64, !dbg !44
@G = external dso_local global [180 x [210 x double]], section ".chaser_data.G", align 64, !dbg !48
@.str = hidden unnamed_addr constant [12 x i8] c"ape.analyze\00", section "llvm.metadata"
@.str.1 = hidden unnamed_addr constant [121 x i8] c"/workspace/experiments-array-support/chaser/.cache/periodic-polybench/affine-bounds-20260929/suite/3mm/source/workload.c\00", section "llvm.metadata"
@.str.2 = hidden unnamed_addr constant [23 x i8] c"==BEGIN DUMP_ARRAYS==\0A\00", align 1
@.str.3 = hidden unnamed_addr constant [15 x i8] c"begin dump: %s\00", align 1
@.str.4 = hidden unnamed_addr constant [2 x i8] c"G\00", align 1
@.str.5 = hidden unnamed_addr constant [2 x i8] c"\0A\00", align 1
@.str.6 = hidden unnamed_addr constant [8 x i8] c"%0.2lf \00", align 1
@.str.7 = hidden unnamed_addr constant [17 x i8] c"\0Aend   dump: %s\0A\00", align 1
@.str.8 = hidden unnamed_addr constant [23 x i8] c"==END   DUMP_ARRAYS==\0A\00", align 1
@llvm.global.annotations = appending global [1 x { i8*, i8*, i8*, i32, i8* }] [{ i8*, i8*, i8*, i32, i8* } { i8* bitcast (i32 ()* @task_job_polybench to i8*), i8* getelementptr inbounds ([12 x i8], [12 x i8]* @.str, i32 0, i32 0), i8* getelementptr inbounds ([121 x i8], [121 x i8]* @.str.1, i32 0, i32 0), i32 151, i8* null }], section "llvm.metadata"

; Function Attrs: noinline nounwind uwtable
define dso_local i32 @task_job_polybench() #0 !dbg !60 {
  %1 = load i32, i32* @ni, align 4, !dbg !68
  %2 = load i32, i32* @nj, align 4, !dbg !69
  %3 = load i32, i32* @nk, align 4, !dbg !70
  %4 = load i32, i32* @nl, align 4, !dbg !71
  %5 = load i32, i32* @nm, align 4, !dbg !72
  call void @llvm.dbg.value(metadata i32 %1, metadata !73, metadata !DIExpression()), !dbg !89
  call void @llvm.dbg.value(metadata i32 %2, metadata !91, metadata !DIExpression()), !dbg !89
  call void @llvm.dbg.value(metadata i32 %3, metadata !92, metadata !DIExpression()), !dbg !89
  call void @llvm.dbg.value(metadata i32 %4, metadata !93, metadata !DIExpression()), !dbg !89
  call void @llvm.dbg.value(metadata i32 %5, metadata !94, metadata !DIExpression()), !dbg !89
  call void @llvm.dbg.value(metadata [190 x double]* getelementptr inbounds ([180 x [190 x double]], [180 x [190 x double]]* @E, i64 0, i64 0), metadata !95, metadata !DIExpression()), !dbg !89
  call void @llvm.dbg.value(metadata [200 x double]* getelementptr inbounds ([180 x [200 x double]], [180 x [200 x double]]* @A, i64 0, i64 0), metadata !96, metadata !DIExpression()), !dbg !89
  call void @llvm.dbg.value(metadata [190 x double]* getelementptr inbounds ([200 x [190 x double]], [200 x [190 x double]]* @B, i64 0, i64 0), metadata !97, metadata !DIExpression()), !dbg !89
  call void @llvm.dbg.value(metadata [210 x double]* getelementptr inbounds ([190 x [210 x double]], [190 x [210 x double]]* @F, i64 0, i64 0), metadata !98, metadata !DIExpression()), !dbg !89
  call void @llvm.dbg.value(metadata [220 x double]* getelementptr inbounds ([190 x [220 x double]], [190 x [220 x double]]* @C, i64 0, i64 0), metadata !99, metadata !DIExpression()), !dbg !89
  call void @llvm.dbg.value(metadata [210 x double]* getelementptr inbounds ([220 x [210 x double]], [220 x [210 x double]]* @D, i64 0, i64 0), metadata !100, metadata !DIExpression()), !dbg !89
  call void @llvm.dbg.value(metadata [210 x double]* getelementptr inbounds ([180 x [210 x double]], [180 x [210 x double]]* @G, i64 0, i64 0), metadata !101, metadata !DIExpression()), !dbg !89
  call void @llvm.dbg.value(metadata i32 0, metadata !102, metadata !DIExpression()), !dbg !89
  br label %6, !dbg !103

6:                                                ; preds = %39, %0
  %.04 = phi i32 [ 0, %0 ], [ %40, %39 ], !dbg !105
  call void @llvm.dbg.value(metadata i32 %.04, metadata !102, metadata !DIExpression()), !dbg !89
  %7 = icmp slt i32 %.04, 180, !dbg !106
  br i1 %7, label %8, label %41, !dbg !108

8:                                                ; preds = %6
  call void @llvm.dbg.value(metadata i32 0, metadata !109, metadata !DIExpression()), !dbg !89
  br label %9, !dbg !110

9:                                                ; preds = %37, %8
  %.01 = phi i32 [ 0, %8 ], [ %38, %37 ], !dbg !112
  call void @llvm.dbg.value(metadata i32 %.01, metadata !109, metadata !DIExpression()), !dbg !89
  %10 = icmp slt i32 %.01, 190, !dbg !113
  br i1 %10, label %11, label %39, !dbg !115

11:                                               ; preds = %9
  %12 = sext i32 %.04 to i64, !dbg !116
  %13 = getelementptr inbounds [190 x double], [190 x double]* getelementptr inbounds ([180 x [190 x double]], [180 x [190 x double]]* @E, i64 0, i64 0), i64 %12, !dbg !116
  %14 = sext i32 %.01 to i64, !dbg !116
  %15 = getelementptr inbounds [190 x double], [190 x double]* %13, i64 0, i64 %14, !dbg !116
  store double 0.000000e+00, double* %15, align 8, !dbg !118
  call void @llvm.dbg.value(metadata i32 0, metadata !119, metadata !DIExpression()), !dbg !89
  br label %16, !dbg !120

16:                                               ; preds = %18, %11
  %.0 = phi i32 [ 0, %11 ], [ %36, %18 ], !dbg !122
  call void @llvm.dbg.value(metadata i32 %.0, metadata !119, metadata !DIExpression()), !dbg !89
  %17 = icmp slt i32 %.0, 200, !dbg !123
  br i1 %17, label %18, label %37, !dbg !125

18:                                               ; preds = %16
  %19 = sext i32 %.04 to i64, !dbg !126
  %20 = getelementptr inbounds [200 x double], [200 x double]* getelementptr inbounds ([180 x [200 x double]], [180 x [200 x double]]* @A, i64 0, i64 0), i64 %19, !dbg !126
  %21 = sext i32 %.0 to i64, !dbg !126
  %22 = getelementptr inbounds [200 x double], [200 x double]* %20, i64 0, i64 %21, !dbg !126
  %23 = load double, double* %22, align 8, !dbg !126
  %24 = sext i32 %.0 to i64, !dbg !127
  %25 = getelementptr inbounds [190 x double], [190 x double]* getelementptr inbounds ([200 x [190 x double]], [200 x [190 x double]]* @B, i64 0, i64 0), i64 %24, !dbg !127
  %26 = sext i32 %.01 to i64, !dbg !127
  %27 = getelementptr inbounds [190 x double], [190 x double]* %25, i64 0, i64 %26, !dbg !127
  %28 = load double, double* %27, align 8, !dbg !127
  %29 = fmul double %23, %28, !dbg !128
  %30 = sext i32 %.04 to i64, !dbg !129
  %31 = getelementptr inbounds [190 x double], [190 x double]* getelementptr inbounds ([180 x [190 x double]], [180 x [190 x double]]* @E, i64 0, i64 0), i64 %30, !dbg !129
  %32 = sext i32 %.01 to i64, !dbg !129
  %33 = getelementptr inbounds [190 x double], [190 x double]* %31, i64 0, i64 %32, !dbg !129
  %34 = load double, double* %33, align 8, !dbg !130
  %35 = fadd double %34, %29, !dbg !130
  store double %35, double* %33, align 8, !dbg !130
  %36 = add nsw i32 %.0, 1, !dbg !131
  call void @llvm.dbg.value(metadata i32 %36, metadata !119, metadata !DIExpression()), !dbg !89
  br label %16, !dbg !132, !llvm.loop !133

37:                                               ; preds = %16
  %38 = add nsw i32 %.01, 1, !dbg !136
  call void @llvm.dbg.value(metadata i32 %38, metadata !109, metadata !DIExpression()), !dbg !89
  br label %9, !dbg !137, !llvm.loop !138

39:                                               ; preds = %9
  %40 = add nsw i32 %.04, 1, !dbg !140
  call void @llvm.dbg.value(metadata i32 %40, metadata !102, metadata !DIExpression()), !dbg !89
  br label %6, !dbg !141, !llvm.loop !142

41:                                               ; preds = %6
  call void @llvm.dbg.value(metadata i32 0, metadata !102, metadata !DIExpression()), !dbg !89
  br label %42, !dbg !144

42:                                               ; preds = %75, %41
  %.15 = phi i32 [ 0, %41 ], [ %76, %75 ], !dbg !146
  call void @llvm.dbg.value(metadata i32 %.15, metadata !102, metadata !DIExpression()), !dbg !89
  %43 = icmp slt i32 %.15, 190, !dbg !147
  br i1 %43, label %44, label %77, !dbg !149

44:                                               ; preds = %42
  call void @llvm.dbg.value(metadata i32 0, metadata !109, metadata !DIExpression()), !dbg !89
  br label %45, !dbg !150

45:                                               ; preds = %73, %44
  %.12 = phi i32 [ 0, %44 ], [ %74, %73 ], !dbg !152
  call void @llvm.dbg.value(metadata i32 %.12, metadata !109, metadata !DIExpression()), !dbg !89
  %46 = icmp slt i32 %.12, 210, !dbg !153
  br i1 %46, label %47, label %75, !dbg !155

47:                                               ; preds = %45
  %48 = sext i32 %.15 to i64, !dbg !156
  %49 = getelementptr inbounds [210 x double], [210 x double]* getelementptr inbounds ([190 x [210 x double]], [190 x [210 x double]]* @F, i64 0, i64 0), i64 %48, !dbg !156
  %50 = sext i32 %.12 to i64, !dbg !156
  %51 = getelementptr inbounds [210 x double], [210 x double]* %49, i64 0, i64 %50, !dbg !156
  store double 0.000000e+00, double* %51, align 8, !dbg !158
  call void @llvm.dbg.value(metadata i32 0, metadata !119, metadata !DIExpression()), !dbg !89
  br label %52, !dbg !159

52:                                               ; preds = %54, %47
  %.1 = phi i32 [ 0, %47 ], [ %72, %54 ], !dbg !161
  call void @llvm.dbg.value(metadata i32 %.1, metadata !119, metadata !DIExpression()), !dbg !89
  %53 = icmp slt i32 %.1, 220, !dbg !162
  br i1 %53, label %54, label %73, !dbg !164

54:                                               ; preds = %52
  %55 = sext i32 %.15 to i64, !dbg !165
  %56 = getelementptr inbounds [220 x double], [220 x double]* getelementptr inbounds ([190 x [220 x double]], [190 x [220 x double]]* @C, i64 0, i64 0), i64 %55, !dbg !165
  %57 = sext i32 %.1 to i64, !dbg !165
  %58 = getelementptr inbounds [220 x double], [220 x double]* %56, i64 0, i64 %57, !dbg !165
  %59 = load double, double* %58, align 8, !dbg !165
  %60 = sext i32 %.1 to i64, !dbg !166
  %61 = getelementptr inbounds [210 x double], [210 x double]* getelementptr inbounds ([220 x [210 x double]], [220 x [210 x double]]* @D, i64 0, i64 0), i64 %60, !dbg !166
  %62 = sext i32 %.12 to i64, !dbg !166
  %63 = getelementptr inbounds [210 x double], [210 x double]* %61, i64 0, i64 %62, !dbg !166
  %64 = load double, double* %63, align 8, !dbg !166
  %65 = fmul double %59, %64, !dbg !167
  %66 = sext i32 %.15 to i64, !dbg !168
  %67 = getelementptr inbounds [210 x double], [210 x double]* getelementptr inbounds ([190 x [210 x double]], [190 x [210 x double]]* @F, i64 0, i64 0), i64 %66, !dbg !168
  %68 = sext i32 %.12 to i64, !dbg !168
  %69 = getelementptr inbounds [210 x double], [210 x double]* %67, i64 0, i64 %68, !dbg !168
  %70 = load double, double* %69, align 8, !dbg !169
  %71 = fadd double %70, %65, !dbg !169
  store double %71, double* %69, align 8, !dbg !169
  %72 = add nsw i32 %.1, 1, !dbg !170
  call void @llvm.dbg.value(metadata i32 %72, metadata !119, metadata !DIExpression()), !dbg !89
  br label %52, !dbg !171, !llvm.loop !172

73:                                               ; preds = %52
  %74 = add nsw i32 %.12, 1, !dbg !174
  call void @llvm.dbg.value(metadata i32 %74, metadata !109, metadata !DIExpression()), !dbg !89
  br label %45, !dbg !175, !llvm.loop !176

75:                                               ; preds = %45
  %76 = add nsw i32 %.15, 1, !dbg !178
  call void @llvm.dbg.value(metadata i32 %76, metadata !102, metadata !DIExpression()), !dbg !89
  br label %42, !dbg !179, !llvm.loop !180

77:                                               ; preds = %42
  call void @llvm.dbg.value(metadata i32 0, metadata !102, metadata !DIExpression()), !dbg !89
  br label %78, !dbg !182

78:                                               ; preds = %111, %77
  %.26 = phi i32 [ 0, %77 ], [ %112, %111 ], !dbg !184
  call void @llvm.dbg.value(metadata i32 %.26, metadata !102, metadata !DIExpression()), !dbg !89
  %79 = icmp slt i32 %.26, 180, !dbg !185
  br i1 %79, label %80, label %113, !dbg !187

80:                                               ; preds = %78
  call void @llvm.dbg.value(metadata i32 0, metadata !109, metadata !DIExpression()), !dbg !89
  br label %81, !dbg !188

81:                                               ; preds = %109, %80
  %.23 = phi i32 [ 0, %80 ], [ %110, %109 ], !dbg !190
  call void @llvm.dbg.value(metadata i32 %.23, metadata !109, metadata !DIExpression()), !dbg !89
  %82 = icmp slt i32 %.23, 210, !dbg !191
  br i1 %82, label %83, label %111, !dbg !193

83:                                               ; preds = %81
  %84 = sext i32 %.26 to i64, !dbg !194
  %85 = getelementptr inbounds [210 x double], [210 x double]* getelementptr inbounds ([180 x [210 x double]], [180 x [210 x double]]* @G, i64 0, i64 0), i64 %84, !dbg !194
  %86 = sext i32 %.23 to i64, !dbg !194
  %87 = getelementptr inbounds [210 x double], [210 x double]* %85, i64 0, i64 %86, !dbg !194
  store double 0.000000e+00, double* %87, align 8, !dbg !196
  call void @llvm.dbg.value(metadata i32 0, metadata !119, metadata !DIExpression()), !dbg !89
  br label %88, !dbg !197

88:                                               ; preds = %90, %83
  %.2 = phi i32 [ 0, %83 ], [ %108, %90 ], !dbg !199
  call void @llvm.dbg.value(metadata i32 %.2, metadata !119, metadata !DIExpression()), !dbg !89
  %89 = icmp slt i32 %.2, 190, !dbg !200
  br i1 %89, label %90, label %109, !dbg !202

90:                                               ; preds = %88
  %91 = sext i32 %.26 to i64, !dbg !203
  %92 = getelementptr inbounds [190 x double], [190 x double]* getelementptr inbounds ([180 x [190 x double]], [180 x [190 x double]]* @E, i64 0, i64 0), i64 %91, !dbg !203
  %93 = sext i32 %.2 to i64, !dbg !203
  %94 = getelementptr inbounds [190 x double], [190 x double]* %92, i64 0, i64 %93, !dbg !203
  %95 = load double, double* %94, align 8, !dbg !203
  %96 = sext i32 %.2 to i64, !dbg !204
  %97 = getelementptr inbounds [210 x double], [210 x double]* getelementptr inbounds ([190 x [210 x double]], [190 x [210 x double]]* @F, i64 0, i64 0), i64 %96, !dbg !204
  %98 = sext i32 %.23 to i64, !dbg !204
  %99 = getelementptr inbounds [210 x double], [210 x double]* %97, i64 0, i64 %98, !dbg !204
  %100 = load double, double* %99, align 8, !dbg !204
  %101 = fmul double %95, %100, !dbg !205
  %102 = sext i32 %.26 to i64, !dbg !206
  %103 = getelementptr inbounds [210 x double], [210 x double]* getelementptr inbounds ([180 x [210 x double]], [180 x [210 x double]]* @G, i64 0, i64 0), i64 %102, !dbg !206
  %104 = sext i32 %.23 to i64, !dbg !206
  %105 = getelementptr inbounds [210 x double], [210 x double]* %103, i64 0, i64 %104, !dbg !206
  %106 = load double, double* %105, align 8, !dbg !207
  %107 = fadd double %106, %101, !dbg !207
  store double %107, double* %105, align 8, !dbg !207
  %108 = add nsw i32 %.2, 1, !dbg !208
  call void @llvm.dbg.value(metadata i32 %108, metadata !119, metadata !DIExpression()), !dbg !89
  br label %88, !dbg !209, !llvm.loop !210

109:                                              ; preds = %88
  %110 = add nsw i32 %.23, 1, !dbg !212
  call void @llvm.dbg.value(metadata i32 %110, metadata !109, metadata !DIExpression()), !dbg !89
  br label %81, !dbg !213, !llvm.loop !214

111:                                              ; preds = %81
  %112 = add nsw i32 %.26, 1, !dbg !216
  call void @llvm.dbg.value(metadata i32 %112, metadata !102, metadata !DIExpression()), !dbg !89
  br label %78, !dbg !217, !llvm.loop !218

113:                                              ; preds = %78
  ret i32 0, !dbg !220
}

; Function Attrs: nofree nosync nounwind readnone speculatable willreturn
declare void @llvm.dbg.value(metadata, metadata, metadata) #1

attributes #0 = { noinline nounwind uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { nofree nosync nounwind readnone speculatable willreturn }

!llvm.dbg.cu = !{!2}
!llvm.module.flags = !{!52, !53, !54, !55, !56, !57, !58}
!llvm.ident = !{!59}

!0 = !DIGlobalVariableExpression(var: !1, expr: !DIExpression())
!1 = distinct !DIGlobalVariable(name: "ni", scope: !2, file: !11, line: 130, type: !12, isLocal: false, isDefinition: true)
!2 = distinct !DICompileUnit(language: DW_LANG_C99, file: !3, producer: "Ubuntu clang version 14.0.0-1ubuntu1.1", isOptimized: false, runtimeVersion: 0, emissionKind: FullDebug, retainedTypes: !4, globals: !8, splitDebugInlining: false, nameTableKind: None)
!3 = !DIFile(filename: "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/affine-bounds-20260929/suite/3mm/source/workload.c", directory: "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/affine-bounds-20260929/suite/3mm/analysis-g", checksumkind: CSK_MD5, checksum: "1c405f3e7488fe5ad3ee534d675a4089")
!4 = !{!5, !6, !7}
!5 = !DIBasicType(name: "double", size: 64, encoding: DW_ATE_float)
!6 = !DIBasicType(name: "unsigned int", size: 32, encoding: DW_ATE_unsigned)
!7 = !DIBasicType(name: "unsigned char", size: 8, encoding: DW_ATE_unsigned_char)
!8 = !{!0, !9, !13, !15, !17, !19, !25, !30, !34, !39, !44, !48}
!9 = !DIGlobalVariableExpression(var: !10, expr: !DIExpression())
!10 = distinct !DIGlobalVariable(name: "nj", scope: !2, file: !11, line: 131, type: !12, isLocal: false, isDefinition: true)
!11 = !DIFile(filename: "source/workload.c", directory: "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/affine-bounds-20260929/suite/3mm", checksumkind: CSK_MD5, checksum: "1c405f3e7488fe5ad3ee534d675a4089")
!12 = !DIBasicType(name: "int", size: 32, encoding: DW_ATE_signed)
!13 = !DIGlobalVariableExpression(var: !14, expr: !DIExpression())
!14 = distinct !DIGlobalVariable(name: "nk", scope: !2, file: !11, line: 132, type: !12, isLocal: false, isDefinition: true)
!15 = !DIGlobalVariableExpression(var: !16, expr: !DIExpression())
!16 = distinct !DIGlobalVariable(name: "nl", scope: !2, file: !11, line: 133, type: !12, isLocal: false, isDefinition: true)
!17 = !DIGlobalVariableExpression(var: !18, expr: !DIExpression())
!18 = distinct !DIGlobalVariable(name: "nm", scope: !2, file: !11, line: 134, type: !12, isLocal: false, isDefinition: true)
!19 = !DIGlobalVariableExpression(var: !20, expr: !DIExpression())
!20 = distinct !DIGlobalVariable(name: "E", scope: !2, file: !11, line: 34, type: !21, isLocal: false, isDefinition: true, align: 512)
!21 = !DICompositeType(tag: DW_TAG_array_type, baseType: !5, size: 2188800, elements: !22)
!22 = !{!23, !24}
!23 = !DISubrange(count: 180)
!24 = !DISubrange(count: 190)
!25 = !DIGlobalVariableExpression(var: !26, expr: !DIExpression())
!26 = distinct !DIGlobalVariable(name: "A", scope: !2, file: !11, line: 35, type: !27, isLocal: false, isDefinition: true, align: 512)
!27 = !DICompositeType(tag: DW_TAG_array_type, baseType: !5, size: 2304000, elements: !28)
!28 = !{!23, !29}
!29 = !DISubrange(count: 200)
!30 = !DIGlobalVariableExpression(var: !31, expr: !DIExpression())
!31 = distinct !DIGlobalVariable(name: "B", scope: !2, file: !11, line: 36, type: !32, isLocal: false, isDefinition: true, align: 512)
!32 = !DICompositeType(tag: DW_TAG_array_type, baseType: !5, size: 2432000, elements: !33)
!33 = !{!29, !24}
!34 = !DIGlobalVariableExpression(var: !35, expr: !DIExpression())
!35 = distinct !DIGlobalVariable(name: "F", scope: !2, file: !11, line: 37, type: !36, isLocal: false, isDefinition: true, align: 512)
!36 = !DICompositeType(tag: DW_TAG_array_type, baseType: !5, size: 2553600, elements: !37)
!37 = !{!24, !38}
!38 = !DISubrange(count: 210)
!39 = !DIGlobalVariableExpression(var: !40, expr: !DIExpression())
!40 = distinct !DIGlobalVariable(name: "C", scope: !2, file: !11, line: 38, type: !41, isLocal: false, isDefinition: true, align: 512)
!41 = !DICompositeType(tag: DW_TAG_array_type, baseType: !5, size: 2675200, elements: !42)
!42 = !{!24, !43}
!43 = !DISubrange(count: 220)
!44 = !DIGlobalVariableExpression(var: !45, expr: !DIExpression())
!45 = distinct !DIGlobalVariable(name: "D", scope: !2, file: !11, line: 39, type: !46, isLocal: false, isDefinition: true, align: 512)
!46 = !DICompositeType(tag: DW_TAG_array_type, baseType: !5, size: 2956800, elements: !47)
!47 = !{!43, !38}
!48 = !DIGlobalVariableExpression(var: !49, expr: !DIExpression())
!49 = distinct !DIGlobalVariable(name: "G", scope: !2, file: !11, line: 40, type: !50, isLocal: false, isDefinition: true, align: 512)
!50 = !DICompositeType(tag: DW_TAG_array_type, baseType: !5, size: 2419200, elements: !51)
!51 = !{!23, !38}
!52 = !{i32 7, !"Dwarf Version", i32 5}
!53 = !{i32 2, !"Debug Info Version", i32 3}
!54 = !{i32 1, !"wchar_size", i32 4}
!55 = !{i32 7, !"PIC Level", i32 2}
!56 = !{i32 7, !"PIE Level", i32 2}
!57 = !{i32 7, !"uwtable", i32 1}
!58 = !{i32 7, !"frame-pointer", i32 2}
!59 = !{!"Ubuntu clang version 14.0.0-1ubuntu1.1"}
!60 = distinct !DISubprogram(name: "task_job_polybench", scope: !11, file: !11, line: 151, type: !61, scopeLine: 151, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !2, retainedNodes: !67)
!61 = !DISubroutineType(types: !62)
!62 = !{!63}
!63 = !DIDerivedType(tag: DW_TAG_typedef, name: "uint32_t", file: !64, line: 26, baseType: !65)
!64 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/stdint-uintn.h", directory: "", checksumkind: CSK_MD5, checksum: "2bf2ae53c58c01b1a1b9383b5195125c")
!65 = !DIDerivedType(tag: DW_TAG_typedef, name: "__uint32_t", file: !66, line: 42, baseType: !6)
!66 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/types.h", directory: "", checksumkind: CSK_MD5, checksum: "d108b5f93a74c50510d7d9bc0ab36df9")
!67 = !{}
!68 = !DILocation(line: 152, column: 15, scope: !60)
!69 = !DILocation(line: 152, column: 19, scope: !60)
!70 = !DILocation(line: 152, column: 23, scope: !60)
!71 = !DILocation(line: 152, column: 27, scope: !60)
!72 = !DILocation(line: 152, column: 31, scope: !60)
!73 = !DILocalVariable(name: "ni", arg: 1, scope: !74, file: !11, line: 88, type: !12)
!74 = distinct !DISubprogram(name: "kernel_3mm", scope: !11, file: !11, line: 88, type: !75, scopeLine: 96, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition, unit: !2, retainedNodes: !67)
!75 = !DISubroutineType(types: !76)
!76 = !{null, !12, !12, !12, !12, !12, !77, !80, !77, !83, !86, !83, !83}
!77 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !78, size: 64)
!78 = !DICompositeType(tag: DW_TAG_array_type, baseType: !5, size: 12160, elements: !79)
!79 = !{!24}
!80 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !81, size: 64)
!81 = !DICompositeType(tag: DW_TAG_array_type, baseType: !5, size: 12800, elements: !82)
!82 = !{!29}
!83 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !84, size: 64)
!84 = !DICompositeType(tag: DW_TAG_array_type, baseType: !5, size: 13440, elements: !85)
!85 = !{!38}
!86 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !87, size: 64)
!87 = !DICompositeType(tag: DW_TAG_array_type, baseType: !5, size: 14080, elements: !88)
!88 = !{!43}
!89 = !DILocation(line: 0, scope: !74, inlinedAt: !90)
!90 = distinct !DILocation(line: 152, column: 3, scope: !60)
!91 = !DILocalVariable(name: "nj", arg: 2, scope: !74, file: !11, line: 88, type: !12)
!92 = !DILocalVariable(name: "nk", arg: 3, scope: !74, file: !11, line: 88, type: !12)
!93 = !DILocalVariable(name: "nl", arg: 4, scope: !74, file: !11, line: 88, type: !12)
!94 = !DILocalVariable(name: "nm", arg: 5, scope: !74, file: !11, line: 88, type: !12)
!95 = !DILocalVariable(name: "E", arg: 6, scope: !74, file: !11, line: 89, type: !77)
!96 = !DILocalVariable(name: "A", arg: 7, scope: !74, file: !11, line: 90, type: !80)
!97 = !DILocalVariable(name: "B", arg: 8, scope: !74, file: !11, line: 91, type: !77)
!98 = !DILocalVariable(name: "F", arg: 9, scope: !74, file: !11, line: 92, type: !83)
!99 = !DILocalVariable(name: "C", arg: 10, scope: !74, file: !11, line: 93, type: !86)
!100 = !DILocalVariable(name: "D", arg: 11, scope: !74, file: !11, line: 94, type: !83)
!101 = !DILocalVariable(name: "G", arg: 12, scope: !74, file: !11, line: 95, type: !83)
!102 = !DILocalVariable(name: "i", scope: !74, file: !11, line: 97, type: !12)
!103 = !DILocation(line: 101, column: 8, scope: !104, inlinedAt: !90)
!104 = distinct !DILexicalBlock(scope: !74, file: !11, line: 101, column: 3)
!105 = !DILocation(line: 0, scope: !104, inlinedAt: !90)
!106 = !DILocation(line: 101, column: 17, scope: !107, inlinedAt: !90)
!107 = distinct !DILexicalBlock(scope: !104, file: !11, line: 101, column: 3)
!108 = !DILocation(line: 101, column: 3, scope: !104, inlinedAt: !90)
!109 = !DILocalVariable(name: "j", scope: !74, file: !11, line: 97, type: !12)
!110 = !DILocation(line: 102, column: 10, scope: !111, inlinedAt: !90)
!111 = distinct !DILexicalBlock(scope: !107, file: !11, line: 102, column: 5)
!112 = !DILocation(line: 0, scope: !111, inlinedAt: !90)
!113 = !DILocation(line: 102, column: 19, scope: !114, inlinedAt: !90)
!114 = distinct !DILexicalBlock(scope: !111, file: !11, line: 102, column: 5)
!115 = !DILocation(line: 102, column: 5, scope: !111, inlinedAt: !90)
!116 = !DILocation(line: 104, column: 2, scope: !117, inlinedAt: !90)
!117 = distinct !DILexicalBlock(scope: !114, file: !11, line: 103, column: 7)
!118 = !DILocation(line: 104, column: 10, scope: !117, inlinedAt: !90)
!119 = !DILocalVariable(name: "k", scope: !74, file: !11, line: 97, type: !12)
!120 = !DILocation(line: 105, column: 7, scope: !121, inlinedAt: !90)
!121 = distinct !DILexicalBlock(scope: !117, file: !11, line: 105, column: 2)
!122 = !DILocation(line: 0, scope: !121, inlinedAt: !90)
!123 = !DILocation(line: 105, column: 16, scope: !124, inlinedAt: !90)
!124 = distinct !DILexicalBlock(scope: !121, file: !11, line: 105, column: 2)
!125 = !DILocation(line: 105, column: 2, scope: !121, inlinedAt: !90)
!126 = !DILocation(line: 106, column: 15, scope: !124, inlinedAt: !90)
!127 = !DILocation(line: 106, column: 25, scope: !124, inlinedAt: !90)
!128 = !DILocation(line: 106, column: 23, scope: !124, inlinedAt: !90)
!129 = !DILocation(line: 106, column: 4, scope: !124, inlinedAt: !90)
!130 = !DILocation(line: 106, column: 12, scope: !124, inlinedAt: !90)
!131 = !DILocation(line: 105, column: 26, scope: !124, inlinedAt: !90)
!132 = !DILocation(line: 105, column: 2, scope: !124, inlinedAt: !90)
!133 = distinct !{!133, !125, !134, !135}
!134 = !DILocation(line: 106, column: 31, scope: !121, inlinedAt: !90)
!135 = !{!"llvm.loop.mustprogress"}
!136 = !DILocation(line: 102, column: 30, scope: !114, inlinedAt: !90)
!137 = !DILocation(line: 102, column: 5, scope: !114, inlinedAt: !90)
!138 = distinct !{!138, !115, !139, !135}
!139 = !DILocation(line: 107, column: 7, scope: !111, inlinedAt: !90)
!140 = !DILocation(line: 101, column: 28, scope: !107, inlinedAt: !90)
!141 = !DILocation(line: 101, column: 3, scope: !107, inlinedAt: !90)
!142 = distinct !{!142, !108, !143, !135}
!143 = !DILocation(line: 107, column: 7, scope: !104, inlinedAt: !90)
!144 = !DILocation(line: 109, column: 8, scope: !145, inlinedAt: !90)
!145 = distinct !DILexicalBlock(scope: !74, file: !11, line: 109, column: 3)
!146 = !DILocation(line: 0, scope: !145, inlinedAt: !90)
!147 = !DILocation(line: 109, column: 17, scope: !148, inlinedAt: !90)
!148 = distinct !DILexicalBlock(scope: !145, file: !11, line: 109, column: 3)
!149 = !DILocation(line: 109, column: 3, scope: !145, inlinedAt: !90)
!150 = !DILocation(line: 110, column: 10, scope: !151, inlinedAt: !90)
!151 = distinct !DILexicalBlock(scope: !148, file: !11, line: 110, column: 5)
!152 = !DILocation(line: 0, scope: !151, inlinedAt: !90)
!153 = !DILocation(line: 110, column: 19, scope: !154, inlinedAt: !90)
!154 = distinct !DILexicalBlock(scope: !151, file: !11, line: 110, column: 5)
!155 = !DILocation(line: 110, column: 5, scope: !151, inlinedAt: !90)
!156 = !DILocation(line: 112, column: 2, scope: !157, inlinedAt: !90)
!157 = distinct !DILexicalBlock(scope: !154, file: !11, line: 111, column: 7)
!158 = !DILocation(line: 112, column: 10, scope: !157, inlinedAt: !90)
!159 = !DILocation(line: 113, column: 7, scope: !160, inlinedAt: !90)
!160 = distinct !DILexicalBlock(scope: !157, file: !11, line: 113, column: 2)
!161 = !DILocation(line: 0, scope: !160, inlinedAt: !90)
!162 = !DILocation(line: 113, column: 16, scope: !163, inlinedAt: !90)
!163 = distinct !DILexicalBlock(scope: !160, file: !11, line: 113, column: 2)
!164 = !DILocation(line: 113, column: 2, scope: !160, inlinedAt: !90)
!165 = !DILocation(line: 114, column: 15, scope: !163, inlinedAt: !90)
!166 = !DILocation(line: 114, column: 25, scope: !163, inlinedAt: !90)
!167 = !DILocation(line: 114, column: 23, scope: !163, inlinedAt: !90)
!168 = !DILocation(line: 114, column: 4, scope: !163, inlinedAt: !90)
!169 = !DILocation(line: 114, column: 12, scope: !163, inlinedAt: !90)
!170 = !DILocation(line: 113, column: 26, scope: !163, inlinedAt: !90)
!171 = !DILocation(line: 113, column: 2, scope: !163, inlinedAt: !90)
!172 = distinct !{!172, !164, !173, !135}
!173 = !DILocation(line: 114, column: 31, scope: !160, inlinedAt: !90)
!174 = !DILocation(line: 110, column: 30, scope: !154, inlinedAt: !90)
!175 = !DILocation(line: 110, column: 5, scope: !154, inlinedAt: !90)
!176 = distinct !{!176, !155, !177, !135}
!177 = !DILocation(line: 115, column: 7, scope: !151, inlinedAt: !90)
!178 = !DILocation(line: 109, column: 28, scope: !148, inlinedAt: !90)
!179 = !DILocation(line: 109, column: 3, scope: !148, inlinedAt: !90)
!180 = distinct !{!180, !149, !181, !135}
!181 = !DILocation(line: 115, column: 7, scope: !145, inlinedAt: !90)
!182 = !DILocation(line: 117, column: 8, scope: !183, inlinedAt: !90)
!183 = distinct !DILexicalBlock(scope: !74, file: !11, line: 117, column: 3)
!184 = !DILocation(line: 0, scope: !183, inlinedAt: !90)
!185 = !DILocation(line: 117, column: 17, scope: !186, inlinedAt: !90)
!186 = distinct !DILexicalBlock(scope: !183, file: !11, line: 117, column: 3)
!187 = !DILocation(line: 117, column: 3, scope: !183, inlinedAt: !90)
!188 = !DILocation(line: 118, column: 10, scope: !189, inlinedAt: !90)
!189 = distinct !DILexicalBlock(scope: !186, file: !11, line: 118, column: 5)
!190 = !DILocation(line: 0, scope: !189, inlinedAt: !90)
!191 = !DILocation(line: 118, column: 19, scope: !192, inlinedAt: !90)
!192 = distinct !DILexicalBlock(scope: !189, file: !11, line: 118, column: 5)
!193 = !DILocation(line: 118, column: 5, scope: !189, inlinedAt: !90)
!194 = !DILocation(line: 120, column: 2, scope: !195, inlinedAt: !90)
!195 = distinct !DILexicalBlock(scope: !192, file: !11, line: 119, column: 7)
!196 = !DILocation(line: 120, column: 10, scope: !195, inlinedAt: !90)
!197 = !DILocation(line: 121, column: 7, scope: !198, inlinedAt: !90)
!198 = distinct !DILexicalBlock(scope: !195, file: !11, line: 121, column: 2)
!199 = !DILocation(line: 0, scope: !198, inlinedAt: !90)
!200 = !DILocation(line: 121, column: 16, scope: !201, inlinedAt: !90)
!201 = distinct !DILexicalBlock(scope: !198, file: !11, line: 121, column: 2)
!202 = !DILocation(line: 121, column: 2, scope: !198, inlinedAt: !90)
!203 = !DILocation(line: 122, column: 15, scope: !201, inlinedAt: !90)
!204 = !DILocation(line: 122, column: 25, scope: !201, inlinedAt: !90)
!205 = !DILocation(line: 122, column: 23, scope: !201, inlinedAt: !90)
!206 = !DILocation(line: 122, column: 4, scope: !201, inlinedAt: !90)
!207 = !DILocation(line: 122, column: 12, scope: !201, inlinedAt: !90)
!208 = !DILocation(line: 121, column: 26, scope: !201, inlinedAt: !90)
!209 = !DILocation(line: 121, column: 2, scope: !201, inlinedAt: !90)
!210 = distinct !{!210, !202, !211, !135}
!211 = !DILocation(line: 122, column: 31, scope: !198, inlinedAt: !90)
!212 = !DILocation(line: 118, column: 30, scope: !192, inlinedAt: !90)
!213 = !DILocation(line: 118, column: 5, scope: !192, inlinedAt: !90)
!214 = distinct !{!214, !193, !215, !135}
!215 = !DILocation(line: 123, column: 7, scope: !189, inlinedAt: !90)
!216 = !DILocation(line: 117, column: 28, scope: !186, inlinedAt: !90)
!217 = !DILocation(line: 117, column: 3, scope: !186, inlinedAt: !90)
!218 = distinct !{!218, !187, !219, !135}
!219 = !DILocation(line: 123, column: 7, scope: !183, inlinedAt: !90)
!220 = !DILocation(line: 160, column: 3, scope: !60)
