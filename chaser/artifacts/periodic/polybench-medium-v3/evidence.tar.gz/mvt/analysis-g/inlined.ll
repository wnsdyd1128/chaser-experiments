; ModuleID = 'workload.ll'
source_filename = "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/affine-bounds-20260929/suite/mvt/source/workload.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

%struct._IO_FILE = type { i32, i8*, i8*, i8*, i8*, i8*, i8*, i8*, i8*, i8*, i8*, i8*, %struct._IO_marker*, %struct._IO_FILE*, i32, i32, i64, i16, i8, [1 x i8], i8*, i64, %struct._IO_codecvt*, %struct._IO_wide_data*, %struct._IO_FILE*, i8*, i64, i32, [20 x i8] }
%struct._IO_marker = type opaque
%struct._IO_codecvt = type opaque
%struct._IO_wide_data = type opaque
%struct.__va_list_tag = type { i32, i32, i8*, i8* }

@n = dso_local global i32 400, align 4, !dbg !0
@A = dso_local global [400 x [400 x double]] zeroinitializer, section ".chaser_data.A", align 64, !dbg !30
@x1 = dso_local global [400 x double] zeroinitializer, section ".chaser_data.x1", align 64, !dbg !35
@x2 = dso_local global [400 x double] zeroinitializer, section ".chaser_data.x2", align 64, !dbg !39
@y_1 = dso_local global [400 x double] zeroinitializer, section ".chaser_data.y_1", align 64, !dbg !41
@y_2 = dso_local global [400 x double] zeroinitializer, section ".chaser_data.y_2", align 64, !dbg !43
@.str = private unnamed_addr constant [12 x i8] c"ape.analyze\00", section "llvm.metadata"
@.str.1 = private unnamed_addr constant [121 x i8] c"/workspace/experiments-array-support/chaser/.cache/periodic-polybench/affine-bounds-20260929/suite/mvt/source/workload.c\00", section "llvm.metadata"
@pb_hash = internal global i32 0, align 4, !dbg !27
@workload_jobs = dso_local constant [1 x i32 ()*] [i32 ()* @task_job_polybench], align 8, !dbg !9
@workload_expected = dso_local constant [1 x i32] [i32 2099682718], align 4, !dbg !23
@stderr = external global %struct._IO_FILE*, align 8
@.str.2 = private unnamed_addr constant [23 x i8] c"==BEGIN DUMP_ARRAYS==\0A\00", align 1
@.str.3 = private unnamed_addr constant [15 x i8] c"begin dump: %s\00", align 1
@.str.4 = private unnamed_addr constant [3 x i8] c"x1\00", align 1
@.str.5 = private unnamed_addr constant [2 x i8] c"\0A\00", align 1
@.str.6 = private unnamed_addr constant [8 x i8] c"%0.2lf \00", align 1
@.str.7 = private unnamed_addr constant [17 x i8] c"\0Aend   dump: %s\0A\00", align 1
@.str.8 = private unnamed_addr constant [3 x i8] c"x2\00", align 1
@.str.9 = private unnamed_addr constant [23 x i8] c"==END   DUMP_ARRAYS==\0A\00", align 1
@pb_emit = internal global i32 1, align 4, !dbg !45
@llvm.global.annotations = appending global [1 x { i8*, i8*, i8*, i32, i8* }] [{ i8*, i8*, i8*, i32, i8* } { i8* bitcast (i32 ()* @task_job_polybench to i8*), i8* getelementptr inbounds ([12 x i8], [12 x i8]* @.str, i32 0, i32 0), i8* getelementptr inbounds ([121 x i8], [121 x i8]* @.str.1, i32 0, i32 0), i32 130, i8* null }], section "llvm.metadata"

; Function Attrs: noinline nounwind uwtable
define dso_local void @workload_prepare() #0 !dbg !56 {
  ret void, !dbg !60
}

; Function Attrs: noinline nounwind uwtable
define dso_local void @workload_reset(i32 noundef %0) #0 !dbg !61 {
  call void @llvm.dbg.value(metadata i32 %0, metadata !64, metadata !DIExpression()), !dbg !65
  call void @llvm.memset.p0i8.i64(i8* align 64 bitcast ([400 x [400 x double]]* @A to i8*), i8 0, i64 1280000, i1 false), !dbg !66
  call void @llvm.memset.p0i8.i64(i8* align 64 bitcast ([400 x double]* @x1 to i8*), i8 0, i64 3200, i1 false), !dbg !67
  call void @llvm.memset.p0i8.i64(i8* align 64 bitcast ([400 x double]* @x2 to i8*), i8 0, i64 3200, i1 false), !dbg !68
  call void @llvm.memset.p0i8.i64(i8* align 64 bitcast ([400 x double]* @y_1 to i8*), i8 0, i64 3200, i1 false), !dbg !69
  call void @llvm.memset.p0i8.i64(i8* align 64 bitcast ([400 x double]* @y_2 to i8*), i8 0, i64 3200, i1 false), !dbg !70
  %2 = load i32, i32* @n, align 4, !dbg !71
  call void @init_array(i32 noundef %2, double* noundef getelementptr inbounds ([400 x double], [400 x double]* @x1, i64 0, i64 0), double* noundef getelementptr inbounds ([400 x double], [400 x double]* @x2, i64 0, i64 0), double* noundef getelementptr inbounds ([400 x double], [400 x double]* @y_1, i64 0, i64 0), double* noundef getelementptr inbounds ([400 x double], [400 x double]* @y_2, i64 0, i64 0), [400 x double]* noundef getelementptr inbounds ([400 x [400 x double]], [400 x [400 x double]]* @A, i64 0, i64 0)), !dbg !72
  ret void, !dbg !73
}

; Function Attrs: nofree nosync nounwind readnone speculatable willreturn
declare void @llvm.dbg.declare(metadata, metadata, metadata) #1

; Function Attrs: argmemonly nofree nounwind willreturn writeonly
declare void @llvm.memset.p0i8.i64(i8* nocapture writeonly, i8, i64, i1 immarg) #2

; Function Attrs: noinline nounwind uwtable
define internal void @init_array(i32 noundef %0, double* noundef %1, double* noundef %2, double* noundef %3, double* noundef %4, [400 x double]* noundef %5) #0 !dbg !74 {
  call void @llvm.dbg.value(metadata i32 %0, metadata !79, metadata !DIExpression()), !dbg !80
  call void @llvm.dbg.value(metadata double* %1, metadata !81, metadata !DIExpression()), !dbg !80
  call void @llvm.dbg.value(metadata double* %2, metadata !82, metadata !DIExpression()), !dbg !80
  call void @llvm.dbg.value(metadata double* %3, metadata !83, metadata !DIExpression()), !dbg !80
  call void @llvm.dbg.value(metadata double* %4, metadata !84, metadata !DIExpression()), !dbg !80
  call void @llvm.dbg.value(metadata [400 x double]* %5, metadata !85, metadata !DIExpression()), !dbg !80
  call void @llvm.dbg.value(metadata i32 0, metadata !86, metadata !DIExpression()), !dbg !80
  br label %7, !dbg !87

7:                                                ; preds = %52, %6
  %.01 = phi i32 [ 0, %6 ], [ %53, %52 ], !dbg !89
  call void @llvm.dbg.value(metadata i32 %.01, metadata !86, metadata !DIExpression()), !dbg !80
  %8 = icmp slt i32 %.01, %0, !dbg !90
  br i1 %8, label %9, label %54, !dbg !92

9:                                                ; preds = %7
  %10 = srem i32 %.01, %0, !dbg !93
  %11 = sitofp i32 %10 to double, !dbg !95
  %12 = sitofp i32 %0 to double, !dbg !96
  %13 = fdiv double %11, %12, !dbg !97
  %14 = sext i32 %.01 to i64, !dbg !98
  %15 = getelementptr inbounds double, double* %1, i64 %14, !dbg !98
  store double %13, double* %15, align 8, !dbg !99
  %16 = add nsw i32 %.01, 1, !dbg !100
  %17 = srem i32 %16, %0, !dbg !101
  %18 = sitofp i32 %17 to double, !dbg !102
  %19 = sitofp i32 %0 to double, !dbg !103
  %20 = fdiv double %18, %19, !dbg !104
  %21 = sext i32 %.01 to i64, !dbg !105
  %22 = getelementptr inbounds double, double* %2, i64 %21, !dbg !105
  store double %20, double* %22, align 8, !dbg !106
  %23 = add nsw i32 %.01, 3, !dbg !107
  %24 = srem i32 %23, %0, !dbg !108
  %25 = sitofp i32 %24 to double, !dbg !109
  %26 = sitofp i32 %0 to double, !dbg !110
  %27 = fdiv double %25, %26, !dbg !111
  %28 = sext i32 %.01 to i64, !dbg !112
  %29 = getelementptr inbounds double, double* %3, i64 %28, !dbg !112
  store double %27, double* %29, align 8, !dbg !113
  %30 = add nsw i32 %.01, 4, !dbg !114
  %31 = srem i32 %30, %0, !dbg !115
  %32 = sitofp i32 %31 to double, !dbg !116
  %33 = sitofp i32 %0 to double, !dbg !117
  %34 = fdiv double %32, %33, !dbg !118
  %35 = sext i32 %.01 to i64, !dbg !119
  %36 = getelementptr inbounds double, double* %4, i64 %35, !dbg !119
  store double %34, double* %36, align 8, !dbg !120
  call void @llvm.dbg.value(metadata i32 0, metadata !121, metadata !DIExpression()), !dbg !80
  br label %37, !dbg !122

37:                                               ; preds = %49, %9
  %.0 = phi i32 [ 0, %9 ], [ %50, %49 ], !dbg !124
  call void @llvm.dbg.value(metadata i32 %.0, metadata !121, metadata !DIExpression()), !dbg !80
  %38 = icmp slt i32 %.0, %0, !dbg !125
  br i1 %38, label %39, label %51, !dbg !127

39:                                               ; preds = %37
  %40 = mul nsw i32 %.01, %.0, !dbg !128
  %41 = srem i32 %40, %0, !dbg !129
  %42 = sitofp i32 %41 to double, !dbg !130
  %43 = sitofp i32 %0 to double, !dbg !131
  %44 = fdiv double %42, %43, !dbg !132
  %45 = sext i32 %.01 to i64, !dbg !133
  %46 = getelementptr inbounds [400 x double], [400 x double]* %5, i64 %45, !dbg !133
  %47 = sext i32 %.0 to i64, !dbg !133
  %48 = getelementptr inbounds [400 x double], [400 x double]* %46, i64 0, i64 %47, !dbg !133
  store double %44, double* %48, align 8, !dbg !134
  br label %49, !dbg !133

49:                                               ; preds = %39
  %50 = add nsw i32 %.0, 1, !dbg !135
  call void @llvm.dbg.value(metadata i32 %50, metadata !121, metadata !DIExpression()), !dbg !80
  br label %37, !dbg !136, !llvm.loop !137

51:                                               ; preds = %37
  br label %52, !dbg !140

52:                                               ; preds = %51
  %53 = add nsw i32 %.01, 1, !dbg !141
  call void @llvm.dbg.value(metadata i32 %53, metadata !86, metadata !DIExpression()), !dbg !80
  br label %7, !dbg !142, !llvm.loop !143

54:                                               ; preds = %7
  ret void, !dbg !145
}

; Function Attrs: noinline nounwind uwtable
define dso_local i32 @task_job_polybench() #0 !dbg !146 {
  %1 = load i32, i32* @n, align 4, !dbg !147
  call void @llvm.dbg.value(metadata i32 %1, metadata !148, metadata !DIExpression()), !dbg !150
  call void @llvm.dbg.value(metadata double* getelementptr inbounds ([400 x double], [400 x double]* @x1, i64 0, i64 0), metadata !152, metadata !DIExpression()), !dbg !150
  call void @llvm.dbg.value(metadata double* getelementptr inbounds ([400 x double], [400 x double]* @x2, i64 0, i64 0), metadata !153, metadata !DIExpression()), !dbg !150
  call void @llvm.dbg.value(metadata double* getelementptr inbounds ([400 x double], [400 x double]* @y_1, i64 0, i64 0), metadata !154, metadata !DIExpression()), !dbg !150
  call void @llvm.dbg.value(metadata double* getelementptr inbounds ([400 x double], [400 x double]* @y_2, i64 0, i64 0), metadata !155, metadata !DIExpression()), !dbg !150
  call void @llvm.dbg.value(metadata [400 x double]* getelementptr inbounds ([400 x [400 x double]], [400 x [400 x double]]* @A, i64 0, i64 0), metadata !156, metadata !DIExpression()), !dbg !150
  call void @llvm.dbg.value(metadata i32 0, metadata !157, metadata !DIExpression()), !dbg !150
  br label %2, !dbg !158

2:                                                ; preds = %24, %0
  %.01 = phi i32 [ 0, %0 ], [ %25, %24 ], !dbg !160
  call void @llvm.dbg.value(metadata i32 %.01, metadata !157, metadata !DIExpression()), !dbg !150
  %3 = icmp slt i32 %.01, 400, !dbg !161
  br i1 %3, label %4, label %26, !dbg !163

4:                                                ; preds = %2
  call void @llvm.dbg.value(metadata i32 0, metadata !164, metadata !DIExpression()), !dbg !150
  br label %5, !dbg !165

5:                                                ; preds = %7, %4
  %.0 = phi i32 [ 0, %4 ], [ %23, %7 ], !dbg !167
  call void @llvm.dbg.value(metadata i32 %.0, metadata !164, metadata !DIExpression()), !dbg !150
  %6 = icmp slt i32 %.0, 400, !dbg !168
  br i1 %6, label %7, label %24, !dbg !170

7:                                                ; preds = %5
  %8 = sext i32 %.01 to i64, !dbg !171
  %9 = getelementptr inbounds double, double* getelementptr inbounds ([400 x double], [400 x double]* @x1, i64 0, i64 0), i64 %8, !dbg !171
  %10 = load double, double* %9, align 8, !dbg !171
  %11 = sext i32 %.01 to i64, !dbg !172
  %12 = getelementptr inbounds [400 x double], [400 x double]* getelementptr inbounds ([400 x [400 x double]], [400 x [400 x double]]* @A, i64 0, i64 0), i64 %11, !dbg !172
  %13 = sext i32 %.0 to i64, !dbg !172
  %14 = getelementptr inbounds [400 x double], [400 x double]* %12, i64 0, i64 %13, !dbg !172
  %15 = load double, double* %14, align 8, !dbg !172
  %16 = sext i32 %.0 to i64, !dbg !173
  %17 = getelementptr inbounds double, double* getelementptr inbounds ([400 x double], [400 x double]* @y_1, i64 0, i64 0), i64 %16, !dbg !173
  %18 = load double, double* %17, align 8, !dbg !173
  %19 = fmul double %15, %18, !dbg !174
  %20 = fadd double %10, %19, !dbg !175
  %21 = sext i32 %.01 to i64, !dbg !176
  %22 = getelementptr inbounds double, double* getelementptr inbounds ([400 x double], [400 x double]* @x1, i64 0, i64 0), i64 %21, !dbg !176
  store double %20, double* %22, align 8, !dbg !177
  %23 = add nsw i32 %.0, 1, !dbg !178
  call void @llvm.dbg.value(metadata i32 %23, metadata !164, metadata !DIExpression()), !dbg !150
  br label %5, !dbg !179, !llvm.loop !180

24:                                               ; preds = %5
  %25 = add nsw i32 %.01, 1, !dbg !182
  call void @llvm.dbg.value(metadata i32 %25, metadata !157, metadata !DIExpression()), !dbg !150
  br label %2, !dbg !183, !llvm.loop !184

26:                                               ; preds = %2
  call void @llvm.dbg.value(metadata i32 0, metadata !157, metadata !DIExpression()), !dbg !150
  br label %27, !dbg !186

27:                                               ; preds = %49, %26
  %.12 = phi i32 [ 0, %26 ], [ %50, %49 ], !dbg !188
  call void @llvm.dbg.value(metadata i32 %.12, metadata !157, metadata !DIExpression()), !dbg !150
  %28 = icmp slt i32 %.12, 400, !dbg !189
  br i1 %28, label %29, label %51, !dbg !191

29:                                               ; preds = %27
  call void @llvm.dbg.value(metadata i32 0, metadata !164, metadata !DIExpression()), !dbg !150
  br label %30, !dbg !192

30:                                               ; preds = %32, %29
  %.1 = phi i32 [ 0, %29 ], [ %48, %32 ], !dbg !194
  call void @llvm.dbg.value(metadata i32 %.1, metadata !164, metadata !DIExpression()), !dbg !150
  %31 = icmp slt i32 %.1, 400, !dbg !195
  br i1 %31, label %32, label %49, !dbg !197

32:                                               ; preds = %30
  %33 = sext i32 %.12 to i64, !dbg !198
  %34 = getelementptr inbounds double, double* getelementptr inbounds ([400 x double], [400 x double]* @x2, i64 0, i64 0), i64 %33, !dbg !198
  %35 = load double, double* %34, align 8, !dbg !198
  %36 = sext i32 %.1 to i64, !dbg !199
  %37 = getelementptr inbounds [400 x double], [400 x double]* getelementptr inbounds ([400 x [400 x double]], [400 x [400 x double]]* @A, i64 0, i64 0), i64 %36, !dbg !199
  %38 = sext i32 %.12 to i64, !dbg !199
  %39 = getelementptr inbounds [400 x double], [400 x double]* %37, i64 0, i64 %38, !dbg !199
  %40 = load double, double* %39, align 8, !dbg !199
  %41 = sext i32 %.1 to i64, !dbg !200
  %42 = getelementptr inbounds double, double* getelementptr inbounds ([400 x double], [400 x double]* @y_2, i64 0, i64 0), i64 %41, !dbg !200
  %43 = load double, double* %42, align 8, !dbg !200
  %44 = fmul double %40, %43, !dbg !201
  %45 = fadd double %35, %44, !dbg !202
  %46 = sext i32 %.12 to i64, !dbg !203
  %47 = getelementptr inbounds double, double* getelementptr inbounds ([400 x double], [400 x double]* @x2, i64 0, i64 0), i64 %46, !dbg !203
  store double %45, double* %47, align 8, !dbg !204
  %48 = add nsw i32 %.1, 1, !dbg !205
  call void @llvm.dbg.value(metadata i32 %48, metadata !164, metadata !DIExpression()), !dbg !150
  br label %30, !dbg !206, !llvm.loop !207

49:                                               ; preds = %30
  %50 = add nsw i32 %.12, 1, !dbg !209
  call void @llvm.dbg.value(metadata i32 %50, metadata !157, metadata !DIExpression()), !dbg !150
  br label %27, !dbg !210, !llvm.loop !211

51:                                               ; preds = %27
  ret i32 0, !dbg !213
}

; Function Attrs: noinline nounwind uwtable
define dso_local i32 @workload_checksum(i32 noundef %0) #0 !dbg !214 {
  call void @llvm.dbg.value(metadata i32 %0, metadata !217, metadata !DIExpression()), !dbg !218
  store i32 -2128831035, i32* @pb_hash, align 4, !dbg !219
  %2 = load i32, i32* @n, align 4, !dbg !220
  call void @print_array(i32 noundef %2, double* noundef getelementptr inbounds ([400 x double], [400 x double]* @x1, i64 0, i64 0), double* noundef getelementptr inbounds ([400 x double], [400 x double]* @x2, i64 0, i64 0)), !dbg !221
  %3 = load i32, i32* @pb_hash, align 4, !dbg !222
  ret i32 %3, !dbg !223
}

; Function Attrs: noinline nounwind uwtable
define internal void @print_array(i32 noundef %0, double* noundef %1, double* noundef %2) #0 !dbg !224 {
  call void @llvm.dbg.value(metadata i32 %0, metadata !227, metadata !DIExpression()), !dbg !228
  call void @llvm.dbg.value(metadata double* %1, metadata !229, metadata !DIExpression()), !dbg !228
  call void @llvm.dbg.value(metadata double* %2, metadata !230, metadata !DIExpression()), !dbg !228
  %4 = load %struct._IO_FILE*, %struct._IO_FILE** @stderr, align 8, !dbg !231
  %5 = call i32 (%struct._IO_FILE*, i8*, ...) @pb_fprintf(%struct._IO_FILE* noundef %4, i8* noundef getelementptr inbounds ([23 x i8], [23 x i8]* @.str.2, i64 0, i64 0)), !dbg !231
  %6 = load %struct._IO_FILE*, %struct._IO_FILE** @stderr, align 8, !dbg !232
  %7 = call i32 (%struct._IO_FILE*, i8*, ...) @pb_fprintf(%struct._IO_FILE* noundef %6, i8* noundef getelementptr inbounds ([15 x i8], [15 x i8]* @.str.3, i64 0, i64 0), i8* noundef getelementptr inbounds ([3 x i8], [3 x i8]* @.str.4, i64 0, i64 0)), !dbg !232
  call void @llvm.dbg.value(metadata i32 0, metadata !233, metadata !DIExpression()), !dbg !228
  br label %8, !dbg !234

8:                                                ; preds = %22, %3
  %.0 = phi i32 [ 0, %3 ], [ %23, %22 ], !dbg !236
  call void @llvm.dbg.value(metadata i32 %.0, metadata !233, metadata !DIExpression()), !dbg !228
  %9 = icmp slt i32 %.0, %0, !dbg !237
  br i1 %9, label %10, label %24, !dbg !239

10:                                               ; preds = %8
  %11 = srem i32 %.0, 20, !dbg !240
  %12 = icmp eq i32 %11, 0, !dbg !243
  br i1 %12, label %13, label %16, !dbg !244

13:                                               ; preds = %10
  %14 = load %struct._IO_FILE*, %struct._IO_FILE** @stderr, align 8, !dbg !245
  %15 = call i32 (%struct._IO_FILE*, i8*, ...) @pb_fprintf(%struct._IO_FILE* noundef %14, i8* noundef getelementptr inbounds ([2 x i8], [2 x i8]* @.str.5, i64 0, i64 0)), !dbg !246
  br label %16, !dbg !246

16:                                               ; preds = %13, %10
  %17 = load %struct._IO_FILE*, %struct._IO_FILE** @stderr, align 8, !dbg !247
  %18 = sext i32 %.0 to i64, !dbg !248
  %19 = getelementptr inbounds double, double* %1, i64 %18, !dbg !248
  %20 = load double, double* %19, align 8, !dbg !248
  %21 = call i32 (%struct._IO_FILE*, i8*, ...) @pb_fprintf(%struct._IO_FILE* noundef %17, i8* noundef getelementptr inbounds ([8 x i8], [8 x i8]* @.str.6, i64 0, i64 0), double noundef %20), !dbg !249
  br label %22, !dbg !250

22:                                               ; preds = %16
  %23 = add nsw i32 %.0, 1, !dbg !251
  call void @llvm.dbg.value(metadata i32 %23, metadata !233, metadata !DIExpression()), !dbg !228
  br label %8, !dbg !252, !llvm.loop !253

24:                                               ; preds = %8
  %25 = load %struct._IO_FILE*, %struct._IO_FILE** @stderr, align 8, !dbg !255
  %26 = call i32 (%struct._IO_FILE*, i8*, ...) @pb_fprintf(%struct._IO_FILE* noundef %25, i8* noundef getelementptr inbounds ([17 x i8], [17 x i8]* @.str.7, i64 0, i64 0), i8* noundef getelementptr inbounds ([3 x i8], [3 x i8]* @.str.4, i64 0, i64 0)), !dbg !255
  %27 = load %struct._IO_FILE*, %struct._IO_FILE** @stderr, align 8, !dbg !256
  %28 = call i32 (%struct._IO_FILE*, i8*, ...) @pb_fprintf(%struct._IO_FILE* noundef %27, i8* noundef getelementptr inbounds ([15 x i8], [15 x i8]* @.str.3, i64 0, i64 0), i8* noundef getelementptr inbounds ([3 x i8], [3 x i8]* @.str.8, i64 0, i64 0)), !dbg !256
  call void @llvm.dbg.value(metadata i32 0, metadata !233, metadata !DIExpression()), !dbg !228
  br label %29, !dbg !257

29:                                               ; preds = %43, %24
  %.1 = phi i32 [ 0, %24 ], [ %44, %43 ], !dbg !259
  call void @llvm.dbg.value(metadata i32 %.1, metadata !233, metadata !DIExpression()), !dbg !228
  %30 = icmp slt i32 %.1, %0, !dbg !260
  br i1 %30, label %31, label %45, !dbg !262

31:                                               ; preds = %29
  %32 = srem i32 %.1, 20, !dbg !263
  %33 = icmp eq i32 %32, 0, !dbg !266
  br i1 %33, label %34, label %37, !dbg !267

34:                                               ; preds = %31
  %35 = load %struct._IO_FILE*, %struct._IO_FILE** @stderr, align 8, !dbg !268
  %36 = call i32 (%struct._IO_FILE*, i8*, ...) @pb_fprintf(%struct._IO_FILE* noundef %35, i8* noundef getelementptr inbounds ([2 x i8], [2 x i8]* @.str.5, i64 0, i64 0)), !dbg !269
  br label %37, !dbg !269

37:                                               ; preds = %34, %31
  %38 = load %struct._IO_FILE*, %struct._IO_FILE** @stderr, align 8, !dbg !270
  %39 = sext i32 %.1 to i64, !dbg !271
  %40 = getelementptr inbounds double, double* %2, i64 %39, !dbg !271
  %41 = load double, double* %40, align 8, !dbg !271
  %42 = call i32 (%struct._IO_FILE*, i8*, ...) @pb_fprintf(%struct._IO_FILE* noundef %38, i8* noundef getelementptr inbounds ([8 x i8], [8 x i8]* @.str.6, i64 0, i64 0), double noundef %41), !dbg !272
  br label %43, !dbg !273

43:                                               ; preds = %37
  %44 = add nsw i32 %.1, 1, !dbg !274
  call void @llvm.dbg.value(metadata i32 %44, metadata !233, metadata !DIExpression()), !dbg !228
  br label %29, !dbg !275, !llvm.loop !276

45:                                               ; preds = %29
  %46 = load %struct._IO_FILE*, %struct._IO_FILE** @stderr, align 8, !dbg !278
  %47 = call i32 (%struct._IO_FILE*, i8*, ...) @pb_fprintf(%struct._IO_FILE* noundef %46, i8* noundef getelementptr inbounds ([17 x i8], [17 x i8]* @.str.7, i64 0, i64 0), i8* noundef getelementptr inbounds ([3 x i8], [3 x i8]* @.str.8, i64 0, i64 0)), !dbg !278
  %48 = load %struct._IO_FILE*, %struct._IO_FILE** @stderr, align 8, !dbg !279
  %49 = call i32 (%struct._IO_FILE*, i8*, ...) @pb_fprintf(%struct._IO_FILE* noundef %48, i8* noundef getelementptr inbounds ([23 x i8], [23 x i8]* @.str.9, i64 0, i64 0)), !dbg !279
  ret void, !dbg !280
}

; Function Attrs: noinline nounwind uwtable
define internal i32 @pb_fprintf(%struct._IO_FILE* noundef %0, i8* noundef %1, ...) #0 !dbg !281 {
  %3 = alloca [768 x i8], align 16
  %4 = alloca [1 x %struct.__va_list_tag], align 16
  call void @llvm.dbg.value(metadata %struct._IO_FILE* %0, metadata !345, metadata !DIExpression()), !dbg !346
  call void @llvm.dbg.value(metadata i8* %1, metadata !347, metadata !DIExpression()), !dbg !346
  call void @llvm.dbg.declare(metadata [768 x i8]* %3, metadata !348, metadata !DIExpression()), !dbg !352
  call void @llvm.dbg.declare(metadata [1 x %struct.__va_list_tag]* %4, metadata !353, metadata !DIExpression()), !dbg !367
  %5 = getelementptr inbounds [1 x %struct.__va_list_tag], [1 x %struct.__va_list_tag]* %4, i64 0, i64 0, !dbg !368
  %6 = bitcast %struct.__va_list_tag* %5 to i8*, !dbg !368
  call void @llvm.va_start(i8* %6), !dbg !368
  %7 = getelementptr inbounds [768 x i8], [768 x i8]* %3, i64 0, i64 0, !dbg !369
  %8 = getelementptr inbounds [1 x %struct.__va_list_tag], [1 x %struct.__va_list_tag]* %4, i64 0, i64 0, !dbg !370
  %9 = call i32 @vsnprintf(i8* noundef %7, i64 noundef 768, i8* noundef %1, %struct.__va_list_tag* noundef %8) #6, !dbg !371
  call void @llvm.dbg.value(metadata i32 %9, metadata !372, metadata !DIExpression()), !dbg !346
  %10 = getelementptr inbounds [1 x %struct.__va_list_tag], [1 x %struct.__va_list_tag]* %4, i64 0, i64 0, !dbg !373
  %11 = bitcast %struct.__va_list_tag* %10 to i8*, !dbg !373
  call void @llvm.va_end(i8* %11), !dbg !373
  %12 = icmp slt i32 %9, 0, !dbg !374
  br i1 %12, label %16, label %13, !dbg !376

13:                                               ; preds = %2
  %14 = zext i32 %9 to i64, !dbg !377
  %15 = icmp uge i64 %14, 768, !dbg !378
  br i1 %15, label %16, label %17, !dbg !379

16:                                               ; preds = %13, %2
  call void @abort() #7, !dbg !380
  unreachable, !dbg !380

17:                                               ; preds = %13
  call void @llvm.dbg.value(metadata i32 0, metadata !381, metadata !DIExpression()), !dbg !383
  br label %18, !dbg !384

18:                                               ; preds = %29, %17
  %.0 = phi i32 [ 0, %17 ], [ %30, %29 ], !dbg !383
  call void @llvm.dbg.value(metadata i32 %.0, metadata !381, metadata !DIExpression()), !dbg !383
  %19 = icmp slt i32 %.0, %9, !dbg !385
  br i1 %19, label %20, label %31, !dbg !387

20:                                               ; preds = %18
  %21 = sext i32 %.0 to i64, !dbg !388
  %22 = getelementptr inbounds [768 x i8], [768 x i8]* %3, i64 0, i64 %21, !dbg !388
  %23 = load i8, i8* %22, align 1, !dbg !388
  %24 = zext i8 %23 to i32, !dbg !390
  %25 = load i32, i32* @pb_hash, align 4, !dbg !391
  %26 = xor i32 %25, %24, !dbg !391
  store i32 %26, i32* @pb_hash, align 4, !dbg !391
  %27 = load i32, i32* @pb_hash, align 4, !dbg !392
  %28 = mul i32 %27, 16777619, !dbg !392
  store i32 %28, i32* @pb_hash, align 4, !dbg !392
  br label %29, !dbg !393

29:                                               ; preds = %20
  %30 = add nsw i32 %.0, 1, !dbg !394
  call void @llvm.dbg.value(metadata i32 %30, metadata !381, metadata !DIExpression()), !dbg !383
  br label %18, !dbg !395, !llvm.loop !396

31:                                               ; preds = %18
  %32 = load i32, i32* @pb_emit, align 4, !dbg !398
  ret i32 %9, !dbg !399
}

; Function Attrs: nofree nosync nounwind willreturn
declare void @llvm.va_start(i8*) #3

; Function Attrs: nounwind
declare i32 @vsnprintf(i8* noundef, i64 noundef, i8* noundef, %struct.__va_list_tag* noundef) #4

; Function Attrs: nofree nosync nounwind willreturn
declare void @llvm.va_end(i8*) #3

; Function Attrs: noreturn nounwind
declare void @abort() #5

; Function Attrs: nofree nosync nounwind readnone speculatable willreturn
declare void @llvm.dbg.value(metadata, metadata, metadata) #1

attributes #0 = { noinline nounwind uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { nofree nosync nounwind readnone speculatable willreturn }
attributes #2 = { argmemonly nofree nounwind willreturn writeonly }
attributes #3 = { nofree nosync nounwind willreturn }
attributes #4 = { nounwind "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #5 = { noreturn nounwind "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #6 = { nounwind }
attributes #7 = { noreturn nounwind }

!llvm.dbg.cu = !{!2}
!llvm.module.flags = !{!48, !49, !50, !51, !52, !53, !54}
!llvm.ident = !{!55}

!0 = !DIGlobalVariableExpression(var: !1, expr: !DIExpression())
!1 = distinct !DIGlobalVariable(name: "n", scope: !2, file: !11, line: 114, type: !47, isLocal: false, isDefinition: true)
!2 = distinct !DICompileUnit(language: DW_LANG_C99, file: !3, producer: "Ubuntu clang version 14.0.0-1ubuntu1.1", isOptimized: false, runtimeVersion: 0, emissionKind: FullDebug, retainedTypes: !4, globals: !8, splitDebugInlining: false, nameTableKind: None)
!3 = !DIFile(filename: "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/affine-bounds-20260929/suite/mvt/source/workload.c", directory: "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/affine-bounds-20260929/suite/mvt/analysis-g", checksumkind: CSK_MD5, checksum: "f71e460355e980f9bb96215091b80313")
!4 = !{!5, !6, !7}
!5 = !DIBasicType(name: "double", size: 64, encoding: DW_ATE_float)
!6 = !DIBasicType(name: "unsigned int", size: 32, encoding: DW_ATE_unsigned)
!7 = !DIBasicType(name: "unsigned char", size: 8, encoding: DW_ATE_unsigned_char)
!8 = !{!0, !9, !23, !27, !30, !35, !39, !41, !43, !45}
!9 = !DIGlobalVariableExpression(var: !10, expr: !DIExpression())
!10 = distinct !DIGlobalVariable(name: "workload_jobs", scope: !2, file: !11, line: 145, type: !12, isLocal: false, isDefinition: true)
!11 = !DIFile(filename: "source/workload.c", directory: "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/affine-bounds-20260929/suite/mvt", checksumkind: CSK_MD5, checksum: "f71e460355e980f9bb96215091b80313")
!12 = !DICompositeType(tag: DW_TAG_array_type, baseType: !13, size: 64, elements: !21)
!13 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !14)
!14 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !15, size: 64)
!15 = !DISubroutineType(types: !16)
!16 = !{!17}
!17 = !DIDerivedType(tag: DW_TAG_typedef, name: "uint32_t", file: !18, line: 26, baseType: !19)
!18 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/stdint-uintn.h", directory: "", checksumkind: CSK_MD5, checksum: "2bf2ae53c58c01b1a1b9383b5195125c")
!19 = !DIDerivedType(tag: DW_TAG_typedef, name: "__uint32_t", file: !20, line: 42, baseType: !6)
!20 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/types.h", directory: "", checksumkind: CSK_MD5, checksum: "d108b5f93a74c50510d7d9bc0ab36df9")
!21 = !{!22}
!22 = !DISubrange(count: 1)
!23 = !DIGlobalVariableExpression(var: !24, expr: !DIExpression())
!24 = distinct !DIGlobalVariable(name: "workload_expected", scope: !2, file: !11, line: 149, type: !25, isLocal: false, isDefinition: true)
!25 = !DICompositeType(tag: DW_TAG_array_type, baseType: !26, size: 32, elements: !21)
!26 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !17)
!27 = !DIGlobalVariableExpression(var: !28, expr: !DIExpression())
!28 = distinct !DIGlobalVariable(name: "pb_hash", scope: !2, file: !29, line: 9, type: !17, isLocal: true, isDefinition: true)
!29 = !DIFile(filename: "source/adapter.h", directory: "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/affine-bounds-20260929/suite/mvt", checksumkind: CSK_MD5, checksum: "26a6068928b2092758f244a9d00163d7")
!30 = !DIGlobalVariableExpression(var: !31, expr: !DIExpression())
!31 = distinct !DIGlobalVariable(name: "A", scope: !2, file: !11, line: 34, type: !32, isLocal: false, isDefinition: true, align: 512)
!32 = !DICompositeType(tag: DW_TAG_array_type, baseType: !5, size: 10240000, elements: !33)
!33 = !{!34, !34}
!34 = !DISubrange(count: 400)
!35 = !DIGlobalVariableExpression(var: !36, expr: !DIExpression())
!36 = distinct !DIGlobalVariable(name: "x1", scope: !2, file: !11, line: 35, type: !37, isLocal: false, isDefinition: true, align: 512)
!37 = !DICompositeType(tag: DW_TAG_array_type, baseType: !5, size: 25600, elements: !38)
!38 = !{!34}
!39 = !DIGlobalVariableExpression(var: !40, expr: !DIExpression())
!40 = distinct !DIGlobalVariable(name: "x2", scope: !2, file: !11, line: 36, type: !37, isLocal: false, isDefinition: true, align: 512)
!41 = !DIGlobalVariableExpression(var: !42, expr: !DIExpression())
!42 = distinct !DIGlobalVariable(name: "y_1", scope: !2, file: !11, line: 37, type: !37, isLocal: false, isDefinition: true, align: 512)
!43 = !DIGlobalVariableExpression(var: !44, expr: !DIExpression())
!44 = distinct !DIGlobalVariable(name: "y_2", scope: !2, file: !11, line: 38, type: !37, isLocal: false, isDefinition: true, align: 512)
!45 = !DIGlobalVariableExpression(var: !46, expr: !DIExpression())
!46 = distinct !DIGlobalVariable(name: "pb_emit", scope: !2, file: !29, line: 10, type: !47, isLocal: true, isDefinition: true)
!47 = !DIBasicType(name: "int", size: 32, encoding: DW_ATE_signed)
!48 = !{i32 7, !"Dwarf Version", i32 5}
!49 = !{i32 2, !"Debug Info Version", i32 3}
!50 = !{i32 1, !"wchar_size", i32 4}
!51 = !{i32 7, !"PIC Level", i32 2}
!52 = !{i32 7, !"PIE Level", i32 2}
!53 = !{i32 7, !"uwtable", i32 1}
!54 = !{i32 7, !"frame-pointer", i32 2}
!55 = !{!"Ubuntu clang version 14.0.0-1ubuntu1.1"}
!56 = distinct !DISubprogram(name: "workload_prepare", scope: !11, file: !11, line: 115, type: !57, scopeLine: 115, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !2, retainedNodes: !59)
!57 = !DISubroutineType(types: !58)
!58 = !{null}
!59 = !{}
!60 = !DILocation(line: 115, column: 30, scope: !56)
!61 = distinct !DISubprogram(name: "workload_reset", scope: !11, file: !11, line: 116, type: !62, scopeLine: 116, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !2, retainedNodes: !59)
!62 = !DISubroutineType(types: !63)
!63 = !{null, !6}
!64 = !DILocalVariable(name: "task", arg: 1, scope: !61, file: !11, line: 116, type: !6)
!65 = !DILocation(line: 0, scope: !61)
!66 = !DILocation(line: 118, column: 3, scope: !61)
!67 = !DILocation(line: 119, column: 3, scope: !61)
!68 = !DILocation(line: 120, column: 3, scope: !61)
!69 = !DILocation(line: 121, column: 3, scope: !61)
!70 = !DILocation(line: 122, column: 3, scope: !61)
!71 = !DILocation(line: 123, column: 15, scope: !61)
!72 = !DILocation(line: 123, column: 3, scope: !61)
!73 = !DILocation(line: 129, column: 1, scope: !61)
!74 = distinct !DISubprogram(name: "init_array", scope: !11, file: !11, line: 40, type: !75, scopeLine: 46, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition, unit: !2, retainedNodes: !59)
!75 = !DISubroutineType(types: !76)
!76 = !{null, !47, !77, !77, !77, !77, !78}
!77 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !5, size: 64)
!78 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !37, size: 64)
!79 = !DILocalVariable(name: "n", arg: 1, scope: !74, file: !11, line: 40, type: !47)
!80 = !DILocation(line: 0, scope: !74)
!81 = !DILocalVariable(name: "x1", arg: 2, scope: !74, file: !11, line: 41, type: !77)
!82 = !DILocalVariable(name: "x2", arg: 3, scope: !74, file: !11, line: 42, type: !77)
!83 = !DILocalVariable(name: "y_1", arg: 4, scope: !74, file: !11, line: 43, type: !77)
!84 = !DILocalVariable(name: "y_2", arg: 5, scope: !74, file: !11, line: 44, type: !77)
!85 = !DILocalVariable(name: "A", arg: 6, scope: !74, file: !11, line: 45, type: !78)
!86 = !DILocalVariable(name: "i", scope: !74, file: !11, line: 47, type: !47)
!87 = !DILocation(line: 49, column: 8, scope: !88)
!88 = distinct !DILexicalBlock(scope: !74, file: !11, line: 49, column: 3)
!89 = !DILocation(line: 0, scope: !88)
!90 = !DILocation(line: 49, column: 17, scope: !91)
!91 = distinct !DILexicalBlock(scope: !88, file: !11, line: 49, column: 3)
!92 = !DILocation(line: 49, column: 3, scope: !88)
!93 = !DILocation(line: 51, column: 30, scope: !94)
!94 = distinct !DILexicalBlock(scope: !91, file: !11, line: 50, column: 5)
!95 = !DILocation(line: 51, column: 15, scope: !94)
!96 = !DILocation(line: 51, column: 37, scope: !94)
!97 = !DILocation(line: 51, column: 35, scope: !94)
!98 = !DILocation(line: 51, column: 7, scope: !94)
!99 = !DILocation(line: 51, column: 13, scope: !94)
!100 = !DILocation(line: 52, column: 31, scope: !94)
!101 = !DILocation(line: 52, column: 36, scope: !94)
!102 = !DILocation(line: 52, column: 15, scope: !94)
!103 = !DILocation(line: 52, column: 43, scope: !94)
!104 = !DILocation(line: 52, column: 41, scope: !94)
!105 = !DILocation(line: 52, column: 7, scope: !94)
!106 = !DILocation(line: 52, column: 13, scope: !94)
!107 = !DILocation(line: 53, column: 32, scope: !94)
!108 = !DILocation(line: 53, column: 37, scope: !94)
!109 = !DILocation(line: 53, column: 16, scope: !94)
!110 = !DILocation(line: 53, column: 44, scope: !94)
!111 = !DILocation(line: 53, column: 42, scope: !94)
!112 = !DILocation(line: 53, column: 7, scope: !94)
!113 = !DILocation(line: 53, column: 14, scope: !94)
!114 = !DILocation(line: 54, column: 32, scope: !94)
!115 = !DILocation(line: 54, column: 37, scope: !94)
!116 = !DILocation(line: 54, column: 16, scope: !94)
!117 = !DILocation(line: 54, column: 44, scope: !94)
!118 = !DILocation(line: 54, column: 42, scope: !94)
!119 = !DILocation(line: 54, column: 7, scope: !94)
!120 = !DILocation(line: 54, column: 14, scope: !94)
!121 = !DILocalVariable(name: "j", scope: !74, file: !11, line: 47, type: !47)
!122 = !DILocation(line: 55, column: 12, scope: !123)
!123 = distinct !DILexicalBlock(scope: !94, file: !11, line: 55, column: 7)
!124 = !DILocation(line: 0, scope: !123)
!125 = !DILocation(line: 55, column: 21, scope: !126)
!126 = distinct !DILexicalBlock(scope: !123, file: !11, line: 55, column: 7)
!127 = !DILocation(line: 55, column: 7, scope: !123)
!128 = !DILocation(line: 56, column: 26, scope: !126)
!129 = !DILocation(line: 56, column: 29, scope: !126)
!130 = !DILocation(line: 56, column: 12, scope: !126)
!131 = !DILocation(line: 56, column: 36, scope: !126)
!132 = !DILocation(line: 56, column: 34, scope: !126)
!133 = !DILocation(line: 56, column: 2, scope: !126)
!134 = !DILocation(line: 56, column: 10, scope: !126)
!135 = !DILocation(line: 55, column: 27, scope: !126)
!136 = !DILocation(line: 55, column: 7, scope: !126)
!137 = distinct !{!137, !127, !138, !139}
!138 = !DILocation(line: 56, column: 36, scope: !123)
!139 = !{!"llvm.loop.mustprogress"}
!140 = !DILocation(line: 57, column: 5, scope: !94)
!141 = !DILocation(line: 49, column: 23, scope: !91)
!142 = !DILocation(line: 49, column: 3, scope: !91)
!143 = distinct !{!143, !92, !144, !139}
!144 = !DILocation(line: 57, column: 5, scope: !88)
!145 = !DILocation(line: 58, column: 1, scope: !74)
!146 = distinct !DISubprogram(name: "task_job_polybench", scope: !11, file: !11, line: 130, type: !15, scopeLine: 130, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !2, retainedNodes: !59)
!147 = !DILocation(line: 131, column: 15, scope: !146)
!148 = !DILocalVariable(name: "n", arg: 1, scope: !149, file: !11, line: 92, type: !47)
!149 = distinct !DISubprogram(name: "kernel_mvt", scope: !11, file: !11, line: 92, type: !75, scopeLine: 98, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition, unit: !2, retainedNodes: !59)
!150 = !DILocation(line: 0, scope: !149, inlinedAt: !151)
!151 = distinct !DILocation(line: 131, column: 3, scope: !146)
!152 = !DILocalVariable(name: "x1", arg: 2, scope: !149, file: !11, line: 93, type: !77)
!153 = !DILocalVariable(name: "x2", arg: 3, scope: !149, file: !11, line: 94, type: !77)
!154 = !DILocalVariable(name: "y_1", arg: 4, scope: !149, file: !11, line: 95, type: !77)
!155 = !DILocalVariable(name: "y_2", arg: 5, scope: !149, file: !11, line: 96, type: !77)
!156 = !DILocalVariable(name: "A", arg: 6, scope: !149, file: !11, line: 97, type: !78)
!157 = !DILocalVariable(name: "i", scope: !149, file: !11, line: 99, type: !47)
!158 = !DILocation(line: 102, column: 8, scope: !159, inlinedAt: !151)
!159 = distinct !DILexicalBlock(scope: !149, file: !11, line: 102, column: 3)
!160 = !DILocation(line: 0, scope: !159, inlinedAt: !151)
!161 = !DILocation(line: 102, column: 17, scope: !162, inlinedAt: !151)
!162 = distinct !DILexicalBlock(scope: !159, file: !11, line: 102, column: 3)
!163 = !DILocation(line: 102, column: 3, scope: !159, inlinedAt: !151)
!164 = !DILocalVariable(name: "j", scope: !149, file: !11, line: 99, type: !47)
!165 = !DILocation(line: 103, column: 10, scope: !166, inlinedAt: !151)
!166 = distinct !DILexicalBlock(scope: !162, file: !11, line: 103, column: 5)
!167 = !DILocation(line: 0, scope: !166, inlinedAt: !151)
!168 = !DILocation(line: 103, column: 19, scope: !169, inlinedAt: !151)
!169 = distinct !DILexicalBlock(scope: !166, file: !11, line: 103, column: 5)
!170 = !DILocation(line: 103, column: 5, scope: !166, inlinedAt: !151)
!171 = !DILocation(line: 104, column: 15, scope: !169, inlinedAt: !151)
!172 = !DILocation(line: 104, column: 23, scope: !169, inlinedAt: !151)
!173 = !DILocation(line: 104, column: 33, scope: !169, inlinedAt: !151)
!174 = !DILocation(line: 104, column: 31, scope: !169, inlinedAt: !151)
!175 = !DILocation(line: 104, column: 21, scope: !169, inlinedAt: !151)
!176 = !DILocation(line: 104, column: 7, scope: !169, inlinedAt: !151)
!177 = !DILocation(line: 104, column: 13, scope: !169, inlinedAt: !151)
!178 = !DILocation(line: 103, column: 29, scope: !169, inlinedAt: !151)
!179 = !DILocation(line: 103, column: 5, scope: !169, inlinedAt: !151)
!180 = distinct !{!180, !170, !181, !139}
!181 = !DILocation(line: 104, column: 38, scope: !166, inlinedAt: !151)
!182 = !DILocation(line: 102, column: 27, scope: !162, inlinedAt: !151)
!183 = !DILocation(line: 102, column: 3, scope: !162, inlinedAt: !151)
!184 = distinct !{!184, !163, !185, !139}
!185 = !DILocation(line: 104, column: 38, scope: !159, inlinedAt: !151)
!186 = !DILocation(line: 105, column: 8, scope: !187, inlinedAt: !151)
!187 = distinct !DILexicalBlock(scope: !149, file: !11, line: 105, column: 3)
!188 = !DILocation(line: 0, scope: !187, inlinedAt: !151)
!189 = !DILocation(line: 105, column: 17, scope: !190, inlinedAt: !151)
!190 = distinct !DILexicalBlock(scope: !187, file: !11, line: 105, column: 3)
!191 = !DILocation(line: 105, column: 3, scope: !187, inlinedAt: !151)
!192 = !DILocation(line: 106, column: 10, scope: !193, inlinedAt: !151)
!193 = distinct !DILexicalBlock(scope: !190, file: !11, line: 106, column: 5)
!194 = !DILocation(line: 0, scope: !193, inlinedAt: !151)
!195 = !DILocation(line: 106, column: 19, scope: !196, inlinedAt: !151)
!196 = distinct !DILexicalBlock(scope: !193, file: !11, line: 106, column: 5)
!197 = !DILocation(line: 106, column: 5, scope: !193, inlinedAt: !151)
!198 = !DILocation(line: 107, column: 15, scope: !196, inlinedAt: !151)
!199 = !DILocation(line: 107, column: 23, scope: !196, inlinedAt: !151)
!200 = !DILocation(line: 107, column: 33, scope: !196, inlinedAt: !151)
!201 = !DILocation(line: 107, column: 31, scope: !196, inlinedAt: !151)
!202 = !DILocation(line: 107, column: 21, scope: !196, inlinedAt: !151)
!203 = !DILocation(line: 107, column: 7, scope: !196, inlinedAt: !151)
!204 = !DILocation(line: 107, column: 13, scope: !196, inlinedAt: !151)
!205 = !DILocation(line: 106, column: 29, scope: !196, inlinedAt: !151)
!206 = !DILocation(line: 106, column: 5, scope: !196, inlinedAt: !151)
!207 = distinct !{!207, !197, !208, !139}
!208 = !DILocation(line: 107, column: 38, scope: !193, inlinedAt: !151)
!209 = !DILocation(line: 105, column: 27, scope: !190, inlinedAt: !151)
!210 = !DILocation(line: 105, column: 3, scope: !190, inlinedAt: !151)
!211 = distinct !{!211, !191, !212, !139}
!212 = !DILocation(line: 107, column: 38, scope: !187, inlinedAt: !151)
!213 = !DILocation(line: 137, column: 3, scope: !146)
!214 = distinct !DISubprogram(name: "workload_checksum", scope: !11, file: !11, line: 139, type: !215, scopeLine: 139, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !2, retainedNodes: !59)
!215 = !DISubroutineType(types: !216)
!216 = !{!17, !6}
!217 = !DILocalVariable(name: "task", arg: 1, scope: !214, file: !11, line: 139, type: !6)
!218 = !DILocation(line: 0, scope: !214)
!219 = !DILocation(line: 141, column: 11, scope: !214)
!220 = !DILocation(line: 142, column: 15, scope: !214)
!221 = !DILocation(line: 142, column: 3, scope: !214)
!222 = !DILocation(line: 143, column: 10, scope: !214)
!223 = !DILocation(line: 143, column: 3, scope: !214)
!224 = distinct !DISubprogram(name: "print_array", scope: !11, file: !11, line: 64, type: !225, scopeLine: 68, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition, unit: !2, retainedNodes: !59)
!225 = !DISubroutineType(types: !226)
!226 = !{null, !47, !77, !77}
!227 = !DILocalVariable(name: "n", arg: 1, scope: !224, file: !11, line: 64, type: !47)
!228 = !DILocation(line: 0, scope: !224)
!229 = !DILocalVariable(name: "x1", arg: 2, scope: !224, file: !11, line: 65, type: !77)
!230 = !DILocalVariable(name: "x2", arg: 3, scope: !224, file: !11, line: 66, type: !77)
!231 = !DILocation(line: 71, column: 3, scope: !224)
!232 = !DILocation(line: 72, column: 3, scope: !224)
!233 = !DILocalVariable(name: "i", scope: !224, file: !11, line: 69, type: !47)
!234 = !DILocation(line: 73, column: 8, scope: !235)
!235 = distinct !DILexicalBlock(scope: !224, file: !11, line: 73, column: 3)
!236 = !DILocation(line: 0, scope: !235)
!237 = !DILocation(line: 73, column: 17, scope: !238)
!238 = distinct !DILexicalBlock(scope: !235, file: !11, line: 73, column: 3)
!239 = !DILocation(line: 73, column: 3, scope: !235)
!240 = !DILocation(line: 74, column: 11, scope: !241)
!241 = distinct !DILexicalBlock(scope: !242, file: !11, line: 74, column: 9)
!242 = distinct !DILexicalBlock(scope: !238, file: !11, line: 73, column: 27)
!243 = !DILocation(line: 74, column: 16, scope: !241)
!244 = !DILocation(line: 74, column: 9, scope: !242)
!245 = !DILocation(line: 74, column: 31, scope: !241)
!246 = !DILocation(line: 74, column: 22, scope: !241)
!247 = !DILocation(line: 75, column: 14, scope: !242)
!248 = !DILocation(line: 75, column: 59, scope: !242)
!249 = !DILocation(line: 75, column: 5, scope: !242)
!250 = !DILocation(line: 76, column: 3, scope: !242)
!251 = !DILocation(line: 73, column: 23, scope: !238)
!252 = !DILocation(line: 73, column: 3, scope: !238)
!253 = distinct !{!253, !239, !254, !139}
!254 = !DILocation(line: 76, column: 3, scope: !235)
!255 = !DILocation(line: 77, column: 3, scope: !224)
!256 = !DILocation(line: 79, column: 3, scope: !224)
!257 = !DILocation(line: 80, column: 8, scope: !258)
!258 = distinct !DILexicalBlock(scope: !224, file: !11, line: 80, column: 3)
!259 = !DILocation(line: 0, scope: !258)
!260 = !DILocation(line: 80, column: 17, scope: !261)
!261 = distinct !DILexicalBlock(scope: !258, file: !11, line: 80, column: 3)
!262 = !DILocation(line: 80, column: 3, scope: !258)
!263 = !DILocation(line: 81, column: 11, scope: !264)
!264 = distinct !DILexicalBlock(scope: !265, file: !11, line: 81, column: 9)
!265 = distinct !DILexicalBlock(scope: !261, file: !11, line: 80, column: 27)
!266 = !DILocation(line: 81, column: 16, scope: !264)
!267 = !DILocation(line: 81, column: 9, scope: !265)
!268 = !DILocation(line: 81, column: 31, scope: !264)
!269 = !DILocation(line: 81, column: 22, scope: !264)
!270 = !DILocation(line: 82, column: 14, scope: !265)
!271 = !DILocation(line: 82, column: 59, scope: !265)
!272 = !DILocation(line: 82, column: 5, scope: !265)
!273 = !DILocation(line: 83, column: 3, scope: !265)
!274 = !DILocation(line: 80, column: 23, scope: !261)
!275 = !DILocation(line: 80, column: 3, scope: !261)
!276 = distinct !{!276, !262, !277, !139}
!277 = !DILocation(line: 83, column: 3, scope: !258)
!278 = !DILocation(line: 84, column: 3, scope: !224)
!279 = !DILocation(line: 85, column: 3, scope: !224)
!280 = !DILocation(line: 86, column: 1, scope: !224)
!281 = distinct !DISubprogram(name: "pb_fprintf", scope: !29, file: !29, line: 13, type: !282, scopeLine: 14, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition, unit: !2, retainedNodes: !59)
!282 = !DISubroutineType(types: !283)
!283 = !{!47, !284, !343, null}
!284 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !285, size: 64)
!285 = !DIDerivedType(tag: DW_TAG_typedef, name: "FILE", file: !286, line: 7, baseType: !287)
!286 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/types/FILE.h", directory: "", checksumkind: CSK_MD5, checksum: "571f9fb6223c42439075fdde11a0de5d")
!287 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "_IO_FILE", file: !288, line: 49, size: 1728, elements: !289)
!288 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/types/struct_FILE.h", directory: "", checksumkind: CSK_MD5, checksum: "1bad07471b7974df4ecc1d1c2ca207e6")
!289 = !{!290, !291, !294, !295, !296, !297, !298, !299, !300, !301, !302, !303, !304, !307, !309, !310, !311, !314, !316, !318, !320, !323, !325, !328, !331, !332, !334, !338, !339}
!290 = !DIDerivedType(tag: DW_TAG_member, name: "_flags", scope: !287, file: !288, line: 51, baseType: !47, size: 32)
!291 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_read_ptr", scope: !287, file: !288, line: 54, baseType: !292, size: 64, offset: 64)
!292 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !293, size: 64)
!293 = !DIBasicType(name: "char", size: 8, encoding: DW_ATE_signed_char)
!294 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_read_end", scope: !287, file: !288, line: 55, baseType: !292, size: 64, offset: 128)
!295 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_read_base", scope: !287, file: !288, line: 56, baseType: !292, size: 64, offset: 192)
!296 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_write_base", scope: !287, file: !288, line: 57, baseType: !292, size: 64, offset: 256)
!297 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_write_ptr", scope: !287, file: !288, line: 58, baseType: !292, size: 64, offset: 320)
!298 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_write_end", scope: !287, file: !288, line: 59, baseType: !292, size: 64, offset: 384)
!299 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_buf_base", scope: !287, file: !288, line: 60, baseType: !292, size: 64, offset: 448)
!300 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_buf_end", scope: !287, file: !288, line: 61, baseType: !292, size: 64, offset: 512)
!301 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_save_base", scope: !287, file: !288, line: 64, baseType: !292, size: 64, offset: 576)
!302 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_backup_base", scope: !287, file: !288, line: 65, baseType: !292, size: 64, offset: 640)
!303 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_save_end", scope: !287, file: !288, line: 66, baseType: !292, size: 64, offset: 704)
!304 = !DIDerivedType(tag: DW_TAG_member, name: "_markers", scope: !287, file: !288, line: 68, baseType: !305, size: 64, offset: 768)
!305 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !306, size: 64)
!306 = !DICompositeType(tag: DW_TAG_structure_type, name: "_IO_marker", file: !288, line: 36, flags: DIFlagFwdDecl)
!307 = !DIDerivedType(tag: DW_TAG_member, name: "_chain", scope: !287, file: !288, line: 70, baseType: !308, size: 64, offset: 832)
!308 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !287, size: 64)
!309 = !DIDerivedType(tag: DW_TAG_member, name: "_fileno", scope: !287, file: !288, line: 72, baseType: !47, size: 32, offset: 896)
!310 = !DIDerivedType(tag: DW_TAG_member, name: "_flags2", scope: !287, file: !288, line: 73, baseType: !47, size: 32, offset: 928)
!311 = !DIDerivedType(tag: DW_TAG_member, name: "_old_offset", scope: !287, file: !288, line: 74, baseType: !312, size: 64, offset: 960)
!312 = !DIDerivedType(tag: DW_TAG_typedef, name: "__off_t", file: !20, line: 152, baseType: !313)
!313 = !DIBasicType(name: "long", size: 64, encoding: DW_ATE_signed)
!314 = !DIDerivedType(tag: DW_TAG_member, name: "_cur_column", scope: !287, file: !288, line: 77, baseType: !315, size: 16, offset: 1024)
!315 = !DIBasicType(name: "unsigned short", size: 16, encoding: DW_ATE_unsigned)
!316 = !DIDerivedType(tag: DW_TAG_member, name: "_vtable_offset", scope: !287, file: !288, line: 78, baseType: !317, size: 8, offset: 1040)
!317 = !DIBasicType(name: "signed char", size: 8, encoding: DW_ATE_signed_char)
!318 = !DIDerivedType(tag: DW_TAG_member, name: "_shortbuf", scope: !287, file: !288, line: 79, baseType: !319, size: 8, offset: 1048)
!319 = !DICompositeType(tag: DW_TAG_array_type, baseType: !293, size: 8, elements: !21)
!320 = !DIDerivedType(tag: DW_TAG_member, name: "_lock", scope: !287, file: !288, line: 81, baseType: !321, size: 64, offset: 1088)
!321 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !322, size: 64)
!322 = !DIDerivedType(tag: DW_TAG_typedef, name: "_IO_lock_t", file: !288, line: 43, baseType: null)
!323 = !DIDerivedType(tag: DW_TAG_member, name: "_offset", scope: !287, file: !288, line: 89, baseType: !324, size: 64, offset: 1152)
!324 = !DIDerivedType(tag: DW_TAG_typedef, name: "__off64_t", file: !20, line: 153, baseType: !313)
!325 = !DIDerivedType(tag: DW_TAG_member, name: "_codecvt", scope: !287, file: !288, line: 91, baseType: !326, size: 64, offset: 1216)
!326 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !327, size: 64)
!327 = !DICompositeType(tag: DW_TAG_structure_type, name: "_IO_codecvt", file: !288, line: 37, flags: DIFlagFwdDecl)
!328 = !DIDerivedType(tag: DW_TAG_member, name: "_wide_data", scope: !287, file: !288, line: 92, baseType: !329, size: 64, offset: 1280)
!329 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !330, size: 64)
!330 = !DICompositeType(tag: DW_TAG_structure_type, name: "_IO_wide_data", file: !288, line: 38, flags: DIFlagFwdDecl)
!331 = !DIDerivedType(tag: DW_TAG_member, name: "_freeres_list", scope: !287, file: !288, line: 93, baseType: !308, size: 64, offset: 1344)
!332 = !DIDerivedType(tag: DW_TAG_member, name: "_freeres_buf", scope: !287, file: !288, line: 94, baseType: !333, size: 64, offset: 1408)
!333 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: null, size: 64)
!334 = !DIDerivedType(tag: DW_TAG_member, name: "__pad5", scope: !287, file: !288, line: 95, baseType: !335, size: 64, offset: 1472)
!335 = !DIDerivedType(tag: DW_TAG_typedef, name: "size_t", file: !336, line: 46, baseType: !337)
!336 = !DIFile(filename: "/usr/lib/llvm-14/lib/clang/14.0.0/include/stddef.h", directory: "", checksumkind: CSK_MD5, checksum: "2499dd2361b915724b073282bea3a7bc")
!337 = !DIBasicType(name: "unsigned long", size: 64, encoding: DW_ATE_unsigned)
!338 = !DIDerivedType(tag: DW_TAG_member, name: "_mode", scope: !287, file: !288, line: 96, baseType: !47, size: 32, offset: 1536)
!339 = !DIDerivedType(tag: DW_TAG_member, name: "_unused2", scope: !287, file: !288, line: 98, baseType: !340, size: 160, offset: 1568)
!340 = !DICompositeType(tag: DW_TAG_array_type, baseType: !293, size: 160, elements: !341)
!341 = !{!342}
!342 = !DISubrange(count: 20)
!343 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !344, size: 64)
!344 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !293)
!345 = !DILocalVariable(name: "stream", arg: 1, scope: !281, file: !29, line: 13, type: !284)
!346 = !DILocation(line: 0, scope: !281)
!347 = !DILocalVariable(name: "format", arg: 2, scope: !281, file: !29, line: 13, type: !343)
!348 = !DILocalVariable(name: "buffer", scope: !281, file: !29, line: 15, type: !349)
!349 = !DICompositeType(tag: DW_TAG_array_type, baseType: !293, size: 6144, elements: !350)
!350 = !{!351}
!351 = !DISubrange(count: 768)
!352 = !DILocation(line: 15, column: 10, scope: !281)
!353 = !DILocalVariable(name: "args", scope: !281, file: !29, line: 16, type: !354)
!354 = !DIDerivedType(tag: DW_TAG_typedef, name: "va_list", file: !355, line: 52, baseType: !356)
!355 = !DIFile(filename: "/usr/include/stdio.h", directory: "", checksumkind: CSK_MD5, checksum: "f31eefcc3f15835fc5a4023a625cf609")
!356 = !DIDerivedType(tag: DW_TAG_typedef, name: "__gnuc_va_list", file: !357, line: 32, baseType: !358)
!357 = !DIFile(filename: "/usr/lib/llvm-14/lib/clang/14.0.0/include/stdarg.h", directory: "", checksumkind: CSK_MD5, checksum: "4de3cbd931b589d291e5c39387aecf82")
!358 = !DIDerivedType(tag: DW_TAG_typedef, name: "__builtin_va_list", file: !359, baseType: !360)
!359 = !DIFile(filename: "source/workload.c", directory: "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/affine-bounds-20260929/suite/mvt")
!360 = !DICompositeType(tag: DW_TAG_array_type, baseType: !361, size: 192, elements: !21)
!361 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "__va_list_tag", size: 192, elements: !362)
!362 = !{!363, !364, !365, !366}
!363 = !DIDerivedType(tag: DW_TAG_member, name: "gp_offset", scope: !361, file: !359, line: 16, baseType: !6, size: 32)
!364 = !DIDerivedType(tag: DW_TAG_member, name: "fp_offset", scope: !361, file: !359, line: 16, baseType: !6, size: 32, offset: 32)
!365 = !DIDerivedType(tag: DW_TAG_member, name: "overflow_arg_area", scope: !361, file: !359, line: 16, baseType: !333, size: 64, offset: 64)
!366 = !DIDerivedType(tag: DW_TAG_member, name: "reg_save_area", scope: !361, file: !359, line: 16, baseType: !333, size: 64, offset: 128)
!367 = !DILocation(line: 16, column: 13, scope: !281)
!368 = !DILocation(line: 17, column: 5, scope: !281)
!369 = !DILocation(line: 18, column: 27, scope: !281)
!370 = !DILocation(line: 18, column: 59, scope: !281)
!371 = !DILocation(line: 18, column: 17, scope: !281)
!372 = !DILocalVariable(name: "count", scope: !281, file: !29, line: 18, type: !47)
!373 = !DILocation(line: 19, column: 5, scope: !281)
!374 = !DILocation(line: 20, column: 15, scope: !375)
!375 = distinct !DILexicalBlock(scope: !281, file: !29, line: 20, column: 9)
!376 = !DILocation(line: 20, column: 19, scope: !375)
!377 = !DILocation(line: 20, column: 22, scope: !375)
!378 = !DILocation(line: 20, column: 38, scope: !375)
!379 = !DILocation(line: 20, column: 9, scope: !281)
!380 = !DILocation(line: 20, column: 57, scope: !375)
!381 = !DILocalVariable(name: "i", scope: !382, file: !29, line: 21, type: !47)
!382 = distinct !DILexicalBlock(scope: !281, file: !29, line: 21, column: 5)
!383 = !DILocation(line: 0, scope: !382)
!384 = !DILocation(line: 21, column: 10, scope: !382)
!385 = !DILocation(line: 21, column: 23, scope: !386)
!386 = distinct !DILexicalBlock(scope: !382, file: !29, line: 21, column: 5)
!387 = !DILocation(line: 21, column: 5, scope: !382)
!388 = !DILocation(line: 22, column: 35, scope: !389)
!389 = distinct !DILexicalBlock(scope: !386, file: !29, line: 21, column: 37)
!390 = !DILocation(line: 22, column: 20, scope: !389)
!391 = !DILocation(line: 22, column: 17, scope: !389)
!392 = !DILocation(line: 23, column: 17, scope: !389)
!393 = !DILocation(line: 24, column: 5, scope: !389)
!394 = !DILocation(line: 21, column: 32, scope: !386)
!395 = !DILocation(line: 21, column: 5, scope: !386)
!396 = distinct !{!396, !387, !397, !139}
!397 = !DILocation(line: 24, column: 5, scope: !382)
!398 = !DILocation(line: 29, column: 11, scope: !281)
!399 = !DILocation(line: 31, column: 5, scope: !281)
