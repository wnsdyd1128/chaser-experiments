; ModuleID = '/workspace/experiments-array-support/chaser/.cache/periodic-polybench/affine-bounds-20260929/suite/mvt/source/workload.c'
source_filename = "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/affine-bounds-20260929/suite/mvt/source/workload.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

%struct._IO_FILE = type { i32, i8*, i8*, i8*, i8*, i8*, i8*, i8*, i8*, i8*, i8*, i8*, %struct._IO_marker*, %struct._IO_FILE*, i32, i32, i64, i16, i8, [1 x i8], i8*, i64, %struct._IO_codecvt*, %struct._IO_wide_data*, %struct._IO_FILE*, i8*, i64, i32, [20 x i8] }
%struct._IO_marker = type opaque
%struct._IO_codecvt = type opaque
%struct._IO_wide_data = type opaque
%struct.__va_list_tag = type { i32, i32, i8*, i8* }

@n = dso_local global i32 400, align 4, !dbg !0
@A = dso_local global [400 x [400 x double]] zeroinitializer, section ".chaser_data.A", align 64, !dbg !30
@x1 = dso_local global [400 x double] zeroinitializer, section ".chaser_data.x1", align 64, !dbg !35
@x2 = dso_local global [400 x double] zeroinitializer, section ".chaser_data.x2", align 64, !dbg !39
@y_1 = dso_local global [400 x double] zeroinitializer, section ".chaser_data.y_1", align 64, !dbg !41
@y_2 = dso_local global [400 x double] zeroinitializer, section ".chaser_data.y_2", align 64, !dbg !43
@.str = private unnamed_addr constant [12 x i8] c"ape.analyze\00", section "llvm.metadata"
@.str.1 = private unnamed_addr constant [121 x i8] c"/workspace/experiments-array-support/chaser/.cache/periodic-polybench/affine-bounds-20260929/suite/mvt/source/workload.c\00", section "llvm.metadata"
@pb_hash = internal global i32 0, align 4, !dbg !27
@workload_jobs = dso_local constant [1 x i32 ()*] [i32 ()* @task_job_polybench], align 8, !dbg !9
@workload_expected = dso_local constant [1 x i32] [i32 2099682718], align 4, !dbg !23
@stderr = external global %struct._IO_FILE*, align 8
@.str.2 = private unnamed_addr constant [23 x i8] c"==BEGIN DUMP_ARRAYS==\0A\00", align 1
@.str.3 = private unnamed_addr constant [15 x i8] c"begin dump: %s\00", align 1
@.str.4 = private unnamed_addr constant [3 x i8] c"x1\00", align 1
@.str.5 = private unnamed_addr constant [2 x i8] c"\0A\00", align 1
@.str.6 = private unnamed_addr constant [8 x i8] c"%0.2lf \00", align 1
@.str.7 = private unnamed_addr constant [17 x i8] c"\0Aend   dump: %s\0A\00", align 1
@.str.8 = private unnamed_addr constant [3 x i8] c"x2\00", align 1
@.str.9 = private unnamed_addr constant [23 x i8] c"==END   DUMP_ARRAYS==\0A\00", align 1
@pb_emit = internal global i32 1, align 4, !dbg !45
@llvm.global.annotations = appending global [1 x { i8*, i8*, i8*, i32, i8* }] [{ i8*, i8*, i8*, i32, i8* } { i8* bitcast (i32 ()* @task_job_polybench to i8*), i8* getelementptr inbounds ([12 x i8], [12 x i8]* @.str, i32 0, i32 0), i8* getelementptr inbounds ([121 x i8], [121 x i8]* @.str.1, i32 0, i32 0), i32 130, i8* null }], section "llvm.metadata"

; Function Attrs: noinline nounwind uwtable
define dso_local void @workload_prepare() #0 !dbg !56 {
  ret void, !dbg !60
}

; Function Attrs: noinline nounwind uwtable
define dso_local void @workload_reset(i32 noundef %0) #0 !dbg !61 {
  %2 = alloca i32, align 4
  store i32 %0, i32* %2, align 4
  call void @llvm.dbg.declare(metadata i32* %2, metadata !64, metadata !DIExpression()), !dbg !65
  %3 = load i32, i32* %2, align 4, !dbg !66
  call void @llvm.memset.p0i8.i64(i8* align 64 bitcast ([400 x [400 x double]]* @A to i8*), i8 0, i64 1280000, i1 false), !dbg !67
  call void @llvm.memset.p0i8.i64(i8* align 64 bitcast ([400 x double]* @x1 to i8*), i8 0, i64 3200, i1 false), !dbg !68
  call void @llvm.memset.p0i8.i64(i8* align 64 bitcast ([400 x double]* @x2 to i8*), i8 0, i64 3200, i1 false), !dbg !69
  call void @llvm.memset.p0i8.i64(i8* align 64 bitcast ([400 x double]* @y_1 to i8*), i8 0, i64 3200, i1 false), !dbg !70
  call void @llvm.memset.p0i8.i64(i8* align 64 bitcast ([400 x double]* @y_2 to i8*), i8 0, i64 3200, i1 false), !dbg !71
  %4 = load i32, i32* @n, align 4, !dbg !72
  call void @init_array(i32 noundef %4, double* noundef getelementptr inbounds ([400 x double], [400 x double]* @x1, i64 0, i64 0), double* noundef getelementptr inbounds ([400 x double], [400 x double]* @x2, i64 0, i64 0), double* noundef getelementptr inbounds ([400 x double], [400 x double]* @y_1, i64 0, i64 0), double* noundef getelementptr inbounds ([400 x double], [400 x double]* @y_2, i64 0, i64 0), [400 x double]* noundef getelementptr inbounds ([400 x [400 x double]], [400 x [400 x double]]* @A, i64 0, i64 0)), !dbg !73
  ret void, !dbg !74
}

; Function Attrs: nofree nosync nounwind readnone speculatable willreturn
declare void @llvm.dbg.declare(metadata, metadata, metadata) #1

; Function Attrs: argmemonly nofree nounwind willreturn writeonly
declare void @llvm.memset.p0i8.i64(i8* nocapture writeonly, i8, i64, i1 immarg) #2

; Function Attrs: noinline nounwind uwtable
define internal void @init_array(i32 noundef %0, double* noundef %1, double* noundef %2, double* noundef %3, double* noundef %4, [400 x double]* noundef %5) #0 !dbg !75 {
  %7 = alloca i32, align 4
  %8 = alloca double*, align 8
  %9 = alloca double*, align 8
  %10 = alloca double*, align 8
  %11 = alloca double*, align 8
  %12 = alloca [400 x double]*, align 8
  %13 = alloca i32, align 4
  %14 = alloca i32, align 4
  store i32 %0, i32* %7, align 4
  call void @llvm.dbg.declare(metadata i32* %7, metadata !80, metadata !DIExpression()), !dbg !81
  store double* %1, double** %8, align 8
  call void @llvm.dbg.declare(metadata double** %8, metadata !82, metadata !DIExpression()), !dbg !83
  store double* %2, double** %9, align 8
  call void @llvm.dbg.declare(metadata double** %9, metadata !84, metadata !DIExpression()), !dbg !85
  store double* %3, double** %10, align 8
  call void @llvm.dbg.declare(metadata double** %10, metadata !86, metadata !DIExpression()), !dbg !87
  store double* %4, double** %11, align 8
  call void @llvm.dbg.declare(metadata double** %11, metadata !88, metadata !DIExpression()), !dbg !89
  store [400 x double]* %5, [400 x double]** %12, align 8
  call void @llvm.dbg.declare(metadata [400 x double]** %12, metadata !90, metadata !DIExpression()), !dbg !91
  call void @llvm.dbg.declare(metadata i32* %13, metadata !92, metadata !DIExpression()), !dbg !93
  call void @llvm.dbg.declare(metadata i32* %14, metadata !94, metadata !DIExpression()), !dbg !95
  store i32 0, i32* %13, align 4, !dbg !96
  br label %15, !dbg !98

15:                                               ; preds = %92, %6
  %16 = load i32, i32* %13, align 4, !dbg !99
  %17 = load i32, i32* %7, align 4, !dbg !101
  %18 = icmp slt i32 %16, %17, !dbg !102
  br i1 %18, label %19, label %95, !dbg !103

19:                                               ; preds = %15
  %20 = load i32, i32* %13, align 4, !dbg !104
  %21 = load i32, i32* %7, align 4, !dbg !106
  %22 = srem i32 %20, %21, !dbg !107
  %23 = sitofp i32 %22 to double, !dbg !108
  %24 = load i32, i32* %7, align 4, !dbg !109
  %25 = sitofp i32 %24 to double, !dbg !109
  %26 = fdiv double %23, %25, !dbg !110
  %27 = load double*, double** %8, align 8, !dbg !111
  %28 = load i32, i32* %13, align 4, !dbg !112
  %29 = sext i32 %28 to i64, !dbg !111
  %30 = getelementptr inbounds double, double* %27, i64 %29, !dbg !111
  store double %26, double* %30, align 8, !dbg !113
  %31 = load i32, i32* %13, align 4, !dbg !114
  %32 = add nsw i32 %31, 1, !dbg !115
  %33 = load i32, i32* %7, align 4, !dbg !116
  %34 = srem i32 %32, %33, !dbg !117
  %35 = sitofp i32 %34 to double, !dbg !118
  %36 = load i32, i32* %7, align 4, !dbg !119
  %37 = sitofp i32 %36 to double, !dbg !119
  %38 = fdiv double %35, %37, !dbg !120
  %39 = load double*, double** %9, align 8, !dbg !121
  %40 = load i32, i32* %13, align 4, !dbg !122
  %41 = sext i32 %40 to i64, !dbg !121
  %42 = getelementptr inbounds double, double* %39, i64 %41, !dbg !121
  store double %38, double* %42, align 8, !dbg !123
  %43 = load i32, i32* %13, align 4, !dbg !124
  %44 = add nsw i32 %43, 3, !dbg !125
  %45 = load i32, i32* %7, align 4, !dbg !126
  %46 = srem i32 %44, %45, !dbg !127
  %47 = sitofp i32 %46 to double, !dbg !128
  %48 = load i32, i32* %7, align 4, !dbg !129
  %49 = sitofp i32 %48 to double, !dbg !129
  %50 = fdiv double %47, %49, !dbg !130
  %51 = load double*, double** %10, align 8, !dbg !131
  %52 = load i32, i32* %13, align 4, !dbg !132
  %53 = sext i32 %52 to i64, !dbg !131
  %54 = getelementptr inbounds double, double* %51, i64 %53, !dbg !131
  store double %50, double* %54, align 8, !dbg !133
  %55 = load i32, i32* %13, align 4, !dbg !134
  %56 = add nsw i32 %55, 4, !dbg !135
  %57 = load i32, i32* %7, align 4, !dbg !136
  %58 = srem i32 %56, %57, !dbg !137
  %59 = sitofp i32 %58 to double, !dbg !138
  %60 = load i32, i32* %7, align 4, !dbg !139
  %61 = sitofp i32 %60 to double, !dbg !139
  %62 = fdiv double %59, %61, !dbg !140
  %63 = load double*, double** %11, align 8, !dbg !141
  %64 = load i32, i32* %13, align 4, !dbg !142
  %65 = sext i32 %64 to i64, !dbg !141
  %66 = getelementptr inbounds double, double* %63, i64 %65, !dbg !141
  store double %62, double* %66, align 8, !dbg !143
  store i32 0, i32* %14, align 4, !dbg !144
  br label %67, !dbg !146

67:                                               ; preds = %88, %19
  %68 = load i32, i32* %14, align 4, !dbg !147
  %69 = load i32, i32* %7, align 4, !dbg !149
  %70 = icmp slt i32 %68, %69, !dbg !150
  br i1 %70, label %71, label %91, !dbg !151

71:                                               ; preds = %67
  %72 = load i32, i32* %13, align 4, !dbg !152
  %73 = load i32, i32* %14, align 4, !dbg !153
  %74 = mul nsw i32 %72, %73, !dbg !154
  %75 = load i32, i32* %7, align 4, !dbg !155
  %76 = srem i32 %74, %75, !dbg !156
  %77 = sitofp i32 %76 to double, !dbg !157
  %78 = load i32, i32* %7, align 4, !dbg !158
  %79 = sitofp i32 %78 to double, !dbg !158
  %80 = fdiv double %77, %79, !dbg !159
  %81 = load [400 x double]*, [400 x double]** %12, align 8, !dbg !160
  %82 = load i32, i32* %13, align 4, !dbg !161
  %83 = sext i32 %82 to i64, !dbg !160
  %84 = getelementptr inbounds [400 x double], [400 x double]* %81, i64 %83, !dbg !160
  %85 = load i32, i32* %14, align 4, !dbg !162
  %86 = sext i32 %85 to i64, !dbg !160
  %87 = getelementptr inbounds [400 x double], [400 x double]* %84, i64 0, i64 %86, !dbg !160
  store double %80, double* %87, align 8, !dbg !163
  br label %88, !dbg !160

88:                                               ; preds = %71
  %89 = load i32, i32* %14, align 4, !dbg !164
  %90 = add nsw i32 %89, 1, !dbg !164
  store i32 %90, i32* %14, align 4, !dbg !164
  br label %67, !dbg !165, !llvm.loop !166

91:                                               ; preds = %67
  br label %92, !dbg !169

92:                                               ; preds = %91
  %93 = load i32, i32* %13, align 4, !dbg !170
  %94 = add nsw i32 %93, 1, !dbg !170
  store i32 %94, i32* %13, align 4, !dbg !170
  br label %15, !dbg !171, !llvm.loop !172

95:                                               ; preds = %15
  ret void, !dbg !174
}

; Function Attrs: noinline nounwind uwtable
define dso_local i32 @task_job_polybench() #0 !dbg !175 {
  %1 = alloca i32, align 4
  %2 = alloca double*, align 8
  %3 = alloca double*, align 8
  %4 = alloca double*, align 8
  %5 = alloca double*, align 8
  %6 = alloca [400 x double]*, align 8
  %7 = alloca i32, align 4
  %8 = alloca i32, align 4
  %9 = load i32, i32* @n, align 4, !dbg !176
  store i32 %9, i32* %1, align 4
  call void @llvm.dbg.declare(metadata i32* %1, metadata !177, metadata !DIExpression()), !dbg !179
  store double* getelementptr inbounds ([400 x double], [400 x double]* @x1, i64 0, i64 0), double** %2, align 8
  call void @llvm.dbg.declare(metadata double** %2, metadata !181, metadata !DIExpression()), !dbg !182
  store double* getelementptr inbounds ([400 x double], [400 x double]* @x2, i64 0, i64 0), double** %3, align 8
  call void @llvm.dbg.declare(metadata double** %3, metadata !183, metadata !DIExpression()), !dbg !184
  store double* getelementptr inbounds ([400 x double], [400 x double]* @y_1, i64 0, i64 0), double** %4, align 8
  call void @llvm.dbg.declare(metadata double** %4, metadata !185, metadata !DIExpression()), !dbg !186
  store double* getelementptr inbounds ([400 x double], [400 x double]* @y_2, i64 0, i64 0), double** %5, align 8
  call void @llvm.dbg.declare(metadata double** %5, metadata !187, metadata !DIExpression()), !dbg !188
  store [400 x double]* getelementptr inbounds ([400 x [400 x double]], [400 x [400 x double]]* @A, i64 0, i64 0), [400 x double]** %6, align 8
  call void @llvm.dbg.declare(metadata [400 x double]** %6, metadata !189, metadata !DIExpression()), !dbg !190
  call void @llvm.dbg.declare(metadata i32* %7, metadata !191, metadata !DIExpression()), !dbg !192
  call void @llvm.dbg.declare(metadata i32* %8, metadata !193, metadata !DIExpression()), !dbg !194
  store i32 0, i32* %7, align 4, !dbg !195
  br label %10, !dbg !197

10:                                               ; preds = %44, %0
  %11 = load i32, i32* %7, align 4, !dbg !198
  %12 = icmp slt i32 %11, 400, !dbg !200
  br i1 %12, label %13, label %47, !dbg !201

13:                                               ; preds = %10
  store i32 0, i32* %8, align 4, !dbg !202
  br label %14, !dbg !204

14:                                               ; preds = %17, %13
  %15 = load i32, i32* %8, align 4, !dbg !205
  %16 = icmp slt i32 %15, 400, !dbg !207
  br i1 %16, label %17, label %44, !dbg !208

17:                                               ; preds = %14
  %18 = load double*, double** %2, align 8, !dbg !209
  %19 = load i32, i32* %7, align 4, !dbg !210
  %20 = sext i32 %19 to i64, !dbg !209
  %21 = getelementptr inbounds double, double* %18, i64 %20, !dbg !209
  %22 = load double, double* %21, align 8, !dbg !209
  %23 = load [400 x double]*, [400 x double]** %6, align 8, !dbg !211
  %24 = load i32, i32* %7, align 4, !dbg !212
  %25 = sext i32 %24 to i64, !dbg !211
  %26 = getelementptr inbounds [400 x double], [400 x double]* %23, i64 %25, !dbg !211
  %27 = load i32, i32* %8, align 4, !dbg !213
  %28 = sext i32 %27 to i64, !dbg !211
  %29 = getelementptr inbounds [400 x double], [400 x double]* %26, i64 0, i64 %28, !dbg !211
  %30 = load double, double* %29, align 8, !dbg !211
  %31 = load double*, double** %4, align 8, !dbg !214
  %32 = load i32, i32* %8, align 4, !dbg !215
  %33 = sext i32 %32 to i64, !dbg !214
  %34 = getelementptr inbounds double, double* %31, i64 %33, !dbg !214
  %35 = load double, double* %34, align 8, !dbg !214
  %36 = fmul double %30, %35, !dbg !216
  %37 = fadd double %22, %36, !dbg !217
  %38 = load double*, double** %2, align 8, !dbg !218
  %39 = load i32, i32* %7, align 4, !dbg !219
  %40 = sext i32 %39 to i64, !dbg !218
  %41 = getelementptr inbounds double, double* %38, i64 %40, !dbg !218
  store double %37, double* %41, align 8, !dbg !220
  %42 = load i32, i32* %8, align 4, !dbg !221
  %43 = add nsw i32 %42, 1, !dbg !221
  store i32 %43, i32* %8, align 4, !dbg !221
  br label %14, !dbg !222, !llvm.loop !223

44:                                               ; preds = %14
  %45 = load i32, i32* %7, align 4, !dbg !225
  %46 = add nsw i32 %45, 1, !dbg !225
  store i32 %46, i32* %7, align 4, !dbg !225
  br label %10, !dbg !226, !llvm.loop !227

47:                                               ; preds = %10
  store i32 0, i32* %7, align 4, !dbg !229
  br label %48, !dbg !231

48:                                               ; preds = %82, %47
  %49 = load i32, i32* %7, align 4, !dbg !232
  %50 = icmp slt i32 %49, 400, !dbg !234
  br i1 %50, label %51, label %85, !dbg !235

51:                                               ; preds = %48
  store i32 0, i32* %8, align 4, !dbg !236
  br label %52, !dbg !238

52:                                               ; preds = %55, %51
  %53 = load i32, i32* %8, align 4, !dbg !239
  %54 = icmp slt i32 %53, 400, !dbg !241
  br i1 %54, label %55, label %82, !dbg !242

55:                                               ; preds = %52
  %56 = load double*, double** %3, align 8, !dbg !243
  %57 = load i32, i32* %7, align 4, !dbg !244
  %58 = sext i32 %57 to i64, !dbg !243
  %59 = getelementptr inbounds double, double* %56, i64 %58, !dbg !243
  %60 = load double, double* %59, align 8, !dbg !243
  %61 = load [400 x double]*, [400 x double]** %6, align 8, !dbg !245
  %62 = load i32, i32* %8, align 4, !dbg !246
  %63 = sext i32 %62 to i64, !dbg !245
  %64 = getelementptr inbounds [400 x double], [400 x double]* %61, i64 %63, !dbg !245
  %65 = load i32, i32* %7, align 4, !dbg !247
  %66 = sext i32 %65 to i64, !dbg !245
  %67 = getelementptr inbounds [400 x double], [400 x double]* %64, i64 0, i64 %66, !dbg !245
  %68 = load double, double* %67, align 8, !dbg !245
  %69 = load double*, double** %5, align 8, !dbg !248
  %70 = load i32, i32* %8, align 4, !dbg !249
  %71 = sext i32 %70 to i64, !dbg !248
  %72 = getelementptr inbounds double, double* %69, i64 %71, !dbg !248
  %73 = load double, double* %72, align 8, !dbg !248
  %74 = fmul double %68, %73, !dbg !250
  %75 = fadd double %60, %74, !dbg !251
  %76 = load double*, double** %3, align 8, !dbg !252
  %77 = load i32, i32* %7, align 4, !dbg !253
  %78 = sext i32 %77 to i64, !dbg !252
  %79 = getelementptr inbounds double, double* %76, i64 %78, !dbg !252
  store double %75, double* %79, align 8, !dbg !254
  %80 = load i32, i32* %8, align 4, !dbg !255
  %81 = add nsw i32 %80, 1, !dbg !255
  store i32 %81, i32* %8, align 4, !dbg !255
  br label %52, !dbg !256, !llvm.loop !257

82:                                               ; preds = %52
  %83 = load i32, i32* %7, align 4, !dbg !259
  %84 = add nsw i32 %83, 1, !dbg !259
  store i32 %84, i32* %7, align 4, !dbg !259
  br label %48, !dbg !260, !llvm.loop !261

85:                                               ; preds = %48
  ret i32 0, !dbg !263
}

; Function Attrs: noinline nounwind uwtable
define dso_local i32 @workload_checksum(i32 noundef %0) #0 !dbg !264 {
  %2 = alloca i32, align 4
  store i32 %0, i32* %2, align 4
  call void @llvm.dbg.declare(metadata i32* %2, metadata !267, metadata !DIExpression()), !dbg !268
  %3 = load i32, i32* %2, align 4, !dbg !269
  store i32 -2128831035, i32* @pb_hash, align 4, !dbg !270
  %4 = load i32, i32* @n, align 4, !dbg !271
  call void @print_array(i32 noundef %4, double* noundef getelementptr inbounds ([400 x double], [400 x double]* @x1, i64 0, i64 0), double* noundef getelementptr inbounds ([400 x double], [400 x double]* @x2, i64 0, i64 0)), !dbg !272
  %5 = load i32, i32* @pb_hash, align 4, !dbg !273
  ret i32 %5, !dbg !274
}

; Function Attrs: noinline nounwind uwtable
define internal void @print_array(i32 noundef %0, double* noundef %1, double* noundef %2) #0 !dbg !275 {
  %4 = alloca i32, align 4
  %5 = alloca double*, align 8
  %6 = alloca double*, align 8
  %7 = alloca i32, align 4
  store i32 %0, i32* %4, align 4
  call void @llvm.dbg.declare(metadata i32* %4, metadata !278, metadata !DIExpression()), !dbg !279
  store double* %1, double** %5, align 8
  call void @llvm.dbg.declare(metadata double** %5, metadata !280, metadata !DIExpression()), !dbg !281
  store double* %2, double** %6, align 8
  call void @llvm.dbg.declare(metadata double** %6, metadata !282, metadata !DIExpression()), !dbg !283
  call void @llvm.dbg.declare(metadata i32* %7, metadata !284, metadata !DIExpression()), !dbg !285
  %8 = load %struct._IO_FILE*, %struct._IO_FILE** @stderr, align 8, !dbg !286
  %9 = call i32 (%struct._IO_FILE*, i8*, ...) @pb_fprintf(%struct._IO_FILE* noundef %8, i8* noundef getelementptr inbounds ([23 x i8], [23 x i8]* @.str.2, i64 0, i64 0)), !dbg !286
  %10 = load %struct._IO_FILE*, %struct._IO_FILE** @stderr, align 8, !dbg !287
  %11 = call i32 (%struct._IO_FILE*, i8*, ...) @pb_fprintf(%struct._IO_FILE* noundef %10, i8* noundef getelementptr inbounds ([15 x i8], [15 x i8]* @.str.3, i64 0, i64 0), i8* noundef getelementptr inbounds ([3 x i8], [3 x i8]* @.str.4, i64 0, i64 0)), !dbg !287
  store i32 0, i32* %7, align 4, !dbg !288
  br label %12, !dbg !290

12:                                               ; preds = %31, %3
  %13 = load i32, i32* %7, align 4, !dbg !291
  %14 = load i32, i32* %4, align 4, !dbg !293
  %15 = icmp slt i32 %13, %14, !dbg !294
  br i1 %15, label %16, label %34, !dbg !295

16:                                               ; preds = %12
  %17 = load i32, i32* %7, align 4, !dbg !296
  %18 = srem i32 %17, 20, !dbg !299
  %19 = icmp eq i32 %18, 0, !dbg !300
  br i1 %19, label %20, label %23, !dbg !301

20:                                               ; preds = %16
  %21 = load %struct._IO_FILE*, %struct._IO_FILE** @stderr, align 8, !dbg !302
  %22 = call i32 (%struct._IO_FILE*, i8*, ...) @pb_fprintf(%struct._IO_FILE* noundef %21, i8* noundef getelementptr inbounds ([2 x i8], [2 x i8]* @.str.5, i64 0, i64 0)), !dbg !303
  br label %23, !dbg !303

23:                                               ; preds = %20, %16
  %24 = load %struct._IO_FILE*, %struct._IO_FILE** @stderr, align 8, !dbg !304
  %25 = load double*, double** %5, align 8, !dbg !305
  %26 = load i32, i32* %7, align 4, !dbg !306
  %27 = sext i32 %26 to i64, !dbg !305
  %28 = getelementptr inbounds double, double* %25, i64 %27, !dbg !305
  %29 = load double, double* %28, align 8, !dbg !305
  %30 = call i32 (%struct._IO_FILE*, i8*, ...) @pb_fprintf(%struct._IO_FILE* noundef %24, i8* noundef getelementptr inbounds ([8 x i8], [8 x i8]* @.str.6, i64 0, i64 0), double noundef %29), !dbg !307
  br label %31, !dbg !308

31:                                               ; preds = %23
  %32 = load i32, i32* %7, align 4, !dbg !309
  %33 = add nsw i32 %32, 1, !dbg !309
  store i32 %33, i32* %7, align 4, !dbg !309
  br label %12, !dbg !310, !llvm.loop !311

34:                                               ; preds = %12
  %35 = load %struct._IO_FILE*, %struct._IO_FILE** @stderr, align 8, !dbg !313
  %36 = call i32 (%struct._IO_FILE*, i8*, ...) @pb_fprintf(%struct._IO_FILE* noundef %35, i8* noundef getelementptr inbounds ([17 x i8], [17 x i8]* @.str.7, i64 0, i64 0), i8* noundef getelementptr inbounds ([3 x i8], [3 x i8]* @.str.4, i64 0, i64 0)), !dbg !313
  %37 = load %struct._IO_FILE*, %struct._IO_FILE** @stderr, align 8, !dbg !314
  %38 = call i32 (%struct._IO_FILE*, i8*, ...) @pb_fprintf(%struct._IO_FILE* noundef %37, i8* noundef getelementptr inbounds ([15 x i8], [15 x i8]* @.str.3, i64 0, i64 0), i8* noundef getelementptr inbounds ([3 x i8], [3 x i8]* @.str.8, i64 0, i64 0)), !dbg !314
  store i32 0, i32* %7, align 4, !dbg !315
  br label %39, !dbg !317

39:                                               ; preds = %58, %34
  %40 = load i32, i32* %7, align 4, !dbg !318
  %41 = load i32, i32* %4, align 4, !dbg !320
  %42 = icmp slt i32 %40, %41, !dbg !321
  br i1 %42, label %43, label %61, !dbg !322

43:                                               ; preds = %39
  %44 = load i32, i32* %7, align 4, !dbg !323
  %45 = srem i32 %44, 20, !dbg !326
  %46 = icmp eq i32 %45, 0, !dbg !327
  br i1 %46, label %47, label %50, !dbg !328

47:                                               ; preds = %43
  %48 = load %struct._IO_FILE*, %struct._IO_FILE** @stderr, align 8, !dbg !329
  %49 = call i32 (%struct._IO_FILE*, i8*, ...) @pb_fprintf(%struct._IO_FILE* noundef %48, i8* noundef getelementptr inbounds ([2 x i8], [2 x i8]* @.str.5, i64 0, i64 0)), !dbg !330
  br label %50, !dbg !330

50:                                               ; preds = %47, %43
  %51 = load %struct._IO_FILE*, %struct._IO_FILE** @stderr, align 8, !dbg !331
  %52 = load double*, double** %6, align 8, !dbg !332
  %53 = load i32, i32* %7, align 4, !dbg !333
  %54 = sext i32 %53 to i64, !dbg !332
  %55 = getelementptr inbounds double, double* %52, i64 %54, !dbg !332
  %56 = load double, double* %55, align 8, !dbg !332
  %57 = call i32 (%struct._IO_FILE*, i8*, ...) @pb_fprintf(%struct._IO_FILE* noundef %51, i8* noundef getelementptr inbounds ([8 x i8], [8 x i8]* @.str.6, i64 0, i64 0), double noundef %56), !dbg !334
  br label %58, !dbg !335

58:                                               ; preds = %50
  %59 = load i32, i32* %7, align 4, !dbg !336
  %60 = add nsw i32 %59, 1, !dbg !336
  store i32 %60, i32* %7, align 4, !dbg !336
  br label %39, !dbg !337, !llvm.loop !338

61:                                               ; preds = %39
  %62 = load %struct._IO_FILE*, %struct._IO_FILE** @stderr, align 8, !dbg !340
  %63 = call i32 (%struct._IO_FILE*, i8*, ...) @pb_fprintf(%struct._IO_FILE* noundef %62, i8* noundef getelementptr inbounds ([17 x i8], [17 x i8]* @.str.7, i64 0, i64 0), i8* noundef getelementptr inbounds ([3 x i8], [3 x i8]* @.str.8, i64 0, i64 0)), !dbg !340
  %64 = load %struct._IO_FILE*, %struct._IO_FILE** @stderr, align 8, !dbg !341
  %65 = call i32 (%struct._IO_FILE*, i8*, ...) @pb_fprintf(%struct._IO_FILE* noundef %64, i8* noundef getelementptr inbounds ([23 x i8], [23 x i8]* @.str.9, i64 0, i64 0)), !dbg !341
  ret void, !dbg !342
}

; Function Attrs: noinline nounwind uwtable
define internal i32 @pb_fprintf(%struct._IO_FILE* noundef %0, i8* noundef %1, ...) #0 !dbg !343 {
  %3 = alloca %struct._IO_FILE*, align 8
  %4 = alloca i8*, align 8
  %5 = alloca [768 x i8], align 16
  %6 = alloca [1 x %struct.__va_list_tag], align 16
  %7 = alloca i32, align 4
  %8 = alloca i32, align 4
  store %struct._IO_FILE* %0, %struct._IO_FILE** %3, align 8
  call void @llvm.dbg.declare(metadata %struct._IO_FILE** %3, metadata !407, metadata !DIExpression()), !dbg !408
  store i8* %1, i8** %4, align 8
  call void @llvm.dbg.declare(metadata i8** %4, metadata !409, metadata !DIExpression()), !dbg !410
  call void @llvm.dbg.declare(metadata [768 x i8]* %5, metadata !411, metadata !DIExpression()), !dbg !415
  call void @llvm.dbg.declare(metadata [1 x %struct.__va_list_tag]* %6, metadata !416, metadata !DIExpression()), !dbg !430
  %9 = getelementptr inbounds [1 x %struct.__va_list_tag], [1 x %struct.__va_list_tag]* %6, i64 0, i64 0, !dbg !431
  %10 = bitcast %struct.__va_list_tag* %9 to i8*, !dbg !431
  call void @llvm.va_start(i8* %10), !dbg !431
  call void @llvm.dbg.declare(metadata i32* %7, metadata !432, metadata !DIExpression()), !dbg !433
  %11 = getelementptr inbounds [768 x i8], [768 x i8]* %5, i64 0, i64 0, !dbg !434
  %12 = load i8*, i8** %4, align 8, !dbg !435
  %13 = getelementptr inbounds [1 x %struct.__va_list_tag], [1 x %struct.__va_list_tag]* %6, i64 0, i64 0, !dbg !436
  %14 = call i32 @vsnprintf(i8* noundef %11, i64 noundef 768, i8* noundef %12, %struct.__va_list_tag* noundef %13) #6, !dbg !437
  store i32 %14, i32* %7, align 4, !dbg !433
  %15 = getelementptr inbounds [1 x %struct.__va_list_tag], [1 x %struct.__va_list_tag]* %6, i64 0, i64 0, !dbg !438
  %16 = bitcast %struct.__va_list_tag* %15 to i8*, !dbg !438
  call void @llvm.va_end(i8* %16), !dbg !438
  %17 = load i32, i32* %7, align 4, !dbg !439
  %18 = icmp slt i32 %17, 0, !dbg !441
  br i1 %18, label %23, label %19, !dbg !442

19:                                               ; preds = %2
  %20 = load i32, i32* %7, align 4, !dbg !443
  %21 = zext i32 %20 to i64, !dbg !444
  %22 = icmp uge i64 %21, 768, !dbg !445
  br i1 %22, label %23, label %24, !dbg !446

23:                                               ; preds = %19, %2
  call void @abort() #7, !dbg !447
  unreachable, !dbg !447

24:                                               ; preds = %19
  call void @llvm.dbg.declare(metadata i32* %8, metadata !448, metadata !DIExpression()), !dbg !450
  store i32 0, i32* %8, align 4, !dbg !450
  br label %25, !dbg !451

25:                                               ; preds = %39, %24
  %26 = load i32, i32* %8, align 4, !dbg !452
  %27 = load i32, i32* %7, align 4, !dbg !454
  %28 = icmp slt i32 %26, %27, !dbg !455
  br i1 %28, label %29, label %42, !dbg !456

29:                                               ; preds = %25
  %30 = load i32, i32* %8, align 4, !dbg !457
  %31 = sext i32 %30 to i64, !dbg !459
  %32 = getelementptr inbounds [768 x i8], [768 x i8]* %5, i64 0, i64 %31, !dbg !459
  %33 = load i8, i8* %32, align 1, !dbg !459
  %34 = zext i8 %33 to i32, !dbg !460
  %35 = load i32, i32* @pb_hash, align 4, !dbg !461
  %36 = xor i32 %35, %34, !dbg !461
  store i32 %36, i32* @pb_hash, align 4, !dbg !461
  %37 = load i32, i32* @pb_hash, align 4, !dbg !462
  %38 = mul i32 %37, 16777619, !dbg !462
  store i32 %38, i32* @pb_hash, align 4, !dbg !462
  br label %39, !dbg !463

39:                                               ; preds = %29
  %40 = load i32, i32* %8, align 4, !dbg !464
  %41 = add nsw i32 %40, 1, !dbg !464
  store i32 %41, i32* %8, align 4, !dbg !464
  br label %25, !dbg !465, !llvm.loop !466

42:                                               ; preds = %25
  %43 = load %struct._IO_FILE*, %struct._IO_FILE** %3, align 8, !dbg !468
  %44 = load i32, i32* @pb_emit, align 4, !dbg !469
  %45 = load i32, i32* %7, align 4, !dbg !470
  ret i32 %45, !dbg !471
}

; Function Attrs: nofree nosync nounwind willreturn
declare void @llvm.va_start(i8*) #3

; Function Attrs: nounwind
declare i32 @vsnprintf(i8* noundef, i64 noundef, i8* noundef, %struct.__va_list_tag* noundef) #4

; Function Attrs: nofree nosync nounwind willreturn
declare void @llvm.va_end(i8*) #3

; Function Attrs: noreturn nounwind
declare void @abort() #5

attributes #0 = { noinline nounwind uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { nofree nosync nounwind readnone speculatable willreturn }
attributes #2 = { argmemonly nofree nounwind willreturn writeonly }
attributes #3 = { nofree nosync nounwind willreturn }
attributes #4 = { nounwind "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #5 = { noreturn nounwind "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #6 = { nounwind }
attributes #7 = { noreturn nounwind }

!llvm.dbg.cu = !{!2}
!llvm.module.flags = !{!48, !49, !50, !51, !52, !53, !54}
!llvm.ident = !{!55}

!0 = !DIGlobalVariableExpression(var: !1, expr: !DIExpression())
!1 = distinct !DIGlobalVariable(name: "n", scope: !2, file: !11, line: 114, type: !47, isLocal: false, isDefinition: true)
!2 = distinct !DICompileUnit(language: DW_LANG_C99, file: !3, producer: "Ubuntu clang version 14.0.0-1ubuntu1.1", isOptimized: false, runtimeVersion: 0, emissionKind: FullDebug, retainedTypes: !4, globals: !8, splitDebugInlining: false, nameTableKind: None)
!3 = !DIFile(filename: "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/affine-bounds-20260929/suite/mvt/source/workload.c", directory: "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/affine-bounds-20260929/suite/mvt/analysis-g", checksumkind: CSK_MD5, checksum: "f71e460355e980f9bb96215091b80313")
!4 = !{!5, !6, !7}
!5 = !DIBasicType(name: "double", size: 64, encoding: DW_ATE_float)
!6 = !DIBasicType(name: "unsigned int", size: 32, encoding: DW_ATE_unsigned)
!7 = !DIBasicType(name: "unsigned char", size: 8, encoding: DW_ATE_unsigned_char)
!8 = !{!0, !9, !23, !27, !30, !35, !39, !41, !43, !45}
!9 = !DIGlobalVariableExpression(var: !10, expr: !DIExpression())
!10 = distinct !DIGlobalVariable(name: "workload_jobs", scope: !2, file: !11, line: 145, type: !12, isLocal: false, isDefinition: true)
!11 = !DIFile(filename: "source/workload.c", directory: "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/affine-bounds-20260929/suite/mvt", checksumkind: CSK_MD5, checksum: "f71e460355e980f9bb96215091b80313")
!12 = !DICompositeType(tag: DW_TAG_array_type, baseType: !13, size: 64, elements: !21)
!13 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !14)
!14 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !15, size: 64)
!15 = !DISubroutineType(types: !16)
!16 = !{!17}
!17 = !DIDerivedType(tag: DW_TAG_typedef, name: "uint32_t", file: !18, line: 26, baseType: !19)
!18 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/stdint-uintn.h", directory: "", checksumkind: CSK_MD5, checksum: "2bf2ae53c58c01b1a1b9383b5195125c")
!19 = !DIDerivedType(tag: DW_TAG_typedef, name: "__uint32_t", file: !20, line: 42, baseType: !6)
!20 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/types.h", directory: "", checksumkind: CSK_MD5, checksum: "d108b5f93a74c50510d7d9bc0ab36df9")
!21 = !{!22}
!22 = !DISubrange(count: 1)
!23 = !DIGlobalVariableExpression(var: !24, expr: !DIExpression())
!24 = distinct !DIGlobalVariable(name: "workload_expected", scope: !2, file: !11, line: 149, type: !25, isLocal: false, isDefinition: true)
!25 = !DICompositeType(tag: DW_TAG_array_type, baseType: !26, size: 32, elements: !21)
!26 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !17)
!27 = !DIGlobalVariableExpression(var: !28, expr: !DIExpression())
!28 = distinct !DIGlobalVariable(name: "pb_hash", scope: !2, file: !29, line: 9, type: !17, isLocal: true, isDefinition: true)
!29 = !DIFile(filename: "source/adapter.h", directory: "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/affine-bounds-20260929/suite/mvt", checksumkind: CSK_MD5, checksum: "26a6068928b2092758f244a9d00163d7")
!30 = !DIGlobalVariableExpression(var: !31, expr: !DIExpression())
!31 = distinct !DIGlobalVariable(name: "A", scope: !2, file: !11, line: 34, type: !32, isLocal: false, isDefinition: true, align: 512)
!32 = !DICompositeType(tag: DW_TAG_array_type, baseType: !5, size: 10240000, elements: !33)
!33 = !{!34, !34}
!34 = !DISubrange(count: 400)
!35 = !DIGlobalVariableExpression(var: !36, expr: !DIExpression())
!36 = distinct !DIGlobalVariable(name: "x1", scope: !2, file: !11, line: 35, type: !37, isLocal: false, isDefinition: true, align: 512)
!37 = !DICompositeType(tag: DW_TAG_array_type, baseType: !5, size: 25600, elements: !38)
!38 = !{!34}
!39 = !DIGlobalVariableExpression(var: !40, expr: !DIExpression())
!40 = distinct !DIGlobalVariable(name: "x2", scope: !2, file: !11, line: 36, type: !37, isLocal: false, isDefinition: true, align: 512)
!41 = !DIGlobalVariableExpression(var: !42, expr: !DIExpression())
!42 = distinct !DIGlobalVariable(name: "y_1", scope: !2, file: !11, line: 37, type: !37, isLocal: false, isDefinition: true, align: 512)
!43 = !DIGlobalVariableExpression(var: !44, expr: !DIExpression())
!44 = distinct !DIGlobalVariable(name: "y_2", scope: !2, file: !11, line: 38, type: !37, isLocal: false, isDefinition: true, align: 512)
!45 = !DIGlobalVariableExpression(var: !46, expr: !DIExpression())
!46 = distinct !DIGlobalVariable(name: "pb_emit", scope: !2, file: !29, line: 10, type: !47, isLocal: true, isDefinition: true)
!47 = !DIBasicType(name: "int", size: 32, encoding: DW_ATE_signed)
!48 = !{i32 7, !"Dwarf Version", i32 5}
!49 = !{i32 2, !"Debug Info Version", i32 3}
!50 = !{i32 1, !"wchar_size", i32 4}
!51 = !{i32 7, !"PIC Level", i32 2}
!52 = !{i32 7, !"PIE Level", i32 2}
!53 = !{i32 7, !"uwtable", i32 1}
!54 = !{i32 7, !"frame-pointer", i32 2}
!55 = !{!"Ubuntu clang version 14.0.0-1ubuntu1.1"}
!56 = distinct !DISubprogram(name: "workload_prepare", scope: !11, file: !11, line: 115, type: !57, scopeLine: 115, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !2, retainedNodes: !59)
!57 = !DISubroutineType(types: !58)
!58 = !{null}
!59 = !{}
!60 = !DILocation(line: 115, column: 30, scope: !56)
!61 = distinct !DISubprogram(name: "workload_reset", scope: !11, file: !11, line: 116, type: !62, scopeLine: 116, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !2, retainedNodes: !59)
!62 = !DISubroutineType(types: !63)
!63 = !{null, !6}
!64 = !DILocalVariable(name: "task", arg: 1, scope: !61, file: !11, line: 116, type: !6)
!65 = !DILocation(line: 116, column: 30, scope: !61)
!66 = !DILocation(line: 117, column: 9, scope: !61)
!67 = !DILocation(line: 118, column: 3, scope: !61)
!68 = !DILocation(line: 119, column: 3, scope: !61)
!69 = !DILocation(line: 120, column: 3, scope: !61)
!70 = !DILocation(line: 121, column: 3, scope: !61)
!71 = !DILocation(line: 122, column: 3, scope: !61)
!72 = !DILocation(line: 123, column: 15, scope: !61)
!73 = !DILocation(line: 123, column: 3, scope: !61)
!74 = !DILocation(line: 129, column: 1, scope: !61)
!75 = distinct !DISubprogram(name: "init_array", scope: !11, file: !11, line: 40, type: !76, scopeLine: 46, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition, unit: !2, retainedNodes: !59)
!76 = !DISubroutineType(types: !77)
!77 = !{null, !47, !78, !78, !78, !78, !79}
!78 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !5, size: 64)
!79 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !37, size: 64)
!80 = !DILocalVariable(name: "n", arg: 1, scope: !75, file: !11, line: 40, type: !47)
!81 = !DILocation(line: 40, column: 21, scope: !75)
!82 = !DILocalVariable(name: "x1", arg: 2, scope: !75, file: !11, line: 41, type: !78)
!83 = !DILocation(line: 41, column: 13, scope: !75)
!84 = !DILocalVariable(name: "x2", arg: 3, scope: !75, file: !11, line: 42, type: !78)
!85 = !DILocation(line: 42, column: 13, scope: !75)
!86 = !DILocalVariable(name: "y_1", arg: 4, scope: !75, file: !11, line: 43, type: !78)
!87 = !DILocation(line: 43, column: 13, scope: !75)
!88 = !DILocalVariable(name: "y_2", arg: 5, scope: !75, file: !11, line: 44, type: !78)
!89 = !DILocation(line: 44, column: 13, scope: !75)
!90 = !DILocalVariable(name: "A", arg: 6, scope: !75, file: !11, line: 45, type: !79)
!91 = !DILocation(line: 45, column: 13, scope: !75)
!92 = !DILocalVariable(name: "i", scope: !75, file: !11, line: 47, type: !47)
!93 = !DILocation(line: 47, column: 7, scope: !75)
!94 = !DILocalVariable(name: "j", scope: !75, file: !11, line: 47, type: !47)
!95 = !DILocation(line: 47, column: 10, scope: !75)
!96 = !DILocation(line: 49, column: 10, scope: !97)
!97 = distinct !DILexicalBlock(scope: !75, file: !11, line: 49, column: 3)
!98 = !DILocation(line: 49, column: 8, scope: !97)
!99 = !DILocation(line: 49, column: 15, scope: !100)
!100 = distinct !DILexicalBlock(scope: !97, file: !11, line: 49, column: 3)
!101 = !DILocation(line: 49, column: 19, scope: !100)
!102 = !DILocation(line: 49, column: 17, scope: !100)
!103 = !DILocation(line: 49, column: 3, scope: !97)
!104 = !DILocation(line: 51, column: 28, scope: !105)
!105 = distinct !DILexicalBlock(scope: !100, file: !11, line: 50, column: 5)
!106 = !DILocation(line: 51, column: 32, scope: !105)
!107 = !DILocation(line: 51, column: 30, scope: !105)
!108 = !DILocation(line: 51, column: 15, scope: !105)
!109 = !DILocation(line: 51, column: 37, scope: !105)
!110 = !DILocation(line: 51, column: 35, scope: !105)
!111 = !DILocation(line: 51, column: 7, scope: !105)
!112 = !DILocation(line: 51, column: 10, scope: !105)
!113 = !DILocation(line: 51, column: 13, scope: !105)
!114 = !DILocation(line: 52, column: 29, scope: !105)
!115 = !DILocation(line: 52, column: 31, scope: !105)
!116 = !DILocation(line: 52, column: 38, scope: !105)
!117 = !DILocation(line: 52, column: 36, scope: !105)
!118 = !DILocation(line: 52, column: 15, scope: !105)
!119 = !DILocation(line: 52, column: 43, scope: !105)
!120 = !DILocation(line: 52, column: 41, scope: !105)
!121 = !DILocation(line: 52, column: 7, scope: !105)
!122 = !DILocation(line: 52, column: 10, scope: !105)
!123 = !DILocation(line: 52, column: 13, scope: !105)
!124 = !DILocation(line: 53, column: 30, scope: !105)
!125 = !DILocation(line: 53, column: 32, scope: !105)
!126 = !DILocation(line: 53, column: 39, scope: !105)
!127 = !DILocation(line: 53, column: 37, scope: !105)
!128 = !DILocation(line: 53, column: 16, scope: !105)
!129 = !DILocation(line: 53, column: 44, scope: !105)
!130 = !DILocation(line: 53, column: 42, scope: !105)
!131 = !DILocation(line: 53, column: 7, scope: !105)
!132 = !DILocation(line: 53, column: 11, scope: !105)
!133 = !DILocation(line: 53, column: 14, scope: !105)
!134 = !DILocation(line: 54, column: 30, scope: !105)
!135 = !DILocation(line: 54, column: 32, scope: !105)
!136 = !DILocation(line: 54, column: 39, scope: !105)
!137 = !DILocation(line: 54, column: 37, scope: !105)
!138 = !DILocation(line: 54, column: 16, scope: !105)
!139 = !DILocation(line: 54, column: 44, scope: !105)
!140 = !DILocation(line: 54, column: 42, scope: !105)
!141 = !DILocation(line: 54, column: 7, scope: !105)
!142 = !DILocation(line: 54, column: 11, scope: !105)
!143 = !DILocation(line: 54, column: 14, scope: !105)
!144 = !DILocation(line: 55, column: 14, scope: !145)
!145 = distinct !DILexicalBlock(scope: !105, file: !11, line: 55, column: 7)
!146 = !DILocation(line: 55, column: 12, scope: !145)
!147 = !DILocation(line: 55, column: 19, scope: !148)
!148 = distinct !DILexicalBlock(scope: !145, file: !11, line: 55, column: 7)
!149 = !DILocation(line: 55, column: 23, scope: !148)
!150 = !DILocation(line: 55, column: 21, scope: !148)
!151 = !DILocation(line: 55, column: 7, scope: !145)
!152 = !DILocation(line: 56, column: 25, scope: !148)
!153 = !DILocation(line: 56, column: 27, scope: !148)
!154 = !DILocation(line: 56, column: 26, scope: !148)
!155 = !DILocation(line: 56, column: 31, scope: !148)
!156 = !DILocation(line: 56, column: 29, scope: !148)
!157 = !DILocation(line: 56, column: 12, scope: !148)
!158 = !DILocation(line: 56, column: 36, scope: !148)
!159 = !DILocation(line: 56, column: 34, scope: !148)
!160 = !DILocation(line: 56, column: 2, scope: !148)
!161 = !DILocation(line: 56, column: 4, scope: !148)
!162 = !DILocation(line: 56, column: 7, scope: !148)
!163 = !DILocation(line: 56, column: 10, scope: !148)
!164 = !DILocation(line: 55, column: 27, scope: !148)
!165 = !DILocation(line: 55, column: 7, scope: !148)
!166 = distinct !{!166, !151, !167, !168}
!167 = !DILocation(line: 56, column: 36, scope: !145)
!168 = !{!"llvm.loop.mustprogress"}
!169 = !DILocation(line: 57, column: 5, scope: !105)
!170 = !DILocation(line: 49, column: 23, scope: !100)
!171 = !DILocation(line: 49, column: 3, scope: !100)
!172 = distinct !{!172, !103, !173, !168}
!173 = !DILocation(line: 57, column: 5, scope: !97)
!174 = !DILocation(line: 58, column: 1, scope: !75)
!175 = distinct !DISubprogram(name: "task_job_polybench", scope: !11, file: !11, line: 130, type: !15, scopeLine: 130, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !2, retainedNodes: !59)
!176 = !DILocation(line: 131, column: 15, scope: !175)
!177 = !DILocalVariable(name: "n", arg: 1, scope: !178, file: !11, line: 92, type: !47)
!178 = distinct !DISubprogram(name: "kernel_mvt", scope: !11, file: !11, line: 92, type: !76, scopeLine: 98, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition, unit: !2, retainedNodes: !59)
!179 = !DILocation(line: 92, column: 59, scope: !178, inlinedAt: !180)
!180 = distinct !DILocation(line: 131, column: 3, scope: !175)
!181 = !DILocalVariable(name: "x1", arg: 2, scope: !178, file: !11, line: 93, type: !78)
!182 = !DILocation(line: 93, column: 13, scope: !178, inlinedAt: !180)
!183 = !DILocalVariable(name: "x2", arg: 3, scope: !178, file: !11, line: 94, type: !78)
!184 = !DILocation(line: 94, column: 13, scope: !178, inlinedAt: !180)
!185 = !DILocalVariable(name: "y_1", arg: 4, scope: !178, file: !11, line: 95, type: !78)
!186 = !DILocation(line: 95, column: 13, scope: !178, inlinedAt: !180)
!187 = !DILocalVariable(name: "y_2", arg: 5, scope: !178, file: !11, line: 96, type: !78)
!188 = !DILocation(line: 96, column: 13, scope: !178, inlinedAt: !180)
!189 = !DILocalVariable(name: "A", arg: 6, scope: !178, file: !11, line: 97, type: !79)
!190 = !DILocation(line: 97, column: 13, scope: !178, inlinedAt: !180)
!191 = !DILocalVariable(name: "i", scope: !178, file: !11, line: 99, type: !47)
!192 = !DILocation(line: 99, column: 7, scope: !178, inlinedAt: !180)
!193 = !DILocalVariable(name: "j", scope: !178, file: !11, line: 99, type: !47)
!194 = !DILocation(line: 99, column: 10, scope: !178, inlinedAt: !180)
!195 = !DILocation(line: 102, column: 10, scope: !196, inlinedAt: !180)
!196 = distinct !DILexicalBlock(scope: !178, file: !11, line: 102, column: 3)
!197 = !DILocation(line: 102, column: 8, scope: !196, inlinedAt: !180)
!198 = !DILocation(line: 102, column: 15, scope: !199, inlinedAt: !180)
!199 = distinct !DILexicalBlock(scope: !196, file: !11, line: 102, column: 3)
!200 = !DILocation(line: 102, column: 17, scope: !199, inlinedAt: !180)
!201 = !DILocation(line: 102, column: 3, scope: !196, inlinedAt: !180)
!202 = !DILocation(line: 103, column: 12, scope: !203, inlinedAt: !180)
!203 = distinct !DILexicalBlock(scope: !199, file: !11, line: 103, column: 5)
!204 = !DILocation(line: 103, column: 10, scope: !203, inlinedAt: !180)
!205 = !DILocation(line: 103, column: 17, scope: !206, inlinedAt: !180)
!206 = distinct !DILexicalBlock(scope: !203, file: !11, line: 103, column: 5)
!207 = !DILocation(line: 103, column: 19, scope: !206, inlinedAt: !180)
!208 = !DILocation(line: 103, column: 5, scope: !203, inlinedAt: !180)
!209 = !DILocation(line: 104, column: 15, scope: !206, inlinedAt: !180)
!210 = !DILocation(line: 104, column: 18, scope: !206, inlinedAt: !180)
!211 = !DILocation(line: 104, column: 23, scope: !206, inlinedAt: !180)
!212 = !DILocation(line: 104, column: 25, scope: !206, inlinedAt: !180)
!213 = !DILocation(line: 104, column: 28, scope: !206, inlinedAt: !180)
!214 = !DILocation(line: 104, column: 33, scope: !206, inlinedAt: !180)
!215 = !DILocation(line: 104, column: 37, scope: !206, inlinedAt: !180)
!216 = !DILocation(line: 104, column: 31, scope: !206, inlinedAt: !180)
!217 = !DILocation(line: 104, column: 21, scope: !206, inlinedAt: !180)
!218 = !DILocation(line: 104, column: 7, scope: !206, inlinedAt: !180)
!219 = !DILocation(line: 104, column: 10, scope: !206, inlinedAt: !180)
!220 = !DILocation(line: 104, column: 13, scope: !206, inlinedAt: !180)
!221 = !DILocation(line: 103, column: 29, scope: !206, inlinedAt: !180)
!222 = !DILocation(line: 103, column: 5, scope: !206, inlinedAt: !180)
!223 = distinct !{!223, !208, !224, !168}
!224 = !DILocation(line: 104, column: 38, scope: !203, inlinedAt: !180)
!225 = !DILocation(line: 102, column: 27, scope: !199, inlinedAt: !180)
!226 = !DILocation(line: 102, column: 3, scope: !199, inlinedAt: !180)
!227 = distinct !{!227, !201, !228, !168}
!228 = !DILocation(line: 104, column: 38, scope: !196, inlinedAt: !180)
!229 = !DILocation(line: 105, column: 10, scope: !230, inlinedAt: !180)
!230 = distinct !DILexicalBlock(scope: !178, file: !11, line: 105, column: 3)
!231 = !DILocation(line: 105, column: 8, scope: !230, inlinedAt: !180)
!232 = !DILocation(line: 105, column: 15, scope: !233, inlinedAt: !180)
!233 = distinct !DILexicalBlock(scope: !230, file: !11, line: 105, column: 3)
!234 = !DILocation(line: 105, column: 17, scope: !233, inlinedAt: !180)
!235 = !DILocation(line: 105, column: 3, scope: !230, inlinedAt: !180)
!236 = !DILocation(line: 106, column: 12, scope: !237, inlinedAt: !180)
!237 = distinct !DILexicalBlock(scope: !233, file: !11, line: 106, column: 5)
!238 = !DILocation(line: 106, column: 10, scope: !237, inlinedAt: !180)
!239 = !DILocation(line: 106, column: 17, scope: !240, inlinedAt: !180)
!240 = distinct !DILexicalBlock(scope: !237, file: !11, line: 106, column: 5)
!241 = !DILocation(line: 106, column: 19, scope: !240, inlinedAt: !180)
!242 = !DILocation(line: 106, column: 5, scope: !237, inlinedAt: !180)
!243 = !DILocation(line: 107, column: 15, scope: !240, inlinedAt: !180)
!244 = !DILocation(line: 107, column: 18, scope: !240, inlinedAt: !180)
!245 = !DILocation(line: 107, column: 23, scope: !240, inlinedAt: !180)
!246 = !DILocation(line: 107, column: 25, scope: !240, inlinedAt: !180)
!247 = !DILocation(line: 107, column: 28, scope: !240, inlinedAt: !180)
!248 = !DILocation(line: 107, column: 33, scope: !240, inlinedAt: !180)
!249 = !DILocation(line: 107, column: 37, scope: !240, inlinedAt: !180)
!250 = !DILocation(line: 107, column: 31, scope: !240, inlinedAt: !180)
!251 = !DILocation(line: 107, column: 21, scope: !240, inlinedAt: !180)
!252 = !DILocation(line: 107, column: 7, scope: !240, inlinedAt: !180)
!253 = !DILocation(line: 107, column: 10, scope: !240, inlinedAt: !180)
!254 = !DILocation(line: 107, column: 13, scope: !240, inlinedAt: !180)
!255 = !DILocation(line: 106, column: 29, scope: !240, inlinedAt: !180)
!256 = !DILocation(line: 106, column: 5, scope: !240, inlinedAt: !180)
!257 = distinct !{!257, !242, !258, !168}
!258 = !DILocation(line: 107, column: 38, scope: !237, inlinedAt: !180)
!259 = !DILocation(line: 105, column: 27, scope: !233, inlinedAt: !180)
!260 = !DILocation(line: 105, column: 3, scope: !233, inlinedAt: !180)
!261 = distinct !{!261, !235, !262, !168}
!262 = !DILocation(line: 107, column: 38, scope: !230, inlinedAt: !180)
!263 = !DILocation(line: 137, column: 3, scope: !175)
!264 = distinct !DISubprogram(name: "workload_checksum", scope: !11, file: !11, line: 139, type: !265, scopeLine: 139, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !2, retainedNodes: !59)
!265 = !DISubroutineType(types: !266)
!266 = !{!17, !6}
!267 = !DILocalVariable(name: "task", arg: 1, scope: !264, file: !11, line: 139, type: !6)
!268 = !DILocation(line: 139, column: 37, scope: !264)
!269 = !DILocation(line: 140, column: 9, scope: !264)
!270 = !DILocation(line: 141, column: 11, scope: !264)
!271 = !DILocation(line: 142, column: 15, scope: !264)
!272 = !DILocation(line: 142, column: 3, scope: !264)
!273 = !DILocation(line: 143, column: 10, scope: !264)
!274 = !DILocation(line: 143, column: 3, scope: !264)
!275 = distinct !DISubprogram(name: "print_array", scope: !11, file: !11, line: 64, type: !276, scopeLine: 68, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition, unit: !2, retainedNodes: !59)
!276 = !DISubroutineType(types: !277)
!277 = !{null, !47, !78, !78}
!278 = !DILocalVariable(name: "n", arg: 1, scope: !275, file: !11, line: 64, type: !47)
!279 = !DILocation(line: 64, column: 22, scope: !275)
!280 = !DILocalVariable(name: "x1", arg: 2, scope: !275, file: !11, line: 65, type: !78)
!281 = !DILocation(line: 65, column: 14, scope: !275)
!282 = !DILocalVariable(name: "x2", arg: 3, scope: !275, file: !11, line: 66, type: !78)
!283 = !DILocation(line: 66, column: 14, scope: !275)
!284 = !DILocalVariable(name: "i", scope: !275, file: !11, line: 69, type: !47)
!285 = !DILocation(line: 69, column: 7, scope: !275)
!286 = !DILocation(line: 71, column: 3, scope: !275)
!287 = !DILocation(line: 72, column: 3, scope: !275)
!288 = !DILocation(line: 73, column: 10, scope: !289)
!289 = distinct !DILexicalBlock(scope: !275, file: !11, line: 73, column: 3)
!290 = !DILocation(line: 73, column: 8, scope: !289)
!291 = !DILocation(line: 73, column: 15, scope: !292)
!292 = distinct !DILexicalBlock(scope: !289, file: !11, line: 73, column: 3)
!293 = !DILocation(line: 73, column: 19, scope: !292)
!294 = !DILocation(line: 73, column: 17, scope: !292)
!295 = !DILocation(line: 73, column: 3, scope: !289)
!296 = !DILocation(line: 74, column: 9, scope: !297)
!297 = distinct !DILexicalBlock(scope: !298, file: !11, line: 74, column: 9)
!298 = distinct !DILexicalBlock(scope: !292, file: !11, line: 73, column: 27)
!299 = !DILocation(line: 74, column: 11, scope: !297)
!300 = !DILocation(line: 74, column: 16, scope: !297)
!301 = !DILocation(line: 74, column: 9, scope: !298)
!302 = !DILocation(line: 74, column: 31, scope: !297)
!303 = !DILocation(line: 74, column: 22, scope: !297)
!304 = !DILocation(line: 75, column: 14, scope: !298)
!305 = !DILocation(line: 75, column: 59, scope: !298)
!306 = !DILocation(line: 75, column: 62, scope: !298)
!307 = !DILocation(line: 75, column: 5, scope: !298)
!308 = !DILocation(line: 76, column: 3, scope: !298)
!309 = !DILocation(line: 73, column: 23, scope: !292)
!310 = !DILocation(line: 73, column: 3, scope: !292)
!311 = distinct !{!311, !295, !312, !168}
!312 = !DILocation(line: 76, column: 3, scope: !289)
!313 = !DILocation(line: 77, column: 3, scope: !275)
!314 = !DILocation(line: 79, column: 3, scope: !275)
!315 = !DILocation(line: 80, column: 10, scope: !316)
!316 = distinct !DILexicalBlock(scope: !275, file: !11, line: 80, column: 3)
!317 = !DILocation(line: 80, column: 8, scope: !316)
!318 = !DILocation(line: 80, column: 15, scope: !319)
!319 = distinct !DILexicalBlock(scope: !316, file: !11, line: 80, column: 3)
!320 = !DILocation(line: 80, column: 19, scope: !319)
!321 = !DILocation(line: 80, column: 17, scope: !319)
!322 = !DILocation(line: 80, column: 3, scope: !316)
!323 = !DILocation(line: 81, column: 9, scope: !324)
!324 = distinct !DILexicalBlock(scope: !325, file: !11, line: 81, column: 9)
!325 = distinct !DILexicalBlock(scope: !319, file: !11, line: 80, column: 27)
!326 = !DILocation(line: 81, column: 11, scope: !324)
!327 = !DILocation(line: 81, column: 16, scope: !324)
!328 = !DILocation(line: 81, column: 9, scope: !325)
!329 = !DILocation(line: 81, column: 31, scope: !324)
!330 = !DILocation(line: 81, column: 22, scope: !324)
!331 = !DILocation(line: 82, column: 14, scope: !325)
!332 = !DILocation(line: 82, column: 59, scope: !325)
!333 = !DILocation(line: 82, column: 62, scope: !325)
!334 = !DILocation(line: 82, column: 5, scope: !325)
!335 = !DILocation(line: 83, column: 3, scope: !325)
!336 = !DILocation(line: 80, column: 23, scope: !319)
!337 = !DILocation(line: 80, column: 3, scope: !319)
!338 = distinct !{!338, !322, !339, !168}
!339 = !DILocation(line: 83, column: 3, scope: !316)
!340 = !DILocation(line: 84, column: 3, scope: !275)
!341 = !DILocation(line: 85, column: 3, scope: !275)
!342 = !DILocation(line: 86, column: 1, scope: !275)
!343 = distinct !DISubprogram(name: "pb_fprintf", scope: !29, file: !29, line: 13, type: !344, scopeLine: 14, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition, unit: !2, retainedNodes: !59)
!344 = !DISubroutineType(types: !345)
!345 = !{!47, !346, !405, null}
!346 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !347, size: 64)
!347 = !DIDerivedType(tag: DW_TAG_typedef, name: "FILE", file: !348, line: 7, baseType: !349)
!348 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/types/FILE.h", directory: "", checksumkind: CSK_MD5, checksum: "571f9fb6223c42439075fdde11a0de5d")
!349 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "_IO_FILE", file: !350, line: 49, size: 1728, elements: !351)
!350 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/types/struct_FILE.h", directory: "", checksumkind: CSK_MD5, checksum: "1bad07471b7974df4ecc1d1c2ca207e6")
!351 = !{!352, !353, !356, !357, !358, !359, !360, !361, !362, !363, !364, !365, !366, !369, !371, !372, !373, !376, !378, !380, !382, !385, !387, !390, !393, !394, !396, !400, !401}
!352 = !DIDerivedType(tag: DW_TAG_member, name: "_flags", scope: !349, file: !350, line: 51, baseType: !47, size: 32)
!353 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_read_ptr", scope: !349, file: !350, line: 54, baseType: !354, size: 64, offset: 64)
!354 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !355, size: 64)
!355 = !DIBasicType(name: "char", size: 8, encoding: DW_ATE_signed_char)
!356 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_read_end", scope: !349, file: !350, line: 55, baseType: !354, size: 64, offset: 128)
!357 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_read_base", scope: !349, file: !350, line: 56, baseType: !354, size: 64, offset: 192)
!358 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_write_base", scope: !349, file: !350, line: 57, baseType: !354, size: 64, offset: 256)
!359 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_write_ptr", scope: !349, file: !350, line: 58, baseType: !354, size: 64, offset: 320)
!360 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_write_end", scope: !349, file: !350, line: 59, baseType: !354, size: 64, offset: 384)
!361 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_buf_base", scope: !349, file: !350, line: 60, baseType: !354, size: 64, offset: 448)
!362 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_buf_end", scope: !349, file: !350, line: 61, baseType: !354, size: 64, offset: 512)
!363 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_save_base", scope: !349, file: !350, line: 64, baseType: !354, size: 64, offset: 576)
!364 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_backup_base", scope: !349, file: !350, line: 65, baseType: !354, size: 64, offset: 640)
!365 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_save_end", scope: !349, file: !350, line: 66, baseType: !354, size: 64, offset: 704)
!366 = !DIDerivedType(tag: DW_TAG_member, name: "_markers", scope: !349, file: !350, line: 68, baseType: !367, size: 64, offset: 768)
!367 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !368, size: 64)
!368 = !DICompositeType(tag: DW_TAG_structure_type, name: "_IO_marker", file: !350, line: 36, flags: DIFlagFwdDecl)
!369 = !DIDerivedType(tag: DW_TAG_member, name: "_chain", scope: !349, file: !350, line: 70, baseType: !370, size: 64, offset: 832)
!370 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !349, size: 64)
!371 = !DIDerivedType(tag: DW_TAG_member, name: "_fileno", scope: !349, file: !350, line: 72, baseType: !47, size: 32, offset: 896)
!372 = !DIDerivedType(tag: DW_TAG_member, name: "_flags2", scope: !349, file: !350, line: 73, baseType: !47, size: 32, offset: 928)
!373 = !DIDerivedType(tag: DW_TAG_member, name: "_old_offset", scope: !349, file: !350, line: 74, baseType: !374, size: 64, offset: 960)
!374 = !DIDerivedType(tag: DW_TAG_typedef, name: "__off_t", file: !20, line: 152, baseType: !375)
!375 = !DIBasicType(name: "long", size: 64, encoding: DW_ATE_signed)
!376 = !DIDerivedType(tag: DW_TAG_member, name: "_cur_column", scope: !349, file: !350, line: 77, baseType: !377, size: 16, offset: 1024)
!377 = !DIBasicType(name: "unsigned short", size: 16, encoding: DW_ATE_unsigned)
!378 = !DIDerivedType(tag: DW_TAG_member, name: "_vtable_offset", scope: !349, file: !350, line: 78, baseType: !379, size: 8, offset: 1040)
!379 = !DIBasicType(name: "signed char", size: 8, encoding: DW_ATE_signed_char)
!380 = !DIDerivedType(tag: DW_TAG_member, name: "_shortbuf", scope: !349, file: !350, line: 79, baseType: !381, size: 8, offset: 1048)
!381 = !DICompositeType(tag: DW_TAG_array_type, baseType: !355, size: 8, elements: !21)
!382 = !DIDerivedType(tag: DW_TAG_member, name: "_lock", scope: !349, file: !350, line: 81, baseType: !383, size: 64, offset: 1088)
!383 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !384, size: 64)
!384 = !DIDerivedType(tag: DW_TAG_typedef, name: "_IO_lock_t", file: !350, line: 43, baseType: null)
!385 = !DIDerivedType(tag: DW_TAG_member, name: "_offset", scope: !349, file: !350, line: 89, baseType: !386, size: 64, offset: 1152)
!386 = !DIDerivedType(tag: DW_TAG_typedef, name: "__off64_t", file: !20, line: 153, baseType: !375)
!387 = !DIDerivedType(tag: DW_TAG_member, name: "_codecvt", scope: !349, file: !350, line: 91, baseType: !388, size: 64, offset: 1216)
!388 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !389, size: 64)
!389 = !DICompositeType(tag: DW_TAG_structure_type, name: "_IO_codecvt", file: !350, line: 37, flags: DIFlagFwdDecl)
!390 = !DIDerivedType(tag: DW_TAG_member, name: "_wide_data", scope: !349, file: !350, line: 92, baseType: !391, size: 64, offset: 1280)
!391 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !392, size: 64)
!392 = !DICompositeType(tag: DW_TAG_structure_type, name: "_IO_wide_data", file: !350, line: 38, flags: DIFlagFwdDecl)
!393 = !DIDerivedType(tag: DW_TAG_member, name: "_freeres_list", scope: !349, file: !350, line: 93, baseType: !370, size: 64, offset: 1344)
!394 = !DIDerivedType(tag: DW_TAG_member, name: "_freeres_buf", scope: !349, file: !350, line: 94, baseType: !395, size: 64, offset: 1408)
!395 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: null, size: 64)
!396 = !DIDerivedType(tag: DW_TAG_member, name: "__pad5", scope: !349, file: !350, line: 95, baseType: !397, size: 64, offset: 1472)
!397 = !DIDerivedType(tag: DW_TAG_typedef, name: "size_t", file: !398, line: 46, baseType: !399)
!398 = !DIFile(filename: "/usr/lib/llvm-14/lib/clang/14.0.0/include/stddef.h", directory: "", checksumkind: CSK_MD5, checksum: "2499dd2361b915724b073282bea3a7bc")
!399 = !DIBasicType(name: "unsigned long", size: 64, encoding: DW_ATE_unsigned)
!400 = !DIDerivedType(tag: DW_TAG_member, name: "_mode", scope: !349, file: !350, line: 96, baseType: !47, size: 32, offset: 1536)
!401 = !DIDerivedType(tag: DW_TAG_member, name: "_unused2", scope: !349, file: !350, line: 98, baseType: !402, size: 160, offset: 1568)
!402 = !DICompositeType(tag: DW_TAG_array_type, baseType: !355, size: 160, elements: !403)
!403 = !{!404}
!404 = !DISubrange(count: 20)
!405 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !406, size: 64)
!406 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !355)
!407 = !DILocalVariable(name: "stream", arg: 1, scope: !343, file: !29, line: 13, type: !346)
!408 = !DILocation(line: 13, column: 29, scope: !343)
!409 = !DILocalVariable(name: "format", arg: 2, scope: !343, file: !29, line: 13, type: !405)
!410 = !DILocation(line: 13, column: 49, scope: !343)
!411 = !DILocalVariable(name: "buffer", scope: !343, file: !29, line: 15, type: !412)
!412 = !DICompositeType(tag: DW_TAG_array_type, baseType: !355, size: 6144, elements: !413)
!413 = !{!414}
!414 = !DISubrange(count: 768)
!415 = !DILocation(line: 15, column: 10, scope: !343)
!416 = !DILocalVariable(name: "args", scope: !343, file: !29, line: 16, type: !417)
!417 = !DIDerivedType(tag: DW_TAG_typedef, name: "va_list", file: !418, line: 52, baseType: !419)
!418 = !DIFile(filename: "/usr/include/stdio.h", directory: "", checksumkind: CSK_MD5, checksum: "f31eefcc3f15835fc5a4023a625cf609")
!419 = !DIDerivedType(tag: DW_TAG_typedef, name: "__gnuc_va_list", file: !420, line: 32, baseType: !421)
!420 = !DIFile(filename: "/usr/lib/llvm-14/lib/clang/14.0.0/include/stdarg.h", directory: "", checksumkind: CSK_MD5, checksum: "4de3cbd931b589d291e5c39387aecf82")
!421 = !DIDerivedType(tag: DW_TAG_typedef, name: "__builtin_va_list", file: !422, baseType: !423)
!422 = !DIFile(filename: "source/workload.c", directory: "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/affine-bounds-20260929/suite/mvt")
!423 = !DICompositeType(tag: DW_TAG_array_type, baseType: !424, size: 192, elements: !21)
!424 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "__va_list_tag", size: 192, elements: !425)
!425 = !{!426, !427, !428, !429}
!426 = !DIDerivedType(tag: DW_TAG_member, name: "gp_offset", scope: !424, file: !422, line: 16, baseType: !6, size: 32)
!427 = !DIDerivedType(tag: DW_TAG_member, name: "fp_offset", scope: !424, file: !422, line: 16, baseType: !6, size: 32, offset: 32)
!428 = !DIDerivedType(tag: DW_TAG_member, name: "overflow_arg_area", scope: !424, file: !422, line: 16, baseType: !395, size: 64, offset: 64)
!429 = !DIDerivedType(tag: DW_TAG_member, name: "reg_save_area", scope: !424, file: !422, line: 16, baseType: !395, size: 64, offset: 128)
!430 = !DILocation(line: 16, column: 13, scope: !343)
!431 = !DILocation(line: 17, column: 5, scope: !343)
!432 = !DILocalVariable(name: "count", scope: !343, file: !29, line: 18, type: !47)
!433 = !DILocation(line: 18, column: 9, scope: !343)
!434 = !DILocation(line: 18, column: 27, scope: !343)
!435 = !DILocation(line: 18, column: 51, scope: !343)
!436 = !DILocation(line: 18, column: 59, scope: !343)
!437 = !DILocation(line: 18, column: 17, scope: !343)
!438 = !DILocation(line: 19, column: 5, scope: !343)
!439 = !DILocation(line: 20, column: 9, scope: !440)
!440 = distinct !DILexicalBlock(scope: !343, file: !29, line: 20, column: 9)
!441 = !DILocation(line: 20, column: 15, scope: !440)
!442 = !DILocation(line: 20, column: 19, scope: !440)
!443 = !DILocation(line: 20, column: 32, scope: !440)
!444 = !DILocation(line: 20, column: 22, scope: !440)
!445 = !DILocation(line: 20, column: 38, scope: !440)
!446 = !DILocation(line: 20, column: 9, scope: !343)
!447 = !DILocation(line: 20, column: 57, scope: !440)
!448 = !DILocalVariable(name: "i", scope: !449, file: !29, line: 21, type: !47)
!449 = distinct !DILexicalBlock(scope: !343, file: !29, line: 21, column: 5)
!450 = !DILocation(line: 21, column: 14, scope: !449)
!451 = !DILocation(line: 21, column: 10, scope: !449)
!452 = !DILocation(line: 21, column: 21, scope: !453)
!453 = distinct !DILexicalBlock(scope: !449, file: !29, line: 21, column: 5)
!454 = !DILocation(line: 21, column: 25, scope: !453)
!455 = !DILocation(line: 21, column: 23, scope: !453)
!456 = !DILocation(line: 21, column: 5, scope: !449)
!457 = !DILocation(line: 22, column: 42, scope: !458)
!458 = distinct !DILexicalBlock(scope: !453, file: !29, line: 21, column: 37)
!459 = !DILocation(line: 22, column: 35, scope: !458)
!460 = !DILocation(line: 22, column: 20, scope: !458)
!461 = !DILocation(line: 22, column: 17, scope: !458)
!462 = !DILocation(line: 23, column: 17, scope: !458)
!463 = !DILocation(line: 24, column: 5, scope: !458)
!464 = !DILocation(line: 21, column: 32, scope: !453)
!465 = !DILocation(line: 21, column: 5, scope: !453)
!466 = distinct !{!466, !456, !467, !168}
!467 = !DILocation(line: 24, column: 5, scope: !449)
!468 = !DILocation(line: 28, column: 11, scope: !343)
!469 = !DILocation(line: 29, column: 11, scope: !343)
!470 = !DILocation(line: 31, column: 12, scope: !343)
!471 = !DILocation(line: 31, column: 5, scope: !343)
