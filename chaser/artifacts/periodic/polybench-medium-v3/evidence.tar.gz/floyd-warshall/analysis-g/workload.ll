; ModuleID = '/workspace/experiments-array-support/chaser/.cache/periodic-polybench/affine-bounds-20260929/suite/floyd-warshall/source/workload.c'
source_filename = "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/affine-bounds-20260929/suite/floyd-warshall/source/workload.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

%struct._IO_FILE = type { i32, i8*, i8*, i8*, i8*, i8*, i8*, i8*, i8*, i8*, i8*, i8*, %struct._IO_marker*, %struct._IO_FILE*, i32, i32, i64, i16, i8, [1 x i8], i8*, i64, %struct._IO_codecvt*, %struct._IO_wide_data*, %struct._IO_FILE*, i8*, i64, i32, [20 x i8] }
%struct._IO_marker = type opaque
%struct._IO_codecvt = type opaque
%struct._IO_wide_data = type opaque
%struct.__va_list_tag = type { i32, i32, i8*, i8* }

@n = dso_local global i32 500, align 4, !dbg !0
@path = dso_local global [500 x [500 x i32]] zeroinitializer, section ".chaser_data.path", align 64, !dbg !29
@.str = private unnamed_addr constant [12 x i8] c"ape.analyze\00", section "llvm.metadata"
@.str.1 = private unnamed_addr constant [132 x i8] c"/workspace/experiments-array-support/chaser/.cache/periodic-polybench/affine-bounds-20260929/suite/floyd-warshall/source/workload.c\00", section "llvm.metadata"
@pb_hash = internal global i32 0, align 4, !dbg !26
@workload_jobs = dso_local constant [1 x i32 ()*] [i32 ()* @task_job_polybench], align 8, !dbg !8
@workload_expected = dso_local constant [1 x i32] [i32 -161771851], align 4, !dbg !22
@stderr = external global %struct._IO_FILE*, align 8
@.str.2 = private unnamed_addr constant [23 x i8] c"==BEGIN DUMP_ARRAYS==\0A\00", align 1
@.str.3 = private unnamed_addr constant [15 x i8] c"begin dump: %s\00", align 1
@.str.4 = private unnamed_addr constant [5 x i8] c"path\00", align 1
@.str.5 = private unnamed_addr constant [2 x i8] c"\0A\00", align 1
@.str.6 = private unnamed_addr constant [4 x i8] c"%d \00", align 1
@.str.7 = private unnamed_addr constant [17 x i8] c"\0Aend   dump: %s\0A\00", align 1
@.str.8 = private unnamed_addr constant [23 x i8] c"==END   DUMP_ARRAYS==\0A\00", align 1
@pb_emit = internal global i32 1, align 4, !dbg !35
@llvm.global.annotations = appending global [1 x { i8*, i8*, i8*, i32, i8* }] [{ i8*, i8*, i8*, i32, i8* } { i8* bitcast (i32 ()* @task_job_polybench to i8*), i8* getelementptr inbounds ([12 x i8], [12 x i8]* @.str, i32 0, i32 0), i8* getelementptr inbounds ([132 x i8], [132 x i8]* @.str.1, i32 0, i32 0), i32 100, i8* null }], section "llvm.metadata"

; Function Attrs: noinline nounwind uwtable
define dso_local void @workload_prepare() #0 !dbg !45 {
  ret void, !dbg !49
}

; Function Attrs: noinline nounwind uwtable
define dso_local void @workload_reset(i32 noundef %0) #0 !dbg !50 {
  %2 = alloca i32, align 4
  store i32 %0, i32* %2, align 4
  call void @llvm.dbg.declare(metadata i32* %2, metadata !53, metadata !DIExpression()), !dbg !54
  %3 = load i32, i32* %2, align 4, !dbg !55
  call void @llvm.memset.p0i8.i64(i8* align 64 bitcast ([500 x [500 x i32]]* @path to i8*), i8 0, i64 1000000, i1 false), !dbg !56
  %4 = load i32, i32* @n, align 4, !dbg !57
  call void @init_array(i32 noundef %4, [500 x i32]* noundef getelementptr inbounds ([500 x [500 x i32]], [500 x [500 x i32]]* @path, i64 0, i64 0)), !dbg !58
  ret void, !dbg !59
}

; Function Attrs: nofree nosync nounwind readnone speculatable willreturn
declare void @llvm.dbg.declare(metadata, metadata, metadata) #1

; Function Attrs: argmemonly nofree nounwind willreturn writeonly
declare void @llvm.memset.p0i8.i64(i8* nocapture writeonly, i8, i64, i1 immarg) #2

; Function Attrs: noinline nounwind uwtable
define internal void @init_array(i32 noundef %0, [500 x i32]* noundef %1) #0 !dbg !60 {
  %3 = alloca i32, align 4
  %4 = alloca [500 x i32]*, align 8
  %5 = alloca i32, align 4
  %6 = alloca i32, align 4
  store i32 %0, i32* %3, align 4
  call void @llvm.dbg.declare(metadata i32* %3, metadata !66, metadata !DIExpression()), !dbg !67
  store [500 x i32]* %1, [500 x i32]** %4, align 8
  call void @llvm.dbg.declare(metadata [500 x i32]** %4, metadata !68, metadata !DIExpression()), !dbg !69
  call void @llvm.dbg.declare(metadata i32* %5, metadata !70, metadata !DIExpression()), !dbg !71
  call void @llvm.dbg.declare(metadata i32* %6, metadata !72, metadata !DIExpression()), !dbg !73
  store i32 0, i32* %5, align 4, !dbg !74
  br label %7, !dbg !76

7:                                                ; preds = %59, %2
  %8 = load i32, i32* %5, align 4, !dbg !77
  %9 = load i32, i32* %3, align 4, !dbg !79
  %10 = icmp slt i32 %8, %9, !dbg !80
  br i1 %10, label %11, label %62, !dbg !81

11:                                               ; preds = %7
  store i32 0, i32* %6, align 4, !dbg !82
  br label %12, !dbg !84

12:                                               ; preds = %55, %11
  %13 = load i32, i32* %6, align 4, !dbg !85
  %14 = load i32, i32* %3, align 4, !dbg !87
  %15 = icmp slt i32 %13, %14, !dbg !88
  br i1 %15, label %16, label %58, !dbg !89

16:                                               ; preds = %12
  %17 = load i32, i32* %5, align 4, !dbg !90
  %18 = load i32, i32* %6, align 4, !dbg !92
  %19 = mul nsw i32 %17, %18, !dbg !93
  %20 = srem i32 %19, 7, !dbg !94
  %21 = add nsw i32 %20, 1, !dbg !95
  %22 = load [500 x i32]*, [500 x i32]** %4, align 8, !dbg !96
  %23 = load i32, i32* %5, align 4, !dbg !97
  %24 = sext i32 %23 to i64, !dbg !96
  %25 = getelementptr inbounds [500 x i32], [500 x i32]* %22, i64 %24, !dbg !96
  %26 = load i32, i32* %6, align 4, !dbg !98
  %27 = sext i32 %26 to i64, !dbg !96
  %28 = getelementptr inbounds [500 x i32], [500 x i32]* %25, i64 0, i64 %27, !dbg !96
  store i32 %21, i32* %28, align 4, !dbg !99
  %29 = load i32, i32* %5, align 4, !dbg !100
  %30 = load i32, i32* %6, align 4, !dbg !102
  %31 = add nsw i32 %29, %30, !dbg !103
  %32 = srem i32 %31, 13, !dbg !104
  %33 = icmp eq i32 %32, 0, !dbg !105
  br i1 %33, label %46, label %34, !dbg !106

34:                                               ; preds = %16
  %35 = load i32, i32* %5, align 4, !dbg !107
  %36 = load i32, i32* %6, align 4, !dbg !108
  %37 = add nsw i32 %35, %36, !dbg !109
  %38 = srem i32 %37, 7, !dbg !110
  %39 = icmp eq i32 %38, 0, !dbg !111
  br i1 %39, label %46, label %40, !dbg !112

40:                                               ; preds = %34
  %41 = load i32, i32* %5, align 4, !dbg !113
  %42 = load i32, i32* %6, align 4, !dbg !114
  %43 = add nsw i32 %41, %42, !dbg !115
  %44 = srem i32 %43, 11, !dbg !116
  %45 = icmp eq i32 %44, 0, !dbg !117
  br i1 %45, label %46, label %54, !dbg !118

46:                                               ; preds = %40, %34, %16
  %47 = load [500 x i32]*, [500 x i32]** %4, align 8, !dbg !119
  %48 = load i32, i32* %5, align 4, !dbg !120
  %49 = sext i32 %48 to i64, !dbg !119
  %50 = getelementptr inbounds [500 x i32], [500 x i32]* %47, i64 %49, !dbg !119
  %51 = load i32, i32* %6, align 4, !dbg !121
  %52 = sext i32 %51 to i64, !dbg !119
  %53 = getelementptr inbounds [500 x i32], [500 x i32]* %50, i64 0, i64 %52, !dbg !119
  store i32 999, i32* %53, align 4, !dbg !122
  br label %54, !dbg !119

54:                                               ; preds = %46, %40
  br label %55, !dbg !123

55:                                               ; preds = %54
  %56 = load i32, i32* %6, align 4, !dbg !124
  %57 = add nsw i32 %56, 1, !dbg !124
  store i32 %57, i32* %6, align 4, !dbg !124
  br label %12, !dbg !125, !llvm.loop !126

58:                                               ; preds = %12
  br label %59, !dbg !127

59:                                               ; preds = %58
  %60 = load i32, i32* %5, align 4, !dbg !129
  %61 = add nsw i32 %60, 1, !dbg !129
  store i32 %61, i32* %5, align 4, !dbg !129
  br label %7, !dbg !130, !llvm.loop !131

62:                                               ; preds = %7
  ret void, !dbg !133
}

; Function Attrs: noinline nounwind uwtable
define dso_local i32 @task_job_polybench() #0 !dbg !134 {
  %1 = alloca i32, align 4
  %2 = alloca [500 x i32]*, align 8
  %3 = alloca i32, align 4
  %4 = alloca i32, align 4
  %5 = alloca i32, align 4
  %6 = load i32, i32* @n, align 4, !dbg !135
  store i32 %6, i32* %1, align 4
  call void @llvm.dbg.declare(metadata i32* %1, metadata !136, metadata !DIExpression()), !dbg !138
  store [500 x i32]* getelementptr inbounds ([500 x [500 x i32]], [500 x [500 x i32]]* @path, i64 0, i64 0), [500 x i32]** %2, align 8
  call void @llvm.dbg.declare(metadata [500 x i32]** %2, metadata !140, metadata !DIExpression()), !dbg !141
  call void @llvm.dbg.declare(metadata i32* %3, metadata !142, metadata !DIExpression()), !dbg !143
  call void @llvm.dbg.declare(metadata i32* %4, metadata !144, metadata !DIExpression()), !dbg !145
  call void @llvm.dbg.declare(metadata i32* %5, metadata !146, metadata !DIExpression()), !dbg !147
  store i32 0, i32* %5, align 4, !dbg !148
  br label %7, !dbg !150

7:                                                ; preds = %86, %0
  %8 = load i32, i32* %5, align 4, !dbg !151
  %9 = icmp slt i32 %8, 500, !dbg !153
  br i1 %9, label %10, label %89, !dbg !154

10:                                               ; preds = %7
  store i32 0, i32* %3, align 4, !dbg !155
  br label %11, !dbg !158

11:                                               ; preds = %83, %10
  %12 = load i32, i32* %3, align 4, !dbg !159
  %13 = icmp slt i32 %12, 500, !dbg !161
  br i1 %13, label %14, label %86, !dbg !162

14:                                               ; preds = %11
  store i32 0, i32* %4, align 4, !dbg !163
  br label %15, !dbg !165

15:                                               ; preds = %72, %14
  %16 = load i32, i32* %4, align 4, !dbg !166
  %17 = icmp slt i32 %16, 500, !dbg !168
  br i1 %17, label %18, label %83, !dbg !169

18:                                               ; preds = %15
  %19 = load [500 x i32]*, [500 x i32]** %2, align 8, !dbg !170
  %20 = load i32, i32* %3, align 4, !dbg !171
  %21 = sext i32 %20 to i64, !dbg !170
  %22 = getelementptr inbounds [500 x i32], [500 x i32]* %19, i64 %21, !dbg !170
  %23 = load i32, i32* %4, align 4, !dbg !172
  %24 = sext i32 %23 to i64, !dbg !170
  %25 = getelementptr inbounds [500 x i32], [500 x i32]* %22, i64 0, i64 %24, !dbg !170
  %26 = load i32, i32* %25, align 4, !dbg !170
  %27 = load [500 x i32]*, [500 x i32]** %2, align 8, !dbg !173
  %28 = load i32, i32* %3, align 4, !dbg !174
  %29 = sext i32 %28 to i64, !dbg !173
  %30 = getelementptr inbounds [500 x i32], [500 x i32]* %27, i64 %29, !dbg !173
  %31 = load i32, i32* %5, align 4, !dbg !175
  %32 = sext i32 %31 to i64, !dbg !173
  %33 = getelementptr inbounds [500 x i32], [500 x i32]* %30, i64 0, i64 %32, !dbg !173
  %34 = load i32, i32* %33, align 4, !dbg !173
  %35 = load [500 x i32]*, [500 x i32]** %2, align 8, !dbg !176
  %36 = load i32, i32* %5, align 4, !dbg !177
  %37 = sext i32 %36 to i64, !dbg !176
  %38 = getelementptr inbounds [500 x i32], [500 x i32]* %35, i64 %37, !dbg !176
  %39 = load i32, i32* %4, align 4, !dbg !178
  %40 = sext i32 %39 to i64, !dbg !176
  %41 = getelementptr inbounds [500 x i32], [500 x i32]* %38, i64 0, i64 %40, !dbg !176
  %42 = load i32, i32* %41, align 4, !dbg !176
  %43 = add nsw i32 %34, %42, !dbg !179
  %44 = icmp slt i32 %26, %43, !dbg !180
  br i1 %44, label %45, label %54, !dbg !170

45:                                               ; preds = %18
  %46 = load [500 x i32]*, [500 x i32]** %2, align 8, !dbg !181
  %47 = load i32, i32* %3, align 4, !dbg !182
  %48 = sext i32 %47 to i64, !dbg !181
  %49 = getelementptr inbounds [500 x i32], [500 x i32]* %46, i64 %48, !dbg !181
  %50 = load i32, i32* %4, align 4, !dbg !183
  %51 = sext i32 %50 to i64, !dbg !181
  %52 = getelementptr inbounds [500 x i32], [500 x i32]* %49, i64 0, i64 %51, !dbg !181
  %53 = load i32, i32* %52, align 4, !dbg !181
  br label %72, !dbg !170

54:                                               ; preds = %18
  %55 = load [500 x i32]*, [500 x i32]** %2, align 8, !dbg !184
  %56 = load i32, i32* %3, align 4, !dbg !185
  %57 = sext i32 %56 to i64, !dbg !184
  %58 = getelementptr inbounds [500 x i32], [500 x i32]* %55, i64 %57, !dbg !184
  %59 = load i32, i32* %5, align 4, !dbg !186
  %60 = sext i32 %59 to i64, !dbg !184
  %61 = getelementptr inbounds [500 x i32], [500 x i32]* %58, i64 0, i64 %60, !dbg !184
  %62 = load i32, i32* %61, align 4, !dbg !184
  %63 = load [500 x i32]*, [500 x i32]** %2, align 8, !dbg !187
  %64 = load i32, i32* %5, align 4, !dbg !188
  %65 = sext i32 %64 to i64, !dbg !187
  %66 = getelementptr inbounds [500 x i32], [500 x i32]* %63, i64 %65, !dbg !187
  %67 = load i32, i32* %4, align 4, !dbg !189
  %68 = sext i32 %67 to i64, !dbg !187
  %69 = getelementptr inbounds [500 x i32], [500 x i32]* %66, i64 0, i64 %68, !dbg !187
  %70 = load i32, i32* %69, align 4, !dbg !187
  %71 = add nsw i32 %62, %70, !dbg !190
  br label %72, !dbg !170

72:                                               ; preds = %54, %45
  %73 = phi i32 [ %53, %45 ], [ %71, %54 ], !dbg !170
  %74 = load [500 x i32]*, [500 x i32]** %2, align 8, !dbg !191
  %75 = load i32, i32* %3, align 4, !dbg !192
  %76 = sext i32 %75 to i64, !dbg !191
  %77 = getelementptr inbounds [500 x i32], [500 x i32]* %74, i64 %76, !dbg !191
  %78 = load i32, i32* %4, align 4, !dbg !193
  %79 = sext i32 %78 to i64, !dbg !191
  %80 = getelementptr inbounds [500 x i32], [500 x i32]* %77, i64 0, i64 %79, !dbg !191
  store i32 %73, i32* %80, align 4, !dbg !194
  %81 = load i32, i32* %4, align 4, !dbg !195
  %82 = add nsw i32 %81, 1, !dbg !195
  store i32 %82, i32* %4, align 4, !dbg !195
  br label %15, !dbg !196, !llvm.loop !197

83:                                               ; preds = %15
  %84 = load i32, i32* %3, align 4, !dbg !199
  %85 = add nsw i32 %84, 1, !dbg !199
  store i32 %85, i32* %3, align 4, !dbg !199
  br label %11, !dbg !200, !llvm.loop !201

86:                                               ; preds = %11
  %87 = load i32, i32* %5, align 4, !dbg !203
  %88 = add nsw i32 %87, 1, !dbg !203
  store i32 %88, i32* %5, align 4, !dbg !203
  br label %7, !dbg !204, !llvm.loop !205

89:                                               ; preds = %7
  ret i32 0, !dbg !207
}

; Function Attrs: noinline nounwind uwtable
define dso_local i32 @workload_checksum(i32 noundef %0) #0 !dbg !208 {
  %2 = alloca i32, align 4
  store i32 %0, i32* %2, align 4
  call void @llvm.dbg.declare(metadata i32* %2, metadata !211, metadata !DIExpression()), !dbg !212
  %3 = load i32, i32* %2, align 4, !dbg !213
  store i32 -2128831035, i32* @pb_hash, align 4, !dbg !214
  %4 = load i32, i32* @n, align 4, !dbg !215
  call void @print_array(i32 noundef %4, [500 x i32]* noundef getelementptr inbounds ([500 x [500 x i32]], [500 x [500 x i32]]* @path, i64 0, i64 0)), !dbg !216
  %5 = load i32, i32* @pb_hash, align 4, !dbg !217
  ret i32 %5, !dbg !218
}

; Function Attrs: noinline nounwind uwtable
define internal void @print_array(i32 noundef %0, [500 x i32]* noundef %1) #0 !dbg !219 {
  %3 = alloca i32, align 4
  %4 = alloca [500 x i32]*, align 8
  %5 = alloca i32, align 4
  %6 = alloca i32, align 4
  store i32 %0, i32* %3, align 4
  call void @llvm.dbg.declare(metadata i32* %3, metadata !220, metadata !DIExpression()), !dbg !221
  store [500 x i32]* %1, [500 x i32]** %4, align 8
  call void @llvm.dbg.declare(metadata [500 x i32]** %4, metadata !222, metadata !DIExpression()), !dbg !223
  call void @llvm.dbg.declare(metadata i32* %5, metadata !224, metadata !DIExpression()), !dbg !225
  call void @llvm.dbg.declare(metadata i32* %6, metadata !226, metadata !DIExpression()), !dbg !227
  %7 = load %struct._IO_FILE*, %struct._IO_FILE** @stderr, align 8, !dbg !228
  %8 = call i32 (%struct._IO_FILE*, i8*, ...) @pb_fprintf(%struct._IO_FILE* noundef %7, i8* noundef getelementptr inbounds ([23 x i8], [23 x i8]* @.str.2, i64 0, i64 0)), !dbg !228
  %9 = load %struct._IO_FILE*, %struct._IO_FILE** @stderr, align 8, !dbg !229
  %10 = call i32 (%struct._IO_FILE*, i8*, ...) @pb_fprintf(%struct._IO_FILE* noundef %9, i8* noundef getelementptr inbounds ([15 x i8], [15 x i8]* @.str.3, i64 0, i64 0), i8* noundef getelementptr inbounds ([5 x i8], [5 x i8]* @.str.4, i64 0, i64 0)), !dbg !229
  store i32 0, i32* %5, align 4, !dbg !230
  br label %11, !dbg !232

11:                                               ; preds = %46, %2
  %12 = load i32, i32* %5, align 4, !dbg !233
  %13 = load i32, i32* %3, align 4, !dbg !235
  %14 = icmp slt i32 %12, %13, !dbg !236
  br i1 %14, label %15, label %49, !dbg !237

15:                                               ; preds = %11
  store i32 0, i32* %6, align 4, !dbg !238
  br label %16, !dbg !240

16:                                               ; preds = %42, %15
  %17 = load i32, i32* %6, align 4, !dbg !241
  %18 = load i32, i32* %3, align 4, !dbg !243
  %19 = icmp slt i32 %17, %18, !dbg !244
  br i1 %19, label %20, label %45, !dbg !245

20:                                               ; preds = %16
  %21 = load i32, i32* %5, align 4, !dbg !246
  %22 = load i32, i32* %3, align 4, !dbg !249
  %23 = mul nsw i32 %21, %22, !dbg !250
  %24 = load i32, i32* %6, align 4, !dbg !251
  %25 = add nsw i32 %23, %24, !dbg !252
  %26 = srem i32 %25, 20, !dbg !253
  %27 = icmp eq i32 %26, 0, !dbg !254
  br i1 %27, label %28, label %31, !dbg !255

28:                                               ; preds = %20
  %29 = load %struct._IO_FILE*, %struct._IO_FILE** @stderr, align 8, !dbg !256
  %30 = call i32 (%struct._IO_FILE*, i8*, ...) @pb_fprintf(%struct._IO_FILE* noundef %29, i8* noundef getelementptr inbounds ([2 x i8], [2 x i8]* @.str.5, i64 0, i64 0)), !dbg !257
  br label %31, !dbg !257

31:                                               ; preds = %28, %20
  %32 = load %struct._IO_FILE*, %struct._IO_FILE** @stderr, align 8, !dbg !258
  %33 = load [500 x i32]*, [500 x i32]** %4, align 8, !dbg !259
  %34 = load i32, i32* %5, align 4, !dbg !260
  %35 = sext i32 %34 to i64, !dbg !259
  %36 = getelementptr inbounds [500 x i32], [500 x i32]* %33, i64 %35, !dbg !259
  %37 = load i32, i32* %6, align 4, !dbg !261
  %38 = sext i32 %37 to i64, !dbg !259
  %39 = getelementptr inbounds [500 x i32], [500 x i32]* %36, i64 0, i64 %38, !dbg !259
  %40 = load i32, i32* %39, align 4, !dbg !259
  %41 = call i32 (%struct._IO_FILE*, i8*, ...) @pb_fprintf(%struct._IO_FILE* noundef %32, i8* noundef getelementptr inbounds ([4 x i8], [4 x i8]* @.str.6, i64 0, i64 0), i32 noundef %40), !dbg !262
  br label %42, !dbg !263

42:                                               ; preds = %31
  %43 = load i32, i32* %6, align 4, !dbg !264
  %44 = add nsw i32 %43, 1, !dbg !264
  store i32 %44, i32* %6, align 4, !dbg !264
  br label %16, !dbg !265, !llvm.loop !266

45:                                               ; preds = %16
  br label %46, !dbg !267

46:                                               ; preds = %45
  %47 = load i32, i32* %5, align 4, !dbg !268
  %48 = add nsw i32 %47, 1, !dbg !268
  store i32 %48, i32* %5, align 4, !dbg !268
  br label %11, !dbg !269, !llvm.loop !270

49:                                               ; preds = %11
  %50 = load %struct._IO_FILE*, %struct._IO_FILE** @stderr, align 8, !dbg !272
  %51 = call i32 (%struct._IO_FILE*, i8*, ...) @pb_fprintf(%struct._IO_FILE* noundef %50, i8* noundef getelementptr inbounds ([17 x i8], [17 x i8]* @.str.7, i64 0, i64 0), i8* noundef getelementptr inbounds ([5 x i8], [5 x i8]* @.str.4, i64 0, i64 0)), !dbg !272
  %52 = load %struct._IO_FILE*, %struct._IO_FILE** @stderr, align 8, !dbg !273
  %53 = call i32 (%struct._IO_FILE*, i8*, ...) @pb_fprintf(%struct._IO_FILE* noundef %52, i8* noundef getelementptr inbounds ([23 x i8], [23 x i8]* @.str.8, i64 0, i64 0)), !dbg !273
  ret void, !dbg !274
}

; Function Attrs: noinline nounwind uwtable
define internal i32 @pb_fprintf(%struct._IO_FILE* noundef %0, i8* noundef %1, ...) #0 !dbg !275 {
  %3 = alloca %struct._IO_FILE*, align 8
  %4 = alloca i8*, align 8
  %5 = alloca [768 x i8], align 16
  %6 = alloca [1 x %struct.__va_list_tag], align 16
  %7 = alloca i32, align 4
  %8 = alloca i32, align 4
  store %struct._IO_FILE* %0, %struct._IO_FILE** %3, align 8
  call void @llvm.dbg.declare(metadata %struct._IO_FILE** %3, metadata !339, metadata !DIExpression()), !dbg !340
  store i8* %1, i8** %4, align 8
  call void @llvm.dbg.declare(metadata i8** %4, metadata !341, metadata !DIExpression()), !dbg !342
  call void @llvm.dbg.declare(metadata [768 x i8]* %5, metadata !343, metadata !DIExpression()), !dbg !347
  call void @llvm.dbg.declare(metadata [1 x %struct.__va_list_tag]* %6, metadata !348, metadata !DIExpression()), !dbg !362
  %9 = getelementptr inbounds [1 x %struct.__va_list_tag], [1 x %struct.__va_list_tag]* %6, i64 0, i64 0, !dbg !363
  %10 = bitcast %struct.__va_list_tag* %9 to i8*, !dbg !363
  call void @llvm.va_start(i8* %10), !dbg !363
  call void @llvm.dbg.declare(metadata i32* %7, metadata !364, metadata !DIExpression()), !dbg !365
  %11 = getelementptr inbounds [768 x i8], [768 x i8]* %5, i64 0, i64 0, !dbg !366
  %12 = load i8*, i8** %4, align 8, !dbg !367
  %13 = getelementptr inbounds [1 x %struct.__va_list_tag], [1 x %struct.__va_list_tag]* %6, i64 0, i64 0, !dbg !368
  %14 = call i32 @vsnprintf(i8* noundef %11, i64 noundef 768, i8* noundef %12, %struct.__va_list_tag* noundef %13) #6, !dbg !369
  store i32 %14, i32* %7, align 4, !dbg !365
  %15 = getelementptr inbounds [1 x %struct.__va_list_tag], [1 x %struct.__va_list_tag]* %6, i64 0, i64 0, !dbg !370
  %16 = bitcast %struct.__va_list_tag* %15 to i8*, !dbg !370
  call void @llvm.va_end(i8* %16), !dbg !370
  %17 = load i32, i32* %7, align 4, !dbg !371
  %18 = icmp slt i32 %17, 0, !dbg !373
  br i1 %18, label %23, label %19, !dbg !374

19:                                               ; preds = %2
  %20 = load i32, i32* %7, align 4, !dbg !375
  %21 = zext i32 %20 to i64, !dbg !376
  %22 = icmp uge i64 %21, 768, !dbg !377
  br i1 %22, label %23, label %24, !dbg !378

23:                                               ; preds = %19, %2
  call void @abort() #7, !dbg !379
  unreachable, !dbg !379

24:                                               ; preds = %19
  call void @llvm.dbg.declare(metadata i32* %8, metadata !380, metadata !DIExpression()), !dbg !382
  store i32 0, i32* %8, align 4, !dbg !382
  br label %25, !dbg !383

25:                                               ; preds = %39, %24
  %26 = load i32, i32* %8, align 4, !dbg !384
  %27 = load i32, i32* %7, align 4, !dbg !386
  %28 = icmp slt i32 %26, %27, !dbg !387
  br i1 %28, label %29, label %42, !dbg !388

29:                                               ; preds = %25
  %30 = load i32, i32* %8, align 4, !dbg !389
  %31 = sext i32 %30 to i64, !dbg !391
  %32 = getelementptr inbounds [768 x i8], [768 x i8]* %5, i64 0, i64 %31, !dbg !391
  %33 = load i8, i8* %32, align 1, !dbg !391
  %34 = zext i8 %33 to i32, !dbg !392
  %35 = load i32, i32* @pb_hash, align 4, !dbg !393
  %36 = xor i32 %35, %34, !dbg !393
  store i32 %36, i32* @pb_hash, align 4, !dbg !393
  %37 = load i32, i32* @pb_hash, align 4, !dbg !394
  %38 = mul i32 %37, 16777619, !dbg !394
  store i32 %38, i32* @pb_hash, align 4, !dbg !394
  br label %39, !dbg !395

39:                                               ; preds = %29
  %40 = load i32, i32* %8, align 4, !dbg !396
  %41 = add nsw i32 %40, 1, !dbg !396
  store i32 %41, i32* %8, align 4, !dbg !396
  br label %25, !dbg !397, !llvm.loop !398

42:                                               ; preds = %25
  %43 = load %struct._IO_FILE*, %struct._IO_FILE** %3, align 8, !dbg !400
  %44 = load i32, i32* @pb_emit, align 4, !dbg !401
  %45 = load i32, i32* %7, align 4, !dbg !402
  ret i32 %45, !dbg !403
}

; Function Attrs: nofree nosync nounwind willreturn
declare void @llvm.va_start(i8*) #3

; Function Attrs: nounwind
declare i32 @vsnprintf(i8* noundef, i64 noundef, i8* noundef, %struct.__va_list_tag* noundef) #4

; Function Attrs: nofree nosync nounwind willreturn
declare void @llvm.va_end(i8*) #3

; Function Attrs: noreturn nounwind
declare void @abort() #5

attributes #0 = { noinline nounwind uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { nofree nosync nounwind readnone speculatable willreturn }
attributes #2 = { argmemonly nofree nounwind willreturn writeonly }
attributes #3 = { nofree nosync nounwind willreturn }
attributes #4 = { nounwind "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #5 = { noreturn nounwind "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #6 = { nounwind }
attributes #7 = { noreturn nounwind }

!llvm.dbg.cu = !{!2}
!llvm.module.flags = !{!37, !38, !39, !40, !41, !42, !43}
!llvm.ident = !{!44}

!0 = !DIGlobalVariableExpression(var: !1, expr: !DIExpression())
!1 = distinct !DIGlobalVariable(name: "n", scope: !2, file: !10, line: 93, type: !32, isLocal: false, isDefinition: true)
!2 = distinct !DICompileUnit(language: DW_LANG_C99, file: !3, producer: "Ubuntu clang version 14.0.0-1ubuntu1.1", isOptimized: false, runtimeVersion: 0, emissionKind: FullDebug, retainedTypes: !4, globals: !7, splitDebugInlining: false, nameTableKind: None)
!3 = !DIFile(filename: "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/affine-bounds-20260929/suite/floyd-warshall/source/workload.c", directory: "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/affine-bounds-20260929/suite/floyd-warshall/analysis-g", checksumkind: CSK_MD5, checksum: "829643a027e81ecd281897c0f8fc5926")
!4 = !{!5, !6}
!5 = !DIBasicType(name: "unsigned int", size: 32, encoding: DW_ATE_unsigned)
!6 = !DIBasicType(name: "unsigned char", size: 8, encoding: DW_ATE_unsigned_char)
!7 = !{!0, !8, !22, !26, !29, !35}
!8 = !DIGlobalVariableExpression(var: !9, expr: !DIExpression())
!9 = distinct !DIGlobalVariable(name: "workload_jobs", scope: !2, file: !10, line: 110, type: !11, isLocal: false, isDefinition: true)
!10 = !DIFile(filename: "source/workload.c", directory: "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/affine-bounds-20260929/suite/floyd-warshall", checksumkind: CSK_MD5, checksum: "829643a027e81ecd281897c0f8fc5926")
!11 = !DICompositeType(tag: DW_TAG_array_type, baseType: !12, size: 64, elements: !20)
!12 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !13)
!13 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !14, size: 64)
!14 = !DISubroutineType(types: !15)
!15 = !{!16}
!16 = !DIDerivedType(tag: DW_TAG_typedef, name: "uint32_t", file: !17, line: 26, baseType: !18)
!17 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/stdint-uintn.h", directory: "", checksumkind: CSK_MD5, checksum: "2bf2ae53c58c01b1a1b9383b5195125c")
!18 = !DIDerivedType(tag: DW_TAG_typedef, name: "__uint32_t", file: !19, line: 42, baseType: !5)
!19 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/types.h", directory: "", checksumkind: CSK_MD5, checksum: "d108b5f93a74c50510d7d9bc0ab36df9")
!20 = !{!21}
!21 = !DISubrange(count: 1)
!22 = !DIGlobalVariableExpression(var: !23, expr: !DIExpression())
!23 = distinct !DIGlobalVariable(name: "workload_expected", scope: !2, file: !10, line: 114, type: !24, isLocal: false, isDefinition: true)
!24 = !DICompositeType(tag: DW_TAG_array_type, baseType: !25, size: 32, elements: !20)
!25 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !16)
!26 = !DIGlobalVariableExpression(var: !27, expr: !DIExpression())
!27 = distinct !DIGlobalVariable(name: "pb_hash", scope: !2, file: !28, line: 9, type: !16, isLocal: true, isDefinition: true)
!28 = !DIFile(filename: "source/adapter.h", directory: "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/affine-bounds-20260929/suite/floyd-warshall", checksumkind: CSK_MD5, checksum: "26a6068928b2092758f244a9d00163d7")
!29 = !DIGlobalVariableExpression(var: !30, expr: !DIExpression())
!30 = distinct !DIGlobalVariable(name: "path", scope: !2, file: !10, line: 34, type: !31, isLocal: false, isDefinition: true, align: 512)
!31 = !DICompositeType(tag: DW_TAG_array_type, baseType: !32, size: 8000000, elements: !33)
!32 = !DIBasicType(name: "int", size: 32, encoding: DW_ATE_signed)
!33 = !{!34, !34}
!34 = !DISubrange(count: 500)
!35 = !DIGlobalVariableExpression(var: !36, expr: !DIExpression())
!36 = distinct !DIGlobalVariable(name: "pb_emit", scope: !2, file: !28, line: 10, type: !32, isLocal: true, isDefinition: true)
!37 = !{i32 7, !"Dwarf Version", i32 5}
!38 = !{i32 2, !"Debug Info Version", i32 3}
!39 = !{i32 1, !"wchar_size", i32 4}
!40 = !{i32 7, !"PIC Level", i32 2}
!41 = !{i32 7, !"PIE Level", i32 2}
!42 = !{i32 7, !"uwtable", i32 1}
!43 = !{i32 7, !"frame-pointer", i32 2}
!44 = !{!"Ubuntu clang version 14.0.0-1ubuntu1.1"}
!45 = distinct !DISubprogram(name: "workload_prepare", scope: !10, file: !10, line: 94, type: !46, scopeLine: 94, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !2, retainedNodes: !48)
!46 = !DISubroutineType(types: !47)
!47 = !{null}
!48 = !{}
!49 = !DILocation(line: 94, column: 30, scope: !45)
!50 = distinct !DISubprogram(name: "workload_reset", scope: !10, file: !10, line: 95, type: !51, scopeLine: 95, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !2, retainedNodes: !48)
!51 = !DISubroutineType(types: !52)
!52 = !{null, !5}
!53 = !DILocalVariable(name: "task", arg: 1, scope: !50, file: !10, line: 95, type: !5)
!54 = !DILocation(line: 95, column: 30, scope: !50)
!55 = !DILocation(line: 96, column: 9, scope: !50)
!56 = !DILocation(line: 97, column: 3, scope: !50)
!57 = !DILocation(line: 98, column: 15, scope: !50)
!58 = !DILocation(line: 98, column: 3, scope: !50)
!59 = !DILocation(line: 99, column: 1, scope: !50)
!60 = distinct !DISubprogram(name: "init_array", scope: !10, file: !10, line: 36, type: !61, scopeLine: 38, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition, unit: !2, retainedNodes: !48)
!61 = !DISubroutineType(types: !62)
!62 = !{null, !32, !63}
!63 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !64, size: 64)
!64 = !DICompositeType(tag: DW_TAG_array_type, baseType: !32, size: 16000, elements: !65)
!65 = !{!34}
!66 = !DILocalVariable(name: "n", arg: 1, scope: !60, file: !10, line: 36, type: !32)
!67 = !DILocation(line: 36, column: 22, scope: !60)
!68 = !DILocalVariable(name: "path", arg: 2, scope: !60, file: !10, line: 37, type: !63)
!69 = !DILocation(line: 37, column: 14, scope: !60)
!70 = !DILocalVariable(name: "i", scope: !60, file: !10, line: 39, type: !32)
!71 = !DILocation(line: 39, column: 7, scope: !60)
!72 = !DILocalVariable(name: "j", scope: !60, file: !10, line: 39, type: !32)
!73 = !DILocation(line: 39, column: 10, scope: !60)
!74 = !DILocation(line: 41, column: 10, scope: !75)
!75 = distinct !DILexicalBlock(scope: !60, file: !10, line: 41, column: 3)
!76 = !DILocation(line: 41, column: 8, scope: !75)
!77 = !DILocation(line: 41, column: 15, scope: !78)
!78 = distinct !DILexicalBlock(scope: !75, file: !10, line: 41, column: 3)
!79 = !DILocation(line: 41, column: 19, scope: !78)
!80 = !DILocation(line: 41, column: 17, scope: !78)
!81 = !DILocation(line: 41, column: 3, scope: !75)
!82 = !DILocation(line: 42, column: 12, scope: !83)
!83 = distinct !DILexicalBlock(scope: !78, file: !10, line: 42, column: 5)
!84 = !DILocation(line: 42, column: 10, scope: !83)
!85 = !DILocation(line: 42, column: 17, scope: !86)
!86 = distinct !DILexicalBlock(scope: !83, file: !10, line: 42, column: 5)
!87 = !DILocation(line: 42, column: 21, scope: !86)
!88 = !DILocation(line: 42, column: 19, scope: !86)
!89 = !DILocation(line: 42, column: 5, scope: !83)
!90 = !DILocation(line: 43, column: 20, scope: !91)
!91 = distinct !DILexicalBlock(scope: !86, file: !10, line: 42, column: 29)
!92 = !DILocation(line: 43, column: 22, scope: !91)
!93 = !DILocation(line: 43, column: 21, scope: !91)
!94 = !DILocation(line: 43, column: 23, scope: !91)
!95 = !DILocation(line: 43, column: 25, scope: !91)
!96 = !DILocation(line: 43, column: 7, scope: !91)
!97 = !DILocation(line: 43, column: 12, scope: !91)
!98 = !DILocation(line: 43, column: 15, scope: !91)
!99 = !DILocation(line: 43, column: 18, scope: !91)
!100 = !DILocation(line: 44, column: 12, scope: !101)
!101 = distinct !DILexicalBlock(scope: !91, file: !10, line: 44, column: 11)
!102 = !DILocation(line: 44, column: 14, scope: !101)
!103 = !DILocation(line: 44, column: 13, scope: !101)
!104 = !DILocation(line: 44, column: 16, scope: !101)
!105 = !DILocation(line: 44, column: 20, scope: !101)
!106 = !DILocation(line: 44, column: 25, scope: !101)
!107 = !DILocation(line: 44, column: 29, scope: !101)
!108 = !DILocation(line: 44, column: 31, scope: !101)
!109 = !DILocation(line: 44, column: 30, scope: !101)
!110 = !DILocation(line: 44, column: 33, scope: !101)
!111 = !DILocation(line: 44, column: 35, scope: !101)
!112 = !DILocation(line: 44, column: 39, scope: !101)
!113 = !DILocation(line: 44, column: 43, scope: !101)
!114 = !DILocation(line: 44, column: 45, scope: !101)
!115 = !DILocation(line: 44, column: 44, scope: !101)
!116 = !DILocation(line: 44, column: 47, scope: !101)
!117 = !DILocation(line: 44, column: 51, scope: !101)
!118 = !DILocation(line: 44, column: 11, scope: !91)
!119 = !DILocation(line: 45, column: 10, scope: !101)
!120 = !DILocation(line: 45, column: 15, scope: !101)
!121 = !DILocation(line: 45, column: 18, scope: !101)
!122 = !DILocation(line: 45, column: 21, scope: !101)
!123 = !DILocation(line: 46, column: 5, scope: !91)
!124 = !DILocation(line: 42, column: 25, scope: !86)
!125 = !DILocation(line: 42, column: 5, scope: !86)
!126 = distinct !{!126, !89, !127, !128}
!127 = !DILocation(line: 46, column: 5, scope: !83)
!128 = !{!"llvm.loop.mustprogress"}
!129 = !DILocation(line: 41, column: 23, scope: !78)
!130 = !DILocation(line: 41, column: 3, scope: !78)
!131 = distinct !{!131, !81, !132, !128}
!132 = !DILocation(line: 46, column: 5, scope: !75)
!133 = !DILocation(line: 47, column: 1, scope: !60)
!134 = distinct !DISubprogram(name: "task_job_polybench", scope: !10, file: !10, line: 100, type: !14, scopeLine: 100, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !2, retainedNodes: !48)
!135 = !DILocation(line: 101, column: 26, scope: !134)
!136 = !DILocalVariable(name: "n", arg: 1, scope: !137, file: !10, line: 74, type: !32)
!137 = distinct !DISubprogram(name: "kernel_floyd_warshall", scope: !10, file: !10, line: 74, type: !61, scopeLine: 76, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition, unit: !2, retainedNodes: !48)
!138 = !DILocation(line: 74, column: 70, scope: !137, inlinedAt: !139)
!139 = distinct !DILocation(line: 101, column: 3, scope: !134)
!140 = !DILocalVariable(name: "path", arg: 2, scope: !137, file: !10, line: 75, type: !63)
!141 = !DILocation(line: 75, column: 17, scope: !137, inlinedAt: !139)
!142 = !DILocalVariable(name: "i", scope: !137, file: !10, line: 77, type: !32)
!143 = !DILocation(line: 77, column: 7, scope: !137, inlinedAt: !139)
!144 = !DILocalVariable(name: "j", scope: !137, file: !10, line: 77, type: !32)
!145 = !DILocation(line: 77, column: 10, scope: !137, inlinedAt: !139)
!146 = !DILocalVariable(name: "k", scope: !137, file: !10, line: 77, type: !32)
!147 = !DILocation(line: 77, column: 13, scope: !137, inlinedAt: !139)
!148 = !DILocation(line: 80, column: 10, scope: !149, inlinedAt: !139)
!149 = distinct !DILexicalBlock(scope: !137, file: !10, line: 80, column: 3)
!150 = !DILocation(line: 80, column: 8, scope: !149, inlinedAt: !139)
!151 = !DILocation(line: 80, column: 15, scope: !152, inlinedAt: !139)
!152 = distinct !DILexicalBlock(scope: !149, file: !10, line: 80, column: 3)
!153 = !DILocation(line: 80, column: 17, scope: !152, inlinedAt: !139)
!154 = !DILocation(line: 80, column: 3, scope: !149, inlinedAt: !139)
!155 = !DILocation(line: 82, column: 13, scope: !156, inlinedAt: !139)
!156 = distinct !DILexicalBlock(scope: !157, file: !10, line: 82, column: 7)
!157 = distinct !DILexicalBlock(scope: !152, file: !10, line: 81, column: 5)
!158 = !DILocation(line: 82, column: 11, scope: !156, inlinedAt: !139)
!159 = !DILocation(line: 82, column: 18, scope: !160, inlinedAt: !139)
!160 = distinct !DILexicalBlock(scope: !156, file: !10, line: 82, column: 7)
!161 = !DILocation(line: 82, column: 20, scope: !160, inlinedAt: !139)
!162 = !DILocation(line: 82, column: 7, scope: !156, inlinedAt: !139)
!163 = !DILocation(line: 83, column: 9, scope: !164, inlinedAt: !139)
!164 = distinct !DILexicalBlock(scope: !160, file: !10, line: 83, column: 2)
!165 = !DILocation(line: 83, column: 7, scope: !164, inlinedAt: !139)
!166 = !DILocation(line: 83, column: 14, scope: !167, inlinedAt: !139)
!167 = distinct !DILexicalBlock(scope: !164, file: !10, line: 83, column: 2)
!168 = !DILocation(line: 83, column: 16, scope: !167, inlinedAt: !139)
!169 = !DILocation(line: 83, column: 2, scope: !164, inlinedAt: !139)
!170 = !DILocation(line: 84, column: 17, scope: !167, inlinedAt: !139)
!171 = !DILocation(line: 84, column: 22, scope: !167, inlinedAt: !139)
!172 = !DILocation(line: 84, column: 25, scope: !167, inlinedAt: !139)
!173 = !DILocation(line: 84, column: 30, scope: !167, inlinedAt: !139)
!174 = !DILocation(line: 84, column: 35, scope: !167, inlinedAt: !139)
!175 = !DILocation(line: 84, column: 38, scope: !167, inlinedAt: !139)
!176 = !DILocation(line: 84, column: 43, scope: !167, inlinedAt: !139)
!177 = !DILocation(line: 84, column: 48, scope: !167, inlinedAt: !139)
!178 = !DILocation(line: 84, column: 51, scope: !167, inlinedAt: !139)
!179 = !DILocation(line: 84, column: 41, scope: !167, inlinedAt: !139)
!180 = !DILocation(line: 84, column: 28, scope: !167, inlinedAt: !139)
!181 = !DILocation(line: 85, column: 6, scope: !167, inlinedAt: !139)
!182 = !DILocation(line: 85, column: 11, scope: !167, inlinedAt: !139)
!183 = !DILocation(line: 85, column: 14, scope: !167, inlinedAt: !139)
!184 = !DILocation(line: 85, column: 19, scope: !167, inlinedAt: !139)
!185 = !DILocation(line: 85, column: 24, scope: !167, inlinedAt: !139)
!186 = !DILocation(line: 85, column: 27, scope: !167, inlinedAt: !139)
!187 = !DILocation(line: 85, column: 32, scope: !167, inlinedAt: !139)
!188 = !DILocation(line: 85, column: 37, scope: !167, inlinedAt: !139)
!189 = !DILocation(line: 85, column: 40, scope: !167, inlinedAt: !139)
!190 = !DILocation(line: 85, column: 30, scope: !167, inlinedAt: !139)
!191 = !DILocation(line: 84, column: 4, scope: !167, inlinedAt: !139)
!192 = !DILocation(line: 84, column: 9, scope: !167, inlinedAt: !139)
!193 = !DILocation(line: 84, column: 12, scope: !167, inlinedAt: !139)
!194 = !DILocation(line: 84, column: 15, scope: !167, inlinedAt: !139)
!195 = !DILocation(line: 83, column: 26, scope: !167, inlinedAt: !139)
!196 = !DILocation(line: 83, column: 2, scope: !167, inlinedAt: !139)
!197 = distinct !{!197, !169, !198, !128}
!198 = !DILocation(line: 85, column: 41, scope: !164, inlinedAt: !139)
!199 = !DILocation(line: 82, column: 30, scope: !160, inlinedAt: !139)
!200 = !DILocation(line: 82, column: 7, scope: !160, inlinedAt: !139)
!201 = distinct !{!201, !162, !202, !128}
!202 = !DILocation(line: 85, column: 41, scope: !156, inlinedAt: !139)
!203 = !DILocation(line: 80, column: 27, scope: !152, inlinedAt: !139)
!204 = !DILocation(line: 80, column: 3, scope: !152, inlinedAt: !139)
!205 = distinct !{!205, !154, !206, !128}
!206 = !DILocation(line: 86, column: 5, scope: !149, inlinedAt: !139)
!207 = !DILocation(line: 102, column: 3, scope: !134)
!208 = distinct !DISubprogram(name: "workload_checksum", scope: !10, file: !10, line: 104, type: !209, scopeLine: 104, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !2, retainedNodes: !48)
!209 = !DISubroutineType(types: !210)
!210 = !{!16, !5}
!211 = !DILocalVariable(name: "task", arg: 1, scope: !208, file: !10, line: 104, type: !5)
!212 = !DILocation(line: 104, column: 37, scope: !208)
!213 = !DILocation(line: 105, column: 9, scope: !208)
!214 = !DILocation(line: 106, column: 11, scope: !208)
!215 = !DILocation(line: 107, column: 15, scope: !208)
!216 = !DILocation(line: 107, column: 3, scope: !208)
!217 = !DILocation(line: 108, column: 10, scope: !208)
!218 = !DILocation(line: 108, column: 3, scope: !208)
!219 = distinct !DISubprogram(name: "print_array", scope: !10, file: !10, line: 53, type: !61, scopeLine: 56, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition, unit: !2, retainedNodes: !48)
!220 = !DILocalVariable(name: "n", arg: 1, scope: !219, file: !10, line: 53, type: !32)
!221 = !DILocation(line: 53, column: 22, scope: !219)
!222 = !DILocalVariable(name: "path", arg: 2, scope: !219, file: !10, line: 54, type: !63)
!223 = !DILocation(line: 54, column: 14, scope: !219)
!224 = !DILocalVariable(name: "i", scope: !219, file: !10, line: 57, type: !32)
!225 = !DILocation(line: 57, column: 7, scope: !219)
!226 = !DILocalVariable(name: "j", scope: !219, file: !10, line: 57, type: !32)
!227 = !DILocation(line: 57, column: 10, scope: !219)
!228 = !DILocation(line: 59, column: 3, scope: !219)
!229 = !DILocation(line: 60, column: 3, scope: !219)
!230 = !DILocation(line: 61, column: 10, scope: !231)
!231 = distinct !DILexicalBlock(scope: !219, file: !10, line: 61, column: 3)
!232 = !DILocation(line: 61, column: 8, scope: !231)
!233 = !DILocation(line: 61, column: 15, scope: !234)
!234 = distinct !DILexicalBlock(scope: !231, file: !10, line: 61, column: 3)
!235 = !DILocation(line: 61, column: 19, scope: !234)
!236 = !DILocation(line: 61, column: 17, scope: !234)
!237 = !DILocation(line: 61, column: 3, scope: !231)
!238 = !DILocation(line: 62, column: 12, scope: !239)
!239 = distinct !DILexicalBlock(scope: !234, file: !10, line: 62, column: 5)
!240 = !DILocation(line: 62, column: 10, scope: !239)
!241 = !DILocation(line: 62, column: 17, scope: !242)
!242 = distinct !DILexicalBlock(scope: !239, file: !10, line: 62, column: 5)
!243 = !DILocation(line: 62, column: 21, scope: !242)
!244 = !DILocation(line: 62, column: 19, scope: !242)
!245 = !DILocation(line: 62, column: 5, scope: !239)
!246 = !DILocation(line: 63, column: 12, scope: !247)
!247 = distinct !DILexicalBlock(scope: !248, file: !10, line: 63, column: 11)
!248 = distinct !DILexicalBlock(scope: !242, file: !10, line: 62, column: 29)
!249 = !DILocation(line: 63, column: 16, scope: !247)
!250 = !DILocation(line: 63, column: 14, scope: !247)
!251 = !DILocation(line: 63, column: 20, scope: !247)
!252 = !DILocation(line: 63, column: 18, scope: !247)
!253 = !DILocation(line: 63, column: 23, scope: !247)
!254 = !DILocation(line: 63, column: 28, scope: !247)
!255 = !DILocation(line: 63, column: 11, scope: !248)
!256 = !DILocation(line: 63, column: 43, scope: !247)
!257 = !DILocation(line: 63, column: 34, scope: !247)
!258 = !DILocation(line: 64, column: 16, scope: !248)
!259 = !DILocation(line: 64, column: 61, scope: !248)
!260 = !DILocation(line: 64, column: 66, scope: !248)
!261 = !DILocation(line: 64, column: 69, scope: !248)
!262 = !DILocation(line: 64, column: 7, scope: !248)
!263 = !DILocation(line: 65, column: 5, scope: !248)
!264 = !DILocation(line: 62, column: 25, scope: !242)
!265 = !DILocation(line: 62, column: 5, scope: !242)
!266 = distinct !{!266, !245, !267, !128}
!267 = !DILocation(line: 65, column: 5, scope: !239)
!268 = !DILocation(line: 61, column: 23, scope: !234)
!269 = !DILocation(line: 61, column: 3, scope: !234)
!270 = distinct !{!270, !237, !271, !128}
!271 = !DILocation(line: 65, column: 5, scope: !231)
!272 = !DILocation(line: 66, column: 3, scope: !219)
!273 = !DILocation(line: 67, column: 3, scope: !219)
!274 = !DILocation(line: 68, column: 1, scope: !219)
!275 = distinct !DISubprogram(name: "pb_fprintf", scope: !28, file: !28, line: 13, type: !276, scopeLine: 14, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition, unit: !2, retainedNodes: !48)
!276 = !DISubroutineType(types: !277)
!277 = !{!32, !278, !337, null}
!278 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !279, size: 64)
!279 = !DIDerivedType(tag: DW_TAG_typedef, name: "FILE", file: !280, line: 7, baseType: !281)
!280 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/types/FILE.h", directory: "", checksumkind: CSK_MD5, checksum: "571f9fb6223c42439075fdde11a0de5d")
!281 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "_IO_FILE", file: !282, line: 49, size: 1728, elements: !283)
!282 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/types/struct_FILE.h", directory: "", checksumkind: CSK_MD5, checksum: "1bad07471b7974df4ecc1d1c2ca207e6")
!283 = !{!284, !285, !288, !289, !290, !291, !292, !293, !294, !295, !296, !297, !298, !301, !303, !304, !305, !308, !310, !312, !314, !317, !319, !322, !325, !326, !328, !332, !333}
!284 = !DIDerivedType(tag: DW_TAG_member, name: "_flags", scope: !281, file: !282, line: 51, baseType: !32, size: 32)
!285 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_read_ptr", scope: !281, file: !282, line: 54, baseType: !286, size: 64, offset: 64)
!286 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !287, size: 64)
!287 = !DIBasicType(name: "char", size: 8, encoding: DW_ATE_signed_char)
!288 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_read_end", scope: !281, file: !282, line: 55, baseType: !286, size: 64, offset: 128)
!289 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_read_base", scope: !281, file: !282, line: 56, baseType: !286, size: 64, offset: 192)
!290 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_write_base", scope: !281, file: !282, line: 57, baseType: !286, size: 64, offset: 256)
!291 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_write_ptr", scope: !281, file: !282, line: 58, baseType: !286, size: 64, offset: 320)
!292 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_write_end", scope: !281, file: !282, line: 59, baseType: !286, size: 64, offset: 384)
!293 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_buf_base", scope: !281, file: !282, line: 60, baseType: !286, size: 64, offset: 448)
!294 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_buf_end", scope: !281, file: !282, line: 61, baseType: !286, size: 64, offset: 512)
!295 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_save_base", scope: !281, file: !282, line: 64, baseType: !286, size: 64, offset: 576)
!296 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_backup_base", scope: !281, file: !282, line: 65, baseType: !286, size: 64, offset: 640)
!297 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_save_end", scope: !281, file: !282, line: 66, baseType: !286, size: 64, offset: 704)
!298 = !DIDerivedType(tag: DW_TAG_member, name: "_markers", scope: !281, file: !282, line: 68, baseType: !299, size: 64, offset: 768)
!299 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !300, size: 64)
!300 = !DICompositeType(tag: DW_TAG_structure_type, name: "_IO_marker", file: !282, line: 36, flags: DIFlagFwdDecl)
!301 = !DIDerivedType(tag: DW_TAG_member, name: "_chain", scope: !281, file: !282, line: 70, baseType: !302, size: 64, offset: 832)
!302 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !281, size: 64)
!303 = !DIDerivedType(tag: DW_TAG_member, name: "_fileno", scope: !281, file: !282, line: 72, baseType: !32, size: 32, offset: 896)
!304 = !DIDerivedType(tag: DW_TAG_member, name: "_flags2", scope: !281, file: !282, line: 73, baseType: !32, size: 32, offset: 928)
!305 = !DIDerivedType(tag: DW_TAG_member, name: "_old_offset", scope: !281, file: !282, line: 74, baseType: !306, size: 64, offset: 960)
!306 = !DIDerivedType(tag: DW_TAG_typedef, name: "__off_t", file: !19, line: 152, baseType: !307)
!307 = !DIBasicType(name: "long", size: 64, encoding: DW_ATE_signed)
!308 = !DIDerivedType(tag: DW_TAG_member, name: "_cur_column", scope: !281, file: !282, line: 77, baseType: !309, size: 16, offset: 1024)
!309 = !DIBasicType(name: "unsigned short", size: 16, encoding: DW_ATE_unsigned)
!310 = !DIDerivedType(tag: DW_TAG_member, name: "_vtable_offset", scope: !281, file: !282, line: 78, baseType: !311, size: 8, offset: 1040)
!311 = !DIBasicType(name: "signed char", size: 8, encoding: DW_ATE_signed_char)
!312 = !DIDerivedType(tag: DW_TAG_member, name: "_shortbuf", scope: !281, file: !282, line: 79, baseType: !313, size: 8, offset: 1048)
!313 = !DICompositeType(tag: DW_TAG_array_type, baseType: !287, size: 8, elements: !20)
!314 = !DIDerivedType(tag: DW_TAG_member, name: "_lock", scope: !281, file: !282, line: 81, baseType: !315, size: 64, offset: 1088)
!315 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !316, size: 64)
!316 = !DIDerivedType(tag: DW_TAG_typedef, name: "_IO_lock_t", file: !282, line: 43, baseType: null)
!317 = !DIDerivedType(tag: DW_TAG_member, name: "_offset", scope: !281, file: !282, line: 89, baseType: !318, size: 64, offset: 1152)
!318 = !DIDerivedType(tag: DW_TAG_typedef, name: "__off64_t", file: !19, line: 153, baseType: !307)
!319 = !DIDerivedType(tag: DW_TAG_member, name: "_codecvt", scope: !281, file: !282, line: 91, baseType: !320, size: 64, offset: 1216)
!320 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !321, size: 64)
!321 = !DICompositeType(tag: DW_TAG_structure_type, name: "_IO_codecvt", file: !282, line: 37, flags: DIFlagFwdDecl)
!322 = !DIDerivedType(tag: DW_TAG_member, name: "_wide_data", scope: !281, file: !282, line: 92, baseType: !323, size: 64, offset: 1280)
!323 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !324, size: 64)
!324 = !DICompositeType(tag: DW_TAG_structure_type, name: "_IO_wide_data", file: !282, line: 38, flags: DIFlagFwdDecl)
!325 = !DIDerivedType(tag: DW_TAG_member, name: "_freeres_list", scope: !281, file: !282, line: 93, baseType: !302, size: 64, offset: 1344)
!326 = !DIDerivedType(tag: DW_TAG_member, name: "_freeres_buf", scope: !281, file: !282, line: 94, baseType: !327, size: 64, offset: 1408)
!327 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: null, size: 64)
!328 = !DIDerivedType(tag: DW_TAG_member, name: "__pad5", scope: !281, file: !282, line: 95, baseType: !329, size: 64, offset: 1472)
!329 = !DIDerivedType(tag: DW_TAG_typedef, name: "size_t", file: !330, line: 46, baseType: !331)
!330 = !DIFile(filename: "/usr/lib/llvm-14/lib/clang/14.0.0/include/stddef.h", directory: "", checksumkind: CSK_MD5, checksum: "2499dd2361b915724b073282bea3a7bc")
!331 = !DIBasicType(name: "unsigned long", size: 64, encoding: DW_ATE_unsigned)
!332 = !DIDerivedType(tag: DW_TAG_member, name: "_mode", scope: !281, file: !282, line: 96, baseType: !32, size: 32, offset: 1536)
!333 = !DIDerivedType(tag: DW_TAG_member, name: "_unused2", scope: !281, file: !282, line: 98, baseType: !334, size: 160, offset: 1568)
!334 = !DICompositeType(tag: DW_TAG_array_type, baseType: !287, size: 160, elements: !335)
!335 = !{!336}
!336 = !DISubrange(count: 20)
!337 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !338, size: 64)
!338 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !287)
!339 = !DILocalVariable(name: "stream", arg: 1, scope: !275, file: !28, line: 13, type: !278)
!340 = !DILocation(line: 13, column: 29, scope: !275)
!341 = !DILocalVariable(name: "format", arg: 2, scope: !275, file: !28, line: 13, type: !337)
!342 = !DILocation(line: 13, column: 49, scope: !275)
!343 = !DILocalVariable(name: "buffer", scope: !275, file: !28, line: 15, type: !344)
!344 = !DICompositeType(tag: DW_TAG_array_type, baseType: !287, size: 6144, elements: !345)
!345 = !{!346}
!346 = !DISubrange(count: 768)
!347 = !DILocation(line: 15, column: 10, scope: !275)
!348 = !DILocalVariable(name: "args", scope: !275, file: !28, line: 16, type: !349)
!349 = !DIDerivedType(tag: DW_TAG_typedef, name: "va_list", file: !350, line: 52, baseType: !351)
!350 = !DIFile(filename: "/usr/include/stdio.h", directory: "", checksumkind: CSK_MD5, checksum: "f31eefcc3f15835fc5a4023a625cf609")
!351 = !DIDerivedType(tag: DW_TAG_typedef, name: "__gnuc_va_list", file: !352, line: 32, baseType: !353)
!352 = !DIFile(filename: "/usr/lib/llvm-14/lib/clang/14.0.0/include/stdarg.h", directory: "", checksumkind: CSK_MD5, checksum: "4de3cbd931b589d291e5c39387aecf82")
!353 = !DIDerivedType(tag: DW_TAG_typedef, name: "__builtin_va_list", file: !354, baseType: !355)
!354 = !DIFile(filename: "source/workload.c", directory: "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/affine-bounds-20260929/suite/floyd-warshall")
!355 = !DICompositeType(tag: DW_TAG_array_type, baseType: !356, size: 192, elements: !20)
!356 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "__va_list_tag", size: 192, elements: !357)
!357 = !{!358, !359, !360, !361}
!358 = !DIDerivedType(tag: DW_TAG_member, name: "gp_offset", scope: !356, file: !354, line: 16, baseType: !5, size: 32)
!359 = !DIDerivedType(tag: DW_TAG_member, name: "fp_offset", scope: !356, file: !354, line: 16, baseType: !5, size: 32, offset: 32)
!360 = !DIDerivedType(tag: DW_TAG_member, name: "overflow_arg_area", scope: !356, file: !354, line: 16, baseType: !327, size: 64, offset: 64)
!361 = !DIDerivedType(tag: DW_TAG_member, name: "reg_save_area", scope: !356, file: !354, line: 16, baseType: !327, size: 64, offset: 128)
!362 = !DILocation(line: 16, column: 13, scope: !275)
!363 = !DILocation(line: 17, column: 5, scope: !275)
!364 = !DILocalVariable(name: "count", scope: !275, file: !28, line: 18, type: !32)
!365 = !DILocation(line: 18, column: 9, scope: !275)
!366 = !DILocation(line: 18, column: 27, scope: !275)
!367 = !DILocation(line: 18, column: 51, scope: !275)
!368 = !DILocation(line: 18, column: 59, scope: !275)
!369 = !DILocation(line: 18, column: 17, scope: !275)
!370 = !DILocation(line: 19, column: 5, scope: !275)
!371 = !DILocation(line: 20, column: 9, scope: !372)
!372 = distinct !DILexicalBlock(scope: !275, file: !28, line: 20, column: 9)
!373 = !DILocation(line: 20, column: 15, scope: !372)
!374 = !DILocation(line: 20, column: 19, scope: !372)
!375 = !DILocation(line: 20, column: 32, scope: !372)
!376 = !DILocation(line: 20, column: 22, scope: !372)
!377 = !DILocation(line: 20, column: 38, scope: !372)
!378 = !DILocation(line: 20, column: 9, scope: !275)
!379 = !DILocation(line: 20, column: 57, scope: !372)
!380 = !DILocalVariable(name: "i", scope: !381, file: !28, line: 21, type: !32)
!381 = distinct !DILexicalBlock(scope: !275, file: !28, line: 21, column: 5)
!382 = !DILocation(line: 21, column: 14, scope: !381)
!383 = !DILocation(line: 21, column: 10, scope: !381)
!384 = !DILocation(line: 21, column: 21, scope: !385)
!385 = distinct !DILexicalBlock(scope: !381, file: !28, line: 21, column: 5)
!386 = !DILocation(line: 21, column: 25, scope: !385)
!387 = !DILocation(line: 21, column: 23, scope: !385)
!388 = !DILocation(line: 21, column: 5, scope: !381)
!389 = !DILocation(line: 22, column: 42, scope: !390)
!390 = distinct !DILexicalBlock(scope: !385, file: !28, line: 21, column: 37)
!391 = !DILocation(line: 22, column: 35, scope: !390)
!392 = !DILocation(line: 22, column: 20, scope: !390)
!393 = !DILocation(line: 22, column: 17, scope: !390)
!394 = !DILocation(line: 23, column: 17, scope: !390)
!395 = !DILocation(line: 24, column: 5, scope: !390)
!396 = !DILocation(line: 21, column: 32, scope: !385)
!397 = !DILocation(line: 21, column: 5, scope: !385)
!398 = distinct !{!398, !388, !399, !128}
!399 = !DILocation(line: 24, column: 5, scope: !381)
!400 = !DILocation(line: 28, column: 11, scope: !275)
!401 = !DILocation(line: 29, column: 11, scope: !275)
!402 = !DILocation(line: 31, column: 12, scope: !275)
!403 = !DILocation(line: 31, column: 5, scope: !275)
