; ModuleID = 'inlined.ll'
source_filename = "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/affine-bounds-20260929/suite/floyd-warshall/source/workload.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

@n = external dso_local global i32, align 4, !dbg !0
@path = external dso_local global [500 x [500 x i32]], section ".chaser_data.path", align 64, !dbg !8
@.str = hidden unnamed_addr constant [12 x i8] c"ape.analyze\00", section "llvm.metadata"
@.str.1 = hidden unnamed_addr constant [132 x i8] c"/workspace/experiments-array-support/chaser/.cache/periodic-polybench/affine-bounds-20260929/suite/floyd-warshall/source/workload.c\00", section "llvm.metadata"
@.str.2 = hidden unnamed_addr constant [23 x i8] c"==BEGIN DUMP_ARRAYS==\0A\00", align 1
@.str.3 = hidden unnamed_addr constant [15 x i8] c"begin dump: %s\00", align 1
@.str.4 = hidden unnamed_addr constant [5 x i8] c"path\00", align 1
@.str.5 = hidden unnamed_addr constant [2 x i8] c"\0A\00", align 1
@.str.6 = hidden unnamed_addr constant [4 x i8] c"%d \00", align 1
@.str.7 = hidden unnamed_addr constant [17 x i8] c"\0Aend   dump: %s\0A\00", align 1
@.str.8 = hidden unnamed_addr constant [23 x i8] c"==END   DUMP_ARRAYS==\0A\00", align 1
@llvm.global.annotations = appending global [1 x { i8*, i8*, i8*, i32, i8* }] [{ i8*, i8*, i8*, i32, i8* } { i8* bitcast (i32 ()* @task_job_polybench to i8*), i8* getelementptr inbounds ([12 x i8], [12 x i8]* @.str, i32 0, i32 0), i8* getelementptr inbounds ([132 x i8], [132 x i8]* @.str.1, i32 0, i32 0), i32 100, i8* null }], section "llvm.metadata"

; Function Attrs: noinline nounwind uwtable
define dso_local i32 @task_job_polybench() #0 !dbg !23 {
  %1 = load i32, i32* @n, align 4, !dbg !31
  call void @llvm.dbg.value(metadata i32 %1, metadata !32, metadata !DIExpression()), !dbg !39
  call void @llvm.dbg.value(metadata [500 x i32]* getelementptr inbounds ([500 x [500 x i32]], [500 x [500 x i32]]* @path, i64 0, i64 0), metadata !41, metadata !DIExpression()), !dbg !39
  call void @llvm.dbg.value(metadata i32 0, metadata !42, metadata !DIExpression()), !dbg !39
  br label %2, !dbg !43

2:                                                ; preds = %55, %0
  %.0 = phi i32 [ 0, %0 ], [ %56, %55 ], !dbg !45
  call void @llvm.dbg.value(metadata i32 %.0, metadata !42, metadata !DIExpression()), !dbg !39
  %3 = icmp slt i32 %.0, 500, !dbg !46
  br i1 %3, label %4, label %57, !dbg !48

4:                                                ; preds = %2
  call void @llvm.dbg.value(metadata i32 0, metadata !49, metadata !DIExpression()), !dbg !39
  br label %5, !dbg !50

5:                                                ; preds = %53, %4
  %.02 = phi i32 [ 0, %4 ], [ %54, %53 ], !dbg !53
  call void @llvm.dbg.value(metadata i32 %.02, metadata !49, metadata !DIExpression()), !dbg !39
  %6 = icmp slt i32 %.02, 500, !dbg !54
  br i1 %6, label %7, label %55, !dbg !56

7:                                                ; preds = %5
  call void @llvm.dbg.value(metadata i32 0, metadata !57, metadata !DIExpression()), !dbg !39
  br label %8, !dbg !58

8:                                                ; preds = %46, %7
  %.01 = phi i32 [ 0, %7 ], [ %52, %46 ], !dbg !60
  call void @llvm.dbg.value(metadata i32 %.01, metadata !57, metadata !DIExpression()), !dbg !39
  %9 = icmp slt i32 %.01, 500, !dbg !61
  br i1 %9, label %10, label %53, !dbg !63

10:                                               ; preds = %8
  %11 = sext i32 %.02 to i64, !dbg !64
  %12 = getelementptr inbounds [500 x i32], [500 x i32]* getelementptr inbounds ([500 x [500 x i32]], [500 x [500 x i32]]* @path, i64 0, i64 0), i64 %11, !dbg !64
  %13 = sext i32 %.01 to i64, !dbg !64
  %14 = getelementptr inbounds [500 x i32], [500 x i32]* %12, i64 0, i64 %13, !dbg !64
  %15 = load i32, i32* %14, align 4, !dbg !64
  %16 = sext i32 %.02 to i64, !dbg !65
  %17 = getelementptr inbounds [500 x i32], [500 x i32]* getelementptr inbounds ([500 x [500 x i32]], [500 x [500 x i32]]* @path, i64 0, i64 0), i64 %16, !dbg !65
  %18 = sext i32 %.0 to i64, !dbg !65
  %19 = getelementptr inbounds [500 x i32], [500 x i32]* %17, i64 0, i64 %18, !dbg !65
  %20 = load i32, i32* %19, align 4, !dbg !65
  %21 = sext i32 %.0 to i64, !dbg !66
  %22 = getelementptr inbounds [500 x i32], [500 x i32]* getelementptr inbounds ([500 x [500 x i32]], [500 x [500 x i32]]* @path, i64 0, i64 0), i64 %21, !dbg !66
  %23 = sext i32 %.01 to i64, !dbg !66
  %24 = getelementptr inbounds [500 x i32], [500 x i32]* %22, i64 0, i64 %23, !dbg !66
  %25 = load i32, i32* %24, align 4, !dbg !66
  %26 = add nsw i32 %20, %25, !dbg !67
  %27 = icmp slt i32 %15, %26, !dbg !68
  br i1 %27, label %28, label %34, !dbg !64

28:                                               ; preds = %10
  %29 = sext i32 %.02 to i64, !dbg !69
  %30 = getelementptr inbounds [500 x i32], [500 x i32]* getelementptr inbounds ([500 x [500 x i32]], [500 x [500 x i32]]* @path, i64 0, i64 0), i64 %29, !dbg !69
  %31 = sext i32 %.01 to i64, !dbg !69
  %32 = getelementptr inbounds [500 x i32], [500 x i32]* %30, i64 0, i64 %31, !dbg !69
  %33 = load i32, i32* %32, align 4, !dbg !69
  br label %46, !dbg !64

34:                                               ; preds = %10
  %35 = sext i32 %.02 to i64, !dbg !70
  %36 = getelementptr inbounds [500 x i32], [500 x i32]* getelementptr inbounds ([500 x [500 x i32]], [500 x [500 x i32]]* @path, i64 0, i64 0), i64 %35, !dbg !70
  %37 = sext i32 %.0 to i64, !dbg !70
  %38 = getelementptr inbounds [500 x i32], [500 x i32]* %36, i64 0, i64 %37, !dbg !70
  %39 = load i32, i32* %38, align 4, !dbg !70
  %40 = sext i32 %.0 to i64, !dbg !71
  %41 = getelementptr inbounds [500 x i32], [500 x i32]* getelementptr inbounds ([500 x [500 x i32]], [500 x [500 x i32]]* @path, i64 0, i64 0), i64 %40, !dbg !71
  %42 = sext i32 %.01 to i64, !dbg !71
  %43 = getelementptr inbounds [500 x i32], [500 x i32]* %41, i64 0, i64 %42, !dbg !71
  %44 = load i32, i32* %43, align 4, !dbg !71
  %45 = add nsw i32 %39, %44, !dbg !72
  br label %46, !dbg !64

46:                                               ; preds = %34, %28
  %47 = phi i32 [ %33, %28 ], [ %45, %34 ], !dbg !64
  %48 = sext i32 %.02 to i64, !dbg !73
  %49 = getelementptr inbounds [500 x i32], [500 x i32]* getelementptr inbounds ([500 x [500 x i32]], [500 x [500 x i32]]* @path, i64 0, i64 0), i64 %48, !dbg !73
  %50 = sext i32 %.01 to i64, !dbg !73
  %51 = getelementptr inbounds [500 x i32], [500 x i32]* %49, i64 0, i64 %50, !dbg !73
  store i32 %47, i32* %51, align 4, !dbg !74
  %52 = add nsw i32 %.01, 1, !dbg !75
  call void @llvm.dbg.value(metadata i32 %52, metadata !57, metadata !DIExpression()), !dbg !39
  br label %8, !dbg !76, !llvm.loop !77

53:                                               ; preds = %8
  %54 = add nsw i32 %.02, 1, !dbg !80
  call void @llvm.dbg.value(metadata i32 %54, metadata !49, metadata !DIExpression()), !dbg !39
  br label %5, !dbg !81, !llvm.loop !82

55:                                               ; preds = %5
  %56 = add nsw i32 %.0, 1, !dbg !84
  call void @llvm.dbg.value(metadata i32 %56, metadata !42, metadata !DIExpression()), !dbg !39
  br label %2, !dbg !85, !llvm.loop !86

57:                                               ; preds = %2
  ret i32 0, !dbg !88
}

; Function Attrs: nofree nosync nounwind readnone speculatable willreturn
declare void @llvm.dbg.value(metadata, metadata, metadata) #1

attributes #0 = { noinline nounwind uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { nofree nosync nounwind readnone speculatable willreturn }

!llvm.dbg.cu = !{!2}
!llvm.module.flags = !{!15, !16, !17, !18, !19, !20, !21}
!llvm.ident = !{!22}

!0 = !DIGlobalVariableExpression(var: !1, expr: !DIExpression())
!1 = distinct !DIGlobalVariable(name: "n", scope: !2, file: !10, line: 93, type: !12, isLocal: false, isDefinition: true)
!2 = distinct !DICompileUnit(language: DW_LANG_C99, file: !3, producer: "Ubuntu clang version 14.0.0-1ubuntu1.1", isOptimized: false, runtimeVersion: 0, emissionKind: FullDebug, retainedTypes: !4, globals: !7, splitDebugInlining: false, nameTableKind: None)
!3 = !DIFile(filename: "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/affine-bounds-20260929/suite/floyd-warshall/source/workload.c", directory: "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/affine-bounds-20260929/suite/floyd-warshall/analysis-p", checksumkind: CSK_MD5, checksum: "829643a027e81ecd281897c0f8fc5926")
!4 = !{!5, !6}
!5 = !DIBasicType(name: "unsigned int", size: 32, encoding: DW_ATE_unsigned)
!6 = !DIBasicType(name: "unsigned char", size: 8, encoding: DW_ATE_unsigned_char)
!7 = !{!0, !8}
!8 = !DIGlobalVariableExpression(var: !9, expr: !DIExpression())
!9 = distinct !DIGlobalVariable(name: "path", scope: !2, file: !10, line: 34, type: !11, isLocal: false, isDefinition: true, align: 512)
!10 = !DIFile(filename: "source/workload.c", directory: "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/affine-bounds-20260929/suite/floyd-warshall", checksumkind: CSK_MD5, checksum: "829643a027e81ecd281897c0f8fc5926")
!11 = !DICompositeType(tag: DW_TAG_array_type, baseType: !12, size: 8000000, elements: !13)
!12 = !DIBasicType(name: "int", size: 32, encoding: DW_ATE_signed)
!13 = !{!14, !14}
!14 = !DISubrange(count: 500)
!15 = !{i32 7, !"Dwarf Version", i32 5}
!16 = !{i32 2, !"Debug Info Version", i32 3}
!17 = !{i32 1, !"wchar_size", i32 4}
!18 = !{i32 7, !"PIC Level", i32 2}
!19 = !{i32 7, !"PIE Level", i32 2}
!20 = !{i32 7, !"uwtable", i32 1}
!21 = !{i32 7, !"frame-pointer", i32 2}
!22 = !{!"Ubuntu clang version 14.0.0-1ubuntu1.1"}
!23 = distinct !DISubprogram(name: "task_job_polybench", scope: !10, file: !10, line: 100, type: !24, scopeLine: 100, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !2, retainedNodes: !30)
!24 = !DISubroutineType(types: !25)
!25 = !{!26}
!26 = !DIDerivedType(tag: DW_TAG_typedef, name: "uint32_t", file: !27, line: 26, baseType: !28)
!27 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/stdint-uintn.h", directory: "", checksumkind: CSK_MD5, checksum: "2bf2ae53c58c01b1a1b9383b5195125c")
!28 = !DIDerivedType(tag: DW_TAG_typedef, name: "__uint32_t", file: !29, line: 42, baseType: !5)
!29 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/types.h", directory: "", checksumkind: CSK_MD5, checksum: "d108b5f93a74c50510d7d9bc0ab36df9")
!30 = !{}
!31 = !DILocation(line: 101, column: 26, scope: !23)
!32 = !DILocalVariable(name: "n", arg: 1, scope: !33, file: !10, line: 74, type: !12)
!33 = distinct !DISubprogram(name: "kernel_floyd_warshall", scope: !10, file: !10, line: 74, type: !34, scopeLine: 76, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition, unit: !2, retainedNodes: !30)
!34 = !DISubroutineType(types: !35)
!35 = !{null, !12, !36}
!36 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !37, size: 64)
!37 = !DICompositeType(tag: DW_TAG_array_type, baseType: !12, size: 16000, elements: !38)
!38 = !{!14}
!39 = !DILocation(line: 0, scope: !33, inlinedAt: !40)
!40 = distinct !DILocation(line: 101, column: 3, scope: !23)
!41 = !DILocalVariable(name: "path", arg: 2, scope: !33, file: !10, line: 75, type: !36)
!42 = !DILocalVariable(name: "k", scope: !33, file: !10, line: 77, type: !12)
!43 = !DILocation(line: 80, column: 8, scope: !44, inlinedAt: !40)
!44 = distinct !DILexicalBlock(scope: !33, file: !10, line: 80, column: 3)
!45 = !DILocation(line: 0, scope: !44, inlinedAt: !40)
!46 = !DILocation(line: 80, column: 17, scope: !47, inlinedAt: !40)
!47 = distinct !DILexicalBlock(scope: !44, file: !10, line: 80, column: 3)
!48 = !DILocation(line: 80, column: 3, scope: !44, inlinedAt: !40)
!49 = !DILocalVariable(name: "i", scope: !33, file: !10, line: 77, type: !12)
!50 = !DILocation(line: 82, column: 11, scope: !51, inlinedAt: !40)
!51 = distinct !DILexicalBlock(scope: !52, file: !10, line: 82, column: 7)
!52 = distinct !DILexicalBlock(scope: !47, file: !10, line: 81, column: 5)
!53 = !DILocation(line: 0, scope: !51, inlinedAt: !40)
!54 = !DILocation(line: 82, column: 20, scope: !55, inlinedAt: !40)
!55 = distinct !DILexicalBlock(scope: !51, file: !10, line: 82, column: 7)
!56 = !DILocation(line: 82, column: 7, scope: !51, inlinedAt: !40)
!57 = !DILocalVariable(name: "j", scope: !33, file: !10, line: 77, type: !12)
!58 = !DILocation(line: 83, column: 7, scope: !59, inlinedAt: !40)
!59 = distinct !DILexicalBlock(scope: !55, file: !10, line: 83, column: 2)
!60 = !DILocation(line: 0, scope: !59, inlinedAt: !40)
!61 = !DILocation(line: 83, column: 16, scope: !62, inlinedAt: !40)
!62 = distinct !DILexicalBlock(scope: !59, file: !10, line: 83, column: 2)
!63 = !DILocation(line: 83, column: 2, scope: !59, inlinedAt: !40)
!64 = !DILocation(line: 84, column: 17, scope: !62, inlinedAt: !40)
!65 = !DILocation(line: 84, column: 30, scope: !62, inlinedAt: !40)
!66 = !DILocation(line: 84, column: 43, scope: !62, inlinedAt: !40)
!67 = !DILocation(line: 84, column: 41, scope: !62, inlinedAt: !40)
!68 = !DILocation(line: 84, column: 28, scope: !62, inlinedAt: !40)
!69 = !DILocation(line: 85, column: 6, scope: !62, inlinedAt: !40)
!70 = !DILocation(line: 85, column: 19, scope: !62, inlinedAt: !40)
!71 = !DILocation(line: 85, column: 32, scope: !62, inlinedAt: !40)
!72 = !DILocation(line: 85, column: 30, scope: !62, inlinedAt: !40)
!73 = !DILocation(line: 84, column: 4, scope: !62, inlinedAt: !40)
!74 = !DILocation(line: 84, column: 15, scope: !62, inlinedAt: !40)
!75 = !DILocation(line: 83, column: 26, scope: !62, inlinedAt: !40)
!76 = !DILocation(line: 83, column: 2, scope: !62, inlinedAt: !40)
!77 = distinct !{!77, !63, !78, !79}
!78 = !DILocation(line: 85, column: 41, scope: !59, inlinedAt: !40)
!79 = !{!"llvm.loop.mustprogress"}
!80 = !DILocation(line: 82, column: 30, scope: !55, inlinedAt: !40)
!81 = !DILocation(line: 82, column: 7, scope: !55, inlinedAt: !40)
!82 = distinct !{!82, !56, !83, !79}
!83 = !DILocation(line: 85, column: 41, scope: !51, inlinedAt: !40)
!84 = !DILocation(line: 80, column: 27, scope: !47, inlinedAt: !40)
!85 = !DILocation(line: 80, column: 3, scope: !47, inlinedAt: !40)
!86 = distinct !{!86, !48, !87, !79}
!87 = !DILocation(line: 86, column: 5, scope: !44, inlinedAt: !40)
!88 = !DILocation(line: 102, column: 3, scope: !23)
