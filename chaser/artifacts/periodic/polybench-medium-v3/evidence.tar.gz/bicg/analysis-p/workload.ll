; ModuleID = '/workspace/experiments-array-support/chaser/.cache/periodic-polybench/affine-bounds-20260929/suite/bicg/source/workload.c'
source_filename = "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/affine-bounds-20260929/suite/bicg/source/workload.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

%struct._IO_FILE = type { i32, i8*, i8*, i8*, i8*, i8*, i8*, i8*, i8*, i8*, i8*, i8*, %struct._IO_marker*, %struct._IO_FILE*, i32, i32, i64, i16, i8, [1 x i8], i8*, i64, %struct._IO_codecvt*, %struct._IO_wide_data*, %struct._IO_FILE*, i8*, i64, i32, [20 x i8] }
%struct._IO_marker = type opaque
%struct._IO_codecvt = type opaque
%struct._IO_wide_data = type opaque
%struct.__va_list_tag = type { i32, i32, i8*, i8* }

@n = dso_local global i32 410, align 4, !dbg !0
@m = dso_local global i32 390, align 4, !dbg !9
@A = dso_local global [410 x [390 x double]] zeroinitializer, section ".chaser_data.A", align 64, !dbg !33
@s = dso_local global [390 x double] zeroinitializer, section ".chaser_data.s", align 64, !dbg !39
@q = dso_local global [410 x double] zeroinitializer, section ".chaser_data.q", align 64, !dbg !43
@p = dso_local global [390 x double] zeroinitializer, section ".chaser_data.p", align 64, !dbg !47
@r = dso_local global [410 x double] zeroinitializer, section ".chaser_data.r", align 64, !dbg !49
@.str = private unnamed_addr constant [12 x i8] c"ape.analyze\00", section "llvm.metadata"
@.str.1 = private unnamed_addr constant [122 x i8] c"/workspace/experiments-array-support/chaser/.cache/periodic-polybench/affine-bounds-20260929/suite/bicg/source/workload.c\00", section "llvm.metadata"
@pb_hash = internal global i32 0, align 4, !dbg !30
@workload_jobs = dso_local constant [1 x i32 ()*] [i32 ()* @task_job_polybench], align 8, !dbg !13
@workload_expected = dso_local constant [1 x i32] [i32 -1587675741], align 4, !dbg !26
@stderr = external global %struct._IO_FILE*, align 8
@.str.2 = private unnamed_addr constant [23 x i8] c"==BEGIN DUMP_ARRAYS==\0A\00", align 1
@.str.3 = private unnamed_addr constant [15 x i8] c"begin dump: %s\00", align 1
@.str.4 = private unnamed_addr constant [2 x i8] c"s\00", align 1
@.str.5 = private unnamed_addr constant [2 x i8] c"\0A\00", align 1
@.str.6 = private unnamed_addr constant [8 x i8] c"%0.2lf \00", align 1
@.str.7 = private unnamed_addr constant [17 x i8] c"\0Aend   dump: %s\0A\00", align 1
@.str.8 = private unnamed_addr constant [2 x i8] c"q\00", align 1
@.str.9 = private unnamed_addr constant [23 x i8] c"==END   DUMP_ARRAYS==\0A\00", align 1
@pb_emit = internal global i32 1, align 4, !dbg !51
@llvm.global.annotations = appending global [1 x { i8*, i8*, i8*, i32, i8* }] [{ i8*, i8*, i8*, i32, i8* } { i8* bitcast (i32 ()* @task_job_polybench to i8*), i8* getelementptr inbounds ([12 x i8], [12 x i8]* @.str, i32 0, i32 0), i8* getelementptr inbounds ([122 x i8], [122 x i8]* @.str.1, i32 0, i32 0), i32 129, i8* null }], section "llvm.metadata"

; Function Attrs: noinline nounwind uwtable
define dso_local void @workload_prepare() #0 !dbg !61 {
  ret void, !dbg !65
}

; Function Attrs: noinline nounwind uwtable
define dso_local void @workload_reset(i32 noundef %0) #0 !dbg !66 {
  %2 = alloca i32, align 4
  store i32 %0, i32* %2, align 4
  call void @llvm.dbg.declare(metadata i32* %2, metadata !69, metadata !DIExpression()), !dbg !70
  %3 = load i32, i32* %2, align 4, !dbg !71
  call void @llvm.memset.p0i8.i64(i8* align 64 bitcast ([410 x [390 x double]]* @A to i8*), i8 0, i64 1279200, i1 false), !dbg !72
  call void @llvm.memset.p0i8.i64(i8* align 64 bitcast ([390 x double]* @s to i8*), i8 0, i64 3120, i1 false), !dbg !73
  call void @llvm.memset.p0i8.i64(i8* align 64 bitcast ([410 x double]* @q to i8*), i8 0, i64 3280, i1 false), !dbg !74
  call void @llvm.memset.p0i8.i64(i8* align 64 bitcast ([390 x double]* @p to i8*), i8 0, i64 3120, i1 false), !dbg !75
  call void @llvm.memset.p0i8.i64(i8* align 64 bitcast ([410 x double]* @r to i8*), i8 0, i64 3280, i1 false), !dbg !76
  %4 = load i32, i32* @m, align 4, !dbg !77
  %5 = load i32, i32* @n, align 4, !dbg !78
  call void @init_array(i32 noundef %4, i32 noundef %5, [390 x double]* noundef getelementptr inbounds ([410 x [390 x double]], [410 x [390 x double]]* @A, i64 0, i64 0), double* noundef getelementptr inbounds ([410 x double], [410 x double]* @r, i64 0, i64 0), double* noundef getelementptr inbounds ([390 x double], [390 x double]* @p, i64 0, i64 0)), !dbg !79
  ret void, !dbg !80
}

; Function Attrs: nofree nosync nounwind readnone speculatable willreturn
declare void @llvm.dbg.declare(metadata, metadata, metadata) #1

; Function Attrs: argmemonly nofree nounwind willreturn writeonly
declare void @llvm.memset.p0i8.i64(i8* nocapture writeonly, i8, i64, i1 immarg) #2

; Function Attrs: noinline nounwind uwtable
define internal void @init_array(i32 noundef %0, i32 noundef %1, [390 x double]* noundef %2, double* noundef %3, double* noundef %4) #0 !dbg !81 {
  %6 = alloca i32, align 4
  %7 = alloca i32, align 4
  %8 = alloca [390 x double]*, align 8
  %9 = alloca double*, align 8
  %10 = alloca double*, align 8
  %11 = alloca i32, align 4
  %12 = alloca i32, align 4
  store i32 %0, i32* %6, align 4
  call void @llvm.dbg.declare(metadata i32* %6, metadata !86, metadata !DIExpression()), !dbg !87
  store i32 %1, i32* %7, align 4
  call void @llvm.dbg.declare(metadata i32* %7, metadata !88, metadata !DIExpression()), !dbg !89
  store [390 x double]* %2, [390 x double]** %8, align 8
  call void @llvm.dbg.declare(metadata [390 x double]** %8, metadata !90, metadata !DIExpression()), !dbg !91
  store double* %3, double** %9, align 8
  call void @llvm.dbg.declare(metadata double** %9, metadata !92, metadata !DIExpression()), !dbg !93
  store double* %4, double** %10, align 8
  call void @llvm.dbg.declare(metadata double** %10, metadata !94, metadata !DIExpression()), !dbg !95
  call void @llvm.dbg.declare(metadata i32* %11, metadata !96, metadata !DIExpression()), !dbg !97
  call void @llvm.dbg.declare(metadata i32* %12, metadata !98, metadata !DIExpression()), !dbg !99
  store i32 0, i32* %11, align 4, !dbg !100
  br label %13, !dbg !102

13:                                               ; preds = %29, %5
  %14 = load i32, i32* %11, align 4, !dbg !103
  %15 = load i32, i32* %6, align 4, !dbg !105
  %16 = icmp slt i32 %14, %15, !dbg !106
  br i1 %16, label %17, label %32, !dbg !107

17:                                               ; preds = %13
  %18 = load i32, i32* %11, align 4, !dbg !108
  %19 = load i32, i32* %6, align 4, !dbg !109
  %20 = srem i32 %18, %19, !dbg !110
  %21 = sitofp i32 %20 to double, !dbg !111
  %22 = load i32, i32* %6, align 4, !dbg !112
  %23 = sitofp i32 %22 to double, !dbg !112
  %24 = fdiv double %21, %23, !dbg !113
  %25 = load double*, double** %10, align 8, !dbg !114
  %26 = load i32, i32* %11, align 4, !dbg !115
  %27 = sext i32 %26 to i64, !dbg !114
  %28 = getelementptr inbounds double, double* %25, i64 %27, !dbg !114
  store double %24, double* %28, align 8, !dbg !116
  br label %29, !dbg !114

29:                                               ; preds = %17
  %30 = load i32, i32* %11, align 4, !dbg !117
  %31 = add nsw i32 %30, 1, !dbg !117
  store i32 %31, i32* %11, align 4, !dbg !117
  br label %13, !dbg !118, !llvm.loop !119

32:                                               ; preds = %13
  store i32 0, i32* %11, align 4, !dbg !122
  br label %33, !dbg !124

33:                                               ; preds = %75, %32
  %34 = load i32, i32* %11, align 4, !dbg !125
  %35 = load i32, i32* %7, align 4, !dbg !127
  %36 = icmp slt i32 %34, %35, !dbg !128
  br i1 %36, label %37, label %78, !dbg !129

37:                                               ; preds = %33
  %38 = load i32, i32* %11, align 4, !dbg !130
  %39 = load i32, i32* %7, align 4, !dbg !132
  %40 = srem i32 %38, %39, !dbg !133
  %41 = sitofp i32 %40 to double, !dbg !134
  %42 = load i32, i32* %7, align 4, !dbg !135
  %43 = sitofp i32 %42 to double, !dbg !135
  %44 = fdiv double %41, %43, !dbg !136
  %45 = load double*, double** %9, align 8, !dbg !137
  %46 = load i32, i32* %11, align 4, !dbg !138
  %47 = sext i32 %46 to i64, !dbg !137
  %48 = getelementptr inbounds double, double* %45, i64 %47, !dbg !137
  store double %44, double* %48, align 8, !dbg !139
  store i32 0, i32* %12, align 4, !dbg !140
  br label %49, !dbg !142

49:                                               ; preds = %71, %37
  %50 = load i32, i32* %12, align 4, !dbg !143
  %51 = load i32, i32* %6, align 4, !dbg !145
  %52 = icmp slt i32 %50, %51, !dbg !146
  br i1 %52, label %53, label %74, !dbg !147

53:                                               ; preds = %49
  %54 = load i32, i32* %11, align 4, !dbg !148
  %55 = load i32, i32* %12, align 4, !dbg !149
  %56 = add nsw i32 %55, 1, !dbg !150
  %57 = mul nsw i32 %54, %56, !dbg !151
  %58 = load i32, i32* %7, align 4, !dbg !152
  %59 = srem i32 %57, %58, !dbg !153
  %60 = sitofp i32 %59 to double, !dbg !154
  %61 = load i32, i32* %7, align 4, !dbg !155
  %62 = sitofp i32 %61 to double, !dbg !155
  %63 = fdiv double %60, %62, !dbg !156
  %64 = load [390 x double]*, [390 x double]** %8, align 8, !dbg !157
  %65 = load i32, i32* %11, align 4, !dbg !158
  %66 = sext i32 %65 to i64, !dbg !157
  %67 = getelementptr inbounds [390 x double], [390 x double]* %64, i64 %66, !dbg !157
  %68 = load i32, i32* %12, align 4, !dbg !159
  %69 = sext i32 %68 to i64, !dbg !157
  %70 = getelementptr inbounds [390 x double], [390 x double]* %67, i64 0, i64 %69, !dbg !157
  store double %63, double* %70, align 8, !dbg !160
  br label %71, !dbg !157

71:                                               ; preds = %53
  %72 = load i32, i32* %12, align 4, !dbg !161
  %73 = add nsw i32 %72, 1, !dbg !161
  store i32 %73, i32* %12, align 4, !dbg !161
  br label %49, !dbg !162, !llvm.loop !163

74:                                               ; preds = %49
  br label %75, !dbg !165

75:                                               ; preds = %74
  %76 = load i32, i32* %11, align 4, !dbg !166
  %77 = add nsw i32 %76, 1, !dbg !166
  store i32 %77, i32* %11, align 4, !dbg !166
  br label %33, !dbg !167, !llvm.loop !168

78:                                               ; preds = %33
  ret void, !dbg !170
}

; Function Attrs: noinline nounwind uwtable
define dso_local i32 @task_job_polybench() #0 !dbg !171 {
  %1 = alloca i32, align 4
  %2 = alloca i32, align 4
  %3 = alloca [390 x double]*, align 8
  %4 = alloca double*, align 8
  %5 = alloca double*, align 8
  %6 = alloca double*, align 8
  %7 = alloca double*, align 8
  %8 = alloca i32, align 4
  %9 = alloca i32, align 4
  %10 = load i32, i32* @m, align 4, !dbg !172
  %11 = load i32, i32* @n, align 4, !dbg !173
  store i32 %10, i32* %1, align 4
  call void @llvm.dbg.declare(metadata i32* %1, metadata !174, metadata !DIExpression()), !dbg !178
  store i32 %11, i32* %2, align 4
  call void @llvm.dbg.declare(metadata i32* %2, metadata !180, metadata !DIExpression()), !dbg !181
  store [390 x double]* getelementptr inbounds ([410 x [390 x double]], [410 x [390 x double]]* @A, i64 0, i64 0), [390 x double]** %3, align 8
  call void @llvm.dbg.declare(metadata [390 x double]** %3, metadata !182, metadata !DIExpression()), !dbg !183
  store double* getelementptr inbounds ([390 x double], [390 x double]* @s, i64 0, i64 0), double** %4, align 8
  call void @llvm.dbg.declare(metadata double** %4, metadata !184, metadata !DIExpression()), !dbg !185
  store double* getelementptr inbounds ([410 x double], [410 x double]* @q, i64 0, i64 0), double** %5, align 8
  call void @llvm.dbg.declare(metadata double** %5, metadata !186, metadata !DIExpression()), !dbg !187
  store double* getelementptr inbounds ([390 x double], [390 x double]* @p, i64 0, i64 0), double** %6, align 8
  call void @llvm.dbg.declare(metadata double** %6, metadata !188, metadata !DIExpression()), !dbg !189
  store double* getelementptr inbounds ([410 x double], [410 x double]* @r, i64 0, i64 0), double** %7, align 8
  call void @llvm.dbg.declare(metadata double** %7, metadata !190, metadata !DIExpression()), !dbg !191
  call void @llvm.dbg.declare(metadata i32* %8, metadata !192, metadata !DIExpression()), !dbg !193
  call void @llvm.dbg.declare(metadata i32* %9, metadata !194, metadata !DIExpression()), !dbg !195
  store i32 0, i32* %8, align 4, !dbg !196
  br label %12, !dbg !198

12:                                               ; preds = %15, %0
  %13 = load i32, i32* %8, align 4, !dbg !199
  %14 = icmp slt i32 %13, 390, !dbg !201
  br i1 %14, label %15, label %22, !dbg !202

15:                                               ; preds = %12
  %16 = load double*, double** %4, align 8, !dbg !203
  %17 = load i32, i32* %8, align 4, !dbg !204
  %18 = sext i32 %17 to i64, !dbg !203
  %19 = getelementptr inbounds double, double* %16, i64 %18, !dbg !203
  store double 0.000000e+00, double* %19, align 8, !dbg !205
  %20 = load i32, i32* %8, align 4, !dbg !206
  %21 = add nsw i32 %20, 1, !dbg !206
  store i32 %21, i32* %8, align 4, !dbg !206
  br label %12, !dbg !207, !llvm.loop !208

22:                                               ; preds = %12
  store i32 0, i32* %8, align 4, !dbg !210
  br label %23, !dbg !212

23:                                               ; preds = %85, %22
  %24 = load i32, i32* %8, align 4, !dbg !213
  %25 = icmp slt i32 %24, 410, !dbg !215
  br i1 %25, label %26, label %88, !dbg !216

26:                                               ; preds = %23
  %27 = load double*, double** %5, align 8, !dbg !217
  %28 = load i32, i32* %8, align 4, !dbg !219
  %29 = sext i32 %28 to i64, !dbg !217
  %30 = getelementptr inbounds double, double* %27, i64 %29, !dbg !217
  store double 0.000000e+00, double* %30, align 8, !dbg !220
  store i32 0, i32* %9, align 4, !dbg !221
  br label %31, !dbg !223

31:                                               ; preds = %34, %26
  %32 = load i32, i32* %9, align 4, !dbg !224
  %33 = icmp slt i32 %32, 390, !dbg !226
  br i1 %33, label %34, label %85, !dbg !227

34:                                               ; preds = %31
  %35 = load double*, double** %4, align 8, !dbg !228
  %36 = load i32, i32* %9, align 4, !dbg !230
  %37 = sext i32 %36 to i64, !dbg !228
  %38 = getelementptr inbounds double, double* %35, i64 %37, !dbg !228
  %39 = load double, double* %38, align 8, !dbg !228
  %40 = load double*, double** %7, align 8, !dbg !231
  %41 = load i32, i32* %8, align 4, !dbg !232
  %42 = sext i32 %41 to i64, !dbg !231
  %43 = getelementptr inbounds double, double* %40, i64 %42, !dbg !231
  %44 = load double, double* %43, align 8, !dbg !231
  %45 = load [390 x double]*, [390 x double]** %3, align 8, !dbg !233
  %46 = load i32, i32* %8, align 4, !dbg !234
  %47 = sext i32 %46 to i64, !dbg !233
  %48 = getelementptr inbounds [390 x double], [390 x double]* %45, i64 %47, !dbg !233
  %49 = load i32, i32* %9, align 4, !dbg !235
  %50 = sext i32 %49 to i64, !dbg !233
  %51 = getelementptr inbounds [390 x double], [390 x double]* %48, i64 0, i64 %50, !dbg !233
  %52 = load double, double* %51, align 8, !dbg !233
  %53 = fmul double %44, %52, !dbg !236
  %54 = fadd double %39, %53, !dbg !237
  %55 = load double*, double** %4, align 8, !dbg !238
  %56 = load i32, i32* %9, align 4, !dbg !239
  %57 = sext i32 %56 to i64, !dbg !238
  %58 = getelementptr inbounds double, double* %55, i64 %57, !dbg !238
  store double %54, double* %58, align 8, !dbg !240
  %59 = load double*, double** %5, align 8, !dbg !241
  %60 = load i32, i32* %8, align 4, !dbg !242
  %61 = sext i32 %60 to i64, !dbg !241
  %62 = getelementptr inbounds double, double* %59, i64 %61, !dbg !241
  %63 = load double, double* %62, align 8, !dbg !241
  %64 = load [390 x double]*, [390 x double]** %3, align 8, !dbg !243
  %65 = load i32, i32* %8, align 4, !dbg !244
  %66 = sext i32 %65 to i64, !dbg !243
  %67 = getelementptr inbounds [390 x double], [390 x double]* %64, i64 %66, !dbg !243
  %68 = load i32, i32* %9, align 4, !dbg !245
  %69 = sext i32 %68 to i64, !dbg !243
  %70 = getelementptr inbounds [390 x double], [390 x double]* %67, i64 0, i64 %69, !dbg !243
  %71 = load double, double* %70, align 8, !dbg !243
  %72 = load double*, double** %6, align 8, !dbg !246
  %73 = load i32, i32* %9, align 4, !dbg !247
  %74 = sext i32 %73 to i64, !dbg !246
  %75 = getelementptr inbounds double, double* %72, i64 %74, !dbg !246
  %76 = load double, double* %75, align 8, !dbg !246
  %77 = fmul double %71, %76, !dbg !248
  %78 = fadd double %63, %77, !dbg !249
  %79 = load double*, double** %5, align 8, !dbg !250
  %80 = load i32, i32* %8, align 4, !dbg !251
  %81 = sext i32 %80 to i64, !dbg !250
  %82 = getelementptr inbounds double, double* %79, i64 %81, !dbg !250
  store double %78, double* %82, align 8, !dbg !252
  %83 = load i32, i32* %9, align 4, !dbg !253
  %84 = add nsw i32 %83, 1, !dbg !253
  store i32 %84, i32* %9, align 4, !dbg !253
  br label %31, !dbg !254, !llvm.loop !255

85:                                               ; preds = %31
  %86 = load i32, i32* %8, align 4, !dbg !257
  %87 = add nsw i32 %86, 1, !dbg !257
  store i32 %87, i32* %8, align 4, !dbg !257
  br label %23, !dbg !258, !llvm.loop !259

88:                                               ; preds = %23
  ret i32 0, !dbg !261
}

; Function Attrs: noinline nounwind uwtable
define dso_local i32 @workload_checksum(i32 noundef %0) #0 !dbg !262 {
  %2 = alloca i32, align 4
  store i32 %0, i32* %2, align 4
  call void @llvm.dbg.declare(metadata i32* %2, metadata !265, metadata !DIExpression()), !dbg !266
  %3 = load i32, i32* %2, align 4, !dbg !267
  store i32 -2128831035, i32* @pb_hash, align 4, !dbg !268
  %4 = load i32, i32* @m, align 4, !dbg !269
  %5 = load i32, i32* @n, align 4, !dbg !270
  call void @print_array(i32 noundef %4, i32 noundef %5, double* noundef getelementptr inbounds ([390 x double], [390 x double]* @s, i64 0, i64 0), double* noundef getelementptr inbounds ([410 x double], [410 x double]* @q, i64 0, i64 0)), !dbg !271
  %6 = load i32, i32* @pb_hash, align 4, !dbg !272
  ret i32 %6, !dbg !273
}

; Function Attrs: noinline nounwind uwtable
define internal void @print_array(i32 noundef %0, i32 noundef %1, double* noundef %2, double* noundef %3) #0 !dbg !274 {
  %5 = alloca i32, align 4
  %6 = alloca i32, align 4
  %7 = alloca double*, align 8
  %8 = alloca double*, align 8
  %9 = alloca i32, align 4
  store i32 %0, i32* %5, align 4
  call void @llvm.dbg.declare(metadata i32* %5, metadata !277, metadata !DIExpression()), !dbg !278
  store i32 %1, i32* %6, align 4
  call void @llvm.dbg.declare(metadata i32* %6, metadata !279, metadata !DIExpression()), !dbg !280
  store double* %2, double** %7, align 8
  call void @llvm.dbg.declare(metadata double** %7, metadata !281, metadata !DIExpression()), !dbg !282
  store double* %3, double** %8, align 8
  call void @llvm.dbg.declare(metadata double** %8, metadata !283, metadata !DIExpression()), !dbg !284
  call void @llvm.dbg.declare(metadata i32* %9, metadata !285, metadata !DIExpression()), !dbg !286
  %10 = load %struct._IO_FILE*, %struct._IO_FILE** @stderr, align 8, !dbg !287
  %11 = call i32 (%struct._IO_FILE*, i8*, ...) @pb_fprintf(%struct._IO_FILE* noundef %10, i8* noundef getelementptr inbounds ([23 x i8], [23 x i8]* @.str.2, i64 0, i64 0)), !dbg !287
  %12 = load %struct._IO_FILE*, %struct._IO_FILE** @stderr, align 8, !dbg !288
  %13 = call i32 (%struct._IO_FILE*, i8*, ...) @pb_fprintf(%struct._IO_FILE* noundef %12, i8* noundef getelementptr inbounds ([15 x i8], [15 x i8]* @.str.3, i64 0, i64 0), i8* noundef getelementptr inbounds ([2 x i8], [2 x i8]* @.str.4, i64 0, i64 0)), !dbg !288
  store i32 0, i32* %9, align 4, !dbg !289
  br label %14, !dbg !291

14:                                               ; preds = %33, %4
  %15 = load i32, i32* %9, align 4, !dbg !292
  %16 = load i32, i32* %5, align 4, !dbg !294
  %17 = icmp slt i32 %15, %16, !dbg !295
  br i1 %17, label %18, label %36, !dbg !296

18:                                               ; preds = %14
  %19 = load i32, i32* %9, align 4, !dbg !297
  %20 = srem i32 %19, 20, !dbg !300
  %21 = icmp eq i32 %20, 0, !dbg !301
  br i1 %21, label %22, label %25, !dbg !302

22:                                               ; preds = %18
  %23 = load %struct._IO_FILE*, %struct._IO_FILE** @stderr, align 8, !dbg !303
  %24 = call i32 (%struct._IO_FILE*, i8*, ...) @pb_fprintf(%struct._IO_FILE* noundef %23, i8* noundef getelementptr inbounds ([2 x i8], [2 x i8]* @.str.5, i64 0, i64 0)), !dbg !304
  br label %25, !dbg !304

25:                                               ; preds = %22, %18
  %26 = load %struct._IO_FILE*, %struct._IO_FILE** @stderr, align 8, !dbg !305
  %27 = load double*, double** %7, align 8, !dbg !306
  %28 = load i32, i32* %9, align 4, !dbg !307
  %29 = sext i32 %28 to i64, !dbg !306
  %30 = getelementptr inbounds double, double* %27, i64 %29, !dbg !306
  %31 = load double, double* %30, align 8, !dbg !306
  %32 = call i32 (%struct._IO_FILE*, i8*, ...) @pb_fprintf(%struct._IO_FILE* noundef %26, i8* noundef getelementptr inbounds ([8 x i8], [8 x i8]* @.str.6, i64 0, i64 0), double noundef %31), !dbg !308
  br label %33, !dbg !309

33:                                               ; preds = %25
  %34 = load i32, i32* %9, align 4, !dbg !310
  %35 = add nsw i32 %34, 1, !dbg !310
  store i32 %35, i32* %9, align 4, !dbg !310
  br label %14, !dbg !311, !llvm.loop !312

36:                                               ; preds = %14
  %37 = load %struct._IO_FILE*, %struct._IO_FILE** @stderr, align 8, !dbg !314
  %38 = call i32 (%struct._IO_FILE*, i8*, ...) @pb_fprintf(%struct._IO_FILE* noundef %37, i8* noundef getelementptr inbounds ([17 x i8], [17 x i8]* @.str.7, i64 0, i64 0), i8* noundef getelementptr inbounds ([2 x i8], [2 x i8]* @.str.4, i64 0, i64 0)), !dbg !314
  %39 = load %struct._IO_FILE*, %struct._IO_FILE** @stderr, align 8, !dbg !315
  %40 = call i32 (%struct._IO_FILE*, i8*, ...) @pb_fprintf(%struct._IO_FILE* noundef %39, i8* noundef getelementptr inbounds ([15 x i8], [15 x i8]* @.str.3, i64 0, i64 0), i8* noundef getelementptr inbounds ([2 x i8], [2 x i8]* @.str.8, i64 0, i64 0)), !dbg !315
  store i32 0, i32* %9, align 4, !dbg !316
  br label %41, !dbg !318

41:                                               ; preds = %60, %36
  %42 = load i32, i32* %9, align 4, !dbg !319
  %43 = load i32, i32* %6, align 4, !dbg !321
  %44 = icmp slt i32 %42, %43, !dbg !322
  br i1 %44, label %45, label %63, !dbg !323

45:                                               ; preds = %41
  %46 = load i32, i32* %9, align 4, !dbg !324
  %47 = srem i32 %46, 20, !dbg !327
  %48 = icmp eq i32 %47, 0, !dbg !328
  br i1 %48, label %49, label %52, !dbg !329

49:                                               ; preds = %45
  %50 = load %struct._IO_FILE*, %struct._IO_FILE** @stderr, align 8, !dbg !330
  %51 = call i32 (%struct._IO_FILE*, i8*, ...) @pb_fprintf(%struct._IO_FILE* noundef %50, i8* noundef getelementptr inbounds ([2 x i8], [2 x i8]* @.str.5, i64 0, i64 0)), !dbg !331
  br label %52, !dbg !331

52:                                               ; preds = %49, %45
  %53 = load %struct._IO_FILE*, %struct._IO_FILE** @stderr, align 8, !dbg !332
  %54 = load double*, double** %8, align 8, !dbg !333
  %55 = load i32, i32* %9, align 4, !dbg !334
  %56 = sext i32 %55 to i64, !dbg !333
  %57 = getelementptr inbounds double, double* %54, i64 %56, !dbg !333
  %58 = load double, double* %57, align 8, !dbg !333
  %59 = call i32 (%struct._IO_FILE*, i8*, ...) @pb_fprintf(%struct._IO_FILE* noundef %53, i8* noundef getelementptr inbounds ([8 x i8], [8 x i8]* @.str.6, i64 0, i64 0), double noundef %58), !dbg !335
  br label %60, !dbg !336

60:                                               ; preds = %52
  %61 = load i32, i32* %9, align 4, !dbg !337
  %62 = add nsw i32 %61, 1, !dbg !337
  store i32 %62, i32* %9, align 4, !dbg !337
  br label %41, !dbg !338, !llvm.loop !339

63:                                               ; preds = %41
  %64 = load %struct._IO_FILE*, %struct._IO_FILE** @stderr, align 8, !dbg !341
  %65 = call i32 (%struct._IO_FILE*, i8*, ...) @pb_fprintf(%struct._IO_FILE* noundef %64, i8* noundef getelementptr inbounds ([17 x i8], [17 x i8]* @.str.7, i64 0, i64 0), i8* noundef getelementptr inbounds ([2 x i8], [2 x i8]* @.str.8, i64 0, i64 0)), !dbg !341
  %66 = load %struct._IO_FILE*, %struct._IO_FILE** @stderr, align 8, !dbg !342
  %67 = call i32 (%struct._IO_FILE*, i8*, ...) @pb_fprintf(%struct._IO_FILE* noundef %66, i8* noundef getelementptr inbounds ([23 x i8], [23 x i8]* @.str.9, i64 0, i64 0)), !dbg !342
  ret void, !dbg !343
}

; Function Attrs: noinline nounwind uwtable
define internal i32 @pb_fprintf(%struct._IO_FILE* noundef %0, i8* noundef %1, ...) #0 !dbg !344 {
  %3 = alloca %struct._IO_FILE*, align 8
  %4 = alloca i8*, align 8
  %5 = alloca [768 x i8], align 16
  %6 = alloca [1 x %struct.__va_list_tag], align 16
  %7 = alloca i32, align 4
  %8 = alloca i32, align 4
  store %struct._IO_FILE* %0, %struct._IO_FILE** %3, align 8
  call void @llvm.dbg.declare(metadata %struct._IO_FILE** %3, metadata !408, metadata !DIExpression()), !dbg !409
  store i8* %1, i8** %4, align 8
  call void @llvm.dbg.declare(metadata i8** %4, metadata !410, metadata !DIExpression()), !dbg !411
  call void @llvm.dbg.declare(metadata [768 x i8]* %5, metadata !412, metadata !DIExpression()), !dbg !416
  call void @llvm.dbg.declare(metadata [1 x %struct.__va_list_tag]* %6, metadata !417, metadata !DIExpression()), !dbg !431
  %9 = getelementptr inbounds [1 x %struct.__va_list_tag], [1 x %struct.__va_list_tag]* %6, i64 0, i64 0, !dbg !432
  %10 = bitcast %struct.__va_list_tag* %9 to i8*, !dbg !432
  call void @llvm.va_start(i8* %10), !dbg !432
  call void @llvm.dbg.declare(metadata i32* %7, metadata !433, metadata !DIExpression()), !dbg !434
  %11 = getelementptr inbounds [768 x i8], [768 x i8]* %5, i64 0, i64 0, !dbg !435
  %12 = load i8*, i8** %4, align 8, !dbg !436
  %13 = getelementptr inbounds [1 x %struct.__va_list_tag], [1 x %struct.__va_list_tag]* %6, i64 0, i64 0, !dbg !437
  %14 = call i32 @vsnprintf(i8* noundef %11, i64 noundef 768, i8* noundef %12, %struct.__va_list_tag* noundef %13) #6, !dbg !438
  store i32 %14, i32* %7, align 4, !dbg !434
  %15 = getelementptr inbounds [1 x %struct.__va_list_tag], [1 x %struct.__va_list_tag]* %6, i64 0, i64 0, !dbg !439
  %16 = bitcast %struct.__va_list_tag* %15 to i8*, !dbg !439
  call void @llvm.va_end(i8* %16), !dbg !439
  %17 = load i32, i32* %7, align 4, !dbg !440
  %18 = icmp slt i32 %17, 0, !dbg !442
  br i1 %18, label %23, label %19, !dbg !443

19:                                               ; preds = %2
  %20 = load i32, i32* %7, align 4, !dbg !444
  %21 = zext i32 %20 to i64, !dbg !445
  %22 = icmp uge i64 %21, 768, !dbg !446
  br i1 %22, label %23, label %24, !dbg !447

23:                                               ; preds = %19, %2
  call void @abort() #7, !dbg !448
  unreachable, !dbg !448

24:                                               ; preds = %19
  call void @llvm.dbg.declare(metadata i32* %8, metadata !449, metadata !DIExpression()), !dbg !451
  store i32 0, i32* %8, align 4, !dbg !451
  br label %25, !dbg !452

25:                                               ; preds = %39, %24
  %26 = load i32, i32* %8, align 4, !dbg !453
  %27 = load i32, i32* %7, align 4, !dbg !455
  %28 = icmp slt i32 %26, %27, !dbg !456
  br i1 %28, label %29, label %42, !dbg !457

29:                                               ; preds = %25
  %30 = load i32, i32* %8, align 4, !dbg !458
  %31 = sext i32 %30 to i64, !dbg !460
  %32 = getelementptr inbounds [768 x i8], [768 x i8]* %5, i64 0, i64 %31, !dbg !460
  %33 = load i8, i8* %32, align 1, !dbg !460
  %34 = zext i8 %33 to i32, !dbg !461
  %35 = load i32, i32* @pb_hash, align 4, !dbg !462
  %36 = xor i32 %35, %34, !dbg !462
  store i32 %36, i32* @pb_hash, align 4, !dbg !462
  %37 = load i32, i32* @pb_hash, align 4, !dbg !463
  %38 = mul i32 %37, 16777619, !dbg !463
  store i32 %38, i32* @pb_hash, align 4, !dbg !463
  br label %39, !dbg !464

39:                                               ; preds = %29
  %40 = load i32, i32* %8, align 4, !dbg !465
  %41 = add nsw i32 %40, 1, !dbg !465
  store i32 %41, i32* %8, align 4, !dbg !465
  br label %25, !dbg !466, !llvm.loop !467

42:                                               ; preds = %25
  %43 = load %struct._IO_FILE*, %struct._IO_FILE** %3, align 8, !dbg !469
  %44 = load i32, i32* @pb_emit, align 4, !dbg !470
  %45 = load i32, i32* %7, align 4, !dbg !471
  ret i32 %45, !dbg !472
}

; Function Attrs: nofree nosync nounwind willreturn
declare void @llvm.va_start(i8*) #3

; Function Attrs: nounwind
declare i32 @vsnprintf(i8* noundef, i64 noundef, i8* noundef, %struct.__va_list_tag* noundef) #4

; Function Attrs: nofree nosync nounwind willreturn
declare void @llvm.va_end(i8*) #3

; Function Attrs: noreturn nounwind
declare void @abort() #5

attributes #0 = { noinline nounwind uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { nofree nosync nounwind readnone speculatable willreturn }
attributes #2 = { argmemonly nofree nounwind willreturn writeonly }
attributes #3 = { nofree nosync nounwind willreturn }
attributes #4 = { nounwind "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #5 = { noreturn nounwind "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #6 = { nounwind }
attributes #7 = { noreturn nounwind }

!llvm.dbg.cu = !{!2}
!llvm.module.flags = !{!53, !54, !55, !56, !57, !58, !59}
!llvm.ident = !{!60}

!0 = !DIGlobalVariableExpression(var: !1, expr: !DIExpression())
!1 = distinct !DIGlobalVariable(name: "n", scope: !2, file: !11, line: 114, type: !12, isLocal: false, isDefinition: true)
!2 = distinct !DICompileUnit(language: DW_LANG_C99, file: !3, producer: "Ubuntu clang version 14.0.0-1ubuntu1.1", isOptimized: false, runtimeVersion: 0, emissionKind: FullDebug, retainedTypes: !4, globals: !8, splitDebugInlining: false, nameTableKind: None)
!3 = !DIFile(filename: "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/affine-bounds-20260929/suite/bicg/source/workload.c", directory: "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/affine-bounds-20260929/suite/bicg/analysis-p", checksumkind: CSK_MD5, checksum: "e8f798e8b436f689a83dca6308f17ffb")
!4 = !{!5, !6, !7}
!5 = !DIBasicType(name: "double", size: 64, encoding: DW_ATE_float)
!6 = !DIBasicType(name: "unsigned int", size: 32, encoding: DW_ATE_unsigned)
!7 = !DIBasicType(name: "unsigned char", size: 8, encoding: DW_ATE_unsigned_char)
!8 = !{!0, !9, !13, !26, !30, !33, !39, !43, !47, !49, !51}
!9 = !DIGlobalVariableExpression(var: !10, expr: !DIExpression())
!10 = distinct !DIGlobalVariable(name: "m", scope: !2, file: !11, line: 115, type: !12, isLocal: false, isDefinition: true)
!11 = !DIFile(filename: "source/workload.c", directory: "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/affine-bounds-20260929/suite/bicg", checksumkind: CSK_MD5, checksum: "e8f798e8b436f689a83dca6308f17ffb")
!12 = !DIBasicType(name: "int", size: 32, encoding: DW_ATE_signed)
!13 = !DIGlobalVariableExpression(var: !14, expr: !DIExpression())
!14 = distinct !DIGlobalVariable(name: "workload_jobs", scope: !2, file: !11, line: 144, type: !15, isLocal: false, isDefinition: true)
!15 = !DICompositeType(tag: DW_TAG_array_type, baseType: !16, size: 64, elements: !24)
!16 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !17)
!17 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !18, size: 64)
!18 = !DISubroutineType(types: !19)
!19 = !{!20}
!20 = !DIDerivedType(tag: DW_TAG_typedef, name: "uint32_t", file: !21, line: 26, baseType: !22)
!21 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/stdint-uintn.h", directory: "", checksumkind: CSK_MD5, checksum: "2bf2ae53c58c01b1a1b9383b5195125c")
!22 = !DIDerivedType(tag: DW_TAG_typedef, name: "__uint32_t", file: !23, line: 42, baseType: !6)
!23 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/types.h", directory: "", checksumkind: CSK_MD5, checksum: "d108b5f93a74c50510d7d9bc0ab36df9")
!24 = !{!25}
!25 = !DISubrange(count: 1)
!26 = !DIGlobalVariableExpression(var: !27, expr: !DIExpression())
!27 = distinct !DIGlobalVariable(name: "workload_expected", scope: !2, file: !11, line: 148, type: !28, isLocal: false, isDefinition: true)
!28 = !DICompositeType(tag: DW_TAG_array_type, baseType: !29, size: 32, elements: !24)
!29 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !20)
!30 = !DIGlobalVariableExpression(var: !31, expr: !DIExpression())
!31 = distinct !DIGlobalVariable(name: "pb_hash", scope: !2, file: !32, line: 9, type: !20, isLocal: true, isDefinition: true)
!32 = !DIFile(filename: "source/adapter.h", directory: "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/affine-bounds-20260929/suite/bicg", checksumkind: CSK_MD5, checksum: "26a6068928b2092758f244a9d00163d7")
!33 = !DIGlobalVariableExpression(var: !34, expr: !DIExpression())
!34 = distinct !DIGlobalVariable(name: "A", scope: !2, file: !11, line: 34, type: !35, isLocal: false, isDefinition: true, align: 512)
!35 = !DICompositeType(tag: DW_TAG_array_type, baseType: !5, size: 10233600, elements: !36)
!36 = !{!37, !38}
!37 = !DISubrange(count: 410)
!38 = !DISubrange(count: 390)
!39 = !DIGlobalVariableExpression(var: !40, expr: !DIExpression())
!40 = distinct !DIGlobalVariable(name: "s", scope: !2, file: !11, line: 35, type: !41, isLocal: false, isDefinition: true, align: 512)
!41 = !DICompositeType(tag: DW_TAG_array_type, baseType: !5, size: 24960, elements: !42)
!42 = !{!38}
!43 = !DIGlobalVariableExpression(var: !44, expr: !DIExpression())
!44 = distinct !DIGlobalVariable(name: "q", scope: !2, file: !11, line: 36, type: !45, isLocal: false, isDefinition: true, align: 512)
!45 = !DICompositeType(tag: DW_TAG_array_type, baseType: !5, size: 26240, elements: !46)
!46 = !{!37}
!47 = !DIGlobalVariableExpression(var: !48, expr: !DIExpression())
!48 = distinct !DIGlobalVariable(name: "p", scope: !2, file: !11, line: 37, type: !41, isLocal: false, isDefinition: true, align: 512)
!49 = !DIGlobalVariableExpression(var: !50, expr: !DIExpression())
!50 = distinct !DIGlobalVariable(name: "r", scope: !2, file: !11, line: 38, type: !45, isLocal: false, isDefinition: true, align: 512)
!51 = !DIGlobalVariableExpression(var: !52, expr: !DIExpression())
!52 = distinct !DIGlobalVariable(name: "pb_emit", scope: !2, file: !32, line: 10, type: !12, isLocal: true, isDefinition: true)
!53 = !{i32 7, !"Dwarf Version", i32 5}
!54 = !{i32 2, !"Debug Info Version", i32 3}
!55 = !{i32 1, !"wchar_size", i32 4}
!56 = !{i32 7, !"PIC Level", i32 2}
!57 = !{i32 7, !"PIE Level", i32 2}
!58 = !{i32 7, !"uwtable", i32 1}
!59 = !{i32 7, !"frame-pointer", i32 2}
!60 = !{!"Ubuntu clang version 14.0.0-1ubuntu1.1"}
!61 = distinct !DISubprogram(name: "workload_prepare", scope: !11, file: !11, line: 116, type: !62, scopeLine: 116, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !2, retainedNodes: !64)
!62 = !DISubroutineType(types: !63)
!63 = !{null}
!64 = !{}
!65 = !DILocation(line: 116, column: 30, scope: !61)
!66 = distinct !DISubprogram(name: "workload_reset", scope: !11, file: !11, line: 117, type: !67, scopeLine: 117, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !2, retainedNodes: !64)
!67 = !DISubroutineType(types: !68)
!68 = !{null, !6}
!69 = !DILocalVariable(name: "task", arg: 1, scope: !66, file: !11, line: 117, type: !6)
!70 = !DILocation(line: 117, column: 30, scope: !66)
!71 = !DILocation(line: 118, column: 9, scope: !66)
!72 = !DILocation(line: 119, column: 3, scope: !66)
!73 = !DILocation(line: 120, column: 3, scope: !66)
!74 = !DILocation(line: 121, column: 3, scope: !66)
!75 = !DILocation(line: 122, column: 3, scope: !66)
!76 = !DILocation(line: 123, column: 3, scope: !66)
!77 = !DILocation(line: 124, column: 15, scope: !66)
!78 = !DILocation(line: 124, column: 18, scope: !66)
!79 = !DILocation(line: 124, column: 3, scope: !66)
!80 = !DILocation(line: 128, column: 1, scope: !66)
!81 = distinct !DISubprogram(name: "init_array", scope: !11, file: !11, line: 40, type: !82, scopeLine: 44, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition, unit: !2, retainedNodes: !64)
!82 = !DISubroutineType(types: !83)
!83 = !{null, !12, !12, !84, !85, !85}
!84 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !41, size: 64)
!85 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !5, size: 64)
!86 = !DILocalVariable(name: "m", arg: 1, scope: !81, file: !11, line: 40, type: !12)
!87 = !DILocation(line: 40, column: 22, scope: !81)
!88 = !DILocalVariable(name: "n", arg: 2, scope: !81, file: !11, line: 40, type: !12)
!89 = !DILocation(line: 40, column: 29, scope: !81)
!90 = !DILocalVariable(name: "A", arg: 3, scope: !81, file: !11, line: 41, type: !84)
!91 = !DILocation(line: 41, column: 14, scope: !81)
!92 = !DILocalVariable(name: "r", arg: 4, scope: !81, file: !11, line: 42, type: !85)
!93 = !DILocation(line: 42, column: 14, scope: !81)
!94 = !DILocalVariable(name: "p", arg: 5, scope: !81, file: !11, line: 43, type: !85)
!95 = !DILocation(line: 43, column: 14, scope: !81)
!96 = !DILocalVariable(name: "i", scope: !81, file: !11, line: 45, type: !12)
!97 = !DILocation(line: 45, column: 7, scope: !81)
!98 = !DILocalVariable(name: "j", scope: !81, file: !11, line: 45, type: !12)
!99 = !DILocation(line: 45, column: 10, scope: !81)
!100 = !DILocation(line: 47, column: 10, scope: !101)
!101 = distinct !DILexicalBlock(scope: !81, file: !11, line: 47, column: 3)
!102 = !DILocation(line: 47, column: 8, scope: !101)
!103 = !DILocation(line: 47, column: 15, scope: !104)
!104 = distinct !DILexicalBlock(scope: !101, file: !11, line: 47, column: 3)
!105 = !DILocation(line: 47, column: 19, scope: !104)
!106 = !DILocation(line: 47, column: 17, scope: !104)
!107 = !DILocation(line: 47, column: 3, scope: !101)
!108 = !DILocation(line: 48, column: 24, scope: !104)
!109 = !DILocation(line: 48, column: 28, scope: !104)
!110 = !DILocation(line: 48, column: 26, scope: !104)
!111 = !DILocation(line: 48, column: 12, scope: !104)
!112 = !DILocation(line: 48, column: 33, scope: !104)
!113 = !DILocation(line: 48, column: 31, scope: !104)
!114 = !DILocation(line: 48, column: 5, scope: !104)
!115 = !DILocation(line: 48, column: 7, scope: !104)
!116 = !DILocation(line: 48, column: 10, scope: !104)
!117 = !DILocation(line: 47, column: 23, scope: !104)
!118 = !DILocation(line: 47, column: 3, scope: !104)
!119 = distinct !{!119, !107, !120, !121}
!120 = !DILocation(line: 48, column: 33, scope: !101)
!121 = !{!"llvm.loop.mustprogress"}
!122 = !DILocation(line: 49, column: 10, scope: !123)
!123 = distinct !DILexicalBlock(scope: !81, file: !11, line: 49, column: 3)
!124 = !DILocation(line: 49, column: 8, scope: !123)
!125 = !DILocation(line: 49, column: 15, scope: !126)
!126 = distinct !DILexicalBlock(scope: !123, file: !11, line: 49, column: 3)
!127 = !DILocation(line: 49, column: 19, scope: !126)
!128 = !DILocation(line: 49, column: 17, scope: !126)
!129 = !DILocation(line: 49, column: 3, scope: !123)
!130 = !DILocation(line: 50, column: 24, scope: !131)
!131 = distinct !DILexicalBlock(scope: !126, file: !11, line: 49, column: 27)
!132 = !DILocation(line: 50, column: 28, scope: !131)
!133 = !DILocation(line: 50, column: 26, scope: !131)
!134 = !DILocation(line: 50, column: 12, scope: !131)
!135 = !DILocation(line: 50, column: 33, scope: !131)
!136 = !DILocation(line: 50, column: 31, scope: !131)
!137 = !DILocation(line: 50, column: 5, scope: !131)
!138 = !DILocation(line: 50, column: 7, scope: !131)
!139 = !DILocation(line: 50, column: 10, scope: !131)
!140 = !DILocation(line: 51, column: 12, scope: !141)
!141 = distinct !DILexicalBlock(scope: !131, file: !11, line: 51, column: 5)
!142 = !DILocation(line: 51, column: 10, scope: !141)
!143 = !DILocation(line: 51, column: 17, scope: !144)
!144 = distinct !DILexicalBlock(scope: !141, file: !11, line: 51, column: 5)
!145 = !DILocation(line: 51, column: 21, scope: !144)
!146 = !DILocation(line: 51, column: 19, scope: !144)
!147 = !DILocation(line: 51, column: 5, scope: !141)
!148 = !DILocation(line: 52, column: 30, scope: !144)
!149 = !DILocation(line: 52, column: 33, scope: !144)
!150 = !DILocation(line: 52, column: 34, scope: !144)
!151 = !DILocation(line: 52, column: 31, scope: !144)
!152 = !DILocation(line: 52, column: 40, scope: !144)
!153 = !DILocation(line: 52, column: 38, scope: !144)
!154 = !DILocation(line: 52, column: 17, scope: !144)
!155 = !DILocation(line: 52, column: 43, scope: !144)
!156 = !DILocation(line: 52, column: 42, scope: !144)
!157 = !DILocation(line: 52, column: 7, scope: !144)
!158 = !DILocation(line: 52, column: 9, scope: !144)
!159 = !DILocation(line: 52, column: 12, scope: !144)
!160 = !DILocation(line: 52, column: 15, scope: !144)
!161 = !DILocation(line: 51, column: 25, scope: !144)
!162 = !DILocation(line: 51, column: 5, scope: !144)
!163 = distinct !{!163, !147, !164, !121}
!164 = !DILocation(line: 52, column: 43, scope: !141)
!165 = !DILocation(line: 53, column: 3, scope: !131)
!166 = !DILocation(line: 49, column: 23, scope: !126)
!167 = !DILocation(line: 49, column: 3, scope: !126)
!168 = distinct !{!168, !129, !169, !121}
!169 = !DILocation(line: 53, column: 3, scope: !123)
!170 = !DILocation(line: 54, column: 1, scope: !81)
!171 = distinct !DISubprogram(name: "task_job_polybench", scope: !11, file: !11, line: 129, type: !18, scopeLine: 129, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !2, retainedNodes: !64)
!172 = !DILocation(line: 130, column: 16, scope: !171)
!173 = !DILocation(line: 130, column: 19, scope: !171)
!174 = !DILocalVariable(name: "m", arg: 1, scope: !175, file: !11, line: 87, type: !12)
!175 = distinct !DISubprogram(name: "kernel_bicg", scope: !11, file: !11, line: 87, type: !176, scopeLine: 93, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition, unit: !2, retainedNodes: !64)
!176 = !DISubroutineType(types: !177)
!177 = !{null, !12, !12, !84, !85, !85, !85, !85}
!178 = !DILocation(line: 87, column: 60, scope: !175, inlinedAt: !179)
!179 = distinct !DILocation(line: 130, column: 3, scope: !171)
!180 = !DILocalVariable(name: "n", arg: 2, scope: !175, file: !11, line: 87, type: !12)
!181 = !DILocation(line: 87, column: 67, scope: !175, inlinedAt: !179)
!182 = !DILocalVariable(name: "A", arg: 3, scope: !175, file: !11, line: 88, type: !84)
!183 = !DILocation(line: 88, column: 14, scope: !175, inlinedAt: !179)
!184 = !DILocalVariable(name: "s", arg: 4, scope: !175, file: !11, line: 89, type: !85)
!185 = !DILocation(line: 89, column: 14, scope: !175, inlinedAt: !179)
!186 = !DILocalVariable(name: "q", arg: 5, scope: !175, file: !11, line: 90, type: !85)
!187 = !DILocation(line: 90, column: 14, scope: !175, inlinedAt: !179)
!188 = !DILocalVariable(name: "p", arg: 6, scope: !175, file: !11, line: 91, type: !85)
!189 = !DILocation(line: 91, column: 14, scope: !175, inlinedAt: !179)
!190 = !DILocalVariable(name: "r", arg: 7, scope: !175, file: !11, line: 92, type: !85)
!191 = !DILocation(line: 92, column: 14, scope: !175, inlinedAt: !179)
!192 = !DILocalVariable(name: "i", scope: !175, file: !11, line: 94, type: !12)
!193 = !DILocation(line: 94, column: 7, scope: !175, inlinedAt: !179)
!194 = !DILocalVariable(name: "j", scope: !175, file: !11, line: 94, type: !12)
!195 = !DILocation(line: 94, column: 10, scope: !175, inlinedAt: !179)
!196 = !DILocation(line: 97, column: 10, scope: !197, inlinedAt: !179)
!197 = distinct !DILexicalBlock(scope: !175, file: !11, line: 97, column: 3)
!198 = !DILocation(line: 97, column: 8, scope: !197, inlinedAt: !179)
!199 = !DILocation(line: 97, column: 15, scope: !200, inlinedAt: !179)
!200 = distinct !DILexicalBlock(scope: !197, file: !11, line: 97, column: 3)
!201 = !DILocation(line: 97, column: 17, scope: !200, inlinedAt: !179)
!202 = !DILocation(line: 97, column: 3, scope: !197, inlinedAt: !179)
!203 = !DILocation(line: 98, column: 5, scope: !200, inlinedAt: !179)
!204 = !DILocation(line: 98, column: 7, scope: !200, inlinedAt: !179)
!205 = !DILocation(line: 98, column: 10, scope: !200, inlinedAt: !179)
!206 = !DILocation(line: 97, column: 27, scope: !200, inlinedAt: !179)
!207 = !DILocation(line: 97, column: 3, scope: !200, inlinedAt: !179)
!208 = distinct !{!208, !202, !209, !121}
!209 = !DILocation(line: 98, column: 12, scope: !197, inlinedAt: !179)
!210 = !DILocation(line: 99, column: 10, scope: !211, inlinedAt: !179)
!211 = distinct !DILexicalBlock(scope: !175, file: !11, line: 99, column: 3)
!212 = !DILocation(line: 99, column: 8, scope: !211, inlinedAt: !179)
!213 = !DILocation(line: 99, column: 15, scope: !214, inlinedAt: !179)
!214 = distinct !DILexicalBlock(scope: !211, file: !11, line: 99, column: 3)
!215 = !DILocation(line: 99, column: 17, scope: !214, inlinedAt: !179)
!216 = !DILocation(line: 99, column: 3, scope: !211, inlinedAt: !179)
!217 = !DILocation(line: 101, column: 7, scope: !218, inlinedAt: !179)
!218 = distinct !DILexicalBlock(scope: !214, file: !11, line: 100, column: 5)
!219 = !DILocation(line: 101, column: 9, scope: !218, inlinedAt: !179)
!220 = !DILocation(line: 101, column: 12, scope: !218, inlinedAt: !179)
!221 = !DILocation(line: 102, column: 14, scope: !222, inlinedAt: !179)
!222 = distinct !DILexicalBlock(scope: !218, file: !11, line: 102, column: 7)
!223 = !DILocation(line: 102, column: 12, scope: !222, inlinedAt: !179)
!224 = !DILocation(line: 102, column: 19, scope: !225, inlinedAt: !179)
!225 = distinct !DILexicalBlock(scope: !222, file: !11, line: 102, column: 7)
!226 = !DILocation(line: 102, column: 21, scope: !225, inlinedAt: !179)
!227 = !DILocation(line: 102, column: 7, scope: !222, inlinedAt: !179)
!228 = !DILocation(line: 104, column: 11, scope: !229, inlinedAt: !179)
!229 = distinct !DILexicalBlock(scope: !225, file: !11, line: 103, column: 2)
!230 = !DILocation(line: 104, column: 13, scope: !229, inlinedAt: !179)
!231 = !DILocation(line: 104, column: 18, scope: !229, inlinedAt: !179)
!232 = !DILocation(line: 104, column: 20, scope: !229, inlinedAt: !179)
!233 = !DILocation(line: 104, column: 25, scope: !229, inlinedAt: !179)
!234 = !DILocation(line: 104, column: 27, scope: !229, inlinedAt: !179)
!235 = !DILocation(line: 104, column: 30, scope: !229, inlinedAt: !179)
!236 = !DILocation(line: 104, column: 23, scope: !229, inlinedAt: !179)
!237 = !DILocation(line: 104, column: 16, scope: !229, inlinedAt: !179)
!238 = !DILocation(line: 104, column: 4, scope: !229, inlinedAt: !179)
!239 = !DILocation(line: 104, column: 6, scope: !229, inlinedAt: !179)
!240 = !DILocation(line: 104, column: 9, scope: !229, inlinedAt: !179)
!241 = !DILocation(line: 105, column: 11, scope: !229, inlinedAt: !179)
!242 = !DILocation(line: 105, column: 13, scope: !229, inlinedAt: !179)
!243 = !DILocation(line: 105, column: 18, scope: !229, inlinedAt: !179)
!244 = !DILocation(line: 105, column: 20, scope: !229, inlinedAt: !179)
!245 = !DILocation(line: 105, column: 23, scope: !229, inlinedAt: !179)
!246 = !DILocation(line: 105, column: 28, scope: !229, inlinedAt: !179)
!247 = !DILocation(line: 105, column: 30, scope: !229, inlinedAt: !179)
!248 = !DILocation(line: 105, column: 26, scope: !229, inlinedAt: !179)
!249 = !DILocation(line: 105, column: 16, scope: !229, inlinedAt: !179)
!250 = !DILocation(line: 105, column: 4, scope: !229, inlinedAt: !179)
!251 = !DILocation(line: 105, column: 6, scope: !229, inlinedAt: !179)
!252 = !DILocation(line: 105, column: 9, scope: !229, inlinedAt: !179)
!253 = !DILocation(line: 102, column: 31, scope: !225, inlinedAt: !179)
!254 = !DILocation(line: 102, column: 7, scope: !225, inlinedAt: !179)
!255 = distinct !{!255, !227, !256, !121}
!256 = !DILocation(line: 106, column: 2, scope: !222, inlinedAt: !179)
!257 = !DILocation(line: 99, column: 27, scope: !214, inlinedAt: !179)
!258 = !DILocation(line: 99, column: 3, scope: !214, inlinedAt: !179)
!259 = distinct !{!259, !216, !260, !121}
!260 = !DILocation(line: 107, column: 5, scope: !211, inlinedAt: !179)
!261 = !DILocation(line: 136, column: 3, scope: !171)
!262 = distinct !DISubprogram(name: "workload_checksum", scope: !11, file: !11, line: 138, type: !263, scopeLine: 138, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !2, retainedNodes: !64)
!263 = !DISubroutineType(types: !264)
!264 = !{!20, !6}
!265 = !DILocalVariable(name: "task", arg: 1, scope: !262, file: !11, line: 138, type: !6)
!266 = !DILocation(line: 138, column: 37, scope: !262)
!267 = !DILocation(line: 139, column: 9, scope: !262)
!268 = !DILocation(line: 140, column: 11, scope: !262)
!269 = !DILocation(line: 141, column: 15, scope: !262)
!270 = !DILocation(line: 141, column: 18, scope: !262)
!271 = !DILocation(line: 141, column: 3, scope: !262)
!272 = !DILocation(line: 142, column: 10, scope: !262)
!273 = !DILocation(line: 142, column: 3, scope: !262)
!274 = distinct !DISubprogram(name: "print_array", scope: !11, file: !11, line: 60, type: !275, scopeLine: 64, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition, unit: !2, retainedNodes: !64)
!275 = !DISubroutineType(types: !276)
!276 = !{null, !12, !12, !85, !85}
!277 = !DILocalVariable(name: "m", arg: 1, scope: !274, file: !11, line: 60, type: !12)
!278 = !DILocation(line: 60, column: 22, scope: !274)
!279 = !DILocalVariable(name: "n", arg: 2, scope: !274, file: !11, line: 60, type: !12)
!280 = !DILocation(line: 60, column: 29, scope: !274)
!281 = !DILocalVariable(name: "s", arg: 3, scope: !274, file: !11, line: 61, type: !85)
!282 = !DILocation(line: 61, column: 14, scope: !274)
!283 = !DILocalVariable(name: "q", arg: 4, scope: !274, file: !11, line: 62, type: !85)
!284 = !DILocation(line: 62, column: 14, scope: !274)
!285 = !DILocalVariable(name: "i", scope: !274, file: !11, line: 65, type: !12)
!286 = !DILocation(line: 65, column: 7, scope: !274)
!287 = !DILocation(line: 67, column: 3, scope: !274)
!288 = !DILocation(line: 68, column: 3, scope: !274)
!289 = !DILocation(line: 69, column: 10, scope: !290)
!290 = distinct !DILexicalBlock(scope: !274, file: !11, line: 69, column: 3)
!291 = !DILocation(line: 69, column: 8, scope: !290)
!292 = !DILocation(line: 69, column: 15, scope: !293)
!293 = distinct !DILexicalBlock(scope: !290, file: !11, line: 69, column: 3)
!294 = !DILocation(line: 69, column: 19, scope: !293)
!295 = !DILocation(line: 69, column: 17, scope: !293)
!296 = !DILocation(line: 69, column: 3, scope: !290)
!297 = !DILocation(line: 70, column: 9, scope: !298)
!298 = distinct !DILexicalBlock(scope: !299, file: !11, line: 70, column: 9)
!299 = distinct !DILexicalBlock(scope: !293, file: !11, line: 69, column: 27)
!300 = !DILocation(line: 70, column: 11, scope: !298)
!301 = !DILocation(line: 70, column: 16, scope: !298)
!302 = !DILocation(line: 70, column: 9, scope: !299)
!303 = !DILocation(line: 70, column: 31, scope: !298)
!304 = !DILocation(line: 70, column: 22, scope: !298)
!305 = !DILocation(line: 71, column: 14, scope: !299)
!306 = !DILocation(line: 71, column: 59, scope: !299)
!307 = !DILocation(line: 71, column: 61, scope: !299)
!308 = !DILocation(line: 71, column: 5, scope: !299)
!309 = !DILocation(line: 72, column: 3, scope: !299)
!310 = !DILocation(line: 69, column: 23, scope: !293)
!311 = !DILocation(line: 69, column: 3, scope: !293)
!312 = distinct !{!312, !296, !313, !121}
!313 = !DILocation(line: 72, column: 3, scope: !290)
!314 = !DILocation(line: 73, column: 3, scope: !274)
!315 = !DILocation(line: 74, column: 3, scope: !274)
!316 = !DILocation(line: 75, column: 10, scope: !317)
!317 = distinct !DILexicalBlock(scope: !274, file: !11, line: 75, column: 3)
!318 = !DILocation(line: 75, column: 8, scope: !317)
!319 = !DILocation(line: 75, column: 15, scope: !320)
!320 = distinct !DILexicalBlock(scope: !317, file: !11, line: 75, column: 3)
!321 = !DILocation(line: 75, column: 19, scope: !320)
!322 = !DILocation(line: 75, column: 17, scope: !320)
!323 = !DILocation(line: 75, column: 3, scope: !317)
!324 = !DILocation(line: 76, column: 9, scope: !325)
!325 = distinct !DILexicalBlock(scope: !326, file: !11, line: 76, column: 9)
!326 = distinct !DILexicalBlock(scope: !320, file: !11, line: 75, column: 27)
!327 = !DILocation(line: 76, column: 11, scope: !325)
!328 = !DILocation(line: 76, column: 16, scope: !325)
!329 = !DILocation(line: 76, column: 9, scope: !326)
!330 = !DILocation(line: 76, column: 31, scope: !325)
!331 = !DILocation(line: 76, column: 22, scope: !325)
!332 = !DILocation(line: 77, column: 14, scope: !326)
!333 = !DILocation(line: 77, column: 59, scope: !326)
!334 = !DILocation(line: 77, column: 61, scope: !326)
!335 = !DILocation(line: 77, column: 5, scope: !326)
!336 = !DILocation(line: 78, column: 3, scope: !326)
!337 = !DILocation(line: 75, column: 23, scope: !320)
!338 = !DILocation(line: 75, column: 3, scope: !320)
!339 = distinct !{!339, !323, !340, !121}
!340 = !DILocation(line: 78, column: 3, scope: !317)
!341 = !DILocation(line: 79, column: 3, scope: !274)
!342 = !DILocation(line: 80, column: 3, scope: !274)
!343 = !DILocation(line: 81, column: 1, scope: !274)
!344 = distinct !DISubprogram(name: "pb_fprintf", scope: !32, file: !32, line: 13, type: !345, scopeLine: 14, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition, unit: !2, retainedNodes: !64)
!345 = !DISubroutineType(types: !346)
!346 = !{!12, !347, !406, null}
!347 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !348, size: 64)
!348 = !DIDerivedType(tag: DW_TAG_typedef, name: "FILE", file: !349, line: 7, baseType: !350)
!349 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/types/FILE.h", directory: "", checksumkind: CSK_MD5, checksum: "571f9fb6223c42439075fdde11a0de5d")
!350 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "_IO_FILE", file: !351, line: 49, size: 1728, elements: !352)
!351 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/types/struct_FILE.h", directory: "", checksumkind: CSK_MD5, checksum: "1bad07471b7974df4ecc1d1c2ca207e6")
!352 = !{!353, !354, !357, !358, !359, !360, !361, !362, !363, !364, !365, !366, !367, !370, !372, !373, !374, !377, !379, !381, !383, !386, !388, !391, !394, !395, !397, !401, !402}
!353 = !DIDerivedType(tag: DW_TAG_member, name: "_flags", scope: !350, file: !351, line: 51, baseType: !12, size: 32)
!354 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_read_ptr", scope: !350, file: !351, line: 54, baseType: !355, size: 64, offset: 64)
!355 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !356, size: 64)
!356 = !DIBasicType(name: "char", size: 8, encoding: DW_ATE_signed_char)
!357 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_read_end", scope: !350, file: !351, line: 55, baseType: !355, size: 64, offset: 128)
!358 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_read_base", scope: !350, file: !351, line: 56, baseType: !355, size: 64, offset: 192)
!359 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_write_base", scope: !350, file: !351, line: 57, baseType: !355, size: 64, offset: 256)
!360 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_write_ptr", scope: !350, file: !351, line: 58, baseType: !355, size: 64, offset: 320)
!361 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_write_end", scope: !350, file: !351, line: 59, baseType: !355, size: 64, offset: 384)
!362 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_buf_base", scope: !350, file: !351, line: 60, baseType: !355, size: 64, offset: 448)
!363 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_buf_end", scope: !350, file: !351, line: 61, baseType: !355, size: 64, offset: 512)
!364 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_save_base", scope: !350, file: !351, line: 64, baseType: !355, size: 64, offset: 576)
!365 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_backup_base", scope: !350, file: !351, line: 65, baseType: !355, size: 64, offset: 640)
!366 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_save_end", scope: !350, file: !351, line: 66, baseType: !355, size: 64, offset: 704)
!367 = !DIDerivedType(tag: DW_TAG_member, name: "_markers", scope: !350, file: !351, line: 68, baseType: !368, size: 64, offset: 768)
!368 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !369, size: 64)
!369 = !DICompositeType(tag: DW_TAG_structure_type, name: "_IO_marker", file: !351, line: 36, flags: DIFlagFwdDecl)
!370 = !DIDerivedType(tag: DW_TAG_member, name: "_chain", scope: !350, file: !351, line: 70, baseType: !371, size: 64, offset: 832)
!371 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !350, size: 64)
!372 = !DIDerivedType(tag: DW_TAG_member, name: "_fileno", scope: !350, file: !351, line: 72, baseType: !12, size: 32, offset: 896)
!373 = !DIDerivedType(tag: DW_TAG_member, name: "_flags2", scope: !350, file: !351, line: 73, baseType: !12, size: 32, offset: 928)
!374 = !DIDerivedType(tag: DW_TAG_member, name: "_old_offset", scope: !350, file: !351, line: 74, baseType: !375, size: 64, offset: 960)
!375 = !DIDerivedType(tag: DW_TAG_typedef, name: "__off_t", file: !23, line: 152, baseType: !376)
!376 = !DIBasicType(name: "long", size: 64, encoding: DW_ATE_signed)
!377 = !DIDerivedType(tag: DW_TAG_member, name: "_cur_column", scope: !350, file: !351, line: 77, baseType: !378, size: 16, offset: 1024)
!378 = !DIBasicType(name: "unsigned short", size: 16, encoding: DW_ATE_unsigned)
!379 = !DIDerivedType(tag: DW_TAG_member, name: "_vtable_offset", scope: !350, file: !351, line: 78, baseType: !380, size: 8, offset: 1040)
!380 = !DIBasicType(name: "signed char", size: 8, encoding: DW_ATE_signed_char)
!381 = !DIDerivedType(tag: DW_TAG_member, name: "_shortbuf", scope: !350, file: !351, line: 79, baseType: !382, size: 8, offset: 1048)
!382 = !DICompositeType(tag: DW_TAG_array_type, baseType: !356, size: 8, elements: !24)
!383 = !DIDerivedType(tag: DW_TAG_member, name: "_lock", scope: !350, file: !351, line: 81, baseType: !384, size: 64, offset: 1088)
!384 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !385, size: 64)
!385 = !DIDerivedType(tag: DW_TAG_typedef, name: "_IO_lock_t", file: !351, line: 43, baseType: null)
!386 = !DIDerivedType(tag: DW_TAG_member, name: "_offset", scope: !350, file: !351, line: 89, baseType: !387, size: 64, offset: 1152)
!387 = !DIDerivedType(tag: DW_TAG_typedef, name: "__off64_t", file: !23, line: 153, baseType: !376)
!388 = !DIDerivedType(tag: DW_TAG_member, name: "_codecvt", scope: !350, file: !351, line: 91, baseType: !389, size: 64, offset: 1216)
!389 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !390, size: 64)
!390 = !DICompositeType(tag: DW_TAG_structure_type, name: "_IO_codecvt", file: !351, line: 37, flags: DIFlagFwdDecl)
!391 = !DIDerivedType(tag: DW_TAG_member, name: "_wide_data", scope: !350, file: !351, line: 92, baseType: !392, size: 64, offset: 1280)
!392 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !393, size: 64)
!393 = !DICompositeType(tag: DW_TAG_structure_type, name: "_IO_wide_data", file: !351, line: 38, flags: DIFlagFwdDecl)
!394 = !DIDerivedType(tag: DW_TAG_member, name: "_freeres_list", scope: !350, file: !351, line: 93, baseType: !371, size: 64, offset: 1344)
!395 = !DIDerivedType(tag: DW_TAG_member, name: "_freeres_buf", scope: !350, file: !351, line: 94, baseType: !396, size: 64, offset: 1408)
!396 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: null, size: 64)
!397 = !DIDerivedType(tag: DW_TAG_member, name: "__pad5", scope: !350, file: !351, line: 95, baseType: !398, size: 64, offset: 1472)
!398 = !DIDerivedType(tag: DW_TAG_typedef, name: "size_t", file: !399, line: 46, baseType: !400)
!399 = !DIFile(filename: "/usr/lib/llvm-14/lib/clang/14.0.0/include/stddef.h", directory: "", checksumkind: CSK_MD5, checksum: "2499dd2361b915724b073282bea3a7bc")
!400 = !DIBasicType(name: "unsigned long", size: 64, encoding: DW_ATE_unsigned)
!401 = !DIDerivedType(tag: DW_TAG_member, name: "_mode", scope: !350, file: !351, line: 96, baseType: !12, size: 32, offset: 1536)
!402 = !DIDerivedType(tag: DW_TAG_member, name: "_unused2", scope: !350, file: !351, line: 98, baseType: !403, size: 160, offset: 1568)
!403 = !DICompositeType(tag: DW_TAG_array_type, baseType: !356, size: 160, elements: !404)
!404 = !{!405}
!405 = !DISubrange(count: 20)
!406 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !407, size: 64)
!407 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !356)
!408 = !DILocalVariable(name: "stream", arg: 1, scope: !344, file: !32, line: 13, type: !347)
!409 = !DILocation(line: 13, column: 29, scope: !344)
!410 = !DILocalVariable(name: "format", arg: 2, scope: !344, file: !32, line: 13, type: !406)
!411 = !DILocation(line: 13, column: 49, scope: !344)
!412 = !DILocalVariable(name: "buffer", scope: !344, file: !32, line: 15, type: !413)
!413 = !DICompositeType(tag: DW_TAG_array_type, baseType: !356, size: 6144, elements: !414)
!414 = !{!415}
!415 = !DISubrange(count: 768)
!416 = !DILocation(line: 15, column: 10, scope: !344)
!417 = !DILocalVariable(name: "args", scope: !344, file: !32, line: 16, type: !418)
!418 = !DIDerivedType(tag: DW_TAG_typedef, name: "va_list", file: !419, line: 52, baseType: !420)
!419 = !DIFile(filename: "/usr/include/stdio.h", directory: "", checksumkind: CSK_MD5, checksum: "f31eefcc3f15835fc5a4023a625cf609")
!420 = !DIDerivedType(tag: DW_TAG_typedef, name: "__gnuc_va_list", file: !421, line: 32, baseType: !422)
!421 = !DIFile(filename: "/usr/lib/llvm-14/lib/clang/14.0.0/include/stdarg.h", directory: "", checksumkind: CSK_MD5, checksum: "4de3cbd931b589d291e5c39387aecf82")
!422 = !DIDerivedType(tag: DW_TAG_typedef, name: "__builtin_va_list", file: !423, baseType: !424)
!423 = !DIFile(filename: "source/workload.c", directory: "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/affine-bounds-20260929/suite/bicg")
!424 = !DICompositeType(tag: DW_TAG_array_type, baseType: !425, size: 192, elements: !24)
!425 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "__va_list_tag", size: 192, elements: !426)
!426 = !{!427, !428, !429, !430}
!427 = !DIDerivedType(tag: DW_TAG_member, name: "gp_offset", scope: !425, file: !423, line: 16, baseType: !6, size: 32)
!428 = !DIDerivedType(tag: DW_TAG_member, name: "fp_offset", scope: !425, file: !423, line: 16, baseType: !6, size: 32, offset: 32)
!429 = !DIDerivedType(tag: DW_TAG_member, name: "overflow_arg_area", scope: !425, file: !423, line: 16, baseType: !396, size: 64, offset: 64)
!430 = !DIDerivedType(tag: DW_TAG_member, name: "reg_save_area", scope: !425, file: !423, line: 16, baseType: !396, size: 64, offset: 128)
!431 = !DILocation(line: 16, column: 13, scope: !344)
!432 = !DILocation(line: 17, column: 5, scope: !344)
!433 = !DILocalVariable(name: "count", scope: !344, file: !32, line: 18, type: !12)
!434 = !DILocation(line: 18, column: 9, scope: !344)
!435 = !DILocation(line: 18, column: 27, scope: !344)
!436 = !DILocation(line: 18, column: 51, scope: !344)
!437 = !DILocation(line: 18, column: 59, scope: !344)
!438 = !DILocation(line: 18, column: 17, scope: !344)
!439 = !DILocation(line: 19, column: 5, scope: !344)
!440 = !DILocation(line: 20, column: 9, scope: !441)
!441 = distinct !DILexicalBlock(scope: !344, file: !32, line: 20, column: 9)
!442 = !DILocation(line: 20, column: 15, scope: !441)
!443 = !DILocation(line: 20, column: 19, scope: !441)
!444 = !DILocation(line: 20, column: 32, scope: !441)
!445 = !DILocation(line: 20, column: 22, scope: !441)
!446 = !DILocation(line: 20, column: 38, scope: !441)
!447 = !DILocation(line: 20, column: 9, scope: !344)
!448 = !DILocation(line: 20, column: 57, scope: !441)
!449 = !DILocalVariable(name: "i", scope: !450, file: !32, line: 21, type: !12)
!450 = distinct !DILexicalBlock(scope: !344, file: !32, line: 21, column: 5)
!451 = !DILocation(line: 21, column: 14, scope: !450)
!452 = !DILocation(line: 21, column: 10, scope: !450)
!453 = !DILocation(line: 21, column: 21, scope: !454)
!454 = distinct !DILexicalBlock(scope: !450, file: !32, line: 21, column: 5)
!455 = !DILocation(line: 21, column: 25, scope: !454)
!456 = !DILocation(line: 21, column: 23, scope: !454)
!457 = !DILocation(line: 21, column: 5, scope: !450)
!458 = !DILocation(line: 22, column: 42, scope: !459)
!459 = distinct !DILexicalBlock(scope: !454, file: !32, line: 21, column: 37)
!460 = !DILocation(line: 22, column: 35, scope: !459)
!461 = !DILocation(line: 22, column: 20, scope: !459)
!462 = !DILocation(line: 22, column: 17, scope: !459)
!463 = !DILocation(line: 23, column: 17, scope: !459)
!464 = !DILocation(line: 24, column: 5, scope: !459)
!465 = !DILocation(line: 21, column: 32, scope: !454)
!466 = !DILocation(line: 21, column: 5, scope: !454)
!467 = distinct !{!467, !457, !468, !121}
!468 = !DILocation(line: 24, column: 5, scope: !450)
!469 = !DILocation(line: 28, column: 11, scope: !344)
!470 = !DILocation(line: 29, column: 11, scope: !344)
!471 = !DILocation(line: 31, column: 12, scope: !344)
!472 = !DILocation(line: 31, column: 5, scope: !344)
