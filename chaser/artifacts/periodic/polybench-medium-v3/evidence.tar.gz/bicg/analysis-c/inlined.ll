; ModuleID = 'workload.ll'
source_filename = "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/affine-bounds-20260929/suite/bicg/source/workload.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

%struct._IO_FILE = type { i32, i8*, i8*, i8*, i8*, i8*, i8*, i8*, i8*, i8*, i8*, i8*, %struct._IO_marker*, %struct._IO_FILE*, i32, i32, i64, i16, i8, [1 x i8], i8*, i64, %struct._IO_codecvt*, %struct._IO_wide_data*, %struct._IO_FILE*, i8*, i64, i32, [20 x i8] }
%struct._IO_marker = type opaque
%struct._IO_codecvt = type opaque
%struct._IO_wide_data = type opaque
%struct.__va_list_tag = type { i32, i32, i8*, i8* }

@n = dso_local global i32 410, align 4, !dbg !0
@m = dso_local global i32 390, align 4, !dbg !9
@A = dso_local global [410 x [390 x double]] zeroinitializer, section ".chaser_data.A", align 64, !dbg !33
@s = dso_local global [390 x double] zeroinitializer, section ".chaser_data.s", align 64, !dbg !39
@q = dso_local global [410 x double] zeroinitializer, section ".chaser_data.q", align 64, !dbg !43
@p = dso_local global [390 x double] zeroinitializer, section ".chaser_data.p", align 64, !dbg !47
@r = dso_local global [410 x double] zeroinitializer, section ".chaser_data.r", align 64, !dbg !49
@.str = private unnamed_addr constant [12 x i8] c"ape.analyze\00", section "llvm.metadata"
@.str.1 = private unnamed_addr constant [122 x i8] c"/workspace/experiments-array-support/chaser/.cache/periodic-polybench/affine-bounds-20260929/suite/bicg/source/workload.c\00", section "llvm.metadata"
@pb_hash = internal global i32 0, align 4, !dbg !30
@workload_jobs = dso_local constant [1 x i32 ()*] [i32 ()* @task_job_polybench], align 8, !dbg !13
@workload_expected = dso_local constant [1 x i32] [i32 -1587675741], align 4, !dbg !26
@stderr = external global %struct._IO_FILE*, align 8
@.str.2 = private unnamed_addr constant [23 x i8] c"==BEGIN DUMP_ARRAYS==\0A\00", align 1
@.str.3 = private unnamed_addr constant [15 x i8] c"begin dump: %s\00", align 1
@.str.4 = private unnamed_addr constant [2 x i8] c"s\00", align 1
@.str.5 = private unnamed_addr constant [2 x i8] c"\0A\00", align 1
@.str.6 = private unnamed_addr constant [8 x i8] c"%0.2lf \00", align 1
@.str.7 = private unnamed_addr constant [17 x i8] c"\0Aend   dump: %s\0A\00", align 1
@.str.8 = private unnamed_addr constant [2 x i8] c"q\00", align 1
@.str.9 = private unnamed_addr constant [23 x i8] c"==END   DUMP_ARRAYS==\0A\00", align 1
@pb_emit = internal global i32 1, align 4, !dbg !51
@llvm.global.annotations = appending global [1 x { i8*, i8*, i8*, i32, i8* }] [{ i8*, i8*, i8*, i32, i8* } { i8* bitcast (i32 ()* @task_job_polybench to i8*), i8* getelementptr inbounds ([12 x i8], [12 x i8]* @.str, i32 0, i32 0), i8* getelementptr inbounds ([122 x i8], [122 x i8]* @.str.1, i32 0, i32 0), i32 129, i8* null }], section "llvm.metadata"

; Function Attrs: noinline nounwind uwtable
define dso_local void @workload_prepare() #0 !dbg !61 {
  ret void, !dbg !65
}

; Function Attrs: noinline nounwind uwtable
define dso_local void @workload_reset(i32 noundef %0) #0 !dbg !66 {
  call void @llvm.dbg.value(metadata i32 %0, metadata !69, metadata !DIExpression()), !dbg !70
  call void @llvm.memset.p0i8.i64(i8* align 64 bitcast ([410 x [390 x double]]* @A to i8*), i8 0, i64 1279200, i1 false), !dbg !71
  call void @llvm.memset.p0i8.i64(i8* align 64 bitcast ([390 x double]* @s to i8*), i8 0, i64 3120, i1 false), !dbg !72
  call void @llvm.memset.p0i8.i64(i8* align 64 bitcast ([410 x double]* @q to i8*), i8 0, i64 3280, i1 false), !dbg !73
  call void @llvm.memset.p0i8.i64(i8* align 64 bitcast ([390 x double]* @p to i8*), i8 0, i64 3120, i1 false), !dbg !74
  call void @llvm.memset.p0i8.i64(i8* align 64 bitcast ([410 x double]* @r to i8*), i8 0, i64 3280, i1 false), !dbg !75
  %2 = load i32, i32* @m, align 4, !dbg !76
  %3 = load i32, i32* @n, align 4, !dbg !77
  call void @init_array(i32 noundef %2, i32 noundef %3, [390 x double]* noundef getelementptr inbounds ([410 x [390 x double]], [410 x [390 x double]]* @A, i64 0, i64 0), double* noundef getelementptr inbounds ([410 x double], [410 x double]* @r, i64 0, i64 0), double* noundef getelementptr inbounds ([390 x double], [390 x double]* @p, i64 0, i64 0)), !dbg !78
  ret void, !dbg !79
}

; Function Attrs: nofree nosync nounwind readnone speculatable willreturn
declare void @llvm.dbg.declare(metadata, metadata, metadata) #1

; Function Attrs: argmemonly nofree nounwind willreturn writeonly
declare void @llvm.memset.p0i8.i64(i8* nocapture writeonly, i8, i64, i1 immarg) #2

; Function Attrs: noinline nounwind uwtable
define internal void @init_array(i32 noundef %0, i32 noundef %1, [390 x double]* noundef %2, double* noundef %3, double* noundef %4) #0 !dbg !80 {
  call void @llvm.dbg.value(metadata i32 %0, metadata !85, metadata !DIExpression()), !dbg !86
  call void @llvm.dbg.value(metadata i32 %1, metadata !87, metadata !DIExpression()), !dbg !86
  call void @llvm.dbg.value(metadata [390 x double]* %2, metadata !88, metadata !DIExpression()), !dbg !86
  call void @llvm.dbg.value(metadata double* %3, metadata !89, metadata !DIExpression()), !dbg !86
  call void @llvm.dbg.value(metadata double* %4, metadata !90, metadata !DIExpression()), !dbg !86
  call void @llvm.dbg.value(metadata i32 0, metadata !91, metadata !DIExpression()), !dbg !86
  br label %6, !dbg !92

6:                                                ; preds = %15, %5
  %.01 = phi i32 [ 0, %5 ], [ %16, %15 ], !dbg !94
  call void @llvm.dbg.value(metadata i32 %.01, metadata !91, metadata !DIExpression()), !dbg !86
  %7 = icmp slt i32 %.01, %0, !dbg !95
  br i1 %7, label %8, label %17, !dbg !97

8:                                                ; preds = %6
  %9 = srem i32 %.01, %0, !dbg !98
  %10 = sitofp i32 %9 to double, !dbg !99
  %11 = sitofp i32 %0 to double, !dbg !100
  %12 = fdiv double %10, %11, !dbg !101
  %13 = sext i32 %.01 to i64, !dbg !102
  %14 = getelementptr inbounds double, double* %4, i64 %13, !dbg !102
  store double %12, double* %14, align 8, !dbg !103
  br label %15, !dbg !102

15:                                               ; preds = %8
  %16 = add nsw i32 %.01, 1, !dbg !104
  call void @llvm.dbg.value(metadata i32 %16, metadata !91, metadata !DIExpression()), !dbg !86
  br label %6, !dbg !105, !llvm.loop !106

17:                                               ; preds = %6
  call void @llvm.dbg.value(metadata i32 0, metadata !91, metadata !DIExpression()), !dbg !86
  br label %18, !dbg !109

18:                                               ; preds = %43, %17
  %.1 = phi i32 [ 0, %17 ], [ %44, %43 ], !dbg !111
  call void @llvm.dbg.value(metadata i32 %.1, metadata !91, metadata !DIExpression()), !dbg !86
  %19 = icmp slt i32 %.1, %1, !dbg !112
  br i1 %19, label %20, label %45, !dbg !114

20:                                               ; preds = %18
  %21 = srem i32 %.1, %1, !dbg !115
  %22 = sitofp i32 %21 to double, !dbg !117
  %23 = sitofp i32 %1 to double, !dbg !118
  %24 = fdiv double %22, %23, !dbg !119
  %25 = sext i32 %.1 to i64, !dbg !120
  %26 = getelementptr inbounds double, double* %3, i64 %25, !dbg !120
  store double %24, double* %26, align 8, !dbg !121
  call void @llvm.dbg.value(metadata i32 0, metadata !122, metadata !DIExpression()), !dbg !86
  br label %27, !dbg !123

27:                                               ; preds = %40, %20
  %.0 = phi i32 [ 0, %20 ], [ %41, %40 ], !dbg !125
  call void @llvm.dbg.value(metadata i32 %.0, metadata !122, metadata !DIExpression()), !dbg !86
  %28 = icmp slt i32 %.0, %0, !dbg !126
  br i1 %28, label %29, label %42, !dbg !128

29:                                               ; preds = %27
  %30 = add nsw i32 %.0, 1, !dbg !129
  %31 = mul nsw i32 %.1, %30, !dbg !130
  %32 = srem i32 %31, %1, !dbg !131
  %33 = sitofp i32 %32 to double, !dbg !132
  %34 = sitofp i32 %1 to double, !dbg !133
  %35 = fdiv double %33, %34, !dbg !134
  %36 = sext i32 %.1 to i64, !dbg !135
  %37 = getelementptr inbounds [390 x double], [390 x double]* %2, i64 %36, !dbg !135
  %38 = sext i32 %.0 to i64, !dbg !135
  %39 = getelementptr inbounds [390 x double], [390 x double]* %37, i64 0, i64 %38, !dbg !135
  store double %35, double* %39, align 8, !dbg !136
  br label %40, !dbg !135

40:                                               ; preds = %29
  %41 = add nsw i32 %.0, 1, !dbg !137
  call void @llvm.dbg.value(metadata i32 %41, metadata !122, metadata !DIExpression()), !dbg !86
  br label %27, !dbg !138, !llvm.loop !139

42:                                               ; preds = %27
  br label %43, !dbg !141

43:                                               ; preds = %42
  %44 = add nsw i32 %.1, 1, !dbg !142
  call void @llvm.dbg.value(metadata i32 %44, metadata !91, metadata !DIExpression()), !dbg !86
  br label %18, !dbg !143, !llvm.loop !144

45:                                               ; preds = %18
  ret void, !dbg !146
}

; Function Attrs: noinline nounwind uwtable
define dso_local i32 @task_job_polybench() #0 !dbg !147 {
  %1 = load i32, i32* @m, align 4, !dbg !148
  %2 = load i32, i32* @n, align 4, !dbg !149
  call void @llvm.dbg.value(metadata i32 %1, metadata !150, metadata !DIExpression()), !dbg !154
  call void @llvm.dbg.value(metadata i32 %2, metadata !156, metadata !DIExpression()), !dbg !154
  call void @llvm.dbg.value(metadata [390 x double]* getelementptr inbounds ([410 x [390 x double]], [410 x [390 x double]]* @A, i64 0, i64 0), metadata !157, metadata !DIExpression()), !dbg !154
  call void @llvm.dbg.value(metadata double* getelementptr inbounds ([390 x double], [390 x double]* @s, i64 0, i64 0), metadata !158, metadata !DIExpression()), !dbg !154
  call void @llvm.dbg.value(metadata double* getelementptr inbounds ([410 x double], [410 x double]* @q, i64 0, i64 0), metadata !159, metadata !DIExpression()), !dbg !154
  call void @llvm.dbg.value(metadata double* getelementptr inbounds ([390 x double], [390 x double]* @p, i64 0, i64 0), metadata !160, metadata !DIExpression()), !dbg !154
  call void @llvm.dbg.value(metadata double* getelementptr inbounds ([410 x double], [410 x double]* @r, i64 0, i64 0), metadata !161, metadata !DIExpression()), !dbg !154
  call void @llvm.dbg.value(metadata i32 0, metadata !162, metadata !DIExpression()), !dbg !154
  br label %3, !dbg !163

3:                                                ; preds = %5, %0
  %.01 = phi i32 [ 0, %0 ], [ %8, %5 ], !dbg !165
  call void @llvm.dbg.value(metadata i32 %.01, metadata !162, metadata !DIExpression()), !dbg !154
  %4 = icmp slt i32 %.01, 390, !dbg !166
  br i1 %4, label %5, label %9, !dbg !168

5:                                                ; preds = %3
  %6 = sext i32 %.01 to i64, !dbg !169
  %7 = getelementptr inbounds double, double* getelementptr inbounds ([390 x double], [390 x double]* @s, i64 0, i64 0), i64 %6, !dbg !169
  store double 0.000000e+00, double* %7, align 8, !dbg !170
  %8 = add nsw i32 %.01, 1, !dbg !171
  call void @llvm.dbg.value(metadata i32 %8, metadata !162, metadata !DIExpression()), !dbg !154
  br label %3, !dbg !172, !llvm.loop !173

9:                                                ; preds = %3
  call void @llvm.dbg.value(metadata i32 0, metadata !162, metadata !DIExpression()), !dbg !154
  br label %10, !dbg !175

10:                                               ; preds = %49, %9
  %.1 = phi i32 [ 0, %9 ], [ %50, %49 ], !dbg !177
  call void @llvm.dbg.value(metadata i32 %.1, metadata !162, metadata !DIExpression()), !dbg !154
  %11 = icmp slt i32 %.1, 410, !dbg !178
  br i1 %11, label %12, label %51, !dbg !180

12:                                               ; preds = %10
  %13 = sext i32 %.1 to i64, !dbg !181
  %14 = getelementptr inbounds double, double* getelementptr inbounds ([410 x double], [410 x double]* @q, i64 0, i64 0), i64 %13, !dbg !181
  store double 0.000000e+00, double* %14, align 8, !dbg !183
  call void @llvm.dbg.value(metadata i32 0, metadata !184, metadata !DIExpression()), !dbg !154
  br label %15, !dbg !185

15:                                               ; preds = %17, %12
  %.0 = phi i32 [ 0, %12 ], [ %48, %17 ], !dbg !187
  call void @llvm.dbg.value(metadata i32 %.0, metadata !184, metadata !DIExpression()), !dbg !154
  %16 = icmp slt i32 %.0, 390, !dbg !188
  br i1 %16, label %17, label %49, !dbg !190

17:                                               ; preds = %15
  %18 = sext i32 %.0 to i64, !dbg !191
  %19 = getelementptr inbounds double, double* getelementptr inbounds ([390 x double], [390 x double]* @s, i64 0, i64 0), i64 %18, !dbg !191
  %20 = load double, double* %19, align 8, !dbg !191
  %21 = sext i32 %.1 to i64, !dbg !193
  %22 = getelementptr inbounds double, double* getelementptr inbounds ([410 x double], [410 x double]* @r, i64 0, i64 0), i64 %21, !dbg !193
  %23 = load double, double* %22, align 8, !dbg !193
  %24 = sext i32 %.1 to i64, !dbg !194
  %25 = getelementptr inbounds [390 x double], [390 x double]* getelementptr inbounds ([410 x [390 x double]], [410 x [390 x double]]* @A, i64 0, i64 0), i64 %24, !dbg !194
  %26 = sext i32 %.0 to i64, !dbg !194
  %27 = getelementptr inbounds [390 x double], [390 x double]* %25, i64 0, i64 %26, !dbg !194
  %28 = load double, double* %27, align 8, !dbg !194
  %29 = fmul double %23, %28, !dbg !195
  %30 = fadd double %20, %29, !dbg !196
  %31 = sext i32 %.0 to i64, !dbg !197
  %32 = getelementptr inbounds double, double* getelementptr inbounds ([390 x double], [390 x double]* @s, i64 0, i64 0), i64 %31, !dbg !197
  store double %30, double* %32, align 8, !dbg !198
  %33 = sext i32 %.1 to i64, !dbg !199
  %34 = getelementptr inbounds double, double* getelementptr inbounds ([410 x double], [410 x double]* @q, i64 0, i64 0), i64 %33, !dbg !199
  %35 = load double, double* %34, align 8, !dbg !199
  %36 = sext i32 %.1 to i64, !dbg !200
  %37 = getelementptr inbounds [390 x double], [390 x double]* getelementptr inbounds ([410 x [390 x double]], [410 x [390 x double]]* @A, i64 0, i64 0), i64 %36, !dbg !200
  %38 = sext i32 %.0 to i64, !dbg !200
  %39 = getelementptr inbounds [390 x double], [390 x double]* %37, i64 0, i64 %38, !dbg !200
  %40 = load double, double* %39, align 8, !dbg !200
  %41 = sext i32 %.0 to i64, !dbg !201
  %42 = getelementptr inbounds double, double* getelementptr inbounds ([390 x double], [390 x double]* @p, i64 0, i64 0), i64 %41, !dbg !201
  %43 = load double, double* %42, align 8, !dbg !201
  %44 = fmul double %40, %43, !dbg !202
  %45 = fadd double %35, %44, !dbg !203
  %46 = sext i32 %.1 to i64, !dbg !204
  %47 = getelementptr inbounds double, double* getelementptr inbounds ([410 x double], [410 x double]* @q, i64 0, i64 0), i64 %46, !dbg !204
  store double %45, double* %47, align 8, !dbg !205
  %48 = add nsw i32 %.0, 1, !dbg !206
  call void @llvm.dbg.value(metadata i32 %48, metadata !184, metadata !DIExpression()), !dbg !154
  br label %15, !dbg !207, !llvm.loop !208

49:                                               ; preds = %15
  %50 = add nsw i32 %.1, 1, !dbg !210
  call void @llvm.dbg.value(metadata i32 %50, metadata !162, metadata !DIExpression()), !dbg !154
  br label %10, !dbg !211, !llvm.loop !212

51:                                               ; preds = %10
  ret i32 0, !dbg !214
}

; Function Attrs: noinline nounwind uwtable
define dso_local i32 @workload_checksum(i32 noundef %0) #0 !dbg !215 {
  call void @llvm.dbg.value(metadata i32 %0, metadata !218, metadata !DIExpression()), !dbg !219
  store i32 -2128831035, i32* @pb_hash, align 4, !dbg !220
  %2 = load i32, i32* @m, align 4, !dbg !221
  %3 = load i32, i32* @n, align 4, !dbg !222
  call void @print_array(i32 noundef %2, i32 noundef %3, double* noundef getelementptr inbounds ([390 x double], [390 x double]* @s, i64 0, i64 0), double* noundef getelementptr inbounds ([410 x double], [410 x double]* @q, i64 0, i64 0)), !dbg !223
  %4 = load i32, i32* @pb_hash, align 4, !dbg !224
  ret i32 %4, !dbg !225
}

; Function Attrs: noinline nounwind uwtable
define internal void @print_array(i32 noundef %0, i32 noundef %1, double* noundef %2, double* noundef %3) #0 !dbg !226 {
  call void @llvm.dbg.value(metadata i32 %0, metadata !229, metadata !DIExpression()), !dbg !230
  call void @llvm.dbg.value(metadata i32 %1, metadata !231, metadata !DIExpression()), !dbg !230
  call void @llvm.dbg.value(metadata double* %2, metadata !232, metadata !DIExpression()), !dbg !230
  call void @llvm.dbg.value(metadata double* %3, metadata !233, metadata !DIExpression()), !dbg !230
  %5 = load %struct._IO_FILE*, %struct._IO_FILE** @stderr, align 8, !dbg !234
  %6 = call i32 (%struct._IO_FILE*, i8*, ...) @pb_fprintf(%struct._IO_FILE* noundef %5, i8* noundef getelementptr inbounds ([23 x i8], [23 x i8]* @.str.2, i64 0, i64 0)), !dbg !234
  %7 = load %struct._IO_FILE*, %struct._IO_FILE** @stderr, align 8, !dbg !235
  %8 = call i32 (%struct._IO_FILE*, i8*, ...) @pb_fprintf(%struct._IO_FILE* noundef %7, i8* noundef getelementptr inbounds ([15 x i8], [15 x i8]* @.str.3, i64 0, i64 0), i8* noundef getelementptr inbounds ([2 x i8], [2 x i8]* @.str.4, i64 0, i64 0)), !dbg !235
  call void @llvm.dbg.value(metadata i32 0, metadata !236, metadata !DIExpression()), !dbg !230
  br label %9, !dbg !237

9:                                                ; preds = %23, %4
  %.0 = phi i32 [ 0, %4 ], [ %24, %23 ], !dbg !239
  call void @llvm.dbg.value(metadata i32 %.0, metadata !236, metadata !DIExpression()), !dbg !230
  %10 = icmp slt i32 %.0, %0, !dbg !240
  br i1 %10, label %11, label %25, !dbg !242

11:                                               ; preds = %9
  %12 = srem i32 %.0, 20, !dbg !243
  %13 = icmp eq i32 %12, 0, !dbg !246
  br i1 %13, label %14, label %17, !dbg !247

14:                                               ; preds = %11
  %15 = load %struct._IO_FILE*, %struct._IO_FILE** @stderr, align 8, !dbg !248
  %16 = call i32 (%struct._IO_FILE*, i8*, ...) @pb_fprintf(%struct._IO_FILE* noundef %15, i8* noundef getelementptr inbounds ([2 x i8], [2 x i8]* @.str.5, i64 0, i64 0)), !dbg !249
  br label %17, !dbg !249

17:                                               ; preds = %14, %11
  %18 = load %struct._IO_FILE*, %struct._IO_FILE** @stderr, align 8, !dbg !250
  %19 = sext i32 %.0 to i64, !dbg !251
  %20 = getelementptr inbounds double, double* %2, i64 %19, !dbg !251
  %21 = load double, double* %20, align 8, !dbg !251
  %22 = call i32 (%struct._IO_FILE*, i8*, ...) @pb_fprintf(%struct._IO_FILE* noundef %18, i8* noundef getelementptr inbounds ([8 x i8], [8 x i8]* @.str.6, i64 0, i64 0), double noundef %21), !dbg !252
  br label %23, !dbg !253

23:                                               ; preds = %17
  %24 = add nsw i32 %.0, 1, !dbg !254
  call void @llvm.dbg.value(metadata i32 %24, metadata !236, metadata !DIExpression()), !dbg !230
  br label %9, !dbg !255, !llvm.loop !256

25:                                               ; preds = %9
  %26 = load %struct._IO_FILE*, %struct._IO_FILE** @stderr, align 8, !dbg !258
  %27 = call i32 (%struct._IO_FILE*, i8*, ...) @pb_fprintf(%struct._IO_FILE* noundef %26, i8* noundef getelementptr inbounds ([17 x i8], [17 x i8]* @.str.7, i64 0, i64 0), i8* noundef getelementptr inbounds ([2 x i8], [2 x i8]* @.str.4, i64 0, i64 0)), !dbg !258
  %28 = load %struct._IO_FILE*, %struct._IO_FILE** @stderr, align 8, !dbg !259
  %29 = call i32 (%struct._IO_FILE*, i8*, ...) @pb_fprintf(%struct._IO_FILE* noundef %28, i8* noundef getelementptr inbounds ([15 x i8], [15 x i8]* @.str.3, i64 0, i64 0), i8* noundef getelementptr inbounds ([2 x i8], [2 x i8]* @.str.8, i64 0, i64 0)), !dbg !259
  call void @llvm.dbg.value(metadata i32 0, metadata !236, metadata !DIExpression()), !dbg !230
  br label %30, !dbg !260

30:                                               ; preds = %44, %25
  %.1 = phi i32 [ 0, %25 ], [ %45, %44 ], !dbg !262
  call void @llvm.dbg.value(metadata i32 %.1, metadata !236, metadata !DIExpression()), !dbg !230
  %31 = icmp slt i32 %.1, %1, !dbg !263
  br i1 %31, label %32, label %46, !dbg !265

32:                                               ; preds = %30
  %33 = srem i32 %.1, 20, !dbg !266
  %34 = icmp eq i32 %33, 0, !dbg !269
  br i1 %34, label %35, label %38, !dbg !270

35:                                               ; preds = %32
  %36 = load %struct._IO_FILE*, %struct._IO_FILE** @stderr, align 8, !dbg !271
  %37 = call i32 (%struct._IO_FILE*, i8*, ...) @pb_fprintf(%struct._IO_FILE* noundef %36, i8* noundef getelementptr inbounds ([2 x i8], [2 x i8]* @.str.5, i64 0, i64 0)), !dbg !272
  br label %38, !dbg !272

38:                                               ; preds = %35, %32
  %39 = load %struct._IO_FILE*, %struct._IO_FILE** @stderr, align 8, !dbg !273
  %40 = sext i32 %.1 to i64, !dbg !274
  %41 = getelementptr inbounds double, double* %3, i64 %40, !dbg !274
  %42 = load double, double* %41, align 8, !dbg !274
  %43 = call i32 (%struct._IO_FILE*, i8*, ...) @pb_fprintf(%struct._IO_FILE* noundef %39, i8* noundef getelementptr inbounds ([8 x i8], [8 x i8]* @.str.6, i64 0, i64 0), double noundef %42), !dbg !275
  br label %44, !dbg !276

44:                                               ; preds = %38
  %45 = add nsw i32 %.1, 1, !dbg !277
  call void @llvm.dbg.value(metadata i32 %45, metadata !236, metadata !DIExpression()), !dbg !230
  br label %30, !dbg !278, !llvm.loop !279

46:                                               ; preds = %30
  %47 = load %struct._IO_FILE*, %struct._IO_FILE** @stderr, align 8, !dbg !281
  %48 = call i32 (%struct._IO_FILE*, i8*, ...) @pb_fprintf(%struct._IO_FILE* noundef %47, i8* noundef getelementptr inbounds ([17 x i8], [17 x i8]* @.str.7, i64 0, i64 0), i8* noundef getelementptr inbounds ([2 x i8], [2 x i8]* @.str.8, i64 0, i64 0)), !dbg !281
  %49 = load %struct._IO_FILE*, %struct._IO_FILE** @stderr, align 8, !dbg !282
  %50 = call i32 (%struct._IO_FILE*, i8*, ...) @pb_fprintf(%struct._IO_FILE* noundef %49, i8* noundef getelementptr inbounds ([23 x i8], [23 x i8]* @.str.9, i64 0, i64 0)), !dbg !282
  ret void, !dbg !283
}

; Function Attrs: noinline nounwind uwtable
define internal i32 @pb_fprintf(%struct._IO_FILE* noundef %0, i8* noundef %1, ...) #0 !dbg !284 {
  %3 = alloca [768 x i8], align 16
  %4 = alloca [1 x %struct.__va_list_tag], align 16
  call void @llvm.dbg.value(metadata %struct._IO_FILE* %0, metadata !348, metadata !DIExpression()), !dbg !349
  call void @llvm.dbg.value(metadata i8* %1, metadata !350, metadata !DIExpression()), !dbg !349
  call void @llvm.dbg.declare(metadata [768 x i8]* %3, metadata !351, metadata !DIExpression()), !dbg !355
  call void @llvm.dbg.declare(metadata [1 x %struct.__va_list_tag]* %4, metadata !356, metadata !DIExpression()), !dbg !370
  %5 = getelementptr inbounds [1 x %struct.__va_list_tag], [1 x %struct.__va_list_tag]* %4, i64 0, i64 0, !dbg !371
  %6 = bitcast %struct.__va_list_tag* %5 to i8*, !dbg !371
  call void @llvm.va_start(i8* %6), !dbg !371
  %7 = getelementptr inbounds [768 x i8], [768 x i8]* %3, i64 0, i64 0, !dbg !372
  %8 = getelementptr inbounds [1 x %struct.__va_list_tag], [1 x %struct.__va_list_tag]* %4, i64 0, i64 0, !dbg !373
  %9 = call i32 @vsnprintf(i8* noundef %7, i64 noundef 768, i8* noundef %1, %struct.__va_list_tag* noundef %8) #6, !dbg !374
  call void @llvm.dbg.value(metadata i32 %9, metadata !375, metadata !DIExpression()), !dbg !349
  %10 = getelementptr inbounds [1 x %struct.__va_list_tag], [1 x %struct.__va_list_tag]* %4, i64 0, i64 0, !dbg !376
  %11 = bitcast %struct.__va_list_tag* %10 to i8*, !dbg !376
  call void @llvm.va_end(i8* %11), !dbg !376
  %12 = icmp slt i32 %9, 0, !dbg !377
  br i1 %12, label %16, label %13, !dbg !379

13:                                               ; preds = %2
  %14 = zext i32 %9 to i64, !dbg !380
  %15 = icmp uge i64 %14, 768, !dbg !381
  br i1 %15, label %16, label %17, !dbg !382

16:                                               ; preds = %13, %2
  call void @abort() #7, !dbg !383
  unreachable, !dbg !383

17:                                               ; preds = %13
  call void @llvm.dbg.value(metadata i32 0, metadata !384, metadata !DIExpression()), !dbg !386
  br label %18, !dbg !387

18:                                               ; preds = %29, %17
  %.0 = phi i32 [ 0, %17 ], [ %30, %29 ], !dbg !386
  call void @llvm.dbg.value(metadata i32 %.0, metadata !384, metadata !DIExpression()), !dbg !386
  %19 = icmp slt i32 %.0, %9, !dbg !388
  br i1 %19, label %20, label %31, !dbg !390

20:                                               ; preds = %18
  %21 = sext i32 %.0 to i64, !dbg !391
  %22 = getelementptr inbounds [768 x i8], [768 x i8]* %3, i64 0, i64 %21, !dbg !391
  %23 = load i8, i8* %22, align 1, !dbg !391
  %24 = zext i8 %23 to i32, !dbg !393
  %25 = load i32, i32* @pb_hash, align 4, !dbg !394
  %26 = xor i32 %25, %24, !dbg !394
  store i32 %26, i32* @pb_hash, align 4, !dbg !394
  %27 = load i32, i32* @pb_hash, align 4, !dbg !395
  %28 = mul i32 %27, 16777619, !dbg !395
  store i32 %28, i32* @pb_hash, align 4, !dbg !395
  br label %29, !dbg !396

29:                                               ; preds = %20
  %30 = add nsw i32 %.0, 1, !dbg !397
  call void @llvm.dbg.value(metadata i32 %30, metadata !384, metadata !DIExpression()), !dbg !386
  br label %18, !dbg !398, !llvm.loop !399

31:                                               ; preds = %18
  %32 = load i32, i32* @pb_emit, align 4, !dbg !401
  ret i32 %9, !dbg !402
}

; Function Attrs: nofree nosync nounwind willreturn
declare void @llvm.va_start(i8*) #3

; Function Attrs: nounwind
declare i32 @vsnprintf(i8* noundef, i64 noundef, i8* noundef, %struct.__va_list_tag* noundef) #4

; Function Attrs: nofree nosync nounwind willreturn
declare void @llvm.va_end(i8*) #3

; Function Attrs: noreturn nounwind
declare void @abort() #5

; Function Attrs: nofree nosync nounwind readnone speculatable willreturn
declare void @llvm.dbg.value(metadata, metadata, metadata) #1

attributes #0 = { noinline nounwind uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { nofree nosync nounwind readnone speculatable willreturn }
attributes #2 = { argmemonly nofree nounwind willreturn writeonly }
attributes #3 = { nofree nosync nounwind willreturn }
attributes #4 = { nounwind "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #5 = { noreturn nounwind "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #6 = { nounwind }
attributes #7 = { noreturn nounwind }

!llvm.dbg.cu = !{!2}
!llvm.module.flags = !{!53, !54, !55, !56, !57, !58, !59}
!llvm.ident = !{!60}

!0 = !DIGlobalVariableExpression(var: !1, expr: !DIExpression())
!1 = distinct !DIGlobalVariable(name: "n", scope: !2, file: !11, line: 114, type: !12, isLocal: false, isDefinition: true)
!2 = distinct !DICompileUnit(language: DW_LANG_C99, file: !3, producer: "Ubuntu clang version 14.0.0-1ubuntu1.1", isOptimized: false, runtimeVersion: 0, emissionKind: FullDebug, retainedTypes: !4, globals: !8, splitDebugInlining: false, nameTableKind: None)
!3 = !DIFile(filename: "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/affine-bounds-20260929/suite/bicg/source/workload.c", directory: "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/affine-bounds-20260929/suite/bicg/analysis-c", checksumkind: CSK_MD5, checksum: "e8f798e8b436f689a83dca6308f17ffb")
!4 = !{!5, !6, !7}
!5 = !DIBasicType(name: "double", size: 64, encoding: DW_ATE_float)
!6 = !DIBasicType(name: "unsigned int", size: 32, encoding: DW_ATE_unsigned)
!7 = !DIBasicType(name: "unsigned char", size: 8, encoding: DW_ATE_unsigned_char)
!8 = !{!0, !9, !13, !26, !30, !33, !39, !43, !47, !49, !51}
!9 = !DIGlobalVariableExpression(var: !10, expr: !DIExpression())
!10 = distinct !DIGlobalVariable(name: "m", scope: !2, file: !11, line: 115, type: !12, isLocal: false, isDefinition: true)
!11 = !DIFile(filename: "source/workload.c", directory: "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/affine-bounds-20260929/suite/bicg", checksumkind: CSK_MD5, checksum: "e8f798e8b436f689a83dca6308f17ffb")
!12 = !DIBasicType(name: "int", size: 32, encoding: DW_ATE_signed)
!13 = !DIGlobalVariableExpression(var: !14, expr: !DIExpression())
!14 = distinct !DIGlobalVariable(name: "workload_jobs", scope: !2, file: !11, line: 144, type: !15, isLocal: false, isDefinition: true)
!15 = !DICompositeType(tag: DW_TAG_array_type, baseType: !16, size: 64, elements: !24)
!16 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !17)
!17 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !18, size: 64)
!18 = !DISubroutineType(types: !19)
!19 = !{!20}
!20 = !DIDerivedType(tag: DW_TAG_typedef, name: "uint32_t", file: !21, line: 26, baseType: !22)
!21 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/stdint-uintn.h", directory: "", checksumkind: CSK_MD5, checksum: "2bf2ae53c58c01b1a1b9383b5195125c")
!22 = !DIDerivedType(tag: DW_TAG_typedef, name: "__uint32_t", file: !23, line: 42, baseType: !6)
!23 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/types.h", directory: "", checksumkind: CSK_MD5, checksum: "d108b5f93a74c50510d7d9bc0ab36df9")
!24 = !{!25}
!25 = !DISubrange(count: 1)
!26 = !DIGlobalVariableExpression(var: !27, expr: !DIExpression())
!27 = distinct !DIGlobalVariable(name: "workload_expected", scope: !2, file: !11, line: 148, type: !28, isLocal: false, isDefinition: true)
!28 = !DICompositeType(tag: DW_TAG_array_type, baseType: !29, size: 32, elements: !24)
!29 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !20)
!30 = !DIGlobalVariableExpression(var: !31, expr: !DIExpression())
!31 = distinct !DIGlobalVariable(name: "pb_hash", scope: !2, file: !32, line: 9, type: !20, isLocal: true, isDefinition: true)
!32 = !DIFile(filename: "source/adapter.h", directory: "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/affine-bounds-20260929/suite/bicg", checksumkind: CSK_MD5, checksum: "26a6068928b2092758f244a9d00163d7")
!33 = !DIGlobalVariableExpression(var: !34, expr: !DIExpression())
!34 = distinct !DIGlobalVariable(name: "A", scope: !2, file: !11, line: 34, type: !35, isLocal: false, isDefinition: true, align: 512)
!35 = !DICompositeType(tag: DW_TAG_array_type, baseType: !5, size: 10233600, elements: !36)
!36 = !{!37, !38}
!37 = !DISubrange(count: 410)
!38 = !DISubrange(count: 390)
!39 = !DIGlobalVariableExpression(var: !40, expr: !DIExpression())
!40 = distinct !DIGlobalVariable(name: "s", scope: !2, file: !11, line: 35, type: !41, isLocal: false, isDefinition: true, align: 512)
!41 = !DICompositeType(tag: DW_TAG_array_type, baseType: !5, size: 24960, elements: !42)
!42 = !{!38}
!43 = !DIGlobalVariableExpression(var: !44, expr: !DIExpression())
!44 = distinct !DIGlobalVariable(name: "q", scope: !2, file: !11, line: 36, type: !45, isLocal: false, isDefinition: true, align: 512)
!45 = !DICompositeType(tag: DW_TAG_array_type, baseType: !5, size: 26240, elements: !46)
!46 = !{!37}
!47 = !DIGlobalVariableExpression(var: !48, expr: !DIExpression())
!48 = distinct !DIGlobalVariable(name: "p", scope: !2, file: !11, line: 37, type: !41, isLocal: false, isDefinition: true, align: 512)
!49 = !DIGlobalVariableExpression(var: !50, expr: !DIExpression())
!50 = distinct !DIGlobalVariable(name: "r", scope: !2, file: !11, line: 38, type: !45, isLocal: false, isDefinition: true, align: 512)
!51 = !DIGlobalVariableExpression(var: !52, expr: !DIExpression())
!52 = distinct !DIGlobalVariable(name: "pb_emit", scope: !2, file: !32, line: 10, type: !12, isLocal: true, isDefinition: true)
!53 = !{i32 7, !"Dwarf Version", i32 5}
!54 = !{i32 2, !"Debug Info Version", i32 3}
!55 = !{i32 1, !"wchar_size", i32 4}
!56 = !{i32 7, !"PIC Level", i32 2}
!57 = !{i32 7, !"PIE Level", i32 2}
!58 = !{i32 7, !"uwtable", i32 1}
!59 = !{i32 7, !"frame-pointer", i32 2}
!60 = !{!"Ubuntu clang version 14.0.0-1ubuntu1.1"}
!61 = distinct !DISubprogram(name: "workload_prepare", scope: !11, file: !11, line: 116, type: !62, scopeLine: 116, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !2, retainedNodes: !64)
!62 = !DISubroutineType(types: !63)
!63 = !{null}
!64 = !{}
!65 = !DILocation(line: 116, column: 30, scope: !61)
!66 = distinct !DISubprogram(name: "workload_reset", scope: !11, file: !11, line: 117, type: !67, scopeLine: 117, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !2, retainedNodes: !64)
!67 = !DISubroutineType(types: !68)
!68 = !{null, !6}
!69 = !DILocalVariable(name: "task", arg: 1, scope: !66, file: !11, line: 117, type: !6)
!70 = !DILocation(line: 0, scope: !66)
!71 = !DILocation(line: 119, column: 3, scope: !66)
!72 = !DILocation(line: 120, column: 3, scope: !66)
!73 = !DILocation(line: 121, column: 3, scope: !66)
!74 = !DILocation(line: 122, column: 3, scope: !66)
!75 = !DILocation(line: 123, column: 3, scope: !66)
!76 = !DILocation(line: 124, column: 15, scope: !66)
!77 = !DILocation(line: 124, column: 18, scope: !66)
!78 = !DILocation(line: 124, column: 3, scope: !66)
!79 = !DILocation(line: 128, column: 1, scope: !66)
!80 = distinct !DISubprogram(name: "init_array", scope: !11, file: !11, line: 40, type: !81, scopeLine: 44, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition, unit: !2, retainedNodes: !64)
!81 = !DISubroutineType(types: !82)
!82 = !{null, !12, !12, !83, !84, !84}
!83 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !41, size: 64)
!84 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !5, size: 64)
!85 = !DILocalVariable(name: "m", arg: 1, scope: !80, file: !11, line: 40, type: !12)
!86 = !DILocation(line: 0, scope: !80)
!87 = !DILocalVariable(name: "n", arg: 2, scope: !80, file: !11, line: 40, type: !12)
!88 = !DILocalVariable(name: "A", arg: 3, scope: !80, file: !11, line: 41, type: !83)
!89 = !DILocalVariable(name: "r", arg: 4, scope: !80, file: !11, line: 42, type: !84)
!90 = !DILocalVariable(name: "p", arg: 5, scope: !80, file: !11, line: 43, type: !84)
!91 = !DILocalVariable(name: "i", scope: !80, file: !11, line: 45, type: !12)
!92 = !DILocation(line: 47, column: 8, scope: !93)
!93 = distinct !DILexicalBlock(scope: !80, file: !11, line: 47, column: 3)
!94 = !DILocation(line: 0, scope: !93)
!95 = !DILocation(line: 47, column: 17, scope: !96)
!96 = distinct !DILexicalBlock(scope: !93, file: !11, line: 47, column: 3)
!97 = !DILocation(line: 47, column: 3, scope: !93)
!98 = !DILocation(line: 48, column: 26, scope: !96)
!99 = !DILocation(line: 48, column: 12, scope: !96)
!100 = !DILocation(line: 48, column: 33, scope: !96)
!101 = !DILocation(line: 48, column: 31, scope: !96)
!102 = !DILocation(line: 48, column: 5, scope: !96)
!103 = !DILocation(line: 48, column: 10, scope: !96)
!104 = !DILocation(line: 47, column: 23, scope: !96)
!105 = !DILocation(line: 47, column: 3, scope: !96)
!106 = distinct !{!106, !97, !107, !108}
!107 = !DILocation(line: 48, column: 33, scope: !93)
!108 = !{!"llvm.loop.mustprogress"}
!109 = !DILocation(line: 49, column: 8, scope: !110)
!110 = distinct !DILexicalBlock(scope: !80, file: !11, line: 49, column: 3)
!111 = !DILocation(line: 0, scope: !110)
!112 = !DILocation(line: 49, column: 17, scope: !113)
!113 = distinct !DILexicalBlock(scope: !110, file: !11, line: 49, column: 3)
!114 = !DILocation(line: 49, column: 3, scope: !110)
!115 = !DILocation(line: 50, column: 26, scope: !116)
!116 = distinct !DILexicalBlock(scope: !113, file: !11, line: 49, column: 27)
!117 = !DILocation(line: 50, column: 12, scope: !116)
!118 = !DILocation(line: 50, column: 33, scope: !116)
!119 = !DILocation(line: 50, column: 31, scope: !116)
!120 = !DILocation(line: 50, column: 5, scope: !116)
!121 = !DILocation(line: 50, column: 10, scope: !116)
!122 = !DILocalVariable(name: "j", scope: !80, file: !11, line: 45, type: !12)
!123 = !DILocation(line: 51, column: 10, scope: !124)
!124 = distinct !DILexicalBlock(scope: !116, file: !11, line: 51, column: 5)
!125 = !DILocation(line: 0, scope: !124)
!126 = !DILocation(line: 51, column: 19, scope: !127)
!127 = distinct !DILexicalBlock(scope: !124, file: !11, line: 51, column: 5)
!128 = !DILocation(line: 51, column: 5, scope: !124)
!129 = !DILocation(line: 52, column: 34, scope: !127)
!130 = !DILocation(line: 52, column: 31, scope: !127)
!131 = !DILocation(line: 52, column: 38, scope: !127)
!132 = !DILocation(line: 52, column: 17, scope: !127)
!133 = !DILocation(line: 52, column: 43, scope: !127)
!134 = !DILocation(line: 52, column: 42, scope: !127)
!135 = !DILocation(line: 52, column: 7, scope: !127)
!136 = !DILocation(line: 52, column: 15, scope: !127)
!137 = !DILocation(line: 51, column: 25, scope: !127)
!138 = !DILocation(line: 51, column: 5, scope: !127)
!139 = distinct !{!139, !128, !140, !108}
!140 = !DILocation(line: 52, column: 43, scope: !124)
!141 = !DILocation(line: 53, column: 3, scope: !116)
!142 = !DILocation(line: 49, column: 23, scope: !113)
!143 = !DILocation(line: 49, column: 3, scope: !113)
!144 = distinct !{!144, !114, !145, !108}
!145 = !DILocation(line: 53, column: 3, scope: !110)
!146 = !DILocation(line: 54, column: 1, scope: !80)
!147 = distinct !DISubprogram(name: "task_job_polybench", scope: !11, file: !11, line: 129, type: !18, scopeLine: 129, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !2, retainedNodes: !64)
!148 = !DILocation(line: 130, column: 16, scope: !147)
!149 = !DILocation(line: 130, column: 19, scope: !147)
!150 = !DILocalVariable(name: "m", arg: 1, scope: !151, file: !11, line: 87, type: !12)
!151 = distinct !DISubprogram(name: "kernel_bicg", scope: !11, file: !11, line: 87, type: !152, scopeLine: 93, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition, unit: !2, retainedNodes: !64)
!152 = !DISubroutineType(types: !153)
!153 = !{null, !12, !12, !83, !84, !84, !84, !84}
!154 = !DILocation(line: 0, scope: !151, inlinedAt: !155)
!155 = distinct !DILocation(line: 130, column: 3, scope: !147)
!156 = !DILocalVariable(name: "n", arg: 2, scope: !151, file: !11, line: 87, type: !12)
!157 = !DILocalVariable(name: "A", arg: 3, scope: !151, file: !11, line: 88, type: !83)
!158 = !DILocalVariable(name: "s", arg: 4, scope: !151, file: !11, line: 89, type: !84)
!159 = !DILocalVariable(name: "q", arg: 5, scope: !151, file: !11, line: 90, type: !84)
!160 = !DILocalVariable(name: "p", arg: 6, scope: !151, file: !11, line: 91, type: !84)
!161 = !DILocalVariable(name: "r", arg: 7, scope: !151, file: !11, line: 92, type: !84)
!162 = !DILocalVariable(name: "i", scope: !151, file: !11, line: 94, type: !12)
!163 = !DILocation(line: 97, column: 8, scope: !164, inlinedAt: !155)
!164 = distinct !DILexicalBlock(scope: !151, file: !11, line: 97, column: 3)
!165 = !DILocation(line: 0, scope: !164, inlinedAt: !155)
!166 = !DILocation(line: 97, column: 17, scope: !167, inlinedAt: !155)
!167 = distinct !DILexicalBlock(scope: !164, file: !11, line: 97, column: 3)
!168 = !DILocation(line: 97, column: 3, scope: !164, inlinedAt: !155)
!169 = !DILocation(line: 98, column: 5, scope: !167, inlinedAt: !155)
!170 = !DILocation(line: 98, column: 10, scope: !167, inlinedAt: !155)
!171 = !DILocation(line: 97, column: 27, scope: !167, inlinedAt: !155)
!172 = !DILocation(line: 97, column: 3, scope: !167, inlinedAt: !155)
!173 = distinct !{!173, !168, !174, !108}
!174 = !DILocation(line: 98, column: 12, scope: !164, inlinedAt: !155)
!175 = !DILocation(line: 99, column: 8, scope: !176, inlinedAt: !155)
!176 = distinct !DILexicalBlock(scope: !151, file: !11, line: 99, column: 3)
!177 = !DILocation(line: 0, scope: !176, inlinedAt: !155)
!178 = !DILocation(line: 99, column: 17, scope: !179, inlinedAt: !155)
!179 = distinct !DILexicalBlock(scope: !176, file: !11, line: 99, column: 3)
!180 = !DILocation(line: 99, column: 3, scope: !176, inlinedAt: !155)
!181 = !DILocation(line: 101, column: 7, scope: !182, inlinedAt: !155)
!182 = distinct !DILexicalBlock(scope: !179, file: !11, line: 100, column: 5)
!183 = !DILocation(line: 101, column: 12, scope: !182, inlinedAt: !155)
!184 = !DILocalVariable(name: "j", scope: !151, file: !11, line: 94, type: !12)
!185 = !DILocation(line: 102, column: 12, scope: !186, inlinedAt: !155)
!186 = distinct !DILexicalBlock(scope: !182, file: !11, line: 102, column: 7)
!187 = !DILocation(line: 0, scope: !186, inlinedAt: !155)
!188 = !DILocation(line: 102, column: 21, scope: !189, inlinedAt: !155)
!189 = distinct !DILexicalBlock(scope: !186, file: !11, line: 102, column: 7)
!190 = !DILocation(line: 102, column: 7, scope: !186, inlinedAt: !155)
!191 = !DILocation(line: 104, column: 11, scope: !192, inlinedAt: !155)
!192 = distinct !DILexicalBlock(scope: !189, file: !11, line: 103, column: 2)
!193 = !DILocation(line: 104, column: 18, scope: !192, inlinedAt: !155)
!194 = !DILocation(line: 104, column: 25, scope: !192, inlinedAt: !155)
!195 = !DILocation(line: 104, column: 23, scope: !192, inlinedAt: !155)
!196 = !DILocation(line: 104, column: 16, scope: !192, inlinedAt: !155)
!197 = !DILocation(line: 104, column: 4, scope: !192, inlinedAt: !155)
!198 = !DILocation(line: 104, column: 9, scope: !192, inlinedAt: !155)
!199 = !DILocation(line: 105, column: 11, scope: !192, inlinedAt: !155)
!200 = !DILocation(line: 105, column: 18, scope: !192, inlinedAt: !155)
!201 = !DILocation(line: 105, column: 28, scope: !192, inlinedAt: !155)
!202 = !DILocation(line: 105, column: 26, scope: !192, inlinedAt: !155)
!203 = !DILocation(line: 105, column: 16, scope: !192, inlinedAt: !155)
!204 = !DILocation(line: 105, column: 4, scope: !192, inlinedAt: !155)
!205 = !DILocation(line: 105, column: 9, scope: !192, inlinedAt: !155)
!206 = !DILocation(line: 102, column: 31, scope: !189, inlinedAt: !155)
!207 = !DILocation(line: 102, column: 7, scope: !189, inlinedAt: !155)
!208 = distinct !{!208, !190, !209, !108}
!209 = !DILocation(line: 106, column: 2, scope: !186, inlinedAt: !155)
!210 = !DILocation(line: 99, column: 27, scope: !179, inlinedAt: !155)
!211 = !DILocation(line: 99, column: 3, scope: !179, inlinedAt: !155)
!212 = distinct !{!212, !180, !213, !108}
!213 = !DILocation(line: 107, column: 5, scope: !176, inlinedAt: !155)
!214 = !DILocation(line: 136, column: 3, scope: !147)
!215 = distinct !DISubprogram(name: "workload_checksum", scope: !11, file: !11, line: 138, type: !216, scopeLine: 138, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !2, retainedNodes: !64)
!216 = !DISubroutineType(types: !217)
!217 = !{!20, !6}
!218 = !DILocalVariable(name: "task", arg: 1, scope: !215, file: !11, line: 138, type: !6)
!219 = !DILocation(line: 0, scope: !215)
!220 = !DILocation(line: 140, column: 11, scope: !215)
!221 = !DILocation(line: 141, column: 15, scope: !215)
!222 = !DILocation(line: 141, column: 18, scope: !215)
!223 = !DILocation(line: 141, column: 3, scope: !215)
!224 = !DILocation(line: 142, column: 10, scope: !215)
!225 = !DILocation(line: 142, column: 3, scope: !215)
!226 = distinct !DISubprogram(name: "print_array", scope: !11, file: !11, line: 60, type: !227, scopeLine: 64, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition, unit: !2, retainedNodes: !64)
!227 = !DISubroutineType(types: !228)
!228 = !{null, !12, !12, !84, !84}
!229 = !DILocalVariable(name: "m", arg: 1, scope: !226, file: !11, line: 60, type: !12)
!230 = !DILocation(line: 0, scope: !226)
!231 = !DILocalVariable(name: "n", arg: 2, scope: !226, file: !11, line: 60, type: !12)
!232 = !DILocalVariable(name: "s", arg: 3, scope: !226, file: !11, line: 61, type: !84)
!233 = !DILocalVariable(name: "q", arg: 4, scope: !226, file: !11, line: 62, type: !84)
!234 = !DILocation(line: 67, column: 3, scope: !226)
!235 = !DILocation(line: 68, column: 3, scope: !226)
!236 = !DILocalVariable(name: "i", scope: !226, file: !11, line: 65, type: !12)
!237 = !DILocation(line: 69, column: 8, scope: !238)
!238 = distinct !DILexicalBlock(scope: !226, file: !11, line: 69, column: 3)
!239 = !DILocation(line: 0, scope: !238)
!240 = !DILocation(line: 69, column: 17, scope: !241)
!241 = distinct !DILexicalBlock(scope: !238, file: !11, line: 69, column: 3)
!242 = !DILocation(line: 69, column: 3, scope: !238)
!243 = !DILocation(line: 70, column: 11, scope: !244)
!244 = distinct !DILexicalBlock(scope: !245, file: !11, line: 70, column: 9)
!245 = distinct !DILexicalBlock(scope: !241, file: !11, line: 69, column: 27)
!246 = !DILocation(line: 70, column: 16, scope: !244)
!247 = !DILocation(line: 70, column: 9, scope: !245)
!248 = !DILocation(line: 70, column: 31, scope: !244)
!249 = !DILocation(line: 70, column: 22, scope: !244)
!250 = !DILocation(line: 71, column: 14, scope: !245)
!251 = !DILocation(line: 71, column: 59, scope: !245)
!252 = !DILocation(line: 71, column: 5, scope: !245)
!253 = !DILocation(line: 72, column: 3, scope: !245)
!254 = !DILocation(line: 69, column: 23, scope: !241)
!255 = !DILocation(line: 69, column: 3, scope: !241)
!256 = distinct !{!256, !242, !257, !108}
!257 = !DILocation(line: 72, column: 3, scope: !238)
!258 = !DILocation(line: 73, column: 3, scope: !226)
!259 = !DILocation(line: 74, column: 3, scope: !226)
!260 = !DILocation(line: 75, column: 8, scope: !261)
!261 = distinct !DILexicalBlock(scope: !226, file: !11, line: 75, column: 3)
!262 = !DILocation(line: 0, scope: !261)
!263 = !DILocation(line: 75, column: 17, scope: !264)
!264 = distinct !DILexicalBlock(scope: !261, file: !11, line: 75, column: 3)
!265 = !DILocation(line: 75, column: 3, scope: !261)
!266 = !DILocation(line: 76, column: 11, scope: !267)
!267 = distinct !DILexicalBlock(scope: !268, file: !11, line: 76, column: 9)
!268 = distinct !DILexicalBlock(scope: !264, file: !11, line: 75, column: 27)
!269 = !DILocation(line: 76, column: 16, scope: !267)
!270 = !DILocation(line: 76, column: 9, scope: !268)
!271 = !DILocation(line: 76, column: 31, scope: !267)
!272 = !DILocation(line: 76, column: 22, scope: !267)
!273 = !DILocation(line: 77, column: 14, scope: !268)
!274 = !DILocation(line: 77, column: 59, scope: !268)
!275 = !DILocation(line: 77, column: 5, scope: !268)
!276 = !DILocation(line: 78, column: 3, scope: !268)
!277 = !DILocation(line: 75, column: 23, scope: !264)
!278 = !DILocation(line: 75, column: 3, scope: !264)
!279 = distinct !{!279, !265, !280, !108}
!280 = !DILocation(line: 78, column: 3, scope: !261)
!281 = !DILocation(line: 79, column: 3, scope: !226)
!282 = !DILocation(line: 80, column: 3, scope: !226)
!283 = !DILocation(line: 81, column: 1, scope: !226)
!284 = distinct !DISubprogram(name: "pb_fprintf", scope: !32, file: !32, line: 13, type: !285, scopeLine: 14, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition, unit: !2, retainedNodes: !64)
!285 = !DISubroutineType(types: !286)
!286 = !{!12, !287, !346, null}
!287 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !288, size: 64)
!288 = !DIDerivedType(tag: DW_TAG_typedef, name: "FILE", file: !289, line: 7, baseType: !290)
!289 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/types/FILE.h", directory: "", checksumkind: CSK_MD5, checksum: "571f9fb6223c42439075fdde11a0de5d")
!290 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "_IO_FILE", file: !291, line: 49, size: 1728, elements: !292)
!291 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/types/struct_FILE.h", directory: "", checksumkind: CSK_MD5, checksum: "1bad07471b7974df4ecc1d1c2ca207e6")
!292 = !{!293, !294, !297, !298, !299, !300, !301, !302, !303, !304, !305, !306, !307, !310, !312, !313, !314, !317, !319, !321, !323, !326, !328, !331, !334, !335, !337, !341, !342}
!293 = !DIDerivedType(tag: DW_TAG_member, name: "_flags", scope: !290, file: !291, line: 51, baseType: !12, size: 32)
!294 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_read_ptr", scope: !290, file: !291, line: 54, baseType: !295, size: 64, offset: 64)
!295 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !296, size: 64)
!296 = !DIBasicType(name: "char", size: 8, encoding: DW_ATE_signed_char)
!297 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_read_end", scope: !290, file: !291, line: 55, baseType: !295, size: 64, offset: 128)
!298 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_read_base", scope: !290, file: !291, line: 56, baseType: !295, size: 64, offset: 192)
!299 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_write_base", scope: !290, file: !291, line: 57, baseType: !295, size: 64, offset: 256)
!300 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_write_ptr", scope: !290, file: !291, line: 58, baseType: !295, size: 64, offset: 320)
!301 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_write_end", scope: !290, file: !291, line: 59, baseType: !295, size: 64, offset: 384)
!302 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_buf_base", scope: !290, file: !291, line: 60, baseType: !295, size: 64, offset: 448)
!303 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_buf_end", scope: !290, file: !291, line: 61, baseType: !295, size: 64, offset: 512)
!304 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_save_base", scope: !290, file: !291, line: 64, baseType: !295, size: 64, offset: 576)
!305 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_backup_base", scope: !290, file: !291, line: 65, baseType: !295, size: 64, offset: 640)
!306 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_save_end", scope: !290, file: !291, line: 66, baseType: !295, size: 64, offset: 704)
!307 = !DIDerivedType(tag: DW_TAG_member, name: "_markers", scope: !290, file: !291, line: 68, baseType: !308, size: 64, offset: 768)
!308 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !309, size: 64)
!309 = !DICompositeType(tag: DW_TAG_structure_type, name: "_IO_marker", file: !291, line: 36, flags: DIFlagFwdDecl)
!310 = !DIDerivedType(tag: DW_TAG_member, name: "_chain", scope: !290, file: !291, line: 70, baseType: !311, size: 64, offset: 832)
!311 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !290, size: 64)
!312 = !DIDerivedType(tag: DW_TAG_member, name: "_fileno", scope: !290, file: !291, line: 72, baseType: !12, size: 32, offset: 896)
!313 = !DIDerivedType(tag: DW_TAG_member, name: "_flags2", scope: !290, file: !291, line: 73, baseType: !12, size: 32, offset: 928)
!314 = !DIDerivedType(tag: DW_TAG_member, name: "_old_offset", scope: !290, file: !291, line: 74, baseType: !315, size: 64, offset: 960)
!315 = !DIDerivedType(tag: DW_TAG_typedef, name: "__off_t", file: !23, line: 152, baseType: !316)
!316 = !DIBasicType(name: "long", size: 64, encoding: DW_ATE_signed)
!317 = !DIDerivedType(tag: DW_TAG_member, name: "_cur_column", scope: !290, file: !291, line: 77, baseType: !318, size: 16, offset: 1024)
!318 = !DIBasicType(name: "unsigned short", size: 16, encoding: DW_ATE_unsigned)
!319 = !DIDerivedType(tag: DW_TAG_member, name: "_vtable_offset", scope: !290, file: !291, line: 78, baseType: !320, size: 8, offset: 1040)
!320 = !DIBasicType(name: "signed char", size: 8, encoding: DW_ATE_signed_char)
!321 = !DIDerivedType(tag: DW_TAG_member, name: "_shortbuf", scope: !290, file: !291, line: 79, baseType: !322, size: 8, offset: 1048)
!322 = !DICompositeType(tag: DW_TAG_array_type, baseType: !296, size: 8, elements: !24)
!323 = !DIDerivedType(tag: DW_TAG_member, name: "_lock", scope: !290, file: !291, line: 81, baseType: !324, size: 64, offset: 1088)
!324 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !325, size: 64)
!325 = !DIDerivedType(tag: DW_TAG_typedef, name: "_IO_lock_t", file: !291, line: 43, baseType: null)
!326 = !DIDerivedType(tag: DW_TAG_member, name: "_offset", scope: !290, file: !291, line: 89, baseType: !327, size: 64, offset: 1152)
!327 = !DIDerivedType(tag: DW_TAG_typedef, name: "__off64_t", file: !23, line: 153, baseType: !316)
!328 = !DIDerivedType(tag: DW_TAG_member, name: "_codecvt", scope: !290, file: !291, line: 91, baseType: !329, size: 64, offset: 1216)
!329 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !330, size: 64)
!330 = !DICompositeType(tag: DW_TAG_structure_type, name: "_IO_codecvt", file: !291, line: 37, flags: DIFlagFwdDecl)
!331 = !DIDerivedType(tag: DW_TAG_member, name: "_wide_data", scope: !290, file: !291, line: 92, baseType: !332, size: 64, offset: 1280)
!332 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !333, size: 64)
!333 = !DICompositeType(tag: DW_TAG_structure_type, name: "_IO_wide_data", file: !291, line: 38, flags: DIFlagFwdDecl)
!334 = !DIDerivedType(tag: DW_TAG_member, name: "_freeres_list", scope: !290, file: !291, line: 93, baseType: !311, size: 64, offset: 1344)
!335 = !DIDerivedType(tag: DW_TAG_member, name: "_freeres_buf", scope: !290, file: !291, line: 94, baseType: !336, size: 64, offset: 1408)
!336 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: null, size: 64)
!337 = !DIDerivedType(tag: DW_TAG_member, name: "__pad5", scope: !290, file: !291, line: 95, baseType: !338, size: 64, offset: 1472)
!338 = !DIDerivedType(tag: DW_TAG_typedef, name: "size_t", file: !339, line: 46, baseType: !340)
!339 = !DIFile(filename: "/usr/lib/llvm-14/lib/clang/14.0.0/include/stddef.h", directory: "", checksumkind: CSK_MD5, checksum: "2499dd2361b915724b073282bea3a7bc")
!340 = !DIBasicType(name: "unsigned long", size: 64, encoding: DW_ATE_unsigned)
!341 = !DIDerivedType(tag: DW_TAG_member, name: "_mode", scope: !290, file: !291, line: 96, baseType: !12, size: 32, offset: 1536)
!342 = !DIDerivedType(tag: DW_TAG_member, name: "_unused2", scope: !290, file: !291, line: 98, baseType: !343, size: 160, offset: 1568)
!343 = !DICompositeType(tag: DW_TAG_array_type, baseType: !296, size: 160, elements: !344)
!344 = !{!345}
!345 = !DISubrange(count: 20)
!346 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !347, size: 64)
!347 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !296)
!348 = !DILocalVariable(name: "stream", arg: 1, scope: !284, file: !32, line: 13, type: !287)
!349 = !DILocation(line: 0, scope: !284)
!350 = !DILocalVariable(name: "format", arg: 2, scope: !284, file: !32, line: 13, type: !346)
!351 = !DILocalVariable(name: "buffer", scope: !284, file: !32, line: 15, type: !352)
!352 = !DICompositeType(tag: DW_TAG_array_type, baseType: !296, size: 6144, elements: !353)
!353 = !{!354}
!354 = !DISubrange(count: 768)
!355 = !DILocation(line: 15, column: 10, scope: !284)
!356 = !DILocalVariable(name: "args", scope: !284, file: !32, line: 16, type: !357)
!357 = !DIDerivedType(tag: DW_TAG_typedef, name: "va_list", file: !358, line: 52, baseType: !359)
!358 = !DIFile(filename: "/usr/include/stdio.h", directory: "", checksumkind: CSK_MD5, checksum: "f31eefcc3f15835fc5a4023a625cf609")
!359 = !DIDerivedType(tag: DW_TAG_typedef, name: "__gnuc_va_list", file: !360, line: 32, baseType: !361)
!360 = !DIFile(filename: "/usr/lib/llvm-14/lib/clang/14.0.0/include/stdarg.h", directory: "", checksumkind: CSK_MD5, checksum: "4de3cbd931b589d291e5c39387aecf82")
!361 = !DIDerivedType(tag: DW_TAG_typedef, name: "__builtin_va_list", file: !362, baseType: !363)
!362 = !DIFile(filename: "source/workload.c", directory: "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/affine-bounds-20260929/suite/bicg")
!363 = !DICompositeType(tag: DW_TAG_array_type, baseType: !364, size: 192, elements: !24)
!364 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "__va_list_tag", size: 192, elements: !365)
!365 = !{!366, !367, !368, !369}
!366 = !DIDerivedType(tag: DW_TAG_member, name: "gp_offset", scope: !364, file: !362, line: 16, baseType: !6, size: 32)
!367 = !DIDerivedType(tag: DW_TAG_member, name: "fp_offset", scope: !364, file: !362, line: 16, baseType: !6, size: 32, offset: 32)
!368 = !DIDerivedType(tag: DW_TAG_member, name: "overflow_arg_area", scope: !364, file: !362, line: 16, baseType: !336, size: 64, offset: 64)
!369 = !DIDerivedType(tag: DW_TAG_member, name: "reg_save_area", scope: !364, file: !362, line: 16, baseType: !336, size: 64, offset: 128)
!370 = !DILocation(line: 16, column: 13, scope: !284)
!371 = !DILocation(line: 17, column: 5, scope: !284)
!372 = !DILocation(line: 18, column: 27, scope: !284)
!373 = !DILocation(line: 18, column: 59, scope: !284)
!374 = !DILocation(line: 18, column: 17, scope: !284)
!375 = !DILocalVariable(name: "count", scope: !284, file: !32, line: 18, type: !12)
!376 = !DILocation(line: 19, column: 5, scope: !284)
!377 = !DILocation(line: 20, column: 15, scope: !378)
!378 = distinct !DILexicalBlock(scope: !284, file: !32, line: 20, column: 9)
!379 = !DILocation(line: 20, column: 19, scope: !378)
!380 = !DILocation(line: 20, column: 22, scope: !378)
!381 = !DILocation(line: 20, column: 38, scope: !378)
!382 = !DILocation(line: 20, column: 9, scope: !284)
!383 = !DILocation(line: 20, column: 57, scope: !378)
!384 = !DILocalVariable(name: "i", scope: !385, file: !32, line: 21, type: !12)
!385 = distinct !DILexicalBlock(scope: !284, file: !32, line: 21, column: 5)
!386 = !DILocation(line: 0, scope: !385)
!387 = !DILocation(line: 21, column: 10, scope: !385)
!388 = !DILocation(line: 21, column: 23, scope: !389)
!389 = distinct !DILexicalBlock(scope: !385, file: !32, line: 21, column: 5)
!390 = !DILocation(line: 21, column: 5, scope: !385)
!391 = !DILocation(line: 22, column: 35, scope: !392)
!392 = distinct !DILexicalBlock(scope: !389, file: !32, line: 21, column: 37)
!393 = !DILocation(line: 22, column: 20, scope: !392)
!394 = !DILocation(line: 22, column: 17, scope: !392)
!395 = !DILocation(line: 23, column: 17, scope: !392)
!396 = !DILocation(line: 24, column: 5, scope: !392)
!397 = !DILocation(line: 21, column: 32, scope: !389)
!398 = !DILocation(line: 21, column: 5, scope: !389)
!399 = distinct !{!399, !390, !400, !108}
!400 = !DILocation(line: 24, column: 5, scope: !385)
!401 = !DILocation(line: 29, column: 11, scope: !284)
!402 = !DILocation(line: 31, column: 5, scope: !284)
