; ModuleID = 'inlined.ll'
source_filename = "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/affine-bounds-20260929/suite/covariance/source/workload.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

@n = external dso_local global i32, align 4, !dbg !0
@m = external dso_local global i32, align 4, !dbg !9
@data = external dso_local global [260 x [240 x double]], section ".chaser_data.data", align 64, !dbg !13
@cov = external dso_local global [240 x [240 x double]], section ".chaser_data.cov", align 64, !dbg !19
@mean = external dso_local global [240 x double], section ".chaser_data.mean", align 64, !dbg !23
@float_n = external dso_local global double, align 8, !dbg !27
@.str = hidden unnamed_addr constant [12 x i8] c"ape.analyze\00", section "llvm.metadata"
@.str.1 = hidden unnamed_addr constant [128 x i8] c"/workspace/experiments-array-support/chaser/.cache/periodic-polybench/affine-bounds-20260929/suite/covariance/source/workload.c\00", section "llvm.metadata"
@.str.2 = hidden unnamed_addr constant [23 x i8] c"==BEGIN DUMP_ARRAYS==\0A\00", align 1
@.str.3 = hidden unnamed_addr constant [15 x i8] c"begin dump: %s\00", align 1
@.str.4 = hidden unnamed_addr constant [4 x i8] c"cov\00", align 1
@.str.5 = hidden unnamed_addr constant [2 x i8] c"\0A\00", align 1
@.str.6 = hidden unnamed_addr constant [8 x i8] c"%0.2lf \00", align 1
@.str.7 = hidden unnamed_addr constant [17 x i8] c"\0Aend   dump: %s\0A\00", align 1
@.str.8 = hidden unnamed_addr constant [23 x i8] c"==END   DUMP_ARRAYS==\0A\00", align 1
@llvm.global.annotations = appending global [1 x { i8*, i8*, i8*, i32, i8* }] [{ i8*, i8*, i8*, i32, i8* } { i8* bitcast (i32 ()* @task_job_polybench to i8*), i8* getelementptr inbounds ([12 x i8], [12 x i8]* @.str, i32 0, i32 0), i8* getelementptr inbounds ([128 x i8], [128 x i8]* @.str.1, i32 0, i32 0), i32 125, i8* null }], section "llvm.metadata"

; Function Attrs: noinline nounwind uwtable
define dso_local i32 @task_job_polybench() #0 !dbg !37 {
  %1 = load i32, i32* @m, align 4, !dbg !45
  %2 = load i32, i32* @n, align 4, !dbg !46
  %3 = load double, double* @float_n, align 8, !dbg !47
  call void @llvm.dbg.value(metadata i32 %1, metadata !48, metadata !DIExpression()), !dbg !54
  call void @llvm.dbg.value(metadata i32 %2, metadata !56, metadata !DIExpression()), !dbg !54
  call void @llvm.dbg.value(metadata double %3, metadata !57, metadata !DIExpression()), !dbg !54
  call void @llvm.dbg.value(metadata [240 x double]* getelementptr inbounds ([260 x [240 x double]], [260 x [240 x double]]* @data, i64 0, i64 0), metadata !58, metadata !DIExpression()), !dbg !54
  call void @llvm.dbg.value(metadata [240 x double]* getelementptr inbounds ([240 x [240 x double]], [240 x [240 x double]]* @cov, i64 0, i64 0), metadata !59, metadata !DIExpression()), !dbg !54
  call void @llvm.dbg.value(metadata double* getelementptr inbounds ([240 x double], [240 x double]* @mean, i64 0, i64 0), metadata !60, metadata !DIExpression()), !dbg !54
  call void @llvm.dbg.value(metadata i32 0, metadata !61, metadata !DIExpression()), !dbg !54
  br label %4, !dbg !62

4:                                                ; preds = %22, %0
  %.01 = phi i32 [ 0, %0 ], [ %27, %22 ], !dbg !64
  call void @llvm.dbg.value(metadata i32 %.01, metadata !61, metadata !DIExpression()), !dbg !54
  %5 = icmp slt i32 %.01, 240, !dbg !65
  br i1 %5, label %6, label %28, !dbg !67

6:                                                ; preds = %4
  %7 = sext i32 %.01 to i64, !dbg !68
  %8 = getelementptr inbounds double, double* getelementptr inbounds ([240 x double], [240 x double]* @mean, i64 0, i64 0), i64 %7, !dbg !68
  store double 0.000000e+00, double* %8, align 8, !dbg !70
  call void @llvm.dbg.value(metadata i32 0, metadata !71, metadata !DIExpression()), !dbg !54
  br label %9, !dbg !72

9:                                                ; preds = %11, %6
  %.02 = phi i32 [ 0, %6 ], [ %21, %11 ], !dbg !74
  call void @llvm.dbg.value(metadata i32 %.02, metadata !71, metadata !DIExpression()), !dbg !54
  %10 = icmp slt i32 %.02, 260, !dbg !75
  br i1 %10, label %11, label %22, !dbg !77

11:                                               ; preds = %9
  %12 = sext i32 %.02 to i64, !dbg !78
  %13 = getelementptr inbounds [240 x double], [240 x double]* getelementptr inbounds ([260 x [240 x double]], [260 x [240 x double]]* @data, i64 0, i64 0), i64 %12, !dbg !78
  %14 = sext i32 %.01 to i64, !dbg !78
  %15 = getelementptr inbounds [240 x double], [240 x double]* %13, i64 0, i64 %14, !dbg !78
  %16 = load double, double* %15, align 8, !dbg !78
  %17 = sext i32 %.01 to i64, !dbg !79
  %18 = getelementptr inbounds double, double* getelementptr inbounds ([240 x double], [240 x double]* @mean, i64 0, i64 0), i64 %17, !dbg !79
  %19 = load double, double* %18, align 8, !dbg !80
  %20 = fadd double %19, %16, !dbg !80
  store double %20, double* %18, align 8, !dbg !80
  %21 = add nsw i32 %.02, 1, !dbg !81
  call void @llvm.dbg.value(metadata i32 %21, metadata !71, metadata !DIExpression()), !dbg !54
  br label %9, !dbg !82, !llvm.loop !83

22:                                               ; preds = %9
  %23 = sext i32 %.01 to i64, !dbg !86
  %24 = getelementptr inbounds double, double* getelementptr inbounds ([240 x double], [240 x double]* @mean, i64 0, i64 0), i64 %23, !dbg !86
  %25 = load double, double* %24, align 8, !dbg !87
  %26 = fdiv double %25, %3, !dbg !87
  store double %26, double* %24, align 8, !dbg !87
  %27 = add nsw i32 %.01, 1, !dbg !88
  call void @llvm.dbg.value(metadata i32 %27, metadata !61, metadata !DIExpression()), !dbg !54
  br label %4, !dbg !89, !llvm.loop !90

28:                                               ; preds = %4
  call void @llvm.dbg.value(metadata i32 0, metadata !71, metadata !DIExpression()), !dbg !54
  br label %29, !dbg !92

29:                                               ; preds = %45, %28
  %.13 = phi i32 [ 0, %28 ], [ %46, %45 ], !dbg !94
  call void @llvm.dbg.value(metadata i32 %.13, metadata !71, metadata !DIExpression()), !dbg !54
  %30 = icmp slt i32 %.13, 260, !dbg !95
  br i1 %30, label %31, label %47, !dbg !97

31:                                               ; preds = %29
  call void @llvm.dbg.value(metadata i32 0, metadata !61, metadata !DIExpression()), !dbg !54
  br label %32, !dbg !98

32:                                               ; preds = %34, %31
  %.1 = phi i32 [ 0, %31 ], [ %44, %34 ], !dbg !100
  call void @llvm.dbg.value(metadata i32 %.1, metadata !61, metadata !DIExpression()), !dbg !54
  %33 = icmp slt i32 %.1, 240, !dbg !101
  br i1 %33, label %34, label %45, !dbg !103

34:                                               ; preds = %32
  %35 = sext i32 %.1 to i64, !dbg !104
  %36 = getelementptr inbounds double, double* getelementptr inbounds ([240 x double], [240 x double]* @mean, i64 0, i64 0), i64 %35, !dbg !104
  %37 = load double, double* %36, align 8, !dbg !104
  %38 = sext i32 %.13 to i64, !dbg !105
  %39 = getelementptr inbounds [240 x double], [240 x double]* getelementptr inbounds ([260 x [240 x double]], [260 x [240 x double]]* @data, i64 0, i64 0), i64 %38, !dbg !105
  %40 = sext i32 %.1 to i64, !dbg !105
  %41 = getelementptr inbounds [240 x double], [240 x double]* %39, i64 0, i64 %40, !dbg !105
  %42 = load double, double* %41, align 8, !dbg !106
  %43 = fsub double %42, %37, !dbg !106
  store double %43, double* %41, align 8, !dbg !106
  %44 = add nsw i32 %.1, 1, !dbg !107
  call void @llvm.dbg.value(metadata i32 %44, metadata !61, metadata !DIExpression()), !dbg !54
  br label %32, !dbg !108, !llvm.loop !109

45:                                               ; preds = %32
  %46 = add nsw i32 %.13, 1, !dbg !111
  call void @llvm.dbg.value(metadata i32 %46, metadata !71, metadata !DIExpression()), !dbg !54
  br label %29, !dbg !112, !llvm.loop !113

47:                                               ; preds = %29
  call void @llvm.dbg.value(metadata i32 0, metadata !71, metadata !DIExpression()), !dbg !54
  br label %48, !dbg !115

48:                                               ; preds = %97, %47
  %.24 = phi i32 [ 0, %47 ], [ %98, %97 ], !dbg !117
  call void @llvm.dbg.value(metadata i32 %.24, metadata !71, metadata !DIExpression()), !dbg !54
  %49 = icmp slt i32 %.24, 240, !dbg !118
  br i1 %49, label %50, label %99, !dbg !120

50:                                               ; preds = %48
  call void @llvm.dbg.value(metadata i32 %.24, metadata !61, metadata !DIExpression()), !dbg !54
  br label %51, !dbg !121

51:                                               ; preds = %79, %50
  %.2 = phi i32 [ %.24, %50 ], [ %96, %79 ], !dbg !123
  call void @llvm.dbg.value(metadata i32 %.2, metadata !61, metadata !DIExpression()), !dbg !54
  %52 = icmp slt i32 %.2, 240, !dbg !124
  br i1 %52, label %53, label %97, !dbg !126

53:                                               ; preds = %51
  %54 = sext i32 %.24 to i64, !dbg !127
  %55 = getelementptr inbounds [240 x double], [240 x double]* getelementptr inbounds ([240 x [240 x double]], [240 x [240 x double]]* @cov, i64 0, i64 0), i64 %54, !dbg !127
  %56 = sext i32 %.2 to i64, !dbg !127
  %57 = getelementptr inbounds [240 x double], [240 x double]* %55, i64 0, i64 %56, !dbg !127
  store double 0.000000e+00, double* %57, align 8, !dbg !129
  call void @llvm.dbg.value(metadata i32 0, metadata !130, metadata !DIExpression()), !dbg !54
  br label %58, !dbg !131

58:                                               ; preds = %60, %53
  %.0 = phi i32 [ 0, %53 ], [ %78, %60 ], !dbg !133
  call void @llvm.dbg.value(metadata i32 %.0, metadata !130, metadata !DIExpression()), !dbg !54
  %59 = icmp slt i32 %.0, 260, !dbg !134
  br i1 %59, label %60, label %79, !dbg !136

60:                                               ; preds = %58
  %61 = sext i32 %.0 to i64, !dbg !137
  %62 = getelementptr inbounds [240 x double], [240 x double]* getelementptr inbounds ([260 x [240 x double]], [260 x [240 x double]]* @data, i64 0, i64 0), i64 %61, !dbg !137
  %63 = sext i32 %.24 to i64, !dbg !137
  %64 = getelementptr inbounds [240 x double], [240 x double]* %62, i64 0, i64 %63, !dbg !137
  %65 = load double, double* %64, align 8, !dbg !137
  %66 = sext i32 %.0 to i64, !dbg !138
  %67 = getelementptr inbounds [240 x double], [240 x double]* getelementptr inbounds ([260 x [240 x double]], [260 x [240 x double]]* @data, i64 0, i64 0), i64 %66, !dbg !138
  %68 = sext i32 %.2 to i64, !dbg !138
  %69 = getelementptr inbounds [240 x double], [240 x double]* %67, i64 0, i64 %68, !dbg !138
  %70 = load double, double* %69, align 8, !dbg !138
  %71 = fmul double %65, %70, !dbg !139
  %72 = sext i32 %.24 to i64, !dbg !140
  %73 = getelementptr inbounds [240 x double], [240 x double]* getelementptr inbounds ([240 x [240 x double]], [240 x [240 x double]]* @cov, i64 0, i64 0), i64 %72, !dbg !140
  %74 = sext i32 %.2 to i64, !dbg !140
  %75 = getelementptr inbounds [240 x double], [240 x double]* %73, i64 0, i64 %74, !dbg !140
  %76 = load double, double* %75, align 8, !dbg !141
  %77 = fadd double %76, %71, !dbg !141
  store double %77, double* %75, align 8, !dbg !141
  %78 = add nsw i32 %.0, 1, !dbg !142
  call void @llvm.dbg.value(metadata i32 %78, metadata !130, metadata !DIExpression()), !dbg !54
  br label %58, !dbg !143, !llvm.loop !144

79:                                               ; preds = %58
  %80 = fsub double %3, 1.000000e+00, !dbg !146
  %81 = sext i32 %.24 to i64, !dbg !147
  %82 = getelementptr inbounds [240 x double], [240 x double]* getelementptr inbounds ([240 x [240 x double]], [240 x [240 x double]]* @cov, i64 0, i64 0), i64 %81, !dbg !147
  %83 = sext i32 %.2 to i64, !dbg !147
  %84 = getelementptr inbounds [240 x double], [240 x double]* %82, i64 0, i64 %83, !dbg !147
  %85 = load double, double* %84, align 8, !dbg !148
  %86 = fdiv double %85, %80, !dbg !148
  store double %86, double* %84, align 8, !dbg !148
  %87 = sext i32 %.24 to i64, !dbg !149
  %88 = getelementptr inbounds [240 x double], [240 x double]* getelementptr inbounds ([240 x [240 x double]], [240 x [240 x double]]* @cov, i64 0, i64 0), i64 %87, !dbg !149
  %89 = sext i32 %.2 to i64, !dbg !149
  %90 = getelementptr inbounds [240 x double], [240 x double]* %88, i64 0, i64 %89, !dbg !149
  %91 = load double, double* %90, align 8, !dbg !149
  %92 = sext i32 %.2 to i64, !dbg !150
  %93 = getelementptr inbounds [240 x double], [240 x double]* getelementptr inbounds ([240 x [240 x double]], [240 x [240 x double]]* @cov, i64 0, i64 0), i64 %92, !dbg !150
  %94 = sext i32 %.24 to i64, !dbg !150
  %95 = getelementptr inbounds [240 x double], [240 x double]* %93, i64 0, i64 %94, !dbg !150
  store double %91, double* %95, align 8, !dbg !151
  %96 = add nsw i32 %.2, 1, !dbg !152
  call void @llvm.dbg.value(metadata i32 %96, metadata !61, metadata !DIExpression()), !dbg !54
  br label %51, !dbg !153, !llvm.loop !154

97:                                               ; preds = %51
  %98 = add nsw i32 %.24, 1, !dbg !156
  call void @llvm.dbg.value(metadata i32 %98, metadata !71, metadata !DIExpression()), !dbg !54
  br label %48, !dbg !157, !llvm.loop !158

99:                                               ; preds = %48
  ret i32 0, !dbg !160
}

; Function Attrs: nofree nosync nounwind readnone speculatable willreturn
declare void @llvm.dbg.value(metadata, metadata, metadata) #1

attributes #0 = { noinline nounwind uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { nofree nosync nounwind readnone speculatable willreturn }

!llvm.dbg.cu = !{!2}
!llvm.module.flags = !{!29, !30, !31, !32, !33, !34, !35}
!llvm.ident = !{!36}

!0 = !DIGlobalVariableExpression(var: !1, expr: !DIExpression())
!1 = distinct !DIGlobalVariable(name: "n", scope: !2, file: !11, line: 112, type: !12, isLocal: false, isDefinition: true)
!2 = distinct !DICompileUnit(language: DW_LANG_C99, file: !3, producer: "Ubuntu clang version 14.0.0-1ubuntu1.1", isOptimized: false, runtimeVersion: 0, emissionKind: FullDebug, retainedTypes: !4, globals: !8, splitDebugInlining: false, nameTableKind: None)
!3 = !DIFile(filename: "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/affine-bounds-20260929/suite/covariance/source/workload.c", directory: "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/affine-bounds-20260929/suite/covariance/analysis-native", checksumkind: CSK_MD5, checksum: "5266233317551a092f7140d5a93b2e7f")
!4 = !{!5, !6, !7}
!5 = !DIBasicType(name: "double", size: 64, encoding: DW_ATE_float)
!6 = !DIBasicType(name: "unsigned int", size: 32, encoding: DW_ATE_unsigned)
!7 = !DIBasicType(name: "unsigned char", size: 8, encoding: DW_ATE_unsigned_char)
!8 = !{!0, !9, !13, !19, !23, !27}
!9 = !DIGlobalVariableExpression(var: !10, expr: !DIExpression())
!10 = distinct !DIGlobalVariable(name: "m", scope: !2, file: !11, line: 113, type: !12, isLocal: false, isDefinition: true)
!11 = !DIFile(filename: "source/workload.c", directory: "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/affine-bounds-20260929/suite/covariance", checksumkind: CSK_MD5, checksum: "5266233317551a092f7140d5a93b2e7f")
!12 = !DIBasicType(name: "int", size: 32, encoding: DW_ATE_signed)
!13 = !DIGlobalVariableExpression(var: !14, expr: !DIExpression())
!14 = distinct !DIGlobalVariable(name: "data", scope: !2, file: !11, line: 34, type: !15, isLocal: false, isDefinition: true, align: 512)
!15 = !DICompositeType(tag: DW_TAG_array_type, baseType: !5, size: 3993600, elements: !16)
!16 = !{!17, !18}
!17 = !DISubrange(count: 260)
!18 = !DISubrange(count: 240)
!19 = !DIGlobalVariableExpression(var: !20, expr: !DIExpression())
!20 = distinct !DIGlobalVariable(name: "cov", scope: !2, file: !11, line: 35, type: !21, isLocal: false, isDefinition: true, align: 512)
!21 = !DICompositeType(tag: DW_TAG_array_type, baseType: !5, size: 3686400, elements: !22)
!22 = !{!18, !18}
!23 = !DIGlobalVariableExpression(var: !24, expr: !DIExpression())
!24 = distinct !DIGlobalVariable(name: "mean", scope: !2, file: !11, line: 36, type: !25, isLocal: false, isDefinition: true, align: 512)
!25 = !DICompositeType(tag: DW_TAG_array_type, baseType: !5, size: 15360, elements: !26)
!26 = !{!18}
!27 = !DIGlobalVariableExpression(var: !28, expr: !DIExpression())
!28 = distinct !DIGlobalVariable(name: "float_n", scope: !2, file: !11, line: 116, type: !5, isLocal: false, isDefinition: true)
!29 = !{i32 7, !"Dwarf Version", i32 5}
!30 = !{i32 2, !"Debug Info Version", i32 3}
!31 = !{i32 1, !"wchar_size", i32 4}
!32 = !{i32 7, !"PIC Level", i32 2}
!33 = !{i32 7, !"PIE Level", i32 2}
!34 = !{i32 7, !"uwtable", i32 1}
!35 = !{i32 7, !"frame-pointer", i32 2}
!36 = !{!"Ubuntu clang version 14.0.0-1ubuntu1.1"}
!37 = distinct !DISubprogram(name: "task_job_polybench", scope: !11, file: !11, line: 125, type: !38, scopeLine: 125, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !2, retainedNodes: !44)
!38 = !DISubroutineType(types: !39)
!39 = !{!40}
!40 = !DIDerivedType(tag: DW_TAG_typedef, name: "uint32_t", file: !41, line: 26, baseType: !42)
!41 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/stdint-uintn.h", directory: "", checksumkind: CSK_MD5, checksum: "2bf2ae53c58c01b1a1b9383b5195125c")
!42 = !DIDerivedType(tag: DW_TAG_typedef, name: "__uint32_t", file: !43, line: 42, baseType: !6)
!43 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/types.h", directory: "", checksumkind: CSK_MD5, checksum: "d108b5f93a74c50510d7d9bc0ab36df9")
!44 = !{}
!45 = !DILocation(line: 126, column: 22, scope: !37)
!46 = !DILocation(line: 126, column: 25, scope: !37)
!47 = !DILocation(line: 126, column: 28, scope: !37)
!48 = !DILocalVariable(name: "m", arg: 1, scope: !49, file: !11, line: 76, type: !12)
!49 = distinct !DISubprogram(name: "kernel_covariance", scope: !11, file: !11, line: 76, type: !50, scopeLine: 81, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition, unit: !2, retainedNodes: !44)
!50 = !DISubroutineType(types: !51)
!51 = !{null, !12, !12, !5, !52, !52, !53}
!52 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !25, size: 64)
!53 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !5, size: 64)
!54 = !DILocation(line: 0, scope: !49, inlinedAt: !55)
!55 = distinct !DILocation(line: 126, column: 3, scope: !37)
!56 = !DILocalVariable(name: "n", arg: 2, scope: !49, file: !11, line: 76, type: !12)
!57 = !DILocalVariable(name: "float_n", arg: 3, scope: !49, file: !11, line: 77, type: !5)
!58 = !DILocalVariable(name: "data", arg: 4, scope: !49, file: !11, line: 78, type: !52)
!59 = !DILocalVariable(name: "cov", arg: 5, scope: !49, file: !11, line: 79, type: !52)
!60 = !DILocalVariable(name: "mean", arg: 6, scope: !49, file: !11, line: 80, type: !53)
!61 = !DILocalVariable(name: "j", scope: !49, file: !11, line: 82, type: !12)
!62 = !DILocation(line: 85, column: 8, scope: !63, inlinedAt: !55)
!63 = distinct !DILexicalBlock(scope: !49, file: !11, line: 85, column: 3)
!64 = !DILocation(line: 0, scope: !63, inlinedAt: !55)
!65 = !DILocation(line: 85, column: 17, scope: !66, inlinedAt: !55)
!66 = distinct !DILexicalBlock(scope: !63, file: !11, line: 85, column: 3)
!67 = !DILocation(line: 85, column: 3, scope: !63, inlinedAt: !55)
!68 = !DILocation(line: 87, column: 7, scope: !69, inlinedAt: !55)
!69 = distinct !DILexicalBlock(scope: !66, file: !11, line: 86, column: 5)
!70 = !DILocation(line: 87, column: 15, scope: !69, inlinedAt: !55)
!71 = !DILocalVariable(name: "i", scope: !49, file: !11, line: 82, type: !12)
!72 = !DILocation(line: 88, column: 12, scope: !73, inlinedAt: !55)
!73 = distinct !DILexicalBlock(scope: !69, file: !11, line: 88, column: 7)
!74 = !DILocation(line: 0, scope: !73, inlinedAt: !55)
!75 = !DILocation(line: 88, column: 21, scope: !76, inlinedAt: !55)
!76 = distinct !DILexicalBlock(scope: !73, file: !11, line: 88, column: 7)
!77 = !DILocation(line: 88, column: 7, scope: !73, inlinedAt: !55)
!78 = !DILocation(line: 89, column: 20, scope: !76, inlinedAt: !55)
!79 = !DILocation(line: 89, column: 9, scope: !76, inlinedAt: !55)
!80 = !DILocation(line: 89, column: 17, scope: !76, inlinedAt: !55)
!81 = !DILocation(line: 88, column: 31, scope: !76, inlinedAt: !55)
!82 = !DILocation(line: 88, column: 7, scope: !76, inlinedAt: !55)
!83 = distinct !{!83, !77, !84, !85}
!84 = !DILocation(line: 89, column: 29, scope: !73, inlinedAt: !55)
!85 = !{!"llvm.loop.mustprogress"}
!86 = !DILocation(line: 90, column: 7, scope: !69, inlinedAt: !55)
!87 = !DILocation(line: 90, column: 15, scope: !69, inlinedAt: !55)
!88 = !DILocation(line: 85, column: 27, scope: !66, inlinedAt: !55)
!89 = !DILocation(line: 85, column: 3, scope: !66, inlinedAt: !55)
!90 = distinct !{!90, !67, !91, !85}
!91 = !DILocation(line: 91, column: 5, scope: !63, inlinedAt: !55)
!92 = !DILocation(line: 93, column: 8, scope: !93, inlinedAt: !55)
!93 = distinct !DILexicalBlock(scope: !49, file: !11, line: 93, column: 3)
!94 = !DILocation(line: 0, scope: !93, inlinedAt: !55)
!95 = !DILocation(line: 93, column: 17, scope: !96, inlinedAt: !55)
!96 = distinct !DILexicalBlock(scope: !93, file: !11, line: 93, column: 3)
!97 = !DILocation(line: 93, column: 3, scope: !93, inlinedAt: !55)
!98 = !DILocation(line: 94, column: 10, scope: !99, inlinedAt: !55)
!99 = distinct !DILexicalBlock(scope: !96, file: !11, line: 94, column: 5)
!100 = !DILocation(line: 0, scope: !99, inlinedAt: !55)
!101 = !DILocation(line: 94, column: 19, scope: !102, inlinedAt: !55)
!102 = distinct !DILexicalBlock(scope: !99, file: !11, line: 94, column: 5)
!103 = !DILocation(line: 94, column: 5, scope: !99, inlinedAt: !55)
!104 = !DILocation(line: 95, column: 21, scope: !102, inlinedAt: !55)
!105 = !DILocation(line: 95, column: 7, scope: !102, inlinedAt: !55)
!106 = !DILocation(line: 95, column: 18, scope: !102, inlinedAt: !55)
!107 = !DILocation(line: 94, column: 29, scope: !102, inlinedAt: !55)
!108 = !DILocation(line: 94, column: 5, scope: !102, inlinedAt: !55)
!109 = distinct !{!109, !103, !110, !85}
!110 = !DILocation(line: 95, column: 27, scope: !99, inlinedAt: !55)
!111 = !DILocation(line: 93, column: 27, scope: !96, inlinedAt: !55)
!112 = !DILocation(line: 93, column: 3, scope: !96, inlinedAt: !55)
!113 = distinct !{!113, !97, !114, !85}
!114 = !DILocation(line: 95, column: 27, scope: !93, inlinedAt: !55)
!115 = !DILocation(line: 97, column: 8, scope: !116, inlinedAt: !55)
!116 = distinct !DILexicalBlock(scope: !49, file: !11, line: 97, column: 3)
!117 = !DILocation(line: 0, scope: !116, inlinedAt: !55)
!118 = !DILocation(line: 97, column: 17, scope: !119, inlinedAt: !55)
!119 = distinct !DILexicalBlock(scope: !116, file: !11, line: 97, column: 3)
!120 = !DILocation(line: 97, column: 3, scope: !116, inlinedAt: !55)
!121 = !DILocation(line: 98, column: 10, scope: !122, inlinedAt: !55)
!122 = distinct !DILexicalBlock(scope: !119, file: !11, line: 98, column: 5)
!123 = !DILocation(line: 0, scope: !122, inlinedAt: !55)
!124 = !DILocation(line: 98, column: 19, scope: !125, inlinedAt: !55)
!125 = distinct !DILexicalBlock(scope: !122, file: !11, line: 98, column: 5)
!126 = !DILocation(line: 98, column: 5, scope: !122, inlinedAt: !55)
!127 = !DILocation(line: 100, column: 9, scope: !128, inlinedAt: !55)
!128 = distinct !DILexicalBlock(scope: !125, file: !11, line: 99, column: 7)
!129 = !DILocation(line: 100, column: 19, scope: !128, inlinedAt: !55)
!130 = !DILocalVariable(name: "k", scope: !49, file: !11, line: 82, type: !12)
!131 = !DILocation(line: 101, column: 14, scope: !132, inlinedAt: !55)
!132 = distinct !DILexicalBlock(scope: !128, file: !11, line: 101, column: 9)
!133 = !DILocation(line: 0, scope: !132, inlinedAt: !55)
!134 = !DILocation(line: 101, column: 23, scope: !135, inlinedAt: !55)
!135 = distinct !DILexicalBlock(scope: !132, file: !11, line: 101, column: 9)
!136 = !DILocation(line: 101, column: 9, scope: !132, inlinedAt: !55)
!137 = !DILocation(line: 102, column: 17, scope: !135, inlinedAt: !55)
!138 = !DILocation(line: 102, column: 30, scope: !135, inlinedAt: !55)
!139 = !DILocation(line: 102, column: 28, scope: !135, inlinedAt: !55)
!140 = !DILocation(line: 102, column: 4, scope: !135, inlinedAt: !55)
!141 = !DILocation(line: 102, column: 14, scope: !135, inlinedAt: !55)
!142 = !DILocation(line: 101, column: 33, scope: !135, inlinedAt: !55)
!143 = !DILocation(line: 101, column: 9, scope: !135, inlinedAt: !55)
!144 = distinct !{!144, !136, !145, !85}
!145 = !DILocation(line: 102, column: 39, scope: !132, inlinedAt: !55)
!146 = !DILocation(line: 103, column: 31, scope: !128, inlinedAt: !55)
!147 = !DILocation(line: 103, column: 9, scope: !128, inlinedAt: !55)
!148 = !DILocation(line: 103, column: 19, scope: !128, inlinedAt: !55)
!149 = !DILocation(line: 104, column: 21, scope: !128, inlinedAt: !55)
!150 = !DILocation(line: 104, column: 9, scope: !128, inlinedAt: !55)
!151 = !DILocation(line: 104, column: 19, scope: !128, inlinedAt: !55)
!152 = !DILocation(line: 98, column: 29, scope: !125, inlinedAt: !55)
!153 = !DILocation(line: 98, column: 5, scope: !125, inlinedAt: !55)
!154 = distinct !{!154, !126, !155, !85}
!155 = !DILocation(line: 105, column: 7, scope: !122, inlinedAt: !55)
!156 = !DILocation(line: 97, column: 27, scope: !119, inlinedAt: !55)
!157 = !DILocation(line: 97, column: 3, scope: !119, inlinedAt: !55)
!158 = distinct !{!158, !120, !159, !85}
!159 = !DILocation(line: 105, column: 7, scope: !116, inlinedAt: !55)
!160 = !DILocation(line: 130, column: 3, scope: !37)
