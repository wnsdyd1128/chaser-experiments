; ModuleID = 'workload.ll'
source_filename = "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/affine-bounds-20260929/suite/covariance/source/workload.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

%struct._IO_FILE = type { i32, i8*, i8*, i8*, i8*, i8*, i8*, i8*, i8*, i8*, i8*, i8*, %struct._IO_marker*, %struct._IO_FILE*, i32, i32, i64, i16, i8, [1 x i8], i8*, i64, %struct._IO_codecvt*, %struct._IO_wide_data*, %struct._IO_FILE*, i8*, i64, i32, [20 x i8] }
%struct._IO_marker = type opaque
%struct._IO_codecvt = type opaque
%struct._IO_wide_data = type opaque
%struct.__va_list_tag = type { i32, i32, i8*, i8* }

@n = dso_local global i32 260, align 4, !dbg !0
@m = dso_local global i32 240, align 4, !dbg !9
@data = dso_local global [260 x [240 x double]] zeroinitializer, section ".chaser_data.data", align 64, !dbg !33
@cov = dso_local global [240 x [240 x double]] zeroinitializer, section ".chaser_data.cov", align 64, !dbg !39
@mean = dso_local global [240 x double] zeroinitializer, section ".chaser_data.mean", align 64, !dbg !43
@float_n = dso_local global double 0.000000e+00, align 8, !dbg !47
@.str = private unnamed_addr constant [12 x i8] c"ape.analyze\00", section "llvm.metadata"
@.str.1 = private unnamed_addr constant [128 x i8] c"/workspace/experiments-array-support/chaser/.cache/periodic-polybench/affine-bounds-20260929/suite/covariance/source/workload.c\00", section "llvm.metadata"
@pb_hash = internal global i32 0, align 4, !dbg !30
@workload_jobs = dso_local constant [1 x i32 ()*] [i32 ()* @task_job_polybench], align 8, !dbg !13
@workload_expected = dso_local constant [1 x i32] [i32 -1195980795], align 4, !dbg !26
@stderr = external global %struct._IO_FILE*, align 8
@.str.2 = private unnamed_addr constant [23 x i8] c"==BEGIN DUMP_ARRAYS==\0A\00", align 1
@.str.3 = private unnamed_addr constant [15 x i8] c"begin dump: %s\00", align 1
@.str.4 = private unnamed_addr constant [4 x i8] c"cov\00", align 1
@.str.5 = private unnamed_addr constant [2 x i8] c"\0A\00", align 1
@.str.6 = private unnamed_addr constant [8 x i8] c"%0.2lf \00", align 1
@.str.7 = private unnamed_addr constant [17 x i8] c"\0Aend   dump: %s\0A\00", align 1
@.str.8 = private unnamed_addr constant [23 x i8] c"==END   DUMP_ARRAYS==\0A\00", align 1
@pb_emit = internal global i32 1, align 4, !dbg !49
@llvm.global.annotations = appending global [1 x { i8*, i8*, i8*, i32, i8* }] [{ i8*, i8*, i8*, i32, i8* } { i8* bitcast (i32 ()* @task_job_polybench to i8*), i8* getelementptr inbounds ([12 x i8], [12 x i8]* @.str, i32 0, i32 0), i8* getelementptr inbounds ([128 x i8], [128 x i8]* @.str.1, i32 0, i32 0), i32 125, i8* null }], section "llvm.metadata"

; Function Attrs: noinline nounwind uwtable
define dso_local void @workload_prepare() #0 !dbg !59 {
  ret void, !dbg !63
}

; Function Attrs: noinline nounwind uwtable
define dso_local void @workload_reset(i32 noundef %0) #0 !dbg !64 {
  call void @llvm.dbg.value(metadata i32 %0, metadata !67, metadata !DIExpression()), !dbg !68
  call void @llvm.memset.p0i8.i64(i8* align 64 bitcast ([260 x [240 x double]]* @data to i8*), i8 0, i64 499200, i1 false), !dbg !69
  call void @llvm.memset.p0i8.i64(i8* align 64 bitcast ([240 x [240 x double]]* @cov to i8*), i8 0, i64 460800, i1 false), !dbg !70
  call void @llvm.memset.p0i8.i64(i8* align 64 bitcast ([240 x double]* @mean to i8*), i8 0, i64 1920, i1 false), !dbg !71
  %2 = load i32, i32* @m, align 4, !dbg !72
  %3 = load i32, i32* @n, align 4, !dbg !73
  call void @init_array(i32 noundef %2, i32 noundef %3, double* noundef @float_n, [240 x double]* noundef getelementptr inbounds ([260 x [240 x double]], [260 x [240 x double]]* @data, i64 0, i64 0)), !dbg !74
  ret void, !dbg !75
}

; Function Attrs: nofree nosync nounwind readnone speculatable willreturn
declare void @llvm.dbg.declare(metadata, metadata, metadata) #1

; Function Attrs: argmemonly nofree nounwind willreturn writeonly
declare void @llvm.memset.p0i8.i64(i8* nocapture writeonly, i8, i64, i1 immarg) #2

; Function Attrs: noinline nounwind uwtable
define internal void @init_array(i32 noundef %0, i32 noundef %1, double* noundef %2, [240 x double]* noundef %3) #0 !dbg !76 {
  call void @llvm.dbg.value(metadata i32 %0, metadata !81, metadata !DIExpression()), !dbg !82
  call void @llvm.dbg.value(metadata i32 %1, metadata !83, metadata !DIExpression()), !dbg !82
  call void @llvm.dbg.value(metadata double* %2, metadata !84, metadata !DIExpression()), !dbg !82
  call void @llvm.dbg.value(metadata [240 x double]* %3, metadata !85, metadata !DIExpression()), !dbg !82
  %5 = sitofp i32 %1 to double, !dbg !86
  store double %5, double* %2, align 8, !dbg !87
  call void @llvm.dbg.value(metadata i32 0, metadata !88, metadata !DIExpression()), !dbg !82
  br label %6, !dbg !89

6:                                                ; preds = %23, %4
  %.01 = phi i32 [ 0, %4 ], [ %24, %23 ], !dbg !91
  call void @llvm.dbg.value(metadata i32 %.01, metadata !88, metadata !DIExpression()), !dbg !82
  %7 = icmp slt i32 %.01, 260, !dbg !92
  br i1 %7, label %8, label %25, !dbg !94

8:                                                ; preds = %6
  call void @llvm.dbg.value(metadata i32 0, metadata !95, metadata !DIExpression()), !dbg !82
  br label %9, !dbg !96

9:                                                ; preds = %20, %8
  %.0 = phi i32 [ 0, %8 ], [ %21, %20 ], !dbg !98
  call void @llvm.dbg.value(metadata i32 %.0, metadata !95, metadata !DIExpression()), !dbg !82
  %10 = icmp slt i32 %.0, 240, !dbg !99
  br i1 %10, label %11, label %22, !dbg !101

11:                                               ; preds = %9
  %12 = sitofp i32 %.01 to double, !dbg !102
  %13 = sitofp i32 %.0 to double, !dbg !103
  %14 = fmul double %12, %13, !dbg !104
  %15 = fdiv double %14, 2.400000e+02, !dbg !105
  %16 = sext i32 %.01 to i64, !dbg !106
  %17 = getelementptr inbounds [240 x double], [240 x double]* %3, i64 %16, !dbg !106
  %18 = sext i32 %.0 to i64, !dbg !106
  %19 = getelementptr inbounds [240 x double], [240 x double]* %17, i64 0, i64 %18, !dbg !106
  store double %15, double* %19, align 8, !dbg !107
  br label %20, !dbg !106

20:                                               ; preds = %11
  %21 = add nsw i32 %.0, 1, !dbg !108
  call void @llvm.dbg.value(metadata i32 %21, metadata !95, metadata !DIExpression()), !dbg !82
  br label %9, !dbg !109, !llvm.loop !110

22:                                               ; preds = %9
  br label %23, !dbg !111

23:                                               ; preds = %22
  %24 = add nsw i32 %.01, 1, !dbg !113
  call void @llvm.dbg.value(metadata i32 %24, metadata !88, metadata !DIExpression()), !dbg !82
  br label %6, !dbg !114, !llvm.loop !115

25:                                               ; preds = %6
  ret void, !dbg !117
}

; Function Attrs: noinline nounwind uwtable
define dso_local i32 @task_job_polybench() #0 !dbg !118 {
  %1 = load i32, i32* @m, align 4, !dbg !119
  %2 = load i32, i32* @n, align 4, !dbg !120
  %3 = load double, double* @float_n, align 8, !dbg !121
  call void @llvm.dbg.value(metadata i32 %1, metadata !122, metadata !DIExpression()), !dbg !126
  call void @llvm.dbg.value(metadata i32 %2, metadata !128, metadata !DIExpression()), !dbg !126
  call void @llvm.dbg.value(metadata double %3, metadata !129, metadata !DIExpression()), !dbg !126
  call void @llvm.dbg.value(metadata [240 x double]* getelementptr inbounds ([260 x [240 x double]], [260 x [240 x double]]* @data, i64 0, i64 0), metadata !130, metadata !DIExpression()), !dbg !126
  call void @llvm.dbg.value(metadata [240 x double]* getelementptr inbounds ([240 x [240 x double]], [240 x [240 x double]]* @cov, i64 0, i64 0), metadata !131, metadata !DIExpression()), !dbg !126
  call void @llvm.dbg.value(metadata double* getelementptr inbounds ([240 x double], [240 x double]* @mean, i64 0, i64 0), metadata !132, metadata !DIExpression()), !dbg !126
  call void @llvm.dbg.value(metadata i32 0, metadata !133, metadata !DIExpression()), !dbg !126
  br label %4, !dbg !134

4:                                                ; preds = %22, %0
  %.01 = phi i32 [ 0, %0 ], [ %27, %22 ], !dbg !136
  call void @llvm.dbg.value(metadata i32 %.01, metadata !133, metadata !DIExpression()), !dbg !126
  %5 = icmp slt i32 %.01, 240, !dbg !137
  br i1 %5, label %6, label %28, !dbg !139

6:                                                ; preds = %4
  %7 = sext i32 %.01 to i64, !dbg !140
  %8 = getelementptr inbounds double, double* getelementptr inbounds ([240 x double], [240 x double]* @mean, i64 0, i64 0), i64 %7, !dbg !140
  store double 0.000000e+00, double* %8, align 8, !dbg !142
  call void @llvm.dbg.value(metadata i32 0, metadata !143, metadata !DIExpression()), !dbg !126
  br label %9, !dbg !144

9:                                                ; preds = %11, %6
  %.02 = phi i32 [ 0, %6 ], [ %21, %11 ], !dbg !146
  call void @llvm.dbg.value(metadata i32 %.02, metadata !143, metadata !DIExpression()), !dbg !126
  %10 = icmp slt i32 %.02, 260, !dbg !147
  br i1 %10, label %11, label %22, !dbg !149

11:                                               ; preds = %9
  %12 = sext i32 %.02 to i64, !dbg !150
  %13 = getelementptr inbounds [240 x double], [240 x double]* getelementptr inbounds ([260 x [240 x double]], [260 x [240 x double]]* @data, i64 0, i64 0), i64 %12, !dbg !150
  %14 = sext i32 %.01 to i64, !dbg !150
  %15 = getelementptr inbounds [240 x double], [240 x double]* %13, i64 0, i64 %14, !dbg !150
  %16 = load double, double* %15, align 8, !dbg !150
  %17 = sext i32 %.01 to i64, !dbg !151
  %18 = getelementptr inbounds double, double* getelementptr inbounds ([240 x double], [240 x double]* @mean, i64 0, i64 0), i64 %17, !dbg !151
  %19 = load double, double* %18, align 8, !dbg !152
  %20 = fadd double %19, %16, !dbg !152
  store double %20, double* %18, align 8, !dbg !152
  %21 = add nsw i32 %.02, 1, !dbg !153
  call void @llvm.dbg.value(metadata i32 %21, metadata !143, metadata !DIExpression()), !dbg !126
  br label %9, !dbg !154, !llvm.loop !155

22:                                               ; preds = %9
  %23 = sext i32 %.01 to i64, !dbg !157
  %24 = getelementptr inbounds double, double* getelementptr inbounds ([240 x double], [240 x double]* @mean, i64 0, i64 0), i64 %23, !dbg !157
  %25 = load double, double* %24, align 8, !dbg !158
  %26 = fdiv double %25, %3, !dbg !158
  store double %26, double* %24, align 8, !dbg !158
  %27 = add nsw i32 %.01, 1, !dbg !159
  call void @llvm.dbg.value(metadata i32 %27, metadata !133, metadata !DIExpression()), !dbg !126
  br label %4, !dbg !160, !llvm.loop !161

28:                                               ; preds = %4
  call void @llvm.dbg.value(metadata i32 0, metadata !143, metadata !DIExpression()), !dbg !126
  br label %29, !dbg !163

29:                                               ; preds = %45, %28
  %.13 = phi i32 [ 0, %28 ], [ %46, %45 ], !dbg !165
  call void @llvm.dbg.value(metadata i32 %.13, metadata !143, metadata !DIExpression()), !dbg !126
  %30 = icmp slt i32 %.13, 260, !dbg !166
  br i1 %30, label %31, label %47, !dbg !168

31:                                               ; preds = %29
  call void @llvm.dbg.value(metadata i32 0, metadata !133, metadata !DIExpression()), !dbg !126
  br label %32, !dbg !169

32:                                               ; preds = %34, %31
  %.1 = phi i32 [ 0, %31 ], [ %44, %34 ], !dbg !171
  call void @llvm.dbg.value(metadata i32 %.1, metadata !133, metadata !DIExpression()), !dbg !126
  %33 = icmp slt i32 %.1, 240, !dbg !172
  br i1 %33, label %34, label %45, !dbg !174

34:                                               ; preds = %32
  %35 = sext i32 %.1 to i64, !dbg !175
  %36 = getelementptr inbounds double, double* getelementptr inbounds ([240 x double], [240 x double]* @mean, i64 0, i64 0), i64 %35, !dbg !175
  %37 = load double, double* %36, align 8, !dbg !175
  %38 = sext i32 %.13 to i64, !dbg !176
  %39 = getelementptr inbounds [240 x double], [240 x double]* getelementptr inbounds ([260 x [240 x double]], [260 x [240 x double]]* @data, i64 0, i64 0), i64 %38, !dbg !176
  %40 = sext i32 %.1 to i64, !dbg !176
  %41 = getelementptr inbounds [240 x double], [240 x double]* %39, i64 0, i64 %40, !dbg !176
  %42 = load double, double* %41, align 8, !dbg !177
  %43 = fsub double %42, %37, !dbg !177
  store double %43, double* %41, align 8, !dbg !177
  %44 = add nsw i32 %.1, 1, !dbg !178
  call void @llvm.dbg.value(metadata i32 %44, metadata !133, metadata !DIExpression()), !dbg !126
  br label %32, !dbg !179, !llvm.loop !180

45:                                               ; preds = %32
  %46 = add nsw i32 %.13, 1, !dbg !182
  call void @llvm.dbg.value(metadata i32 %46, metadata !143, metadata !DIExpression()), !dbg !126
  br label %29, !dbg !183, !llvm.loop !184

47:                                               ; preds = %29
  call void @llvm.dbg.value(metadata i32 0, metadata !143, metadata !DIExpression()), !dbg !126
  br label %48, !dbg !186

48:                                               ; preds = %97, %47
  %.24 = phi i32 [ 0, %47 ], [ %98, %97 ], !dbg !188
  call void @llvm.dbg.value(metadata i32 %.24, metadata !143, metadata !DIExpression()), !dbg !126
  %49 = icmp slt i32 %.24, 240, !dbg !189
  br i1 %49, label %50, label %99, !dbg !191

50:                                               ; preds = %48
  call void @llvm.dbg.value(metadata i32 %.24, metadata !133, metadata !DIExpression()), !dbg !126
  br label %51, !dbg !192

51:                                               ; preds = %79, %50
  %.2 = phi i32 [ %.24, %50 ], [ %96, %79 ], !dbg !194
  call void @llvm.dbg.value(metadata i32 %.2, metadata !133, metadata !DIExpression()), !dbg !126
  %52 = icmp slt i32 %.2, 240, !dbg !195
  br i1 %52, label %53, label %97, !dbg !197

53:                                               ; preds = %51
  %54 = sext i32 %.24 to i64, !dbg !198
  %55 = getelementptr inbounds [240 x double], [240 x double]* getelementptr inbounds ([240 x [240 x double]], [240 x [240 x double]]* @cov, i64 0, i64 0), i64 %54, !dbg !198
  %56 = sext i32 %.2 to i64, !dbg !198
  %57 = getelementptr inbounds [240 x double], [240 x double]* %55, i64 0, i64 %56, !dbg !198
  store double 0.000000e+00, double* %57, align 8, !dbg !200
  call void @llvm.dbg.value(metadata i32 0, metadata !201, metadata !DIExpression()), !dbg !126
  br label %58, !dbg !202

58:                                               ; preds = %60, %53
  %.0 = phi i32 [ 0, %53 ], [ %78, %60 ], !dbg !204
  call void @llvm.dbg.value(metadata i32 %.0, metadata !201, metadata !DIExpression()), !dbg !126
  %59 = icmp slt i32 %.0, 260, !dbg !205
  br i1 %59, label %60, label %79, !dbg !207

60:                                               ; preds = %58
  %61 = sext i32 %.0 to i64, !dbg !208
  %62 = getelementptr inbounds [240 x double], [240 x double]* getelementptr inbounds ([260 x [240 x double]], [260 x [240 x double]]* @data, i64 0, i64 0), i64 %61, !dbg !208
  %63 = sext i32 %.24 to i64, !dbg !208
  %64 = getelementptr inbounds [240 x double], [240 x double]* %62, i64 0, i64 %63, !dbg !208
  %65 = load double, double* %64, align 8, !dbg !208
  %66 = sext i32 %.0 to i64, !dbg !209
  %67 = getelementptr inbounds [240 x double], [240 x double]* getelementptr inbounds ([260 x [240 x double]], [260 x [240 x double]]* @data, i64 0, i64 0), i64 %66, !dbg !209
  %68 = sext i32 %.2 to i64, !dbg !209
  %69 = getelementptr inbounds [240 x double], [240 x double]* %67, i64 0, i64 %68, !dbg !209
  %70 = load double, double* %69, align 8, !dbg !209
  %71 = fmul double %65, %70, !dbg !210
  %72 = sext i32 %.24 to i64, !dbg !211
  %73 = getelementptr inbounds [240 x double], [240 x double]* getelementptr inbounds ([240 x [240 x double]], [240 x [240 x double]]* @cov, i64 0, i64 0), i64 %72, !dbg !211
  %74 = sext i32 %.2 to i64, !dbg !211
  %75 = getelementptr inbounds [240 x double], [240 x double]* %73, i64 0, i64 %74, !dbg !211
  %76 = load double, double* %75, align 8, !dbg !212
  %77 = fadd double %76, %71, !dbg !212
  store double %77, double* %75, align 8, !dbg !212
  %78 = add nsw i32 %.0, 1, !dbg !213
  call void @llvm.dbg.value(metadata i32 %78, metadata !201, metadata !DIExpression()), !dbg !126
  br label %58, !dbg !214, !llvm.loop !215

79:                                               ; preds = %58
  %80 = fsub double %3, 1.000000e+00, !dbg !217
  %81 = sext i32 %.24 to i64, !dbg !218
  %82 = getelementptr inbounds [240 x double], [240 x double]* getelementptr inbounds ([240 x [240 x double]], [240 x [240 x double]]* @cov, i64 0, i64 0), i64 %81, !dbg !218
  %83 = sext i32 %.2 to i64, !dbg !218
  %84 = getelementptr inbounds [240 x double], [240 x double]* %82, i64 0, i64 %83, !dbg !218
  %85 = load double, double* %84, align 8, !dbg !219
  %86 = fdiv double %85, %80, !dbg !219
  store double %86, double* %84, align 8, !dbg !219
  %87 = sext i32 %.24 to i64, !dbg !220
  %88 = getelementptr inbounds [240 x double], [240 x double]* getelementptr inbounds ([240 x [240 x double]], [240 x [240 x double]]* @cov, i64 0, i64 0), i64 %87, !dbg !220
  %89 = sext i32 %.2 to i64, !dbg !220
  %90 = getelementptr inbounds [240 x double], [240 x double]* %88, i64 0, i64 %89, !dbg !220
  %91 = load double, double* %90, align 8, !dbg !220
  %92 = sext i32 %.2 to i64, !dbg !221
  %93 = getelementptr inbounds [240 x double], [240 x double]* getelementptr inbounds ([240 x [240 x double]], [240 x [240 x double]]* @cov, i64 0, i64 0), i64 %92, !dbg !221
  %94 = sext i32 %.24 to i64, !dbg !221
  %95 = getelementptr inbounds [240 x double], [240 x double]* %93, i64 0, i64 %94, !dbg !221
  store double %91, double* %95, align 8, !dbg !222
  %96 = add nsw i32 %.2, 1, !dbg !223
  call void @llvm.dbg.value(metadata i32 %96, metadata !133, metadata !DIExpression()), !dbg !126
  br label %51, !dbg !224, !llvm.loop !225

97:                                               ; preds = %51
  %98 = add nsw i32 %.24, 1, !dbg !227
  call void @llvm.dbg.value(metadata i32 %98, metadata !143, metadata !DIExpression()), !dbg !126
  br label %48, !dbg !228, !llvm.loop !229

99:                                               ; preds = %48
  ret i32 0, !dbg !231
}

; Function Attrs: noinline nounwind uwtable
define dso_local i32 @workload_checksum(i32 noundef %0) #0 !dbg !232 {
  call void @llvm.dbg.value(metadata i32 %0, metadata !235, metadata !DIExpression()), !dbg !236
  store i32 -2128831035, i32* @pb_hash, align 4, !dbg !237
  %2 = load i32, i32* @m, align 4, !dbg !238
  call void @print_array(i32 noundef %2, [240 x double]* noundef getelementptr inbounds ([240 x [240 x double]], [240 x [240 x double]]* @cov, i64 0, i64 0)), !dbg !239
  %3 = load i32, i32* @pb_hash, align 4, !dbg !240
  ret i32 %3, !dbg !241
}

; Function Attrs: noinline nounwind uwtable
define internal void @print_array(i32 noundef %0, [240 x double]* noundef %1) #0 !dbg !242 {
  call void @llvm.dbg.value(metadata i32 %0, metadata !245, metadata !DIExpression()), !dbg !246
  call void @llvm.dbg.value(metadata [240 x double]* %1, metadata !247, metadata !DIExpression()), !dbg !246
  %3 = load %struct._IO_FILE*, %struct._IO_FILE** @stderr, align 8, !dbg !248
  %4 = call i32 (%struct._IO_FILE*, i8*, ...) @pb_fprintf(%struct._IO_FILE* noundef %3, i8* noundef getelementptr inbounds ([23 x i8], [23 x i8]* @.str.2, i64 0, i64 0)), !dbg !248
  %5 = load %struct._IO_FILE*, %struct._IO_FILE** @stderr, align 8, !dbg !249
  %6 = call i32 (%struct._IO_FILE*, i8*, ...) @pb_fprintf(%struct._IO_FILE* noundef %5, i8* noundef getelementptr inbounds ([15 x i8], [15 x i8]* @.str.3, i64 0, i64 0), i8* noundef getelementptr inbounds ([4 x i8], [4 x i8]* @.str.4, i64 0, i64 0)), !dbg !249
  call void @llvm.dbg.value(metadata i32 0, metadata !250, metadata !DIExpression()), !dbg !246
  br label %7, !dbg !251

7:                                                ; preds = %31, %2
  %.01 = phi i32 [ 0, %2 ], [ %32, %31 ], !dbg !253
  call void @llvm.dbg.value(metadata i32 %.01, metadata !250, metadata !DIExpression()), !dbg !246
  %8 = icmp slt i32 %.01, %0, !dbg !254
  br i1 %8, label %9, label %33, !dbg !256

9:                                                ; preds = %7
  call void @llvm.dbg.value(metadata i32 0, metadata !257, metadata !DIExpression()), !dbg !246
  br label %10, !dbg !258

10:                                               ; preds = %28, %9
  %.0 = phi i32 [ 0, %9 ], [ %29, %28 ], !dbg !260
  call void @llvm.dbg.value(metadata i32 %.0, metadata !257, metadata !DIExpression()), !dbg !246
  %11 = icmp slt i32 %.0, %0, !dbg !261
  br i1 %11, label %12, label %30, !dbg !263

12:                                               ; preds = %10
  %13 = mul nsw i32 %.01, %0, !dbg !264
  %14 = add nsw i32 %13, %.0, !dbg !267
  %15 = srem i32 %14, 20, !dbg !268
  %16 = icmp eq i32 %15, 0, !dbg !269
  br i1 %16, label %17, label %20, !dbg !270

17:                                               ; preds = %12
  %18 = load %struct._IO_FILE*, %struct._IO_FILE** @stderr, align 8, !dbg !271
  %19 = call i32 (%struct._IO_FILE*, i8*, ...) @pb_fprintf(%struct._IO_FILE* noundef %18, i8* noundef getelementptr inbounds ([2 x i8], [2 x i8]* @.str.5, i64 0, i64 0)), !dbg !272
  br label %20, !dbg !272

20:                                               ; preds = %17, %12
  %21 = load %struct._IO_FILE*, %struct._IO_FILE** @stderr, align 8, !dbg !273
  %22 = sext i32 %.01 to i64, !dbg !274
  %23 = getelementptr inbounds [240 x double], [240 x double]* %1, i64 %22, !dbg !274
  %24 = sext i32 %.0 to i64, !dbg !274
  %25 = getelementptr inbounds [240 x double], [240 x double]* %23, i64 0, i64 %24, !dbg !274
  %26 = load double, double* %25, align 8, !dbg !274
  %27 = call i32 (%struct._IO_FILE*, i8*, ...) @pb_fprintf(%struct._IO_FILE* noundef %21, i8* noundef getelementptr inbounds ([8 x i8], [8 x i8]* @.str.6, i64 0, i64 0), double noundef %26), !dbg !275
  br label %28, !dbg !276

28:                                               ; preds = %20
  %29 = add nsw i32 %.0, 1, !dbg !277
  call void @llvm.dbg.value(metadata i32 %29, metadata !257, metadata !DIExpression()), !dbg !246
  br label %10, !dbg !278, !llvm.loop !279

30:                                               ; preds = %10
  br label %31, !dbg !280

31:                                               ; preds = %30
  %32 = add nsw i32 %.01, 1, !dbg !281
  call void @llvm.dbg.value(metadata i32 %32, metadata !250, metadata !DIExpression()), !dbg !246
  br label %7, !dbg !282, !llvm.loop !283

33:                                               ; preds = %7
  %34 = load %struct._IO_FILE*, %struct._IO_FILE** @stderr, align 8, !dbg !285
  %35 = call i32 (%struct._IO_FILE*, i8*, ...) @pb_fprintf(%struct._IO_FILE* noundef %34, i8* noundef getelementptr inbounds ([17 x i8], [17 x i8]* @.str.7, i64 0, i64 0), i8* noundef getelementptr inbounds ([4 x i8], [4 x i8]* @.str.4, i64 0, i64 0)), !dbg !285
  %36 = load %struct._IO_FILE*, %struct._IO_FILE** @stderr, align 8, !dbg !286
  %37 = call i32 (%struct._IO_FILE*, i8*, ...) @pb_fprintf(%struct._IO_FILE* noundef %36, i8* noundef getelementptr inbounds ([23 x i8], [23 x i8]* @.str.8, i64 0, i64 0)), !dbg !286
  ret void, !dbg !287
}

; Function Attrs: noinline nounwind uwtable
define internal i32 @pb_fprintf(%struct._IO_FILE* noundef %0, i8* noundef %1, ...) #0 !dbg !288 {
  %3 = alloca [768 x i8], align 16
  %4 = alloca [1 x %struct.__va_list_tag], align 16
  call void @llvm.dbg.value(metadata %struct._IO_FILE* %0, metadata !352, metadata !DIExpression()), !dbg !353
  call void @llvm.dbg.value(metadata i8* %1, metadata !354, metadata !DIExpression()), !dbg !353
  call void @llvm.dbg.declare(metadata [768 x i8]* %3, metadata !355, metadata !DIExpression()), !dbg !359
  call void @llvm.dbg.declare(metadata [1 x %struct.__va_list_tag]* %4, metadata !360, metadata !DIExpression()), !dbg !374
  %5 = getelementptr inbounds [1 x %struct.__va_list_tag], [1 x %struct.__va_list_tag]* %4, i64 0, i64 0, !dbg !375
  %6 = bitcast %struct.__va_list_tag* %5 to i8*, !dbg !375
  call void @llvm.va_start(i8* %6), !dbg !375
  %7 = getelementptr inbounds [768 x i8], [768 x i8]* %3, i64 0, i64 0, !dbg !376
  %8 = getelementptr inbounds [1 x %struct.__va_list_tag], [1 x %struct.__va_list_tag]* %4, i64 0, i64 0, !dbg !377
  %9 = call i32 @vsnprintf(i8* noundef %7, i64 noundef 768, i8* noundef %1, %struct.__va_list_tag* noundef %8) #6, !dbg !378
  call void @llvm.dbg.value(metadata i32 %9, metadata !379, metadata !DIExpression()), !dbg !353
  %10 = getelementptr inbounds [1 x %struct.__va_list_tag], [1 x %struct.__va_list_tag]* %4, i64 0, i64 0, !dbg !380
  %11 = bitcast %struct.__va_list_tag* %10 to i8*, !dbg !380
  call void @llvm.va_end(i8* %11), !dbg !380
  %12 = icmp slt i32 %9, 0, !dbg !381
  br i1 %12, label %16, label %13, !dbg !383

13:                                               ; preds = %2
  %14 = zext i32 %9 to i64, !dbg !384
  %15 = icmp uge i64 %14, 768, !dbg !385
  br i1 %15, label %16, label %17, !dbg !386

16:                                               ; preds = %13, %2
  call void @abort() #7, !dbg !387
  unreachable, !dbg !387

17:                                               ; preds = %13
  call void @llvm.dbg.value(metadata i32 0, metadata !388, metadata !DIExpression()), !dbg !390
  br label %18, !dbg !391

18:                                               ; preds = %29, %17
  %.0 = phi i32 [ 0, %17 ], [ %30, %29 ], !dbg !390
  call void @llvm.dbg.value(metadata i32 %.0, metadata !388, metadata !DIExpression()), !dbg !390
  %19 = icmp slt i32 %.0, %9, !dbg !392
  br i1 %19, label %20, label %31, !dbg !394

20:                                               ; preds = %18
  %21 = sext i32 %.0 to i64, !dbg !395
  %22 = getelementptr inbounds [768 x i8], [768 x i8]* %3, i64 0, i64 %21, !dbg !395
  %23 = load i8, i8* %22, align 1, !dbg !395
  %24 = zext i8 %23 to i32, !dbg !397
  %25 = load i32, i32* @pb_hash, align 4, !dbg !398
  %26 = xor i32 %25, %24, !dbg !398
  store i32 %26, i32* @pb_hash, align 4, !dbg !398
  %27 = load i32, i32* @pb_hash, align 4, !dbg !399
  %28 = mul i32 %27, 16777619, !dbg !399
  store i32 %28, i32* @pb_hash, align 4, !dbg !399
  br label %29, !dbg !400

29:                                               ; preds = %20
  %30 = add nsw i32 %.0, 1, !dbg !401
  call void @llvm.dbg.value(metadata i32 %30, metadata !388, metadata !DIExpression()), !dbg !390
  br label %18, !dbg !402, !llvm.loop !403

31:                                               ; preds = %18
  %32 = load i32, i32* @pb_emit, align 4, !dbg !405
  ret i32 %9, !dbg !406
}

; Function Attrs: nofree nosync nounwind willreturn
declare void @llvm.va_start(i8*) #3

; Function Attrs: nounwind
declare i32 @vsnprintf(i8* noundef, i64 noundef, i8* noundef, %struct.__va_list_tag* noundef) #4

; Function Attrs: nofree nosync nounwind willreturn
declare void @llvm.va_end(i8*) #3

; Function Attrs: noreturn nounwind
declare void @abort() #5

; Function Attrs: nofree nosync nounwind readnone speculatable willreturn
declare void @llvm.dbg.value(metadata, metadata, metadata) #1

attributes #0 = { noinline nounwind uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { nofree nosync nounwind readnone speculatable willreturn }
attributes #2 = { argmemonly nofree nounwind willreturn writeonly }
attributes #3 = { nofree nosync nounwind willreturn }
attributes #4 = { nounwind "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #5 = { noreturn nounwind "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #6 = { nounwind }
attributes #7 = { noreturn nounwind }

!llvm.dbg.cu = !{!2}
!llvm.module.flags = !{!51, !52, !53, !54, !55, !56, !57}
!llvm.ident = !{!58}

!0 = !DIGlobalVariableExpression(var: !1, expr: !DIExpression())
!1 = distinct !DIGlobalVariable(name: "n", scope: !2, file: !11, line: 112, type: !12, isLocal: false, isDefinition: true)
!2 = distinct !DICompileUnit(language: DW_LANG_C99, file: !3, producer: "Ubuntu clang version 14.0.0-1ubuntu1.1", isOptimized: false, runtimeVersion: 0, emissionKind: FullDebug, retainedTypes: !4, globals: !8, splitDebugInlining: false, nameTableKind: None)
!3 = !DIFile(filename: "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/affine-bounds-20260929/suite/covariance/source/workload.c", directory: "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/affine-bounds-20260929/suite/covariance/analysis-p", checksumkind: CSK_MD5, checksum: "5266233317551a092f7140d5a93b2e7f")
!4 = !{!5, !6, !7}
!5 = !DIBasicType(name: "double", size: 64, encoding: DW_ATE_float)
!6 = !DIBasicType(name: "unsigned int", size: 32, encoding: DW_ATE_unsigned)
!7 = !DIBasicType(name: "unsigned char", size: 8, encoding: DW_ATE_unsigned_char)
!8 = !{!0, !9, !13, !26, !30, !33, !39, !43, !47, !49}
!9 = !DIGlobalVariableExpression(var: !10, expr: !DIExpression())
!10 = distinct !DIGlobalVariable(name: "m", scope: !2, file: !11, line: 113, type: !12, isLocal: false, isDefinition: true)
!11 = !DIFile(filename: "source/workload.c", directory: "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/affine-bounds-20260929/suite/covariance", checksumkind: CSK_MD5, checksum: "5266233317551a092f7140d5a93b2e7f")
!12 = !DIBasicType(name: "int", size: 32, encoding: DW_ATE_signed)
!13 = !DIGlobalVariableExpression(var: !14, expr: !DIExpression())
!14 = distinct !DIGlobalVariable(name: "workload_jobs", scope: !2, file: !11, line: 138, type: !15, isLocal: false, isDefinition: true)
!15 = !DICompositeType(tag: DW_TAG_array_type, baseType: !16, size: 64, elements: !24)
!16 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !17)
!17 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !18, size: 64)
!18 = !DISubroutineType(types: !19)
!19 = !{!20}
!20 = !DIDerivedType(tag: DW_TAG_typedef, name: "uint32_t", file: !21, line: 26, baseType: !22)
!21 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/stdint-uintn.h", directory: "", checksumkind: CSK_MD5, checksum: "2bf2ae53c58c01b1a1b9383b5195125c")
!22 = !DIDerivedType(tag: DW_TAG_typedef, name: "__uint32_t", file: !23, line: 42, baseType: !6)
!23 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/types.h", directory: "", checksumkind: CSK_MD5, checksum: "d108b5f93a74c50510d7d9bc0ab36df9")
!24 = !{!25}
!25 = !DISubrange(count: 1)
!26 = !DIGlobalVariableExpression(var: !27, expr: !DIExpression())
!27 = distinct !DIGlobalVariable(name: "workload_expected", scope: !2, file: !11, line: 142, type: !28, isLocal: false, isDefinition: true)
!28 = !DICompositeType(tag: DW_TAG_array_type, baseType: !29, size: 32, elements: !24)
!29 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !20)
!30 = !DIGlobalVariableExpression(var: !31, expr: !DIExpression())
!31 = distinct !DIGlobalVariable(name: "pb_hash", scope: !2, file: !32, line: 9, type: !20, isLocal: true, isDefinition: true)
!32 = !DIFile(filename: "source/adapter.h", directory: "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/affine-bounds-20260929/suite/covariance", checksumkind: CSK_MD5, checksum: "26a6068928b2092758f244a9d00163d7")
!33 = !DIGlobalVariableExpression(var: !34, expr: !DIExpression())
!34 = distinct !DIGlobalVariable(name: "data", scope: !2, file: !11, line: 34, type: !35, isLocal: false, isDefinition: true, align: 512)
!35 = !DICompositeType(tag: DW_TAG_array_type, baseType: !5, size: 3993600, elements: !36)
!36 = !{!37, !38}
!37 = !DISubrange(count: 260)
!38 = !DISubrange(count: 240)
!39 = !DIGlobalVariableExpression(var: !40, expr: !DIExpression())
!40 = distinct !DIGlobalVariable(name: "cov", scope: !2, file: !11, line: 35, type: !41, isLocal: false, isDefinition: true, align: 512)
!41 = !DICompositeType(tag: DW_TAG_array_type, baseType: !5, size: 3686400, elements: !42)
!42 = !{!38, !38}
!43 = !DIGlobalVariableExpression(var: !44, expr: !DIExpression())
!44 = distinct !DIGlobalVariable(name: "mean", scope: !2, file: !11, line: 36, type: !45, isLocal: false, isDefinition: true, align: 512)
!45 = !DICompositeType(tag: DW_TAG_array_type, baseType: !5, size: 15360, elements: !46)
!46 = !{!38}
!47 = !DIGlobalVariableExpression(var: !48, expr: !DIExpression())
!48 = distinct !DIGlobalVariable(name: "float_n", scope: !2, file: !11, line: 116, type: !5, isLocal: false, isDefinition: true)
!49 = !DIGlobalVariableExpression(var: !50, expr: !DIExpression())
!50 = distinct !DIGlobalVariable(name: "pb_emit", scope: !2, file: !32, line: 10, type: !12, isLocal: true, isDefinition: true)
!51 = !{i32 7, !"Dwarf Version", i32 5}
!52 = !{i32 2, !"Debug Info Version", i32 3}
!53 = !{i32 1, !"wchar_size", i32 4}
!54 = !{i32 7, !"PIC Level", i32 2}
!55 = !{i32 7, !"PIE Level", i32 2}
!56 = !{i32 7, !"uwtable", i32 1}
!57 = !{i32 7, !"frame-pointer", i32 2}
!58 = !{!"Ubuntu clang version 14.0.0-1ubuntu1.1"}
!59 = distinct !DISubprogram(name: "workload_prepare", scope: !11, file: !11, line: 117, type: !60, scopeLine: 117, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !2, retainedNodes: !62)
!60 = !DISubroutineType(types: !61)
!61 = !{null}
!62 = !{}
!63 = !DILocation(line: 117, column: 30, scope: !59)
!64 = distinct !DISubprogram(name: "workload_reset", scope: !11, file: !11, line: 118, type: !65, scopeLine: 118, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !2, retainedNodes: !62)
!65 = !DISubroutineType(types: !66)
!66 = !{null, !6}
!67 = !DILocalVariable(name: "task", arg: 1, scope: !64, file: !11, line: 118, type: !6)
!68 = !DILocation(line: 0, scope: !64)
!69 = !DILocation(line: 120, column: 3, scope: !64)
!70 = !DILocation(line: 121, column: 3, scope: !64)
!71 = !DILocation(line: 122, column: 3, scope: !64)
!72 = !DILocation(line: 123, column: 15, scope: !64)
!73 = !DILocation(line: 123, column: 18, scope: !64)
!74 = !DILocation(line: 123, column: 3, scope: !64)
!75 = !DILocation(line: 124, column: 1, scope: !64)
!76 = distinct !DISubprogram(name: "init_array", scope: !11, file: !11, line: 38, type: !77, scopeLine: 41, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition, unit: !2, retainedNodes: !62)
!77 = !DISubroutineType(types: !78)
!78 = !{null, !12, !12, !79, !80}
!79 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !5, size: 64)
!80 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !45, size: 64)
!81 = !DILocalVariable(name: "m", arg: 1, scope: !76, file: !11, line: 38, type: !12)
!82 = !DILocation(line: 0, scope: !76)
!83 = !DILocalVariable(name: "n", arg: 2, scope: !76, file: !11, line: 38, type: !12)
!84 = !DILocalVariable(name: "float_n", arg: 3, scope: !76, file: !11, line: 39, type: !79)
!85 = !DILocalVariable(name: "data", arg: 4, scope: !76, file: !11, line: 40, type: !80)
!86 = !DILocation(line: 44, column: 14, scope: !76)
!87 = !DILocation(line: 44, column: 12, scope: !76)
!88 = !DILocalVariable(name: "i", scope: !76, file: !11, line: 42, type: !12)
!89 = !DILocation(line: 46, column: 8, scope: !90)
!90 = distinct !DILexicalBlock(scope: !76, file: !11, line: 46, column: 3)
!91 = !DILocation(line: 0, scope: !90)
!92 = !DILocation(line: 46, column: 17, scope: !93)
!93 = distinct !DILexicalBlock(scope: !90, file: !11, line: 46, column: 3)
!94 = !DILocation(line: 46, column: 3, scope: !90)
!95 = !DILocalVariable(name: "j", scope: !76, file: !11, line: 42, type: !12)
!96 = !DILocation(line: 47, column: 10, scope: !97)
!97 = distinct !DILexicalBlock(scope: !93, file: !11, line: 47, column: 5)
!98 = !DILocation(line: 0, scope: !97)
!99 = !DILocation(line: 47, column: 19, scope: !100)
!100 = distinct !DILexicalBlock(scope: !97, file: !11, line: 47, column: 5)
!101 = !DILocation(line: 47, column: 5, scope: !97)
!102 = !DILocation(line: 48, column: 21, scope: !100)
!103 = !DILocation(line: 48, column: 35, scope: !100)
!104 = !DILocation(line: 48, column: 34, scope: !100)
!105 = !DILocation(line: 48, column: 38, scope: !100)
!106 = !DILocation(line: 48, column: 7, scope: !100)
!107 = !DILocation(line: 48, column: 18, scope: !100)
!108 = !DILocation(line: 47, column: 25, scope: !100)
!109 = !DILocation(line: 47, column: 5, scope: !100)
!110 = distinct !{!110, !101, !111, !112}
!111 = !DILocation(line: 48, column: 40, scope: !97)
!112 = !{!"llvm.loop.mustprogress"}
!113 = !DILocation(line: 46, column: 23, scope: !93)
!114 = !DILocation(line: 46, column: 3, scope: !93)
!115 = distinct !{!115, !94, !116, !112}
!116 = !DILocation(line: 48, column: 40, scope: !90)
!117 = !DILocation(line: 49, column: 1, scope: !76)
!118 = distinct !DISubprogram(name: "task_job_polybench", scope: !11, file: !11, line: 125, type: !18, scopeLine: 125, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !2, retainedNodes: !62)
!119 = !DILocation(line: 126, column: 22, scope: !118)
!120 = !DILocation(line: 126, column: 25, scope: !118)
!121 = !DILocation(line: 126, column: 28, scope: !118)
!122 = !DILocalVariable(name: "m", arg: 1, scope: !123, file: !11, line: 76, type: !12)
!123 = distinct !DISubprogram(name: "kernel_covariance", scope: !11, file: !11, line: 76, type: !124, scopeLine: 81, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition, unit: !2, retainedNodes: !62)
!124 = !DISubroutineType(types: !125)
!125 = !{null, !12, !12, !5, !80, !80, !79}
!126 = !DILocation(line: 0, scope: !123, inlinedAt: !127)
!127 = distinct !DILocation(line: 126, column: 3, scope: !118)
!128 = !DILocalVariable(name: "n", arg: 2, scope: !123, file: !11, line: 76, type: !12)
!129 = !DILocalVariable(name: "float_n", arg: 3, scope: !123, file: !11, line: 77, type: !5)
!130 = !DILocalVariable(name: "data", arg: 4, scope: !123, file: !11, line: 78, type: !80)
!131 = !DILocalVariable(name: "cov", arg: 5, scope: !123, file: !11, line: 79, type: !80)
!132 = !DILocalVariable(name: "mean", arg: 6, scope: !123, file: !11, line: 80, type: !79)
!133 = !DILocalVariable(name: "j", scope: !123, file: !11, line: 82, type: !12)
!134 = !DILocation(line: 85, column: 8, scope: !135, inlinedAt: !127)
!135 = distinct !DILexicalBlock(scope: !123, file: !11, line: 85, column: 3)
!136 = !DILocation(line: 0, scope: !135, inlinedAt: !127)
!137 = !DILocation(line: 85, column: 17, scope: !138, inlinedAt: !127)
!138 = distinct !DILexicalBlock(scope: !135, file: !11, line: 85, column: 3)
!139 = !DILocation(line: 85, column: 3, scope: !135, inlinedAt: !127)
!140 = !DILocation(line: 87, column: 7, scope: !141, inlinedAt: !127)
!141 = distinct !DILexicalBlock(scope: !138, file: !11, line: 86, column: 5)
!142 = !DILocation(line: 87, column: 15, scope: !141, inlinedAt: !127)
!143 = !DILocalVariable(name: "i", scope: !123, file: !11, line: 82, type: !12)
!144 = !DILocation(line: 88, column: 12, scope: !145, inlinedAt: !127)
!145 = distinct !DILexicalBlock(scope: !141, file: !11, line: 88, column: 7)
!146 = !DILocation(line: 0, scope: !145, inlinedAt: !127)
!147 = !DILocation(line: 88, column: 21, scope: !148, inlinedAt: !127)
!148 = distinct !DILexicalBlock(scope: !145, file: !11, line: 88, column: 7)
!149 = !DILocation(line: 88, column: 7, scope: !145, inlinedAt: !127)
!150 = !DILocation(line: 89, column: 20, scope: !148, inlinedAt: !127)
!151 = !DILocation(line: 89, column: 9, scope: !148, inlinedAt: !127)
!152 = !DILocation(line: 89, column: 17, scope: !148, inlinedAt: !127)
!153 = !DILocation(line: 88, column: 31, scope: !148, inlinedAt: !127)
!154 = !DILocation(line: 88, column: 7, scope: !148, inlinedAt: !127)
!155 = distinct !{!155, !149, !156, !112}
!156 = !DILocation(line: 89, column: 29, scope: !145, inlinedAt: !127)
!157 = !DILocation(line: 90, column: 7, scope: !141, inlinedAt: !127)
!158 = !DILocation(line: 90, column: 15, scope: !141, inlinedAt: !127)
!159 = !DILocation(line: 85, column: 27, scope: !138, inlinedAt: !127)
!160 = !DILocation(line: 85, column: 3, scope: !138, inlinedAt: !127)
!161 = distinct !{!161, !139, !162, !112}
!162 = !DILocation(line: 91, column: 5, scope: !135, inlinedAt: !127)
!163 = !DILocation(line: 93, column: 8, scope: !164, inlinedAt: !127)
!164 = distinct !DILexicalBlock(scope: !123, file: !11, line: 93, column: 3)
!165 = !DILocation(line: 0, scope: !164, inlinedAt: !127)
!166 = !DILocation(line: 93, column: 17, scope: !167, inlinedAt: !127)
!167 = distinct !DILexicalBlock(scope: !164, file: !11, line: 93, column: 3)
!168 = !DILocation(line: 93, column: 3, scope: !164, inlinedAt: !127)
!169 = !DILocation(line: 94, column: 10, scope: !170, inlinedAt: !127)
!170 = distinct !DILexicalBlock(scope: !167, file: !11, line: 94, column: 5)
!171 = !DILocation(line: 0, scope: !170, inlinedAt: !127)
!172 = !DILocation(line: 94, column: 19, scope: !173, inlinedAt: !127)
!173 = distinct !DILexicalBlock(scope: !170, file: !11, line: 94, column: 5)
!174 = !DILocation(line: 94, column: 5, scope: !170, inlinedAt: !127)
!175 = !DILocation(line: 95, column: 21, scope: !173, inlinedAt: !127)
!176 = !DILocation(line: 95, column: 7, scope: !173, inlinedAt: !127)
!177 = !DILocation(line: 95, column: 18, scope: !173, inlinedAt: !127)
!178 = !DILocation(line: 94, column: 29, scope: !173, inlinedAt: !127)
!179 = !DILocation(line: 94, column: 5, scope: !173, inlinedAt: !127)
!180 = distinct !{!180, !174, !181, !112}
!181 = !DILocation(line: 95, column: 27, scope: !170, inlinedAt: !127)
!182 = !DILocation(line: 93, column: 27, scope: !167, inlinedAt: !127)
!183 = !DILocation(line: 93, column: 3, scope: !167, inlinedAt: !127)
!184 = distinct !{!184, !168, !185, !112}
!185 = !DILocation(line: 95, column: 27, scope: !164, inlinedAt: !127)
!186 = !DILocation(line: 97, column: 8, scope: !187, inlinedAt: !127)
!187 = distinct !DILexicalBlock(scope: !123, file: !11, line: 97, column: 3)
!188 = !DILocation(line: 0, scope: !187, inlinedAt: !127)
!189 = !DILocation(line: 97, column: 17, scope: !190, inlinedAt: !127)
!190 = distinct !DILexicalBlock(scope: !187, file: !11, line: 97, column: 3)
!191 = !DILocation(line: 97, column: 3, scope: !187, inlinedAt: !127)
!192 = !DILocation(line: 98, column: 10, scope: !193, inlinedAt: !127)
!193 = distinct !DILexicalBlock(scope: !190, file: !11, line: 98, column: 5)
!194 = !DILocation(line: 0, scope: !193, inlinedAt: !127)
!195 = !DILocation(line: 98, column: 19, scope: !196, inlinedAt: !127)
!196 = distinct !DILexicalBlock(scope: !193, file: !11, line: 98, column: 5)
!197 = !DILocation(line: 98, column: 5, scope: !193, inlinedAt: !127)
!198 = !DILocation(line: 100, column: 9, scope: !199, inlinedAt: !127)
!199 = distinct !DILexicalBlock(scope: !196, file: !11, line: 99, column: 7)
!200 = !DILocation(line: 100, column: 19, scope: !199, inlinedAt: !127)
!201 = !DILocalVariable(name: "k", scope: !123, file: !11, line: 82, type: !12)
!202 = !DILocation(line: 101, column: 14, scope: !203, inlinedAt: !127)
!203 = distinct !DILexicalBlock(scope: !199, file: !11, line: 101, column: 9)
!204 = !DILocation(line: 0, scope: !203, inlinedAt: !127)
!205 = !DILocation(line: 101, column: 23, scope: !206, inlinedAt: !127)
!206 = distinct !DILexicalBlock(scope: !203, file: !11, line: 101, column: 9)
!207 = !DILocation(line: 101, column: 9, scope: !203, inlinedAt: !127)
!208 = !DILocation(line: 102, column: 17, scope: !206, inlinedAt: !127)
!209 = !DILocation(line: 102, column: 30, scope: !206, inlinedAt: !127)
!210 = !DILocation(line: 102, column: 28, scope: !206, inlinedAt: !127)
!211 = !DILocation(line: 102, column: 4, scope: !206, inlinedAt: !127)
!212 = !DILocation(line: 102, column: 14, scope: !206, inlinedAt: !127)
!213 = !DILocation(line: 101, column: 33, scope: !206, inlinedAt: !127)
!214 = !DILocation(line: 101, column: 9, scope: !206, inlinedAt: !127)
!215 = distinct !{!215, !207, !216, !112}
!216 = !DILocation(line: 102, column: 39, scope: !203, inlinedAt: !127)
!217 = !DILocation(line: 103, column: 31, scope: !199, inlinedAt: !127)
!218 = !DILocation(line: 103, column: 9, scope: !199, inlinedAt: !127)
!219 = !DILocation(line: 103, column: 19, scope: !199, inlinedAt: !127)
!220 = !DILocation(line: 104, column: 21, scope: !199, inlinedAt: !127)
!221 = !DILocation(line: 104, column: 9, scope: !199, inlinedAt: !127)
!222 = !DILocation(line: 104, column: 19, scope: !199, inlinedAt: !127)
!223 = !DILocation(line: 98, column: 29, scope: !196, inlinedAt: !127)
!224 = !DILocation(line: 98, column: 5, scope: !196, inlinedAt: !127)
!225 = distinct !{!225, !197, !226, !112}
!226 = !DILocation(line: 105, column: 7, scope: !193, inlinedAt: !127)
!227 = !DILocation(line: 97, column: 27, scope: !190, inlinedAt: !127)
!228 = !DILocation(line: 97, column: 3, scope: !190, inlinedAt: !127)
!229 = distinct !{!229, !191, !230, !112}
!230 = !DILocation(line: 105, column: 7, scope: !187, inlinedAt: !127)
!231 = !DILocation(line: 130, column: 3, scope: !118)
!232 = distinct !DISubprogram(name: "workload_checksum", scope: !11, file: !11, line: 132, type: !233, scopeLine: 132, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !2, retainedNodes: !62)
!233 = !DISubroutineType(types: !234)
!234 = !{!20, !6}
!235 = !DILocalVariable(name: "task", arg: 1, scope: !232, file: !11, line: 132, type: !6)
!236 = !DILocation(line: 0, scope: !232)
!237 = !DILocation(line: 134, column: 11, scope: !232)
!238 = !DILocation(line: 135, column: 15, scope: !232)
!239 = !DILocation(line: 135, column: 3, scope: !232)
!240 = !DILocation(line: 136, column: 10, scope: !232)
!241 = !DILocation(line: 136, column: 3, scope: !232)
!242 = distinct !DISubprogram(name: "print_array", scope: !11, file: !11, line: 55, type: !243, scopeLine: 58, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition, unit: !2, retainedNodes: !62)
!243 = !DISubroutineType(types: !244)
!244 = !{null, !12, !80}
!245 = !DILocalVariable(name: "m", arg: 1, scope: !242, file: !11, line: 55, type: !12)
!246 = !DILocation(line: 0, scope: !242)
!247 = !DILocalVariable(name: "cov", arg: 2, scope: !242, file: !11, line: 56, type: !80)
!248 = !DILocation(line: 61, column: 3, scope: !242)
!249 = !DILocation(line: 62, column: 3, scope: !242)
!250 = !DILocalVariable(name: "i", scope: !242, file: !11, line: 59, type: !12)
!251 = !DILocation(line: 63, column: 8, scope: !252)
!252 = distinct !DILexicalBlock(scope: !242, file: !11, line: 63, column: 3)
!253 = !DILocation(line: 0, scope: !252)
!254 = !DILocation(line: 63, column: 17, scope: !255)
!255 = distinct !DILexicalBlock(scope: !252, file: !11, line: 63, column: 3)
!256 = !DILocation(line: 63, column: 3, scope: !252)
!257 = !DILocalVariable(name: "j", scope: !242, file: !11, line: 59, type: !12)
!258 = !DILocation(line: 64, column: 10, scope: !259)
!259 = distinct !DILexicalBlock(scope: !255, file: !11, line: 64, column: 5)
!260 = !DILocation(line: 0, scope: !259)
!261 = !DILocation(line: 64, column: 19, scope: !262)
!262 = distinct !DILexicalBlock(scope: !259, file: !11, line: 64, column: 5)
!263 = !DILocation(line: 64, column: 5, scope: !259)
!264 = !DILocation(line: 65, column: 14, scope: !265)
!265 = distinct !DILexicalBlock(scope: !266, file: !11, line: 65, column: 11)
!266 = distinct !DILexicalBlock(scope: !262, file: !11, line: 64, column: 29)
!267 = !DILocation(line: 65, column: 18, scope: !265)
!268 = !DILocation(line: 65, column: 23, scope: !265)
!269 = !DILocation(line: 65, column: 28, scope: !265)
!270 = !DILocation(line: 65, column: 11, scope: !266)
!271 = !DILocation(line: 65, column: 43, scope: !265)
!272 = !DILocation(line: 65, column: 34, scope: !265)
!273 = !DILocation(line: 66, column: 16, scope: !266)
!274 = !DILocation(line: 66, column: 61, scope: !266)
!275 = !DILocation(line: 66, column: 7, scope: !266)
!276 = !DILocation(line: 67, column: 5, scope: !266)
!277 = !DILocation(line: 64, column: 25, scope: !262)
!278 = !DILocation(line: 64, column: 5, scope: !262)
!279 = distinct !{!279, !263, !280, !112}
!280 = !DILocation(line: 67, column: 5, scope: !259)
!281 = !DILocation(line: 63, column: 23, scope: !255)
!282 = !DILocation(line: 63, column: 3, scope: !255)
!283 = distinct !{!283, !256, !284, !112}
!284 = !DILocation(line: 67, column: 5, scope: !252)
!285 = !DILocation(line: 68, column: 3, scope: !242)
!286 = !DILocation(line: 69, column: 3, scope: !242)
!287 = !DILocation(line: 70, column: 1, scope: !242)
!288 = distinct !DISubprogram(name: "pb_fprintf", scope: !32, file: !32, line: 13, type: !289, scopeLine: 14, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition, unit: !2, retainedNodes: !62)
!289 = !DISubroutineType(types: !290)
!290 = !{!12, !291, !350, null}
!291 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !292, size: 64)
!292 = !DIDerivedType(tag: DW_TAG_typedef, name: "FILE", file: !293, line: 7, baseType: !294)
!293 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/types/FILE.h", directory: "", checksumkind: CSK_MD5, checksum: "571f9fb6223c42439075fdde11a0de5d")
!294 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "_IO_FILE", file: !295, line: 49, size: 1728, elements: !296)
!295 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/types/struct_FILE.h", directory: "", checksumkind: CSK_MD5, checksum: "1bad07471b7974df4ecc1d1c2ca207e6")
!296 = !{!297, !298, !301, !302, !303, !304, !305, !306, !307, !308, !309, !310, !311, !314, !316, !317, !318, !321, !323, !325, !327, !330, !332, !335, !338, !339, !341, !345, !346}
!297 = !DIDerivedType(tag: DW_TAG_member, name: "_flags", scope: !294, file: !295, line: 51, baseType: !12, size: 32)
!298 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_read_ptr", scope: !294, file: !295, line: 54, baseType: !299, size: 64, offset: 64)
!299 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !300, size: 64)
!300 = !DIBasicType(name: "char", size: 8, encoding: DW_ATE_signed_char)
!301 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_read_end", scope: !294, file: !295, line: 55, baseType: !299, size: 64, offset: 128)
!302 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_read_base", scope: !294, file: !295, line: 56, baseType: !299, size: 64, offset: 192)
!303 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_write_base", scope: !294, file: !295, line: 57, baseType: !299, size: 64, offset: 256)
!304 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_write_ptr", scope: !294, file: !295, line: 58, baseType: !299, size: 64, offset: 320)
!305 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_write_end", scope: !294, file: !295, line: 59, baseType: !299, size: 64, offset: 384)
!306 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_buf_base", scope: !294, file: !295, line: 60, baseType: !299, size: 64, offset: 448)
!307 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_buf_end", scope: !294, file: !295, line: 61, baseType: !299, size: 64, offset: 512)
!308 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_save_base", scope: !294, file: !295, line: 64, baseType: !299, size: 64, offset: 576)
!309 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_backup_base", scope: !294, file: !295, line: 65, baseType: !299, size: 64, offset: 640)
!310 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_save_end", scope: !294, file: !295, line: 66, baseType: !299, size: 64, offset: 704)
!311 = !DIDerivedType(tag: DW_TAG_member, name: "_markers", scope: !294, file: !295, line: 68, baseType: !312, size: 64, offset: 768)
!312 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !313, size: 64)
!313 = !DICompositeType(tag: DW_TAG_structure_type, name: "_IO_marker", file: !295, line: 36, flags: DIFlagFwdDecl)
!314 = !DIDerivedType(tag: DW_TAG_member, name: "_chain", scope: !294, file: !295, line: 70, baseType: !315, size: 64, offset: 832)
!315 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !294, size: 64)
!316 = !DIDerivedType(tag: DW_TAG_member, name: "_fileno", scope: !294, file: !295, line: 72, baseType: !12, size: 32, offset: 896)
!317 = !DIDerivedType(tag: DW_TAG_member, name: "_flags2", scope: !294, file: !295, line: 73, baseType: !12, size: 32, offset: 928)
!318 = !DIDerivedType(tag: DW_TAG_member, name: "_old_offset", scope: !294, file: !295, line: 74, baseType: !319, size: 64, offset: 960)
!319 = !DIDerivedType(tag: DW_TAG_typedef, name: "__off_t", file: !23, line: 152, baseType: !320)
!320 = !DIBasicType(name: "long", size: 64, encoding: DW_ATE_signed)
!321 = !DIDerivedType(tag: DW_TAG_member, name: "_cur_column", scope: !294, file: !295, line: 77, baseType: !322, size: 16, offset: 1024)
!322 = !DIBasicType(name: "unsigned short", size: 16, encoding: DW_ATE_unsigned)
!323 = !DIDerivedType(tag: DW_TAG_member, name: "_vtable_offset", scope: !294, file: !295, line: 78, baseType: !324, size: 8, offset: 1040)
!324 = !DIBasicType(name: "signed char", size: 8, encoding: DW_ATE_signed_char)
!325 = !DIDerivedType(tag: DW_TAG_member, name: "_shortbuf", scope: !294, file: !295, line: 79, baseType: !326, size: 8, offset: 1048)
!326 = !DICompositeType(tag: DW_TAG_array_type, baseType: !300, size: 8, elements: !24)
!327 = !DIDerivedType(tag: DW_TAG_member, name: "_lock", scope: !294, file: !295, line: 81, baseType: !328, size: 64, offset: 1088)
!328 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !329, size: 64)
!329 = !DIDerivedType(tag: DW_TAG_typedef, name: "_IO_lock_t", file: !295, line: 43, baseType: null)
!330 = !DIDerivedType(tag: DW_TAG_member, name: "_offset", scope: !294, file: !295, line: 89, baseType: !331, size: 64, offset: 1152)
!331 = !DIDerivedType(tag: DW_TAG_typedef, name: "__off64_t", file: !23, line: 153, baseType: !320)
!332 = !DIDerivedType(tag: DW_TAG_member, name: "_codecvt", scope: !294, file: !295, line: 91, baseType: !333, size: 64, offset: 1216)
!333 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !334, size: 64)
!334 = !DICompositeType(tag: DW_TAG_structure_type, name: "_IO_codecvt", file: !295, line: 37, flags: DIFlagFwdDecl)
!335 = !DIDerivedType(tag: DW_TAG_member, name: "_wide_data", scope: !294, file: !295, line: 92, baseType: !336, size: 64, offset: 1280)
!336 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !337, size: 64)
!337 = !DICompositeType(tag: DW_TAG_structure_type, name: "_IO_wide_data", file: !295, line: 38, flags: DIFlagFwdDecl)
!338 = !DIDerivedType(tag: DW_TAG_member, name: "_freeres_list", scope: !294, file: !295, line: 93, baseType: !315, size: 64, offset: 1344)
!339 = !DIDerivedType(tag: DW_TAG_member, name: "_freeres_buf", scope: !294, file: !295, line: 94, baseType: !340, size: 64, offset: 1408)
!340 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: null, size: 64)
!341 = !DIDerivedType(tag: DW_TAG_member, name: "__pad5", scope: !294, file: !295, line: 95, baseType: !342, size: 64, offset: 1472)
!342 = !DIDerivedType(tag: DW_TAG_typedef, name: "size_t", file: !343, line: 46, baseType: !344)
!343 = !DIFile(filename: "/usr/lib/llvm-14/lib/clang/14.0.0/include/stddef.h", directory: "", checksumkind: CSK_MD5, checksum: "2499dd2361b915724b073282bea3a7bc")
!344 = !DIBasicType(name: "unsigned long", size: 64, encoding: DW_ATE_unsigned)
!345 = !DIDerivedType(tag: DW_TAG_member, name: "_mode", scope: !294, file: !295, line: 96, baseType: !12, size: 32, offset: 1536)
!346 = !DIDerivedType(tag: DW_TAG_member, name: "_unused2", scope: !294, file: !295, line: 98, baseType: !347, size: 160, offset: 1568)
!347 = !DICompositeType(tag: DW_TAG_array_type, baseType: !300, size: 160, elements: !348)
!348 = !{!349}
!349 = !DISubrange(count: 20)
!350 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !351, size: 64)
!351 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !300)
!352 = !DILocalVariable(name: "stream", arg: 1, scope: !288, file: !32, line: 13, type: !291)
!353 = !DILocation(line: 0, scope: !288)
!354 = !DILocalVariable(name: "format", arg: 2, scope: !288, file: !32, line: 13, type: !350)
!355 = !DILocalVariable(name: "buffer", scope: !288, file: !32, line: 15, type: !356)
!356 = !DICompositeType(tag: DW_TAG_array_type, baseType: !300, size: 6144, elements: !357)
!357 = !{!358}
!358 = !DISubrange(count: 768)
!359 = !DILocation(line: 15, column: 10, scope: !288)
!360 = !DILocalVariable(name: "args", scope: !288, file: !32, line: 16, type: !361)
!361 = !DIDerivedType(tag: DW_TAG_typedef, name: "va_list", file: !362, line: 52, baseType: !363)
!362 = !DIFile(filename: "/usr/include/stdio.h", directory: "", checksumkind: CSK_MD5, checksum: "f31eefcc3f15835fc5a4023a625cf609")
!363 = !DIDerivedType(tag: DW_TAG_typedef, name: "__gnuc_va_list", file: !364, line: 32, baseType: !365)
!364 = !DIFile(filename: "/usr/lib/llvm-14/lib/clang/14.0.0/include/stdarg.h", directory: "", checksumkind: CSK_MD5, checksum: "4de3cbd931b589d291e5c39387aecf82")
!365 = !DIDerivedType(tag: DW_TAG_typedef, name: "__builtin_va_list", file: !366, baseType: !367)
!366 = !DIFile(filename: "source/workload.c", directory: "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/affine-bounds-20260929/suite/covariance")
!367 = !DICompositeType(tag: DW_TAG_array_type, baseType: !368, size: 192, elements: !24)
!368 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "__va_list_tag", size: 192, elements: !369)
!369 = !{!370, !371, !372, !373}
!370 = !DIDerivedType(tag: DW_TAG_member, name: "gp_offset", scope: !368, file: !366, line: 16, baseType: !6, size: 32)
!371 = !DIDerivedType(tag: DW_TAG_member, name: "fp_offset", scope: !368, file: !366, line: 16, baseType: !6, size: 32, offset: 32)
!372 = !DIDerivedType(tag: DW_TAG_member, name: "overflow_arg_area", scope: !368, file: !366, line: 16, baseType: !340, size: 64, offset: 64)
!373 = !DIDerivedType(tag: DW_TAG_member, name: "reg_save_area", scope: !368, file: !366, line: 16, baseType: !340, size: 64, offset: 128)
!374 = !DILocation(line: 16, column: 13, scope: !288)
!375 = !DILocation(line: 17, column: 5, scope: !288)
!376 = !DILocation(line: 18, column: 27, scope: !288)
!377 = !DILocation(line: 18, column: 59, scope: !288)
!378 = !DILocation(line: 18, column: 17, scope: !288)
!379 = !DILocalVariable(name: "count", scope: !288, file: !32, line: 18, type: !12)
!380 = !DILocation(line: 19, column: 5, scope: !288)
!381 = !DILocation(line: 20, column: 15, scope: !382)
!382 = distinct !DILexicalBlock(scope: !288, file: !32, line: 20, column: 9)
!383 = !DILocation(line: 20, column: 19, scope: !382)
!384 = !DILocation(line: 20, column: 22, scope: !382)
!385 = !DILocation(line: 20, column: 38, scope: !382)
!386 = !DILocation(line: 20, column: 9, scope: !288)
!387 = !DILocation(line: 20, column: 57, scope: !382)
!388 = !DILocalVariable(name: "i", scope: !389, file: !32, line: 21, type: !12)
!389 = distinct !DILexicalBlock(scope: !288, file: !32, line: 21, column: 5)
!390 = !DILocation(line: 0, scope: !389)
!391 = !DILocation(line: 21, column: 10, scope: !389)
!392 = !DILocation(line: 21, column: 23, scope: !393)
!393 = distinct !DILexicalBlock(scope: !389, file: !32, line: 21, column: 5)
!394 = !DILocation(line: 21, column: 5, scope: !389)
!395 = !DILocation(line: 22, column: 35, scope: !396)
!396 = distinct !DILexicalBlock(scope: !393, file: !32, line: 21, column: 37)
!397 = !DILocation(line: 22, column: 20, scope: !396)
!398 = !DILocation(line: 22, column: 17, scope: !396)
!399 = !DILocation(line: 23, column: 17, scope: !396)
!400 = !DILocation(line: 24, column: 5, scope: !396)
!401 = !DILocation(line: 21, column: 32, scope: !393)
!402 = !DILocation(line: 21, column: 5, scope: !393)
!403 = distinct !{!403, !394, !404, !112}
!404 = !DILocation(line: 24, column: 5, scope: !389)
!405 = !DILocation(line: 29, column: 11, scope: !288)
!406 = !DILocation(line: 31, column: 5, scope: !288)
