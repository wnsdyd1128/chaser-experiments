; ModuleID = 'inlined.ll'
source_filename = "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/affine-bounds-20260929/suite/fdtd-2d/source/workload.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

@tmax = external dso_local global i32, align 4, !dbg !0
@nx = external dso_local global i32, align 4, !dbg !9
@ny = external dso_local global i32, align 4, !dbg !13
@ex = external dso_local global [200 x [240 x double]], section ".chaser_data.ex", align 64, !dbg !15
@ey = external dso_local global [200 x [240 x double]], section ".chaser_data.ey", align 64, !dbg !21
@hz = external dso_local global [200 x [240 x double]], section ".chaser_data.hz", align 64, !dbg !23
@_fict_ = external dso_local global [100 x double], section ".chaser_data._fict_", align 64, !dbg !25
@.str = hidden unnamed_addr constant [12 x i8] c"ape.analyze\00", section "llvm.metadata"
@.str.1 = hidden unnamed_addr constant [125 x i8] c"/workspace/experiments-array-support/chaser/.cache/periodic-polybench/affine-bounds-20260929/suite/fdtd-2d/source/workload.c\00", section "llvm.metadata"
@.str.2 = hidden unnamed_addr constant [23 x i8] c"==BEGIN DUMP_ARRAYS==\0A\00", align 1
@.str.3 = hidden unnamed_addr constant [15 x i8] c"begin dump: %s\00", align 1
@.str.4 = hidden unnamed_addr constant [3 x i8] c"ex\00", align 1
@.str.5 = hidden unnamed_addr constant [2 x i8] c"\0A\00", align 1
@.str.6 = hidden unnamed_addr constant [8 x i8] c"%0.2lf \00", align 1
@.str.7 = hidden unnamed_addr constant [17 x i8] c"\0Aend   dump: %s\0A\00", align 1
@.str.8 = hidden unnamed_addr constant [23 x i8] c"==END   DUMP_ARRAYS==\0A\00", align 1
@.str.9 = hidden unnamed_addr constant [3 x i8] c"ey\00", align 1
@.str.10 = hidden unnamed_addr constant [3 x i8] c"hz\00", align 1
@llvm.global.annotations = appending global [1 x { i8*, i8*, i8*, i32, i8* }] [{ i8*, i8*, i8*, i32, i8* } { i8* bitcast (i32 ()* @task_job_polybench to i8*), i8* getelementptr inbounds ([12 x i8], [12 x i8]* @.str, i32 0, i32 0), i8* getelementptr inbounds ([125 x i8], [125 x i8]* @.str.1, i32 0, i32 0), i32 152, i8* null }], section "llvm.metadata"

; Function Attrs: noinline nounwind uwtable
define dso_local i32 @task_job_polybench() #0 !dbg !38 {
  %1 = load i32, i32* @tmax, align 4, !dbg !46
  %2 = load i32, i32* @nx, align 4, !dbg !47
  %3 = load i32, i32* @ny, align 4, !dbg !48
  call void @llvm.dbg.value(metadata i32 %1, metadata !49, metadata !DIExpression()), !dbg !57
  call void @llvm.dbg.value(metadata i32 %2, metadata !59, metadata !DIExpression()), !dbg !57
  call void @llvm.dbg.value(metadata i32 %3, metadata !60, metadata !DIExpression()), !dbg !57
  call void @llvm.dbg.value(metadata [240 x double]* getelementptr inbounds ([200 x [240 x double]], [200 x [240 x double]]* @ex, i64 0, i64 0), metadata !61, metadata !DIExpression()), !dbg !57
  call void @llvm.dbg.value(metadata [240 x double]* getelementptr inbounds ([200 x [240 x double]], [200 x [240 x double]]* @ey, i64 0, i64 0), metadata !62, metadata !DIExpression()), !dbg !57
  call void @llvm.dbg.value(metadata [240 x double]* getelementptr inbounds ([200 x [240 x double]], [200 x [240 x double]]* @hz, i64 0, i64 0), metadata !63, metadata !DIExpression()), !dbg !57
  call void @llvm.dbg.value(metadata double* getelementptr inbounds ([100 x double], [100 x double]* @_fict_, i64 0, i64 0), metadata !64, metadata !DIExpression()), !dbg !57
  call void @llvm.dbg.value(metadata i32 0, metadata !65, metadata !DIExpression()), !dbg !57
  br label %4, !dbg !66

4:                                                ; preds = %128, %0
  %.04 = phi i32 [ 0, %0 ], [ %129, %128 ], !dbg !68
  call void @llvm.dbg.value(metadata i32 %.04, metadata !65, metadata !DIExpression()), !dbg !57
  %5 = icmp slt i32 %.04, 100, !dbg !69
  br i1 %5, label %6, label %130, !dbg !71

6:                                                ; preds = %4
  call void @llvm.dbg.value(metadata i32 0, metadata !72, metadata !DIExpression()), !dbg !57
  br label %7, !dbg !73

7:                                                ; preds = %9, %6
  %.0 = phi i32 [ 0, %6 ], [ %15, %9 ], !dbg !76
  call void @llvm.dbg.value(metadata i32 %.0, metadata !72, metadata !DIExpression()), !dbg !57
  %8 = icmp slt i32 %.0, 240, !dbg !77
  br i1 %8, label %9, label %16, !dbg !79

9:                                                ; preds = %7
  %10 = sext i32 %.04 to i64, !dbg !80
  %11 = getelementptr inbounds double, double* getelementptr inbounds ([100 x double], [100 x double]* @_fict_, i64 0, i64 0), i64 %10, !dbg !80
  %12 = load double, double* %11, align 8, !dbg !80
  %13 = sext i32 %.0 to i64, !dbg !81
  %14 = getelementptr inbounds [240 x double], [240 x double]* getelementptr inbounds ([200 x [240 x double]], [200 x [240 x double]]* @ey, i64 0, i64 0), i64 0, i64 %13, !dbg !81
  store double %12, double* %14, align 8, !dbg !82
  %15 = add nsw i32 %.0, 1, !dbg !83
  call void @llvm.dbg.value(metadata i32 %15, metadata !72, metadata !DIExpression()), !dbg !57
  br label %7, !dbg !84, !llvm.loop !85

16:                                               ; preds = %7
  call void @llvm.dbg.value(metadata i32 1, metadata !88, metadata !DIExpression()), !dbg !57
  br label %17, !dbg !89

17:                                               ; preds = %47, %16
  %.01 = phi i32 [ 1, %16 ], [ %48, %47 ], !dbg !91
  call void @llvm.dbg.value(metadata i32 %.01, metadata !88, metadata !DIExpression()), !dbg !57
  %18 = icmp slt i32 %.01, 200, !dbg !92
  br i1 %18, label %19, label %49, !dbg !94

19:                                               ; preds = %17
  call void @llvm.dbg.value(metadata i32 0, metadata !72, metadata !DIExpression()), !dbg !57
  br label %20, !dbg !95

20:                                               ; preds = %22, %19
  %.1 = phi i32 [ 0, %19 ], [ %46, %22 ], !dbg !97
  call void @llvm.dbg.value(metadata i32 %.1, metadata !72, metadata !DIExpression()), !dbg !57
  %21 = icmp slt i32 %.1, 240, !dbg !98
  br i1 %21, label %22, label %47, !dbg !100

22:                                               ; preds = %20
  %23 = sext i32 %.01 to i64, !dbg !101
  %24 = getelementptr inbounds [240 x double], [240 x double]* getelementptr inbounds ([200 x [240 x double]], [200 x [240 x double]]* @ey, i64 0, i64 0), i64 %23, !dbg !101
  %25 = sext i32 %.1 to i64, !dbg !101
  %26 = getelementptr inbounds [240 x double], [240 x double]* %24, i64 0, i64 %25, !dbg !101
  %27 = load double, double* %26, align 8, !dbg !101
  %28 = sext i32 %.01 to i64, !dbg !102
  %29 = getelementptr inbounds [240 x double], [240 x double]* getelementptr inbounds ([200 x [240 x double]], [200 x [240 x double]]* @hz, i64 0, i64 0), i64 %28, !dbg !102
  %30 = sext i32 %.1 to i64, !dbg !102
  %31 = getelementptr inbounds [240 x double], [240 x double]* %29, i64 0, i64 %30, !dbg !102
  %32 = load double, double* %31, align 8, !dbg !102
  %33 = sub nsw i32 %.01, 1, !dbg !103
  %34 = sext i32 %33 to i64, !dbg !104
  %35 = getelementptr inbounds [240 x double], [240 x double]* getelementptr inbounds ([200 x [240 x double]], [200 x [240 x double]]* @hz, i64 0, i64 0), i64 %34, !dbg !104
  %36 = sext i32 %.1 to i64, !dbg !104
  %37 = getelementptr inbounds [240 x double], [240 x double]* %35, i64 0, i64 %36, !dbg !104
  %38 = load double, double* %37, align 8, !dbg !104
  %39 = fsub double %32, %38, !dbg !105
  %40 = fmul double 5.000000e-01, %39, !dbg !106
  %41 = fsub double %27, %40, !dbg !107
  %42 = sext i32 %.01 to i64, !dbg !108
  %43 = getelementptr inbounds [240 x double], [240 x double]* getelementptr inbounds ([200 x [240 x double]], [200 x [240 x double]]* @ey, i64 0, i64 0), i64 %42, !dbg !108
  %44 = sext i32 %.1 to i64, !dbg !108
  %45 = getelementptr inbounds [240 x double], [240 x double]* %43, i64 0, i64 %44, !dbg !108
  store double %41, double* %45, align 8, !dbg !109
  %46 = add nsw i32 %.1, 1, !dbg !110
  call void @llvm.dbg.value(metadata i32 %46, metadata !72, metadata !DIExpression()), !dbg !57
  br label %20, !dbg !111, !llvm.loop !112

47:                                               ; preds = %20
  %48 = add nsw i32 %.01, 1, !dbg !114
  call void @llvm.dbg.value(metadata i32 %48, metadata !88, metadata !DIExpression()), !dbg !57
  br label %17, !dbg !115, !llvm.loop !116

49:                                               ; preds = %17
  call void @llvm.dbg.value(metadata i32 0, metadata !88, metadata !DIExpression()), !dbg !57
  br label %50, !dbg !118

50:                                               ; preds = %80, %49
  %.12 = phi i32 [ 0, %49 ], [ %81, %80 ], !dbg !120
  call void @llvm.dbg.value(metadata i32 %.12, metadata !88, metadata !DIExpression()), !dbg !57
  %51 = icmp slt i32 %.12, 200, !dbg !121
  br i1 %51, label %52, label %82, !dbg !123

52:                                               ; preds = %50
  call void @llvm.dbg.value(metadata i32 1, metadata !72, metadata !DIExpression()), !dbg !57
  br label %53, !dbg !124

53:                                               ; preds = %55, %52
  %.2 = phi i32 [ 1, %52 ], [ %79, %55 ], !dbg !126
  call void @llvm.dbg.value(metadata i32 %.2, metadata !72, metadata !DIExpression()), !dbg !57
  %54 = icmp slt i32 %.2, 240, !dbg !127
  br i1 %54, label %55, label %80, !dbg !129

55:                                               ; preds = %53
  %56 = sext i32 %.12 to i64, !dbg !130
  %57 = getelementptr inbounds [240 x double], [240 x double]* getelementptr inbounds ([200 x [240 x double]], [200 x [240 x double]]* @ex, i64 0, i64 0), i64 %56, !dbg !130
  %58 = sext i32 %.2 to i64, !dbg !130
  %59 = getelementptr inbounds [240 x double], [240 x double]* %57, i64 0, i64 %58, !dbg !130
  %60 = load double, double* %59, align 8, !dbg !130
  %61 = sext i32 %.12 to i64, !dbg !131
  %62 = getelementptr inbounds [240 x double], [240 x double]* getelementptr inbounds ([200 x [240 x double]], [200 x [240 x double]]* @hz, i64 0, i64 0), i64 %61, !dbg !131
  %63 = sext i32 %.2 to i64, !dbg !131
  %64 = getelementptr inbounds [240 x double], [240 x double]* %62, i64 0, i64 %63, !dbg !131
  %65 = load double, double* %64, align 8, !dbg !131
  %66 = sext i32 %.12 to i64, !dbg !132
  %67 = getelementptr inbounds [240 x double], [240 x double]* getelementptr inbounds ([200 x [240 x double]], [200 x [240 x double]]* @hz, i64 0, i64 0), i64 %66, !dbg !132
  %68 = sub nsw i32 %.2, 1, !dbg !133
  %69 = sext i32 %68 to i64, !dbg !132
  %70 = getelementptr inbounds [240 x double], [240 x double]* %67, i64 0, i64 %69, !dbg !132
  %71 = load double, double* %70, align 8, !dbg !132
  %72 = fsub double %65, %71, !dbg !134
  %73 = fmul double 5.000000e-01, %72, !dbg !135
  %74 = fsub double %60, %73, !dbg !136
  %75 = sext i32 %.12 to i64, !dbg !137
  %76 = getelementptr inbounds [240 x double], [240 x double]* getelementptr inbounds ([200 x [240 x double]], [200 x [240 x double]]* @ex, i64 0, i64 0), i64 %75, !dbg !137
  %77 = sext i32 %.2 to i64, !dbg !137
  %78 = getelementptr inbounds [240 x double], [240 x double]* %76, i64 0, i64 %77, !dbg !137
  store double %74, double* %78, align 8, !dbg !138
  %79 = add nsw i32 %.2, 1, !dbg !139
  call void @llvm.dbg.value(metadata i32 %79, metadata !72, metadata !DIExpression()), !dbg !57
  br label %53, !dbg !140, !llvm.loop !141

80:                                               ; preds = %53
  %81 = add nsw i32 %.12, 1, !dbg !143
  call void @llvm.dbg.value(metadata i32 %81, metadata !88, metadata !DIExpression()), !dbg !57
  br label %50, !dbg !144, !llvm.loop !145

82:                                               ; preds = %50
  call void @llvm.dbg.value(metadata i32 0, metadata !88, metadata !DIExpression()), !dbg !57
  br label %83, !dbg !147

83:                                               ; preds = %126, %82
  %.23 = phi i32 [ 0, %82 ], [ %127, %126 ], !dbg !149
  call void @llvm.dbg.value(metadata i32 %.23, metadata !88, metadata !DIExpression()), !dbg !57
  %84 = icmp slt i32 %.23, 199, !dbg !150
  br i1 %84, label %85, label %128, !dbg !152

85:                                               ; preds = %83
  call void @llvm.dbg.value(metadata i32 0, metadata !72, metadata !DIExpression()), !dbg !57
  br label %86, !dbg !153

86:                                               ; preds = %88, %85
  %.3 = phi i32 [ 0, %85 ], [ %125, %88 ], !dbg !155
  call void @llvm.dbg.value(metadata i32 %.3, metadata !72, metadata !DIExpression()), !dbg !57
  %87 = icmp slt i32 %.3, 239, !dbg !156
  br i1 %87, label %88, label %126, !dbg !158

88:                                               ; preds = %86
  %89 = sext i32 %.23 to i64, !dbg !159
  %90 = getelementptr inbounds [240 x double], [240 x double]* getelementptr inbounds ([200 x [240 x double]], [200 x [240 x double]]* @hz, i64 0, i64 0), i64 %89, !dbg !159
  %91 = sext i32 %.3 to i64, !dbg !159
  %92 = getelementptr inbounds [240 x double], [240 x double]* %90, i64 0, i64 %91, !dbg !159
  %93 = load double, double* %92, align 8, !dbg !159
  %94 = sext i32 %.23 to i64, !dbg !160
  %95 = getelementptr inbounds [240 x double], [240 x double]* getelementptr inbounds ([200 x [240 x double]], [200 x [240 x double]]* @ex, i64 0, i64 0), i64 %94, !dbg !160
  %96 = add nsw i32 %.3, 1, !dbg !161
  %97 = sext i32 %96 to i64, !dbg !160
  %98 = getelementptr inbounds [240 x double], [240 x double]* %95, i64 0, i64 %97, !dbg !160
  %99 = load double, double* %98, align 8, !dbg !160
  %100 = sext i32 %.23 to i64, !dbg !162
  %101 = getelementptr inbounds [240 x double], [240 x double]* getelementptr inbounds ([200 x [240 x double]], [200 x [240 x double]]* @ex, i64 0, i64 0), i64 %100, !dbg !162
  %102 = sext i32 %.3 to i64, !dbg !162
  %103 = getelementptr inbounds [240 x double], [240 x double]* %101, i64 0, i64 %102, !dbg !162
  %104 = load double, double* %103, align 8, !dbg !162
  %105 = fsub double %99, %104, !dbg !163
  %106 = add nsw i32 %.23, 1, !dbg !164
  %107 = sext i32 %106 to i64, !dbg !165
  %108 = getelementptr inbounds [240 x double], [240 x double]* getelementptr inbounds ([200 x [240 x double]], [200 x [240 x double]]* @ey, i64 0, i64 0), i64 %107, !dbg !165
  %109 = sext i32 %.3 to i64, !dbg !165
  %110 = getelementptr inbounds [240 x double], [240 x double]* %108, i64 0, i64 %109, !dbg !165
  %111 = load double, double* %110, align 8, !dbg !165
  %112 = fadd double %105, %111, !dbg !166
  %113 = sext i32 %.23 to i64, !dbg !167
  %114 = getelementptr inbounds [240 x double], [240 x double]* getelementptr inbounds ([200 x [240 x double]], [200 x [240 x double]]* @ey, i64 0, i64 0), i64 %113, !dbg !167
  %115 = sext i32 %.3 to i64, !dbg !167
  %116 = getelementptr inbounds [240 x double], [240 x double]* %114, i64 0, i64 %115, !dbg !167
  %117 = load double, double* %116, align 8, !dbg !167
  %118 = fsub double %112, %117, !dbg !168
  %119 = fmul double 0x3FE6666666666666, %118, !dbg !169
  %120 = fsub double %93, %119, !dbg !170
  %121 = sext i32 %.23 to i64, !dbg !171
  %122 = getelementptr inbounds [240 x double], [240 x double]* getelementptr inbounds ([200 x [240 x double]], [200 x [240 x double]]* @hz, i64 0, i64 0), i64 %121, !dbg !171
  %123 = sext i32 %.3 to i64, !dbg !171
  %124 = getelementptr inbounds [240 x double], [240 x double]* %122, i64 0, i64 %123, !dbg !171
  store double %120, double* %124, align 8, !dbg !172
  %125 = add nsw i32 %.3, 1, !dbg !173
  call void @llvm.dbg.value(metadata i32 %125, metadata !72, metadata !DIExpression()), !dbg !57
  br label %86, !dbg !174, !llvm.loop !175

126:                                              ; preds = %86
  %127 = add nsw i32 %.23, 1, !dbg !177
  call void @llvm.dbg.value(metadata i32 %127, metadata !88, metadata !DIExpression()), !dbg !57
  br label %83, !dbg !178, !llvm.loop !179

128:                                              ; preds = %83
  %129 = add nsw i32 %.04, 1, !dbg !181
  call void @llvm.dbg.value(metadata i32 %129, metadata !65, metadata !DIExpression()), !dbg !57
  br label %4, !dbg !182, !llvm.loop !183

130:                                              ; preds = %4
  ret i32 0, !dbg !185
}

; Function Attrs: nofree nosync nounwind readnone speculatable willreturn
declare void @llvm.dbg.value(metadata, metadata, metadata) #1

attributes #0 = { noinline nounwind uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { nofree nosync nounwind readnone speculatable willreturn }

!llvm.dbg.cu = !{!2}
!llvm.module.flags = !{!30, !31, !32, !33, !34, !35, !36}
!llvm.ident = !{!37}

!0 = !DIGlobalVariableExpression(var: !1, expr: !DIExpression())
!1 = distinct !DIGlobalVariable(name: "tmax", scope: !2, file: !11, line: 136, type: !12, isLocal: false, isDefinition: true)
!2 = distinct !DICompileUnit(language: DW_LANG_C99, file: !3, producer: "Ubuntu clang version 14.0.0-1ubuntu1.1", isOptimized: false, runtimeVersion: 0, emissionKind: FullDebug, retainedTypes: !4, globals: !8, splitDebugInlining: false, nameTableKind: None)
!3 = !DIFile(filename: "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/affine-bounds-20260929/suite/fdtd-2d/source/workload.c", directory: "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/affine-bounds-20260929/suite/fdtd-2d/analysis-g", checksumkind: CSK_MD5, checksum: "9d9200f235ea413f4d7971907182251a")
!4 = !{!5, !6, !7}
!5 = !DIBasicType(name: "double", size: 64, encoding: DW_ATE_float)
!6 = !DIBasicType(name: "unsigned int", size: 32, encoding: DW_ATE_unsigned)
!7 = !DIBasicType(name: "unsigned char", size: 8, encoding: DW_ATE_unsigned_char)
!8 = !{!0, !9, !13, !15, !21, !23, !25}
!9 = !DIGlobalVariableExpression(var: !10, expr: !DIExpression())
!10 = distinct !DIGlobalVariable(name: "nx", scope: !2, file: !11, line: 137, type: !12, isLocal: false, isDefinition: true)
!11 = !DIFile(filename: "source/workload.c", directory: "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/affine-bounds-20260929/suite/fdtd-2d", checksumkind: CSK_MD5, checksum: "9d9200f235ea413f4d7971907182251a")
!12 = !DIBasicType(name: "int", size: 32, encoding: DW_ATE_signed)
!13 = !DIGlobalVariableExpression(var: !14, expr: !DIExpression())
!14 = distinct !DIGlobalVariable(name: "ny", scope: !2, file: !11, line: 138, type: !12, isLocal: false, isDefinition: true)
!15 = !DIGlobalVariableExpression(var: !16, expr: !DIExpression())
!16 = distinct !DIGlobalVariable(name: "ex", scope: !2, file: !11, line: 34, type: !17, isLocal: false, isDefinition: true, align: 512)
!17 = !DICompositeType(tag: DW_TAG_array_type, baseType: !5, size: 3072000, elements: !18)
!18 = !{!19, !20}
!19 = !DISubrange(count: 200)
!20 = !DISubrange(count: 240)
!21 = !DIGlobalVariableExpression(var: !22, expr: !DIExpression())
!22 = distinct !DIGlobalVariable(name: "ey", scope: !2, file: !11, line: 35, type: !17, isLocal: false, isDefinition: true, align: 512)
!23 = !DIGlobalVariableExpression(var: !24, expr: !DIExpression())
!24 = distinct !DIGlobalVariable(name: "hz", scope: !2, file: !11, line: 36, type: !17, isLocal: false, isDefinition: true, align: 512)
!25 = !DIGlobalVariableExpression(var: !26, expr: !DIExpression())
!26 = distinct !DIGlobalVariable(name: "_fict_", scope: !2, file: !11, line: 37, type: !27, isLocal: false, isDefinition: true, align: 512)
!27 = !DICompositeType(tag: DW_TAG_array_type, baseType: !5, size: 6400, elements: !28)
!28 = !{!29}
!29 = !DISubrange(count: 100)
!30 = !{i32 7, !"Dwarf Version", i32 5}
!31 = !{i32 2, !"Debug Info Version", i32 3}
!32 = !{i32 1, !"wchar_size", i32 4}
!33 = !{i32 7, !"PIC Level", i32 2}
!34 = !{i32 7, !"PIE Level", i32 2}
!35 = !{i32 7, !"uwtable", i32 1}
!36 = !{i32 7, !"frame-pointer", i32 2}
!37 = !{!"Ubuntu clang version 14.0.0-1ubuntu1.1"}
!38 = distinct !DISubprogram(name: "task_job_polybench", scope: !11, file: !11, line: 152, type: !39, scopeLine: 152, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !2, retainedNodes: !45)
!39 = !DISubroutineType(types: !40)
!40 = !{!41}
!41 = !DIDerivedType(tag: DW_TAG_typedef, name: "uint32_t", file: !42, line: 26, baseType: !43)
!42 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/stdint-uintn.h", directory: "", checksumkind: CSK_MD5, checksum: "2bf2ae53c58c01b1a1b9383b5195125c")
!43 = !DIDerivedType(tag: DW_TAG_typedef, name: "__uint32_t", file: !44, line: 42, baseType: !6)
!44 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/types.h", directory: "", checksumkind: CSK_MD5, checksum: "d108b5f93a74c50510d7d9bc0ab36df9")
!45 = !{}
!46 = !DILocation(line: 153, column: 19, scope: !38)
!47 = !DILocation(line: 153, column: 25, scope: !38)
!48 = !DILocation(line: 153, column: 29, scope: !38)
!49 = !DILocalVariable(name: "tmax", arg: 1, scope: !50, file: !11, line: 103, type: !12)
!50 = distinct !DISubprogram(name: "kernel_fdtd_2d", scope: !11, file: !11, line: 103, type: !51, scopeLine: 110, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition, unit: !2, retainedNodes: !45)
!51 = !DISubroutineType(types: !52)
!52 = !{null, !12, !12, !12, !53, !53, !53, !56}
!53 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !54, size: 64)
!54 = !DICompositeType(tag: DW_TAG_array_type, baseType: !5, size: 15360, elements: !55)
!55 = !{!20}
!56 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !5, size: 64)
!57 = !DILocation(line: 0, scope: !50, inlinedAt: !58)
!58 = distinct !DILocation(line: 153, column: 3, scope: !38)
!59 = !DILocalVariable(name: "nx", arg: 2, scope: !50, file: !11, line: 104, type: !12)
!60 = !DILocalVariable(name: "ny", arg: 3, scope: !50, file: !11, line: 105, type: !12)
!61 = !DILocalVariable(name: "ex", arg: 4, scope: !50, file: !11, line: 106, type: !53)
!62 = !DILocalVariable(name: "ey", arg: 5, scope: !50, file: !11, line: 107, type: !53)
!63 = !DILocalVariable(name: "hz", arg: 6, scope: !50, file: !11, line: 108, type: !53)
!64 = !DILocalVariable(name: "_fict_", arg: 7, scope: !50, file: !11, line: 109, type: !56)
!65 = !DILocalVariable(name: "t", scope: !50, file: !11, line: 111, type: !12)
!66 = !DILocation(line: 115, column: 7, scope: !67, inlinedAt: !58)
!67 = distinct !DILexicalBlock(scope: !50, file: !11, line: 115, column: 3)
!68 = !DILocation(line: 0, scope: !67, inlinedAt: !58)
!69 = !DILocation(line: 115, column: 16, scope: !70, inlinedAt: !58)
!70 = distinct !DILexicalBlock(scope: !67, file: !11, line: 115, column: 3)
!71 = !DILocation(line: 115, column: 3, scope: !67, inlinedAt: !58)
!72 = !DILocalVariable(name: "j", scope: !50, file: !11, line: 111, type: !12)
!73 = !DILocation(line: 117, column: 12, scope: !74, inlinedAt: !58)
!74 = distinct !DILexicalBlock(scope: !75, file: !11, line: 117, column: 7)
!75 = distinct !DILexicalBlock(scope: !70, file: !11, line: 116, column: 5)
!76 = !DILocation(line: 0, scope: !74, inlinedAt: !58)
!77 = !DILocation(line: 117, column: 21, scope: !78, inlinedAt: !58)
!78 = distinct !DILexicalBlock(scope: !74, file: !11, line: 117, column: 7)
!79 = !DILocation(line: 117, column: 7, scope: !74, inlinedAt: !58)
!80 = !DILocation(line: 118, column: 13, scope: !78, inlinedAt: !58)
!81 = !DILocation(line: 118, column: 2, scope: !78, inlinedAt: !58)
!82 = !DILocation(line: 118, column: 11, scope: !78, inlinedAt: !58)
!83 = !DILocation(line: 117, column: 32, scope: !78, inlinedAt: !58)
!84 = !DILocation(line: 117, column: 7, scope: !78, inlinedAt: !58)
!85 = distinct !{!85, !79, !86, !87}
!86 = !DILocation(line: 118, column: 21, scope: !74, inlinedAt: !58)
!87 = !{!"llvm.loop.mustprogress"}
!88 = !DILocalVariable(name: "i", scope: !50, file: !11, line: 111, type: !12)
!89 = !DILocation(line: 119, column: 12, scope: !90, inlinedAt: !58)
!90 = distinct !DILexicalBlock(scope: !75, file: !11, line: 119, column: 7)
!91 = !DILocation(line: 0, scope: !90, inlinedAt: !58)
!92 = !DILocation(line: 119, column: 21, scope: !93, inlinedAt: !58)
!93 = distinct !DILexicalBlock(scope: !90, file: !11, line: 119, column: 7)
!94 = !DILocation(line: 119, column: 7, scope: !90, inlinedAt: !58)
!95 = !DILocation(line: 120, column: 7, scope: !96, inlinedAt: !58)
!96 = distinct !DILexicalBlock(scope: !93, file: !11, line: 120, column: 2)
!97 = !DILocation(line: 0, scope: !96, inlinedAt: !58)
!98 = !DILocation(line: 120, column: 16, scope: !99, inlinedAt: !58)
!99 = distinct !DILexicalBlock(scope: !96, file: !11, line: 120, column: 2)
!100 = !DILocation(line: 120, column: 2, scope: !96, inlinedAt: !58)
!101 = !DILocation(line: 121, column: 15, scope: !99, inlinedAt: !58)
!102 = !DILocation(line: 121, column: 43, scope: !99, inlinedAt: !58)
!103 = !DILocation(line: 121, column: 56, scope: !99, inlinedAt: !58)
!104 = !DILocation(line: 121, column: 52, scope: !99, inlinedAt: !58)
!105 = !DILocation(line: 121, column: 51, scope: !99, inlinedAt: !58)
!106 = !DILocation(line: 121, column: 41, scope: !99, inlinedAt: !58)
!107 = !DILocation(line: 121, column: 24, scope: !99, inlinedAt: !58)
!108 = !DILocation(line: 121, column: 4, scope: !99, inlinedAt: !58)
!109 = !DILocation(line: 121, column: 13, scope: !99, inlinedAt: !58)
!110 = !DILocation(line: 120, column: 27, scope: !99, inlinedAt: !58)
!111 = !DILocation(line: 120, column: 2, scope: !99, inlinedAt: !58)
!112 = distinct !{!112, !100, !113, !87}
!113 = !DILocation(line: 121, column: 62, scope: !96, inlinedAt: !58)
!114 = !DILocation(line: 119, column: 32, scope: !93, inlinedAt: !58)
!115 = !DILocation(line: 119, column: 7, scope: !93, inlinedAt: !58)
!116 = distinct !{!116, !94, !117, !87}
!117 = !DILocation(line: 121, column: 62, scope: !90, inlinedAt: !58)
!118 = !DILocation(line: 122, column: 12, scope: !119, inlinedAt: !58)
!119 = distinct !DILexicalBlock(scope: !75, file: !11, line: 122, column: 7)
!120 = !DILocation(line: 0, scope: !119, inlinedAt: !58)
!121 = !DILocation(line: 122, column: 21, scope: !122, inlinedAt: !58)
!122 = distinct !DILexicalBlock(scope: !119, file: !11, line: 122, column: 7)
!123 = !DILocation(line: 122, column: 7, scope: !119, inlinedAt: !58)
!124 = !DILocation(line: 123, column: 7, scope: !125, inlinedAt: !58)
!125 = distinct !DILexicalBlock(scope: !122, file: !11, line: 123, column: 2)
!126 = !DILocation(line: 0, scope: !125, inlinedAt: !58)
!127 = !DILocation(line: 123, column: 16, scope: !128, inlinedAt: !58)
!128 = distinct !DILexicalBlock(scope: !125, file: !11, line: 123, column: 2)
!129 = !DILocation(line: 123, column: 2, scope: !125, inlinedAt: !58)
!130 = !DILocation(line: 124, column: 15, scope: !128, inlinedAt: !58)
!131 = !DILocation(line: 124, column: 43, scope: !128, inlinedAt: !58)
!132 = !DILocation(line: 124, column: 52, scope: !128, inlinedAt: !58)
!133 = !DILocation(line: 124, column: 59, scope: !128, inlinedAt: !58)
!134 = !DILocation(line: 124, column: 51, scope: !128, inlinedAt: !58)
!135 = !DILocation(line: 124, column: 41, scope: !128, inlinedAt: !58)
!136 = !DILocation(line: 124, column: 24, scope: !128, inlinedAt: !58)
!137 = !DILocation(line: 124, column: 4, scope: !128, inlinedAt: !58)
!138 = !DILocation(line: 124, column: 13, scope: !128, inlinedAt: !58)
!139 = !DILocation(line: 123, column: 27, scope: !128, inlinedAt: !58)
!140 = !DILocation(line: 123, column: 2, scope: !128, inlinedAt: !58)
!141 = distinct !{!141, !129, !142, !87}
!142 = !DILocation(line: 124, column: 62, scope: !125, inlinedAt: !58)
!143 = !DILocation(line: 122, column: 32, scope: !122, inlinedAt: !58)
!144 = !DILocation(line: 122, column: 7, scope: !122, inlinedAt: !58)
!145 = distinct !{!145, !123, !146, !87}
!146 = !DILocation(line: 124, column: 62, scope: !119, inlinedAt: !58)
!147 = !DILocation(line: 125, column: 12, scope: !148, inlinedAt: !58)
!148 = distinct !DILexicalBlock(scope: !75, file: !11, line: 125, column: 7)
!149 = !DILocation(line: 0, scope: !148, inlinedAt: !58)
!150 = !DILocation(line: 125, column: 21, scope: !151, inlinedAt: !58)
!151 = distinct !DILexicalBlock(scope: !148, file: !11, line: 125, column: 7)
!152 = !DILocation(line: 125, column: 7, scope: !148, inlinedAt: !58)
!153 = !DILocation(line: 126, column: 7, scope: !154, inlinedAt: !58)
!154 = distinct !DILexicalBlock(scope: !151, file: !11, line: 126, column: 2)
!155 = !DILocation(line: 0, scope: !154, inlinedAt: !58)
!156 = !DILocation(line: 126, column: 16, scope: !157, inlinedAt: !58)
!157 = distinct !DILexicalBlock(scope: !154, file: !11, line: 126, column: 2)
!158 = !DILocation(line: 126, column: 2, scope: !154, inlinedAt: !58)
!159 = !DILocation(line: 127, column: 15, scope: !157, inlinedAt: !58)
!160 = !DILocation(line: 127, column: 45, scope: !157, inlinedAt: !58)
!161 = !DILocation(line: 127, column: 52, scope: !157, inlinedAt: !58)
!162 = !DILocation(line: 127, column: 58, scope: !157, inlinedAt: !58)
!163 = !DILocation(line: 127, column: 56, scope: !157, inlinedAt: !58)
!164 = !DILocation(line: 128, column: 16, scope: !157, inlinedAt: !58)
!165 = !DILocation(line: 128, column: 12, scope: !157, inlinedAt: !58)
!166 = !DILocation(line: 127, column: 67, scope: !157, inlinedAt: !58)
!167 = !DILocation(line: 128, column: 25, scope: !157, inlinedAt: !58)
!168 = !DILocation(line: 128, column: 23, scope: !157, inlinedAt: !58)
!169 = !DILocation(line: 127, column: 41, scope: !157, inlinedAt: !58)
!170 = !DILocation(line: 127, column: 24, scope: !157, inlinedAt: !58)
!171 = !DILocation(line: 127, column: 4, scope: !157, inlinedAt: !58)
!172 = !DILocation(line: 127, column: 13, scope: !157, inlinedAt: !58)
!173 = !DILocation(line: 126, column: 31, scope: !157, inlinedAt: !58)
!174 = !DILocation(line: 126, column: 2, scope: !157, inlinedAt: !58)
!175 = distinct !{!175, !158, !176, !87}
!176 = !DILocation(line: 128, column: 33, scope: !154, inlinedAt: !58)
!177 = !DILocation(line: 125, column: 36, scope: !151, inlinedAt: !58)
!178 = !DILocation(line: 125, column: 7, scope: !151, inlinedAt: !58)
!179 = distinct !{!179, !152, !180, !87}
!180 = !DILocation(line: 128, column: 33, scope: !148, inlinedAt: !58)
!181 = !DILocation(line: 115, column: 29, scope: !70, inlinedAt: !58)
!182 = !DILocation(line: 115, column: 3, scope: !70, inlinedAt: !58)
!183 = distinct !{!183, !71, !184, !87}
!184 = !DILocation(line: 129, column: 5, scope: !67, inlinedAt: !58)
!185 = !DILocation(line: 158, column: 3, scope: !38)
