; ModuleID = 'workload.ll'
source_filename = "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/affine-bounds-20260929/suite/2mm/source/workload.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

%struct._IO_FILE = type { i32, i8*, i8*, i8*, i8*, i8*, i8*, i8*, i8*, i8*, i8*, i8*, %struct._IO_marker*, %struct._IO_FILE*, i32, i32, i64, i16, i8, [1 x i8], i8*, i64, %struct._IO_codecvt*, %struct._IO_wide_data*, %struct._IO_FILE*, i8*, i64, i32, [20 x i8] }
%struct._IO_marker = type opaque
%struct._IO_codecvt = type opaque
%struct._IO_wide_data = type opaque
%struct.__va_list_tag = type { i32, i32, i8*, i8* }

@ni = dso_local global i32 180, align 4, !dbg !0
@nj = dso_local global i32 190, align 4, !dbg !9
@nk = dso_local global i32 210, align 4, !dbg !13
@nl = dso_local global i32 220, align 4, !dbg !15
@tmp = dso_local global [180 x [190 x double]] zeroinitializer, section ".chaser_data.tmp", align 64, !dbg !37
@A = dso_local global [180 x [210 x double]] zeroinitializer, section ".chaser_data.A", align 64, !dbg !43
@B = dso_local global [210 x [190 x double]] zeroinitializer, section ".chaser_data.B", align 64, !dbg !48
@C = dso_local global [190 x [220 x double]] zeroinitializer, section ".chaser_data.C", align 64, !dbg !52
@D = dso_local global [180 x [220 x double]] zeroinitializer, section ".chaser_data.D", align 64, !dbg !57
@alpha = dso_local global double 0.000000e+00, align 8, !dbg !61
@beta = dso_local global double 0.000000e+00, align 8, !dbg !63
@.str = private unnamed_addr constant [12 x i8] c"ape.analyze\00", section "llvm.metadata"
@.str.1 = private unnamed_addr constant [121 x i8] c"/workspace/experiments-array-support/chaser/.cache/periodic-polybench/affine-bounds-20260929/suite/2mm/source/workload.c\00", section "llvm.metadata"
@pb_hash = internal global i32 0, align 4, !dbg !34
@workload_jobs = dso_local constant [1 x i32 ()*] [i32 ()* @task_job_polybench], align 8, !dbg !17
@workload_expected = dso_local constant [1 x i32] [i32 -1047435711], align 4, !dbg !30
@stderr = external global %struct._IO_FILE*, align 8
@.str.2 = private unnamed_addr constant [23 x i8] c"==BEGIN DUMP_ARRAYS==\0A\00", align 1
@.str.3 = private unnamed_addr constant [15 x i8] c"begin dump: %s\00", align 1
@.str.4 = private unnamed_addr constant [2 x i8] c"D\00", align 1
@.str.5 = private unnamed_addr constant [2 x i8] c"\0A\00", align 1
@.str.6 = private unnamed_addr constant [8 x i8] c"%0.2lf \00", align 1
@.str.7 = private unnamed_addr constant [17 x i8] c"\0Aend   dump: %s\0A\00", align 1
@.str.8 = private unnamed_addr constant [23 x i8] c"==END   DUMP_ARRAYS==\0A\00", align 1
@pb_emit = internal global i32 1, align 4, !dbg !65
@llvm.global.annotations = appending global [1 x { i8*, i8*, i8*, i32, i8* }] [{ i8*, i8*, i8*, i32, i8* } { i8* bitcast (i32 ()* @task_job_polybench to i8*), i8* getelementptr inbounds ([12 x i8], [12 x i8]* @.str, i32 0, i32 0), i8* getelementptr inbounds ([121 x i8], [121 x i8]* @.str.1, i32 0, i32 0), i32 145, i8* null }], section "llvm.metadata"

; Function Attrs: noinline nounwind uwtable
define dso_local void @workload_prepare() #0 !dbg !75 {
  ret void, !dbg !79
}

; Function Attrs: noinline nounwind uwtable
define dso_local void @workload_reset(i32 noundef %0) #0 !dbg !80 {
  call void @llvm.dbg.value(metadata i32 %0, metadata !83, metadata !DIExpression()), !dbg !84
  call void @llvm.memset.p0i8.i64(i8* align 64 bitcast ([180 x [190 x double]]* @tmp to i8*), i8 0, i64 273600, i1 false), !dbg !85
  call void @llvm.memset.p0i8.i64(i8* align 64 bitcast ([180 x [210 x double]]* @A to i8*), i8 0, i64 302400, i1 false), !dbg !86
  call void @llvm.memset.p0i8.i64(i8* align 64 bitcast ([210 x [190 x double]]* @B to i8*), i8 0, i64 319200, i1 false), !dbg !87
  call void @llvm.memset.p0i8.i64(i8* align 64 bitcast ([190 x [220 x double]]* @C to i8*), i8 0, i64 334400, i1 false), !dbg !88
  call void @llvm.memset.p0i8.i64(i8* align 64 bitcast ([180 x [220 x double]]* @D to i8*), i8 0, i64 316800, i1 false), !dbg !89
  %2 = load i32, i32* @ni, align 4, !dbg !90
  %3 = load i32, i32* @nj, align 4, !dbg !91
  %4 = load i32, i32* @nk, align 4, !dbg !92
  %5 = load i32, i32* @nl, align 4, !dbg !93
  call void @init_array(i32 noundef %2, i32 noundef %3, i32 noundef %4, i32 noundef %5, double* noundef @alpha, double* noundef @beta, [210 x double]* noundef getelementptr inbounds ([180 x [210 x double]], [180 x [210 x double]]* @A, i64 0, i64 0), [190 x double]* noundef getelementptr inbounds ([210 x [190 x double]], [210 x [190 x double]]* @B, i64 0, i64 0), [220 x double]* noundef getelementptr inbounds ([190 x [220 x double]], [190 x [220 x double]]* @C, i64 0, i64 0), [220 x double]* noundef getelementptr inbounds ([180 x [220 x double]], [180 x [220 x double]]* @D, i64 0, i64 0)), !dbg !94
  ret void, !dbg !95
}

; Function Attrs: nofree nosync nounwind readnone speculatable willreturn
declare void @llvm.dbg.declare(metadata, metadata, metadata) #1

; Function Attrs: argmemonly nofree nounwind willreturn writeonly
declare void @llvm.memset.p0i8.i64(i8* nocapture writeonly, i8, i64, i1 immarg) #2

; Function Attrs: noinline nounwind uwtable
define internal void @init_array(i32 noundef %0, i32 noundef %1, i32 noundef %2, i32 noundef %3, double* noundef %4, double* noundef %5, [210 x double]* noundef %6, [190 x double]* noundef %7, [220 x double]* noundef %8, [220 x double]* noundef %9) #0 !dbg !96 {
  call void @llvm.dbg.value(metadata i32 %0, metadata !109, metadata !DIExpression()), !dbg !110
  call void @llvm.dbg.value(metadata i32 %1, metadata !111, metadata !DIExpression()), !dbg !110
  call void @llvm.dbg.value(metadata i32 %2, metadata !112, metadata !DIExpression()), !dbg !110
  call void @llvm.dbg.value(metadata i32 %3, metadata !113, metadata !DIExpression()), !dbg !110
  call void @llvm.dbg.value(metadata double* %4, metadata !114, metadata !DIExpression()), !dbg !110
  call void @llvm.dbg.value(metadata double* %5, metadata !115, metadata !DIExpression()), !dbg !110
  call void @llvm.dbg.value(metadata [210 x double]* %6, metadata !116, metadata !DIExpression()), !dbg !110
  call void @llvm.dbg.value(metadata [190 x double]* %7, metadata !117, metadata !DIExpression()), !dbg !110
  call void @llvm.dbg.value(metadata [220 x double]* %8, metadata !118, metadata !DIExpression()), !dbg !110
  call void @llvm.dbg.value(metadata [220 x double]* %9, metadata !119, metadata !DIExpression()), !dbg !110
  store double 1.500000e+00, double* %4, align 8, !dbg !120
  store double 1.200000e+00, double* %5, align 8, !dbg !121
  call void @llvm.dbg.value(metadata i32 0, metadata !122, metadata !DIExpression()), !dbg !110
  br label %11, !dbg !123

11:                                               ; preds = %30, %10
  %.01 = phi i32 [ 0, %10 ], [ %31, %30 ], !dbg !125
  call void @llvm.dbg.value(metadata i32 %.01, metadata !122, metadata !DIExpression()), !dbg !110
  %12 = icmp slt i32 %.01, %0, !dbg !126
  br i1 %12, label %13, label %32, !dbg !128

13:                                               ; preds = %11
  call void @llvm.dbg.value(metadata i32 0, metadata !129, metadata !DIExpression()), !dbg !110
  br label %14, !dbg !130

14:                                               ; preds = %27, %13
  %.0 = phi i32 [ 0, %13 ], [ %28, %27 ], !dbg !132
  call void @llvm.dbg.value(metadata i32 %.0, metadata !129, metadata !DIExpression()), !dbg !110
  %15 = icmp slt i32 %.0, %2, !dbg !133
  br i1 %15, label %16, label %29, !dbg !135

16:                                               ; preds = %14
  %17 = mul nsw i32 %.01, %.0, !dbg !136
  %18 = add nsw i32 %17, 1, !dbg !137
  %19 = srem i32 %18, %0, !dbg !138
  %20 = sitofp i32 %19 to double, !dbg !139
  %21 = sitofp i32 %0 to double, !dbg !140
  %22 = fdiv double %20, %21, !dbg !141
  %23 = sext i32 %.01 to i64, !dbg !142
  %24 = getelementptr inbounds [210 x double], [210 x double]* %6, i64 %23, !dbg !142
  %25 = sext i32 %.0 to i64, !dbg !142
  %26 = getelementptr inbounds [210 x double], [210 x double]* %24, i64 0, i64 %25, !dbg !142
  store double %22, double* %26, align 8, !dbg !143
  br label %27, !dbg !142

27:                                               ; preds = %16
  %28 = add nsw i32 %.0, 1, !dbg !144
  call void @llvm.dbg.value(metadata i32 %28, metadata !129, metadata !DIExpression()), !dbg !110
  br label %14, !dbg !145, !llvm.loop !146

29:                                               ; preds = %14
  br label %30, !dbg !147

30:                                               ; preds = %29
  %31 = add nsw i32 %.01, 1, !dbg !149
  call void @llvm.dbg.value(metadata i32 %31, metadata !122, metadata !DIExpression()), !dbg !110
  br label %11, !dbg !150, !llvm.loop !151

32:                                               ; preds = %11
  call void @llvm.dbg.value(metadata i32 0, metadata !122, metadata !DIExpression()), !dbg !110
  br label %33, !dbg !153

33:                                               ; preds = %52, %32
  %.12 = phi i32 [ 0, %32 ], [ %53, %52 ], !dbg !155
  call void @llvm.dbg.value(metadata i32 %.12, metadata !122, metadata !DIExpression()), !dbg !110
  %34 = icmp slt i32 %.12, %2, !dbg !156
  br i1 %34, label %35, label %54, !dbg !158

35:                                               ; preds = %33
  call void @llvm.dbg.value(metadata i32 0, metadata !129, metadata !DIExpression()), !dbg !110
  br label %36, !dbg !159

36:                                               ; preds = %49, %35
  %.1 = phi i32 [ 0, %35 ], [ %50, %49 ], !dbg !161
  call void @llvm.dbg.value(metadata i32 %.1, metadata !129, metadata !DIExpression()), !dbg !110
  %37 = icmp slt i32 %.1, %1, !dbg !162
  br i1 %37, label %38, label %51, !dbg !164

38:                                               ; preds = %36
  %39 = add nsw i32 %.1, 1, !dbg !165
  %40 = mul nsw i32 %.12, %39, !dbg !166
  %41 = srem i32 %40, %1, !dbg !167
  %42 = sitofp i32 %41 to double, !dbg !168
  %43 = sitofp i32 %1 to double, !dbg !169
  %44 = fdiv double %42, %43, !dbg !170
  %45 = sext i32 %.12 to i64, !dbg !171
  %46 = getelementptr inbounds [190 x double], [190 x double]* %7, i64 %45, !dbg !171
  %47 = sext i32 %.1 to i64, !dbg !171
  %48 = getelementptr inbounds [190 x double], [190 x double]* %46, i64 0, i64 %47, !dbg !171
  store double %44, double* %48, align 8, !dbg !172
  br label %49, !dbg !171

49:                                               ; preds = %38
  %50 = add nsw i32 %.1, 1, !dbg !173
  call void @llvm.dbg.value(metadata i32 %50, metadata !129, metadata !DIExpression()), !dbg !110
  br label %36, !dbg !174, !llvm.loop !175

51:                                               ; preds = %36
  br label %52, !dbg !176

52:                                               ; preds = %51
  %53 = add nsw i32 %.12, 1, !dbg !177
  call void @llvm.dbg.value(metadata i32 %53, metadata !122, metadata !DIExpression()), !dbg !110
  br label %33, !dbg !178, !llvm.loop !179

54:                                               ; preds = %33
  call void @llvm.dbg.value(metadata i32 0, metadata !122, metadata !DIExpression()), !dbg !110
  br label %55, !dbg !181

55:                                               ; preds = %75, %54
  %.23 = phi i32 [ 0, %54 ], [ %76, %75 ], !dbg !183
  call void @llvm.dbg.value(metadata i32 %.23, metadata !122, metadata !DIExpression()), !dbg !110
  %56 = icmp slt i32 %.23, %1, !dbg !184
  br i1 %56, label %57, label %77, !dbg !186

57:                                               ; preds = %55
  call void @llvm.dbg.value(metadata i32 0, metadata !129, metadata !DIExpression()), !dbg !110
  br label %58, !dbg !187

58:                                               ; preds = %72, %57
  %.2 = phi i32 [ 0, %57 ], [ %73, %72 ], !dbg !189
  call void @llvm.dbg.value(metadata i32 %.2, metadata !129, metadata !DIExpression()), !dbg !110
  %59 = icmp slt i32 %.2, %3, !dbg !190
  br i1 %59, label %60, label %74, !dbg !192

60:                                               ; preds = %58
  %61 = add nsw i32 %.2, 3, !dbg !193
  %62 = mul nsw i32 %.23, %61, !dbg !194
  %63 = add nsw i32 %62, 1, !dbg !195
  %64 = srem i32 %63, %3, !dbg !196
  %65 = sitofp i32 %64 to double, !dbg !197
  %66 = sitofp i32 %3 to double, !dbg !198
  %67 = fdiv double %65, %66, !dbg !199
  %68 = sext i32 %.23 to i64, !dbg !200
  %69 = getelementptr inbounds [220 x double], [220 x double]* %8, i64 %68, !dbg !200
  %70 = sext i32 %.2 to i64, !dbg !200
  %71 = getelementptr inbounds [220 x double], [220 x double]* %69, i64 0, i64 %70, !dbg !200
  store double %67, double* %71, align 8, !dbg !201
  br label %72, !dbg !200

72:                                               ; preds = %60
  %73 = add nsw i32 %.2, 1, !dbg !202
  call void @llvm.dbg.value(metadata i32 %73, metadata !129, metadata !DIExpression()), !dbg !110
  br label %58, !dbg !203, !llvm.loop !204

74:                                               ; preds = %58
  br label %75, !dbg !205

75:                                               ; preds = %74
  %76 = add nsw i32 %.23, 1, !dbg !206
  call void @llvm.dbg.value(metadata i32 %76, metadata !122, metadata !DIExpression()), !dbg !110
  br label %55, !dbg !207, !llvm.loop !208

77:                                               ; preds = %55
  call void @llvm.dbg.value(metadata i32 0, metadata !122, metadata !DIExpression()), !dbg !110
  br label %78, !dbg !210

78:                                               ; preds = %97, %77
  %.34 = phi i32 [ 0, %77 ], [ %98, %97 ], !dbg !212
  call void @llvm.dbg.value(metadata i32 %.34, metadata !122, metadata !DIExpression()), !dbg !110
  %79 = icmp slt i32 %.34, %0, !dbg !213
  br i1 %79, label %80, label %99, !dbg !215

80:                                               ; preds = %78
  call void @llvm.dbg.value(metadata i32 0, metadata !129, metadata !DIExpression()), !dbg !110
  br label %81, !dbg !216

81:                                               ; preds = %94, %80
  %.3 = phi i32 [ 0, %80 ], [ %95, %94 ], !dbg !218
  call void @llvm.dbg.value(metadata i32 %.3, metadata !129, metadata !DIExpression()), !dbg !110
  %82 = icmp slt i32 %.3, %3, !dbg !219
  br i1 %82, label %83, label %96, !dbg !221

83:                                               ; preds = %81
  %84 = add nsw i32 %.3, 2, !dbg !222
  %85 = mul nsw i32 %.34, %84, !dbg !223
  %86 = srem i32 %85, %2, !dbg !224
  %87 = sitofp i32 %86 to double, !dbg !225
  %88 = sitofp i32 %2 to double, !dbg !226
  %89 = fdiv double %87, %88, !dbg !227
  %90 = sext i32 %.34 to i64, !dbg !228
  %91 = getelementptr inbounds [220 x double], [220 x double]* %9, i64 %90, !dbg !228
  %92 = sext i32 %.3 to i64, !dbg !228
  %93 = getelementptr inbounds [220 x double], [220 x double]* %91, i64 0, i64 %92, !dbg !228
  store double %89, double* %93, align 8, !dbg !229
  br label %94, !dbg !228

94:                                               ; preds = %83
  %95 = add nsw i32 %.3, 1, !dbg !230
  call void @llvm.dbg.value(metadata i32 %95, metadata !129, metadata !DIExpression()), !dbg !110
  br label %81, !dbg !231, !llvm.loop !232

96:                                               ; preds = %81
  br label %97, !dbg !233

97:                                               ; preds = %96
  %98 = add nsw i32 %.34, 1, !dbg !234
  call void @llvm.dbg.value(metadata i32 %98, metadata !122, metadata !DIExpression()), !dbg !110
  br label %78, !dbg !235, !llvm.loop !236

99:                                               ; preds = %78
  ret void, !dbg !238
}

; Function Attrs: noinline nounwind uwtable
define dso_local i32 @task_job_polybench() #0 !dbg !239 {
  %1 = load i32, i32* @ni, align 4, !dbg !240
  %2 = load i32, i32* @nj, align 4, !dbg !241
  %3 = load i32, i32* @nk, align 4, !dbg !242
  %4 = load i32, i32* @nl, align 4, !dbg !243
  %5 = load double, double* @alpha, align 8, !dbg !244
  %6 = load double, double* @beta, align 8, !dbg !245
  call void @llvm.dbg.value(metadata i32 %1, metadata !246, metadata !DIExpression()), !dbg !250
  call void @llvm.dbg.value(metadata i32 %2, metadata !252, metadata !DIExpression()), !dbg !250
  call void @llvm.dbg.value(metadata i32 %3, metadata !253, metadata !DIExpression()), !dbg !250
  call void @llvm.dbg.value(metadata i32 %4, metadata !254, metadata !DIExpression()), !dbg !250
  call void @llvm.dbg.value(metadata double %5, metadata !255, metadata !DIExpression()), !dbg !250
  call void @llvm.dbg.value(metadata double %6, metadata !256, metadata !DIExpression()), !dbg !250
  call void @llvm.dbg.value(metadata [190 x double]* getelementptr inbounds ([180 x [190 x double]], [180 x [190 x double]]* @tmp, i64 0, i64 0), metadata !257, metadata !DIExpression()), !dbg !250
  call void @llvm.dbg.value(metadata [210 x double]* getelementptr inbounds ([180 x [210 x double]], [180 x [210 x double]]* @A, i64 0, i64 0), metadata !258, metadata !DIExpression()), !dbg !250
  call void @llvm.dbg.value(metadata [190 x double]* getelementptr inbounds ([210 x [190 x double]], [210 x [190 x double]]* @B, i64 0, i64 0), metadata !259, metadata !DIExpression()), !dbg !250
  call void @llvm.dbg.value(metadata [220 x double]* getelementptr inbounds ([190 x [220 x double]], [190 x [220 x double]]* @C, i64 0, i64 0), metadata !260, metadata !DIExpression()), !dbg !250
  call void @llvm.dbg.value(metadata [220 x double]* getelementptr inbounds ([180 x [220 x double]], [180 x [220 x double]]* @D, i64 0, i64 0), metadata !261, metadata !DIExpression()), !dbg !250
  call void @llvm.dbg.value(metadata i32 0, metadata !262, metadata !DIExpression()), !dbg !250
  br label %7, !dbg !263

7:                                                ; preds = %41, %0
  %.03 = phi i32 [ 0, %0 ], [ %42, %41 ], !dbg !265
  call void @llvm.dbg.value(metadata i32 %.03, metadata !262, metadata !DIExpression()), !dbg !250
  %8 = icmp slt i32 %.03, 180, !dbg !266
  br i1 %8, label %9, label %43, !dbg !268

9:                                                ; preds = %7
  call void @llvm.dbg.value(metadata i32 0, metadata !269, metadata !DIExpression()), !dbg !250
  br label %10, !dbg !270

10:                                               ; preds = %39, %9
  %.01 = phi i32 [ 0, %9 ], [ %40, %39 ], !dbg !272
  call void @llvm.dbg.value(metadata i32 %.01, metadata !269, metadata !DIExpression()), !dbg !250
  %11 = icmp slt i32 %.01, 190, !dbg !273
  br i1 %11, label %12, label %41, !dbg !275

12:                                               ; preds = %10
  %13 = sext i32 %.03 to i64, !dbg !276
  %14 = getelementptr inbounds [190 x double], [190 x double]* getelementptr inbounds ([180 x [190 x double]], [180 x [190 x double]]* @tmp, i64 0, i64 0), i64 %13, !dbg !276
  %15 = sext i32 %.01 to i64, !dbg !276
  %16 = getelementptr inbounds [190 x double], [190 x double]* %14, i64 0, i64 %15, !dbg !276
  store double 0.000000e+00, double* %16, align 8, !dbg !278
  call void @llvm.dbg.value(metadata i32 0, metadata !279, metadata !DIExpression()), !dbg !250
  br label %17, !dbg !280

17:                                               ; preds = %19, %12
  %.0 = phi i32 [ 0, %12 ], [ %38, %19 ], !dbg !282
  call void @llvm.dbg.value(metadata i32 %.0, metadata !279, metadata !DIExpression()), !dbg !250
  %18 = icmp slt i32 %.0, 210, !dbg !283
  br i1 %18, label %19, label %39, !dbg !285

19:                                               ; preds = %17
  %20 = sext i32 %.03 to i64, !dbg !286
  %21 = getelementptr inbounds [210 x double], [210 x double]* getelementptr inbounds ([180 x [210 x double]], [180 x [210 x double]]* @A, i64 0, i64 0), i64 %20, !dbg !286
  %22 = sext i32 %.0 to i64, !dbg !286
  %23 = getelementptr inbounds [210 x double], [210 x double]* %21, i64 0, i64 %22, !dbg !286
  %24 = load double, double* %23, align 8, !dbg !286
  %25 = fmul double %5, %24, !dbg !287
  %26 = sext i32 %.0 to i64, !dbg !288
  %27 = getelementptr inbounds [190 x double], [190 x double]* getelementptr inbounds ([210 x [190 x double]], [210 x [190 x double]]* @B, i64 0, i64 0), i64 %26, !dbg !288
  %28 = sext i32 %.01 to i64, !dbg !288
  %29 = getelementptr inbounds [190 x double], [190 x double]* %27, i64 0, i64 %28, !dbg !288
  %30 = load double, double* %29, align 8, !dbg !288
  %31 = fmul double %25, %30, !dbg !289
  %32 = sext i32 %.03 to i64, !dbg !290
  %33 = getelementptr inbounds [190 x double], [190 x double]* getelementptr inbounds ([180 x [190 x double]], [180 x [190 x double]]* @tmp, i64 0, i64 0), i64 %32, !dbg !290
  %34 = sext i32 %.01 to i64, !dbg !290
  %35 = getelementptr inbounds [190 x double], [190 x double]* %33, i64 0, i64 %34, !dbg !290
  %36 = load double, double* %35, align 8, !dbg !291
  %37 = fadd double %36, %31, !dbg !291
  store double %37, double* %35, align 8, !dbg !291
  %38 = add nsw i32 %.0, 1, !dbg !292
  call void @llvm.dbg.value(metadata i32 %38, metadata !279, metadata !DIExpression()), !dbg !250
  br label %17, !dbg !293, !llvm.loop !294

39:                                               ; preds = %17
  %40 = add nsw i32 %.01, 1, !dbg !296
  call void @llvm.dbg.value(metadata i32 %40, metadata !269, metadata !DIExpression()), !dbg !250
  br label %10, !dbg !297, !llvm.loop !298

41:                                               ; preds = %10
  %42 = add nsw i32 %.03, 1, !dbg !300
  call void @llvm.dbg.value(metadata i32 %42, metadata !262, metadata !DIExpression()), !dbg !250
  br label %7, !dbg !301, !llvm.loop !302

43:                                               ; preds = %7
  call void @llvm.dbg.value(metadata i32 0, metadata !262, metadata !DIExpression()), !dbg !250
  br label %44, !dbg !304

44:                                               ; preds = %79, %43
  %.14 = phi i32 [ 0, %43 ], [ %80, %79 ], !dbg !306
  call void @llvm.dbg.value(metadata i32 %.14, metadata !262, metadata !DIExpression()), !dbg !250
  %45 = icmp slt i32 %.14, 180, !dbg !307
  br i1 %45, label %46, label %81, !dbg !309

46:                                               ; preds = %44
  call void @llvm.dbg.value(metadata i32 0, metadata !269, metadata !DIExpression()), !dbg !250
  br label %47, !dbg !310

47:                                               ; preds = %77, %46
  %.12 = phi i32 [ 0, %46 ], [ %78, %77 ], !dbg !312
  call void @llvm.dbg.value(metadata i32 %.12, metadata !269, metadata !DIExpression()), !dbg !250
  %48 = icmp slt i32 %.12, 220, !dbg !313
  br i1 %48, label %49, label %79, !dbg !315

49:                                               ; preds = %47
  %50 = sext i32 %.14 to i64, !dbg !316
  %51 = getelementptr inbounds [220 x double], [220 x double]* getelementptr inbounds ([180 x [220 x double]], [180 x [220 x double]]* @D, i64 0, i64 0), i64 %50, !dbg !316
  %52 = sext i32 %.12 to i64, !dbg !316
  %53 = getelementptr inbounds [220 x double], [220 x double]* %51, i64 0, i64 %52, !dbg !316
  %54 = load double, double* %53, align 8, !dbg !318
  %55 = fmul double %54, %6, !dbg !318
  store double %55, double* %53, align 8, !dbg !318
  call void @llvm.dbg.value(metadata i32 0, metadata !279, metadata !DIExpression()), !dbg !250
  br label %56, !dbg !319

56:                                               ; preds = %58, %49
  %.1 = phi i32 [ 0, %49 ], [ %76, %58 ], !dbg !321
  call void @llvm.dbg.value(metadata i32 %.1, metadata !279, metadata !DIExpression()), !dbg !250
  %57 = icmp slt i32 %.1, 190, !dbg !322
  br i1 %57, label %58, label %77, !dbg !324

58:                                               ; preds = %56
  %59 = sext i32 %.14 to i64, !dbg !325
  %60 = getelementptr inbounds [190 x double], [190 x double]* getelementptr inbounds ([180 x [190 x double]], [180 x [190 x double]]* @tmp, i64 0, i64 0), i64 %59, !dbg !325
  %61 = sext i32 %.1 to i64, !dbg !325
  %62 = getelementptr inbounds [190 x double], [190 x double]* %60, i64 0, i64 %61, !dbg !325
  %63 = load double, double* %62, align 8, !dbg !325
  %64 = sext i32 %.1 to i64, !dbg !326
  %65 = getelementptr inbounds [220 x double], [220 x double]* getelementptr inbounds ([190 x [220 x double]], [190 x [220 x double]]* @C, i64 0, i64 0), i64 %64, !dbg !326
  %66 = sext i32 %.12 to i64, !dbg !326
  %67 = getelementptr inbounds [220 x double], [220 x double]* %65, i64 0, i64 %66, !dbg !326
  %68 = load double, double* %67, align 8, !dbg !326
  %69 = fmul double %63, %68, !dbg !327
  %70 = sext i32 %.14 to i64, !dbg !328
  %71 = getelementptr inbounds [220 x double], [220 x double]* getelementptr inbounds ([180 x [220 x double]], [180 x [220 x double]]* @D, i64 0, i64 0), i64 %70, !dbg !328
  %72 = sext i32 %.12 to i64, !dbg !328
  %73 = getelementptr inbounds [220 x double], [220 x double]* %71, i64 0, i64 %72, !dbg !328
  %74 = load double, double* %73, align 8, !dbg !329
  %75 = fadd double %74, %69, !dbg !329
  store double %75, double* %73, align 8, !dbg !329
  %76 = add nsw i32 %.1, 1, !dbg !330
  call void @llvm.dbg.value(metadata i32 %76, metadata !279, metadata !DIExpression()), !dbg !250
  br label %56, !dbg !331, !llvm.loop !332

77:                                               ; preds = %56
  %78 = add nsw i32 %.12, 1, !dbg !334
  call void @llvm.dbg.value(metadata i32 %78, metadata !269, metadata !DIExpression()), !dbg !250
  br label %47, !dbg !335, !llvm.loop !336

79:                                               ; preds = %47
  %80 = add nsw i32 %.14, 1, !dbg !338
  call void @llvm.dbg.value(metadata i32 %80, metadata !262, metadata !DIExpression()), !dbg !250
  br label %44, !dbg !339, !llvm.loop !340

81:                                               ; preds = %44
  ret i32 0, !dbg !342
}

; Function Attrs: noinline nounwind uwtable
define dso_local i32 @workload_checksum(i32 noundef %0) #0 !dbg !343 {
  call void @llvm.dbg.value(metadata i32 %0, metadata !346, metadata !DIExpression()), !dbg !347
  store i32 -2128831035, i32* @pb_hash, align 4, !dbg !348
  %2 = load i32, i32* @ni, align 4, !dbg !349
  %3 = load i32, i32* @nl, align 4, !dbg !350
  call void @print_array(i32 noundef %2, i32 noundef %3, [220 x double]* noundef getelementptr inbounds ([180 x [220 x double]], [180 x [220 x double]]* @D, i64 0, i64 0)), !dbg !351
  %4 = load i32, i32* @pb_hash, align 4, !dbg !352
  ret i32 %4, !dbg !353
}

; Function Attrs: noinline nounwind uwtable
define internal void @print_array(i32 noundef %0, i32 noundef %1, [220 x double]* noundef %2) #0 !dbg !354 {
  call void @llvm.dbg.value(metadata i32 %0, metadata !357, metadata !DIExpression()), !dbg !358
  call void @llvm.dbg.value(metadata i32 %1, metadata !359, metadata !DIExpression()), !dbg !358
  call void @llvm.dbg.value(metadata [220 x double]* %2, metadata !360, metadata !DIExpression()), !dbg !358
  %4 = load %struct._IO_FILE*, %struct._IO_FILE** @stderr, align 8, !dbg !361
  %5 = call i32 (%struct._IO_FILE*, i8*, ...) @pb_fprintf(%struct._IO_FILE* noundef %4, i8* noundef getelementptr inbounds ([23 x i8], [23 x i8]* @.str.2, i64 0, i64 0)), !dbg !361
  %6 = load %struct._IO_FILE*, %struct._IO_FILE** @stderr, align 8, !dbg !362
  %7 = call i32 (%struct._IO_FILE*, i8*, ...) @pb_fprintf(%struct._IO_FILE* noundef %6, i8* noundef getelementptr inbounds ([15 x i8], [15 x i8]* @.str.3, i64 0, i64 0), i8* noundef getelementptr inbounds ([2 x i8], [2 x i8]* @.str.4, i64 0, i64 0)), !dbg !362
  call void @llvm.dbg.value(metadata i32 0, metadata !363, metadata !DIExpression()), !dbg !358
  br label %8, !dbg !364

8:                                                ; preds = %32, %3
  %.01 = phi i32 [ 0, %3 ], [ %33, %32 ], !dbg !366
  call void @llvm.dbg.value(metadata i32 %.01, metadata !363, metadata !DIExpression()), !dbg !358
  %9 = icmp slt i32 %.01, %0, !dbg !367
  br i1 %9, label %10, label %34, !dbg !369

10:                                               ; preds = %8
  call void @llvm.dbg.value(metadata i32 0, metadata !370, metadata !DIExpression()), !dbg !358
  br label %11, !dbg !371

11:                                               ; preds = %29, %10
  %.0 = phi i32 [ 0, %10 ], [ %30, %29 ], !dbg !373
  call void @llvm.dbg.value(metadata i32 %.0, metadata !370, metadata !DIExpression()), !dbg !358
  %12 = icmp slt i32 %.0, %1, !dbg !374
  br i1 %12, label %13, label %31, !dbg !376

13:                                               ; preds = %11
  %14 = mul nsw i32 %.01, %0, !dbg !377
  %15 = add nsw i32 %14, %.0, !dbg !380
  %16 = srem i32 %15, 20, !dbg !381
  %17 = icmp eq i32 %16, 0, !dbg !382
  br i1 %17, label %18, label %21, !dbg !383

18:                                               ; preds = %13
  %19 = load %struct._IO_FILE*, %struct._IO_FILE** @stderr, align 8, !dbg !384
  %20 = call i32 (%struct._IO_FILE*, i8*, ...) @pb_fprintf(%struct._IO_FILE* noundef %19, i8* noundef getelementptr inbounds ([2 x i8], [2 x i8]* @.str.5, i64 0, i64 0)), !dbg !385
  br label %21, !dbg !385

21:                                               ; preds = %18, %13
  %22 = load %struct._IO_FILE*, %struct._IO_FILE** @stderr, align 8, !dbg !386
  %23 = sext i32 %.01 to i64, !dbg !387
  %24 = getelementptr inbounds [220 x double], [220 x double]* %2, i64 %23, !dbg !387
  %25 = sext i32 %.0 to i64, !dbg !387
  %26 = getelementptr inbounds [220 x double], [220 x double]* %24, i64 0, i64 %25, !dbg !387
  %27 = load double, double* %26, align 8, !dbg !387
  %28 = call i32 (%struct._IO_FILE*, i8*, ...) @pb_fprintf(%struct._IO_FILE* noundef %22, i8* noundef getelementptr inbounds ([8 x i8], [8 x i8]* @.str.6, i64 0, i64 0), double noundef %27), !dbg !388
  br label %29, !dbg !389

29:                                               ; preds = %21
  %30 = add nsw i32 %.0, 1, !dbg !390
  call void @llvm.dbg.value(metadata i32 %30, metadata !370, metadata !DIExpression()), !dbg !358
  br label %11, !dbg !391, !llvm.loop !392

31:                                               ; preds = %11
  br label %32, !dbg !393

32:                                               ; preds = %31
  %33 = add nsw i32 %.01, 1, !dbg !394
  call void @llvm.dbg.value(metadata i32 %33, metadata !363, metadata !DIExpression()), !dbg !358
  br label %8, !dbg !395, !llvm.loop !396

34:                                               ; preds = %8
  %35 = load %struct._IO_FILE*, %struct._IO_FILE** @stderr, align 8, !dbg !398
  %36 = call i32 (%struct._IO_FILE*, i8*, ...) @pb_fprintf(%struct._IO_FILE* noundef %35, i8* noundef getelementptr inbounds ([17 x i8], [17 x i8]* @.str.7, i64 0, i64 0), i8* noundef getelementptr inbounds ([2 x i8], [2 x i8]* @.str.4, i64 0, i64 0)), !dbg !398
  %37 = load %struct._IO_FILE*, %struct._IO_FILE** @stderr, align 8, !dbg !399
  %38 = call i32 (%struct._IO_FILE*, i8*, ...) @pb_fprintf(%struct._IO_FILE* noundef %37, i8* noundef getelementptr inbounds ([23 x i8], [23 x i8]* @.str.8, i64 0, i64 0)), !dbg !399
  ret void, !dbg !400
}

; Function Attrs: noinline nounwind uwtable
define internal i32 @pb_fprintf(%struct._IO_FILE* noundef %0, i8* noundef %1, ...) #0 !dbg !401 {
  %3 = alloca [768 x i8], align 16
  %4 = alloca [1 x %struct.__va_list_tag], align 16
  call void @llvm.dbg.value(metadata %struct._IO_FILE* %0, metadata !465, metadata !DIExpression()), !dbg !466
  call void @llvm.dbg.value(metadata i8* %1, metadata !467, metadata !DIExpression()), !dbg !466
  call void @llvm.dbg.declare(metadata [768 x i8]* %3, metadata !468, metadata !DIExpression()), !dbg !472
  call void @llvm.dbg.declare(metadata [1 x %struct.__va_list_tag]* %4, metadata !473, metadata !DIExpression()), !dbg !487
  %5 = getelementptr inbounds [1 x %struct.__va_list_tag], [1 x %struct.__va_list_tag]* %4, i64 0, i64 0, !dbg !488
  %6 = bitcast %struct.__va_list_tag* %5 to i8*, !dbg !488
  call void @llvm.va_start(i8* %6), !dbg !488
  %7 = getelementptr inbounds [768 x i8], [768 x i8]* %3, i64 0, i64 0, !dbg !489
  %8 = getelementptr inbounds [1 x %struct.__va_list_tag], [1 x %struct.__va_list_tag]* %4, i64 0, i64 0, !dbg !490
  %9 = call i32 @vsnprintf(i8* noundef %7, i64 noundef 768, i8* noundef %1, %struct.__va_list_tag* noundef %8) #6, !dbg !491
  call void @llvm.dbg.value(metadata i32 %9, metadata !492, metadata !DIExpression()), !dbg !466
  %10 = getelementptr inbounds [1 x %struct.__va_list_tag], [1 x %struct.__va_list_tag]* %4, i64 0, i64 0, !dbg !493
  %11 = bitcast %struct.__va_list_tag* %10 to i8*, !dbg !493
  call void @llvm.va_end(i8* %11), !dbg !493
  %12 = icmp slt i32 %9, 0, !dbg !494
  br i1 %12, label %16, label %13, !dbg !496

13:                                               ; preds = %2
  %14 = zext i32 %9 to i64, !dbg !497
  %15 = icmp uge i64 %14, 768, !dbg !498
  br i1 %15, label %16, label %17, !dbg !499

16:                                               ; preds = %13, %2
  call void @abort() #7, !dbg !500
  unreachable, !dbg !500

17:                                               ; preds = %13
  call void @llvm.dbg.value(metadata i32 0, metadata !501, metadata !DIExpression()), !dbg !503
  br label %18, !dbg !504

18:                                               ; preds = %29, %17
  %.0 = phi i32 [ 0, %17 ], [ %30, %29 ], !dbg !503
  call void @llvm.dbg.value(metadata i32 %.0, metadata !501, metadata !DIExpression()), !dbg !503
  %19 = icmp slt i32 %.0, %9, !dbg !505
  br i1 %19, label %20, label %31, !dbg !507

20:                                               ; preds = %18
  %21 = sext i32 %.0 to i64, !dbg !508
  %22 = getelementptr inbounds [768 x i8], [768 x i8]* %3, i64 0, i64 %21, !dbg !508
  %23 = load i8, i8* %22, align 1, !dbg !508
  %24 = zext i8 %23 to i32, !dbg !510
  %25 = load i32, i32* @pb_hash, align 4, !dbg !511
  %26 = xor i32 %25, %24, !dbg !511
  store i32 %26, i32* @pb_hash, align 4, !dbg !511
  %27 = load i32, i32* @pb_hash, align 4, !dbg !512
  %28 = mul i32 %27, 16777619, !dbg !512
  store i32 %28, i32* @pb_hash, align 4, !dbg !512
  br label %29, !dbg !513

29:                                               ; preds = %20
  %30 = add nsw i32 %.0, 1, !dbg !514
  call void @llvm.dbg.value(metadata i32 %30, metadata !501, metadata !DIExpression()), !dbg !503
  br label %18, !dbg !515, !llvm.loop !516

31:                                               ; preds = %18
  %32 = load i32, i32* @pb_emit, align 4, !dbg !518
  ret i32 %9, !dbg !519
}

; Function Attrs: nofree nosync nounwind willreturn
declare void @llvm.va_start(i8*) #3

; Function Attrs: nounwind
declare i32 @vsnprintf(i8* noundef, i64 noundef, i8* noundef, %struct.__va_list_tag* noundef) #4

; Function Attrs: nofree nosync nounwind willreturn
declare void @llvm.va_end(i8*) #3

; Function Attrs: noreturn nounwind
declare void @abort() #5

; Function Attrs: nofree nosync nounwind readnone speculatable willreturn
declare void @llvm.dbg.value(metadata, metadata, metadata) #1

attributes #0 = { noinline nounwind uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { nofree nosync nounwind readnone speculatable willreturn }
attributes #2 = { argmemonly nofree nounwind willreturn writeonly }
attributes #3 = { nofree nosync nounwind willreturn }
attributes #4 = { nounwind "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #5 = { noreturn nounwind "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #6 = { nounwind }
attributes #7 = { noreturn nounwind }

!llvm.dbg.cu = !{!2}
!llvm.module.flags = !{!67, !68, !69, !70, !71, !72, !73}
!llvm.ident = !{!74}

!0 = !DIGlobalVariableExpression(var: !1, expr: !DIExpression())
!1 = distinct !DIGlobalVariable(name: "ni", scope: !2, file: !11, line: 123, type: !12, isLocal: false, isDefinition: true)
!2 = distinct !DICompileUnit(language: DW_LANG_C99, file: !3, producer: "Ubuntu clang version 14.0.0-1ubuntu1.1", isOptimized: false, runtimeVersion: 0, emissionKind: FullDebug, retainedTypes: !4, globals: !8, splitDebugInlining: false, nameTableKind: None)
!3 = !DIFile(filename: "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/affine-bounds-20260929/suite/2mm/source/workload.c", directory: "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/affine-bounds-20260929/suite/2mm/analysis-c", checksumkind: CSK_MD5, checksum: "e544d40efc1ddcb6170e871573d47620")
!4 = !{!5, !6, !7}
!5 = !DIBasicType(name: "double", size: 64, encoding: DW_ATE_float)
!6 = !DIBasicType(name: "unsigned int", size: 32, encoding: DW_ATE_unsigned)
!7 = !DIBasicType(name: "unsigned char", size: 8, encoding: DW_ATE_unsigned_char)
!8 = !{!0, !9, !13, !15, !17, !30, !34, !37, !43, !48, !52, !57, !61, !63, !65}
!9 = !DIGlobalVariableExpression(var: !10, expr: !DIExpression())
!10 = distinct !DIGlobalVariable(name: "nj", scope: !2, file: !11, line: 124, type: !12, isLocal: false, isDefinition: true)
!11 = !DIFile(filename: "source/workload.c", directory: "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/affine-bounds-20260929/suite/2mm", checksumkind: CSK_MD5, checksum: "e544d40efc1ddcb6170e871573d47620")
!12 = !DIBasicType(name: "int", size: 32, encoding: DW_ATE_signed)
!13 = !DIGlobalVariableExpression(var: !14, expr: !DIExpression())
!14 = distinct !DIGlobalVariable(name: "nk", scope: !2, file: !11, line: 125, type: !12, isLocal: false, isDefinition: true)
!15 = !DIGlobalVariableExpression(var: !16, expr: !DIExpression())
!16 = distinct !DIGlobalVariable(name: "nl", scope: !2, file: !11, line: 126, type: !12, isLocal: false, isDefinition: true)
!17 = !DIGlobalVariableExpression(var: !18, expr: !DIExpression())
!18 = distinct !DIGlobalVariable(name: "workload_jobs", scope: !2, file: !11, line: 161, type: !19, isLocal: false, isDefinition: true)
!19 = !DICompositeType(tag: DW_TAG_array_type, baseType: !20, size: 64, elements: !28)
!20 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !21)
!21 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !22, size: 64)
!22 = !DISubroutineType(types: !23)
!23 = !{!24}
!24 = !DIDerivedType(tag: DW_TAG_typedef, name: "uint32_t", file: !25, line: 26, baseType: !26)
!25 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/stdint-uintn.h", directory: "", checksumkind: CSK_MD5, checksum: "2bf2ae53c58c01b1a1b9383b5195125c")
!26 = !DIDerivedType(tag: DW_TAG_typedef, name: "__uint32_t", file: !27, line: 42, baseType: !6)
!27 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/types.h", directory: "", checksumkind: CSK_MD5, checksum: "d108b5f93a74c50510d7d9bc0ab36df9")
!28 = !{!29}
!29 = !DISubrange(count: 1)
!30 = !DIGlobalVariableExpression(var: !31, expr: !DIExpression())
!31 = distinct !DIGlobalVariable(name: "workload_expected", scope: !2, file: !11, line: 165, type: !32, isLocal: false, isDefinition: true)
!32 = !DICompositeType(tag: DW_TAG_array_type, baseType: !33, size: 32, elements: !28)
!33 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !24)
!34 = !DIGlobalVariableExpression(var: !35, expr: !DIExpression())
!35 = distinct !DIGlobalVariable(name: "pb_hash", scope: !2, file: !36, line: 9, type: !24, isLocal: true, isDefinition: true)
!36 = !DIFile(filename: "source/adapter.h", directory: "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/affine-bounds-20260929/suite/2mm", checksumkind: CSK_MD5, checksum: "26a6068928b2092758f244a9d00163d7")
!37 = !DIGlobalVariableExpression(var: !38, expr: !DIExpression())
!38 = distinct !DIGlobalVariable(name: "tmp", scope: !2, file: !11, line: 34, type: !39, isLocal: false, isDefinition: true, align: 512)
!39 = !DICompositeType(tag: DW_TAG_array_type, baseType: !5, size: 2188800, elements: !40)
!40 = !{!41, !42}
!41 = !DISubrange(count: 180)
!42 = !DISubrange(count: 190)
!43 = !DIGlobalVariableExpression(var: !44, expr: !DIExpression())
!44 = distinct !DIGlobalVariable(name: "A", scope: !2, file: !11, line: 35, type: !45, isLocal: false, isDefinition: true, align: 512)
!45 = !DICompositeType(tag: DW_TAG_array_type, baseType: !5, size: 2419200, elements: !46)
!46 = !{!41, !47}
!47 = !DISubrange(count: 210)
!48 = !DIGlobalVariableExpression(var: !49, expr: !DIExpression())
!49 = distinct !DIGlobalVariable(name: "B", scope: !2, file: !11, line: 36, type: !50, isLocal: false, isDefinition: true, align: 512)
!50 = !DICompositeType(tag: DW_TAG_array_type, baseType: !5, size: 2553600, elements: !51)
!51 = !{!47, !42}
!52 = !DIGlobalVariableExpression(var: !53, expr: !DIExpression())
!53 = distinct !DIGlobalVariable(name: "C", scope: !2, file: !11, line: 37, type: !54, isLocal: false, isDefinition: true, align: 512)
!54 = !DICompositeType(tag: DW_TAG_array_type, baseType: !5, size: 2675200, elements: !55)
!55 = !{!42, !56}
!56 = !DISubrange(count: 220)
!57 = !DIGlobalVariableExpression(var: !58, expr: !DIExpression())
!58 = distinct !DIGlobalVariable(name: "D", scope: !2, file: !11, line: 38, type: !59, isLocal: false, isDefinition: true, align: 512)
!59 = !DICompositeType(tag: DW_TAG_array_type, baseType: !5, size: 2534400, elements: !60)
!60 = !{!41, !56}
!61 = !DIGlobalVariableExpression(var: !62, expr: !DIExpression())
!62 = distinct !DIGlobalVariable(name: "alpha", scope: !2, file: !11, line: 129, type: !5, isLocal: false, isDefinition: true)
!63 = !DIGlobalVariableExpression(var: !64, expr: !DIExpression())
!64 = distinct !DIGlobalVariable(name: "beta", scope: !2, file: !11, line: 130, type: !5, isLocal: false, isDefinition: true)
!65 = !DIGlobalVariableExpression(var: !66, expr: !DIExpression())
!66 = distinct !DIGlobalVariable(name: "pb_emit", scope: !2, file: !36, line: 10, type: !12, isLocal: true, isDefinition: true)
!67 = !{i32 7, !"Dwarf Version", i32 5}
!68 = !{i32 2, !"Debug Info Version", i32 3}
!69 = !{i32 1, !"wchar_size", i32 4}
!70 = !{i32 7, !"PIC Level", i32 2}
!71 = !{i32 7, !"PIE Level", i32 2}
!72 = !{i32 7, !"uwtable", i32 1}
!73 = !{i32 7, !"frame-pointer", i32 2}
!74 = !{!"Ubuntu clang version 14.0.0-1ubuntu1.1"}
!75 = distinct !DISubprogram(name: "workload_prepare", scope: !11, file: !11, line: 131, type: !76, scopeLine: 131, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !2, retainedNodes: !78)
!76 = !DISubroutineType(types: !77)
!77 = !{null}
!78 = !{}
!79 = !DILocation(line: 131, column: 30, scope: !75)
!80 = distinct !DISubprogram(name: "workload_reset", scope: !11, file: !11, line: 132, type: !81, scopeLine: 132, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !2, retainedNodes: !78)
!81 = !DISubroutineType(types: !82)
!82 = !{null, !6}
!83 = !DILocalVariable(name: "task", arg: 1, scope: !80, file: !11, line: 132, type: !6)
!84 = !DILocation(line: 0, scope: !80)
!85 = !DILocation(line: 134, column: 3, scope: !80)
!86 = !DILocation(line: 135, column: 3, scope: !80)
!87 = !DILocation(line: 136, column: 3, scope: !80)
!88 = !DILocation(line: 137, column: 3, scope: !80)
!89 = !DILocation(line: 138, column: 3, scope: !80)
!90 = !DILocation(line: 139, column: 15, scope: !80)
!91 = !DILocation(line: 139, column: 19, scope: !80)
!92 = !DILocation(line: 139, column: 23, scope: !80)
!93 = !DILocation(line: 139, column: 27, scope: !80)
!94 = !DILocation(line: 139, column: 3, scope: !80)
!95 = !DILocation(line: 144, column: 1, scope: !80)
!96 = distinct !DISubprogram(name: "init_array", scope: !11, file: !11, line: 40, type: !97, scopeLine: 47, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition, unit: !2, retainedNodes: !78)
!97 = !DISubroutineType(types: !98)
!98 = !{null, !12, !12, !12, !12, !99, !99, !100, !103, !106, !106}
!99 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !5, size: 64)
!100 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !101, size: 64)
!101 = !DICompositeType(tag: DW_TAG_array_type, baseType: !5, size: 13440, elements: !102)
!102 = !{!47}
!103 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !104, size: 64)
!104 = !DICompositeType(tag: DW_TAG_array_type, baseType: !5, size: 12160, elements: !105)
!105 = !{!42}
!106 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !107, size: 64)
!107 = !DICompositeType(tag: DW_TAG_array_type, baseType: !5, size: 14080, elements: !108)
!108 = !{!56}
!109 = !DILocalVariable(name: "ni", arg: 1, scope: !96, file: !11, line: 40, type: !12)
!110 = !DILocation(line: 0, scope: !96)
!111 = !DILocalVariable(name: "nj", arg: 2, scope: !96, file: !11, line: 40, type: !12)
!112 = !DILocalVariable(name: "nk", arg: 3, scope: !96, file: !11, line: 40, type: !12)
!113 = !DILocalVariable(name: "nl", arg: 4, scope: !96, file: !11, line: 40, type: !12)
!114 = !DILocalVariable(name: "alpha", arg: 5, scope: !96, file: !11, line: 41, type: !99)
!115 = !DILocalVariable(name: "beta", arg: 6, scope: !96, file: !11, line: 42, type: !99)
!116 = !DILocalVariable(name: "A", arg: 7, scope: !96, file: !11, line: 43, type: !100)
!117 = !DILocalVariable(name: "B", arg: 8, scope: !96, file: !11, line: 44, type: !103)
!118 = !DILocalVariable(name: "C", arg: 9, scope: !96, file: !11, line: 45, type: !106)
!119 = !DILocalVariable(name: "D", arg: 10, scope: !96, file: !11, line: 46, type: !106)
!120 = !DILocation(line: 50, column: 10, scope: !96)
!121 = !DILocation(line: 51, column: 9, scope: !96)
!122 = !DILocalVariable(name: "i", scope: !96, file: !11, line: 48, type: !12)
!123 = !DILocation(line: 52, column: 8, scope: !124)
!124 = distinct !DILexicalBlock(scope: !96, file: !11, line: 52, column: 3)
!125 = !DILocation(line: 0, scope: !124)
!126 = !DILocation(line: 52, column: 17, scope: !127)
!127 = distinct !DILexicalBlock(scope: !124, file: !11, line: 52, column: 3)
!128 = !DILocation(line: 52, column: 3, scope: !124)
!129 = !DILocalVariable(name: "j", scope: !96, file: !11, line: 48, type: !12)
!130 = !DILocation(line: 53, column: 10, scope: !131)
!131 = distinct !DILexicalBlock(scope: !127, file: !11, line: 53, column: 5)
!132 = !DILocation(line: 0, scope: !131)
!133 = !DILocation(line: 53, column: 19, scope: !134)
!134 = distinct !DILexicalBlock(scope: !131, file: !11, line: 53, column: 5)
!135 = !DILocation(line: 53, column: 5, scope: !131)
!136 = !DILocation(line: 54, column: 32, scope: !134)
!137 = !DILocation(line: 54, column: 34, scope: !134)
!138 = !DILocation(line: 54, column: 38, scope: !134)
!139 = !DILocation(line: 54, column: 17, scope: !134)
!140 = !DILocation(line: 54, column: 46, scope: !134)
!141 = !DILocation(line: 54, column: 44, scope: !134)
!142 = !DILocation(line: 54, column: 7, scope: !134)
!143 = !DILocation(line: 54, column: 15, scope: !134)
!144 = !DILocation(line: 53, column: 26, scope: !134)
!145 = !DILocation(line: 53, column: 5, scope: !134)
!146 = distinct !{!146, !135, !147, !148}
!147 = !DILocation(line: 54, column: 46, scope: !131)
!148 = !{!"llvm.loop.mustprogress"}
!149 = !DILocation(line: 52, column: 24, scope: !127)
!150 = !DILocation(line: 52, column: 3, scope: !127)
!151 = distinct !{!151, !128, !152, !148}
!152 = !DILocation(line: 54, column: 46, scope: !124)
!153 = !DILocation(line: 55, column: 8, scope: !154)
!154 = distinct !DILexicalBlock(scope: !96, file: !11, line: 55, column: 3)
!155 = !DILocation(line: 0, scope: !154)
!156 = !DILocation(line: 55, column: 17, scope: !157)
!157 = distinct !DILexicalBlock(scope: !154, file: !11, line: 55, column: 3)
!158 = !DILocation(line: 55, column: 3, scope: !154)
!159 = !DILocation(line: 56, column: 10, scope: !160)
!160 = distinct !DILexicalBlock(scope: !157, file: !11, line: 56, column: 5)
!161 = !DILocation(line: 0, scope: !160)
!162 = !DILocation(line: 56, column: 19, scope: !163)
!163 = distinct !DILexicalBlock(scope: !160, file: !11, line: 56, column: 5)
!164 = !DILocation(line: 56, column: 5, scope: !160)
!165 = !DILocation(line: 57, column: 34, scope: !163)
!166 = !DILocation(line: 57, column: 31, scope: !163)
!167 = !DILocation(line: 57, column: 38, scope: !163)
!168 = !DILocation(line: 57, column: 17, scope: !163)
!169 = !DILocation(line: 57, column: 46, scope: !163)
!170 = !DILocation(line: 57, column: 44, scope: !163)
!171 = !DILocation(line: 57, column: 7, scope: !163)
!172 = !DILocation(line: 57, column: 15, scope: !163)
!173 = !DILocation(line: 56, column: 26, scope: !163)
!174 = !DILocation(line: 56, column: 5, scope: !163)
!175 = distinct !{!175, !164, !176, !148}
!176 = !DILocation(line: 57, column: 46, scope: !160)
!177 = !DILocation(line: 55, column: 24, scope: !157)
!178 = !DILocation(line: 55, column: 3, scope: !157)
!179 = distinct !{!179, !158, !180, !148}
!180 = !DILocation(line: 57, column: 46, scope: !154)
!181 = !DILocation(line: 58, column: 8, scope: !182)
!182 = distinct !DILexicalBlock(scope: !96, file: !11, line: 58, column: 3)
!183 = !DILocation(line: 0, scope: !182)
!184 = !DILocation(line: 58, column: 17, scope: !185)
!185 = distinct !DILexicalBlock(scope: !182, file: !11, line: 58, column: 3)
!186 = !DILocation(line: 58, column: 3, scope: !182)
!187 = !DILocation(line: 59, column: 10, scope: !188)
!188 = distinct !DILexicalBlock(scope: !185, file: !11, line: 59, column: 5)
!189 = !DILocation(line: 0, scope: !188)
!190 = !DILocation(line: 59, column: 19, scope: !191)
!191 = distinct !DILexicalBlock(scope: !188, file: !11, line: 59, column: 5)
!192 = !DILocation(line: 59, column: 5, scope: !188)
!193 = !DILocation(line: 60, column: 35, scope: !191)
!194 = !DILocation(line: 60, column: 32, scope: !191)
!195 = !DILocation(line: 60, column: 38, scope: !191)
!196 = !DILocation(line: 60, column: 42, scope: !191)
!197 = !DILocation(line: 60, column: 17, scope: !191)
!198 = !DILocation(line: 60, column: 50, scope: !191)
!199 = !DILocation(line: 60, column: 48, scope: !191)
!200 = !DILocation(line: 60, column: 7, scope: !191)
!201 = !DILocation(line: 60, column: 15, scope: !191)
!202 = !DILocation(line: 59, column: 26, scope: !191)
!203 = !DILocation(line: 59, column: 5, scope: !191)
!204 = distinct !{!204, !192, !205, !148}
!205 = !DILocation(line: 60, column: 50, scope: !188)
!206 = !DILocation(line: 58, column: 24, scope: !185)
!207 = !DILocation(line: 58, column: 3, scope: !185)
!208 = distinct !{!208, !186, !209, !148}
!209 = !DILocation(line: 60, column: 50, scope: !182)
!210 = !DILocation(line: 61, column: 8, scope: !211)
!211 = distinct !DILexicalBlock(scope: !96, file: !11, line: 61, column: 3)
!212 = !DILocation(line: 0, scope: !211)
!213 = !DILocation(line: 61, column: 17, scope: !214)
!214 = distinct !DILexicalBlock(scope: !211, file: !11, line: 61, column: 3)
!215 = !DILocation(line: 61, column: 3, scope: !211)
!216 = !DILocation(line: 62, column: 10, scope: !217)
!217 = distinct !DILexicalBlock(scope: !214, file: !11, line: 62, column: 5)
!218 = !DILocation(line: 0, scope: !217)
!219 = !DILocation(line: 62, column: 19, scope: !220)
!220 = distinct !DILexicalBlock(scope: !217, file: !11, line: 62, column: 5)
!221 = !DILocation(line: 62, column: 5, scope: !217)
!222 = !DILocation(line: 63, column: 34, scope: !220)
!223 = !DILocation(line: 63, column: 31, scope: !220)
!224 = !DILocation(line: 63, column: 38, scope: !220)
!225 = !DILocation(line: 63, column: 17, scope: !220)
!226 = !DILocation(line: 63, column: 46, scope: !220)
!227 = !DILocation(line: 63, column: 44, scope: !220)
!228 = !DILocation(line: 63, column: 7, scope: !220)
!229 = !DILocation(line: 63, column: 15, scope: !220)
!230 = !DILocation(line: 62, column: 26, scope: !220)
!231 = !DILocation(line: 62, column: 5, scope: !220)
!232 = distinct !{!232, !221, !233, !148}
!233 = !DILocation(line: 63, column: 46, scope: !217)
!234 = !DILocation(line: 61, column: 24, scope: !214)
!235 = !DILocation(line: 61, column: 3, scope: !214)
!236 = distinct !{!236, !215, !237, !148}
!237 = !DILocation(line: 63, column: 46, scope: !211)
!238 = !DILocation(line: 64, column: 1, scope: !96)
!239 = distinct !DISubprogram(name: "task_job_polybench", scope: !11, file: !11, line: 145, type: !22, scopeLine: 145, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !2, retainedNodes: !78)
!240 = !DILocation(line: 146, column: 15, scope: !239)
!241 = !DILocation(line: 146, column: 19, scope: !239)
!242 = !DILocation(line: 146, column: 23, scope: !239)
!243 = !DILocation(line: 146, column: 27, scope: !239)
!244 = !DILocation(line: 147, column: 8, scope: !239)
!245 = !DILocation(line: 147, column: 15, scope: !239)
!246 = !DILocalVariable(name: "ni", arg: 1, scope: !247, file: !11, line: 90, type: !12)
!247 = distinct !DISubprogram(name: "kernel_2mm", scope: !11, file: !11, line: 90, type: !248, scopeLine: 98, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition, unit: !2, retainedNodes: !78)
!248 = !DISubroutineType(types: !249)
!249 = !{null, !12, !12, !12, !12, !5, !5, !103, !100, !103, !106, !106}
!250 = !DILocation(line: 0, scope: !247, inlinedAt: !251)
!251 = distinct !DILocation(line: 146, column: 3, scope: !239)
!252 = !DILocalVariable(name: "nj", arg: 2, scope: !247, file: !11, line: 90, type: !12)
!253 = !DILocalVariable(name: "nk", arg: 3, scope: !247, file: !11, line: 90, type: !12)
!254 = !DILocalVariable(name: "nl", arg: 4, scope: !247, file: !11, line: 90, type: !12)
!255 = !DILocalVariable(name: "alpha", arg: 5, scope: !247, file: !11, line: 91, type: !5)
!256 = !DILocalVariable(name: "beta", arg: 6, scope: !247, file: !11, line: 92, type: !5)
!257 = !DILocalVariable(name: "tmp", arg: 7, scope: !247, file: !11, line: 93, type: !103)
!258 = !DILocalVariable(name: "A", arg: 8, scope: !247, file: !11, line: 94, type: !100)
!259 = !DILocalVariable(name: "B", arg: 9, scope: !247, file: !11, line: 95, type: !103)
!260 = !DILocalVariable(name: "C", arg: 10, scope: !247, file: !11, line: 96, type: !106)
!261 = !DILocalVariable(name: "D", arg: 11, scope: !247, file: !11, line: 97, type: !106)
!262 = !DILocalVariable(name: "i", scope: !247, file: !11, line: 99, type: !12)
!263 = !DILocation(line: 103, column: 8, scope: !264, inlinedAt: !251)
!264 = distinct !DILexicalBlock(scope: !247, file: !11, line: 103, column: 3)
!265 = !DILocation(line: 0, scope: !264, inlinedAt: !251)
!266 = !DILocation(line: 103, column: 17, scope: !267, inlinedAt: !251)
!267 = distinct !DILexicalBlock(scope: !264, file: !11, line: 103, column: 3)
!268 = !DILocation(line: 103, column: 3, scope: !264, inlinedAt: !251)
!269 = !DILocalVariable(name: "j", scope: !247, file: !11, line: 99, type: !12)
!270 = !DILocation(line: 104, column: 10, scope: !271, inlinedAt: !251)
!271 = distinct !DILexicalBlock(scope: !267, file: !11, line: 104, column: 5)
!272 = !DILocation(line: 0, scope: !271, inlinedAt: !251)
!273 = !DILocation(line: 104, column: 19, scope: !274, inlinedAt: !251)
!274 = distinct !DILexicalBlock(scope: !271, file: !11, line: 104, column: 5)
!275 = !DILocation(line: 104, column: 5, scope: !271, inlinedAt: !251)
!276 = !DILocation(line: 106, column: 2, scope: !277, inlinedAt: !251)
!277 = distinct !DILexicalBlock(scope: !274, file: !11, line: 105, column: 7)
!278 = !DILocation(line: 106, column: 12, scope: !277, inlinedAt: !251)
!279 = !DILocalVariable(name: "k", scope: !247, file: !11, line: 99, type: !12)
!280 = !DILocation(line: 107, column: 7, scope: !281, inlinedAt: !251)
!281 = distinct !DILexicalBlock(scope: !277, file: !11, line: 107, column: 2)
!282 = !DILocation(line: 0, scope: !281, inlinedAt: !251)
!283 = !DILocation(line: 107, column: 16, scope: !284, inlinedAt: !251)
!284 = distinct !DILexicalBlock(scope: !281, file: !11, line: 107, column: 2)
!285 = !DILocation(line: 107, column: 2, scope: !281, inlinedAt: !251)
!286 = !DILocation(line: 108, column: 25, scope: !284, inlinedAt: !251)
!287 = !DILocation(line: 108, column: 23, scope: !284, inlinedAt: !251)
!288 = !DILocation(line: 108, column: 35, scope: !284, inlinedAt: !251)
!289 = !DILocation(line: 108, column: 33, scope: !284, inlinedAt: !251)
!290 = !DILocation(line: 108, column: 4, scope: !284, inlinedAt: !251)
!291 = !DILocation(line: 108, column: 14, scope: !284, inlinedAt: !251)
!292 = !DILocation(line: 107, column: 26, scope: !284, inlinedAt: !251)
!293 = !DILocation(line: 107, column: 2, scope: !284, inlinedAt: !251)
!294 = distinct !{!294, !285, !295, !148}
!295 = !DILocation(line: 108, column: 41, scope: !281, inlinedAt: !251)
!296 = !DILocation(line: 104, column: 30, scope: !274, inlinedAt: !251)
!297 = !DILocation(line: 104, column: 5, scope: !274, inlinedAt: !251)
!298 = distinct !{!298, !275, !299, !148}
!299 = !DILocation(line: 109, column: 7, scope: !271, inlinedAt: !251)
!300 = !DILocation(line: 103, column: 28, scope: !267, inlinedAt: !251)
!301 = !DILocation(line: 103, column: 3, scope: !267, inlinedAt: !251)
!302 = distinct !{!302, !268, !303, !148}
!303 = !DILocation(line: 109, column: 7, scope: !264, inlinedAt: !251)
!304 = !DILocation(line: 110, column: 8, scope: !305, inlinedAt: !251)
!305 = distinct !DILexicalBlock(scope: !247, file: !11, line: 110, column: 3)
!306 = !DILocation(line: 0, scope: !305, inlinedAt: !251)
!307 = !DILocation(line: 110, column: 17, scope: !308, inlinedAt: !251)
!308 = distinct !DILexicalBlock(scope: !305, file: !11, line: 110, column: 3)
!309 = !DILocation(line: 110, column: 3, scope: !305, inlinedAt: !251)
!310 = !DILocation(line: 111, column: 10, scope: !311, inlinedAt: !251)
!311 = distinct !DILexicalBlock(scope: !308, file: !11, line: 111, column: 5)
!312 = !DILocation(line: 0, scope: !311, inlinedAt: !251)
!313 = !DILocation(line: 111, column: 19, scope: !314, inlinedAt: !251)
!314 = distinct !DILexicalBlock(scope: !311, file: !11, line: 111, column: 5)
!315 = !DILocation(line: 111, column: 5, scope: !311, inlinedAt: !251)
!316 = !DILocation(line: 113, column: 2, scope: !317, inlinedAt: !251)
!317 = distinct !DILexicalBlock(scope: !314, file: !11, line: 112, column: 7)
!318 = !DILocation(line: 113, column: 10, scope: !317, inlinedAt: !251)
!319 = !DILocation(line: 114, column: 7, scope: !320, inlinedAt: !251)
!320 = distinct !DILexicalBlock(scope: !317, file: !11, line: 114, column: 2)
!321 = !DILocation(line: 0, scope: !320, inlinedAt: !251)
!322 = !DILocation(line: 114, column: 16, scope: !323, inlinedAt: !251)
!323 = distinct !DILexicalBlock(scope: !320, file: !11, line: 114, column: 2)
!324 = !DILocation(line: 114, column: 2, scope: !320, inlinedAt: !251)
!325 = !DILocation(line: 115, column: 15, scope: !323, inlinedAt: !251)
!326 = !DILocation(line: 115, column: 27, scope: !323, inlinedAt: !251)
!327 = !DILocation(line: 115, column: 25, scope: !323, inlinedAt: !251)
!328 = !DILocation(line: 115, column: 4, scope: !323, inlinedAt: !251)
!329 = !DILocation(line: 115, column: 12, scope: !323, inlinedAt: !251)
!330 = !DILocation(line: 114, column: 26, scope: !323, inlinedAt: !251)
!331 = !DILocation(line: 114, column: 2, scope: !323, inlinedAt: !251)
!332 = distinct !{!332, !324, !333, !148}
!333 = !DILocation(line: 115, column: 33, scope: !320, inlinedAt: !251)
!334 = !DILocation(line: 111, column: 30, scope: !314, inlinedAt: !251)
!335 = !DILocation(line: 111, column: 5, scope: !314, inlinedAt: !251)
!336 = distinct !{!336, !315, !337, !148}
!337 = !DILocation(line: 116, column: 7, scope: !311, inlinedAt: !251)
!338 = !DILocation(line: 110, column: 28, scope: !308, inlinedAt: !251)
!339 = !DILocation(line: 110, column: 3, scope: !308, inlinedAt: !251)
!340 = distinct !{!340, !309, !341, !148}
!341 = !DILocation(line: 116, column: 7, scope: !305, inlinedAt: !251)
!342 = !DILocation(line: 153, column: 3, scope: !239)
!343 = distinct !DISubprogram(name: "workload_checksum", scope: !11, file: !11, line: 155, type: !344, scopeLine: 155, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !2, retainedNodes: !78)
!344 = !DISubroutineType(types: !345)
!345 = !{!24, !6}
!346 = !DILocalVariable(name: "task", arg: 1, scope: !343, file: !11, line: 155, type: !6)
!347 = !DILocation(line: 0, scope: !343)
!348 = !DILocation(line: 157, column: 11, scope: !343)
!349 = !DILocation(line: 158, column: 15, scope: !343)
!350 = !DILocation(line: 158, column: 19, scope: !343)
!351 = !DILocation(line: 158, column: 3, scope: !343)
!352 = !DILocation(line: 159, column: 10, scope: !343)
!353 = !DILocation(line: 159, column: 3, scope: !343)
!354 = distinct !DISubprogram(name: "print_array", scope: !11, file: !11, line: 70, type: !355, scopeLine: 72, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition, unit: !2, retainedNodes: !78)
!355 = !DISubroutineType(types: !356)
!356 = !{null, !12, !12, !106}
!357 = !DILocalVariable(name: "ni", arg: 1, scope: !354, file: !11, line: 70, type: !12)
!358 = !DILocation(line: 0, scope: !354)
!359 = !DILocalVariable(name: "nl", arg: 2, scope: !354, file: !11, line: 70, type: !12)
!360 = !DILocalVariable(name: "D", arg: 3, scope: !354, file: !11, line: 71, type: !106)
!361 = !DILocation(line: 75, column: 3, scope: !354)
!362 = !DILocation(line: 76, column: 3, scope: !354)
!363 = !DILocalVariable(name: "i", scope: !354, file: !11, line: 73, type: !12)
!364 = !DILocation(line: 77, column: 8, scope: !365)
!365 = distinct !DILexicalBlock(scope: !354, file: !11, line: 77, column: 3)
!366 = !DILocation(line: 0, scope: !365)
!367 = !DILocation(line: 77, column: 17, scope: !368)
!368 = distinct !DILexicalBlock(scope: !365, file: !11, line: 77, column: 3)
!369 = !DILocation(line: 77, column: 3, scope: !365)
!370 = !DILocalVariable(name: "j", scope: !354, file: !11, line: 73, type: !12)
!371 = !DILocation(line: 78, column: 10, scope: !372)
!372 = distinct !DILexicalBlock(scope: !368, file: !11, line: 78, column: 5)
!373 = !DILocation(line: 0, scope: !372)
!374 = !DILocation(line: 78, column: 19, scope: !375)
!375 = distinct !DILexicalBlock(scope: !372, file: !11, line: 78, column: 5)
!376 = !DILocation(line: 78, column: 5, scope: !372)
!377 = !DILocation(line: 79, column: 9, scope: !378)
!378 = distinct !DILexicalBlock(scope: !379, file: !11, line: 79, column: 6)
!379 = distinct !DILexicalBlock(scope: !375, file: !11, line: 78, column: 30)
!380 = !DILocation(line: 79, column: 14, scope: !378)
!381 = !DILocation(line: 79, column: 19, scope: !378)
!382 = !DILocation(line: 79, column: 24, scope: !378)
!383 = !DILocation(line: 79, column: 6, scope: !379)
!384 = !DILocation(line: 79, column: 39, scope: !378)
!385 = !DILocation(line: 79, column: 30, scope: !378)
!386 = !DILocation(line: 80, column: 11, scope: !379)
!387 = !DILocation(line: 80, column: 56, scope: !379)
!388 = !DILocation(line: 80, column: 2, scope: !379)
!389 = !DILocation(line: 81, column: 5, scope: !379)
!390 = !DILocation(line: 78, column: 26, scope: !375)
!391 = !DILocation(line: 78, column: 5, scope: !375)
!392 = distinct !{!392, !376, !393, !148}
!393 = !DILocation(line: 81, column: 5, scope: !372)
!394 = !DILocation(line: 77, column: 24, scope: !368)
!395 = !DILocation(line: 77, column: 3, scope: !368)
!396 = distinct !{!396, !369, !397, !148}
!397 = !DILocation(line: 81, column: 5, scope: !365)
!398 = !DILocation(line: 82, column: 3, scope: !354)
!399 = !DILocation(line: 83, column: 3, scope: !354)
!400 = !DILocation(line: 84, column: 1, scope: !354)
!401 = distinct !DISubprogram(name: "pb_fprintf", scope: !36, file: !36, line: 13, type: !402, scopeLine: 14, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition, unit: !2, retainedNodes: !78)
!402 = !DISubroutineType(types: !403)
!403 = !{!12, !404, !463, null}
!404 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !405, size: 64)
!405 = !DIDerivedType(tag: DW_TAG_typedef, name: "FILE", file: !406, line: 7, baseType: !407)
!406 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/types/FILE.h", directory: "", checksumkind: CSK_MD5, checksum: "571f9fb6223c42439075fdde11a0de5d")
!407 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "_IO_FILE", file: !408, line: 49, size: 1728, elements: !409)
!408 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/types/struct_FILE.h", directory: "", checksumkind: CSK_MD5, checksum: "1bad07471b7974df4ecc1d1c2ca207e6")
!409 = !{!410, !411, !414, !415, !416, !417, !418, !419, !420, !421, !422, !423, !424, !427, !429, !430, !431, !434, !436, !438, !440, !443, !445, !448, !451, !452, !454, !458, !459}
!410 = !DIDerivedType(tag: DW_TAG_member, name: "_flags", scope: !407, file: !408, line: 51, baseType: !12, size: 32)
!411 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_read_ptr", scope: !407, file: !408, line: 54, baseType: !412, size: 64, offset: 64)
!412 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !413, size: 64)
!413 = !DIBasicType(name: "char", size: 8, encoding: DW_ATE_signed_char)
!414 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_read_end", scope: !407, file: !408, line: 55, baseType: !412, size: 64, offset: 128)
!415 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_read_base", scope: !407, file: !408, line: 56, baseType: !412, size: 64, offset: 192)
!416 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_write_base", scope: !407, file: !408, line: 57, baseType: !412, size: 64, offset: 256)
!417 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_write_ptr", scope: !407, file: !408, line: 58, baseType: !412, size: 64, offset: 320)
!418 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_write_end", scope: !407, file: !408, line: 59, baseType: !412, size: 64, offset: 384)
!419 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_buf_base", scope: !407, file: !408, line: 60, baseType: !412, size: 64, offset: 448)
!420 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_buf_end", scope: !407, file: !408, line: 61, baseType: !412, size: 64, offset: 512)
!421 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_save_base", scope: !407, file: !408, line: 64, baseType: !412, size: 64, offset: 576)
!422 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_backup_base", scope: !407, file: !408, line: 65, baseType: !412, size: 64, offset: 640)
!423 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_save_end", scope: !407, file: !408, line: 66, baseType: !412, size: 64, offset: 704)
!424 = !DIDerivedType(tag: DW_TAG_member, name: "_markers", scope: !407, file: !408, line: 68, baseType: !425, size: 64, offset: 768)
!425 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !426, size: 64)
!426 = !DICompositeType(tag: DW_TAG_structure_type, name: "_IO_marker", file: !408, line: 36, flags: DIFlagFwdDecl)
!427 = !DIDerivedType(tag: DW_TAG_member, name: "_chain", scope: !407, file: !408, line: 70, baseType: !428, size: 64, offset: 832)
!428 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !407, size: 64)
!429 = !DIDerivedType(tag: DW_TAG_member, name: "_fileno", scope: !407, file: !408, line: 72, baseType: !12, size: 32, offset: 896)
!430 = !DIDerivedType(tag: DW_TAG_member, name: "_flags2", scope: !407, file: !408, line: 73, baseType: !12, size: 32, offset: 928)
!431 = !DIDerivedType(tag: DW_TAG_member, name: "_old_offset", scope: !407, file: !408, line: 74, baseType: !432, size: 64, offset: 960)
!432 = !DIDerivedType(tag: DW_TAG_typedef, name: "__off_t", file: !27, line: 152, baseType: !433)
!433 = !DIBasicType(name: "long", size: 64, encoding: DW_ATE_signed)
!434 = !DIDerivedType(tag: DW_TAG_member, name: "_cur_column", scope: !407, file: !408, line: 77, baseType: !435, size: 16, offset: 1024)
!435 = !DIBasicType(name: "unsigned short", size: 16, encoding: DW_ATE_unsigned)
!436 = !DIDerivedType(tag: DW_TAG_member, name: "_vtable_offset", scope: !407, file: !408, line: 78, baseType: !437, size: 8, offset: 1040)
!437 = !DIBasicType(name: "signed char", size: 8, encoding: DW_ATE_signed_char)
!438 = !DIDerivedType(tag: DW_TAG_member, name: "_shortbuf", scope: !407, file: !408, line: 79, baseType: !439, size: 8, offset: 1048)
!439 = !DICompositeType(tag: DW_TAG_array_type, baseType: !413, size: 8, elements: !28)
!440 = !DIDerivedType(tag: DW_TAG_member, name: "_lock", scope: !407, file: !408, line: 81, baseType: !441, size: 64, offset: 1088)
!441 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !442, size: 64)
!442 = !DIDerivedType(tag: DW_TAG_typedef, name: "_IO_lock_t", file: !408, line: 43, baseType: null)
!443 = !DIDerivedType(tag: DW_TAG_member, name: "_offset", scope: !407, file: !408, line: 89, baseType: !444, size: 64, offset: 1152)
!444 = !DIDerivedType(tag: DW_TAG_typedef, name: "__off64_t", file: !27, line: 153, baseType: !433)
!445 = !DIDerivedType(tag: DW_TAG_member, name: "_codecvt", scope: !407, file: !408, line: 91, baseType: !446, size: 64, offset: 1216)
!446 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !447, size: 64)
!447 = !DICompositeType(tag: DW_TAG_structure_type, name: "_IO_codecvt", file: !408, line: 37, flags: DIFlagFwdDecl)
!448 = !DIDerivedType(tag: DW_TAG_member, name: "_wide_data", scope: !407, file: !408, line: 92, baseType: !449, size: 64, offset: 1280)
!449 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !450, size: 64)
!450 = !DICompositeType(tag: DW_TAG_structure_type, name: "_IO_wide_data", file: !408, line: 38, flags: DIFlagFwdDecl)
!451 = !DIDerivedType(tag: DW_TAG_member, name: "_freeres_list", scope: !407, file: !408, line: 93, baseType: !428, size: 64, offset: 1344)
!452 = !DIDerivedType(tag: DW_TAG_member, name: "_freeres_buf", scope: !407, file: !408, line: 94, baseType: !453, size: 64, offset: 1408)
!453 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: null, size: 64)
!454 = !DIDerivedType(tag: DW_TAG_member, name: "__pad5", scope: !407, file: !408, line: 95, baseType: !455, size: 64, offset: 1472)
!455 = !DIDerivedType(tag: DW_TAG_typedef, name: "size_t", file: !456, line: 46, baseType: !457)
!456 = !DIFile(filename: "/usr/lib/llvm-14/lib/clang/14.0.0/include/stddef.h", directory: "", checksumkind: CSK_MD5, checksum: "2499dd2361b915724b073282bea3a7bc")
!457 = !DIBasicType(name: "unsigned long", size: 64, encoding: DW_ATE_unsigned)
!458 = !DIDerivedType(tag: DW_TAG_member, name: "_mode", scope: !407, file: !408, line: 96, baseType: !12, size: 32, offset: 1536)
!459 = !DIDerivedType(tag: DW_TAG_member, name: "_unused2", scope: !407, file: !408, line: 98, baseType: !460, size: 160, offset: 1568)
!460 = !DICompositeType(tag: DW_TAG_array_type, baseType: !413, size: 160, elements: !461)
!461 = !{!462}
!462 = !DISubrange(count: 20)
!463 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !464, size: 64)
!464 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !413)
!465 = !DILocalVariable(name: "stream", arg: 1, scope: !401, file: !36, line: 13, type: !404)
!466 = !DILocation(line: 0, scope: !401)
!467 = !DILocalVariable(name: "format", arg: 2, scope: !401, file: !36, line: 13, type: !463)
!468 = !DILocalVariable(name: "buffer", scope: !401, file: !36, line: 15, type: !469)
!469 = !DICompositeType(tag: DW_TAG_array_type, baseType: !413, size: 6144, elements: !470)
!470 = !{!471}
!471 = !DISubrange(count: 768)
!472 = !DILocation(line: 15, column: 10, scope: !401)
!473 = !DILocalVariable(name: "args", scope: !401, file: !36, line: 16, type: !474)
!474 = !DIDerivedType(tag: DW_TAG_typedef, name: "va_list", file: !475, line: 52, baseType: !476)
!475 = !DIFile(filename: "/usr/include/stdio.h", directory: "", checksumkind: CSK_MD5, checksum: "f31eefcc3f15835fc5a4023a625cf609")
!476 = !DIDerivedType(tag: DW_TAG_typedef, name: "__gnuc_va_list", file: !477, line: 32, baseType: !478)
!477 = !DIFile(filename: "/usr/lib/llvm-14/lib/clang/14.0.0/include/stdarg.h", directory: "", checksumkind: CSK_MD5, checksum: "4de3cbd931b589d291e5c39387aecf82")
!478 = !DIDerivedType(tag: DW_TAG_typedef, name: "__builtin_va_list", file: !479, baseType: !480)
!479 = !DIFile(filename: "source/workload.c", directory: "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/affine-bounds-20260929/suite/2mm")
!480 = !DICompositeType(tag: DW_TAG_array_type, baseType: !481, size: 192, elements: !28)
!481 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "__va_list_tag", size: 192, elements: !482)
!482 = !{!483, !484, !485, !486}
!483 = !DIDerivedType(tag: DW_TAG_member, name: "gp_offset", scope: !481, file: !479, line: 16, baseType: !6, size: 32)
!484 = !DIDerivedType(tag: DW_TAG_member, name: "fp_offset", scope: !481, file: !479, line: 16, baseType: !6, size: 32, offset: 32)
!485 = !DIDerivedType(tag: DW_TAG_member, name: "overflow_arg_area", scope: !481, file: !479, line: 16, baseType: !453, size: 64, offset: 64)
!486 = !DIDerivedType(tag: DW_TAG_member, name: "reg_save_area", scope: !481, file: !479, line: 16, baseType: !453, size: 64, offset: 128)
!487 = !DILocation(line: 16, column: 13, scope: !401)
!488 = !DILocation(line: 17, column: 5, scope: !401)
!489 = !DILocation(line: 18, column: 27, scope: !401)
!490 = !DILocation(line: 18, column: 59, scope: !401)
!491 = !DILocation(line: 18, column: 17, scope: !401)
!492 = !DILocalVariable(name: "count", scope: !401, file: !36, line: 18, type: !12)
!493 = !DILocation(line: 19, column: 5, scope: !401)
!494 = !DILocation(line: 20, column: 15, scope: !495)
!495 = distinct !DILexicalBlock(scope: !401, file: !36, line: 20, column: 9)
!496 = !DILocation(line: 20, column: 19, scope: !495)
!497 = !DILocation(line: 20, column: 22, scope: !495)
!498 = !DILocation(line: 20, column: 38, scope: !495)
!499 = !DILocation(line: 20, column: 9, scope: !401)
!500 = !DILocation(line: 20, column: 57, scope: !495)
!501 = !DILocalVariable(name: "i", scope: !502, file: !36, line: 21, type: !12)
!502 = distinct !DILexicalBlock(scope: !401, file: !36, line: 21, column: 5)
!503 = !DILocation(line: 0, scope: !502)
!504 = !DILocation(line: 21, column: 10, scope: !502)
!505 = !DILocation(line: 21, column: 23, scope: !506)
!506 = distinct !DILexicalBlock(scope: !502, file: !36, line: 21, column: 5)
!507 = !DILocation(line: 21, column: 5, scope: !502)
!508 = !DILocation(line: 22, column: 35, scope: !509)
!509 = distinct !DILexicalBlock(scope: !506, file: !36, line: 21, column: 37)
!510 = !DILocation(line: 22, column: 20, scope: !509)
!511 = !DILocation(line: 22, column: 17, scope: !509)
!512 = !DILocation(line: 23, column: 17, scope: !509)
!513 = !DILocation(line: 24, column: 5, scope: !509)
!514 = !DILocation(line: 21, column: 32, scope: !506)
!515 = !DILocation(line: 21, column: 5, scope: !506)
!516 = distinct !{!516, !507, !517, !148}
!517 = !DILocation(line: 24, column: 5, scope: !502)
!518 = !DILocation(line: 29, column: 11, scope: !401)
!519 = !DILocation(line: 31, column: 5, scope: !401)
