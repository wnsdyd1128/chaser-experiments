; ModuleID = 'workload.ll'
source_filename = "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/affine-bounds-20260929/suite/durbin/source/workload.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

%struct._IO_FILE = type { i32, i8*, i8*, i8*, i8*, i8*, i8*, i8*, i8*, i8*, i8*, i8*, %struct._IO_marker*, %struct._IO_FILE*, i32, i32, i64, i16, i8, [1 x i8], i8*, i64, %struct._IO_codecvt*, %struct._IO_wide_data*, %struct._IO_FILE*, i8*, i64, i32, [20 x i8] }
%struct._IO_marker = type opaque
%struct._IO_codecvt = type opaque
%struct._IO_wide_data = type opaque
%struct.__va_list_tag = type { i32, i32, i8*, i8* }

@n = dso_local global i32 400, align 4, !dbg !0
@r = dso_local global [400 x double] zeroinitializer, section ".chaser_data.r", align 64, !dbg !29
@y = dso_local global [400 x double] zeroinitializer, section ".chaser_data.y", align 64, !dbg !35
@z = dso_local global [400 x double] zeroinitializer, section ".chaser_data.z", align 64, !dbg !37
@.str = private unnamed_addr constant [12 x i8] c"ape.analyze\00", section "llvm.metadata"
@.str.1 = private unnamed_addr constant [124 x i8] c"/workspace/experiments-array-support/chaser/.cache/periodic-polybench/affine-bounds-20260929/suite/durbin/source/workload.c\00", section "llvm.metadata"
@pb_hash = internal global i32 0, align 4, !dbg !26
@workload_jobs = dso_local constant [1 x i32 ()*] [i32 ()* @task_job_polybench], align 8, !dbg !8
@workload_expected = dso_local constant [1 x i32] [i32 -1040675123], align 4, !dbg !22
@stderr = external global %struct._IO_FILE*, align 8
@.str.2 = private unnamed_addr constant [23 x i8] c"==BEGIN DUMP_ARRAYS==\0A\00", align 1
@.str.3 = private unnamed_addr constant [15 x i8] c"begin dump: %s\00", align 1
@.str.4 = private unnamed_addr constant [2 x i8] c"y\00", align 1
@.str.5 = private unnamed_addr constant [2 x i8] c"\0A\00", align 1
@.str.6 = private unnamed_addr constant [8 x i8] c"%0.2lf \00", align 1
@.str.7 = private unnamed_addr constant [17 x i8] c"\0Aend   dump: %s\0A\00", align 1
@.str.8 = private unnamed_addr constant [23 x i8] c"==END   DUMP_ARRAYS==\0A\00", align 1
@pb_emit = internal global i32 1, align 4, !dbg !39
@llvm.global.annotations = appending global [1 x { i8*, i8*, i8*, i32, i8* }] [{ i8*, i8*, i8*, i32, i8* } { i8* bitcast (i32 ()* @task_job_polybench to i8*), i8* getelementptr inbounds ([12 x i8], [12 x i8]* @.str, i32 0, i32 0), i8* getelementptr inbounds ([124 x i8], [124 x i8]* @.str.1, i32 0, i32 0), i32 120, i8* null }], section "llvm.metadata"

; Function Attrs: noinline nounwind uwtable
define dso_local void @workload_prepare() #0 !dbg !50 {
  ret void, !dbg !54
}

; Function Attrs: noinline nounwind uwtable
define dso_local void @workload_reset(i32 noundef %0) #0 !dbg !55 {
  call void @llvm.dbg.value(metadata i32 %0, metadata !58, metadata !DIExpression()), !dbg !59
  call void @llvm.memset.p0i8.i64(i8* align 64 bitcast ([400 x double]* @r to i8*), i8 0, i64 3200, i1 false), !dbg !60
  call void @llvm.memset.p0i8.i64(i8* align 64 bitcast ([400 x double]* @y to i8*), i8 0, i64 3200, i1 false), !dbg !61
  call void @llvm.memset.p0i8.i64(i8* align 64 bitcast ([400 x double]* @z to i8*), i8 0, i64 3200, i1 false), !dbg !62
  %2 = load i32, i32* @n, align 4, !dbg !63
  call void @init_array(i32 noundef %2, double* noundef getelementptr inbounds ([400 x double], [400 x double]* @r, i64 0, i64 0)), !dbg !64
  ret void, !dbg !65
}

; Function Attrs: nofree nosync nounwind readnone speculatable willreturn
declare void @llvm.dbg.declare(metadata, metadata, metadata) #1

; Function Attrs: argmemonly nofree nounwind willreturn writeonly
declare void @llvm.memset.p0i8.i64(i8* nocapture writeonly, i8, i64, i1 immarg) #2

; Function Attrs: noinline nounwind uwtable
define internal void @init_array(i32 noundef %0, double* noundef %1) #0 !dbg !66 {
  call void @llvm.dbg.value(metadata i32 %0, metadata !70, metadata !DIExpression()), !dbg !71
  call void @llvm.dbg.value(metadata double* %1, metadata !72, metadata !DIExpression()), !dbg !71
  call void @llvm.dbg.declare(metadata i32* undef, metadata !73, metadata !DIExpression()), !dbg !74
  call void @llvm.dbg.value(metadata i32 0, metadata !75, metadata !DIExpression()), !dbg !71
  br label %3, !dbg !76

3:                                                ; preds = %11, %2
  %.0 = phi i32 [ 0, %2 ], [ %12, %11 ], !dbg !78
  call void @llvm.dbg.value(metadata i32 %.0, metadata !75, metadata !DIExpression()), !dbg !71
  %4 = icmp slt i32 %.0, %0, !dbg !79
  br i1 %4, label %5, label %13, !dbg !81

5:                                                ; preds = %3
  %6 = add nsw i32 %0, 1, !dbg !82
  %7 = sub nsw i32 %6, %.0, !dbg !84
  %8 = sitofp i32 %7 to double, !dbg !85
  %9 = sext i32 %.0 to i64, !dbg !86
  %10 = getelementptr inbounds double, double* %1, i64 %9, !dbg !86
  store double %8, double* %10, align 8, !dbg !87
  br label %11, !dbg !88

11:                                               ; preds = %5
  %12 = add nsw i32 %.0, 1, !dbg !89
  call void @llvm.dbg.value(metadata i32 %12, metadata !75, metadata !DIExpression()), !dbg !71
  br label %3, !dbg !90, !llvm.loop !91

13:                                               ; preds = %3
  ret void, !dbg !94
}

; Function Attrs: noinline nounwind uwtable
define dso_local i32 @task_job_polybench() #0 !dbg !95 {
  %1 = load i32, i32* @n, align 4, !dbg !96
  call void @llvm.dbg.value(metadata i32 %1, metadata !97, metadata !DIExpression()), !dbg !101
  call void @llvm.dbg.value(metadata double* getelementptr inbounds ([400 x double], [400 x double]* @r, i64 0, i64 0), metadata !103, metadata !DIExpression()), !dbg !101
  call void @llvm.dbg.value(metadata double* getelementptr inbounds ([400 x double], [400 x double]* @y, i64 0, i64 0), metadata !104, metadata !DIExpression()), !dbg !101
  %2 = load double, double* getelementptr inbounds ([400 x double], [400 x double]* @r, i64 0, i64 0), align 8, !dbg !105
  %3 = fneg double %2, !dbg !106
  store double %3, double* getelementptr inbounds ([400 x double], [400 x double]* @y, i64 0, i64 0), align 8, !dbg !107
  call void @llvm.dbg.value(metadata double 1.000000e+00, metadata !108, metadata !DIExpression()), !dbg !101
  %4 = load double, double* getelementptr inbounds ([400 x double], [400 x double]* @r, i64 0, i64 0), align 8, !dbg !109
  %5 = fneg double %4, !dbg !110
  call void @llvm.dbg.value(metadata double %5, metadata !111, metadata !DIExpression()), !dbg !101
  call void @llvm.dbg.value(metadata i32 1, metadata !112, metadata !DIExpression()), !dbg !101
  br label %6, !dbg !113

6:                                                ; preds = %59, %0
  %.04 = phi double [ 1.000000e+00, %0 ], [ %11, %59 ], !dbg !101
  %.03 = phi double [ %5, %0 ], [ %32, %59 ], !dbg !101
  %.0 = phi i32 [ 1, %0 ], [ %62, %59 ], !dbg !115
  call void @llvm.dbg.value(metadata i32 %.0, metadata !112, metadata !DIExpression()), !dbg !101
  call void @llvm.dbg.value(metadata double %.03, metadata !111, metadata !DIExpression()), !dbg !101
  call void @llvm.dbg.value(metadata double %.04, metadata !108, metadata !DIExpression()), !dbg !101
  %7 = icmp slt i32 %.0, 400, !dbg !116
  br i1 %7, label %8, label %63, !dbg !118

8:                                                ; preds = %6
  %9 = fmul double %.03, %.03, !dbg !119
  %10 = fsub double 1.000000e+00, %9, !dbg !121
  %11 = fmul double %10, %.04, !dbg !122
  call void @llvm.dbg.value(metadata double %11, metadata !108, metadata !DIExpression()), !dbg !101
  call void @llvm.dbg.value(metadata double 0.000000e+00, metadata !123, metadata !DIExpression()), !dbg !101
  call void @llvm.dbg.value(metadata i32 0, metadata !124, metadata !DIExpression()), !dbg !101
  br label %12, !dbg !125

12:                                               ; preds = %14, %8
  %.02 = phi double [ 0.000000e+00, %8 ], [ %24, %14 ], !dbg !127
  %.01 = phi i32 [ 0, %8 ], [ %25, %14 ], !dbg !128
  call void @llvm.dbg.value(metadata i32 %.01, metadata !124, metadata !DIExpression()), !dbg !101
  call void @llvm.dbg.value(metadata double %.02, metadata !123, metadata !DIExpression()), !dbg !101
  %13 = icmp slt i32 %.01, %.0, !dbg !129
  br i1 %13, label %14, label %26, !dbg !131

14:                                               ; preds = %12
  %15 = sub nsw i32 %.0, %.01, !dbg !132
  %16 = sub nsw i32 %15, 1, !dbg !134
  %17 = sext i32 %16 to i64, !dbg !135
  %18 = getelementptr inbounds double, double* getelementptr inbounds ([400 x double], [400 x double]* @r, i64 0, i64 0), i64 %17, !dbg !135
  %19 = load double, double* %18, align 8, !dbg !135
  %20 = sext i32 %.01 to i64, !dbg !136
  %21 = getelementptr inbounds double, double* getelementptr inbounds ([400 x double], [400 x double]* @y, i64 0, i64 0), i64 %20, !dbg !136
  %22 = load double, double* %21, align 8, !dbg !136
  %23 = fmul double %19, %22, !dbg !137
  %24 = fadd double %.02, %23, !dbg !138
  call void @llvm.dbg.value(metadata double %24, metadata !123, metadata !DIExpression()), !dbg !101
  %25 = add nsw i32 %.01, 1, !dbg !139
  call void @llvm.dbg.value(metadata i32 %25, metadata !124, metadata !DIExpression()), !dbg !101
  br label %12, !dbg !140, !llvm.loop !141

26:                                               ; preds = %12
  %27 = sext i32 %.0 to i64, !dbg !143
  %28 = getelementptr inbounds double, double* getelementptr inbounds ([400 x double], [400 x double]* @r, i64 0, i64 0), i64 %27, !dbg !143
  %29 = load double, double* %28, align 8, !dbg !143
  %30 = fadd double %29, %.02, !dbg !144
  %31 = fneg double %30, !dbg !145
  %32 = fdiv double %31, %11, !dbg !146
  call void @llvm.dbg.value(metadata double %32, metadata !111, metadata !DIExpression()), !dbg !101
  call void @llvm.dbg.value(metadata i32 0, metadata !124, metadata !DIExpression()), !dbg !101
  br label %33, !dbg !147

33:                                               ; preds = %35, %26
  %.1 = phi i32 [ 0, %26 ], [ %48, %35 ], !dbg !149
  call void @llvm.dbg.value(metadata i32 %.1, metadata !124, metadata !DIExpression()), !dbg !101
  %34 = icmp slt i32 %.1, %.0, !dbg !150
  br i1 %34, label %35, label %49, !dbg !152

35:                                               ; preds = %33
  %36 = sext i32 %.1 to i64, !dbg !153
  %37 = getelementptr inbounds double, double* getelementptr inbounds ([400 x double], [400 x double]* @y, i64 0, i64 0), i64 %36, !dbg !153
  %38 = load double, double* %37, align 8, !dbg !153
  %39 = sub nsw i32 %.0, %.1, !dbg !155
  %40 = sub nsw i32 %39, 1, !dbg !156
  %41 = sext i32 %40 to i64, !dbg !157
  %42 = getelementptr inbounds double, double* getelementptr inbounds ([400 x double], [400 x double]* @y, i64 0, i64 0), i64 %41, !dbg !157
  %43 = load double, double* %42, align 8, !dbg !157
  %44 = fmul double %32, %43, !dbg !158
  %45 = fadd double %38, %44, !dbg !159
  %46 = sext i32 %.1 to i64, !dbg !160
  %47 = getelementptr inbounds [400 x double], [400 x double]* @z, i64 0, i64 %46, !dbg !160
  store double %45, double* %47, align 8, !dbg !161
  %48 = add nsw i32 %.1, 1, !dbg !162
  call void @llvm.dbg.value(metadata i32 %48, metadata !124, metadata !DIExpression()), !dbg !101
  br label %33, !dbg !163, !llvm.loop !164

49:                                               ; preds = %33
  call void @llvm.dbg.value(metadata i32 0, metadata !124, metadata !DIExpression()), !dbg !101
  br label %50, !dbg !166

50:                                               ; preds = %52, %49
  %.2 = phi i32 [ 0, %49 ], [ %58, %52 ], !dbg !168
  call void @llvm.dbg.value(metadata i32 %.2, metadata !124, metadata !DIExpression()), !dbg !101
  %51 = icmp slt i32 %.2, %.0, !dbg !169
  br i1 %51, label %52, label %59, !dbg !171

52:                                               ; preds = %50
  %53 = sext i32 %.2 to i64, !dbg !172
  %54 = getelementptr inbounds [400 x double], [400 x double]* @z, i64 0, i64 %53, !dbg !172
  %55 = load double, double* %54, align 8, !dbg !172
  %56 = sext i32 %.2 to i64, !dbg !174
  %57 = getelementptr inbounds double, double* getelementptr inbounds ([400 x double], [400 x double]* @y, i64 0, i64 0), i64 %56, !dbg !174
  store double %55, double* %57, align 8, !dbg !175
  %58 = add nsw i32 %.2, 1, !dbg !176
  call void @llvm.dbg.value(metadata i32 %58, metadata !124, metadata !DIExpression()), !dbg !101
  br label %50, !dbg !177, !llvm.loop !178

59:                                               ; preds = %50
  %60 = sext i32 %.0 to i64, !dbg !180
  %61 = getelementptr inbounds double, double* getelementptr inbounds ([400 x double], [400 x double]* @y, i64 0, i64 0), i64 %60, !dbg !180
  store double %32, double* %61, align 8, !dbg !181
  %62 = add nsw i32 %.0, 1, !dbg !182
  call void @llvm.dbg.value(metadata i32 %62, metadata !112, metadata !DIExpression()), !dbg !101
  br label %6, !dbg !183, !llvm.loop !184

63:                                               ; preds = %6
  ret i32 0, !dbg !186
}

; Function Attrs: noinline nounwind uwtable
define dso_local i32 @workload_checksum(i32 noundef %0) #0 !dbg !187 {
  call void @llvm.dbg.value(metadata i32 %0, metadata !190, metadata !DIExpression()), !dbg !191
  store i32 -2128831035, i32* @pb_hash, align 4, !dbg !192
  %2 = load i32, i32* @n, align 4, !dbg !193
  call void @print_array(i32 noundef %2, double* noundef getelementptr inbounds ([400 x double], [400 x double]* @y, i64 0, i64 0)), !dbg !194
  %3 = load i32, i32* @pb_hash, align 4, !dbg !195
  ret i32 %3, !dbg !196
}

; Function Attrs: noinline nounwind uwtable
define internal void @print_array(i32 noundef %0, double* noundef %1) #0 !dbg !197 {
  call void @llvm.dbg.value(metadata i32 %0, metadata !198, metadata !DIExpression()), !dbg !199
  call void @llvm.dbg.value(metadata double* %1, metadata !200, metadata !DIExpression()), !dbg !199
  %3 = load %struct._IO_FILE*, %struct._IO_FILE** @stderr, align 8, !dbg !201
  %4 = call i32 (%struct._IO_FILE*, i8*, ...) @pb_fprintf(%struct._IO_FILE* noundef %3, i8* noundef getelementptr inbounds ([23 x i8], [23 x i8]* @.str.2, i64 0, i64 0)), !dbg !201
  %5 = load %struct._IO_FILE*, %struct._IO_FILE** @stderr, align 8, !dbg !202
  %6 = call i32 (%struct._IO_FILE*, i8*, ...) @pb_fprintf(%struct._IO_FILE* noundef %5, i8* noundef getelementptr inbounds ([15 x i8], [15 x i8]* @.str.3, i64 0, i64 0), i8* noundef getelementptr inbounds ([2 x i8], [2 x i8]* @.str.4, i64 0, i64 0)), !dbg !202
  call void @llvm.dbg.value(metadata i32 0, metadata !203, metadata !DIExpression()), !dbg !199
  br label %7, !dbg !204

7:                                                ; preds = %21, %2
  %.0 = phi i32 [ 0, %2 ], [ %22, %21 ], !dbg !206
  call void @llvm.dbg.value(metadata i32 %.0, metadata !203, metadata !DIExpression()), !dbg !199
  %8 = icmp slt i32 %.0, %0, !dbg !207
  br i1 %8, label %9, label %23, !dbg !209

9:                                                ; preds = %7
  %10 = srem i32 %.0, 20, !dbg !210
  %11 = icmp eq i32 %10, 0, !dbg !213
  br i1 %11, label %12, label %15, !dbg !214

12:                                               ; preds = %9
  %13 = load %struct._IO_FILE*, %struct._IO_FILE** @stderr, align 8, !dbg !215
  %14 = call i32 (%struct._IO_FILE*, i8*, ...) @pb_fprintf(%struct._IO_FILE* noundef %13, i8* noundef getelementptr inbounds ([2 x i8], [2 x i8]* @.str.5, i64 0, i64 0)), !dbg !216
  br label %15, !dbg !216

15:                                               ; preds = %12, %9
  %16 = load %struct._IO_FILE*, %struct._IO_FILE** @stderr, align 8, !dbg !217
  %17 = sext i32 %.0 to i64, !dbg !218
  %18 = getelementptr inbounds double, double* %1, i64 %17, !dbg !218
  %19 = load double, double* %18, align 8, !dbg !218
  %20 = call i32 (%struct._IO_FILE*, i8*, ...) @pb_fprintf(%struct._IO_FILE* noundef %16, i8* noundef getelementptr inbounds ([8 x i8], [8 x i8]* @.str.6, i64 0, i64 0), double noundef %19), !dbg !219
  br label %21, !dbg !220

21:                                               ; preds = %15
  %22 = add nsw i32 %.0, 1, !dbg !221
  call void @llvm.dbg.value(metadata i32 %22, metadata !203, metadata !DIExpression()), !dbg !199
  br label %7, !dbg !222, !llvm.loop !223

23:                                               ; preds = %7
  %24 = load %struct._IO_FILE*, %struct._IO_FILE** @stderr, align 8, !dbg !225
  %25 = call i32 (%struct._IO_FILE*, i8*, ...) @pb_fprintf(%struct._IO_FILE* noundef %24, i8* noundef getelementptr inbounds ([17 x i8], [17 x i8]* @.str.7, i64 0, i64 0), i8* noundef getelementptr inbounds ([2 x i8], [2 x i8]* @.str.4, i64 0, i64 0)), !dbg !225
  %26 = load %struct._IO_FILE*, %struct._IO_FILE** @stderr, align 8, !dbg !226
  %27 = call i32 (%struct._IO_FILE*, i8*, ...) @pb_fprintf(%struct._IO_FILE* noundef %26, i8* noundef getelementptr inbounds ([23 x i8], [23 x i8]* @.str.8, i64 0, i64 0)), !dbg !226
  ret void, !dbg !227
}

; Function Attrs: noinline nounwind uwtable
define internal i32 @pb_fprintf(%struct._IO_FILE* noundef %0, i8* noundef %1, ...) #0 !dbg !228 {
  %3 = alloca [768 x i8], align 16
  %4 = alloca [1 x %struct.__va_list_tag], align 16
  call void @llvm.dbg.value(metadata %struct._IO_FILE* %0, metadata !292, metadata !DIExpression()), !dbg !293
  call void @llvm.dbg.value(metadata i8* %1, metadata !294, metadata !DIExpression()), !dbg !293
  call void @llvm.dbg.declare(metadata [768 x i8]* %3, metadata !295, metadata !DIExpression()), !dbg !299
  call void @llvm.dbg.declare(metadata [1 x %struct.__va_list_tag]* %4, metadata !300, metadata !DIExpression()), !dbg !314
  %5 = getelementptr inbounds [1 x %struct.__va_list_tag], [1 x %struct.__va_list_tag]* %4, i64 0, i64 0, !dbg !315
  %6 = bitcast %struct.__va_list_tag* %5 to i8*, !dbg !315
  call void @llvm.va_start(i8* %6), !dbg !315
  %7 = getelementptr inbounds [768 x i8], [768 x i8]* %3, i64 0, i64 0, !dbg !316
  %8 = getelementptr inbounds [1 x %struct.__va_list_tag], [1 x %struct.__va_list_tag]* %4, i64 0, i64 0, !dbg !317
  %9 = call i32 @vsnprintf(i8* noundef %7, i64 noundef 768, i8* noundef %1, %struct.__va_list_tag* noundef %8) #6, !dbg !318
  call void @llvm.dbg.value(metadata i32 %9, metadata !319, metadata !DIExpression()), !dbg !293
  %10 = getelementptr inbounds [1 x %struct.__va_list_tag], [1 x %struct.__va_list_tag]* %4, i64 0, i64 0, !dbg !320
  %11 = bitcast %struct.__va_list_tag* %10 to i8*, !dbg !320
  call void @llvm.va_end(i8* %11), !dbg !320
  %12 = icmp slt i32 %9, 0, !dbg !321
  br i1 %12, label %16, label %13, !dbg !323

13:                                               ; preds = %2
  %14 = zext i32 %9 to i64, !dbg !324
  %15 = icmp uge i64 %14, 768, !dbg !325
  br i1 %15, label %16, label %17, !dbg !326

16:                                               ; preds = %13, %2
  call void @abort() #7, !dbg !327
  unreachable, !dbg !327

17:                                               ; preds = %13
  call void @llvm.dbg.value(metadata i32 0, metadata !328, metadata !DIExpression()), !dbg !330
  br label %18, !dbg !331

18:                                               ; preds = %29, %17
  %.0 = phi i32 [ 0, %17 ], [ %30, %29 ], !dbg !330
  call void @llvm.dbg.value(metadata i32 %.0, metadata !328, metadata !DIExpression()), !dbg !330
  %19 = icmp slt i32 %.0, %9, !dbg !332
  br i1 %19, label %20, label %31, !dbg !334

20:                                               ; preds = %18
  %21 = sext i32 %.0 to i64, !dbg !335
  %22 = getelementptr inbounds [768 x i8], [768 x i8]* %3, i64 0, i64 %21, !dbg !335
  %23 = load i8, i8* %22, align 1, !dbg !335
  %24 = zext i8 %23 to i32, !dbg !337
  %25 = load i32, i32* @pb_hash, align 4, !dbg !338
  %26 = xor i32 %25, %24, !dbg !338
  store i32 %26, i32* @pb_hash, align 4, !dbg !338
  %27 = load i32, i32* @pb_hash, align 4, !dbg !339
  %28 = mul i32 %27, 16777619, !dbg !339
  store i32 %28, i32* @pb_hash, align 4, !dbg !339
  br label %29, !dbg !340

29:                                               ; preds = %20
  %30 = add nsw i32 %.0, 1, !dbg !341
  call void @llvm.dbg.value(metadata i32 %30, metadata !328, metadata !DIExpression()), !dbg !330
  br label %18, !dbg !342, !llvm.loop !343

31:                                               ; preds = %18
  %32 = load i32, i32* @pb_emit, align 4, !dbg !345
  ret i32 %9, !dbg !346
}

; Function Attrs: nofree nosync nounwind willreturn
declare void @llvm.va_start(i8*) #3

; Function Attrs: nounwind
declare i32 @vsnprintf(i8* noundef, i64 noundef, i8* noundef, %struct.__va_list_tag* noundef) #4

; Function Attrs: nofree nosync nounwind willreturn
declare void @llvm.va_end(i8*) #3

; Function Attrs: noreturn nounwind
declare void @abort() #5

; Function Attrs: nofree nosync nounwind readnone speculatable willreturn
declare void @llvm.dbg.value(metadata, metadata, metadata) #1

attributes #0 = { noinline nounwind uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { nofree nosync nounwind readnone speculatable willreturn }
attributes #2 = { argmemonly nofree nounwind willreturn writeonly }
attributes #3 = { nofree nosync nounwind willreturn }
attributes #4 = { nounwind "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #5 = { noreturn nounwind "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #6 = { nounwind }
attributes #7 = { noreturn nounwind }

!llvm.dbg.cu = !{!2}
!llvm.module.flags = !{!42, !43, !44, !45, !46, !47, !48}
!llvm.ident = !{!49}

!0 = !DIGlobalVariableExpression(var: !1, expr: !DIExpression())
!1 = distinct !DIGlobalVariable(name: "n", scope: !2, file: !10, line: 111, type: !41, isLocal: false, isDefinition: true)
!2 = distinct !DICompileUnit(language: DW_LANG_C99, file: !3, producer: "Ubuntu clang version 14.0.0-1ubuntu1.1", isOptimized: false, runtimeVersion: 0, emissionKind: FullDebug, retainedTypes: !4, globals: !7, splitDebugInlining: false, nameTableKind: None)
!3 = !DIFile(filename: "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/affine-bounds-20260929/suite/durbin/source/workload.c", directory: "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/affine-bounds-20260929/suite/durbin/analysis-g", checksumkind: CSK_MD5, checksum: "70112e389066249fa1577d58e2d004e2")
!4 = !{!5, !6}
!5 = !DIBasicType(name: "unsigned int", size: 32, encoding: DW_ATE_unsigned)
!6 = !DIBasicType(name: "unsigned char", size: 8, encoding: DW_ATE_unsigned_char)
!7 = !{!0, !8, !22, !26, !29, !35, !37, !39}
!8 = !DIGlobalVariableExpression(var: !9, expr: !DIExpression())
!9 = distinct !DIGlobalVariable(name: "workload_jobs", scope: !2, file: !10, line: 132, type: !11, isLocal: false, isDefinition: true)
!10 = !DIFile(filename: "source/workload.c", directory: "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/affine-bounds-20260929/suite/durbin", checksumkind: CSK_MD5, checksum: "70112e389066249fa1577d58e2d004e2")
!11 = !DICompositeType(tag: DW_TAG_array_type, baseType: !12, size: 64, elements: !20)
!12 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !13)
!13 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !14, size: 64)
!14 = !DISubroutineType(types: !15)
!15 = !{!16}
!16 = !DIDerivedType(tag: DW_TAG_typedef, name: "uint32_t", file: !17, line: 26, baseType: !18)
!17 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/stdint-uintn.h", directory: "", checksumkind: CSK_MD5, checksum: "2bf2ae53c58c01b1a1b9383b5195125c")
!18 = !DIDerivedType(tag: DW_TAG_typedef, name: "__uint32_t", file: !19, line: 42, baseType: !5)
!19 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/types.h", directory: "", checksumkind: CSK_MD5, checksum: "d108b5f93a74c50510d7d9bc0ab36df9")
!20 = !{!21}
!21 = !DISubrange(count: 1)
!22 = !DIGlobalVariableExpression(var: !23, expr: !DIExpression())
!23 = distinct !DIGlobalVariable(name: "workload_expected", scope: !2, file: !10, line: 136, type: !24, isLocal: false, isDefinition: true)
!24 = !DICompositeType(tag: DW_TAG_array_type, baseType: !25, size: 32, elements: !20)
!25 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !16)
!26 = !DIGlobalVariableExpression(var: !27, expr: !DIExpression())
!27 = distinct !DIGlobalVariable(name: "pb_hash", scope: !2, file: !28, line: 9, type: !16, isLocal: true, isDefinition: true)
!28 = !DIFile(filename: "source/adapter.h", directory: "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/affine-bounds-20260929/suite/durbin", checksumkind: CSK_MD5, checksum: "26a6068928b2092758f244a9d00163d7")
!29 = !DIGlobalVariableExpression(var: !30, expr: !DIExpression())
!30 = distinct !DIGlobalVariable(name: "r", scope: !2, file: !10, line: 34, type: !31, isLocal: false, isDefinition: true, align: 512)
!31 = !DICompositeType(tag: DW_TAG_array_type, baseType: !32, size: 25600, elements: !33)
!32 = !DIBasicType(name: "double", size: 64, encoding: DW_ATE_float)
!33 = !{!34}
!34 = !DISubrange(count: 400)
!35 = !DIGlobalVariableExpression(var: !36, expr: !DIExpression())
!36 = distinct !DIGlobalVariable(name: "y", scope: !2, file: !10, line: 35, type: !31, isLocal: false, isDefinition: true, align: 512)
!37 = !DIGlobalVariableExpression(var: !38, expr: !DIExpression())
!38 = distinct !DIGlobalVariable(name: "z", scope: !2, file: !10, line: 36, type: !31, isLocal: false, isDefinition: true, align: 512)
!39 = !DIGlobalVariableExpression(var: !40, expr: !DIExpression())
!40 = distinct !DIGlobalVariable(name: "pb_emit", scope: !2, file: !28, line: 10, type: !41, isLocal: true, isDefinition: true)
!41 = !DIBasicType(name: "int", size: 32, encoding: DW_ATE_signed)
!42 = !{i32 7, !"Dwarf Version", i32 5}
!43 = !{i32 2, !"Debug Info Version", i32 3}
!44 = !{i32 1, !"wchar_size", i32 4}
!45 = !{i32 7, !"PIC Level", i32 2}
!46 = !{i32 7, !"PIE Level", i32 2}
!47 = !{i32 7, !"uwtable", i32 1}
!48 = !{i32 7, !"frame-pointer", i32 2}
!49 = !{!"Ubuntu clang version 14.0.0-1ubuntu1.1"}
!50 = distinct !DISubprogram(name: "workload_prepare", scope: !10, file: !10, line: 112, type: !51, scopeLine: 112, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !2, retainedNodes: !53)
!51 = !DISubroutineType(types: !52)
!52 = !{null}
!53 = !{}
!54 = !DILocation(line: 112, column: 30, scope: !50)
!55 = distinct !DISubprogram(name: "workload_reset", scope: !10, file: !10, line: 113, type: !56, scopeLine: 113, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !2, retainedNodes: !53)
!56 = !DISubroutineType(types: !57)
!57 = !{null, !5}
!58 = !DILocalVariable(name: "task", arg: 1, scope: !55, file: !10, line: 113, type: !5)
!59 = !DILocation(line: 0, scope: !55)
!60 = !DILocation(line: 115, column: 3, scope: !55)
!61 = !DILocation(line: 116, column: 3, scope: !55)
!62 = !DILocation(line: 117, column: 3, scope: !55)
!63 = !DILocation(line: 118, column: 15, scope: !55)
!64 = !DILocation(line: 118, column: 3, scope: !55)
!65 = !DILocation(line: 119, column: 1, scope: !55)
!66 = distinct !DISubprogram(name: "init_array", scope: !10, file: !10, line: 38, type: !67, scopeLine: 40, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition, unit: !2, retainedNodes: !53)
!67 = !DISubroutineType(types: !68)
!68 = !{null, !41, !69}
!69 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !32, size: 64)
!70 = !DILocalVariable(name: "n", arg: 1, scope: !66, file: !10, line: 38, type: !41)
!71 = !DILocation(line: 0, scope: !66)
!72 = !DILocalVariable(name: "r", arg: 2, scope: !66, file: !10, line: 39, type: !69)
!73 = !DILocalVariable(name: "j", scope: !66, file: !10, line: 41, type: !41)
!74 = !DILocation(line: 41, column: 10, scope: !66)
!75 = !DILocalVariable(name: "i", scope: !66, file: !10, line: 41, type: !41)
!76 = !DILocation(line: 43, column: 8, scope: !77)
!77 = distinct !DILexicalBlock(scope: !66, file: !10, line: 43, column: 3)
!78 = !DILocation(line: 0, scope: !77)
!79 = !DILocation(line: 43, column: 17, scope: !80)
!80 = distinct !DILexicalBlock(scope: !77, file: !10, line: 43, column: 3)
!81 = !DILocation(line: 43, column: 3, scope: !77)
!82 = !DILocation(line: 45, column: 16, scope: !83)
!83 = distinct !DILexicalBlock(scope: !80, file: !10, line: 44, column: 5)
!84 = !DILocation(line: 45, column: 18, scope: !83)
!85 = !DILocation(line: 45, column: 14, scope: !83)
!86 = !DILocation(line: 45, column: 7, scope: !83)
!87 = !DILocation(line: 45, column: 12, scope: !83)
!88 = !DILocation(line: 46, column: 5, scope: !83)
!89 = !DILocation(line: 43, column: 23, scope: !80)
!90 = !DILocation(line: 43, column: 3, scope: !80)
!91 = distinct !{!91, !81, !92, !93}
!92 = !DILocation(line: 46, column: 5, scope: !77)
!93 = !{!"llvm.loop.mustprogress"}
!94 = !DILocation(line: 47, column: 1, scope: !66)
!95 = distinct !DISubprogram(name: "task_job_polybench", scope: !10, file: !10, line: 120, type: !14, scopeLine: 120, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !2, retainedNodes: !53)
!96 = !DILocation(line: 121, column: 18, scope: !95)
!97 = !DILocalVariable(name: "n", arg: 1, scope: !98, file: !10, line: 73, type: !41)
!98 = distinct !DISubprogram(name: "kernel_durbin", scope: !10, file: !10, line: 73, type: !99, scopeLine: 76, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition, unit: !2, retainedNodes: !53)
!99 = !DISubroutineType(types: !100)
!100 = !{null, !41, !69, !69}
!101 = !DILocation(line: 0, scope: !98, inlinedAt: !102)
!102 = distinct !DILocation(line: 121, column: 3, scope: !95)
!103 = !DILocalVariable(name: "r", arg: 2, scope: !98, file: !10, line: 74, type: !69)
!104 = !DILocalVariable(name: "y", arg: 3, scope: !98, file: !10, line: 75, type: !69)
!105 = !DILocation(line: 85, column: 10, scope: !98, inlinedAt: !102)
!106 = !DILocation(line: 85, column: 9, scope: !98, inlinedAt: !102)
!107 = !DILocation(line: 85, column: 7, scope: !98, inlinedAt: !102)
!108 = !DILocalVariable(name: "beta", scope: !98, file: !10, line: 79, type: !32)
!109 = !DILocation(line: 87, column: 11, scope: !98, inlinedAt: !102)
!110 = !DILocation(line: 87, column: 10, scope: !98, inlinedAt: !102)
!111 = !DILocalVariable(name: "alpha", scope: !98, file: !10, line: 78, type: !32)
!112 = !DILocalVariable(name: "k", scope: !98, file: !10, line: 82, type: !41)
!113 = !DILocation(line: 89, column: 7, scope: !114, inlinedAt: !102)
!114 = distinct !DILexicalBlock(scope: !98, file: !10, line: 89, column: 2)
!115 = !DILocation(line: 0, scope: !114, inlinedAt: !102)
!116 = !DILocation(line: 89, column: 16, scope: !117, inlinedAt: !102)
!117 = distinct !DILexicalBlock(scope: !114, file: !10, line: 89, column: 2)
!118 = !DILocation(line: 89, column: 2, scope: !114, inlinedAt: !102)
!119 = !DILocation(line: 90, column: 19, scope: !120, inlinedAt: !102)
!120 = distinct !DILexicalBlock(scope: !117, file: !10, line: 89, column: 30)
!121 = !DILocation(line: 90, column: 13, scope: !120, inlinedAt: !102)
!122 = !DILocation(line: 90, column: 26, scope: !120, inlinedAt: !102)
!123 = !DILocalVariable(name: "sum", scope: !98, file: !10, line: 80, type: !32)
!124 = !DILocalVariable(name: "i", scope: !98, file: !10, line: 82, type: !41)
!125 = !DILocation(line: 92, column: 9, scope: !126, inlinedAt: !102)
!126 = distinct !DILexicalBlock(scope: !120, file: !10, line: 92, column: 4)
!127 = !DILocation(line: 0, scope: !120, inlinedAt: !102)
!128 = !DILocation(line: 0, scope: !126, inlinedAt: !102)
!129 = !DILocation(line: 92, column: 15, scope: !130, inlinedAt: !102)
!130 = distinct !DILexicalBlock(scope: !126, file: !10, line: 92, column: 4)
!131 = !DILocation(line: 92, column: 4, scope: !126, inlinedAt: !102)
!132 = !DILocation(line: 93, column: 17, scope: !133, inlinedAt: !102)
!133 = distinct !DILexicalBlock(scope: !130, file: !10, line: 92, column: 24)
!134 = !DILocation(line: 93, column: 19, scope: !133, inlinedAt: !102)
!135 = !DILocation(line: 93, column: 14, scope: !133, inlinedAt: !102)
!136 = !DILocation(line: 93, column: 23, scope: !133, inlinedAt: !102)
!137 = !DILocation(line: 93, column: 22, scope: !133, inlinedAt: !102)
!138 = !DILocation(line: 93, column: 11, scope: !133, inlinedAt: !102)
!139 = !DILocation(line: 92, column: 20, scope: !130, inlinedAt: !102)
!140 = !DILocation(line: 92, column: 4, scope: !130, inlinedAt: !102)
!141 = distinct !{!141, !131, !142, !93}
!142 = !DILocation(line: 94, column: 4, scope: !126, inlinedAt: !102)
!143 = !DILocation(line: 95, column: 15, scope: !120, inlinedAt: !102)
!144 = !DILocation(line: 95, column: 20, scope: !120, inlinedAt: !102)
!145 = !DILocation(line: 95, column: 12, scope: !120, inlinedAt: !102)
!146 = !DILocation(line: 95, column: 26, scope: !120, inlinedAt: !102)
!147 = !DILocation(line: 97, column: 9, scope: !148, inlinedAt: !102)
!148 = distinct !DILexicalBlock(scope: !120, file: !10, line: 97, column: 4)
!149 = !DILocation(line: 0, scope: !148, inlinedAt: !102)
!150 = !DILocation(line: 97, column: 15, scope: !151, inlinedAt: !102)
!151 = distinct !DILexicalBlock(scope: !148, file: !10, line: 97, column: 4)
!152 = !DILocation(line: 97, column: 4, scope: !148, inlinedAt: !102)
!153 = !DILocation(line: 98, column: 14, scope: !154, inlinedAt: !102)
!154 = distinct !DILexicalBlock(scope: !151, file: !10, line: 97, column: 24)
!155 = !DILocation(line: 98, column: 30, scope: !154, inlinedAt: !102)
!156 = !DILocation(line: 98, column: 32, scope: !154, inlinedAt: !102)
!157 = !DILocation(line: 98, column: 27, scope: !154, inlinedAt: !102)
!158 = !DILocation(line: 98, column: 26, scope: !154, inlinedAt: !102)
!159 = !DILocation(line: 98, column: 19, scope: !154, inlinedAt: !102)
!160 = !DILocation(line: 98, column: 7, scope: !154, inlinedAt: !102)
!161 = !DILocation(line: 98, column: 12, scope: !154, inlinedAt: !102)
!162 = !DILocation(line: 97, column: 20, scope: !151, inlinedAt: !102)
!163 = !DILocation(line: 97, column: 4, scope: !151, inlinedAt: !102)
!164 = distinct !{!164, !152, !165, !93}
!165 = !DILocation(line: 99, column: 4, scope: !148, inlinedAt: !102)
!166 = !DILocation(line: 100, column: 9, scope: !167, inlinedAt: !102)
!167 = distinct !DILexicalBlock(scope: !120, file: !10, line: 100, column: 4)
!168 = !DILocation(line: 0, scope: !167, inlinedAt: !102)
!169 = !DILocation(line: 100, column: 15, scope: !170, inlinedAt: !102)
!170 = distinct !DILexicalBlock(scope: !167, file: !10, line: 100, column: 4)
!171 = !DILocation(line: 100, column: 4, scope: !167, inlinedAt: !102)
!172 = !DILocation(line: 101, column: 13, scope: !173, inlinedAt: !102)
!173 = distinct !DILexicalBlock(scope: !170, file: !10, line: 100, column: 24)
!174 = !DILocation(line: 101, column: 6, scope: !173, inlinedAt: !102)
!175 = !DILocation(line: 101, column: 11, scope: !173, inlinedAt: !102)
!176 = !DILocation(line: 100, column: 20, scope: !170, inlinedAt: !102)
!177 = !DILocation(line: 100, column: 4, scope: !170, inlinedAt: !102)
!178 = distinct !{!178, !171, !179, !93}
!179 = !DILocation(line: 102, column: 4, scope: !167, inlinedAt: !102)
!180 = !DILocation(line: 103, column: 4, scope: !120, inlinedAt: !102)
!181 = !DILocation(line: 103, column: 9, scope: !120, inlinedAt: !102)
!182 = !DILocation(line: 89, column: 26, scope: !117, inlinedAt: !102)
!183 = !DILocation(line: 89, column: 2, scope: !117, inlinedAt: !102)
!184 = distinct !{!184, !118, !185, !93}
!185 = !DILocation(line: 104, column: 2, scope: !114, inlinedAt: !102)
!186 = !DILocation(line: 124, column: 3, scope: !95)
!187 = distinct !DISubprogram(name: "workload_checksum", scope: !10, file: !10, line: 126, type: !188, scopeLine: 126, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !2, retainedNodes: !53)
!188 = !DISubroutineType(types: !189)
!189 = !{!16, !5}
!190 = !DILocalVariable(name: "task", arg: 1, scope: !187, file: !10, line: 126, type: !5)
!191 = !DILocation(line: 0, scope: !187)
!192 = !DILocation(line: 128, column: 11, scope: !187)
!193 = !DILocation(line: 129, column: 15, scope: !187)
!194 = !DILocation(line: 129, column: 3, scope: !187)
!195 = !DILocation(line: 130, column: 10, scope: !187)
!196 = !DILocation(line: 130, column: 3, scope: !187)
!197 = distinct !DISubprogram(name: "print_array", scope: !10, file: !10, line: 53, type: !67, scopeLine: 56, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition, unit: !2, retainedNodes: !53)
!198 = !DILocalVariable(name: "n", arg: 1, scope: !197, file: !10, line: 53, type: !41)
!199 = !DILocation(line: 0, scope: !197)
!200 = !DILocalVariable(name: "y", arg: 2, scope: !197, file: !10, line: 54, type: !69)
!201 = !DILocation(line: 59, column: 3, scope: !197)
!202 = !DILocation(line: 60, column: 3, scope: !197)
!203 = !DILocalVariable(name: "i", scope: !197, file: !10, line: 57, type: !41)
!204 = !DILocation(line: 61, column: 8, scope: !205)
!205 = distinct !DILexicalBlock(scope: !197, file: !10, line: 61, column: 3)
!206 = !DILocation(line: 0, scope: !205)
!207 = !DILocation(line: 61, column: 17, scope: !208)
!208 = distinct !DILexicalBlock(scope: !205, file: !10, line: 61, column: 3)
!209 = !DILocation(line: 61, column: 3, scope: !205)
!210 = !DILocation(line: 62, column: 11, scope: !211)
!211 = distinct !DILexicalBlock(scope: !212, file: !10, line: 62, column: 9)
!212 = distinct !DILexicalBlock(scope: !208, file: !10, line: 61, column: 27)
!213 = !DILocation(line: 62, column: 16, scope: !211)
!214 = !DILocation(line: 62, column: 9, scope: !212)
!215 = !DILocation(line: 62, column: 31, scope: !211)
!216 = !DILocation(line: 62, column: 22, scope: !211)
!217 = !DILocation(line: 63, column: 14, scope: !212)
!218 = !DILocation(line: 63, column: 59, scope: !212)
!219 = !DILocation(line: 63, column: 5, scope: !212)
!220 = !DILocation(line: 64, column: 3, scope: !212)
!221 = !DILocation(line: 61, column: 23, scope: !208)
!222 = !DILocation(line: 61, column: 3, scope: !208)
!223 = distinct !{!223, !209, !224, !93}
!224 = !DILocation(line: 64, column: 3, scope: !205)
!225 = !DILocation(line: 65, column: 3, scope: !197)
!226 = !DILocation(line: 66, column: 3, scope: !197)
!227 = !DILocation(line: 67, column: 1, scope: !197)
!228 = distinct !DISubprogram(name: "pb_fprintf", scope: !28, file: !28, line: 13, type: !229, scopeLine: 14, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition, unit: !2, retainedNodes: !53)
!229 = !DISubroutineType(types: !230)
!230 = !{!41, !231, !290, null}
!231 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !232, size: 64)
!232 = !DIDerivedType(tag: DW_TAG_typedef, name: "FILE", file: !233, line: 7, baseType: !234)
!233 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/types/FILE.h", directory: "", checksumkind: CSK_MD5, checksum: "571f9fb6223c42439075fdde11a0de5d")
!234 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "_IO_FILE", file: !235, line: 49, size: 1728, elements: !236)
!235 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/types/struct_FILE.h", directory: "", checksumkind: CSK_MD5, checksum: "1bad07471b7974df4ecc1d1c2ca207e6")
!236 = !{!237, !238, !241, !242, !243, !244, !245, !246, !247, !248, !249, !250, !251, !254, !256, !257, !258, !261, !263, !265, !267, !270, !272, !275, !278, !279, !281, !285, !286}
!237 = !DIDerivedType(tag: DW_TAG_member, name: "_flags", scope: !234, file: !235, line: 51, baseType: !41, size: 32)
!238 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_read_ptr", scope: !234, file: !235, line: 54, baseType: !239, size: 64, offset: 64)
!239 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !240, size: 64)
!240 = !DIBasicType(name: "char", size: 8, encoding: DW_ATE_signed_char)
!241 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_read_end", scope: !234, file: !235, line: 55, baseType: !239, size: 64, offset: 128)
!242 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_read_base", scope: !234, file: !235, line: 56, baseType: !239, size: 64, offset: 192)
!243 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_write_base", scope: !234, file: !235, line: 57, baseType: !239, size: 64, offset: 256)
!244 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_write_ptr", scope: !234, file: !235, line: 58, baseType: !239, size: 64, offset: 320)
!245 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_write_end", scope: !234, file: !235, line: 59, baseType: !239, size: 64, offset: 384)
!246 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_buf_base", scope: !234, file: !235, line: 60, baseType: !239, size: 64, offset: 448)
!247 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_buf_end", scope: !234, file: !235, line: 61, baseType: !239, size: 64, offset: 512)
!248 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_save_base", scope: !234, file: !235, line: 64, baseType: !239, size: 64, offset: 576)
!249 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_backup_base", scope: !234, file: !235, line: 65, baseType: !239, size: 64, offset: 640)
!250 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_save_end", scope: !234, file: !235, line: 66, baseType: !239, size: 64, offset: 704)
!251 = !DIDerivedType(tag: DW_TAG_member, name: "_markers", scope: !234, file: !235, line: 68, baseType: !252, size: 64, offset: 768)
!252 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !253, size: 64)
!253 = !DICompositeType(tag: DW_TAG_structure_type, name: "_IO_marker", file: !235, line: 36, flags: DIFlagFwdDecl)
!254 = !DIDerivedType(tag: DW_TAG_member, name: "_chain", scope: !234, file: !235, line: 70, baseType: !255, size: 64, offset: 832)
!255 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !234, size: 64)
!256 = !DIDerivedType(tag: DW_TAG_member, name: "_fileno", scope: !234, file: !235, line: 72, baseType: !41, size: 32, offset: 896)
!257 = !DIDerivedType(tag: DW_TAG_member, name: "_flags2", scope: !234, file: !235, line: 73, baseType: !41, size: 32, offset: 928)
!258 = !DIDerivedType(tag: DW_TAG_member, name: "_old_offset", scope: !234, file: !235, line: 74, baseType: !259, size: 64, offset: 960)
!259 = !DIDerivedType(tag: DW_TAG_typedef, name: "__off_t", file: !19, line: 152, baseType: !260)
!260 = !DIBasicType(name: "long", size: 64, encoding: DW_ATE_signed)
!261 = !DIDerivedType(tag: DW_TAG_member, name: "_cur_column", scope: !234, file: !235, line: 77, baseType: !262, size: 16, offset: 1024)
!262 = !DIBasicType(name: "unsigned short", size: 16, encoding: DW_ATE_unsigned)
!263 = !DIDerivedType(tag: DW_TAG_member, name: "_vtable_offset", scope: !234, file: !235, line: 78, baseType: !264, size: 8, offset: 1040)
!264 = !DIBasicType(name: "signed char", size: 8, encoding: DW_ATE_signed_char)
!265 = !DIDerivedType(tag: DW_TAG_member, name: "_shortbuf", scope: !234, file: !235, line: 79, baseType: !266, size: 8, offset: 1048)
!266 = !DICompositeType(tag: DW_TAG_array_type, baseType: !240, size: 8, elements: !20)
!267 = !DIDerivedType(tag: DW_TAG_member, name: "_lock", scope: !234, file: !235, line: 81, baseType: !268, size: 64, offset: 1088)
!268 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !269, size: 64)
!269 = !DIDerivedType(tag: DW_TAG_typedef, name: "_IO_lock_t", file: !235, line: 43, baseType: null)
!270 = !DIDerivedType(tag: DW_TAG_member, name: "_offset", scope: !234, file: !235, line: 89, baseType: !271, size: 64, offset: 1152)
!271 = !DIDerivedType(tag: DW_TAG_typedef, name: "__off64_t", file: !19, line: 153, baseType: !260)
!272 = !DIDerivedType(tag: DW_TAG_member, name: "_codecvt", scope: !234, file: !235, line: 91, baseType: !273, size: 64, offset: 1216)
!273 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !274, size: 64)
!274 = !DICompositeType(tag: DW_TAG_structure_type, name: "_IO_codecvt", file: !235, line: 37, flags: DIFlagFwdDecl)
!275 = !DIDerivedType(tag: DW_TAG_member, name: "_wide_data", scope: !234, file: !235, line: 92, baseType: !276, size: 64, offset: 1280)
!276 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !277, size: 64)
!277 = !DICompositeType(tag: DW_TAG_structure_type, name: "_IO_wide_data", file: !235, line: 38, flags: DIFlagFwdDecl)
!278 = !DIDerivedType(tag: DW_TAG_member, name: "_freeres_list", scope: !234, file: !235, line: 93, baseType: !255, size: 64, offset: 1344)
!279 = !DIDerivedType(tag: DW_TAG_member, name: "_freeres_buf", scope: !234, file: !235, line: 94, baseType: !280, size: 64, offset: 1408)
!280 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: null, size: 64)
!281 = !DIDerivedType(tag: DW_TAG_member, name: "__pad5", scope: !234, file: !235, line: 95, baseType: !282, size: 64, offset: 1472)
!282 = !DIDerivedType(tag: DW_TAG_typedef, name: "size_t", file: !283, line: 46, baseType: !284)
!283 = !DIFile(filename: "/usr/lib/llvm-14/lib/clang/14.0.0/include/stddef.h", directory: "", checksumkind: CSK_MD5, checksum: "2499dd2361b915724b073282bea3a7bc")
!284 = !DIBasicType(name: "unsigned long", size: 64, encoding: DW_ATE_unsigned)
!285 = !DIDerivedType(tag: DW_TAG_member, name: "_mode", scope: !234, file: !235, line: 96, baseType: !41, size: 32, offset: 1536)
!286 = !DIDerivedType(tag: DW_TAG_member, name: "_unused2", scope: !234, file: !235, line: 98, baseType: !287, size: 160, offset: 1568)
!287 = !DICompositeType(tag: DW_TAG_array_type, baseType: !240, size: 160, elements: !288)
!288 = !{!289}
!289 = !DISubrange(count: 20)
!290 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !291, size: 64)
!291 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !240)
!292 = !DILocalVariable(name: "stream", arg: 1, scope: !228, file: !28, line: 13, type: !231)
!293 = !DILocation(line: 0, scope: !228)
!294 = !DILocalVariable(name: "format", arg: 2, scope: !228, file: !28, line: 13, type: !290)
!295 = !DILocalVariable(name: "buffer", scope: !228, file: !28, line: 15, type: !296)
!296 = !DICompositeType(tag: DW_TAG_array_type, baseType: !240, size: 6144, elements: !297)
!297 = !{!298}
!298 = !DISubrange(count: 768)
!299 = !DILocation(line: 15, column: 10, scope: !228)
!300 = !DILocalVariable(name: "args", scope: !228, file: !28, line: 16, type: !301)
!301 = !DIDerivedType(tag: DW_TAG_typedef, name: "va_list", file: !302, line: 52, baseType: !303)
!302 = !DIFile(filename: "/usr/include/stdio.h", directory: "", checksumkind: CSK_MD5, checksum: "f31eefcc3f15835fc5a4023a625cf609")
!303 = !DIDerivedType(tag: DW_TAG_typedef, name: "__gnuc_va_list", file: !304, line: 32, baseType: !305)
!304 = !DIFile(filename: "/usr/lib/llvm-14/lib/clang/14.0.0/include/stdarg.h", directory: "", checksumkind: CSK_MD5, checksum: "4de3cbd931b589d291e5c39387aecf82")
!305 = !DIDerivedType(tag: DW_TAG_typedef, name: "__builtin_va_list", file: !306, baseType: !307)
!306 = !DIFile(filename: "source/workload.c", directory: "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/affine-bounds-20260929/suite/durbin")
!307 = !DICompositeType(tag: DW_TAG_array_type, baseType: !308, size: 192, elements: !20)
!308 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "__va_list_tag", size: 192, elements: !309)
!309 = !{!310, !311, !312, !313}
!310 = !DIDerivedType(tag: DW_TAG_member, name: "gp_offset", scope: !308, file: !306, line: 16, baseType: !5, size: 32)
!311 = !DIDerivedType(tag: DW_TAG_member, name: "fp_offset", scope: !308, file: !306, line: 16, baseType: !5, size: 32, offset: 32)
!312 = !DIDerivedType(tag: DW_TAG_member, name: "overflow_arg_area", scope: !308, file: !306, line: 16, baseType: !280, size: 64, offset: 64)
!313 = !DIDerivedType(tag: DW_TAG_member, name: "reg_save_area", scope: !308, file: !306, line: 16, baseType: !280, size: 64, offset: 128)
!314 = !DILocation(line: 16, column: 13, scope: !228)
!315 = !DILocation(line: 17, column: 5, scope: !228)
!316 = !DILocation(line: 18, column: 27, scope: !228)
!317 = !DILocation(line: 18, column: 59, scope: !228)
!318 = !DILocation(line: 18, column: 17, scope: !228)
!319 = !DILocalVariable(name: "count", scope: !228, file: !28, line: 18, type: !41)
!320 = !DILocation(line: 19, column: 5, scope: !228)
!321 = !DILocation(line: 20, column: 15, scope: !322)
!322 = distinct !DILexicalBlock(scope: !228, file: !28, line: 20, column: 9)
!323 = !DILocation(line: 20, column: 19, scope: !322)
!324 = !DILocation(line: 20, column: 22, scope: !322)
!325 = !DILocation(line: 20, column: 38, scope: !322)
!326 = !DILocation(line: 20, column: 9, scope: !228)
!327 = !DILocation(line: 20, column: 57, scope: !322)
!328 = !DILocalVariable(name: "i", scope: !329, file: !28, line: 21, type: !41)
!329 = distinct !DILexicalBlock(scope: !228, file: !28, line: 21, column: 5)
!330 = !DILocation(line: 0, scope: !329)
!331 = !DILocation(line: 21, column: 10, scope: !329)
!332 = !DILocation(line: 21, column: 23, scope: !333)
!333 = distinct !DILexicalBlock(scope: !329, file: !28, line: 21, column: 5)
!334 = !DILocation(line: 21, column: 5, scope: !329)
!335 = !DILocation(line: 22, column: 35, scope: !336)
!336 = distinct !DILexicalBlock(scope: !333, file: !28, line: 21, column: 37)
!337 = !DILocation(line: 22, column: 20, scope: !336)
!338 = !DILocation(line: 22, column: 17, scope: !336)
!339 = !DILocation(line: 23, column: 17, scope: !336)
!340 = !DILocation(line: 24, column: 5, scope: !336)
!341 = !DILocation(line: 21, column: 32, scope: !333)
!342 = !DILocation(line: 21, column: 5, scope: !333)
!343 = distinct !{!343, !334, !344, !93}
!344 = !DILocation(line: 24, column: 5, scope: !329)
!345 = !DILocation(line: 29, column: 11, scope: !228)
!346 = !DILocation(line: 31, column: 5, scope: !228)
