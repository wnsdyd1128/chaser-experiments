; ModuleID = 'inlined.ll'
source_filename = "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/affine-bounds-20260929/suite/durbin/source/workload.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

@n = external dso_local global i32, align 4, !dbg !0
@r = external dso_local global [400 x double], section ".chaser_data.r", align 64, !dbg !8
@y = external dso_local global [400 x double], section ".chaser_data.y", align 64, !dbg !15
@z = external dso_local global [400 x double], section ".chaser_data.z", align 64, !dbg !17
@.str = hidden unnamed_addr constant [12 x i8] c"ape.analyze\00", section "llvm.metadata"
@.str.1 = hidden unnamed_addr constant [124 x i8] c"/workspace/experiments-array-support/chaser/.cache/periodic-polybench/affine-bounds-20260929/suite/durbin/source/workload.c\00", section "llvm.metadata"
@.str.2 = hidden unnamed_addr constant [23 x i8] c"==BEGIN DUMP_ARRAYS==\0A\00", align 1
@.str.3 = hidden unnamed_addr constant [15 x i8] c"begin dump: %s\00", align 1
@.str.4 = hidden unnamed_addr constant [2 x i8] c"y\00", align 1
@.str.5 = hidden unnamed_addr constant [2 x i8] c"\0A\00", align 1
@.str.6 = hidden unnamed_addr constant [8 x i8] c"%0.2lf \00", align 1
@.str.7 = hidden unnamed_addr constant [17 x i8] c"\0Aend   dump: %s\0A\00", align 1
@.str.8 = hidden unnamed_addr constant [23 x i8] c"==END   DUMP_ARRAYS==\0A\00", align 1
@llvm.global.annotations = appending global [1 x { i8*, i8*, i8*, i32, i8* }] [{ i8*, i8*, i8*, i32, i8* } { i8* bitcast (i32 ()* @task_job_polybench to i8*), i8* getelementptr inbounds ([12 x i8], [12 x i8]* @.str, i32 0, i32 0), i8* getelementptr inbounds ([124 x i8], [124 x i8]* @.str.1, i32 0, i32 0), i32 120, i8* null }], section "llvm.metadata"

; Function Attrs: noinline nounwind uwtable
define dso_local i32 @task_job_polybench() #0 !dbg !28 {
  %1 = load i32, i32* @n, align 4, !dbg !36
  call void @llvm.dbg.value(metadata i32 %1, metadata !37, metadata !DIExpression()), !dbg !42
  call void @llvm.dbg.value(metadata double* getelementptr inbounds ([400 x double], [400 x double]* @r, i64 0, i64 0), metadata !44, metadata !DIExpression()), !dbg !42
  call void @llvm.dbg.value(metadata double* getelementptr inbounds ([400 x double], [400 x double]* @y, i64 0, i64 0), metadata !45, metadata !DIExpression()), !dbg !42
  %2 = load double, double* getelementptr inbounds ([400 x double], [400 x double]* @r, i64 0, i64 0), align 8, !dbg !46
  %3 = fneg double %2, !dbg !47
  store double %3, double* getelementptr inbounds ([400 x double], [400 x double]* @y, i64 0, i64 0), align 8, !dbg !48
  call void @llvm.dbg.value(metadata double 1.000000e+00, metadata !49, metadata !DIExpression()), !dbg !42
  %4 = load double, double* getelementptr inbounds ([400 x double], [400 x double]* @r, i64 0, i64 0), align 8, !dbg !50
  %5 = fneg double %4, !dbg !51
  call void @llvm.dbg.value(metadata double %5, metadata !52, metadata !DIExpression()), !dbg !42
  call void @llvm.dbg.value(metadata i32 1, metadata !53, metadata !DIExpression()), !dbg !42
  br label %6, !dbg !54

6:                                                ; preds = %59, %0
  %.04 = phi double [ 1.000000e+00, %0 ], [ %11, %59 ], !dbg !42
  %.03 = phi double [ %5, %0 ], [ %32, %59 ], !dbg !42
  %.0 = phi i32 [ 1, %0 ], [ %62, %59 ], !dbg !56
  call void @llvm.dbg.value(metadata i32 %.0, metadata !53, metadata !DIExpression()), !dbg !42
  call void @llvm.dbg.value(metadata double %.03, metadata !52, metadata !DIExpression()), !dbg !42
  call void @llvm.dbg.value(metadata double %.04, metadata !49, metadata !DIExpression()), !dbg !42
  %7 = icmp slt i32 %.0, 400, !dbg !57
  br i1 %7, label %8, label %63, !dbg !59

8:                                                ; preds = %6
  %9 = fmul double %.03, %.03, !dbg !60
  %10 = fsub double 1.000000e+00, %9, !dbg !62
  %11 = fmul double %10, %.04, !dbg !63
  call void @llvm.dbg.value(metadata double %11, metadata !49, metadata !DIExpression()), !dbg !42
  call void @llvm.dbg.value(metadata double 0.000000e+00, metadata !64, metadata !DIExpression()), !dbg !42
  call void @llvm.dbg.value(metadata i32 0, metadata !65, metadata !DIExpression()), !dbg !42
  br label %12, !dbg !66

12:                                               ; preds = %14, %8
  %.02 = phi double [ 0.000000e+00, %8 ], [ %24, %14 ], !dbg !68
  %.01 = phi i32 [ 0, %8 ], [ %25, %14 ], !dbg !69
  call void @llvm.dbg.value(metadata i32 %.01, metadata !65, metadata !DIExpression()), !dbg !42
  call void @llvm.dbg.value(metadata double %.02, metadata !64, metadata !DIExpression()), !dbg !42
  %13 = icmp slt i32 %.01, %.0, !dbg !70
  br i1 %13, label %14, label %26, !dbg !72

14:                                               ; preds = %12
  %15 = sub nsw i32 %.0, %.01, !dbg !73
  %16 = sub nsw i32 %15, 1, !dbg !75
  %17 = sext i32 %16 to i64, !dbg !76
  %18 = getelementptr inbounds double, double* getelementptr inbounds ([400 x double], [400 x double]* @r, i64 0, i64 0), i64 %17, !dbg !76
  %19 = load double, double* %18, align 8, !dbg !76
  %20 = sext i32 %.01 to i64, !dbg !77
  %21 = getelementptr inbounds double, double* getelementptr inbounds ([400 x double], [400 x double]* @y, i64 0, i64 0), i64 %20, !dbg !77
  %22 = load double, double* %21, align 8, !dbg !77
  %23 = fmul double %19, %22, !dbg !78
  %24 = fadd double %.02, %23, !dbg !79
  call void @llvm.dbg.value(metadata double %24, metadata !64, metadata !DIExpression()), !dbg !42
  %25 = add nsw i32 %.01, 1, !dbg !80
  call void @llvm.dbg.value(metadata i32 %25, metadata !65, metadata !DIExpression()), !dbg !42
  br label %12, !dbg !81, !llvm.loop !82

26:                                               ; preds = %12
  %27 = sext i32 %.0 to i64, !dbg !85
  %28 = getelementptr inbounds double, double* getelementptr inbounds ([400 x double], [400 x double]* @r, i64 0, i64 0), i64 %27, !dbg !85
  %29 = load double, double* %28, align 8, !dbg !85
  %30 = fadd double %29, %.02, !dbg !86
  %31 = fneg double %30, !dbg !87
  %32 = fdiv double %31, %11, !dbg !88
  call void @llvm.dbg.value(metadata double %32, metadata !52, metadata !DIExpression()), !dbg !42
  call void @llvm.dbg.value(metadata i32 0, metadata !65, metadata !DIExpression()), !dbg !42
  br label %33, !dbg !89

33:                                               ; preds = %35, %26
  %.1 = phi i32 [ 0, %26 ], [ %48, %35 ], !dbg !91
  call void @llvm.dbg.value(metadata i32 %.1, metadata !65, metadata !DIExpression()), !dbg !42
  %34 = icmp slt i32 %.1, %.0, !dbg !92
  br i1 %34, label %35, label %49, !dbg !94

35:                                               ; preds = %33
  %36 = sext i32 %.1 to i64, !dbg !95
  %37 = getelementptr inbounds double, double* getelementptr inbounds ([400 x double], [400 x double]* @y, i64 0, i64 0), i64 %36, !dbg !95
  %38 = load double, double* %37, align 8, !dbg !95
  %39 = sub nsw i32 %.0, %.1, !dbg !97
  %40 = sub nsw i32 %39, 1, !dbg !98
  %41 = sext i32 %40 to i64, !dbg !99
  %42 = getelementptr inbounds double, double* getelementptr inbounds ([400 x double], [400 x double]* @y, i64 0, i64 0), i64 %41, !dbg !99
  %43 = load double, double* %42, align 8, !dbg !99
  %44 = fmul double %32, %43, !dbg !100
  %45 = fadd double %38, %44, !dbg !101
  %46 = sext i32 %.1 to i64, !dbg !102
  %47 = getelementptr inbounds [400 x double], [400 x double]* @z, i64 0, i64 %46, !dbg !102
  store double %45, double* %47, align 8, !dbg !103
  %48 = add nsw i32 %.1, 1, !dbg !104
  call void @llvm.dbg.value(metadata i32 %48, metadata !65, metadata !DIExpression()), !dbg !42
  br label %33, !dbg !105, !llvm.loop !106

49:                                               ; preds = %33
  call void @llvm.dbg.value(metadata i32 0, metadata !65, metadata !DIExpression()), !dbg !42
  br label %50, !dbg !108

50:                                               ; preds = %52, %49
  %.2 = phi i32 [ 0, %49 ], [ %58, %52 ], !dbg !110
  call void @llvm.dbg.value(metadata i32 %.2, metadata !65, metadata !DIExpression()), !dbg !42
  %51 = icmp slt i32 %.2, %.0, !dbg !111
  br i1 %51, label %52, label %59, !dbg !113

52:                                               ; preds = %50
  %53 = sext i32 %.2 to i64, !dbg !114
  %54 = getelementptr inbounds [400 x double], [400 x double]* @z, i64 0, i64 %53, !dbg !114
  %55 = load double, double* %54, align 8, !dbg !114
  %56 = sext i32 %.2 to i64, !dbg !116
  %57 = getelementptr inbounds double, double* getelementptr inbounds ([400 x double], [400 x double]* @y, i64 0, i64 0), i64 %56, !dbg !116
  store double %55, double* %57, align 8, !dbg !117
  %58 = add nsw i32 %.2, 1, !dbg !118
  call void @llvm.dbg.value(metadata i32 %58, metadata !65, metadata !DIExpression()), !dbg !42
  br label %50, !dbg !119, !llvm.loop !120

59:                                               ; preds = %50
  %60 = sext i32 %.0 to i64, !dbg !122
  %61 = getelementptr inbounds double, double* getelementptr inbounds ([400 x double], [400 x double]* @y, i64 0, i64 0), i64 %60, !dbg !122
  store double %32, double* %61, align 8, !dbg !123
  %62 = add nsw i32 %.0, 1, !dbg !124
  call void @llvm.dbg.value(metadata i32 %62, metadata !53, metadata !DIExpression()), !dbg !42
  br label %6, !dbg !125, !llvm.loop !126

63:                                               ; preds = %6
  ret i32 0, !dbg !128
}

; Function Attrs: nofree nosync nounwind readnone speculatable willreturn
declare void @llvm.dbg.value(metadata, metadata, metadata) #1

attributes #0 = { noinline nounwind uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { nofree nosync nounwind readnone speculatable willreturn }

!llvm.dbg.cu = !{!2}
!llvm.module.flags = !{!20, !21, !22, !23, !24, !25, !26}
!llvm.ident = !{!27}

!0 = !DIGlobalVariableExpression(var: !1, expr: !DIExpression())
!1 = distinct !DIGlobalVariable(name: "n", scope: !2, file: !10, line: 111, type: !19, isLocal: false, isDefinition: true)
!2 = distinct !DICompileUnit(language: DW_LANG_C99, file: !3, producer: "Ubuntu clang version 14.0.0-1ubuntu1.1", isOptimized: false, runtimeVersion: 0, emissionKind: FullDebug, retainedTypes: !4, globals: !7, splitDebugInlining: false, nameTableKind: None)
!3 = !DIFile(filename: "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/affine-bounds-20260929/suite/durbin/source/workload.c", directory: "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/affine-bounds-20260929/suite/durbin/analysis-native", checksumkind: CSK_MD5, checksum: "70112e389066249fa1577d58e2d004e2")
!4 = !{!5, !6}
!5 = !DIBasicType(name: "unsigned int", size: 32, encoding: DW_ATE_unsigned)
!6 = !DIBasicType(name: "unsigned char", size: 8, encoding: DW_ATE_unsigned_char)
!7 = !{!0, !8, !15, !17}
!8 = !DIGlobalVariableExpression(var: !9, expr: !DIExpression())
!9 = distinct !DIGlobalVariable(name: "r", scope: !2, file: !10, line: 34, type: !11, isLocal: false, isDefinition: true, align: 512)
!10 = !DIFile(filename: "source/workload.c", directory: "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/affine-bounds-20260929/suite/durbin", checksumkind: CSK_MD5, checksum: "70112e389066249fa1577d58e2d004e2")
!11 = !DICompositeType(tag: DW_TAG_array_type, baseType: !12, size: 25600, elements: !13)
!12 = !DIBasicType(name: "double", size: 64, encoding: DW_ATE_float)
!13 = !{!14}
!14 = !DISubrange(count: 400)
!15 = !DIGlobalVariableExpression(var: !16, expr: !DIExpression())
!16 = distinct !DIGlobalVariable(name: "y", scope: !2, file: !10, line: 35, type: !11, isLocal: false, isDefinition: true, align: 512)
!17 = !DIGlobalVariableExpression(var: !18, expr: !DIExpression())
!18 = distinct !DIGlobalVariable(name: "z", scope: !2, file: !10, line: 36, type: !11, isLocal: false, isDefinition: true, align: 512)
!19 = !DIBasicType(name: "int", size: 32, encoding: DW_ATE_signed)
!20 = !{i32 7, !"Dwarf Version", i32 5}
!21 = !{i32 2, !"Debug Info Version", i32 3}
!22 = !{i32 1, !"wchar_size", i32 4}
!23 = !{i32 7, !"PIC Level", i32 2}
!24 = !{i32 7, !"PIE Level", i32 2}
!25 = !{i32 7, !"uwtable", i32 1}
!26 = !{i32 7, !"frame-pointer", i32 2}
!27 = !{!"Ubuntu clang version 14.0.0-1ubuntu1.1"}
!28 = distinct !DISubprogram(name: "task_job_polybench", scope: !10, file: !10, line: 120, type: !29, scopeLine: 120, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !2, retainedNodes: !35)
!29 = !DISubroutineType(types: !30)
!30 = !{!31}
!31 = !DIDerivedType(tag: DW_TAG_typedef, name: "uint32_t", file: !32, line: 26, baseType: !33)
!32 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/stdint-uintn.h", directory: "", checksumkind: CSK_MD5, checksum: "2bf2ae53c58c01b1a1b9383b5195125c")
!33 = !DIDerivedType(tag: DW_TAG_typedef, name: "__uint32_t", file: !34, line: 42, baseType: !5)
!34 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/types.h", directory: "", checksumkind: CSK_MD5, checksum: "d108b5f93a74c50510d7d9bc0ab36df9")
!35 = !{}
!36 = !DILocation(line: 121, column: 18, scope: !28)
!37 = !DILocalVariable(name: "n", arg: 1, scope: !38, file: !10, line: 73, type: !19)
!38 = distinct !DISubprogram(name: "kernel_durbin", scope: !10, file: !10, line: 73, type: !39, scopeLine: 76, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition, unit: !2, retainedNodes: !35)
!39 = !DISubroutineType(types: !40)
!40 = !{null, !19, !41, !41}
!41 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !12, size: 64)
!42 = !DILocation(line: 0, scope: !38, inlinedAt: !43)
!43 = distinct !DILocation(line: 121, column: 3, scope: !28)
!44 = !DILocalVariable(name: "r", arg: 2, scope: !38, file: !10, line: 74, type: !41)
!45 = !DILocalVariable(name: "y", arg: 3, scope: !38, file: !10, line: 75, type: !41)
!46 = !DILocation(line: 85, column: 10, scope: !38, inlinedAt: !43)
!47 = !DILocation(line: 85, column: 9, scope: !38, inlinedAt: !43)
!48 = !DILocation(line: 85, column: 7, scope: !38, inlinedAt: !43)
!49 = !DILocalVariable(name: "beta", scope: !38, file: !10, line: 79, type: !12)
!50 = !DILocation(line: 87, column: 11, scope: !38, inlinedAt: !43)
!51 = !DILocation(line: 87, column: 10, scope: !38, inlinedAt: !43)
!52 = !DILocalVariable(name: "alpha", scope: !38, file: !10, line: 78, type: !12)
!53 = !DILocalVariable(name: "k", scope: !38, file: !10, line: 82, type: !19)
!54 = !DILocation(line: 89, column: 7, scope: !55, inlinedAt: !43)
!55 = distinct !DILexicalBlock(scope: !38, file: !10, line: 89, column: 2)
!56 = !DILocation(line: 0, scope: !55, inlinedAt: !43)
!57 = !DILocation(line: 89, column: 16, scope: !58, inlinedAt: !43)
!58 = distinct !DILexicalBlock(scope: !55, file: !10, line: 89, column: 2)
!59 = !DILocation(line: 89, column: 2, scope: !55, inlinedAt: !43)
!60 = !DILocation(line: 90, column: 19, scope: !61, inlinedAt: !43)
!61 = distinct !DILexicalBlock(scope: !58, file: !10, line: 89, column: 30)
!62 = !DILocation(line: 90, column: 13, scope: !61, inlinedAt: !43)
!63 = !DILocation(line: 90, column: 26, scope: !61, inlinedAt: !43)
!64 = !DILocalVariable(name: "sum", scope: !38, file: !10, line: 80, type: !12)
!65 = !DILocalVariable(name: "i", scope: !38, file: !10, line: 82, type: !19)
!66 = !DILocation(line: 92, column: 9, scope: !67, inlinedAt: !43)
!67 = distinct !DILexicalBlock(scope: !61, file: !10, line: 92, column: 4)
!68 = !DILocation(line: 0, scope: !61, inlinedAt: !43)
!69 = !DILocation(line: 0, scope: !67, inlinedAt: !43)
!70 = !DILocation(line: 92, column: 15, scope: !71, inlinedAt: !43)
!71 = distinct !DILexicalBlock(scope: !67, file: !10, line: 92, column: 4)
!72 = !DILocation(line: 92, column: 4, scope: !67, inlinedAt: !43)
!73 = !DILocation(line: 93, column: 17, scope: !74, inlinedAt: !43)
!74 = distinct !DILexicalBlock(scope: !71, file: !10, line: 92, column: 24)
!75 = !DILocation(line: 93, column: 19, scope: !74, inlinedAt: !43)
!76 = !DILocation(line: 93, column: 14, scope: !74, inlinedAt: !43)
!77 = !DILocation(line: 93, column: 23, scope: !74, inlinedAt: !43)
!78 = !DILocation(line: 93, column: 22, scope: !74, inlinedAt: !43)
!79 = !DILocation(line: 93, column: 11, scope: !74, inlinedAt: !43)
!80 = !DILocation(line: 92, column: 20, scope: !71, inlinedAt: !43)
!81 = !DILocation(line: 92, column: 4, scope: !71, inlinedAt: !43)
!82 = distinct !{!82, !72, !83, !84}
!83 = !DILocation(line: 94, column: 4, scope: !67, inlinedAt: !43)
!84 = !{!"llvm.loop.mustprogress"}
!85 = !DILocation(line: 95, column: 15, scope: !61, inlinedAt: !43)
!86 = !DILocation(line: 95, column: 20, scope: !61, inlinedAt: !43)
!87 = !DILocation(line: 95, column: 12, scope: !61, inlinedAt: !43)
!88 = !DILocation(line: 95, column: 26, scope: !61, inlinedAt: !43)
!89 = !DILocation(line: 97, column: 9, scope: !90, inlinedAt: !43)
!90 = distinct !DILexicalBlock(scope: !61, file: !10, line: 97, column: 4)
!91 = !DILocation(line: 0, scope: !90, inlinedAt: !43)
!92 = !DILocation(line: 97, column: 15, scope: !93, inlinedAt: !43)
!93 = distinct !DILexicalBlock(scope: !90, file: !10, line: 97, column: 4)
!94 = !DILocation(line: 97, column: 4, scope: !90, inlinedAt: !43)
!95 = !DILocation(line: 98, column: 14, scope: !96, inlinedAt: !43)
!96 = distinct !DILexicalBlock(scope: !93, file: !10, line: 97, column: 24)
!97 = !DILocation(line: 98, column: 30, scope: !96, inlinedAt: !43)
!98 = !DILocation(line: 98, column: 32, scope: !96, inlinedAt: !43)
!99 = !DILocation(line: 98, column: 27, scope: !96, inlinedAt: !43)
!100 = !DILocation(line: 98, column: 26, scope: !96, inlinedAt: !43)
!101 = !DILocation(line: 98, column: 19, scope: !96, inlinedAt: !43)
!102 = !DILocation(line: 98, column: 7, scope: !96, inlinedAt: !43)
!103 = !DILocation(line: 98, column: 12, scope: !96, inlinedAt: !43)
!104 = !DILocation(line: 97, column: 20, scope: !93, inlinedAt: !43)
!105 = !DILocation(line: 97, column: 4, scope: !93, inlinedAt: !43)
!106 = distinct !{!106, !94, !107, !84}
!107 = !DILocation(line: 99, column: 4, scope: !90, inlinedAt: !43)
!108 = !DILocation(line: 100, column: 9, scope: !109, inlinedAt: !43)
!109 = distinct !DILexicalBlock(scope: !61, file: !10, line: 100, column: 4)
!110 = !DILocation(line: 0, scope: !109, inlinedAt: !43)
!111 = !DILocation(line: 100, column: 15, scope: !112, inlinedAt: !43)
!112 = distinct !DILexicalBlock(scope: !109, file: !10, line: 100, column: 4)
!113 = !DILocation(line: 100, column: 4, scope: !109, inlinedAt: !43)
!114 = !DILocation(line: 101, column: 13, scope: !115, inlinedAt: !43)
!115 = distinct !DILexicalBlock(scope: !112, file: !10, line: 100, column: 24)
!116 = !DILocation(line: 101, column: 6, scope: !115, inlinedAt: !43)
!117 = !DILocation(line: 101, column: 11, scope: !115, inlinedAt: !43)
!118 = !DILocation(line: 100, column: 20, scope: !112, inlinedAt: !43)
!119 = !DILocation(line: 100, column: 4, scope: !112, inlinedAt: !43)
!120 = distinct !{!120, !113, !121, !84}
!121 = !DILocation(line: 102, column: 4, scope: !109, inlinedAt: !43)
!122 = !DILocation(line: 103, column: 4, scope: !61, inlinedAt: !43)
!123 = !DILocation(line: 103, column: 9, scope: !61, inlinedAt: !43)
!124 = !DILocation(line: 89, column: 26, scope: !58, inlinedAt: !43)
!125 = !DILocation(line: 89, column: 2, scope: !58, inlinedAt: !43)
!126 = distinct !{!126, !59, !127, !84}
!127 = !DILocation(line: 104, column: 2, scope: !55, inlinedAt: !43)
!128 = !DILocation(line: 124, column: 3, scope: !28)
