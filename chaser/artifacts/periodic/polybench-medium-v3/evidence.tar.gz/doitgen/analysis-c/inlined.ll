; ModuleID = 'workload.ll'
source_filename = "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/affine-bounds-20260929/suite/doitgen/source/workload.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

%struct._IO_FILE = type { i32, i8*, i8*, i8*, i8*, i8*, i8*, i8*, i8*, i8*, i8*, i8*, %struct._IO_marker*, %struct._IO_FILE*, i32, i32, i64, i16, i8, [1 x i8], i8*, i64, %struct._IO_codecvt*, %struct._IO_wide_data*, %struct._IO_FILE*, i8*, i64, i32, [20 x i8] }
%struct._IO_marker = type opaque
%struct._IO_codecvt = type opaque
%struct._IO_wide_data = type opaque
%struct.__va_list_tag = type { i32, i32, i8*, i8* }

@nr = dso_local global i32 50, align 4, !dbg !0
@nq = dso_local global i32 40, align 4, !dbg !9
@np = dso_local global i32 60, align 4, !dbg !13
@A = dso_local global [50 x [40 x [60 x double]]] zeroinitializer, section ".chaser_data.A", align 64, !dbg !35
@sum = dso_local global [60 x double] zeroinitializer, section ".chaser_data.sum", align 64, !dbg !42
@C4 = dso_local global [60 x [60 x double]] zeroinitializer, section ".chaser_data.C4", align 64, !dbg !46
@.str = private unnamed_addr constant [12 x i8] c"ape.analyze\00", section "llvm.metadata"
@.str.1 = private unnamed_addr constant [125 x i8] c"/workspace/experiments-array-support/chaser/.cache/periodic-polybench/affine-bounds-20260929/suite/doitgen/source/workload.c\00", section "llvm.metadata"
@pb_hash = internal global i32 0, align 4, !dbg !32
@workload_jobs = dso_local constant [1 x i32 ()*] [i32 ()* @task_job_polybench], align 8, !dbg !15
@workload_expected = dso_local constant [1 x i32] [i32 86454017], align 4, !dbg !28
@stderr = external global %struct._IO_FILE*, align 8
@.str.2 = private unnamed_addr constant [23 x i8] c"==BEGIN DUMP_ARRAYS==\0A\00", align 1
@.str.3 = private unnamed_addr constant [15 x i8] c"begin dump: %s\00", align 1
@.str.4 = private unnamed_addr constant [2 x i8] c"A\00", align 1
@.str.5 = private unnamed_addr constant [2 x i8] c"\0A\00", align 1
@.str.6 = private unnamed_addr constant [8 x i8] c"%0.2lf \00", align 1
@.str.7 = private unnamed_addr constant [17 x i8] c"\0Aend   dump: %s\0A\00", align 1
@.str.8 = private unnamed_addr constant [23 x i8] c"==END   DUMP_ARRAYS==\0A\00", align 1
@pb_emit = internal global i32 1, align 4, !dbg !50
@llvm.global.annotations = appending global [1 x { i8*, i8*, i8*, i32, i8* }] [{ i8*, i8*, i8*, i32, i8* } { i8* bitcast (i32 ()* @task_job_polybench to i8*), i8* getelementptr inbounds ([12 x i8], [12 x i8]* @.str, i32 0, i32 0), i8* getelementptr inbounds ([125 x i8], [125 x i8]* @.str.1, i32 0, i32 0), i32 114, i8* null }], section "llvm.metadata"

; Function Attrs: noinline nounwind uwtable
define dso_local void @workload_prepare() #0 !dbg !60 {
  ret void, !dbg !64
}

; Function Attrs: noinline nounwind uwtable
define dso_local void @workload_reset(i32 noundef %0) #0 !dbg !65 {
  call void @llvm.dbg.value(metadata i32 %0, metadata !68, metadata !DIExpression()), !dbg !69
  call void @llvm.memset.p0i8.i64(i8* align 64 bitcast ([50 x [40 x [60 x double]]]* @A to i8*), i8 0, i64 960000, i1 false), !dbg !70
  call void @llvm.memset.p0i8.i64(i8* align 64 bitcast ([60 x double]* @sum to i8*), i8 0, i64 480, i1 false), !dbg !71
  call void @llvm.memset.p0i8.i64(i8* align 64 bitcast ([60 x [60 x double]]* @C4 to i8*), i8 0, i64 28800, i1 false), !dbg !72
  %2 = load i32, i32* @nr, align 4, !dbg !73
  %3 = load i32, i32* @nq, align 4, !dbg !74
  %4 = load i32, i32* @np, align 4, !dbg !75
  call void @init_array(i32 noundef %2, i32 noundef %3, i32 noundef %4, [40 x [60 x double]]* noundef getelementptr inbounds ([50 x [40 x [60 x double]]], [50 x [40 x [60 x double]]]* @A, i64 0, i64 0), [60 x double]* noundef getelementptr inbounds ([60 x [60 x double]], [60 x [60 x double]]* @C4, i64 0, i64 0)), !dbg !76
  ret void, !dbg !77
}

; Function Attrs: nofree nosync nounwind readnone speculatable willreturn
declare void @llvm.dbg.declare(metadata, metadata, metadata) #1

; Function Attrs: argmemonly nofree nounwind willreturn writeonly
declare void @llvm.memset.p0i8.i64(i8* nocapture writeonly, i8, i64, i1 immarg) #2

; Function Attrs: noinline nounwind uwtable
define internal void @init_array(i32 noundef %0, i32 noundef %1, i32 noundef %2, [40 x [60 x double]]* noundef %3, [60 x double]* noundef %4) #0 !dbg !78 {
  call void @llvm.dbg.value(metadata i32 %0, metadata !85, metadata !DIExpression()), !dbg !86
  call void @llvm.dbg.value(metadata i32 %1, metadata !87, metadata !DIExpression()), !dbg !86
  call void @llvm.dbg.value(metadata i32 %2, metadata !88, metadata !DIExpression()), !dbg !86
  call void @llvm.dbg.value(metadata [40 x [60 x double]]* %3, metadata !89, metadata !DIExpression()), !dbg !86
  call void @llvm.dbg.value(metadata [60 x double]* %4, metadata !90, metadata !DIExpression()), !dbg !86
  call void @llvm.dbg.value(metadata i32 0, metadata !91, metadata !DIExpression()), !dbg !86
  br label %6, !dbg !92

6:                                                ; preds = %33, %5
  %.02 = phi i32 [ 0, %5 ], [ %34, %33 ], !dbg !94
  call void @llvm.dbg.value(metadata i32 %.02, metadata !91, metadata !DIExpression()), !dbg !86
  %7 = icmp slt i32 %.02, %0, !dbg !95
  br i1 %7, label %8, label %35, !dbg !97

8:                                                ; preds = %6
  call void @llvm.dbg.value(metadata i32 0, metadata !98, metadata !DIExpression()), !dbg !86
  br label %9, !dbg !99

9:                                                ; preds = %30, %8
  %.01 = phi i32 [ 0, %8 ], [ %31, %30 ], !dbg !101
  call void @llvm.dbg.value(metadata i32 %.01, metadata !98, metadata !DIExpression()), !dbg !86
  %10 = icmp slt i32 %.01, %1, !dbg !102
  br i1 %10, label %11, label %32, !dbg !104

11:                                               ; preds = %9
  call void @llvm.dbg.value(metadata i32 0, metadata !105, metadata !DIExpression()), !dbg !86
  br label %12, !dbg !106

12:                                               ; preds = %27, %11
  %.0 = phi i32 [ 0, %11 ], [ %28, %27 ], !dbg !108
  call void @llvm.dbg.value(metadata i32 %.0, metadata !105, metadata !DIExpression()), !dbg !86
  %13 = icmp slt i32 %.0, %2, !dbg !109
  br i1 %13, label %14, label %29, !dbg !111

14:                                               ; preds = %12
  %15 = mul nsw i32 %.02, %.01, !dbg !112
  %16 = add nsw i32 %15, %.0, !dbg !113
  %17 = srem i32 %16, %2, !dbg !114
  %18 = sitofp i32 %17 to double, !dbg !115
  %19 = sitofp i32 %2 to double, !dbg !116
  %20 = fdiv double %18, %19, !dbg !117
  %21 = sext i32 %.02 to i64, !dbg !118
  %22 = getelementptr inbounds [40 x [60 x double]], [40 x [60 x double]]* %3, i64 %21, !dbg !118
  %23 = sext i32 %.01 to i64, !dbg !118
  %24 = getelementptr inbounds [40 x [60 x double]], [40 x [60 x double]]* %22, i64 0, i64 %23, !dbg !118
  %25 = sext i32 %.0 to i64, !dbg !118
  %26 = getelementptr inbounds [60 x double], [60 x double]* %24, i64 0, i64 %25, !dbg !118
  store double %20, double* %26, align 8, !dbg !119
  br label %27, !dbg !118

27:                                               ; preds = %14
  %28 = add nsw i32 %.0, 1, !dbg !120
  call void @llvm.dbg.value(metadata i32 %28, metadata !105, metadata !DIExpression()), !dbg !86
  br label %12, !dbg !121, !llvm.loop !122

29:                                               ; preds = %12
  br label %30, !dbg !123

30:                                               ; preds = %29
  %31 = add nsw i32 %.01, 1, !dbg !125
  call void @llvm.dbg.value(metadata i32 %31, metadata !98, metadata !DIExpression()), !dbg !86
  br label %9, !dbg !126, !llvm.loop !127

32:                                               ; preds = %9
  br label %33, !dbg !128

33:                                               ; preds = %32
  %34 = add nsw i32 %.02, 1, !dbg !129
  call void @llvm.dbg.value(metadata i32 %34, metadata !91, metadata !DIExpression()), !dbg !86
  br label %6, !dbg !130, !llvm.loop !131

35:                                               ; preds = %6
  call void @llvm.dbg.value(metadata i32 0, metadata !91, metadata !DIExpression()), !dbg !86
  br label %36, !dbg !133

36:                                               ; preds = %54, %35
  %.13 = phi i32 [ 0, %35 ], [ %55, %54 ], !dbg !135
  call void @llvm.dbg.value(metadata i32 %.13, metadata !91, metadata !DIExpression()), !dbg !86
  %37 = icmp slt i32 %.13, %2, !dbg !136
  br i1 %37, label %38, label %56, !dbg !138

38:                                               ; preds = %36
  call void @llvm.dbg.value(metadata i32 0, metadata !98, metadata !DIExpression()), !dbg !86
  br label %39, !dbg !139

39:                                               ; preds = %51, %38
  %.1 = phi i32 [ 0, %38 ], [ %52, %51 ], !dbg !141
  call void @llvm.dbg.value(metadata i32 %.1, metadata !98, metadata !DIExpression()), !dbg !86
  %40 = icmp slt i32 %.1, %2, !dbg !142
  br i1 %40, label %41, label %53, !dbg !144

41:                                               ; preds = %39
  %42 = mul nsw i32 %.13, %.1, !dbg !145
  %43 = srem i32 %42, %2, !dbg !146
  %44 = sitofp i32 %43 to double, !dbg !147
  %45 = sitofp i32 %2 to double, !dbg !148
  %46 = fdiv double %44, %45, !dbg !149
  %47 = sext i32 %.13 to i64, !dbg !150
  %48 = getelementptr inbounds [60 x double], [60 x double]* %4, i64 %47, !dbg !150
  %49 = sext i32 %.1 to i64, !dbg !150
  %50 = getelementptr inbounds [60 x double], [60 x double]* %48, i64 0, i64 %49, !dbg !150
  store double %46, double* %50, align 8, !dbg !151
  br label %51, !dbg !150

51:                                               ; preds = %41
  %52 = add nsw i32 %.1, 1, !dbg !152
  call void @llvm.dbg.value(metadata i32 %52, metadata !98, metadata !DIExpression()), !dbg !86
  br label %39, !dbg !153, !llvm.loop !154

53:                                               ; preds = %39
  br label %54, !dbg !155

54:                                               ; preds = %53
  %55 = add nsw i32 %.13, 1, !dbg !156
  call void @llvm.dbg.value(metadata i32 %55, metadata !91, metadata !DIExpression()), !dbg !86
  br label %36, !dbg !157, !llvm.loop !158

56:                                               ; preds = %36
  ret void, !dbg !160
}

; Function Attrs: noinline nounwind uwtable
define dso_local i32 @task_job_polybench() #0 !dbg !161 {
  %1 = load i32, i32* @nr, align 4, !dbg !162
  %2 = load i32, i32* @nq, align 4, !dbg !163
  %3 = load i32, i32* @np, align 4, !dbg !164
  call void @llvm.dbg.value(metadata i32 %1, metadata !165, metadata !DIExpression()), !dbg !170
  call void @llvm.dbg.value(metadata i32 %2, metadata !172, metadata !DIExpression()), !dbg !170
  call void @llvm.dbg.value(metadata i32 %3, metadata !173, metadata !DIExpression()), !dbg !170
  call void @llvm.dbg.value(metadata [40 x [60 x double]]* getelementptr inbounds ([50 x [40 x [60 x double]]], [50 x [40 x [60 x double]]]* @A, i64 0, i64 0), metadata !174, metadata !DIExpression()), !dbg !170
  call void @llvm.dbg.value(metadata [60 x double]* getelementptr inbounds ([60 x [60 x double]], [60 x [60 x double]]* @C4, i64 0, i64 0), metadata !175, metadata !DIExpression()), !dbg !170
  call void @llvm.dbg.value(metadata double* getelementptr inbounds ([60 x double], [60 x double]* @sum, i64 0, i64 0), metadata !176, metadata !DIExpression()), !dbg !170
  call void @llvm.dbg.value(metadata i32 0, metadata !177, metadata !DIExpression()), !dbg !170
  br label %4, !dbg !178

4:                                                ; preds = %54, %0
  %.03 = phi i32 [ 0, %0 ], [ %55, %54 ], !dbg !180
  call void @llvm.dbg.value(metadata i32 %.03, metadata !177, metadata !DIExpression()), !dbg !170
  %5 = icmp slt i32 %.03, 50, !dbg !181
  br i1 %5, label %6, label %56, !dbg !183

6:                                                ; preds = %4
  call void @llvm.dbg.value(metadata i32 0, metadata !184, metadata !DIExpression()), !dbg !170
  br label %7, !dbg !185

7:                                                ; preds = %52, %6
  %.02 = phi i32 [ 0, %6 ], [ %53, %52 ], !dbg !187
  call void @llvm.dbg.value(metadata i32 %.02, metadata !184, metadata !DIExpression()), !dbg !170
  %8 = icmp slt i32 %.02, 40, !dbg !188
  br i1 %8, label %9, label %54, !dbg !190

9:                                                ; preds = %7
  call void @llvm.dbg.value(metadata i32 0, metadata !191, metadata !DIExpression()), !dbg !170
  br label %10, !dbg !192

10:                                               ; preds = %36, %9
  %.01 = phi i32 [ 0, %9 ], [ %37, %36 ], !dbg !195
  call void @llvm.dbg.value(metadata i32 %.01, metadata !191, metadata !DIExpression()), !dbg !170
  %11 = icmp slt i32 %.01, 60, !dbg !196
  br i1 %11, label %12, label %38, !dbg !198

12:                                               ; preds = %10
  %13 = sext i32 %.01 to i64, !dbg !199
  %14 = getelementptr inbounds double, double* getelementptr inbounds ([60 x double], [60 x double]* @sum, i64 0, i64 0), i64 %13, !dbg !199
  store double 0.000000e+00, double* %14, align 8, !dbg !201
  call void @llvm.dbg.value(metadata i32 0, metadata !202, metadata !DIExpression()), !dbg !170
  br label %15, !dbg !203

15:                                               ; preds = %17, %12
  %.0 = phi i32 [ 0, %12 ], [ %35, %17 ], !dbg !205
  call void @llvm.dbg.value(metadata i32 %.0, metadata !202, metadata !DIExpression()), !dbg !170
  %16 = icmp slt i32 %.0, 60, !dbg !206
  br i1 %16, label %17, label %36, !dbg !208

17:                                               ; preds = %15
  %18 = sext i32 %.03 to i64, !dbg !209
  %19 = getelementptr inbounds [40 x [60 x double]], [40 x [60 x double]]* getelementptr inbounds ([50 x [40 x [60 x double]]], [50 x [40 x [60 x double]]]* @A, i64 0, i64 0), i64 %18, !dbg !209
  %20 = sext i32 %.02 to i64, !dbg !209
  %21 = getelementptr inbounds [40 x [60 x double]], [40 x [60 x double]]* %19, i64 0, i64 %20, !dbg !209
  %22 = sext i32 %.0 to i64, !dbg !209
  %23 = getelementptr inbounds [60 x double], [60 x double]* %21, i64 0, i64 %22, !dbg !209
  %24 = load double, double* %23, align 8, !dbg !209
  %25 = sext i32 %.0 to i64, !dbg !210
  %26 = getelementptr inbounds [60 x double], [60 x double]* getelementptr inbounds ([60 x [60 x double]], [60 x [60 x double]]* @C4, i64 0, i64 0), i64 %25, !dbg !210
  %27 = sext i32 %.01 to i64, !dbg !210
  %28 = getelementptr inbounds [60 x double], [60 x double]* %26, i64 0, i64 %27, !dbg !210
  %29 = load double, double* %28, align 8, !dbg !210
  %30 = fmul double %24, %29, !dbg !211
  %31 = sext i32 %.01 to i64, !dbg !212
  %32 = getelementptr inbounds double, double* getelementptr inbounds ([60 x double], [60 x double]* @sum, i64 0, i64 0), i64 %31, !dbg !212
  %33 = load double, double* %32, align 8, !dbg !213
  %34 = fadd double %33, %30, !dbg !213
  store double %34, double* %32, align 8, !dbg !213
  %35 = add nsw i32 %.0, 1, !dbg !214
  call void @llvm.dbg.value(metadata i32 %35, metadata !202, metadata !DIExpression()), !dbg !170
  br label %15, !dbg !215, !llvm.loop !216

36:                                               ; preds = %15
  %37 = add nsw i32 %.01, 1, !dbg !218
  call void @llvm.dbg.value(metadata i32 %37, metadata !191, metadata !DIExpression()), !dbg !170
  br label %10, !dbg !219, !llvm.loop !220

38:                                               ; preds = %10
  call void @llvm.dbg.value(metadata i32 0, metadata !191, metadata !DIExpression()), !dbg !170
  br label %39, !dbg !222

39:                                               ; preds = %41, %38
  %.1 = phi i32 [ 0, %38 ], [ %51, %41 ], !dbg !224
  call void @llvm.dbg.value(metadata i32 %.1, metadata !191, metadata !DIExpression()), !dbg !170
  %40 = icmp slt i32 %.1, 60, !dbg !225
  br i1 %40, label %41, label %52, !dbg !227

41:                                               ; preds = %39
  %42 = sext i32 %.1 to i64, !dbg !228
  %43 = getelementptr inbounds double, double* getelementptr inbounds ([60 x double], [60 x double]* @sum, i64 0, i64 0), i64 %42, !dbg !228
  %44 = load double, double* %43, align 8, !dbg !228
  %45 = sext i32 %.03 to i64, !dbg !229
  %46 = getelementptr inbounds [40 x [60 x double]], [40 x [60 x double]]* getelementptr inbounds ([50 x [40 x [60 x double]]], [50 x [40 x [60 x double]]]* @A, i64 0, i64 0), i64 %45, !dbg !229
  %47 = sext i32 %.02 to i64, !dbg !229
  %48 = getelementptr inbounds [40 x [60 x double]], [40 x [60 x double]]* %46, i64 0, i64 %47, !dbg !229
  %49 = sext i32 %.1 to i64, !dbg !229
  %50 = getelementptr inbounds [60 x double], [60 x double]* %48, i64 0, i64 %49, !dbg !229
  store double %44, double* %50, align 8, !dbg !230
  %51 = add nsw i32 %.1, 1, !dbg !231
  call void @llvm.dbg.value(metadata i32 %51, metadata !191, metadata !DIExpression()), !dbg !170
  br label %39, !dbg !232, !llvm.loop !233

52:                                               ; preds = %39
  %53 = add nsw i32 %.02, 1, !dbg !235
  call void @llvm.dbg.value(metadata i32 %53, metadata !184, metadata !DIExpression()), !dbg !170
  br label %7, !dbg !236, !llvm.loop !237

54:                                               ; preds = %7
  %55 = add nsw i32 %.03, 1, !dbg !239
  call void @llvm.dbg.value(metadata i32 %55, metadata !177, metadata !DIExpression()), !dbg !170
  br label %4, !dbg !240, !llvm.loop !241

56:                                               ; preds = %4
  ret i32 0, !dbg !243
}

; Function Attrs: noinline nounwind uwtable
define dso_local i32 @workload_checksum(i32 noundef %0) #0 !dbg !244 {
  call void @llvm.dbg.value(metadata i32 %0, metadata !247, metadata !DIExpression()), !dbg !248
  store i32 -2128831035, i32* @pb_hash, align 4, !dbg !249
  %2 = load i32, i32* @nr, align 4, !dbg !250
  %3 = load i32, i32* @nq, align 4, !dbg !251
  %4 = load i32, i32* @np, align 4, !dbg !252
  call void @print_array(i32 noundef %2, i32 noundef %3, i32 noundef %4, [40 x [60 x double]]* noundef getelementptr inbounds ([50 x [40 x [60 x double]]], [50 x [40 x [60 x double]]]* @A, i64 0, i64 0)), !dbg !253
  %5 = load i32, i32* @pb_hash, align 4, !dbg !254
  ret i32 %5, !dbg !255
}

; Function Attrs: noinline nounwind uwtable
define internal void @print_array(i32 noundef %0, i32 noundef %1, i32 noundef %2, [40 x [60 x double]]* noundef %3) #0 !dbg !256 {
  call void @llvm.dbg.value(metadata i32 %0, metadata !259, metadata !DIExpression()), !dbg !260
  call void @llvm.dbg.value(metadata i32 %1, metadata !261, metadata !DIExpression()), !dbg !260
  call void @llvm.dbg.value(metadata i32 %2, metadata !262, metadata !DIExpression()), !dbg !260
  call void @llvm.dbg.value(metadata [40 x [60 x double]]* %3, metadata !263, metadata !DIExpression()), !dbg !260
  %5 = load %struct._IO_FILE*, %struct._IO_FILE** @stderr, align 8, !dbg !264
  %6 = call i32 (%struct._IO_FILE*, i8*, ...) @pb_fprintf(%struct._IO_FILE* noundef %5, i8* noundef getelementptr inbounds ([23 x i8], [23 x i8]* @.str.2, i64 0, i64 0)), !dbg !264
  %7 = load %struct._IO_FILE*, %struct._IO_FILE** @stderr, align 8, !dbg !265
  %8 = call i32 (%struct._IO_FILE*, i8*, ...) @pb_fprintf(%struct._IO_FILE* noundef %7, i8* noundef getelementptr inbounds ([15 x i8], [15 x i8]* @.str.3, i64 0, i64 0), i8* noundef getelementptr inbounds ([2 x i8], [2 x i8]* @.str.4, i64 0, i64 0)), !dbg !265
  call void @llvm.dbg.value(metadata i32 0, metadata !266, metadata !DIExpression()), !dbg !260
  br label %9, !dbg !267

9:                                                ; preds = %44, %4
  %.02 = phi i32 [ 0, %4 ], [ %45, %44 ], !dbg !269
  call void @llvm.dbg.value(metadata i32 %.02, metadata !266, metadata !DIExpression()), !dbg !260
  %10 = icmp slt i32 %.02, %0, !dbg !270
  br i1 %10, label %11, label %46, !dbg !272

11:                                               ; preds = %9
  call void @llvm.dbg.value(metadata i32 0, metadata !273, metadata !DIExpression()), !dbg !260
  br label %12, !dbg !274

12:                                               ; preds = %41, %11
  %.01 = phi i32 [ 0, %11 ], [ %42, %41 ], !dbg !276
  call void @llvm.dbg.value(metadata i32 %.01, metadata !273, metadata !DIExpression()), !dbg !260
  %13 = icmp slt i32 %.01, %1, !dbg !277
  br i1 %13, label %14, label %43, !dbg !279

14:                                               ; preds = %12
  call void @llvm.dbg.value(metadata i32 0, metadata !280, metadata !DIExpression()), !dbg !260
  br label %15, !dbg !281

15:                                               ; preds = %38, %14
  %.0 = phi i32 [ 0, %14 ], [ %39, %38 ], !dbg !283
  call void @llvm.dbg.value(metadata i32 %.0, metadata !280, metadata !DIExpression()), !dbg !260
  %16 = icmp slt i32 %.0, %2, !dbg !284
  br i1 %16, label %17, label %40, !dbg !286

17:                                               ; preds = %15
  %18 = mul nsw i32 %.02, %1, !dbg !287
  %19 = mul nsw i32 %18, %2, !dbg !290
  %20 = mul nsw i32 %.01, %2, !dbg !291
  %21 = add nsw i32 %19, %20, !dbg !292
  %22 = add nsw i32 %21, %.0, !dbg !293
  %23 = srem i32 %22, 20, !dbg !294
  %24 = icmp eq i32 %23, 0, !dbg !295
  br i1 %24, label %25, label %28, !dbg !296

25:                                               ; preds = %17
  %26 = load %struct._IO_FILE*, %struct._IO_FILE** @stderr, align 8, !dbg !297
  %27 = call i32 (%struct._IO_FILE*, i8*, ...) @pb_fprintf(%struct._IO_FILE* noundef %26, i8* noundef getelementptr inbounds ([2 x i8], [2 x i8]* @.str.5, i64 0, i64 0)), !dbg !298
  br label %28, !dbg !298

28:                                               ; preds = %25, %17
  %29 = load %struct._IO_FILE*, %struct._IO_FILE** @stderr, align 8, !dbg !299
  %30 = sext i32 %.02 to i64, !dbg !300
  %31 = getelementptr inbounds [40 x [60 x double]], [40 x [60 x double]]* %3, i64 %30, !dbg !300
  %32 = sext i32 %.01 to i64, !dbg !300
  %33 = getelementptr inbounds [40 x [60 x double]], [40 x [60 x double]]* %31, i64 0, i64 %32, !dbg !300
  %34 = sext i32 %.0 to i64, !dbg !300
  %35 = getelementptr inbounds [60 x double], [60 x double]* %33, i64 0, i64 %34, !dbg !300
  %36 = load double, double* %35, align 8, !dbg !300
  %37 = call i32 (%struct._IO_FILE*, i8*, ...) @pb_fprintf(%struct._IO_FILE* noundef %29, i8* noundef getelementptr inbounds ([8 x i8], [8 x i8]* @.str.6, i64 0, i64 0), double noundef %36), !dbg !301
  br label %38, !dbg !302

38:                                               ; preds = %28
  %39 = add nsw i32 %.0, 1, !dbg !303
  call void @llvm.dbg.value(metadata i32 %39, metadata !280, metadata !DIExpression()), !dbg !260
  br label %15, !dbg !304, !llvm.loop !305

40:                                               ; preds = %15
  br label %41, !dbg !306

41:                                               ; preds = %40
  %42 = add nsw i32 %.01, 1, !dbg !307
  call void @llvm.dbg.value(metadata i32 %42, metadata !273, metadata !DIExpression()), !dbg !260
  br label %12, !dbg !308, !llvm.loop !309

43:                                               ; preds = %12
  br label %44, !dbg !310

44:                                               ; preds = %43
  %45 = add nsw i32 %.02, 1, !dbg !311
  call void @llvm.dbg.value(metadata i32 %45, metadata !266, metadata !DIExpression()), !dbg !260
  br label %9, !dbg !312, !llvm.loop !313

46:                                               ; preds = %9
  %47 = load %struct._IO_FILE*, %struct._IO_FILE** @stderr, align 8, !dbg !315
  %48 = call i32 (%struct._IO_FILE*, i8*, ...) @pb_fprintf(%struct._IO_FILE* noundef %47, i8* noundef getelementptr inbounds ([17 x i8], [17 x i8]* @.str.7, i64 0, i64 0), i8* noundef getelementptr inbounds ([2 x i8], [2 x i8]* @.str.4, i64 0, i64 0)), !dbg !315
  %49 = load %struct._IO_FILE*, %struct._IO_FILE** @stderr, align 8, !dbg !316
  %50 = call i32 (%struct._IO_FILE*, i8*, ...) @pb_fprintf(%struct._IO_FILE* noundef %49, i8* noundef getelementptr inbounds ([23 x i8], [23 x i8]* @.str.8, i64 0, i64 0)), !dbg !316
  ret void, !dbg !317
}

; Function Attrs: noinline nounwind uwtable
define internal i32 @pb_fprintf(%struct._IO_FILE* noundef %0, i8* noundef %1, ...) #0 !dbg !318 {
  %3 = alloca [768 x i8], align 16
  %4 = alloca [1 x %struct.__va_list_tag], align 16
  call void @llvm.dbg.value(metadata %struct._IO_FILE* %0, metadata !382, metadata !DIExpression()), !dbg !383
  call void @llvm.dbg.value(metadata i8* %1, metadata !384, metadata !DIExpression()), !dbg !383
  call void @llvm.dbg.declare(metadata [768 x i8]* %3, metadata !385, metadata !DIExpression()), !dbg !389
  call void @llvm.dbg.declare(metadata [1 x %struct.__va_list_tag]* %4, metadata !390, metadata !DIExpression()), !dbg !404
  %5 = getelementptr inbounds [1 x %struct.__va_list_tag], [1 x %struct.__va_list_tag]* %4, i64 0, i64 0, !dbg !405
  %6 = bitcast %struct.__va_list_tag* %5 to i8*, !dbg !405
  call void @llvm.va_start(i8* %6), !dbg !405
  %7 = getelementptr inbounds [768 x i8], [768 x i8]* %3, i64 0, i64 0, !dbg !406
  %8 = getelementptr inbounds [1 x %struct.__va_list_tag], [1 x %struct.__va_list_tag]* %4, i64 0, i64 0, !dbg !407
  %9 = call i32 @vsnprintf(i8* noundef %7, i64 noundef 768, i8* noundef %1, %struct.__va_list_tag* noundef %8) #6, !dbg !408
  call void @llvm.dbg.value(metadata i32 %9, metadata !409, metadata !DIExpression()), !dbg !383
  %10 = getelementptr inbounds [1 x %struct.__va_list_tag], [1 x %struct.__va_list_tag]* %4, i64 0, i64 0, !dbg !410
  %11 = bitcast %struct.__va_list_tag* %10 to i8*, !dbg !410
  call void @llvm.va_end(i8* %11), !dbg !410
  %12 = icmp slt i32 %9, 0, !dbg !411
  br i1 %12, label %16, label %13, !dbg !413

13:                                               ; preds = %2
  %14 = zext i32 %9 to i64, !dbg !414
  %15 = icmp uge i64 %14, 768, !dbg !415
  br i1 %15, label %16, label %17, !dbg !416

16:                                               ; preds = %13, %2
  call void @abort() #7, !dbg !417
  unreachable, !dbg !417

17:                                               ; preds = %13
  call void @llvm.dbg.value(metadata i32 0, metadata !418, metadata !DIExpression()), !dbg !420
  br label %18, !dbg !421

18:                                               ; preds = %29, %17
  %.0 = phi i32 [ 0, %17 ], [ %30, %29 ], !dbg !420
  call void @llvm.dbg.value(metadata i32 %.0, metadata !418, metadata !DIExpression()), !dbg !420
  %19 = icmp slt i32 %.0, %9, !dbg !422
  br i1 %19, label %20, label %31, !dbg !424

20:                                               ; preds = %18
  %21 = sext i32 %.0 to i64, !dbg !425
  %22 = getelementptr inbounds [768 x i8], [768 x i8]* %3, i64 0, i64 %21, !dbg !425
  %23 = load i8, i8* %22, align 1, !dbg !425
  %24 = zext i8 %23 to i32, !dbg !427
  %25 = load i32, i32* @pb_hash, align 4, !dbg !428
  %26 = xor i32 %25, %24, !dbg !428
  store i32 %26, i32* @pb_hash, align 4, !dbg !428
  %27 = load i32, i32* @pb_hash, align 4, !dbg !429
  %28 = mul i32 %27, 16777619, !dbg !429
  store i32 %28, i32* @pb_hash, align 4, !dbg !429
  br label %29, !dbg !430

29:                                               ; preds = %20
  %30 = add nsw i32 %.0, 1, !dbg !431
  call void @llvm.dbg.value(metadata i32 %30, metadata !418, metadata !DIExpression()), !dbg !420
  br label %18, !dbg !432, !llvm.loop !433

31:                                               ; preds = %18
  %32 = load i32, i32* @pb_emit, align 4, !dbg !435
  ret i32 %9, !dbg !436
}

; Function Attrs: nofree nosync nounwind willreturn
declare void @llvm.va_start(i8*) #3

; Function Attrs: nounwind
declare i32 @vsnprintf(i8* noundef, i64 noundef, i8* noundef, %struct.__va_list_tag* noundef) #4

; Function Attrs: nofree nosync nounwind willreturn
declare void @llvm.va_end(i8*) #3

; Function Attrs: noreturn nounwind
declare void @abort() #5

; Function Attrs: nofree nosync nounwind readnone speculatable willreturn
declare void @llvm.dbg.value(metadata, metadata, metadata) #1

attributes #0 = { noinline nounwind uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { nofree nosync nounwind readnone speculatable willreturn }
attributes #2 = { argmemonly nofree nounwind willreturn writeonly }
attributes #3 = { nofree nosync nounwind willreturn }
attributes #4 = { nounwind "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #5 = { noreturn nounwind "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #6 = { nounwind }
attributes #7 = { noreturn nounwind }

!llvm.dbg.cu = !{!2}
!llvm.module.flags = !{!52, !53, !54, !55, !56, !57, !58}
!llvm.ident = !{!59}

!0 = !DIGlobalVariableExpression(var: !1, expr: !DIExpression())
!1 = distinct !DIGlobalVariable(name: "nr", scope: !2, file: !11, line: 101, type: !12, isLocal: false, isDefinition: true)
!2 = distinct !DICompileUnit(language: DW_LANG_C99, file: !3, producer: "Ubuntu clang version 14.0.0-1ubuntu1.1", isOptimized: false, runtimeVersion: 0, emissionKind: FullDebug, retainedTypes: !4, globals: !8, splitDebugInlining: false, nameTableKind: None)
!3 = !DIFile(filename: "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/affine-bounds-20260929/suite/doitgen/source/workload.c", directory: "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/affine-bounds-20260929/suite/doitgen/analysis-c", checksumkind: CSK_MD5, checksum: "1cfaa4ce7cb91ebdd65caf7b87276fe2")
!4 = !{!5, !6, !7}
!5 = !DIBasicType(name: "double", size: 64, encoding: DW_ATE_float)
!6 = !DIBasicType(name: "unsigned int", size: 32, encoding: DW_ATE_unsigned)
!7 = !DIBasicType(name: "unsigned char", size: 8, encoding: DW_ATE_unsigned_char)
!8 = !{!0, !9, !13, !15, !28, !32, !35, !42, !46, !50}
!9 = !DIGlobalVariableExpression(var: !10, expr: !DIExpression())
!10 = distinct !DIGlobalVariable(name: "nq", scope: !2, file: !11, line: 102, type: !12, isLocal: false, isDefinition: true)
!11 = !DIFile(filename: "source/workload.c", directory: "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/affine-bounds-20260929/suite/doitgen", checksumkind: CSK_MD5, checksum: "1cfaa4ce7cb91ebdd65caf7b87276fe2")
!12 = !DIBasicType(name: "int", size: 32, encoding: DW_ATE_signed)
!13 = !DIGlobalVariableExpression(var: !14, expr: !DIExpression())
!14 = distinct !DIGlobalVariable(name: "np", scope: !2, file: !11, line: 103, type: !12, isLocal: false, isDefinition: true)
!15 = !DIGlobalVariableExpression(var: !16, expr: !DIExpression())
!16 = distinct !DIGlobalVariable(name: "workload_jobs", scope: !2, file: !11, line: 127, type: !17, isLocal: false, isDefinition: true)
!17 = !DICompositeType(tag: DW_TAG_array_type, baseType: !18, size: 64, elements: !26)
!18 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !19)
!19 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !20, size: 64)
!20 = !DISubroutineType(types: !21)
!21 = !{!22}
!22 = !DIDerivedType(tag: DW_TAG_typedef, name: "uint32_t", file: !23, line: 26, baseType: !24)
!23 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/stdint-uintn.h", directory: "", checksumkind: CSK_MD5, checksum: "2bf2ae53c58c01b1a1b9383b5195125c")
!24 = !DIDerivedType(tag: DW_TAG_typedef, name: "__uint32_t", file: !25, line: 42, baseType: !6)
!25 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/types.h", directory: "", checksumkind: CSK_MD5, checksum: "d108b5f93a74c50510d7d9bc0ab36df9")
!26 = !{!27}
!27 = !DISubrange(count: 1)
!28 = !DIGlobalVariableExpression(var: !29, expr: !DIExpression())
!29 = distinct !DIGlobalVariable(name: "workload_expected", scope: !2, file: !11, line: 131, type: !30, isLocal: false, isDefinition: true)
!30 = !DICompositeType(tag: DW_TAG_array_type, baseType: !31, size: 32, elements: !26)
!31 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !22)
!32 = !DIGlobalVariableExpression(var: !33, expr: !DIExpression())
!33 = distinct !DIGlobalVariable(name: "pb_hash", scope: !2, file: !34, line: 9, type: !22, isLocal: true, isDefinition: true)
!34 = !DIFile(filename: "source/adapter.h", directory: "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/affine-bounds-20260929/suite/doitgen", checksumkind: CSK_MD5, checksum: "26a6068928b2092758f244a9d00163d7")
!35 = !DIGlobalVariableExpression(var: !36, expr: !DIExpression())
!36 = distinct !DIGlobalVariable(name: "A", scope: !2, file: !11, line: 34, type: !37, isLocal: false, isDefinition: true, align: 512)
!37 = !DICompositeType(tag: DW_TAG_array_type, baseType: !5, size: 7680000, elements: !38)
!38 = !{!39, !40, !41}
!39 = !DISubrange(count: 50)
!40 = !DISubrange(count: 40)
!41 = !DISubrange(count: 60)
!42 = !DIGlobalVariableExpression(var: !43, expr: !DIExpression())
!43 = distinct !DIGlobalVariable(name: "sum", scope: !2, file: !11, line: 35, type: !44, isLocal: false, isDefinition: true, align: 512)
!44 = !DICompositeType(tag: DW_TAG_array_type, baseType: !5, size: 3840, elements: !45)
!45 = !{!41}
!46 = !DIGlobalVariableExpression(var: !47, expr: !DIExpression())
!47 = distinct !DIGlobalVariable(name: "C4", scope: !2, file: !11, line: 36, type: !48, isLocal: false, isDefinition: true, align: 512)
!48 = !DICompositeType(tag: DW_TAG_array_type, baseType: !5, size: 230400, elements: !49)
!49 = !{!41, !41}
!50 = !DIGlobalVariableExpression(var: !51, expr: !DIExpression())
!51 = distinct !DIGlobalVariable(name: "pb_emit", scope: !2, file: !34, line: 10, type: !12, isLocal: true, isDefinition: true)
!52 = !{i32 7, !"Dwarf Version", i32 5}
!53 = !{i32 2, !"Debug Info Version", i32 3}
!54 = !{i32 1, !"wchar_size", i32 4}
!55 = !{i32 7, !"PIC Level", i32 2}
!56 = !{i32 7, !"PIE Level", i32 2}
!57 = !{i32 7, !"uwtable", i32 1}
!58 = !{i32 7, !"frame-pointer", i32 2}
!59 = !{!"Ubuntu clang version 14.0.0-1ubuntu1.1"}
!60 = distinct !DISubprogram(name: "workload_prepare", scope: !11, file: !11, line: 104, type: !61, scopeLine: 104, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !2, retainedNodes: !63)
!61 = !DISubroutineType(types: !62)
!62 = !{null}
!63 = !{}
!64 = !DILocation(line: 104, column: 30, scope: !60)
!65 = distinct !DISubprogram(name: "workload_reset", scope: !11, file: !11, line: 105, type: !66, scopeLine: 105, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !2, retainedNodes: !63)
!66 = !DISubroutineType(types: !67)
!67 = !{null, !6}
!68 = !DILocalVariable(name: "task", arg: 1, scope: !65, file: !11, line: 105, type: !6)
!69 = !DILocation(line: 0, scope: !65)
!70 = !DILocation(line: 107, column: 3, scope: !65)
!71 = !DILocation(line: 108, column: 3, scope: !65)
!72 = !DILocation(line: 109, column: 3, scope: !65)
!73 = !DILocation(line: 110, column: 15, scope: !65)
!74 = !DILocation(line: 110, column: 19, scope: !65)
!75 = !DILocation(line: 110, column: 23, scope: !65)
!76 = !DILocation(line: 110, column: 3, scope: !65)
!77 = !DILocation(line: 113, column: 1, scope: !65)
!78 = distinct !DISubprogram(name: "init_array", scope: !11, file: !11, line: 38, type: !79, scopeLine: 41, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition, unit: !2, retainedNodes: !63)
!79 = !DISubroutineType(types: !80)
!80 = !{null, !12, !12, !12, !81, !84}
!81 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !82, size: 64)
!82 = !DICompositeType(tag: DW_TAG_array_type, baseType: !5, size: 153600, elements: !83)
!83 = !{!40, !41}
!84 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !44, size: 64)
!85 = !DILocalVariable(name: "nr", arg: 1, scope: !78, file: !11, line: 38, type: !12)
!86 = !DILocation(line: 0, scope: !78)
!87 = !DILocalVariable(name: "nq", arg: 2, scope: !78, file: !11, line: 38, type: !12)
!88 = !DILocalVariable(name: "np", arg: 3, scope: !78, file: !11, line: 38, type: !12)
!89 = !DILocalVariable(name: "A", arg: 4, scope: !78, file: !11, line: 39, type: !81)
!90 = !DILocalVariable(name: "C4", arg: 5, scope: !78, file: !11, line: 40, type: !84)
!91 = !DILocalVariable(name: "i", scope: !78, file: !11, line: 42, type: !12)
!92 = !DILocation(line: 44, column: 8, scope: !93)
!93 = distinct !DILexicalBlock(scope: !78, file: !11, line: 44, column: 3)
!94 = !DILocation(line: 0, scope: !93)
!95 = !DILocation(line: 44, column: 17, scope: !96)
!96 = distinct !DILexicalBlock(scope: !93, file: !11, line: 44, column: 3)
!97 = !DILocation(line: 44, column: 3, scope: !93)
!98 = !DILocalVariable(name: "j", scope: !78, file: !11, line: 42, type: !12)
!99 = !DILocation(line: 45, column: 10, scope: !100)
!100 = distinct !DILexicalBlock(scope: !96, file: !11, line: 45, column: 5)
!101 = !DILocation(line: 0, scope: !100)
!102 = !DILocation(line: 45, column: 19, scope: !103)
!103 = distinct !DILexicalBlock(scope: !100, file: !11, line: 45, column: 5)
!104 = !DILocation(line: 45, column: 5, scope: !100)
!105 = !DILocalVariable(name: "k", scope: !78, file: !11, line: 42, type: !12)
!106 = !DILocation(line: 46, column: 12, scope: !107)
!107 = distinct !DILexicalBlock(scope: !103, file: !11, line: 46, column: 7)
!108 = !DILocation(line: 0, scope: !107)
!109 = !DILocation(line: 46, column: 21, scope: !110)
!110 = distinct !DILexicalBlock(scope: !107, file: !11, line: 46, column: 7)
!111 = !DILocation(line: 46, column: 7, scope: !107)
!112 = !DILocation(line: 47, column: 30, scope: !110)
!113 = !DILocation(line: 47, column: 33, scope: !110)
!114 = !DILocation(line: 47, column: 37, scope: !110)
!115 = !DILocation(line: 47, column: 15, scope: !110)
!116 = !DILocation(line: 47, column: 44, scope: !110)
!117 = !DILocation(line: 47, column: 42, scope: !110)
!118 = !DILocation(line: 47, column: 2, scope: !110)
!119 = !DILocation(line: 47, column: 13, scope: !110)
!120 = !DILocation(line: 46, column: 28, scope: !110)
!121 = !DILocation(line: 46, column: 7, scope: !110)
!122 = distinct !{!122, !111, !123, !124}
!123 = !DILocation(line: 47, column: 44, scope: !107)
!124 = !{!"llvm.loop.mustprogress"}
!125 = !DILocation(line: 45, column: 26, scope: !103)
!126 = !DILocation(line: 45, column: 5, scope: !103)
!127 = distinct !{!127, !104, !128, !124}
!128 = !DILocation(line: 47, column: 44, scope: !100)
!129 = !DILocation(line: 44, column: 24, scope: !96)
!130 = !DILocation(line: 44, column: 3, scope: !96)
!131 = distinct !{!131, !97, !132, !124}
!132 = !DILocation(line: 47, column: 44, scope: !93)
!133 = !DILocation(line: 48, column: 8, scope: !134)
!134 = distinct !DILexicalBlock(scope: !78, file: !11, line: 48, column: 3)
!135 = !DILocation(line: 0, scope: !134)
!136 = !DILocation(line: 48, column: 17, scope: !137)
!137 = distinct !DILexicalBlock(scope: !134, file: !11, line: 48, column: 3)
!138 = !DILocation(line: 48, column: 3, scope: !134)
!139 = !DILocation(line: 49, column: 10, scope: !140)
!140 = distinct !DILexicalBlock(scope: !137, file: !11, line: 49, column: 5)
!141 = !DILocation(line: 0, scope: !140)
!142 = !DILocation(line: 49, column: 19, scope: !143)
!143 = distinct !DILexicalBlock(scope: !140, file: !11, line: 49, column: 5)
!144 = !DILocation(line: 49, column: 5, scope: !140)
!145 = !DILocation(line: 50, column: 32, scope: !143)
!146 = !DILocation(line: 50, column: 35, scope: !143)
!147 = !DILocation(line: 50, column: 18, scope: !143)
!148 = !DILocation(line: 50, column: 43, scope: !143)
!149 = !DILocation(line: 50, column: 41, scope: !143)
!150 = !DILocation(line: 50, column: 7, scope: !143)
!151 = !DILocation(line: 50, column: 16, scope: !143)
!152 = !DILocation(line: 49, column: 26, scope: !143)
!153 = !DILocation(line: 49, column: 5, scope: !143)
!154 = distinct !{!154, !144, !155, !124}
!155 = !DILocation(line: 50, column: 43, scope: !140)
!156 = !DILocation(line: 48, column: 24, scope: !137)
!157 = !DILocation(line: 48, column: 3, scope: !137)
!158 = distinct !{!158, !138, !159, !124}
!159 = !DILocation(line: 50, column: 43, scope: !134)
!160 = !DILocation(line: 51, column: 1, scope: !78)
!161 = distinct !DISubprogram(name: "task_job_polybench", scope: !11, file: !11, line: 114, type: !20, scopeLine: 114, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !2, retainedNodes: !63)
!162 = !DILocation(line: 115, column: 19, scope: !161)
!163 = !DILocation(line: 115, column: 23, scope: !161)
!164 = !DILocation(line: 115, column: 27, scope: !161)
!165 = !DILocalVariable(name: "nr", arg: 1, scope: !166, file: !11, line: 77, type: !12)
!166 = distinct !DISubprogram(name: "kernel_doitgen", scope: !11, file: !11, line: 77, type: !167, scopeLine: 81, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !2, retainedNodes: !63)
!167 = !DISubroutineType(types: !168)
!168 = !{null, !12, !12, !12, !81, !84, !169}
!169 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !5, size: 64)
!170 = !DILocation(line: 0, scope: !166, inlinedAt: !171)
!171 = distinct !DILocation(line: 115, column: 3, scope: !161)
!172 = !DILocalVariable(name: "nq", arg: 2, scope: !166, file: !11, line: 77, type: !12)
!173 = !DILocalVariable(name: "np", arg: 3, scope: !166, file: !11, line: 77, type: !12)
!174 = !DILocalVariable(name: "A", arg: 4, scope: !166, file: !11, line: 78, type: !81)
!175 = !DILocalVariable(name: "C4", arg: 5, scope: !166, file: !11, line: 79, type: !84)
!176 = !DILocalVariable(name: "sum", arg: 6, scope: !166, file: !11, line: 80, type: !169)
!177 = !DILocalVariable(name: "r", scope: !166, file: !11, line: 82, type: !12)
!178 = !DILocation(line: 85, column: 8, scope: !179, inlinedAt: !171)
!179 = distinct !DILexicalBlock(scope: !166, file: !11, line: 85, column: 3)
!180 = !DILocation(line: 0, scope: !179, inlinedAt: !171)
!181 = !DILocation(line: 85, column: 17, scope: !182, inlinedAt: !171)
!182 = distinct !DILexicalBlock(scope: !179, file: !11, line: 85, column: 3)
!183 = !DILocation(line: 85, column: 3, scope: !179, inlinedAt: !171)
!184 = !DILocalVariable(name: "q", scope: !166, file: !11, line: 82, type: !12)
!185 = !DILocation(line: 86, column: 10, scope: !186, inlinedAt: !171)
!186 = distinct !DILexicalBlock(scope: !182, file: !11, line: 86, column: 5)
!187 = !DILocation(line: 0, scope: !186, inlinedAt: !171)
!188 = !DILocation(line: 86, column: 19, scope: !189, inlinedAt: !171)
!189 = distinct !DILexicalBlock(scope: !186, file: !11, line: 86, column: 5)
!190 = !DILocation(line: 86, column: 5, scope: !186, inlinedAt: !171)
!191 = !DILocalVariable(name: "p", scope: !166, file: !11, line: 82, type: !12)
!192 = !DILocation(line: 87, column: 12, scope: !193, inlinedAt: !171)
!193 = distinct !DILexicalBlock(scope: !194, file: !11, line: 87, column: 7)
!194 = distinct !DILexicalBlock(scope: !189, file: !11, line: 86, column: 35)
!195 = !DILocation(line: 0, scope: !193, inlinedAt: !171)
!196 = !DILocation(line: 87, column: 21, scope: !197, inlinedAt: !171)
!197 = distinct !DILexicalBlock(scope: !193, file: !11, line: 87, column: 7)
!198 = !DILocation(line: 87, column: 7, scope: !193, inlinedAt: !171)
!199 = !DILocation(line: 88, column: 2, scope: !200, inlinedAt: !171)
!200 = distinct !DILexicalBlock(scope: !197, file: !11, line: 87, column: 37)
!201 = !DILocation(line: 88, column: 9, scope: !200, inlinedAt: !171)
!202 = !DILocalVariable(name: "s", scope: !166, file: !11, line: 82, type: !12)
!203 = !DILocation(line: 89, column: 7, scope: !204, inlinedAt: !171)
!204 = distinct !DILexicalBlock(scope: !200, file: !11, line: 89, column: 2)
!205 = !DILocation(line: 0, scope: !204, inlinedAt: !171)
!206 = !DILocation(line: 89, column: 16, scope: !207, inlinedAt: !171)
!207 = distinct !DILexicalBlock(scope: !204, file: !11, line: 89, column: 2)
!208 = !DILocation(line: 89, column: 2, scope: !204, inlinedAt: !171)
!209 = !DILocation(line: 90, column: 14, scope: !207, inlinedAt: !171)
!210 = !DILocation(line: 90, column: 27, scope: !207, inlinedAt: !171)
!211 = !DILocation(line: 90, column: 25, scope: !207, inlinedAt: !171)
!212 = !DILocation(line: 90, column: 4, scope: !207, inlinedAt: !171)
!213 = !DILocation(line: 90, column: 11, scope: !207, inlinedAt: !171)
!214 = !DILocation(line: 89, column: 27, scope: !207, inlinedAt: !171)
!215 = !DILocation(line: 89, column: 2, scope: !207, inlinedAt: !171)
!216 = distinct !{!216, !208, !217, !124}
!217 = !DILocation(line: 90, column: 34, scope: !204, inlinedAt: !171)
!218 = !DILocation(line: 87, column: 32, scope: !197, inlinedAt: !171)
!219 = !DILocation(line: 87, column: 7, scope: !197, inlinedAt: !171)
!220 = distinct !{!220, !198, !221, !124}
!221 = !DILocation(line: 91, column: 7, scope: !193, inlinedAt: !171)
!222 = !DILocation(line: 92, column: 12, scope: !223, inlinedAt: !171)
!223 = distinct !DILexicalBlock(scope: !194, file: !11, line: 92, column: 7)
!224 = !DILocation(line: 0, scope: !223, inlinedAt: !171)
!225 = !DILocation(line: 92, column: 21, scope: !226, inlinedAt: !171)
!226 = distinct !DILexicalBlock(scope: !223, file: !11, line: 92, column: 7)
!227 = !DILocation(line: 92, column: 7, scope: !223, inlinedAt: !171)
!228 = !DILocation(line: 93, column: 15, scope: !226, inlinedAt: !171)
!229 = !DILocation(line: 93, column: 2, scope: !226, inlinedAt: !171)
!230 = !DILocation(line: 93, column: 13, scope: !226, inlinedAt: !171)
!231 = !DILocation(line: 92, column: 32, scope: !226, inlinedAt: !171)
!232 = !DILocation(line: 92, column: 7, scope: !226, inlinedAt: !171)
!233 = distinct !{!233, !227, !234, !124}
!234 = !DILocation(line: 93, column: 20, scope: !223, inlinedAt: !171)
!235 = !DILocation(line: 86, column: 30, scope: !189, inlinedAt: !171)
!236 = !DILocation(line: 86, column: 5, scope: !189, inlinedAt: !171)
!237 = distinct !{!237, !190, !238, !124}
!238 = !DILocation(line: 94, column: 5, scope: !186, inlinedAt: !171)
!239 = !DILocation(line: 85, column: 28, scope: !182, inlinedAt: !171)
!240 = !DILocation(line: 85, column: 3, scope: !182, inlinedAt: !171)
!241 = distinct !{!241, !183, !242, !124}
!242 = !DILocation(line: 94, column: 5, scope: !179, inlinedAt: !171)
!243 = !DILocation(line: 119, column: 3, scope: !161)
!244 = distinct !DISubprogram(name: "workload_checksum", scope: !11, file: !11, line: 121, type: !245, scopeLine: 121, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !2, retainedNodes: !63)
!245 = !DISubroutineType(types: !246)
!246 = !{!22, !6}
!247 = !DILocalVariable(name: "task", arg: 1, scope: !244, file: !11, line: 121, type: !6)
!248 = !DILocation(line: 0, scope: !244)
!249 = !DILocation(line: 123, column: 11, scope: !244)
!250 = !DILocation(line: 124, column: 15, scope: !244)
!251 = !DILocation(line: 124, column: 19, scope: !244)
!252 = !DILocation(line: 124, column: 23, scope: !244)
!253 = !DILocation(line: 124, column: 3, scope: !244)
!254 = !DILocation(line: 125, column: 10, scope: !244)
!255 = !DILocation(line: 125, column: 3, scope: !244)
!256 = distinct !DISubprogram(name: "print_array", scope: !11, file: !11, line: 57, type: !257, scopeLine: 59, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition, unit: !2, retainedNodes: !63)
!257 = !DISubroutineType(types: !258)
!258 = !{null, !12, !12, !12, !81}
!259 = !DILocalVariable(name: "nr", arg: 1, scope: !256, file: !11, line: 57, type: !12)
!260 = !DILocation(line: 0, scope: !256)
!261 = !DILocalVariable(name: "nq", arg: 2, scope: !256, file: !11, line: 57, type: !12)
!262 = !DILocalVariable(name: "np", arg: 3, scope: !256, file: !11, line: 57, type: !12)
!263 = !DILocalVariable(name: "A", arg: 4, scope: !256, file: !11, line: 58, type: !81)
!264 = !DILocation(line: 62, column: 3, scope: !256)
!265 = !DILocation(line: 63, column: 3, scope: !256)
!266 = !DILocalVariable(name: "i", scope: !256, file: !11, line: 60, type: !12)
!267 = !DILocation(line: 64, column: 8, scope: !268)
!268 = distinct !DILexicalBlock(scope: !256, file: !11, line: 64, column: 3)
!269 = !DILocation(line: 0, scope: !268)
!270 = !DILocation(line: 64, column: 17, scope: !271)
!271 = distinct !DILexicalBlock(scope: !268, file: !11, line: 64, column: 3)
!272 = !DILocation(line: 64, column: 3, scope: !268)
!273 = !DILocalVariable(name: "j", scope: !256, file: !11, line: 60, type: !12)
!274 = !DILocation(line: 65, column: 10, scope: !275)
!275 = distinct !DILexicalBlock(scope: !271, file: !11, line: 65, column: 5)
!276 = !DILocation(line: 0, scope: !275)
!277 = !DILocation(line: 65, column: 19, scope: !278)
!278 = distinct !DILexicalBlock(scope: !275, file: !11, line: 65, column: 5)
!279 = !DILocation(line: 65, column: 5, scope: !275)
!280 = !DILocalVariable(name: "k", scope: !256, file: !11, line: 60, type: !12)
!281 = !DILocation(line: 66, column: 12, scope: !282)
!282 = distinct !DILexicalBlock(scope: !278, file: !11, line: 66, column: 7)
!283 = !DILocation(line: 0, scope: !282)
!284 = !DILocation(line: 66, column: 21, scope: !285)
!285 = distinct !DILexicalBlock(scope: !282, file: !11, line: 66, column: 7)
!286 = !DILocation(line: 66, column: 7, scope: !282)
!287 = !DILocation(line: 67, column: 8, scope: !288)
!288 = distinct !DILexicalBlock(scope: !289, file: !11, line: 67, column: 6)
!289 = distinct !DILexicalBlock(scope: !285, file: !11, line: 66, column: 32)
!290 = !DILocation(line: 67, column: 11, scope: !288)
!291 = !DILocation(line: 67, column: 16, scope: !288)
!292 = !DILocation(line: 67, column: 14, scope: !288)
!293 = !DILocation(line: 67, column: 19, scope: !288)
!294 = !DILocation(line: 67, column: 23, scope: !288)
!295 = !DILocation(line: 67, column: 28, scope: !288)
!296 = !DILocation(line: 67, column: 6, scope: !289)
!297 = !DILocation(line: 67, column: 43, scope: !288)
!298 = !DILocation(line: 67, column: 34, scope: !288)
!299 = !DILocation(line: 68, column: 11, scope: !289)
!300 = !DILocation(line: 68, column: 56, scope: !289)
!301 = !DILocation(line: 68, column: 2, scope: !289)
!302 = !DILocation(line: 69, column: 7, scope: !289)
!303 = !DILocation(line: 66, column: 28, scope: !285)
!304 = !DILocation(line: 66, column: 7, scope: !285)
!305 = distinct !{!305, !286, !306, !124}
!306 = !DILocation(line: 69, column: 7, scope: !282)
!307 = !DILocation(line: 65, column: 26, scope: !278)
!308 = !DILocation(line: 65, column: 5, scope: !278)
!309 = distinct !{!309, !279, !310, !124}
!310 = !DILocation(line: 69, column: 7, scope: !275)
!311 = !DILocation(line: 64, column: 24, scope: !271)
!312 = !DILocation(line: 64, column: 3, scope: !271)
!313 = distinct !{!313, !272, !314, !124}
!314 = !DILocation(line: 69, column: 7, scope: !268)
!315 = !DILocation(line: 70, column: 3, scope: !256)
!316 = !DILocation(line: 71, column: 3, scope: !256)
!317 = !DILocation(line: 72, column: 1, scope: !256)
!318 = distinct !DISubprogram(name: "pb_fprintf", scope: !34, file: !34, line: 13, type: !319, scopeLine: 14, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition, unit: !2, retainedNodes: !63)
!319 = !DISubroutineType(types: !320)
!320 = !{!12, !321, !380, null}
!321 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !322, size: 64)
!322 = !DIDerivedType(tag: DW_TAG_typedef, name: "FILE", file: !323, line: 7, baseType: !324)
!323 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/types/FILE.h", directory: "", checksumkind: CSK_MD5, checksum: "571f9fb6223c42439075fdde11a0de5d")
!324 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "_IO_FILE", file: !325, line: 49, size: 1728, elements: !326)
!325 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/types/struct_FILE.h", directory: "", checksumkind: CSK_MD5, checksum: "1bad07471b7974df4ecc1d1c2ca207e6")
!326 = !{!327, !328, !331, !332, !333, !334, !335, !336, !337, !338, !339, !340, !341, !344, !346, !347, !348, !351, !353, !355, !357, !360, !362, !365, !368, !369, !371, !375, !376}
!327 = !DIDerivedType(tag: DW_TAG_member, name: "_flags", scope: !324, file: !325, line: 51, baseType: !12, size: 32)
!328 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_read_ptr", scope: !324, file: !325, line: 54, baseType: !329, size: 64, offset: 64)
!329 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !330, size: 64)
!330 = !DIBasicType(name: "char", size: 8, encoding: DW_ATE_signed_char)
!331 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_read_end", scope: !324, file: !325, line: 55, baseType: !329, size: 64, offset: 128)
!332 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_read_base", scope: !324, file: !325, line: 56, baseType: !329, size: 64, offset: 192)
!333 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_write_base", scope: !324, file: !325, line: 57, baseType: !329, size: 64, offset: 256)
!334 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_write_ptr", scope: !324, file: !325, line: 58, baseType: !329, size: 64, offset: 320)
!335 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_write_end", scope: !324, file: !325, line: 59, baseType: !329, size: 64, offset: 384)
!336 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_buf_base", scope: !324, file: !325, line: 60, baseType: !329, size: 64, offset: 448)
!337 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_buf_end", scope: !324, file: !325, line: 61, baseType: !329, size: 64, offset: 512)
!338 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_save_base", scope: !324, file: !325, line: 64, baseType: !329, size: 64, offset: 576)
!339 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_backup_base", scope: !324, file: !325, line: 65, baseType: !329, size: 64, offset: 640)
!340 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_save_end", scope: !324, file: !325, line: 66, baseType: !329, size: 64, offset: 704)
!341 = !DIDerivedType(tag: DW_TAG_member, name: "_markers", scope: !324, file: !325, line: 68, baseType: !342, size: 64, offset: 768)
!342 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !343, size: 64)
!343 = !DICompositeType(tag: DW_TAG_structure_type, name: "_IO_marker", file: !325, line: 36, flags: DIFlagFwdDecl)
!344 = !DIDerivedType(tag: DW_TAG_member, name: "_chain", scope: !324, file: !325, line: 70, baseType: !345, size: 64, offset: 832)
!345 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !324, size: 64)
!346 = !DIDerivedType(tag: DW_TAG_member, name: "_fileno", scope: !324, file: !325, line: 72, baseType: !12, size: 32, offset: 896)
!347 = !DIDerivedType(tag: DW_TAG_member, name: "_flags2", scope: !324, file: !325, line: 73, baseType: !12, size: 32, offset: 928)
!348 = !DIDerivedType(tag: DW_TAG_member, name: "_old_offset", scope: !324, file: !325, line: 74, baseType: !349, size: 64, offset: 960)
!349 = !DIDerivedType(tag: DW_TAG_typedef, name: "__off_t", file: !25, line: 152, baseType: !350)
!350 = !DIBasicType(name: "long", size: 64, encoding: DW_ATE_signed)
!351 = !DIDerivedType(tag: DW_TAG_member, name: "_cur_column", scope: !324, file: !325, line: 77, baseType: !352, size: 16, offset: 1024)
!352 = !DIBasicType(name: "unsigned short", size: 16, encoding: DW_ATE_unsigned)
!353 = !DIDerivedType(tag: DW_TAG_member, name: "_vtable_offset", scope: !324, file: !325, line: 78, baseType: !354, size: 8, offset: 1040)
!354 = !DIBasicType(name: "signed char", size: 8, encoding: DW_ATE_signed_char)
!355 = !DIDerivedType(tag: DW_TAG_member, name: "_shortbuf", scope: !324, file: !325, line: 79, baseType: !356, size: 8, offset: 1048)
!356 = !DICompositeType(tag: DW_TAG_array_type, baseType: !330, size: 8, elements: !26)
!357 = !DIDerivedType(tag: DW_TAG_member, name: "_lock", scope: !324, file: !325, line: 81, baseType: !358, size: 64, offset: 1088)
!358 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !359, size: 64)
!359 = !DIDerivedType(tag: DW_TAG_typedef, name: "_IO_lock_t", file: !325, line: 43, baseType: null)
!360 = !DIDerivedType(tag: DW_TAG_member, name: "_offset", scope: !324, file: !325, line: 89, baseType: !361, size: 64, offset: 1152)
!361 = !DIDerivedType(tag: DW_TAG_typedef, name: "__off64_t", file: !25, line: 153, baseType: !350)
!362 = !DIDerivedType(tag: DW_TAG_member, name: "_codecvt", scope: !324, file: !325, line: 91, baseType: !363, size: 64, offset: 1216)
!363 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !364, size: 64)
!364 = !DICompositeType(tag: DW_TAG_structure_type, name: "_IO_codecvt", file: !325, line: 37, flags: DIFlagFwdDecl)
!365 = !DIDerivedType(tag: DW_TAG_member, name: "_wide_data", scope: !324, file: !325, line: 92, baseType: !366, size: 64, offset: 1280)
!366 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !367, size: 64)
!367 = !DICompositeType(tag: DW_TAG_structure_type, name: "_IO_wide_data", file: !325, line: 38, flags: DIFlagFwdDecl)
!368 = !DIDerivedType(tag: DW_TAG_member, name: "_freeres_list", scope: !324, file: !325, line: 93, baseType: !345, size: 64, offset: 1344)
!369 = !DIDerivedType(tag: DW_TAG_member, name: "_freeres_buf", scope: !324, file: !325, line: 94, baseType: !370, size: 64, offset: 1408)
!370 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: null, size: 64)
!371 = !DIDerivedType(tag: DW_TAG_member, name: "__pad5", scope: !324, file: !325, line: 95, baseType: !372, size: 64, offset: 1472)
!372 = !DIDerivedType(tag: DW_TAG_typedef, name: "size_t", file: !373, line: 46, baseType: !374)
!373 = !DIFile(filename: "/usr/lib/llvm-14/lib/clang/14.0.0/include/stddef.h", directory: "", checksumkind: CSK_MD5, checksum: "2499dd2361b915724b073282bea3a7bc")
!374 = !DIBasicType(name: "unsigned long", size: 64, encoding: DW_ATE_unsigned)
!375 = !DIDerivedType(tag: DW_TAG_member, name: "_mode", scope: !324, file: !325, line: 96, baseType: !12, size: 32, offset: 1536)
!376 = !DIDerivedType(tag: DW_TAG_member, name: "_unused2", scope: !324, file: !325, line: 98, baseType: !377, size: 160, offset: 1568)
!377 = !DICompositeType(tag: DW_TAG_array_type, baseType: !330, size: 160, elements: !378)
!378 = !{!379}
!379 = !DISubrange(count: 20)
!380 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !381, size: 64)
!381 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !330)
!382 = !DILocalVariable(name: "stream", arg: 1, scope: !318, file: !34, line: 13, type: !321)
!383 = !DILocation(line: 0, scope: !318)
!384 = !DILocalVariable(name: "format", arg: 2, scope: !318, file: !34, line: 13, type: !380)
!385 = !DILocalVariable(name: "buffer", scope: !318, file: !34, line: 15, type: !386)
!386 = !DICompositeType(tag: DW_TAG_array_type, baseType: !330, size: 6144, elements: !387)
!387 = !{!388}
!388 = !DISubrange(count: 768)
!389 = !DILocation(line: 15, column: 10, scope: !318)
!390 = !DILocalVariable(name: "args", scope: !318, file: !34, line: 16, type: !391)
!391 = !DIDerivedType(tag: DW_TAG_typedef, name: "va_list", file: !392, line: 52, baseType: !393)
!392 = !DIFile(filename: "/usr/include/stdio.h", directory: "", checksumkind: CSK_MD5, checksum: "f31eefcc3f15835fc5a4023a625cf609")
!393 = !DIDerivedType(tag: DW_TAG_typedef, name: "__gnuc_va_list", file: !394, line: 32, baseType: !395)
!394 = !DIFile(filename: "/usr/lib/llvm-14/lib/clang/14.0.0/include/stdarg.h", directory: "", checksumkind: CSK_MD5, checksum: "4de3cbd931b589d291e5c39387aecf82")
!395 = !DIDerivedType(tag: DW_TAG_typedef, name: "__builtin_va_list", file: !396, baseType: !397)
!396 = !DIFile(filename: "source/workload.c", directory: "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/affine-bounds-20260929/suite/doitgen")
!397 = !DICompositeType(tag: DW_TAG_array_type, baseType: !398, size: 192, elements: !26)
!398 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "__va_list_tag", size: 192, elements: !399)
!399 = !{!400, !401, !402, !403}
!400 = !DIDerivedType(tag: DW_TAG_member, name: "gp_offset", scope: !398, file: !396, line: 16, baseType: !6, size: 32)
!401 = !DIDerivedType(tag: DW_TAG_member, name: "fp_offset", scope: !398, file: !396, line: 16, baseType: !6, size: 32, offset: 32)
!402 = !DIDerivedType(tag: DW_TAG_member, name: "overflow_arg_area", scope: !398, file: !396, line: 16, baseType: !370, size: 64, offset: 64)
!403 = !DIDerivedType(tag: DW_TAG_member, name: "reg_save_area", scope: !398, file: !396, line: 16, baseType: !370, size: 64, offset: 128)
!404 = !DILocation(line: 16, column: 13, scope: !318)
!405 = !DILocation(line: 17, column: 5, scope: !318)
!406 = !DILocation(line: 18, column: 27, scope: !318)
!407 = !DILocation(line: 18, column: 59, scope: !318)
!408 = !DILocation(line: 18, column: 17, scope: !318)
!409 = !DILocalVariable(name: "count", scope: !318, file: !34, line: 18, type: !12)
!410 = !DILocation(line: 19, column: 5, scope: !318)
!411 = !DILocation(line: 20, column: 15, scope: !412)
!412 = distinct !DILexicalBlock(scope: !318, file: !34, line: 20, column: 9)
!413 = !DILocation(line: 20, column: 19, scope: !412)
!414 = !DILocation(line: 20, column: 22, scope: !412)
!415 = !DILocation(line: 20, column: 38, scope: !412)
!416 = !DILocation(line: 20, column: 9, scope: !318)
!417 = !DILocation(line: 20, column: 57, scope: !412)
!418 = !DILocalVariable(name: "i", scope: !419, file: !34, line: 21, type: !12)
!419 = distinct !DILexicalBlock(scope: !318, file: !34, line: 21, column: 5)
!420 = !DILocation(line: 0, scope: !419)
!421 = !DILocation(line: 21, column: 10, scope: !419)
!422 = !DILocation(line: 21, column: 23, scope: !423)
!423 = distinct !DILexicalBlock(scope: !419, file: !34, line: 21, column: 5)
!424 = !DILocation(line: 21, column: 5, scope: !419)
!425 = !DILocation(line: 22, column: 35, scope: !426)
!426 = distinct !DILexicalBlock(scope: !423, file: !34, line: 21, column: 37)
!427 = !DILocation(line: 22, column: 20, scope: !426)
!428 = !DILocation(line: 22, column: 17, scope: !426)
!429 = !DILocation(line: 23, column: 17, scope: !426)
!430 = !DILocation(line: 24, column: 5, scope: !426)
!431 = !DILocation(line: 21, column: 32, scope: !423)
!432 = !DILocation(line: 21, column: 5, scope: !423)
!433 = distinct !{!433, !424, !434, !124}
!434 = !DILocation(line: 24, column: 5, scope: !419)
!435 = !DILocation(line: 29, column: 11, scope: !318)
!436 = !DILocation(line: 31, column: 5, scope: !318)
