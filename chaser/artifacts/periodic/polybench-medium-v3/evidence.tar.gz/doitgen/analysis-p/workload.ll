; ModuleID = '/workspace/experiments-array-support/chaser/.cache/periodic-polybench/affine-bounds-20260929/suite/doitgen/source/workload.c'
source_filename = "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/affine-bounds-20260929/suite/doitgen/source/workload.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

%struct._IO_FILE = type { i32, i8*, i8*, i8*, i8*, i8*, i8*, i8*, i8*, i8*, i8*, i8*, %struct._IO_marker*, %struct._IO_FILE*, i32, i32, i64, i16, i8, [1 x i8], i8*, i64, %struct._IO_codecvt*, %struct._IO_wide_data*, %struct._IO_FILE*, i8*, i64, i32, [20 x i8] }
%struct._IO_marker = type opaque
%struct._IO_codecvt = type opaque
%struct._IO_wide_data = type opaque
%struct.__va_list_tag = type { i32, i32, i8*, i8* }

@nr = dso_local global i32 50, align 4, !dbg !0
@nq = dso_local global i32 40, align 4, !dbg !9
@np = dso_local global i32 60, align 4, !dbg !13
@A = dso_local global [50 x [40 x [60 x double]]] zeroinitializer, section ".chaser_data.A", align 64, !dbg !35
@sum = dso_local global [60 x double] zeroinitializer, section ".chaser_data.sum", align 64, !dbg !42
@C4 = dso_local global [60 x [60 x double]] zeroinitializer, section ".chaser_data.C4", align 64, !dbg !46
@.str = private unnamed_addr constant [12 x i8] c"ape.analyze\00", section "llvm.metadata"
@.str.1 = private unnamed_addr constant [125 x i8] c"/workspace/experiments-array-support/chaser/.cache/periodic-polybench/affine-bounds-20260929/suite/doitgen/source/workload.c\00", section "llvm.metadata"
@pb_hash = internal global i32 0, align 4, !dbg !32
@workload_jobs = dso_local constant [1 x i32 ()*] [i32 ()* @task_job_polybench], align 8, !dbg !15
@workload_expected = dso_local constant [1 x i32] [i32 86454017], align 4, !dbg !28
@stderr = external global %struct._IO_FILE*, align 8
@.str.2 = private unnamed_addr constant [23 x i8] c"==BEGIN DUMP_ARRAYS==\0A\00", align 1
@.str.3 = private unnamed_addr constant [15 x i8] c"begin dump: %s\00", align 1
@.str.4 = private unnamed_addr constant [2 x i8] c"A\00", align 1
@.str.5 = private unnamed_addr constant [2 x i8] c"\0A\00", align 1
@.str.6 = private unnamed_addr constant [8 x i8] c"%0.2lf \00", align 1
@.str.7 = private unnamed_addr constant [17 x i8] c"\0Aend   dump: %s\0A\00", align 1
@.str.8 = private unnamed_addr constant [23 x i8] c"==END   DUMP_ARRAYS==\0A\00", align 1
@pb_emit = internal global i32 1, align 4, !dbg !50
@llvm.global.annotations = appending global [1 x { i8*, i8*, i8*, i32, i8* }] [{ i8*, i8*, i8*, i32, i8* } { i8* bitcast (i32 ()* @task_job_polybench to i8*), i8* getelementptr inbounds ([12 x i8], [12 x i8]* @.str, i32 0, i32 0), i8* getelementptr inbounds ([125 x i8], [125 x i8]* @.str.1, i32 0, i32 0), i32 114, i8* null }], section "llvm.metadata"

; Function Attrs: noinline nounwind uwtable
define dso_local void @workload_prepare() #0 !dbg !60 {
  ret void, !dbg !64
}

; Function Attrs: noinline nounwind uwtable
define dso_local void @workload_reset(i32 noundef %0) #0 !dbg !65 {
  %2 = alloca i32, align 4
  store i32 %0, i32* %2, align 4
  call void @llvm.dbg.declare(metadata i32* %2, metadata !68, metadata !DIExpression()), !dbg !69
  %3 = load i32, i32* %2, align 4, !dbg !70
  call void @llvm.memset.p0i8.i64(i8* align 64 bitcast ([50 x [40 x [60 x double]]]* @A to i8*), i8 0, i64 960000, i1 false), !dbg !71
  call void @llvm.memset.p0i8.i64(i8* align 64 bitcast ([60 x double]* @sum to i8*), i8 0, i64 480, i1 false), !dbg !72
  call void @llvm.memset.p0i8.i64(i8* align 64 bitcast ([60 x [60 x double]]* @C4 to i8*), i8 0, i64 28800, i1 false), !dbg !73
  %4 = load i32, i32* @nr, align 4, !dbg !74
  %5 = load i32, i32* @nq, align 4, !dbg !75
  %6 = load i32, i32* @np, align 4, !dbg !76
  call void @init_array(i32 noundef %4, i32 noundef %5, i32 noundef %6, [40 x [60 x double]]* noundef getelementptr inbounds ([50 x [40 x [60 x double]]], [50 x [40 x [60 x double]]]* @A, i64 0, i64 0), [60 x double]* noundef getelementptr inbounds ([60 x [60 x double]], [60 x [60 x double]]* @C4, i64 0, i64 0)), !dbg !77
  ret void, !dbg !78
}

; Function Attrs: nofree nosync nounwind readnone speculatable willreturn
declare void @llvm.dbg.declare(metadata, metadata, metadata) #1

; Function Attrs: argmemonly nofree nounwind willreturn writeonly
declare void @llvm.memset.p0i8.i64(i8* nocapture writeonly, i8, i64, i1 immarg) #2

; Function Attrs: noinline nounwind uwtable
define internal void @init_array(i32 noundef %0, i32 noundef %1, i32 noundef %2, [40 x [60 x double]]* noundef %3, [60 x double]* noundef %4) #0 !dbg !79 {
  %6 = alloca i32, align 4
  %7 = alloca i32, align 4
  %8 = alloca i32, align 4
  %9 = alloca [40 x [60 x double]]*, align 8
  %10 = alloca [60 x double]*, align 8
  %11 = alloca i32, align 4
  %12 = alloca i32, align 4
  %13 = alloca i32, align 4
  store i32 %0, i32* %6, align 4
  call void @llvm.dbg.declare(metadata i32* %6, metadata !86, metadata !DIExpression()), !dbg !87
  store i32 %1, i32* %7, align 4
  call void @llvm.dbg.declare(metadata i32* %7, metadata !88, metadata !DIExpression()), !dbg !89
  store i32 %2, i32* %8, align 4
  call void @llvm.dbg.declare(metadata i32* %8, metadata !90, metadata !DIExpression()), !dbg !91
  store [40 x [60 x double]]* %3, [40 x [60 x double]]** %9, align 8
  call void @llvm.dbg.declare(metadata [40 x [60 x double]]** %9, metadata !92, metadata !DIExpression()), !dbg !93
  store [60 x double]* %4, [60 x double]** %10, align 8
  call void @llvm.dbg.declare(metadata [60 x double]** %10, metadata !94, metadata !DIExpression()), !dbg !95
  call void @llvm.dbg.declare(metadata i32* %11, metadata !96, metadata !DIExpression()), !dbg !97
  call void @llvm.dbg.declare(metadata i32* %12, metadata !98, metadata !DIExpression()), !dbg !99
  call void @llvm.dbg.declare(metadata i32* %13, metadata !100, metadata !DIExpression()), !dbg !101
  store i32 0, i32* %11, align 4, !dbg !102
  br label %14, !dbg !104

14:                                               ; preds = %58, %5
  %15 = load i32, i32* %11, align 4, !dbg !105
  %16 = load i32, i32* %6, align 4, !dbg !107
  %17 = icmp slt i32 %15, %16, !dbg !108
  br i1 %17, label %18, label %61, !dbg !109

18:                                               ; preds = %14
  store i32 0, i32* %12, align 4, !dbg !110
  br label %19, !dbg !112

19:                                               ; preds = %54, %18
  %20 = load i32, i32* %12, align 4, !dbg !113
  %21 = load i32, i32* %7, align 4, !dbg !115
  %22 = icmp slt i32 %20, %21, !dbg !116
  br i1 %22, label %23, label %57, !dbg !117

23:                                               ; preds = %19
  store i32 0, i32* %13, align 4, !dbg !118
  br label %24, !dbg !120

24:                                               ; preds = %50, %23
  %25 = load i32, i32* %13, align 4, !dbg !121
  %26 = load i32, i32* %8, align 4, !dbg !123
  %27 = icmp slt i32 %25, %26, !dbg !124
  br i1 %27, label %28, label %53, !dbg !125

28:                                               ; preds = %24
  %29 = load i32, i32* %11, align 4, !dbg !126
  %30 = load i32, i32* %12, align 4, !dbg !127
  %31 = mul nsw i32 %29, %30, !dbg !128
  %32 = load i32, i32* %13, align 4, !dbg !129
  %33 = add nsw i32 %31, %32, !dbg !130
  %34 = load i32, i32* %8, align 4, !dbg !131
  %35 = srem i32 %33, %34, !dbg !132
  %36 = sitofp i32 %35 to double, !dbg !133
  %37 = load i32, i32* %8, align 4, !dbg !134
  %38 = sitofp i32 %37 to double, !dbg !134
  %39 = fdiv double %36, %38, !dbg !135
  %40 = load [40 x [60 x double]]*, [40 x [60 x double]]** %9, align 8, !dbg !136
  %41 = load i32, i32* %11, align 4, !dbg !137
  %42 = sext i32 %41 to i64, !dbg !136
  %43 = getelementptr inbounds [40 x [60 x double]], [40 x [60 x double]]* %40, i64 %42, !dbg !136
  %44 = load i32, i32* %12, align 4, !dbg !138
  %45 = sext i32 %44 to i64, !dbg !136
  %46 = getelementptr inbounds [40 x [60 x double]], [40 x [60 x double]]* %43, i64 0, i64 %45, !dbg !136
  %47 = load i32, i32* %13, align 4, !dbg !139
  %48 = sext i32 %47 to i64, !dbg !136
  %49 = getelementptr inbounds [60 x double], [60 x double]* %46, i64 0, i64 %48, !dbg !136
  store double %39, double* %49, align 8, !dbg !140
  br label %50, !dbg !136

50:                                               ; preds = %28
  %51 = load i32, i32* %13, align 4, !dbg !141
  %52 = add nsw i32 %51, 1, !dbg !141
  store i32 %52, i32* %13, align 4, !dbg !141
  br label %24, !dbg !142, !llvm.loop !143

53:                                               ; preds = %24
  br label %54, !dbg !144

54:                                               ; preds = %53
  %55 = load i32, i32* %12, align 4, !dbg !146
  %56 = add nsw i32 %55, 1, !dbg !146
  store i32 %56, i32* %12, align 4, !dbg !146
  br label %19, !dbg !147, !llvm.loop !148

57:                                               ; preds = %19
  br label %58, !dbg !149

58:                                               ; preds = %57
  %59 = load i32, i32* %11, align 4, !dbg !150
  %60 = add nsw i32 %59, 1, !dbg !150
  store i32 %60, i32* %11, align 4, !dbg !150
  br label %14, !dbg !151, !llvm.loop !152

61:                                               ; preds = %14
  store i32 0, i32* %11, align 4, !dbg !154
  br label %62, !dbg !156

62:                                               ; preds = %92, %61
  %63 = load i32, i32* %11, align 4, !dbg !157
  %64 = load i32, i32* %8, align 4, !dbg !159
  %65 = icmp slt i32 %63, %64, !dbg !160
  br i1 %65, label %66, label %95, !dbg !161

66:                                               ; preds = %62
  store i32 0, i32* %12, align 4, !dbg !162
  br label %67, !dbg !164

67:                                               ; preds = %88, %66
  %68 = load i32, i32* %12, align 4, !dbg !165
  %69 = load i32, i32* %8, align 4, !dbg !167
  %70 = icmp slt i32 %68, %69, !dbg !168
  br i1 %70, label %71, label %91, !dbg !169

71:                                               ; preds = %67
  %72 = load i32, i32* %11, align 4, !dbg !170
  %73 = load i32, i32* %12, align 4, !dbg !171
  %74 = mul nsw i32 %72, %73, !dbg !172
  %75 = load i32, i32* %8, align 4, !dbg !173
  %76 = srem i32 %74, %75, !dbg !174
  %77 = sitofp i32 %76 to double, !dbg !175
  %78 = load i32, i32* %8, align 4, !dbg !176
  %79 = sitofp i32 %78 to double, !dbg !176
  %80 = fdiv double %77, %79, !dbg !177
  %81 = load [60 x double]*, [60 x double]** %10, align 8, !dbg !178
  %82 = load i32, i32* %11, align 4, !dbg !179
  %83 = sext i32 %82 to i64, !dbg !178
  %84 = getelementptr inbounds [60 x double], [60 x double]* %81, i64 %83, !dbg !178
  %85 = load i32, i32* %12, align 4, !dbg !180
  %86 = sext i32 %85 to i64, !dbg !178
  %87 = getelementptr inbounds [60 x double], [60 x double]* %84, i64 0, i64 %86, !dbg !178
  store double %80, double* %87, align 8, !dbg !181
  br label %88, !dbg !178

88:                                               ; preds = %71
  %89 = load i32, i32* %12, align 4, !dbg !182
  %90 = add nsw i32 %89, 1, !dbg !182
  store i32 %90, i32* %12, align 4, !dbg !182
  br label %67, !dbg !183, !llvm.loop !184

91:                                               ; preds = %67
  br label %92, !dbg !185

92:                                               ; preds = %91
  %93 = load i32, i32* %11, align 4, !dbg !186
  %94 = add nsw i32 %93, 1, !dbg !186
  store i32 %94, i32* %11, align 4, !dbg !186
  br label %62, !dbg !187, !llvm.loop !188

95:                                               ; preds = %62
  ret void, !dbg !190
}

; Function Attrs: noinline nounwind uwtable
define dso_local i32 @task_job_polybench() #0 !dbg !191 {
  %1 = alloca i32, align 4
  %2 = alloca i32, align 4
  %3 = alloca i32, align 4
  %4 = alloca [40 x [60 x double]]*, align 8
  %5 = alloca [60 x double]*, align 8
  %6 = alloca double*, align 8
  %7 = alloca i32, align 4
  %8 = alloca i32, align 4
  %9 = alloca i32, align 4
  %10 = alloca i32, align 4
  %11 = load i32, i32* @nr, align 4, !dbg !192
  %12 = load i32, i32* @nq, align 4, !dbg !193
  %13 = load i32, i32* @np, align 4, !dbg !194
  store i32 %11, i32* %1, align 4
  call void @llvm.dbg.declare(metadata i32* %1, metadata !195, metadata !DIExpression()), !dbg !200
  store i32 %12, i32* %2, align 4
  call void @llvm.dbg.declare(metadata i32* %2, metadata !202, metadata !DIExpression()), !dbg !203
  store i32 %13, i32* %3, align 4
  call void @llvm.dbg.declare(metadata i32* %3, metadata !204, metadata !DIExpression()), !dbg !205
  store [40 x [60 x double]]* getelementptr inbounds ([50 x [40 x [60 x double]]], [50 x [40 x [60 x double]]]* @A, i64 0, i64 0), [40 x [60 x double]]** %4, align 8
  call void @llvm.dbg.declare(metadata [40 x [60 x double]]** %4, metadata !206, metadata !DIExpression()), !dbg !207
  store [60 x double]* getelementptr inbounds ([60 x [60 x double]], [60 x [60 x double]]* @C4, i64 0, i64 0), [60 x double]** %5, align 8
  call void @llvm.dbg.declare(metadata [60 x double]** %5, metadata !208, metadata !DIExpression()), !dbg !209
  store double* getelementptr inbounds ([60 x double], [60 x double]* @sum, i64 0, i64 0), double** %6, align 8
  call void @llvm.dbg.declare(metadata double** %6, metadata !210, metadata !DIExpression()), !dbg !211
  call void @llvm.dbg.declare(metadata i32* %7, metadata !212, metadata !DIExpression()), !dbg !213
  call void @llvm.dbg.declare(metadata i32* %8, metadata !214, metadata !DIExpression()), !dbg !215
  call void @llvm.dbg.declare(metadata i32* %9, metadata !216, metadata !DIExpression()), !dbg !217
  call void @llvm.dbg.declare(metadata i32* %10, metadata !218, metadata !DIExpression()), !dbg !219
  store i32 0, i32* %7, align 4, !dbg !220
  br label %14, !dbg !222

14:                                               ; preds = %90, %0
  %15 = load i32, i32* %7, align 4, !dbg !223
  %16 = icmp slt i32 %15, 50, !dbg !225
  br i1 %16, label %17, label %93, !dbg !226

17:                                               ; preds = %14
  store i32 0, i32* %8, align 4, !dbg !227
  br label %18, !dbg !229

18:                                               ; preds = %87, %17
  %19 = load i32, i32* %8, align 4, !dbg !230
  %20 = icmp slt i32 %19, 40, !dbg !232
  br i1 %20, label %21, label %90, !dbg !233

21:                                               ; preds = %18
  store i32 0, i32* %9, align 4, !dbg !234
  br label %22, !dbg !237

22:                                               ; preds = %62, %21
  %23 = load i32, i32* %9, align 4, !dbg !238
  %24 = icmp slt i32 %23, 60, !dbg !240
  br i1 %24, label %25, label %65, !dbg !241

25:                                               ; preds = %22
  %26 = load double*, double** %6, align 8, !dbg !242
  %27 = load i32, i32* %9, align 4, !dbg !244
  %28 = sext i32 %27 to i64, !dbg !242
  %29 = getelementptr inbounds double, double* %26, i64 %28, !dbg !242
  store double 0.000000e+00, double* %29, align 8, !dbg !245
  store i32 0, i32* %10, align 4, !dbg !246
  br label %30, !dbg !248

30:                                               ; preds = %33, %25
  %31 = load i32, i32* %10, align 4, !dbg !249
  %32 = icmp slt i32 %31, 60, !dbg !251
  br i1 %32, label %33, label %62, !dbg !252

33:                                               ; preds = %30
  %34 = load [40 x [60 x double]]*, [40 x [60 x double]]** %4, align 8, !dbg !253
  %35 = load i32, i32* %7, align 4, !dbg !254
  %36 = sext i32 %35 to i64, !dbg !253
  %37 = getelementptr inbounds [40 x [60 x double]], [40 x [60 x double]]* %34, i64 %36, !dbg !253
  %38 = load i32, i32* %8, align 4, !dbg !255
  %39 = sext i32 %38 to i64, !dbg !253
  %40 = getelementptr inbounds [40 x [60 x double]], [40 x [60 x double]]* %37, i64 0, i64 %39, !dbg !253
  %41 = load i32, i32* %10, align 4, !dbg !256
  %42 = sext i32 %41 to i64, !dbg !253
  %43 = getelementptr inbounds [60 x double], [60 x double]* %40, i64 0, i64 %42, !dbg !253
  %44 = load double, double* %43, align 8, !dbg !253
  %45 = load [60 x double]*, [60 x double]** %5, align 8, !dbg !257
  %46 = load i32, i32* %10, align 4, !dbg !258
  %47 = sext i32 %46 to i64, !dbg !257
  %48 = getelementptr inbounds [60 x double], [60 x double]* %45, i64 %47, !dbg !257
  %49 = load i32, i32* %9, align 4, !dbg !259
  %50 = sext i32 %49 to i64, !dbg !257
  %51 = getelementptr inbounds [60 x double], [60 x double]* %48, i64 0, i64 %50, !dbg !257
  %52 = load double, double* %51, align 8, !dbg !257
  %53 = fmul double %44, %52, !dbg !260
  %54 = load double*, double** %6, align 8, !dbg !261
  %55 = load i32, i32* %9, align 4, !dbg !262
  %56 = sext i32 %55 to i64, !dbg !261
  %57 = getelementptr inbounds double, double* %54, i64 %56, !dbg !261
  %58 = load double, double* %57, align 8, !dbg !263
  %59 = fadd double %58, %53, !dbg !263
  store double %59, double* %57, align 8, !dbg !263
  %60 = load i32, i32* %10, align 4, !dbg !264
  %61 = add nsw i32 %60, 1, !dbg !264
  store i32 %61, i32* %10, align 4, !dbg !264
  br label %30, !dbg !265, !llvm.loop !266

62:                                               ; preds = %30
  %63 = load i32, i32* %9, align 4, !dbg !268
  %64 = add nsw i32 %63, 1, !dbg !268
  store i32 %64, i32* %9, align 4, !dbg !268
  br label %22, !dbg !269, !llvm.loop !270

65:                                               ; preds = %22
  store i32 0, i32* %9, align 4, !dbg !272
  br label %66, !dbg !274

66:                                               ; preds = %69, %65
  %67 = load i32, i32* %9, align 4, !dbg !275
  %68 = icmp slt i32 %67, 60, !dbg !277
  br i1 %68, label %69, label %87, !dbg !278

69:                                               ; preds = %66
  %70 = load double*, double** %6, align 8, !dbg !279
  %71 = load i32, i32* %9, align 4, !dbg !280
  %72 = sext i32 %71 to i64, !dbg !279
  %73 = getelementptr inbounds double, double* %70, i64 %72, !dbg !279
  %74 = load double, double* %73, align 8, !dbg !279
  %75 = load [40 x [60 x double]]*, [40 x [60 x double]]** %4, align 8, !dbg !281
  %76 = load i32, i32* %7, align 4, !dbg !282
  %77 = sext i32 %76 to i64, !dbg !281
  %78 = getelementptr inbounds [40 x [60 x double]], [40 x [60 x double]]* %75, i64 %77, !dbg !281
  %79 = load i32, i32* %8, align 4, !dbg !283
  %80 = sext i32 %79 to i64, !dbg !281
  %81 = getelementptr inbounds [40 x [60 x double]], [40 x [60 x double]]* %78, i64 0, i64 %80, !dbg !281
  %82 = load i32, i32* %9, align 4, !dbg !284
  %83 = sext i32 %82 to i64, !dbg !281
  %84 = getelementptr inbounds [60 x double], [60 x double]* %81, i64 0, i64 %83, !dbg !281
  store double %74, double* %84, align 8, !dbg !285
  %85 = load i32, i32* %9, align 4, !dbg !286
  %86 = add nsw i32 %85, 1, !dbg !286
  store i32 %86, i32* %9, align 4, !dbg !286
  br label %66, !dbg !287, !llvm.loop !288

87:                                               ; preds = %66
  %88 = load i32, i32* %8, align 4, !dbg !290
  %89 = add nsw i32 %88, 1, !dbg !290
  store i32 %89, i32* %8, align 4, !dbg !290
  br label %18, !dbg !291, !llvm.loop !292

90:                                               ; preds = %18
  %91 = load i32, i32* %7, align 4, !dbg !294
  %92 = add nsw i32 %91, 1, !dbg !294
  store i32 %92, i32* %7, align 4, !dbg !294
  br label %14, !dbg !295, !llvm.loop !296

93:                                               ; preds = %14
  ret i32 0, !dbg !298
}

; Function Attrs: noinline nounwind uwtable
define dso_local i32 @workload_checksum(i32 noundef %0) #0 !dbg !299 {
  %2 = alloca i32, align 4
  store i32 %0, i32* %2, align 4
  call void @llvm.dbg.declare(metadata i32* %2, metadata !302, metadata !DIExpression()), !dbg !303
  %3 = load i32, i32* %2, align 4, !dbg !304
  store i32 -2128831035, i32* @pb_hash, align 4, !dbg !305
  %4 = load i32, i32* @nr, align 4, !dbg !306
  %5 = load i32, i32* @nq, align 4, !dbg !307
  %6 = load i32, i32* @np, align 4, !dbg !308
  call void @print_array(i32 noundef %4, i32 noundef %5, i32 noundef %6, [40 x [60 x double]]* noundef getelementptr inbounds ([50 x [40 x [60 x double]]], [50 x [40 x [60 x double]]]* @A, i64 0, i64 0)), !dbg !309
  %7 = load i32, i32* @pb_hash, align 4, !dbg !310
  ret i32 %7, !dbg !311
}

; Function Attrs: noinline nounwind uwtable
define internal void @print_array(i32 noundef %0, i32 noundef %1, i32 noundef %2, [40 x [60 x double]]* noundef %3) #0 !dbg !312 {
  %5 = alloca i32, align 4
  %6 = alloca i32, align 4
  %7 = alloca i32, align 4
  %8 = alloca [40 x [60 x double]]*, align 8
  %9 = alloca i32, align 4
  %10 = alloca i32, align 4
  %11 = alloca i32, align 4
  store i32 %0, i32* %5, align 4
  call void @llvm.dbg.declare(metadata i32* %5, metadata !315, metadata !DIExpression()), !dbg !316
  store i32 %1, i32* %6, align 4
  call void @llvm.dbg.declare(metadata i32* %6, metadata !317, metadata !DIExpression()), !dbg !318
  store i32 %2, i32* %7, align 4
  call void @llvm.dbg.declare(metadata i32* %7, metadata !319, metadata !DIExpression()), !dbg !320
  store [40 x [60 x double]]* %3, [40 x [60 x double]]** %8, align 8
  call void @llvm.dbg.declare(metadata [40 x [60 x double]]** %8, metadata !321, metadata !DIExpression()), !dbg !322
  call void @llvm.dbg.declare(metadata i32* %9, metadata !323, metadata !DIExpression()), !dbg !324
  call void @llvm.dbg.declare(metadata i32* %10, metadata !325, metadata !DIExpression()), !dbg !326
  call void @llvm.dbg.declare(metadata i32* %11, metadata !327, metadata !DIExpression()), !dbg !328
  %12 = load %struct._IO_FILE*, %struct._IO_FILE** @stderr, align 8, !dbg !329
  %13 = call i32 (%struct._IO_FILE*, i8*, ...) @pb_fprintf(%struct._IO_FILE* noundef %12, i8* noundef getelementptr inbounds ([23 x i8], [23 x i8]* @.str.2, i64 0, i64 0)), !dbg !329
  %14 = load %struct._IO_FILE*, %struct._IO_FILE** @stderr, align 8, !dbg !330
  %15 = call i32 (%struct._IO_FILE*, i8*, ...) @pb_fprintf(%struct._IO_FILE* noundef %14, i8* noundef getelementptr inbounds ([15 x i8], [15 x i8]* @.str.3, i64 0, i64 0), i8* noundef getelementptr inbounds ([2 x i8], [2 x i8]* @.str.4, i64 0, i64 0)), !dbg !330
  store i32 0, i32* %9, align 4, !dbg !331
  br label %16, !dbg !333

16:                                               ; preds = %69, %4
  %17 = load i32, i32* %9, align 4, !dbg !334
  %18 = load i32, i32* %5, align 4, !dbg !336
  %19 = icmp slt i32 %17, %18, !dbg !337
  br i1 %19, label %20, label %72, !dbg !338

20:                                               ; preds = %16
  store i32 0, i32* %10, align 4, !dbg !339
  br label %21, !dbg !341

21:                                               ; preds = %65, %20
  %22 = load i32, i32* %10, align 4, !dbg !342
  %23 = load i32, i32* %6, align 4, !dbg !344
  %24 = icmp slt i32 %22, %23, !dbg !345
  br i1 %24, label %25, label %68, !dbg !346

25:                                               ; preds = %21
  store i32 0, i32* %11, align 4, !dbg !347
  br label %26, !dbg !349

26:                                               ; preds = %61, %25
  %27 = load i32, i32* %11, align 4, !dbg !350
  %28 = load i32, i32* %7, align 4, !dbg !352
  %29 = icmp slt i32 %27, %28, !dbg !353
  br i1 %29, label %30, label %64, !dbg !354

30:                                               ; preds = %26
  %31 = load i32, i32* %9, align 4, !dbg !355
  %32 = load i32, i32* %6, align 4, !dbg !358
  %33 = mul nsw i32 %31, %32, !dbg !359
  %34 = load i32, i32* %7, align 4, !dbg !360
  %35 = mul nsw i32 %33, %34, !dbg !361
  %36 = load i32, i32* %10, align 4, !dbg !362
  %37 = load i32, i32* %7, align 4, !dbg !363
  %38 = mul nsw i32 %36, %37, !dbg !364
  %39 = add nsw i32 %35, %38, !dbg !365
  %40 = load i32, i32* %11, align 4, !dbg !366
  %41 = add nsw i32 %39, %40, !dbg !367
  %42 = srem i32 %41, 20, !dbg !368
  %43 = icmp eq i32 %42, 0, !dbg !369
  br i1 %43, label %44, label %47, !dbg !370

44:                                               ; preds = %30
  %45 = load %struct._IO_FILE*, %struct._IO_FILE** @stderr, align 8, !dbg !371
  %46 = call i32 (%struct._IO_FILE*, i8*, ...) @pb_fprintf(%struct._IO_FILE* noundef %45, i8* noundef getelementptr inbounds ([2 x i8], [2 x i8]* @.str.5, i64 0, i64 0)), !dbg !372
  br label %47, !dbg !372

47:                                               ; preds = %44, %30
  %48 = load %struct._IO_FILE*, %struct._IO_FILE** @stderr, align 8, !dbg !373
  %49 = load [40 x [60 x double]]*, [40 x [60 x double]]** %8, align 8, !dbg !374
  %50 = load i32, i32* %9, align 4, !dbg !375
  %51 = sext i32 %50 to i64, !dbg !374
  %52 = getelementptr inbounds [40 x [60 x double]], [40 x [60 x double]]* %49, i64 %51, !dbg !374
  %53 = load i32, i32* %10, align 4, !dbg !376
  %54 = sext i32 %53 to i64, !dbg !374
  %55 = getelementptr inbounds [40 x [60 x double]], [40 x [60 x double]]* %52, i64 0, i64 %54, !dbg !374
  %56 = load i32, i32* %11, align 4, !dbg !377
  %57 = sext i32 %56 to i64, !dbg !374
  %58 = getelementptr inbounds [60 x double], [60 x double]* %55, i64 0, i64 %57, !dbg !374
  %59 = load double, double* %58, align 8, !dbg !374
  %60 = call i32 (%struct._IO_FILE*, i8*, ...) @pb_fprintf(%struct._IO_FILE* noundef %48, i8* noundef getelementptr inbounds ([8 x i8], [8 x i8]* @.str.6, i64 0, i64 0), double noundef %59), !dbg !378
  br label %61, !dbg !379

61:                                               ; preds = %47
  %62 = load i32, i32* %11, align 4, !dbg !380
  %63 = add nsw i32 %62, 1, !dbg !380
  store i32 %63, i32* %11, align 4, !dbg !380
  br label %26, !dbg !381, !llvm.loop !382

64:                                               ; preds = %26
  br label %65, !dbg !383

65:                                               ; preds = %64
  %66 = load i32, i32* %10, align 4, !dbg !384
  %67 = add nsw i32 %66, 1, !dbg !384
  store i32 %67, i32* %10, align 4, !dbg !384
  br label %21, !dbg !385, !llvm.loop !386

68:                                               ; preds = %21
  br label %69, !dbg !387

69:                                               ; preds = %68
  %70 = load i32, i32* %9, align 4, !dbg !388
  %71 = add nsw i32 %70, 1, !dbg !388
  store i32 %71, i32* %9, align 4, !dbg !388
  br label %16, !dbg !389, !llvm.loop !390

72:                                               ; preds = %16
  %73 = load %struct._IO_FILE*, %struct._IO_FILE** @stderr, align 8, !dbg !392
  %74 = call i32 (%struct._IO_FILE*, i8*, ...) @pb_fprintf(%struct._IO_FILE* noundef %73, i8* noundef getelementptr inbounds ([17 x i8], [17 x i8]* @.str.7, i64 0, i64 0), i8* noundef getelementptr inbounds ([2 x i8], [2 x i8]* @.str.4, i64 0, i64 0)), !dbg !392
  %75 = load %struct._IO_FILE*, %struct._IO_FILE** @stderr, align 8, !dbg !393
  %76 = call i32 (%struct._IO_FILE*, i8*, ...) @pb_fprintf(%struct._IO_FILE* noundef %75, i8* noundef getelementptr inbounds ([23 x i8], [23 x i8]* @.str.8, i64 0, i64 0)), !dbg !393
  ret void, !dbg !394
}

; Function Attrs: noinline nounwind uwtable
define internal i32 @pb_fprintf(%struct._IO_FILE* noundef %0, i8* noundef %1, ...) #0 !dbg !395 {
  %3 = alloca %struct._IO_FILE*, align 8
  %4 = alloca i8*, align 8
  %5 = alloca [768 x i8], align 16
  %6 = alloca [1 x %struct.__va_list_tag], align 16
  %7 = alloca i32, align 4
  %8 = alloca i32, align 4
  store %struct._IO_FILE* %0, %struct._IO_FILE** %3, align 8
  call void @llvm.dbg.declare(metadata %struct._IO_FILE** %3, metadata !459, metadata !DIExpression()), !dbg !460
  store i8* %1, i8** %4, align 8
  call void @llvm.dbg.declare(metadata i8** %4, metadata !461, metadata !DIExpression()), !dbg !462
  call void @llvm.dbg.declare(metadata [768 x i8]* %5, metadata !463, metadata !DIExpression()), !dbg !467
  call void @llvm.dbg.declare(metadata [1 x %struct.__va_list_tag]* %6, metadata !468, metadata !DIExpression()), !dbg !482
  %9 = getelementptr inbounds [1 x %struct.__va_list_tag], [1 x %struct.__va_list_tag]* %6, i64 0, i64 0, !dbg !483
  %10 = bitcast %struct.__va_list_tag* %9 to i8*, !dbg !483
  call void @llvm.va_start(i8* %10), !dbg !483
  call void @llvm.dbg.declare(metadata i32* %7, metadata !484, metadata !DIExpression()), !dbg !485
  %11 = getelementptr inbounds [768 x i8], [768 x i8]* %5, i64 0, i64 0, !dbg !486
  %12 = load i8*, i8** %4, align 8, !dbg !487
  %13 = getelementptr inbounds [1 x %struct.__va_list_tag], [1 x %struct.__va_list_tag]* %6, i64 0, i64 0, !dbg !488
  %14 = call i32 @vsnprintf(i8* noundef %11, i64 noundef 768, i8* noundef %12, %struct.__va_list_tag* noundef %13) #6, !dbg !489
  store i32 %14, i32* %7, align 4, !dbg !485
  %15 = getelementptr inbounds [1 x %struct.__va_list_tag], [1 x %struct.__va_list_tag]* %6, i64 0, i64 0, !dbg !490
  %16 = bitcast %struct.__va_list_tag* %15 to i8*, !dbg !490
  call void @llvm.va_end(i8* %16), !dbg !490
  %17 = load i32, i32* %7, align 4, !dbg !491
  %18 = icmp slt i32 %17, 0, !dbg !493
  br i1 %18, label %23, label %19, !dbg !494

19:                                               ; preds = %2
  %20 = load i32, i32* %7, align 4, !dbg !495
  %21 = zext i32 %20 to i64, !dbg !496
  %22 = icmp uge i64 %21, 768, !dbg !497
  br i1 %22, label %23, label %24, !dbg !498

23:                                               ; preds = %19, %2
  call void @abort() #7, !dbg !499
  unreachable, !dbg !499

24:                                               ; preds = %19
  call void @llvm.dbg.declare(metadata i32* %8, metadata !500, metadata !DIExpression()), !dbg !502
  store i32 0, i32* %8, align 4, !dbg !502
  br label %25, !dbg !503

25:                                               ; preds = %39, %24
  %26 = load i32, i32* %8, align 4, !dbg !504
  %27 = load i32, i32* %7, align 4, !dbg !506
  %28 = icmp slt i32 %26, %27, !dbg !507
  br i1 %28, label %29, label %42, !dbg !508

29:                                               ; preds = %25
  %30 = load i32, i32* %8, align 4, !dbg !509
  %31 = sext i32 %30 to i64, !dbg !511
  %32 = getelementptr inbounds [768 x i8], [768 x i8]* %5, i64 0, i64 %31, !dbg !511
  %33 = load i8, i8* %32, align 1, !dbg !511
  %34 = zext i8 %33 to i32, !dbg !512
  %35 = load i32, i32* @pb_hash, align 4, !dbg !513
  %36 = xor i32 %35, %34, !dbg !513
  store i32 %36, i32* @pb_hash, align 4, !dbg !513
  %37 = load i32, i32* @pb_hash, align 4, !dbg !514
  %38 = mul i32 %37, 16777619, !dbg !514
  store i32 %38, i32* @pb_hash, align 4, !dbg !514
  br label %39, !dbg !515

39:                                               ; preds = %29
  %40 = load i32, i32* %8, align 4, !dbg !516
  %41 = add nsw i32 %40, 1, !dbg !516
  store i32 %41, i32* %8, align 4, !dbg !516
  br label %25, !dbg !517, !llvm.loop !518

42:                                               ; preds = %25
  %43 = load %struct._IO_FILE*, %struct._IO_FILE** %3, align 8, !dbg !520
  %44 = load i32, i32* @pb_emit, align 4, !dbg !521
  %45 = load i32, i32* %7, align 4, !dbg !522
  ret i32 %45, !dbg !523
}

; Function Attrs: nofree nosync nounwind willreturn
declare void @llvm.va_start(i8*) #3

; Function Attrs: nounwind
declare i32 @vsnprintf(i8* noundef, i64 noundef, i8* noundef, %struct.__va_list_tag* noundef) #4

; Function Attrs: nofree nosync nounwind willreturn
declare void @llvm.va_end(i8*) #3

; Function Attrs: noreturn nounwind
declare void @abort() #5

attributes #0 = { noinline nounwind uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { nofree nosync nounwind readnone speculatable willreturn }
attributes #2 = { argmemonly nofree nounwind willreturn writeonly }
attributes #3 = { nofree nosync nounwind willreturn }
attributes #4 = { nounwind "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #5 = { noreturn nounwind "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #6 = { nounwind }
attributes #7 = { noreturn nounwind }

!llvm.dbg.cu = !{!2}
!llvm.module.flags = !{!52, !53, !54, !55, !56, !57, !58}
!llvm.ident = !{!59}

!0 = !DIGlobalVariableExpression(var: !1, expr: !DIExpression())
!1 = distinct !DIGlobalVariable(name: "nr", scope: !2, file: !11, line: 101, type: !12, isLocal: false, isDefinition: true)
!2 = distinct !DICompileUnit(language: DW_LANG_C99, file: !3, producer: "Ubuntu clang version 14.0.0-1ubuntu1.1", isOptimized: false, runtimeVersion: 0, emissionKind: FullDebug, retainedTypes: !4, globals: !8, splitDebugInlining: false, nameTableKind: None)
!3 = !DIFile(filename: "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/affine-bounds-20260929/suite/doitgen/source/workload.c", directory: "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/affine-bounds-20260929/suite/doitgen/analysis-p", checksumkind: CSK_MD5, checksum: "1cfaa4ce7cb91ebdd65caf7b87276fe2")
!4 = !{!5, !6, !7}
!5 = !DIBasicType(name: "double", size: 64, encoding: DW_ATE_float)
!6 = !DIBasicType(name: "unsigned int", size: 32, encoding: DW_ATE_unsigned)
!7 = !DIBasicType(name: "unsigned char", size: 8, encoding: DW_ATE_unsigned_char)
!8 = !{!0, !9, !13, !15, !28, !32, !35, !42, !46, !50}
!9 = !DIGlobalVariableExpression(var: !10, expr: !DIExpression())
!10 = distinct !DIGlobalVariable(name: "nq", scope: !2, file: !11, line: 102, type: !12, isLocal: false, isDefinition: true)
!11 = !DIFile(filename: "source/workload.c", directory: "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/affine-bounds-20260929/suite/doitgen", checksumkind: CSK_MD5, checksum: "1cfaa4ce7cb91ebdd65caf7b87276fe2")
!12 = !DIBasicType(name: "int", size: 32, encoding: DW_ATE_signed)
!13 = !DIGlobalVariableExpression(var: !14, expr: !DIExpression())
!14 = distinct !DIGlobalVariable(name: "np", scope: !2, file: !11, line: 103, type: !12, isLocal: false, isDefinition: true)
!15 = !DIGlobalVariableExpression(var: !16, expr: !DIExpression())
!16 = distinct !DIGlobalVariable(name: "workload_jobs", scope: !2, file: !11, line: 127, type: !17, isLocal: false, isDefinition: true)
!17 = !DICompositeType(tag: DW_TAG_array_type, baseType: !18, size: 64, elements: !26)
!18 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !19)
!19 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !20, size: 64)
!20 = !DISubroutineType(types: !21)
!21 = !{!22}
!22 = !DIDerivedType(tag: DW_TAG_typedef, name: "uint32_t", file: !23, line: 26, baseType: !24)
!23 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/stdint-uintn.h", directory: "", checksumkind: CSK_MD5, checksum: "2bf2ae53c58c01b1a1b9383b5195125c")
!24 = !DIDerivedType(tag: DW_TAG_typedef, name: "__uint32_t", file: !25, line: 42, baseType: !6)
!25 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/types.h", directory: "", checksumkind: CSK_MD5, checksum: "d108b5f93a74c50510d7d9bc0ab36df9")
!26 = !{!27}
!27 = !DISubrange(count: 1)
!28 = !DIGlobalVariableExpression(var: !29, expr: !DIExpression())
!29 = distinct !DIGlobalVariable(name: "workload_expected", scope: !2, file: !11, line: 131, type: !30, isLocal: false, isDefinition: true)
!30 = !DICompositeType(tag: DW_TAG_array_type, baseType: !31, size: 32, elements: !26)
!31 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !22)
!32 = !DIGlobalVariableExpression(var: !33, expr: !DIExpression())
!33 = distinct !DIGlobalVariable(name: "pb_hash", scope: !2, file: !34, line: 9, type: !22, isLocal: true, isDefinition: true)
!34 = !DIFile(filename: "source/adapter.h", directory: "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/affine-bounds-20260929/suite/doitgen", checksumkind: CSK_MD5, checksum: "26a6068928b2092758f244a9d00163d7")
!35 = !DIGlobalVariableExpression(var: !36, expr: !DIExpression())
!36 = distinct !DIGlobalVariable(name: "A", scope: !2, file: !11, line: 34, type: !37, isLocal: false, isDefinition: true, align: 512)
!37 = !DICompositeType(tag: DW_TAG_array_type, baseType: !5, size: 7680000, elements: !38)
!38 = !{!39, !40, !41}
!39 = !DISubrange(count: 50)
!40 = !DISubrange(count: 40)
!41 = !DISubrange(count: 60)
!42 = !DIGlobalVariableExpression(var: !43, expr: !DIExpression())
!43 = distinct !DIGlobalVariable(name: "sum", scope: !2, file: !11, line: 35, type: !44, isLocal: false, isDefinition: true, align: 512)
!44 = !DICompositeType(tag: DW_TAG_array_type, baseType: !5, size: 3840, elements: !45)
!45 = !{!41}
!46 = !DIGlobalVariableExpression(var: !47, expr: !DIExpression())
!47 = distinct !DIGlobalVariable(name: "C4", scope: !2, file: !11, line: 36, type: !48, isLocal: false, isDefinition: true, align: 512)
!48 = !DICompositeType(tag: DW_TAG_array_type, baseType: !5, size: 230400, elements: !49)
!49 = !{!41, !41}
!50 = !DIGlobalVariableExpression(var: !51, expr: !DIExpression())
!51 = distinct !DIGlobalVariable(name: "pb_emit", scope: !2, file: !34, line: 10, type: !12, isLocal: true, isDefinition: true)
!52 = !{i32 7, !"Dwarf Version", i32 5}
!53 = !{i32 2, !"Debug Info Version", i32 3}
!54 = !{i32 1, !"wchar_size", i32 4}
!55 = !{i32 7, !"PIC Level", i32 2}
!56 = !{i32 7, !"PIE Level", i32 2}
!57 = !{i32 7, !"uwtable", i32 1}
!58 = !{i32 7, !"frame-pointer", i32 2}
!59 = !{!"Ubuntu clang version 14.0.0-1ubuntu1.1"}
!60 = distinct !DISubprogram(name: "workload_prepare", scope: !11, file: !11, line: 104, type: !61, scopeLine: 104, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !2, retainedNodes: !63)
!61 = !DISubroutineType(types: !62)
!62 = !{null}
!63 = !{}
!64 = !DILocation(line: 104, column: 30, scope: !60)
!65 = distinct !DISubprogram(name: "workload_reset", scope: !11, file: !11, line: 105, type: !66, scopeLine: 105, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !2, retainedNodes: !63)
!66 = !DISubroutineType(types: !67)
!67 = !{null, !6}
!68 = !DILocalVariable(name: "task", arg: 1, scope: !65, file: !11, line: 105, type: !6)
!69 = !DILocation(line: 105, column: 30, scope: !65)
!70 = !DILocation(line: 106, column: 9, scope: !65)
!71 = !DILocation(line: 107, column: 3, scope: !65)
!72 = !DILocation(line: 108, column: 3, scope: !65)
!73 = !DILocation(line: 109, column: 3, scope: !65)
!74 = !DILocation(line: 110, column: 15, scope: !65)
!75 = !DILocation(line: 110, column: 19, scope: !65)
!76 = !DILocation(line: 110, column: 23, scope: !65)
!77 = !DILocation(line: 110, column: 3, scope: !65)
!78 = !DILocation(line: 113, column: 1, scope: !65)
!79 = distinct !DISubprogram(name: "init_array", scope: !11, file: !11, line: 38, type: !80, scopeLine: 41, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition, unit: !2, retainedNodes: !63)
!80 = !DISubroutineType(types: !81)
!81 = !{null, !12, !12, !12, !82, !85}
!82 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !83, size: 64)
!83 = !DICompositeType(tag: DW_TAG_array_type, baseType: !5, size: 153600, elements: !84)
!84 = !{!40, !41}
!85 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !44, size: 64)
!86 = !DILocalVariable(name: "nr", arg: 1, scope: !79, file: !11, line: 38, type: !12)
!87 = !DILocation(line: 38, column: 21, scope: !79)
!88 = !DILocalVariable(name: "nq", arg: 2, scope: !79, file: !11, line: 38, type: !12)
!89 = !DILocation(line: 38, column: 29, scope: !79)
!90 = !DILocalVariable(name: "np", arg: 3, scope: !79, file: !11, line: 38, type: !12)
!91 = !DILocation(line: 38, column: 37, scope: !79)
!92 = !DILocalVariable(name: "A", arg: 4, scope: !79, file: !11, line: 39, type: !82)
!93 = !DILocation(line: 39, column: 13, scope: !79)
!94 = !DILocalVariable(name: "C4", arg: 5, scope: !79, file: !11, line: 40, type: !85)
!95 = !DILocation(line: 40, column: 13, scope: !79)
!96 = !DILocalVariable(name: "i", scope: !79, file: !11, line: 42, type: !12)
!97 = !DILocation(line: 42, column: 7, scope: !79)
!98 = !DILocalVariable(name: "j", scope: !79, file: !11, line: 42, type: !12)
!99 = !DILocation(line: 42, column: 10, scope: !79)
!100 = !DILocalVariable(name: "k", scope: !79, file: !11, line: 42, type: !12)
!101 = !DILocation(line: 42, column: 13, scope: !79)
!102 = !DILocation(line: 44, column: 10, scope: !103)
!103 = distinct !DILexicalBlock(scope: !79, file: !11, line: 44, column: 3)
!104 = !DILocation(line: 44, column: 8, scope: !103)
!105 = !DILocation(line: 44, column: 15, scope: !106)
!106 = distinct !DILexicalBlock(scope: !103, file: !11, line: 44, column: 3)
!107 = !DILocation(line: 44, column: 19, scope: !106)
!108 = !DILocation(line: 44, column: 17, scope: !106)
!109 = !DILocation(line: 44, column: 3, scope: !103)
!110 = !DILocation(line: 45, column: 12, scope: !111)
!111 = distinct !DILexicalBlock(scope: !106, file: !11, line: 45, column: 5)
!112 = !DILocation(line: 45, column: 10, scope: !111)
!113 = !DILocation(line: 45, column: 17, scope: !114)
!114 = distinct !DILexicalBlock(scope: !111, file: !11, line: 45, column: 5)
!115 = !DILocation(line: 45, column: 21, scope: !114)
!116 = !DILocation(line: 45, column: 19, scope: !114)
!117 = !DILocation(line: 45, column: 5, scope: !111)
!118 = !DILocation(line: 46, column: 14, scope: !119)
!119 = distinct !DILexicalBlock(scope: !114, file: !11, line: 46, column: 7)
!120 = !DILocation(line: 46, column: 12, scope: !119)
!121 = !DILocation(line: 46, column: 19, scope: !122)
!122 = distinct !DILexicalBlock(scope: !119, file: !11, line: 46, column: 7)
!123 = !DILocation(line: 46, column: 23, scope: !122)
!124 = !DILocation(line: 46, column: 21, scope: !122)
!125 = !DILocation(line: 46, column: 7, scope: !119)
!126 = !DILocation(line: 47, column: 29, scope: !122)
!127 = !DILocation(line: 47, column: 31, scope: !122)
!128 = !DILocation(line: 47, column: 30, scope: !122)
!129 = !DILocation(line: 47, column: 35, scope: !122)
!130 = !DILocation(line: 47, column: 33, scope: !122)
!131 = !DILocation(line: 47, column: 38, scope: !122)
!132 = !DILocation(line: 47, column: 37, scope: !122)
!133 = !DILocation(line: 47, column: 15, scope: !122)
!134 = !DILocation(line: 47, column: 44, scope: !122)
!135 = !DILocation(line: 47, column: 42, scope: !122)
!136 = !DILocation(line: 47, column: 2, scope: !122)
!137 = !DILocation(line: 47, column: 4, scope: !122)
!138 = !DILocation(line: 47, column: 7, scope: !122)
!139 = !DILocation(line: 47, column: 10, scope: !122)
!140 = !DILocation(line: 47, column: 13, scope: !122)
!141 = !DILocation(line: 46, column: 28, scope: !122)
!142 = !DILocation(line: 46, column: 7, scope: !122)
!143 = distinct !{!143, !125, !144, !145}
!144 = !DILocation(line: 47, column: 44, scope: !119)
!145 = !{!"llvm.loop.mustprogress"}
!146 = !DILocation(line: 45, column: 26, scope: !114)
!147 = !DILocation(line: 45, column: 5, scope: !114)
!148 = distinct !{!148, !117, !149, !145}
!149 = !DILocation(line: 47, column: 44, scope: !111)
!150 = !DILocation(line: 44, column: 24, scope: !106)
!151 = !DILocation(line: 44, column: 3, scope: !106)
!152 = distinct !{!152, !109, !153, !145}
!153 = !DILocation(line: 47, column: 44, scope: !103)
!154 = !DILocation(line: 48, column: 10, scope: !155)
!155 = distinct !DILexicalBlock(scope: !79, file: !11, line: 48, column: 3)
!156 = !DILocation(line: 48, column: 8, scope: !155)
!157 = !DILocation(line: 48, column: 15, scope: !158)
!158 = distinct !DILexicalBlock(scope: !155, file: !11, line: 48, column: 3)
!159 = !DILocation(line: 48, column: 19, scope: !158)
!160 = !DILocation(line: 48, column: 17, scope: !158)
!161 = !DILocation(line: 48, column: 3, scope: !155)
!162 = !DILocation(line: 49, column: 12, scope: !163)
!163 = distinct !DILexicalBlock(scope: !158, file: !11, line: 49, column: 5)
!164 = !DILocation(line: 49, column: 10, scope: !163)
!165 = !DILocation(line: 49, column: 17, scope: !166)
!166 = distinct !DILexicalBlock(scope: !163, file: !11, line: 49, column: 5)
!167 = !DILocation(line: 49, column: 21, scope: !166)
!168 = !DILocation(line: 49, column: 19, scope: !166)
!169 = !DILocation(line: 49, column: 5, scope: !163)
!170 = !DILocation(line: 50, column: 31, scope: !166)
!171 = !DILocation(line: 50, column: 33, scope: !166)
!172 = !DILocation(line: 50, column: 32, scope: !166)
!173 = !DILocation(line: 50, column: 37, scope: !166)
!174 = !DILocation(line: 50, column: 35, scope: !166)
!175 = !DILocation(line: 50, column: 18, scope: !166)
!176 = !DILocation(line: 50, column: 43, scope: !166)
!177 = !DILocation(line: 50, column: 41, scope: !166)
!178 = !DILocation(line: 50, column: 7, scope: !166)
!179 = !DILocation(line: 50, column: 10, scope: !166)
!180 = !DILocation(line: 50, column: 13, scope: !166)
!181 = !DILocation(line: 50, column: 16, scope: !166)
!182 = !DILocation(line: 49, column: 26, scope: !166)
!183 = !DILocation(line: 49, column: 5, scope: !166)
!184 = distinct !{!184, !169, !185, !145}
!185 = !DILocation(line: 50, column: 43, scope: !163)
!186 = !DILocation(line: 48, column: 24, scope: !158)
!187 = !DILocation(line: 48, column: 3, scope: !158)
!188 = distinct !{!188, !161, !189, !145}
!189 = !DILocation(line: 50, column: 43, scope: !155)
!190 = !DILocation(line: 51, column: 1, scope: !79)
!191 = distinct !DISubprogram(name: "task_job_polybench", scope: !11, file: !11, line: 114, type: !20, scopeLine: 114, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !2, retainedNodes: !63)
!192 = !DILocation(line: 115, column: 19, scope: !191)
!193 = !DILocation(line: 115, column: 23, scope: !191)
!194 = !DILocation(line: 115, column: 27, scope: !191)
!195 = !DILocalVariable(name: "nr", arg: 1, scope: !196, file: !11, line: 77, type: !12)
!196 = distinct !DISubprogram(name: "kernel_doitgen", scope: !11, file: !11, line: 77, type: !197, scopeLine: 81, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !2, retainedNodes: !63)
!197 = !DISubroutineType(types: !198)
!198 = !{null, !12, !12, !12, !82, !85, !199}
!199 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !5, size: 64)
!200 = !DILocation(line: 77, column: 63, scope: !196, inlinedAt: !201)
!201 = distinct !DILocation(line: 115, column: 3, scope: !191)
!202 = !DILocalVariable(name: "nq", arg: 2, scope: !196, file: !11, line: 77, type: !12)
!203 = !DILocation(line: 77, column: 71, scope: !196, inlinedAt: !201)
!204 = !DILocalVariable(name: "np", arg: 3, scope: !196, file: !11, line: 77, type: !12)
!205 = !DILocation(line: 77, column: 79, scope: !196, inlinedAt: !201)
!206 = !DILocalVariable(name: "A", arg: 4, scope: !196, file: !11, line: 78, type: !82)
!207 = !DILocation(line: 78, column: 17, scope: !196, inlinedAt: !201)
!208 = !DILocalVariable(name: "C4", arg: 5, scope: !196, file: !11, line: 79, type: !85)
!209 = !DILocation(line: 79, column: 17, scope: !196, inlinedAt: !201)
!210 = !DILocalVariable(name: "sum", arg: 6, scope: !196, file: !11, line: 80, type: !199)
!211 = !DILocation(line: 80, column: 17, scope: !196, inlinedAt: !201)
!212 = !DILocalVariable(name: "r", scope: !196, file: !11, line: 82, type: !12)
!213 = !DILocation(line: 82, column: 7, scope: !196, inlinedAt: !201)
!214 = !DILocalVariable(name: "q", scope: !196, file: !11, line: 82, type: !12)
!215 = !DILocation(line: 82, column: 10, scope: !196, inlinedAt: !201)
!216 = !DILocalVariable(name: "p", scope: !196, file: !11, line: 82, type: !12)
!217 = !DILocation(line: 82, column: 13, scope: !196, inlinedAt: !201)
!218 = !DILocalVariable(name: "s", scope: !196, file: !11, line: 82, type: !12)
!219 = !DILocation(line: 82, column: 16, scope: !196, inlinedAt: !201)
!220 = !DILocation(line: 85, column: 10, scope: !221, inlinedAt: !201)
!221 = distinct !DILexicalBlock(scope: !196, file: !11, line: 85, column: 3)
!222 = !DILocation(line: 85, column: 8, scope: !221, inlinedAt: !201)
!223 = !DILocation(line: 85, column: 15, scope: !224, inlinedAt: !201)
!224 = distinct !DILexicalBlock(scope: !221, file: !11, line: 85, column: 3)
!225 = !DILocation(line: 85, column: 17, scope: !224, inlinedAt: !201)
!226 = !DILocation(line: 85, column: 3, scope: !221, inlinedAt: !201)
!227 = !DILocation(line: 86, column: 12, scope: !228, inlinedAt: !201)
!228 = distinct !DILexicalBlock(scope: !224, file: !11, line: 86, column: 5)
!229 = !DILocation(line: 86, column: 10, scope: !228, inlinedAt: !201)
!230 = !DILocation(line: 86, column: 17, scope: !231, inlinedAt: !201)
!231 = distinct !DILexicalBlock(scope: !228, file: !11, line: 86, column: 5)
!232 = !DILocation(line: 86, column: 19, scope: !231, inlinedAt: !201)
!233 = !DILocation(line: 86, column: 5, scope: !228, inlinedAt: !201)
!234 = !DILocation(line: 87, column: 14, scope: !235, inlinedAt: !201)
!235 = distinct !DILexicalBlock(scope: !236, file: !11, line: 87, column: 7)
!236 = distinct !DILexicalBlock(scope: !231, file: !11, line: 86, column: 35)
!237 = !DILocation(line: 87, column: 12, scope: !235, inlinedAt: !201)
!238 = !DILocation(line: 87, column: 19, scope: !239, inlinedAt: !201)
!239 = distinct !DILexicalBlock(scope: !235, file: !11, line: 87, column: 7)
!240 = !DILocation(line: 87, column: 21, scope: !239, inlinedAt: !201)
!241 = !DILocation(line: 87, column: 7, scope: !235, inlinedAt: !201)
!242 = !DILocation(line: 88, column: 2, scope: !243, inlinedAt: !201)
!243 = distinct !DILexicalBlock(scope: !239, file: !11, line: 87, column: 37)
!244 = !DILocation(line: 88, column: 6, scope: !243, inlinedAt: !201)
!245 = !DILocation(line: 88, column: 9, scope: !243, inlinedAt: !201)
!246 = !DILocation(line: 89, column: 9, scope: !247, inlinedAt: !201)
!247 = distinct !DILexicalBlock(scope: !243, file: !11, line: 89, column: 2)
!248 = !DILocation(line: 89, column: 7, scope: !247, inlinedAt: !201)
!249 = !DILocation(line: 89, column: 14, scope: !250, inlinedAt: !201)
!250 = distinct !DILexicalBlock(scope: !247, file: !11, line: 89, column: 2)
!251 = !DILocation(line: 89, column: 16, scope: !250, inlinedAt: !201)
!252 = !DILocation(line: 89, column: 2, scope: !247, inlinedAt: !201)
!253 = !DILocation(line: 90, column: 14, scope: !250, inlinedAt: !201)
!254 = !DILocation(line: 90, column: 16, scope: !250, inlinedAt: !201)
!255 = !DILocation(line: 90, column: 19, scope: !250, inlinedAt: !201)
!256 = !DILocation(line: 90, column: 22, scope: !250, inlinedAt: !201)
!257 = !DILocation(line: 90, column: 27, scope: !250, inlinedAt: !201)
!258 = !DILocation(line: 90, column: 30, scope: !250, inlinedAt: !201)
!259 = !DILocation(line: 90, column: 33, scope: !250, inlinedAt: !201)
!260 = !DILocation(line: 90, column: 25, scope: !250, inlinedAt: !201)
!261 = !DILocation(line: 90, column: 4, scope: !250, inlinedAt: !201)
!262 = !DILocation(line: 90, column: 8, scope: !250, inlinedAt: !201)
!263 = !DILocation(line: 90, column: 11, scope: !250, inlinedAt: !201)
!264 = !DILocation(line: 89, column: 27, scope: !250, inlinedAt: !201)
!265 = !DILocation(line: 89, column: 2, scope: !250, inlinedAt: !201)
!266 = distinct !{!266, !252, !267, !145}
!267 = !DILocation(line: 90, column: 34, scope: !247, inlinedAt: !201)
!268 = !DILocation(line: 87, column: 32, scope: !239, inlinedAt: !201)
!269 = !DILocation(line: 87, column: 7, scope: !239, inlinedAt: !201)
!270 = distinct !{!270, !241, !271, !145}
!271 = !DILocation(line: 91, column: 7, scope: !235, inlinedAt: !201)
!272 = !DILocation(line: 92, column: 14, scope: !273, inlinedAt: !201)
!273 = distinct !DILexicalBlock(scope: !236, file: !11, line: 92, column: 7)
!274 = !DILocation(line: 92, column: 12, scope: !273, inlinedAt: !201)
!275 = !DILocation(line: 92, column: 19, scope: !276, inlinedAt: !201)
!276 = distinct !DILexicalBlock(scope: !273, file: !11, line: 92, column: 7)
!277 = !DILocation(line: 92, column: 21, scope: !276, inlinedAt: !201)
!278 = !DILocation(line: 92, column: 7, scope: !273, inlinedAt: !201)
!279 = !DILocation(line: 93, column: 15, scope: !276, inlinedAt: !201)
!280 = !DILocation(line: 93, column: 19, scope: !276, inlinedAt: !201)
!281 = !DILocation(line: 93, column: 2, scope: !276, inlinedAt: !201)
!282 = !DILocation(line: 93, column: 4, scope: !276, inlinedAt: !201)
!283 = !DILocation(line: 93, column: 7, scope: !276, inlinedAt: !201)
!284 = !DILocation(line: 93, column: 10, scope: !276, inlinedAt: !201)
!285 = !DILocation(line: 93, column: 13, scope: !276, inlinedAt: !201)
!286 = !DILocation(line: 92, column: 32, scope: !276, inlinedAt: !201)
!287 = !DILocation(line: 92, column: 7, scope: !276, inlinedAt: !201)
!288 = distinct !{!288, !278, !289, !145}
!289 = !DILocation(line: 93, column: 20, scope: !273, inlinedAt: !201)
!290 = !DILocation(line: 86, column: 30, scope: !231, inlinedAt: !201)
!291 = !DILocation(line: 86, column: 5, scope: !231, inlinedAt: !201)
!292 = distinct !{!292, !233, !293, !145}
!293 = !DILocation(line: 94, column: 5, scope: !228, inlinedAt: !201)
!294 = !DILocation(line: 85, column: 28, scope: !224, inlinedAt: !201)
!295 = !DILocation(line: 85, column: 3, scope: !224, inlinedAt: !201)
!296 = distinct !{!296, !226, !297, !145}
!297 = !DILocation(line: 94, column: 5, scope: !221, inlinedAt: !201)
!298 = !DILocation(line: 119, column: 3, scope: !191)
!299 = distinct !DISubprogram(name: "workload_checksum", scope: !11, file: !11, line: 121, type: !300, scopeLine: 121, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !2, retainedNodes: !63)
!300 = !DISubroutineType(types: !301)
!301 = !{!22, !6}
!302 = !DILocalVariable(name: "task", arg: 1, scope: !299, file: !11, line: 121, type: !6)
!303 = !DILocation(line: 121, column: 37, scope: !299)
!304 = !DILocation(line: 122, column: 9, scope: !299)
!305 = !DILocation(line: 123, column: 11, scope: !299)
!306 = !DILocation(line: 124, column: 15, scope: !299)
!307 = !DILocation(line: 124, column: 19, scope: !299)
!308 = !DILocation(line: 124, column: 23, scope: !299)
!309 = !DILocation(line: 124, column: 3, scope: !299)
!310 = !DILocation(line: 125, column: 10, scope: !299)
!311 = !DILocation(line: 125, column: 3, scope: !299)
!312 = distinct !DISubprogram(name: "print_array", scope: !11, file: !11, line: 57, type: !313, scopeLine: 59, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition, unit: !2, retainedNodes: !63)
!313 = !DISubroutineType(types: !314)
!314 = !{null, !12, !12, !12, !82}
!315 = !DILocalVariable(name: "nr", arg: 1, scope: !312, file: !11, line: 57, type: !12)
!316 = !DILocation(line: 57, column: 22, scope: !312)
!317 = !DILocalVariable(name: "nq", arg: 2, scope: !312, file: !11, line: 57, type: !12)
!318 = !DILocation(line: 57, column: 30, scope: !312)
!319 = !DILocalVariable(name: "np", arg: 3, scope: !312, file: !11, line: 57, type: !12)
!320 = !DILocation(line: 57, column: 38, scope: !312)
!321 = !DILocalVariable(name: "A", arg: 4, scope: !312, file: !11, line: 58, type: !82)
!322 = !DILocation(line: 58, column: 14, scope: !312)
!323 = !DILocalVariable(name: "i", scope: !312, file: !11, line: 60, type: !12)
!324 = !DILocation(line: 60, column: 7, scope: !312)
!325 = !DILocalVariable(name: "j", scope: !312, file: !11, line: 60, type: !12)
!326 = !DILocation(line: 60, column: 10, scope: !312)
!327 = !DILocalVariable(name: "k", scope: !312, file: !11, line: 60, type: !12)
!328 = !DILocation(line: 60, column: 13, scope: !312)
!329 = !DILocation(line: 62, column: 3, scope: !312)
!330 = !DILocation(line: 63, column: 3, scope: !312)
!331 = !DILocation(line: 64, column: 10, scope: !332)
!332 = distinct !DILexicalBlock(scope: !312, file: !11, line: 64, column: 3)
!333 = !DILocation(line: 64, column: 8, scope: !332)
!334 = !DILocation(line: 64, column: 15, scope: !335)
!335 = distinct !DILexicalBlock(scope: !332, file: !11, line: 64, column: 3)
!336 = !DILocation(line: 64, column: 19, scope: !335)
!337 = !DILocation(line: 64, column: 17, scope: !335)
!338 = !DILocation(line: 64, column: 3, scope: !332)
!339 = !DILocation(line: 65, column: 12, scope: !340)
!340 = distinct !DILexicalBlock(scope: !335, file: !11, line: 65, column: 5)
!341 = !DILocation(line: 65, column: 10, scope: !340)
!342 = !DILocation(line: 65, column: 17, scope: !343)
!343 = distinct !DILexicalBlock(scope: !340, file: !11, line: 65, column: 5)
!344 = !DILocation(line: 65, column: 21, scope: !343)
!345 = !DILocation(line: 65, column: 19, scope: !343)
!346 = !DILocation(line: 65, column: 5, scope: !340)
!347 = !DILocation(line: 66, column: 14, scope: !348)
!348 = distinct !DILexicalBlock(scope: !343, file: !11, line: 66, column: 7)
!349 = !DILocation(line: 66, column: 12, scope: !348)
!350 = !DILocation(line: 66, column: 19, scope: !351)
!351 = distinct !DILexicalBlock(scope: !348, file: !11, line: 66, column: 7)
!352 = !DILocation(line: 66, column: 23, scope: !351)
!353 = !DILocation(line: 66, column: 21, scope: !351)
!354 = !DILocation(line: 66, column: 7, scope: !348)
!355 = !DILocation(line: 67, column: 7, scope: !356)
!356 = distinct !DILexicalBlock(scope: !357, file: !11, line: 67, column: 6)
!357 = distinct !DILexicalBlock(scope: !351, file: !11, line: 66, column: 32)
!358 = !DILocation(line: 67, column: 9, scope: !356)
!359 = !DILocation(line: 67, column: 8, scope: !356)
!360 = !DILocation(line: 67, column: 12, scope: !356)
!361 = !DILocation(line: 67, column: 11, scope: !356)
!362 = !DILocation(line: 67, column: 15, scope: !356)
!363 = !DILocation(line: 67, column: 17, scope: !356)
!364 = !DILocation(line: 67, column: 16, scope: !356)
!365 = !DILocation(line: 67, column: 14, scope: !356)
!366 = !DILocation(line: 67, column: 20, scope: !356)
!367 = !DILocation(line: 67, column: 19, scope: !356)
!368 = !DILocation(line: 67, column: 23, scope: !356)
!369 = !DILocation(line: 67, column: 28, scope: !356)
!370 = !DILocation(line: 67, column: 6, scope: !357)
!371 = !DILocation(line: 67, column: 43, scope: !356)
!372 = !DILocation(line: 67, column: 34, scope: !356)
!373 = !DILocation(line: 68, column: 11, scope: !357)
!374 = !DILocation(line: 68, column: 56, scope: !357)
!375 = !DILocation(line: 68, column: 58, scope: !357)
!376 = !DILocation(line: 68, column: 61, scope: !357)
!377 = !DILocation(line: 68, column: 64, scope: !357)
!378 = !DILocation(line: 68, column: 2, scope: !357)
!379 = !DILocation(line: 69, column: 7, scope: !357)
!380 = !DILocation(line: 66, column: 28, scope: !351)
!381 = !DILocation(line: 66, column: 7, scope: !351)
!382 = distinct !{!382, !354, !383, !145}
!383 = !DILocation(line: 69, column: 7, scope: !348)
!384 = !DILocation(line: 65, column: 26, scope: !343)
!385 = !DILocation(line: 65, column: 5, scope: !343)
!386 = distinct !{!386, !346, !387, !145}
!387 = !DILocation(line: 69, column: 7, scope: !340)
!388 = !DILocation(line: 64, column: 24, scope: !335)
!389 = !DILocation(line: 64, column: 3, scope: !335)
!390 = distinct !{!390, !338, !391, !145}
!391 = !DILocation(line: 69, column: 7, scope: !332)
!392 = !DILocation(line: 70, column: 3, scope: !312)
!393 = !DILocation(line: 71, column: 3, scope: !312)
!394 = !DILocation(line: 72, column: 1, scope: !312)
!395 = distinct !DISubprogram(name: "pb_fprintf", scope: !34, file: !34, line: 13, type: !396, scopeLine: 14, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition, unit: !2, retainedNodes: !63)
!396 = !DISubroutineType(types: !397)
!397 = !{!12, !398, !457, null}
!398 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !399, size: 64)
!399 = !DIDerivedType(tag: DW_TAG_typedef, name: "FILE", file: !400, line: 7, baseType: !401)
!400 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/types/FILE.h", directory: "", checksumkind: CSK_MD5, checksum: "571f9fb6223c42439075fdde11a0de5d")
!401 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "_IO_FILE", file: !402, line: 49, size: 1728, elements: !403)
!402 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/types/struct_FILE.h", directory: "", checksumkind: CSK_MD5, checksum: "1bad07471b7974df4ecc1d1c2ca207e6")
!403 = !{!404, !405, !408, !409, !410, !411, !412, !413, !414, !415, !416, !417, !418, !421, !423, !424, !425, !428, !430, !432, !434, !437, !439, !442, !445, !446, !448, !452, !453}
!404 = !DIDerivedType(tag: DW_TAG_member, name: "_flags", scope: !401, file: !402, line: 51, baseType: !12, size: 32)
!405 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_read_ptr", scope: !401, file: !402, line: 54, baseType: !406, size: 64, offset: 64)
!406 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !407, size: 64)
!407 = !DIBasicType(name: "char", size: 8, encoding: DW_ATE_signed_char)
!408 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_read_end", scope: !401, file: !402, line: 55, baseType: !406, size: 64, offset: 128)
!409 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_read_base", scope: !401, file: !402, line: 56, baseType: !406, size: 64, offset: 192)
!410 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_write_base", scope: !401, file: !402, line: 57, baseType: !406, size: 64, offset: 256)
!411 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_write_ptr", scope: !401, file: !402, line: 58, baseType: !406, size: 64, offset: 320)
!412 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_write_end", scope: !401, file: !402, line: 59, baseType: !406, size: 64, offset: 384)
!413 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_buf_base", scope: !401, file: !402, line: 60, baseType: !406, size: 64, offset: 448)
!414 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_buf_end", scope: !401, file: !402, line: 61, baseType: !406, size: 64, offset: 512)
!415 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_save_base", scope: !401, file: !402, line: 64, baseType: !406, size: 64, offset: 576)
!416 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_backup_base", scope: !401, file: !402, line: 65, baseType: !406, size: 64, offset: 640)
!417 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_save_end", scope: !401, file: !402, line: 66, baseType: !406, size: 64, offset: 704)
!418 = !DIDerivedType(tag: DW_TAG_member, name: "_markers", scope: !401, file: !402, line: 68, baseType: !419, size: 64, offset: 768)
!419 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !420, size: 64)
!420 = !DICompositeType(tag: DW_TAG_structure_type, name: "_IO_marker", file: !402, line: 36, flags: DIFlagFwdDecl)
!421 = !DIDerivedType(tag: DW_TAG_member, name: "_chain", scope: !401, file: !402, line: 70, baseType: !422, size: 64, offset: 832)
!422 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !401, size: 64)
!423 = !DIDerivedType(tag: DW_TAG_member, name: "_fileno", scope: !401, file: !402, line: 72, baseType: !12, size: 32, offset: 896)
!424 = !DIDerivedType(tag: DW_TAG_member, name: "_flags2", scope: !401, file: !402, line: 73, baseType: !12, size: 32, offset: 928)
!425 = !DIDerivedType(tag: DW_TAG_member, name: "_old_offset", scope: !401, file: !402, line: 74, baseType: !426, size: 64, offset: 960)
!426 = !DIDerivedType(tag: DW_TAG_typedef, name: "__off_t", file: !25, line: 152, baseType: !427)
!427 = !DIBasicType(name: "long", size: 64, encoding: DW_ATE_signed)
!428 = !DIDerivedType(tag: DW_TAG_member, name: "_cur_column", scope: !401, file: !402, line: 77, baseType: !429, size: 16, offset: 1024)
!429 = !DIBasicType(name: "unsigned short", size: 16, encoding: DW_ATE_unsigned)
!430 = !DIDerivedType(tag: DW_TAG_member, name: "_vtable_offset", scope: !401, file: !402, line: 78, baseType: !431, size: 8, offset: 1040)
!431 = !DIBasicType(name: "signed char", size: 8, encoding: DW_ATE_signed_char)
!432 = !DIDerivedType(tag: DW_TAG_member, name: "_shortbuf", scope: !401, file: !402, line: 79, baseType: !433, size: 8, offset: 1048)
!433 = !DICompositeType(tag: DW_TAG_array_type, baseType: !407, size: 8, elements: !26)
!434 = !DIDerivedType(tag: DW_TAG_member, name: "_lock", scope: !401, file: !402, line: 81, baseType: !435, size: 64, offset: 1088)
!435 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !436, size: 64)
!436 = !DIDerivedType(tag: DW_TAG_typedef, name: "_IO_lock_t", file: !402, line: 43, baseType: null)
!437 = !DIDerivedType(tag: DW_TAG_member, name: "_offset", scope: !401, file: !402, line: 89, baseType: !438, size: 64, offset: 1152)
!438 = !DIDerivedType(tag: DW_TAG_typedef, name: "__off64_t", file: !25, line: 153, baseType: !427)
!439 = !DIDerivedType(tag: DW_TAG_member, name: "_codecvt", scope: !401, file: !402, line: 91, baseType: !440, size: 64, offset: 1216)
!440 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !441, size: 64)
!441 = !DICompositeType(tag: DW_TAG_structure_type, name: "_IO_codecvt", file: !402, line: 37, flags: DIFlagFwdDecl)
!442 = !DIDerivedType(tag: DW_TAG_member, name: "_wide_data", scope: !401, file: !402, line: 92, baseType: !443, size: 64, offset: 1280)
!443 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !444, size: 64)
!444 = !DICompositeType(tag: DW_TAG_structure_type, name: "_IO_wide_data", file: !402, line: 38, flags: DIFlagFwdDecl)
!445 = !DIDerivedType(tag: DW_TAG_member, name: "_freeres_list", scope: !401, file: !402, line: 93, baseType: !422, size: 64, offset: 1344)
!446 = !DIDerivedType(tag: DW_TAG_member, name: "_freeres_buf", scope: !401, file: !402, line: 94, baseType: !447, size: 64, offset: 1408)
!447 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: null, size: 64)
!448 = !DIDerivedType(tag: DW_TAG_member, name: "__pad5", scope: !401, file: !402, line: 95, baseType: !449, size: 64, offset: 1472)
!449 = !DIDerivedType(tag: DW_TAG_typedef, name: "size_t", file: !450, line: 46, baseType: !451)
!450 = !DIFile(filename: "/usr/lib/llvm-14/lib/clang/14.0.0/include/stddef.h", directory: "", checksumkind: CSK_MD5, checksum: "2499dd2361b915724b073282bea3a7bc")
!451 = !DIBasicType(name: "unsigned long", size: 64, encoding: DW_ATE_unsigned)
!452 = !DIDerivedType(tag: DW_TAG_member, name: "_mode", scope: !401, file: !402, line: 96, baseType: !12, size: 32, offset: 1536)
!453 = !DIDerivedType(tag: DW_TAG_member, name: "_unused2", scope: !401, file: !402, line: 98, baseType: !454, size: 160, offset: 1568)
!454 = !DICompositeType(tag: DW_TAG_array_type, baseType: !407, size: 160, elements: !455)
!455 = !{!456}
!456 = !DISubrange(count: 20)
!457 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !458, size: 64)
!458 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !407)
!459 = !DILocalVariable(name: "stream", arg: 1, scope: !395, file: !34, line: 13, type: !398)
!460 = !DILocation(line: 13, column: 29, scope: !395)
!461 = !DILocalVariable(name: "format", arg: 2, scope: !395, file: !34, line: 13, type: !457)
!462 = !DILocation(line: 13, column: 49, scope: !395)
!463 = !DILocalVariable(name: "buffer", scope: !395, file: !34, line: 15, type: !464)
!464 = !DICompositeType(tag: DW_TAG_array_type, baseType: !407, size: 6144, elements: !465)
!465 = !{!466}
!466 = !DISubrange(count: 768)
!467 = !DILocation(line: 15, column: 10, scope: !395)
!468 = !DILocalVariable(name: "args", scope: !395, file: !34, line: 16, type: !469)
!469 = !DIDerivedType(tag: DW_TAG_typedef, name: "va_list", file: !470, line: 52, baseType: !471)
!470 = !DIFile(filename: "/usr/include/stdio.h", directory: "", checksumkind: CSK_MD5, checksum: "f31eefcc3f15835fc5a4023a625cf609")
!471 = !DIDerivedType(tag: DW_TAG_typedef, name: "__gnuc_va_list", file: !472, line: 32, baseType: !473)
!472 = !DIFile(filename: "/usr/lib/llvm-14/lib/clang/14.0.0/include/stdarg.h", directory: "", checksumkind: CSK_MD5, checksum: "4de3cbd931b589d291e5c39387aecf82")
!473 = !DIDerivedType(tag: DW_TAG_typedef, name: "__builtin_va_list", file: !474, baseType: !475)
!474 = !DIFile(filename: "source/workload.c", directory: "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/affine-bounds-20260929/suite/doitgen")
!475 = !DICompositeType(tag: DW_TAG_array_type, baseType: !476, size: 192, elements: !26)
!476 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "__va_list_tag", size: 192, elements: !477)
!477 = !{!478, !479, !480, !481}
!478 = !DIDerivedType(tag: DW_TAG_member, name: "gp_offset", scope: !476, file: !474, line: 16, baseType: !6, size: 32)
!479 = !DIDerivedType(tag: DW_TAG_member, name: "fp_offset", scope: !476, file: !474, line: 16, baseType: !6, size: 32, offset: 32)
!480 = !DIDerivedType(tag: DW_TAG_member, name: "overflow_arg_area", scope: !476, file: !474, line: 16, baseType: !447, size: 64, offset: 64)
!481 = !DIDerivedType(tag: DW_TAG_member, name: "reg_save_area", scope: !476, file: !474, line: 16, baseType: !447, size: 64, offset: 128)
!482 = !DILocation(line: 16, column: 13, scope: !395)
!483 = !DILocation(line: 17, column: 5, scope: !395)
!484 = !DILocalVariable(name: "count", scope: !395, file: !34, line: 18, type: !12)
!485 = !DILocation(line: 18, column: 9, scope: !395)
!486 = !DILocation(line: 18, column: 27, scope: !395)
!487 = !DILocation(line: 18, column: 51, scope: !395)
!488 = !DILocation(line: 18, column: 59, scope: !395)
!489 = !DILocation(line: 18, column: 17, scope: !395)
!490 = !DILocation(line: 19, column: 5, scope: !395)
!491 = !DILocation(line: 20, column: 9, scope: !492)
!492 = distinct !DILexicalBlock(scope: !395, file: !34, line: 20, column: 9)
!493 = !DILocation(line: 20, column: 15, scope: !492)
!494 = !DILocation(line: 20, column: 19, scope: !492)
!495 = !DILocation(line: 20, column: 32, scope: !492)
!496 = !DILocation(line: 20, column: 22, scope: !492)
!497 = !DILocation(line: 20, column: 38, scope: !492)
!498 = !DILocation(line: 20, column: 9, scope: !395)
!499 = !DILocation(line: 20, column: 57, scope: !492)
!500 = !DILocalVariable(name: "i", scope: !501, file: !34, line: 21, type: !12)
!501 = distinct !DILexicalBlock(scope: !395, file: !34, line: 21, column: 5)
!502 = !DILocation(line: 21, column: 14, scope: !501)
!503 = !DILocation(line: 21, column: 10, scope: !501)
!504 = !DILocation(line: 21, column: 21, scope: !505)
!505 = distinct !DILexicalBlock(scope: !501, file: !34, line: 21, column: 5)
!506 = !DILocation(line: 21, column: 25, scope: !505)
!507 = !DILocation(line: 21, column: 23, scope: !505)
!508 = !DILocation(line: 21, column: 5, scope: !501)
!509 = !DILocation(line: 22, column: 42, scope: !510)
!510 = distinct !DILexicalBlock(scope: !505, file: !34, line: 21, column: 37)
!511 = !DILocation(line: 22, column: 35, scope: !510)
!512 = !DILocation(line: 22, column: 20, scope: !510)
!513 = !DILocation(line: 22, column: 17, scope: !510)
!514 = !DILocation(line: 23, column: 17, scope: !510)
!515 = !DILocation(line: 24, column: 5, scope: !510)
!516 = !DILocation(line: 21, column: 32, scope: !505)
!517 = !DILocation(line: 21, column: 5, scope: !505)
!518 = distinct !{!518, !508, !519, !145}
!519 = !DILocation(line: 24, column: 5, scope: !501)
!520 = !DILocation(line: 28, column: 11, scope: !395)
!521 = !DILocation(line: 29, column: 11, scope: !395)
!522 = !DILocation(line: 31, column: 12, scope: !395)
!523 = !DILocation(line: 31, column: 5, scope: !395)
