; ModuleID = 'inlined.ll'
source_filename = "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/affine-bounds-20260929/suite/doitgen/source/workload.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

@nr = external dso_local global i32, align 4, !dbg !0
@nq = external dso_local global i32, align 4, !dbg !9
@np = external dso_local global i32, align 4, !dbg !13
@A = external dso_local global [50 x [40 x [60 x double]]], section ".chaser_data.A", align 64, !dbg !15
@sum = external dso_local global [60 x double], section ".chaser_data.sum", align 64, !dbg !22
@C4 = external dso_local global [60 x [60 x double]], section ".chaser_data.C4", align 64, !dbg !26
@.str = hidden unnamed_addr constant [12 x i8] c"ape.analyze\00", section "llvm.metadata"
@.str.1 = hidden unnamed_addr constant [125 x i8] c"/workspace/experiments-array-support/chaser/.cache/periodic-polybench/affine-bounds-20260929/suite/doitgen/source/workload.c\00", section "llvm.metadata"
@.str.2 = hidden unnamed_addr constant [23 x i8] c"==BEGIN DUMP_ARRAYS==\0A\00", align 1
@.str.3 = hidden unnamed_addr constant [15 x i8] c"begin dump: %s\00", align 1
@.str.4 = hidden unnamed_addr constant [2 x i8] c"A\00", align 1
@.str.5 = hidden unnamed_addr constant [2 x i8] c"\0A\00", align 1
@.str.6 = hidden unnamed_addr constant [8 x i8] c"%0.2lf \00", align 1
@.str.7 = hidden unnamed_addr constant [17 x i8] c"\0Aend   dump: %s\0A\00", align 1
@.str.8 = hidden unnamed_addr constant [23 x i8] c"==END   DUMP_ARRAYS==\0A\00", align 1
@llvm.global.annotations = appending global [1 x { i8*, i8*, i8*, i32, i8* }] [{ i8*, i8*, i8*, i32, i8* } { i8* bitcast (i32 ()* @task_job_polybench to i8*), i8* getelementptr inbounds ([12 x i8], [12 x i8]* @.str, i32 0, i32 0), i8* getelementptr inbounds ([125 x i8], [125 x i8]* @.str.1, i32 0, i32 0), i32 114, i8* null }], section "llvm.metadata"

; Function Attrs: noinline nounwind uwtable
define dso_local i32 @task_job_polybench() #0 !dbg !38 {
  %1 = load i32, i32* @nr, align 4, !dbg !46
  %2 = load i32, i32* @nq, align 4, !dbg !47
  %3 = load i32, i32* @np, align 4, !dbg !48
  call void @llvm.dbg.value(metadata i32 %1, metadata !49, metadata !DIExpression()), !dbg !58
  call void @llvm.dbg.value(metadata i32 %2, metadata !60, metadata !DIExpression()), !dbg !58
  call void @llvm.dbg.value(metadata i32 %3, metadata !61, metadata !DIExpression()), !dbg !58
  call void @llvm.dbg.value(metadata [40 x [60 x double]]* getelementptr inbounds ([50 x [40 x [60 x double]]], [50 x [40 x [60 x double]]]* @A, i64 0, i64 0), metadata !62, metadata !DIExpression()), !dbg !58
  call void @llvm.dbg.value(metadata [60 x double]* getelementptr inbounds ([60 x [60 x double]], [60 x [60 x double]]* @C4, i64 0, i64 0), metadata !63, metadata !DIExpression()), !dbg !58
  call void @llvm.dbg.value(metadata double* getelementptr inbounds ([60 x double], [60 x double]* @sum, i64 0, i64 0), metadata !64, metadata !DIExpression()), !dbg !58
  call void @llvm.dbg.value(metadata i32 0, metadata !65, metadata !DIExpression()), !dbg !58
  br label %4, !dbg !66

4:                                                ; preds = %54, %0
  %.03 = phi i32 [ 0, %0 ], [ %55, %54 ], !dbg !68
  call void @llvm.dbg.value(metadata i32 %.03, metadata !65, metadata !DIExpression()), !dbg !58
  %5 = icmp slt i32 %.03, 50, !dbg !69
  br i1 %5, label %6, label %56, !dbg !71

6:                                                ; preds = %4
  call void @llvm.dbg.value(metadata i32 0, metadata !72, metadata !DIExpression()), !dbg !58
  br label %7, !dbg !73

7:                                                ; preds = %52, %6
  %.02 = phi i32 [ 0, %6 ], [ %53, %52 ], !dbg !75
  call void @llvm.dbg.value(metadata i32 %.02, metadata !72, metadata !DIExpression()), !dbg !58
  %8 = icmp slt i32 %.02, 40, !dbg !76
  br i1 %8, label %9, label %54, !dbg !78

9:                                                ; preds = %7
  call void @llvm.dbg.value(metadata i32 0, metadata !79, metadata !DIExpression()), !dbg !58
  br label %10, !dbg !80

10:                                               ; preds = %36, %9
  %.01 = phi i32 [ 0, %9 ], [ %37, %36 ], !dbg !83
  call void @llvm.dbg.value(metadata i32 %.01, metadata !79, metadata !DIExpression()), !dbg !58
  %11 = icmp slt i32 %.01, 60, !dbg !84
  br i1 %11, label %12, label %38, !dbg !86

12:                                               ; preds = %10
  %13 = sext i32 %.01 to i64, !dbg !87
  %14 = getelementptr inbounds double, double* getelementptr inbounds ([60 x double], [60 x double]* @sum, i64 0, i64 0), i64 %13, !dbg !87
  store double 0.000000e+00, double* %14, align 8, !dbg !89
  call void @llvm.dbg.value(metadata i32 0, metadata !90, metadata !DIExpression()), !dbg !58
  br label %15, !dbg !91

15:                                               ; preds = %17, %12
  %.0 = phi i32 [ 0, %12 ], [ %35, %17 ], !dbg !93
  call void @llvm.dbg.value(metadata i32 %.0, metadata !90, metadata !DIExpression()), !dbg !58
  %16 = icmp slt i32 %.0, 60, !dbg !94
  br i1 %16, label %17, label %36, !dbg !96

17:                                               ; preds = %15
  %18 = sext i32 %.03 to i64, !dbg !97
  %19 = getelementptr inbounds [40 x [60 x double]], [40 x [60 x double]]* getelementptr inbounds ([50 x [40 x [60 x double]]], [50 x [40 x [60 x double]]]* @A, i64 0, i64 0), i64 %18, !dbg !97
  %20 = sext i32 %.02 to i64, !dbg !97
  %21 = getelementptr inbounds [40 x [60 x double]], [40 x [60 x double]]* %19, i64 0, i64 %20, !dbg !97
  %22 = sext i32 %.0 to i64, !dbg !97
  %23 = getelementptr inbounds [60 x double], [60 x double]* %21, i64 0, i64 %22, !dbg !97
  %24 = load double, double* %23, align 8, !dbg !97
  %25 = sext i32 %.0 to i64, !dbg !98
  %26 = getelementptr inbounds [60 x double], [60 x double]* getelementptr inbounds ([60 x [60 x double]], [60 x [60 x double]]* @C4, i64 0, i64 0), i64 %25, !dbg !98
  %27 = sext i32 %.01 to i64, !dbg !98
  %28 = getelementptr inbounds [60 x double], [60 x double]* %26, i64 0, i64 %27, !dbg !98
  %29 = load double, double* %28, align 8, !dbg !98
  %30 = fmul double %24, %29, !dbg !99
  %31 = sext i32 %.01 to i64, !dbg !100
  %32 = getelementptr inbounds double, double* getelementptr inbounds ([60 x double], [60 x double]* @sum, i64 0, i64 0), i64 %31, !dbg !100
  %33 = load double, double* %32, align 8, !dbg !101
  %34 = fadd double %33, %30, !dbg !101
  store double %34, double* %32, align 8, !dbg !101
  %35 = add nsw i32 %.0, 1, !dbg !102
  call void @llvm.dbg.value(metadata i32 %35, metadata !90, metadata !DIExpression()), !dbg !58
  br label %15, !dbg !103, !llvm.loop !104

36:                                               ; preds = %15
  %37 = add nsw i32 %.01, 1, !dbg !107
  call void @llvm.dbg.value(metadata i32 %37, metadata !79, metadata !DIExpression()), !dbg !58
  br label %10, !dbg !108, !llvm.loop !109

38:                                               ; preds = %10
  call void @llvm.dbg.value(metadata i32 0, metadata !79, metadata !DIExpression()), !dbg !58
  br label %39, !dbg !111

39:                                               ; preds = %41, %38
  %.1 = phi i32 [ 0, %38 ], [ %51, %41 ], !dbg !113
  call void @llvm.dbg.value(metadata i32 %.1, metadata !79, metadata !DIExpression()), !dbg !58
  %40 = icmp slt i32 %.1, 60, !dbg !114
  br i1 %40, label %41, label %52, !dbg !116

41:                                               ; preds = %39
  %42 = sext i32 %.1 to i64, !dbg !117
  %43 = getelementptr inbounds double, double* getelementptr inbounds ([60 x double], [60 x double]* @sum, i64 0, i64 0), i64 %42, !dbg !117
  %44 = load double, double* %43, align 8, !dbg !117
  %45 = sext i32 %.03 to i64, !dbg !118
  %46 = getelementptr inbounds [40 x [60 x double]], [40 x [60 x double]]* getelementptr inbounds ([50 x [40 x [60 x double]]], [50 x [40 x [60 x double]]]* @A, i64 0, i64 0), i64 %45, !dbg !118
  %47 = sext i32 %.02 to i64, !dbg !118
  %48 = getelementptr inbounds [40 x [60 x double]], [40 x [60 x double]]* %46, i64 0, i64 %47, !dbg !118
  %49 = sext i32 %.1 to i64, !dbg !118
  %50 = getelementptr inbounds [60 x double], [60 x double]* %48, i64 0, i64 %49, !dbg !118
  store double %44, double* %50, align 8, !dbg !119
  %51 = add nsw i32 %.1, 1, !dbg !120
  call void @llvm.dbg.value(metadata i32 %51, metadata !79, metadata !DIExpression()), !dbg !58
  br label %39, !dbg !121, !llvm.loop !122

52:                                               ; preds = %39
  %53 = add nsw i32 %.02, 1, !dbg !124
  call void @llvm.dbg.value(metadata i32 %53, metadata !72, metadata !DIExpression()), !dbg !58
  br label %7, !dbg !125, !llvm.loop !126

54:                                               ; preds = %7
  %55 = add nsw i32 %.03, 1, !dbg !128
  call void @llvm.dbg.value(metadata i32 %55, metadata !65, metadata !DIExpression()), !dbg !58
  br label %4, !dbg !129, !llvm.loop !130

56:                                               ; preds = %4
  ret i32 0, !dbg !132
}

; Function Attrs: nofree nosync nounwind readnone speculatable willreturn
declare void @llvm.dbg.value(metadata, metadata, metadata) #1

attributes #0 = { noinline nounwind uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { nofree nosync nounwind readnone speculatable willreturn }

!llvm.dbg.cu = !{!2}
!llvm.module.flags = !{!30, !31, !32, !33, !34, !35, !36}
!llvm.ident = !{!37}

!0 = !DIGlobalVariableExpression(var: !1, expr: !DIExpression())
!1 = distinct !DIGlobalVariable(name: "nr", scope: !2, file: !11, line: 101, type: !12, isLocal: false, isDefinition: true)
!2 = distinct !DICompileUnit(language: DW_LANG_C99, file: !3, producer: "Ubuntu clang version 14.0.0-1ubuntu1.1", isOptimized: false, runtimeVersion: 0, emissionKind: FullDebug, retainedTypes: !4, globals: !8, splitDebugInlining: false, nameTableKind: None)
!3 = !DIFile(filename: "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/affine-bounds-20260929/suite/doitgen/source/workload.c", directory: "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/affine-bounds-20260929/suite/doitgen/analysis-g", checksumkind: CSK_MD5, checksum: "1cfaa4ce7cb91ebdd65caf7b87276fe2")
!4 = !{!5, !6, !7}
!5 = !DIBasicType(name: "double", size: 64, encoding: DW_ATE_float)
!6 = !DIBasicType(name: "unsigned int", size: 32, encoding: DW_ATE_unsigned)
!7 = !DIBasicType(name: "unsigned char", size: 8, encoding: DW_ATE_unsigned_char)
!8 = !{!0, !9, !13, !15, !22, !26}
!9 = !DIGlobalVariableExpression(var: !10, expr: !DIExpression())
!10 = distinct !DIGlobalVariable(name: "nq", scope: !2, file: !11, line: 102, type: !12, isLocal: false, isDefinition: true)
!11 = !DIFile(filename: "source/workload.c", directory: "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/affine-bounds-20260929/suite/doitgen", checksumkind: CSK_MD5, checksum: "1cfaa4ce7cb91ebdd65caf7b87276fe2")
!12 = !DIBasicType(name: "int", size: 32, encoding: DW_ATE_signed)
!13 = !DIGlobalVariableExpression(var: !14, expr: !DIExpression())
!14 = distinct !DIGlobalVariable(name: "np", scope: !2, file: !11, line: 103, type: !12, isLocal: false, isDefinition: true)
!15 = !DIGlobalVariableExpression(var: !16, expr: !DIExpression())
!16 = distinct !DIGlobalVariable(name: "A", scope: !2, file: !11, line: 34, type: !17, isLocal: false, isDefinition: true, align: 512)
!17 = !DICompositeType(tag: DW_TAG_array_type, baseType: !5, size: 7680000, elements: !18)
!18 = !{!19, !20, !21}
!19 = !DISubrange(count: 50)
!20 = !DISubrange(count: 40)
!21 = !DISubrange(count: 60)
!22 = !DIGlobalVariableExpression(var: !23, expr: !DIExpression())
!23 = distinct !DIGlobalVariable(name: "sum", scope: !2, file: !11, line: 35, type: !24, isLocal: false, isDefinition: true, align: 512)
!24 = !DICompositeType(tag: DW_TAG_array_type, baseType: !5, size: 3840, elements: !25)
!25 = !{!21}
!26 = !DIGlobalVariableExpression(var: !27, expr: !DIExpression())
!27 = distinct !DIGlobalVariable(name: "C4", scope: !2, file: !11, line: 36, type: !28, isLocal: false, isDefinition: true, align: 512)
!28 = !DICompositeType(tag: DW_TAG_array_type, baseType: !5, size: 230400, elements: !29)
!29 = !{!21, !21}
!30 = !{i32 7, !"Dwarf Version", i32 5}
!31 = !{i32 2, !"Debug Info Version", i32 3}
!32 = !{i32 1, !"wchar_size", i32 4}
!33 = !{i32 7, !"PIC Level", i32 2}
!34 = !{i32 7, !"PIE Level", i32 2}
!35 = !{i32 7, !"uwtable", i32 1}
!36 = !{i32 7, !"frame-pointer", i32 2}
!37 = !{!"Ubuntu clang version 14.0.0-1ubuntu1.1"}
!38 = distinct !DISubprogram(name: "task_job_polybench", scope: !11, file: !11, line: 114, type: !39, scopeLine: 114, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !2, retainedNodes: !45)
!39 = !DISubroutineType(types: !40)
!40 = !{!41}
!41 = !DIDerivedType(tag: DW_TAG_typedef, name: "uint32_t", file: !42, line: 26, baseType: !43)
!42 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/stdint-uintn.h", directory: "", checksumkind: CSK_MD5, checksum: "2bf2ae53c58c01b1a1b9383b5195125c")
!43 = !DIDerivedType(tag: DW_TAG_typedef, name: "__uint32_t", file: !44, line: 42, baseType: !6)
!44 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/types.h", directory: "", checksumkind: CSK_MD5, checksum: "d108b5f93a74c50510d7d9bc0ab36df9")
!45 = !{}
!46 = !DILocation(line: 115, column: 19, scope: !38)
!47 = !DILocation(line: 115, column: 23, scope: !38)
!48 = !DILocation(line: 115, column: 27, scope: !38)
!49 = !DILocalVariable(name: "nr", arg: 1, scope: !50, file: !11, line: 77, type: !12)
!50 = distinct !DISubprogram(name: "kernel_doitgen", scope: !11, file: !11, line: 77, type: !51, scopeLine: 81, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !2, retainedNodes: !45)
!51 = !DISubroutineType(types: !52)
!52 = !{null, !12, !12, !12, !53, !56, !57}
!53 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !54, size: 64)
!54 = !DICompositeType(tag: DW_TAG_array_type, baseType: !5, size: 153600, elements: !55)
!55 = !{!20, !21}
!56 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !24, size: 64)
!57 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !5, size: 64)
!58 = !DILocation(line: 0, scope: !50, inlinedAt: !59)
!59 = distinct !DILocation(line: 115, column: 3, scope: !38)
!60 = !DILocalVariable(name: "nq", arg: 2, scope: !50, file: !11, line: 77, type: !12)
!61 = !DILocalVariable(name: "np", arg: 3, scope: !50, file: !11, line: 77, type: !12)
!62 = !DILocalVariable(name: "A", arg: 4, scope: !50, file: !11, line: 78, type: !53)
!63 = !DILocalVariable(name: "C4", arg: 5, scope: !50, file: !11, line: 79, type: !56)
!64 = !DILocalVariable(name: "sum", arg: 6, scope: !50, file: !11, line: 80, type: !57)
!65 = !DILocalVariable(name: "r", scope: !50, file: !11, line: 82, type: !12)
!66 = !DILocation(line: 85, column: 8, scope: !67, inlinedAt: !59)
!67 = distinct !DILexicalBlock(scope: !50, file: !11, line: 85, column: 3)
!68 = !DILocation(line: 0, scope: !67, inlinedAt: !59)
!69 = !DILocation(line: 85, column: 17, scope: !70, inlinedAt: !59)
!70 = distinct !DILexicalBlock(scope: !67, file: !11, line: 85, column: 3)
!71 = !DILocation(line: 85, column: 3, scope: !67, inlinedAt: !59)
!72 = !DILocalVariable(name: "q", scope: !50, file: !11, line: 82, type: !12)
!73 = !DILocation(line: 86, column: 10, scope: !74, inlinedAt: !59)
!74 = distinct !DILexicalBlock(scope: !70, file: !11, line: 86, column: 5)
!75 = !DILocation(line: 0, scope: !74, inlinedAt: !59)
!76 = !DILocation(line: 86, column: 19, scope: !77, inlinedAt: !59)
!77 = distinct !DILexicalBlock(scope: !74, file: !11, line: 86, column: 5)
!78 = !DILocation(line: 86, column: 5, scope: !74, inlinedAt: !59)
!79 = !DILocalVariable(name: "p", scope: !50, file: !11, line: 82, type: !12)
!80 = !DILocation(line: 87, column: 12, scope: !81, inlinedAt: !59)
!81 = distinct !DILexicalBlock(scope: !82, file: !11, line: 87, column: 7)
!82 = distinct !DILexicalBlock(scope: !77, file: !11, line: 86, column: 35)
!83 = !DILocation(line: 0, scope: !81, inlinedAt: !59)
!84 = !DILocation(line: 87, column: 21, scope: !85, inlinedAt: !59)
!85 = distinct !DILexicalBlock(scope: !81, file: !11, line: 87, column: 7)
!86 = !DILocation(line: 87, column: 7, scope: !81, inlinedAt: !59)
!87 = !DILocation(line: 88, column: 2, scope: !88, inlinedAt: !59)
!88 = distinct !DILexicalBlock(scope: !85, file: !11, line: 87, column: 37)
!89 = !DILocation(line: 88, column: 9, scope: !88, inlinedAt: !59)
!90 = !DILocalVariable(name: "s", scope: !50, file: !11, line: 82, type: !12)
!91 = !DILocation(line: 89, column: 7, scope: !92, inlinedAt: !59)
!92 = distinct !DILexicalBlock(scope: !88, file: !11, line: 89, column: 2)
!93 = !DILocation(line: 0, scope: !92, inlinedAt: !59)
!94 = !DILocation(line: 89, column: 16, scope: !95, inlinedAt: !59)
!95 = distinct !DILexicalBlock(scope: !92, file: !11, line: 89, column: 2)
!96 = !DILocation(line: 89, column: 2, scope: !92, inlinedAt: !59)
!97 = !DILocation(line: 90, column: 14, scope: !95, inlinedAt: !59)
!98 = !DILocation(line: 90, column: 27, scope: !95, inlinedAt: !59)
!99 = !DILocation(line: 90, column: 25, scope: !95, inlinedAt: !59)
!100 = !DILocation(line: 90, column: 4, scope: !95, inlinedAt: !59)
!101 = !DILocation(line: 90, column: 11, scope: !95, inlinedAt: !59)
!102 = !DILocation(line: 89, column: 27, scope: !95, inlinedAt: !59)
!103 = !DILocation(line: 89, column: 2, scope: !95, inlinedAt: !59)
!104 = distinct !{!104, !96, !105, !106}
!105 = !DILocation(line: 90, column: 34, scope: !92, inlinedAt: !59)
!106 = !{!"llvm.loop.mustprogress"}
!107 = !DILocation(line: 87, column: 32, scope: !85, inlinedAt: !59)
!108 = !DILocation(line: 87, column: 7, scope: !85, inlinedAt: !59)
!109 = distinct !{!109, !86, !110, !106}
!110 = !DILocation(line: 91, column: 7, scope: !81, inlinedAt: !59)
!111 = !DILocation(line: 92, column: 12, scope: !112, inlinedAt: !59)
!112 = distinct !DILexicalBlock(scope: !82, file: !11, line: 92, column: 7)
!113 = !DILocation(line: 0, scope: !112, inlinedAt: !59)
!114 = !DILocation(line: 92, column: 21, scope: !115, inlinedAt: !59)
!115 = distinct !DILexicalBlock(scope: !112, file: !11, line: 92, column: 7)
!116 = !DILocation(line: 92, column: 7, scope: !112, inlinedAt: !59)
!117 = !DILocation(line: 93, column: 15, scope: !115, inlinedAt: !59)
!118 = !DILocation(line: 93, column: 2, scope: !115, inlinedAt: !59)
!119 = !DILocation(line: 93, column: 13, scope: !115, inlinedAt: !59)
!120 = !DILocation(line: 92, column: 32, scope: !115, inlinedAt: !59)
!121 = !DILocation(line: 92, column: 7, scope: !115, inlinedAt: !59)
!122 = distinct !{!122, !116, !123, !106}
!123 = !DILocation(line: 93, column: 20, scope: !112, inlinedAt: !59)
!124 = !DILocation(line: 86, column: 30, scope: !77, inlinedAt: !59)
!125 = !DILocation(line: 86, column: 5, scope: !77, inlinedAt: !59)
!126 = distinct !{!126, !78, !127, !106}
!127 = !DILocation(line: 94, column: 5, scope: !74, inlinedAt: !59)
!128 = !DILocation(line: 85, column: 28, scope: !70, inlinedAt: !59)
!129 = !DILocation(line: 85, column: 3, scope: !70, inlinedAt: !59)
!130 = distinct !{!130, !71, !131, !106}
!131 = !DILocation(line: 94, column: 5, scope: !67, inlinedAt: !59)
!132 = !DILocation(line: 119, column: 3, scope: !38)
