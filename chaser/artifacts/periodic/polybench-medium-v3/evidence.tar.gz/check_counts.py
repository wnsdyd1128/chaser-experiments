"""원본 C 루프에서 유도한 접근 수로 종속 종료 경계의 반복 횟수를 확인한다."""
import json
from pathlib import Path

RUN = Path(__file__).resolve().parent
report = json.loads((RUN/'summary.json').read_text())
checks = {}
for name in ('syrk','syr2k','trisolv','durbin'):
    row = report['benchmarks'][name]
    dims = row['dimensions']
    n = dims['N']
    if name in ('syrk','syr2k'):
        # i=0..N-1, j=0..i: N(N+1)/2회. beta 갱신은 2접근.
        # k당 SYRK는 4접근, SYR2K는 6접근. 호출부 n,m,alpha,beta는 4읽기.
        per_update = 4 if name=='syrk' else 6
        expected = 4 + n*(n+1)//2 * (2 + per_update*dims['M'])
        formula = f'4 + N*(N+1)/2 * (2 + {per_update}*M)'
    elif name=='trisolv':
        # j=0..i-1: N(N-1)/2회, 몸체 4접근. 행별 복사 2 + 나눗셈 3접근.
        # 호출부 n은 1읽기. i=0에서 내부 루프는 실행되지 않는다.
        expected = 1 + 5*n + 4*n*(n-1)//2
        formula = '1 + 5*N + 4*N*(N-1)/2'
    else:
        # 최초 r[0] 읽기 2 + y[0] 쓰기 1, 호출부 n 읽기 1.
        # k마다 r[k] 읽기와 y[k] 쓰기 2, 길이 k인 세 루프가 2+3+2접근.
        expected = 4 + 2*(n-1) + 7*n*(n-1)//2
        formula = '4 + 2*(N-1) + 7*N*(N-1)/2'
    modes = {'native':row['native_yarda'], **row['periodic_yarda']}
    assert len(modes)==4
    actual = {}
    for mode,case in modes.items():
        assert case['execution_status']=='passed',(name,mode,case)
        actual[mode]=case['modeled_accesses']
        assert actual[mode]==expected,(name,mode,actual[mode],expected)
    checks[name] = dict(dimensions=dims, formula=formula, expected_accesses=expected,
                       actual_accesses=actual, status='passed')
result = dict(status='passed', scope='independent-source-access-counts-not-dynamic-trace',checks=checks)
(RUN/'access-count-validation.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
print(json.dumps(result,indent=2))
