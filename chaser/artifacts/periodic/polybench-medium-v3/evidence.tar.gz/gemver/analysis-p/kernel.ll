; ModuleID = 'inlined.ll'
source_filename = "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/affine-bounds-20260929/suite/gemver/source/workload.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

@n = external dso_local global i32, align 4, !dbg !0
@A = external dso_local global [400 x [400 x double]], section ".chaser_data.A", align 64, !dbg !9
@u1 = external dso_local global [400 x double], section ".chaser_data.u1", align 64, !dbg !15
@v1 = external dso_local global [400 x double], section ".chaser_data.v1", align 64, !dbg !19
@u2 = external dso_local global [400 x double], section ".chaser_data.u2", align 64, !dbg !21
@v2 = external dso_local global [400 x double], section ".chaser_data.v2", align 64, !dbg !23
@w = external dso_local global [400 x double], section ".chaser_data.w", align 64, !dbg !25
@x = external dso_local global [400 x double], section ".chaser_data.x", align 64, !dbg !27
@y = external dso_local global [400 x double], section ".chaser_data.y", align 64, !dbg !29
@z = external dso_local global [400 x double], section ".chaser_data.z", align 64, !dbg !31
@alpha = external dso_local global double, align 8, !dbg !33
@beta = external dso_local global double, align 8, !dbg !35
@.str = hidden unnamed_addr constant [12 x i8] c"ape.analyze\00", section "llvm.metadata"
@.str.1 = hidden unnamed_addr constant [124 x i8] c"/workspace/experiments-array-support/chaser/.cache/periodic-polybench/affine-bounds-20260929/suite/gemver/source/workload.c\00", section "llvm.metadata"
@.str.2 = hidden unnamed_addr constant [23 x i8] c"==BEGIN DUMP_ARRAYS==\0A\00", align 1
@.str.3 = hidden unnamed_addr constant [15 x i8] c"begin dump: %s\00", align 1
@.str.4 = hidden unnamed_addr constant [2 x i8] c"w\00", align 1
@.str.5 = hidden unnamed_addr constant [2 x i8] c"\0A\00", align 1
@.str.6 = hidden unnamed_addr constant [8 x i8] c"%0.2lf \00", align 1
@.str.7 = hidden unnamed_addr constant [17 x i8] c"\0Aend   dump: %s\0A\00", align 1
@.str.8 = hidden unnamed_addr constant [23 x i8] c"==END   DUMP_ARRAYS==\0A\00", align 1
@llvm.global.annotations = appending global [1 x { i8*, i8*, i8*, i32, i8* }] [{ i8*, i8*, i8*, i32, i8* } { i8* bitcast (i32 ()* @task_job_polybench to i8*), i8* getelementptr inbounds ([12 x i8], [12 x i8]* @.str, i32 0, i32 0), i8* getelementptr inbounds ([124 x i8], [124 x i8]* @.str.1, i32 0, i32 0), i32 167, i8* null }], section "llvm.metadata"

; Function Attrs: noinline nounwind uwtable
define dso_local i32 @task_job_polybench() #0 !dbg !46 {
  %1 = load i32, i32* @n, align 4, !dbg !54
  %2 = load double, double* @alpha, align 8, !dbg !55
  %3 = load double, double* @beta, align 8, !dbg !56
  call void @llvm.dbg.value(metadata i32 %1, metadata !57, metadata !DIExpression()), !dbg !63
  call void @llvm.dbg.value(metadata double %2, metadata !65, metadata !DIExpression()), !dbg !63
  call void @llvm.dbg.value(metadata double %3, metadata !66, metadata !DIExpression()), !dbg !63
  call void @llvm.dbg.value(metadata [400 x double]* getelementptr inbounds ([400 x [400 x double]], [400 x [400 x double]]* @A, i64 0, i64 0), metadata !67, metadata !DIExpression()), !dbg !63
  call void @llvm.dbg.value(metadata double* getelementptr inbounds ([400 x double], [400 x double]* @u1, i64 0, i64 0), metadata !68, metadata !DIExpression()), !dbg !63
  call void @llvm.dbg.value(metadata double* getelementptr inbounds ([400 x double], [400 x double]* @v1, i64 0, i64 0), metadata !69, metadata !DIExpression()), !dbg !63
  call void @llvm.dbg.value(metadata double* getelementptr inbounds ([400 x double], [400 x double]* @u2, i64 0, i64 0), metadata !70, metadata !DIExpression()), !dbg !63
  call void @llvm.dbg.value(metadata double* getelementptr inbounds ([400 x double], [400 x double]* @v2, i64 0, i64 0), metadata !71, metadata !DIExpression()), !dbg !63
  call void @llvm.dbg.value(metadata double* getelementptr inbounds ([400 x double], [400 x double]* @w, i64 0, i64 0), metadata !72, metadata !DIExpression()), !dbg !63
  call void @llvm.dbg.value(metadata double* getelementptr inbounds ([400 x double], [400 x double]* @x, i64 0, i64 0), metadata !73, metadata !DIExpression()), !dbg !63
  call void @llvm.dbg.value(metadata double* getelementptr inbounds ([400 x double], [400 x double]* @y, i64 0, i64 0), metadata !74, metadata !DIExpression()), !dbg !63
  call void @llvm.dbg.value(metadata double* getelementptr inbounds ([400 x double], [400 x double]* @z, i64 0, i64 0), metadata !75, metadata !DIExpression()), !dbg !63
  call void @llvm.dbg.value(metadata i32 0, metadata !76, metadata !DIExpression()), !dbg !63
  br label %4, !dbg !77

4:                                                ; preds = %36, %0
  %.01 = phi i32 [ 0, %0 ], [ %37, %36 ], !dbg !79
  call void @llvm.dbg.value(metadata i32 %.01, metadata !76, metadata !DIExpression()), !dbg !63
  %5 = icmp slt i32 %.01, 400, !dbg !80
  br i1 %5, label %6, label %38, !dbg !82

6:                                                ; preds = %4
  call void @llvm.dbg.value(metadata i32 0, metadata !83, metadata !DIExpression()), !dbg !63
  br label %7, !dbg !84

7:                                                ; preds = %9, %6
  %.0 = phi i32 [ 0, %6 ], [ %35, %9 ], !dbg !86
  call void @llvm.dbg.value(metadata i32 %.0, metadata !83, metadata !DIExpression()), !dbg !63
  %8 = icmp slt i32 %.0, 400, !dbg !87
  br i1 %8, label %9, label %36, !dbg !89

9:                                                ; preds = %7
  %10 = sext i32 %.01 to i64, !dbg !90
  %11 = getelementptr inbounds [400 x double], [400 x double]* getelementptr inbounds ([400 x [400 x double]], [400 x [400 x double]]* @A, i64 0, i64 0), i64 %10, !dbg !90
  %12 = sext i32 %.0 to i64, !dbg !90
  %13 = getelementptr inbounds [400 x double], [400 x double]* %11, i64 0, i64 %12, !dbg !90
  %14 = load double, double* %13, align 8, !dbg !90
  %15 = sext i32 %.01 to i64, !dbg !91
  %16 = getelementptr inbounds double, double* getelementptr inbounds ([400 x double], [400 x double]* @u1, i64 0, i64 0), i64 %15, !dbg !91
  %17 = load double, double* %16, align 8, !dbg !91
  %18 = sext i32 %.0 to i64, !dbg !92
  %19 = getelementptr inbounds double, double* getelementptr inbounds ([400 x double], [400 x double]* @v1, i64 0, i64 0), i64 %18, !dbg !92
  %20 = load double, double* %19, align 8, !dbg !92
  %21 = fmul double %17, %20, !dbg !93
  %22 = fadd double %14, %21, !dbg !94
  %23 = sext i32 %.01 to i64, !dbg !95
  %24 = getelementptr inbounds double, double* getelementptr inbounds ([400 x double], [400 x double]* @u2, i64 0, i64 0), i64 %23, !dbg !95
  %25 = load double, double* %24, align 8, !dbg !95
  %26 = sext i32 %.0 to i64, !dbg !96
  %27 = getelementptr inbounds double, double* getelementptr inbounds ([400 x double], [400 x double]* @v2, i64 0, i64 0), i64 %26, !dbg !96
  %28 = load double, double* %27, align 8, !dbg !96
  %29 = fmul double %25, %28, !dbg !97
  %30 = fadd double %22, %29, !dbg !98
  %31 = sext i32 %.01 to i64, !dbg !99
  %32 = getelementptr inbounds [400 x double], [400 x double]* getelementptr inbounds ([400 x [400 x double]], [400 x [400 x double]]* @A, i64 0, i64 0), i64 %31, !dbg !99
  %33 = sext i32 %.0 to i64, !dbg !99
  %34 = getelementptr inbounds [400 x double], [400 x double]* %32, i64 0, i64 %33, !dbg !99
  store double %30, double* %34, align 8, !dbg !100
  %35 = add nsw i32 %.0, 1, !dbg !101
  call void @llvm.dbg.value(metadata i32 %35, metadata !83, metadata !DIExpression()), !dbg !63
  br label %7, !dbg !102, !llvm.loop !103

36:                                               ; preds = %7
  %37 = add nsw i32 %.01, 1, !dbg !106
  call void @llvm.dbg.value(metadata i32 %37, metadata !76, metadata !DIExpression()), !dbg !63
  br label %4, !dbg !107, !llvm.loop !108

38:                                               ; preds = %4
  call void @llvm.dbg.value(metadata i32 0, metadata !76, metadata !DIExpression()), !dbg !63
  br label %39, !dbg !110

39:                                               ; preds = %62, %38
  %.12 = phi i32 [ 0, %38 ], [ %63, %62 ], !dbg !112
  call void @llvm.dbg.value(metadata i32 %.12, metadata !76, metadata !DIExpression()), !dbg !63
  %40 = icmp slt i32 %.12, 400, !dbg !113
  br i1 %40, label %41, label %64, !dbg !115

41:                                               ; preds = %39
  call void @llvm.dbg.value(metadata i32 0, metadata !83, metadata !DIExpression()), !dbg !63
  br label %42, !dbg !116

42:                                               ; preds = %44, %41
  %.1 = phi i32 [ 0, %41 ], [ %61, %44 ], !dbg !118
  call void @llvm.dbg.value(metadata i32 %.1, metadata !83, metadata !DIExpression()), !dbg !63
  %43 = icmp slt i32 %.1, 400, !dbg !119
  br i1 %43, label %44, label %62, !dbg !121

44:                                               ; preds = %42
  %45 = sext i32 %.12 to i64, !dbg !122
  %46 = getelementptr inbounds double, double* getelementptr inbounds ([400 x double], [400 x double]* @x, i64 0, i64 0), i64 %45, !dbg !122
  %47 = load double, double* %46, align 8, !dbg !122
  %48 = sext i32 %.1 to i64, !dbg !123
  %49 = getelementptr inbounds [400 x double], [400 x double]* getelementptr inbounds ([400 x [400 x double]], [400 x [400 x double]]* @A, i64 0, i64 0), i64 %48, !dbg !123
  %50 = sext i32 %.12 to i64, !dbg !123
  %51 = getelementptr inbounds [400 x double], [400 x double]* %49, i64 0, i64 %50, !dbg !123
  %52 = load double, double* %51, align 8, !dbg !123
  %53 = fmul double %3, %52, !dbg !124
  %54 = sext i32 %.1 to i64, !dbg !125
  %55 = getelementptr inbounds double, double* getelementptr inbounds ([400 x double], [400 x double]* @y, i64 0, i64 0), i64 %54, !dbg !125
  %56 = load double, double* %55, align 8, !dbg !125
  %57 = fmul double %53, %56, !dbg !126
  %58 = fadd double %47, %57, !dbg !127
  %59 = sext i32 %.12 to i64, !dbg !128
  %60 = getelementptr inbounds double, double* getelementptr inbounds ([400 x double], [400 x double]* @x, i64 0, i64 0), i64 %59, !dbg !128
  store double %58, double* %60, align 8, !dbg !129
  %61 = add nsw i32 %.1, 1, !dbg !130
  call void @llvm.dbg.value(metadata i32 %61, metadata !83, metadata !DIExpression()), !dbg !63
  br label %42, !dbg !131, !llvm.loop !132

62:                                               ; preds = %42
  %63 = add nsw i32 %.12, 1, !dbg !134
  call void @llvm.dbg.value(metadata i32 %63, metadata !76, metadata !DIExpression()), !dbg !63
  br label %39, !dbg !135, !llvm.loop !136

64:                                               ; preds = %39
  call void @llvm.dbg.value(metadata i32 0, metadata !76, metadata !DIExpression()), !dbg !63
  br label %65, !dbg !138

65:                                               ; preds = %67, %64
  %.23 = phi i32 [ 0, %64 ], [ %77, %67 ], !dbg !140
  call void @llvm.dbg.value(metadata i32 %.23, metadata !76, metadata !DIExpression()), !dbg !63
  %66 = icmp slt i32 %.23, 400, !dbg !141
  br i1 %66, label %67, label %78, !dbg !143

67:                                               ; preds = %65
  %68 = sext i32 %.23 to i64, !dbg !144
  %69 = getelementptr inbounds double, double* getelementptr inbounds ([400 x double], [400 x double]* @x, i64 0, i64 0), i64 %68, !dbg !144
  %70 = load double, double* %69, align 8, !dbg !144
  %71 = sext i32 %.23 to i64, !dbg !145
  %72 = getelementptr inbounds double, double* getelementptr inbounds ([400 x double], [400 x double]* @z, i64 0, i64 0), i64 %71, !dbg !145
  %73 = load double, double* %72, align 8, !dbg !145
  %74 = fadd double %70, %73, !dbg !146
  %75 = sext i32 %.23 to i64, !dbg !147
  %76 = getelementptr inbounds double, double* getelementptr inbounds ([400 x double], [400 x double]* @x, i64 0, i64 0), i64 %75, !dbg !147
  store double %74, double* %76, align 8, !dbg !148
  %77 = add nsw i32 %.23, 1, !dbg !149
  call void @llvm.dbg.value(metadata i32 %77, metadata !76, metadata !DIExpression()), !dbg !63
  br label %65, !dbg !150, !llvm.loop !151

78:                                               ; preds = %65
  call void @llvm.dbg.value(metadata i32 0, metadata !76, metadata !DIExpression()), !dbg !63
  br label %79, !dbg !153

79:                                               ; preds = %102, %78
  %.3 = phi i32 [ 0, %78 ], [ %103, %102 ], !dbg !155
  call void @llvm.dbg.value(metadata i32 %.3, metadata !76, metadata !DIExpression()), !dbg !63
  %80 = icmp slt i32 %.3, 400, !dbg !156
  br i1 %80, label %81, label %104, !dbg !158

81:                                               ; preds = %79
  call void @llvm.dbg.value(metadata i32 0, metadata !83, metadata !DIExpression()), !dbg !63
  br label %82, !dbg !159

82:                                               ; preds = %84, %81
  %.2 = phi i32 [ 0, %81 ], [ %101, %84 ], !dbg !161
  call void @llvm.dbg.value(metadata i32 %.2, metadata !83, metadata !DIExpression()), !dbg !63
  %83 = icmp slt i32 %.2, 400, !dbg !162
  br i1 %83, label %84, label %102, !dbg !164

84:                                               ; preds = %82
  %85 = sext i32 %.3 to i64, !dbg !165
  %86 = getelementptr inbounds double, double* getelementptr inbounds ([400 x double], [400 x double]* @w, i64 0, i64 0), i64 %85, !dbg !165
  %87 = load double, double* %86, align 8, !dbg !165
  %88 = sext i32 %.3 to i64, !dbg !166
  %89 = getelementptr inbounds [400 x double], [400 x double]* getelementptr inbounds ([400 x [400 x double]], [400 x [400 x double]]* @A, i64 0, i64 0), i64 %88, !dbg !166
  %90 = sext i32 %.2 to i64, !dbg !166
  %91 = getelementptr inbounds [400 x double], [400 x double]* %89, i64 0, i64 %90, !dbg !166
  %92 = load double, double* %91, align 8, !dbg !166
  %93 = fmul double %2, %92, !dbg !167
  %94 = sext i32 %.2 to i64, !dbg !168
  %95 = getelementptr inbounds double, double* getelementptr inbounds ([400 x double], [400 x double]* @x, i64 0, i64 0), i64 %94, !dbg !168
  %96 = load double, double* %95, align 8, !dbg !168
  %97 = fmul double %93, %96, !dbg !169
  %98 = fadd double %87, %97, !dbg !170
  %99 = sext i32 %.3 to i64, !dbg !171
  %100 = getelementptr inbounds double, double* getelementptr inbounds ([400 x double], [400 x double]* @w, i64 0, i64 0), i64 %99, !dbg !171
  store double %98, double* %100, align 8, !dbg !172
  %101 = add nsw i32 %.2, 1, !dbg !173
  call void @llvm.dbg.value(metadata i32 %101, metadata !83, metadata !DIExpression()), !dbg !63
  br label %82, !dbg !174, !llvm.loop !175

102:                                              ; preds = %82
  %103 = add nsw i32 %.3, 1, !dbg !177
  call void @llvm.dbg.value(metadata i32 %103, metadata !76, metadata !DIExpression()), !dbg !63
  br label %79, !dbg !178, !llvm.loop !179

104:                                              ; preds = %79
  ret i32 0, !dbg !181
}

; Function Attrs: nofree nosync nounwind readnone speculatable willreturn
declare void @llvm.dbg.value(metadata, metadata, metadata) #1

attributes #0 = { noinline nounwind uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { nofree nosync nounwind readnone speculatable willreturn }

!llvm.dbg.cu = !{!2}
!llvm.module.flags = !{!38, !39, !40, !41, !42, !43, !44}
!llvm.ident = !{!45}

!0 = !DIGlobalVariableExpression(var: !1, expr: !DIExpression())
!1 = distinct !DIGlobalVariable(name: "n", scope: !2, file: !11, line: 139, type: !37, isLocal: false, isDefinition: true)
!2 = distinct !DICompileUnit(language: DW_LANG_C99, file: !3, producer: "Ubuntu clang version 14.0.0-1ubuntu1.1", isOptimized: false, runtimeVersion: 0, emissionKind: FullDebug, retainedTypes: !4, globals: !8, splitDebugInlining: false, nameTableKind: None)
!3 = !DIFile(filename: "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/affine-bounds-20260929/suite/gemver/source/workload.c", directory: "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/affine-bounds-20260929/suite/gemver/analysis-p", checksumkind: CSK_MD5, checksum: "bbe83b0f1a92e4629170a4942716c66e")
!4 = !{!5, !6, !7}
!5 = !DIBasicType(name: "double", size: 64, encoding: DW_ATE_float)
!6 = !DIBasicType(name: "unsigned int", size: 32, encoding: DW_ATE_unsigned)
!7 = !DIBasicType(name: "unsigned char", size: 8, encoding: DW_ATE_unsigned_char)
!8 = !{!0, !9, !15, !19, !21, !23, !25, !27, !29, !31, !33, !35}
!9 = !DIGlobalVariableExpression(var: !10, expr: !DIExpression())
!10 = distinct !DIGlobalVariable(name: "A", scope: !2, file: !11, line: 34, type: !12, isLocal: false, isDefinition: true, align: 512)
!11 = !DIFile(filename: "source/workload.c", directory: "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/affine-bounds-20260929/suite/gemver", checksumkind: CSK_MD5, checksum: "bbe83b0f1a92e4629170a4942716c66e")
!12 = !DICompositeType(tag: DW_TAG_array_type, baseType: !5, size: 10240000, elements: !13)
!13 = !{!14, !14}
!14 = !DISubrange(count: 400)
!15 = !DIGlobalVariableExpression(var: !16, expr: !DIExpression())
!16 = distinct !DIGlobalVariable(name: "u1", scope: !2, file: !11, line: 35, type: !17, isLocal: false, isDefinition: true, align: 512)
!17 = !DICompositeType(tag: DW_TAG_array_type, baseType: !5, size: 25600, elements: !18)
!18 = !{!14}
!19 = !DIGlobalVariableExpression(var: !20, expr: !DIExpression())
!20 = distinct !DIGlobalVariable(name: "v1", scope: !2, file: !11, line: 36, type: !17, isLocal: false, isDefinition: true, align: 512)
!21 = !DIGlobalVariableExpression(var: !22, expr: !DIExpression())
!22 = distinct !DIGlobalVariable(name: "u2", scope: !2, file: !11, line: 37, type: !17, isLocal: false, isDefinition: true, align: 512)
!23 = !DIGlobalVariableExpression(var: !24, expr: !DIExpression())
!24 = distinct !DIGlobalVariable(name: "v2", scope: !2, file: !11, line: 38, type: !17, isLocal: false, isDefinition: true, align: 512)
!25 = !DIGlobalVariableExpression(var: !26, expr: !DIExpression())
!26 = distinct !DIGlobalVariable(name: "w", scope: !2, file: !11, line: 39, type: !17, isLocal: false, isDefinition: true, align: 512)
!27 = !DIGlobalVariableExpression(var: !28, expr: !DIExpression())
!28 = distinct !DIGlobalVariable(name: "x", scope: !2, file: !11, line: 40, type: !17, isLocal: false, isDefinition: true, align: 512)
!29 = !DIGlobalVariableExpression(var: !30, expr: !DIExpression())
!30 = distinct !DIGlobalVariable(name: "y", scope: !2, file: !11, line: 41, type: !17, isLocal: false, isDefinition: true, align: 512)
!31 = !DIGlobalVariableExpression(var: !32, expr: !DIExpression())
!32 = distinct !DIGlobalVariable(name: "z", scope: !2, file: !11, line: 42, type: !17, isLocal: false, isDefinition: true, align: 512)
!33 = !DIGlobalVariableExpression(var: !34, expr: !DIExpression())
!34 = distinct !DIGlobalVariable(name: "alpha", scope: !2, file: !11, line: 142, type: !5, isLocal: false, isDefinition: true)
!35 = !DIGlobalVariableExpression(var: !36, expr: !DIExpression())
!36 = distinct !DIGlobalVariable(name: "beta", scope: !2, file: !11, line: 143, type: !5, isLocal: false, isDefinition: true)
!37 = !DIBasicType(name: "int", size: 32, encoding: DW_ATE_signed)
!38 = !{i32 7, !"Dwarf Version", i32 5}
!39 = !{i32 2, !"Debug Info Version", i32 3}
!40 = !{i32 1, !"wchar_size", i32 4}
!41 = !{i32 7, !"PIC Level", i32 2}
!42 = !{i32 7, !"PIE Level", i32 2}
!43 = !{i32 7, !"uwtable", i32 1}
!44 = !{i32 7, !"frame-pointer", i32 2}
!45 = !{!"Ubuntu clang version 14.0.0-1ubuntu1.1"}
!46 = distinct !DISubprogram(name: "task_job_polybench", scope: !11, file: !11, line: 167, type: !47, scopeLine: 167, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !2, retainedNodes: !53)
!47 = !DISubroutineType(types: !48)
!48 = !{!49}
!49 = !DIDerivedType(tag: DW_TAG_typedef, name: "uint32_t", file: !50, line: 26, baseType: !51)
!50 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/stdint-uintn.h", directory: "", checksumkind: CSK_MD5, checksum: "2bf2ae53c58c01b1a1b9383b5195125c")
!51 = !DIDerivedType(tag: DW_TAG_typedef, name: "__uint32_t", file: !52, line: 42, baseType: !6)
!52 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/types.h", directory: "", checksumkind: CSK_MD5, checksum: "d108b5f93a74c50510d7d9bc0ab36df9")
!53 = !{}
!54 = !DILocation(line: 168, column: 18, scope: !46)
!55 = !DILocation(line: 168, column: 21, scope: !46)
!56 = !DILocation(line: 168, column: 28, scope: !46)
!57 = !DILocalVariable(name: "n", arg: 1, scope: !58, file: !11, line: 102, type: !37)
!58 = distinct !DISubprogram(name: "kernel_gemver", scope: !11, file: !11, line: 102, type: !59, scopeLine: 114, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition, unit: !2, retainedNodes: !53)
!59 = !DISubroutineType(types: !60)
!60 = !{null, !37, !5, !5, !61, !62, !62, !62, !62, !62, !62, !62, !62}
!61 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !17, size: 64)
!62 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !5, size: 64)
!63 = !DILocation(line: 0, scope: !58, inlinedAt: !64)
!64 = distinct !DILocation(line: 168, column: 3, scope: !46)
!65 = !DILocalVariable(name: "alpha", arg: 2, scope: !58, file: !11, line: 103, type: !5)
!66 = !DILocalVariable(name: "beta", arg: 3, scope: !58, file: !11, line: 104, type: !5)
!67 = !DILocalVariable(name: "A", arg: 4, scope: !58, file: !11, line: 105, type: !61)
!68 = !DILocalVariable(name: "u1", arg: 5, scope: !58, file: !11, line: 106, type: !62)
!69 = !DILocalVariable(name: "v1", arg: 6, scope: !58, file: !11, line: 107, type: !62)
!70 = !DILocalVariable(name: "u2", arg: 7, scope: !58, file: !11, line: 108, type: !62)
!71 = !DILocalVariable(name: "v2", arg: 8, scope: !58, file: !11, line: 109, type: !62)
!72 = !DILocalVariable(name: "w", arg: 9, scope: !58, file: !11, line: 110, type: !62)
!73 = !DILocalVariable(name: "x", arg: 10, scope: !58, file: !11, line: 111, type: !62)
!74 = !DILocalVariable(name: "y", arg: 11, scope: !58, file: !11, line: 112, type: !62)
!75 = !DILocalVariable(name: "z", arg: 12, scope: !58, file: !11, line: 113, type: !62)
!76 = !DILocalVariable(name: "i", scope: !58, file: !11, line: 115, type: !37)
!77 = !DILocation(line: 119, column: 8, scope: !78, inlinedAt: !64)
!78 = distinct !DILexicalBlock(scope: !58, file: !11, line: 119, column: 3)
!79 = !DILocation(line: 0, scope: !78, inlinedAt: !64)
!80 = !DILocation(line: 119, column: 17, scope: !81, inlinedAt: !64)
!81 = distinct !DILexicalBlock(scope: !78, file: !11, line: 119, column: 3)
!82 = !DILocation(line: 119, column: 3, scope: !78, inlinedAt: !64)
!83 = !DILocalVariable(name: "j", scope: !58, file: !11, line: 115, type: !37)
!84 = !DILocation(line: 120, column: 10, scope: !85, inlinedAt: !64)
!85 = distinct !DILexicalBlock(scope: !81, file: !11, line: 120, column: 5)
!86 = !DILocation(line: 0, scope: !85, inlinedAt: !64)
!87 = !DILocation(line: 120, column: 19, scope: !88, inlinedAt: !64)
!88 = distinct !DILexicalBlock(scope: !85, file: !11, line: 120, column: 5)
!89 = !DILocation(line: 120, column: 5, scope: !85, inlinedAt: !64)
!90 = !DILocation(line: 121, column: 17, scope: !88, inlinedAt: !64)
!91 = !DILocation(line: 121, column: 27, scope: !88, inlinedAt: !64)
!92 = !DILocation(line: 121, column: 35, scope: !88, inlinedAt: !64)
!93 = !DILocation(line: 121, column: 33, scope: !88, inlinedAt: !64)
!94 = !DILocation(line: 121, column: 25, scope: !88, inlinedAt: !64)
!95 = !DILocation(line: 121, column: 43, scope: !88, inlinedAt: !64)
!96 = !DILocation(line: 121, column: 51, scope: !88, inlinedAt: !64)
!97 = !DILocation(line: 121, column: 49, scope: !88, inlinedAt: !64)
!98 = !DILocation(line: 121, column: 41, scope: !88, inlinedAt: !64)
!99 = !DILocation(line: 121, column: 7, scope: !88, inlinedAt: !64)
!100 = !DILocation(line: 121, column: 15, scope: !88, inlinedAt: !64)
!101 = !DILocation(line: 120, column: 29, scope: !88, inlinedAt: !64)
!102 = !DILocation(line: 120, column: 5, scope: !88, inlinedAt: !64)
!103 = distinct !{!103, !89, !104, !105}
!104 = !DILocation(line: 121, column: 55, scope: !85, inlinedAt: !64)
!105 = !{!"llvm.loop.mustprogress"}
!106 = !DILocation(line: 119, column: 27, scope: !81, inlinedAt: !64)
!107 = !DILocation(line: 119, column: 3, scope: !81, inlinedAt: !64)
!108 = distinct !{!108, !82, !109, !105}
!109 = !DILocation(line: 121, column: 55, scope: !78, inlinedAt: !64)
!110 = !DILocation(line: 123, column: 8, scope: !111, inlinedAt: !64)
!111 = distinct !DILexicalBlock(scope: !58, file: !11, line: 123, column: 3)
!112 = !DILocation(line: 0, scope: !111, inlinedAt: !64)
!113 = !DILocation(line: 123, column: 17, scope: !114, inlinedAt: !64)
!114 = distinct !DILexicalBlock(scope: !111, file: !11, line: 123, column: 3)
!115 = !DILocation(line: 123, column: 3, scope: !111, inlinedAt: !64)
!116 = !DILocation(line: 124, column: 10, scope: !117, inlinedAt: !64)
!117 = distinct !DILexicalBlock(scope: !114, file: !11, line: 124, column: 5)
!118 = !DILocation(line: 0, scope: !117, inlinedAt: !64)
!119 = !DILocation(line: 124, column: 19, scope: !120, inlinedAt: !64)
!120 = distinct !DILexicalBlock(scope: !117, file: !11, line: 124, column: 5)
!121 = !DILocation(line: 124, column: 5, scope: !117, inlinedAt: !64)
!122 = !DILocation(line: 125, column: 14, scope: !120, inlinedAt: !64)
!123 = !DILocation(line: 125, column: 28, scope: !120, inlinedAt: !64)
!124 = !DILocation(line: 125, column: 26, scope: !120, inlinedAt: !64)
!125 = !DILocation(line: 125, column: 38, scope: !120, inlinedAt: !64)
!126 = !DILocation(line: 125, column: 36, scope: !120, inlinedAt: !64)
!127 = !DILocation(line: 125, column: 19, scope: !120, inlinedAt: !64)
!128 = !DILocation(line: 125, column: 7, scope: !120, inlinedAt: !64)
!129 = !DILocation(line: 125, column: 12, scope: !120, inlinedAt: !64)
!130 = !DILocation(line: 124, column: 29, scope: !120, inlinedAt: !64)
!131 = !DILocation(line: 124, column: 5, scope: !120, inlinedAt: !64)
!132 = distinct !{!132, !121, !133, !105}
!133 = !DILocation(line: 125, column: 41, scope: !117, inlinedAt: !64)
!134 = !DILocation(line: 123, column: 27, scope: !114, inlinedAt: !64)
!135 = !DILocation(line: 123, column: 3, scope: !114, inlinedAt: !64)
!136 = distinct !{!136, !115, !137, !105}
!137 = !DILocation(line: 125, column: 41, scope: !111, inlinedAt: !64)
!138 = !DILocation(line: 127, column: 8, scope: !139, inlinedAt: !64)
!139 = distinct !DILexicalBlock(scope: !58, file: !11, line: 127, column: 3)
!140 = !DILocation(line: 0, scope: !139, inlinedAt: !64)
!141 = !DILocation(line: 127, column: 17, scope: !142, inlinedAt: !64)
!142 = distinct !DILexicalBlock(scope: !139, file: !11, line: 127, column: 3)
!143 = !DILocation(line: 127, column: 3, scope: !139, inlinedAt: !64)
!144 = !DILocation(line: 128, column: 12, scope: !142, inlinedAt: !64)
!145 = !DILocation(line: 128, column: 19, scope: !142, inlinedAt: !64)
!146 = !DILocation(line: 128, column: 17, scope: !142, inlinedAt: !64)
!147 = !DILocation(line: 128, column: 5, scope: !142, inlinedAt: !64)
!148 = !DILocation(line: 128, column: 10, scope: !142, inlinedAt: !64)
!149 = !DILocation(line: 127, column: 27, scope: !142, inlinedAt: !64)
!150 = !DILocation(line: 127, column: 3, scope: !142, inlinedAt: !64)
!151 = distinct !{!151, !143, !152, !105}
!152 = !DILocation(line: 128, column: 22, scope: !139, inlinedAt: !64)
!153 = !DILocation(line: 130, column: 8, scope: !154, inlinedAt: !64)
!154 = distinct !DILexicalBlock(scope: !58, file: !11, line: 130, column: 3)
!155 = !DILocation(line: 0, scope: !154, inlinedAt: !64)
!156 = !DILocation(line: 130, column: 17, scope: !157, inlinedAt: !64)
!157 = distinct !DILexicalBlock(scope: !154, file: !11, line: 130, column: 3)
!158 = !DILocation(line: 130, column: 3, scope: !154, inlinedAt: !64)
!159 = !DILocation(line: 131, column: 10, scope: !160, inlinedAt: !64)
!160 = distinct !DILexicalBlock(scope: !157, file: !11, line: 131, column: 5)
!161 = !DILocation(line: 0, scope: !160, inlinedAt: !64)
!162 = !DILocation(line: 131, column: 19, scope: !163, inlinedAt: !64)
!163 = distinct !DILexicalBlock(scope: !160, file: !11, line: 131, column: 5)
!164 = !DILocation(line: 131, column: 5, scope: !160, inlinedAt: !64)
!165 = !DILocation(line: 132, column: 14, scope: !163, inlinedAt: !64)
!166 = !DILocation(line: 132, column: 30, scope: !163, inlinedAt: !64)
!167 = !DILocation(line: 132, column: 28, scope: !163, inlinedAt: !64)
!168 = !DILocation(line: 132, column: 40, scope: !163, inlinedAt: !64)
!169 = !DILocation(line: 132, column: 38, scope: !163, inlinedAt: !64)
!170 = !DILocation(line: 132, column: 19, scope: !163, inlinedAt: !64)
!171 = !DILocation(line: 132, column: 7, scope: !163, inlinedAt: !64)
!172 = !DILocation(line: 132, column: 12, scope: !163, inlinedAt: !64)
!173 = !DILocation(line: 131, column: 29, scope: !163, inlinedAt: !64)
!174 = !DILocation(line: 131, column: 5, scope: !163, inlinedAt: !64)
!175 = distinct !{!175, !164, !176, !105}
!176 = !DILocation(line: 132, column: 43, scope: !160, inlinedAt: !64)
!177 = !DILocation(line: 130, column: 27, scope: !157, inlinedAt: !64)
!178 = !DILocation(line: 130, column: 3, scope: !157, inlinedAt: !64)
!179 = distinct !{!179, !158, !180, !105}
!180 = !DILocation(line: 132, column: 43, scope: !154, inlinedAt: !64)
!181 = !DILocation(line: 178, column: 3, scope: !46)
