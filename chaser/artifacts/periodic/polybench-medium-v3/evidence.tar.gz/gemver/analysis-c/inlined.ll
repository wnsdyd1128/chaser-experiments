; ModuleID = 'workload.ll'
source_filename = "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/affine-bounds-20260929/suite/gemver/source/workload.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

%struct._IO_FILE = type { i32, i8*, i8*, i8*, i8*, i8*, i8*, i8*, i8*, i8*, i8*, i8*, %struct._IO_marker*, %struct._IO_FILE*, i32, i32, i64, i16, i8, [1 x i8], i8*, i64, %struct._IO_codecvt*, %struct._IO_wide_data*, %struct._IO_FILE*, i8*, i64, i32, [20 x i8] }
%struct._IO_marker = type opaque
%struct._IO_codecvt = type opaque
%struct._IO_wide_data = type opaque
%struct.__va_list_tag = type { i32, i32, i8*, i8* }

@n = dso_local global i32 400, align 4, !dbg !0
@A = dso_local global [400 x [400 x double]] zeroinitializer, section ".chaser_data.A", align 64, !dbg !30
@u1 = dso_local global [400 x double] zeroinitializer, section ".chaser_data.u1", align 64, !dbg !35
@v1 = dso_local global [400 x double] zeroinitializer, section ".chaser_data.v1", align 64, !dbg !39
@u2 = dso_local global [400 x double] zeroinitializer, section ".chaser_data.u2", align 64, !dbg !41
@v2 = dso_local global [400 x double] zeroinitializer, section ".chaser_data.v2", align 64, !dbg !43
@w = dso_local global [400 x double] zeroinitializer, section ".chaser_data.w", align 64, !dbg !45
@x = dso_local global [400 x double] zeroinitializer, section ".chaser_data.x", align 64, !dbg !47
@y = dso_local global [400 x double] zeroinitializer, section ".chaser_data.y", align 64, !dbg !49
@z = dso_local global [400 x double] zeroinitializer, section ".chaser_data.z", align 64, !dbg !51
@alpha = dso_local global double 0.000000e+00, align 8, !dbg !53
@beta = dso_local global double 0.000000e+00, align 8, !dbg !55
@.str = private unnamed_addr constant [12 x i8] c"ape.analyze\00", section "llvm.metadata"
@.str.1 = private unnamed_addr constant [124 x i8] c"/workspace/experiments-array-support/chaser/.cache/periodic-polybench/affine-bounds-20260929/suite/gemver/source/workload.c\00", section "llvm.metadata"
@pb_hash = internal global i32 0, align 4, !dbg !27
@workload_jobs = dso_local constant [1 x i32 ()*] [i32 ()* @task_job_polybench], align 8, !dbg !9
@workload_expected = dso_local constant [1 x i32] [i32 20361423], align 4, !dbg !23
@stderr = external global %struct._IO_FILE*, align 8
@.str.2 = private unnamed_addr constant [23 x i8] c"==BEGIN DUMP_ARRAYS==\0A\00", align 1
@.str.3 = private unnamed_addr constant [15 x i8] c"begin dump: %s\00", align 1
@.str.4 = private unnamed_addr constant [2 x i8] c"w\00", align 1
@.str.5 = private unnamed_addr constant [2 x i8] c"\0A\00", align 1
@.str.6 = private unnamed_addr constant [8 x i8] c"%0.2lf \00", align 1
@.str.7 = private unnamed_addr constant [17 x i8] c"\0Aend   dump: %s\0A\00", align 1
@.str.8 = private unnamed_addr constant [23 x i8] c"==END   DUMP_ARRAYS==\0A\00", align 1
@pb_emit = internal global i32 1, align 4, !dbg !57
@llvm.global.annotations = appending global [1 x { i8*, i8*, i8*, i32, i8* }] [{ i8*, i8*, i8*, i32, i8* } { i8* bitcast (i32 ()* @task_job_polybench to i8*), i8* getelementptr inbounds ([12 x i8], [12 x i8]* @.str, i32 0, i32 0), i8* getelementptr inbounds ([124 x i8], [124 x i8]* @.str.1, i32 0, i32 0), i32 167, i8* null }], section "llvm.metadata"

; Function Attrs: noinline nounwind uwtable
define dso_local void @workload_prepare() #0 !dbg !68 {
  ret void, !dbg !72
}

; Function Attrs: noinline nounwind uwtable
define dso_local void @workload_reset(i32 noundef %0) #0 !dbg !73 {
  call void @llvm.dbg.value(metadata i32 %0, metadata !76, metadata !DIExpression()), !dbg !77
  call void @llvm.memset.p0i8.i64(i8* align 64 bitcast ([400 x [400 x double]]* @A to i8*), i8 0, i64 1280000, i1 false), !dbg !78
  call void @llvm.memset.p0i8.i64(i8* align 64 bitcast ([400 x double]* @u1 to i8*), i8 0, i64 3200, i1 false), !dbg !79
  call void @llvm.memset.p0i8.i64(i8* align 64 bitcast ([400 x double]* @v1 to i8*), i8 0, i64 3200, i1 false), !dbg !80
  call void @llvm.memset.p0i8.i64(i8* align 64 bitcast ([400 x double]* @u2 to i8*), i8 0, i64 3200, i1 false), !dbg !81
  call void @llvm.memset.p0i8.i64(i8* align 64 bitcast ([400 x double]* @v2 to i8*), i8 0, i64 3200, i1 false), !dbg !82
  call void @llvm.memset.p0i8.i64(i8* align 64 bitcast ([400 x double]* @w to i8*), i8 0, i64 3200, i1 false), !dbg !83
  call void @llvm.memset.p0i8.i64(i8* align 64 bitcast ([400 x double]* @x to i8*), i8 0, i64 3200, i1 false), !dbg !84
  call void @llvm.memset.p0i8.i64(i8* align 64 bitcast ([400 x double]* @y to i8*), i8 0, i64 3200, i1 false), !dbg !85
  call void @llvm.memset.p0i8.i64(i8* align 64 bitcast ([400 x double]* @z to i8*), i8 0, i64 3200, i1 false), !dbg !86
  %2 = load i32, i32* @n, align 4, !dbg !87
  call void @init_array(i32 noundef %2, double* noundef @alpha, double* noundef @beta, [400 x double]* noundef getelementptr inbounds ([400 x [400 x double]], [400 x [400 x double]]* @A, i64 0, i64 0), double* noundef getelementptr inbounds ([400 x double], [400 x double]* @u1, i64 0, i64 0), double* noundef getelementptr inbounds ([400 x double], [400 x double]* @v1, i64 0, i64 0), double* noundef getelementptr inbounds ([400 x double], [400 x double]* @u2, i64 0, i64 0), double* noundef getelementptr inbounds ([400 x double], [400 x double]* @v2, i64 0, i64 0), double* noundef getelementptr inbounds ([400 x double], [400 x double]* @w, i64 0, i64 0), double* noundef getelementptr inbounds ([400 x double], [400 x double]* @x, i64 0, i64 0), double* noundef getelementptr inbounds ([400 x double], [400 x double]* @y, i64 0, i64 0), double* noundef getelementptr inbounds ([400 x double], [400 x double]* @z, i64 0, i64 0)), !dbg !88
  ret void, !dbg !89
}

; Function Attrs: nofree nosync nounwind readnone speculatable willreturn
declare void @llvm.dbg.declare(metadata, metadata, metadata) #1

; Function Attrs: argmemonly nofree nounwind willreturn writeonly
declare void @llvm.memset.p0i8.i64(i8* nocapture writeonly, i8, i64, i1 immarg) #2

; Function Attrs: noinline nounwind uwtable
define internal void @init_array(i32 noundef %0, double* noundef %1, double* noundef %2, [400 x double]* noundef %3, double* noundef %4, double* noundef %5, double* noundef %6, double* noundef %7, double* noundef %8, double* noundef %9, double* noundef %10, double* noundef %11) #0 !dbg !90 {
  call void @llvm.dbg.value(metadata i32 %0, metadata !95, metadata !DIExpression()), !dbg !96
  call void @llvm.dbg.value(metadata double* %1, metadata !97, metadata !DIExpression()), !dbg !96
  call void @llvm.dbg.value(metadata double* %2, metadata !98, metadata !DIExpression()), !dbg !96
  call void @llvm.dbg.value(metadata [400 x double]* %3, metadata !99, metadata !DIExpression()), !dbg !96
  call void @llvm.dbg.value(metadata double* %4, metadata !100, metadata !DIExpression()), !dbg !96
  call void @llvm.dbg.value(metadata double* %5, metadata !101, metadata !DIExpression()), !dbg !96
  call void @llvm.dbg.value(metadata double* %6, metadata !102, metadata !DIExpression()), !dbg !96
  call void @llvm.dbg.value(metadata double* %7, metadata !103, metadata !DIExpression()), !dbg !96
  call void @llvm.dbg.value(metadata double* %8, metadata !104, metadata !DIExpression()), !dbg !96
  call void @llvm.dbg.value(metadata double* %9, metadata !105, metadata !DIExpression()), !dbg !96
  call void @llvm.dbg.value(metadata double* %10, metadata !106, metadata !DIExpression()), !dbg !96
  call void @llvm.dbg.value(metadata double* %11, metadata !107, metadata !DIExpression()), !dbg !96
  store double 1.500000e+00, double* %1, align 8, !dbg !108
  store double 1.200000e+00, double* %2, align 8, !dbg !109
  %13 = sitofp i32 %0 to double, !dbg !110
  call void @llvm.dbg.value(metadata double %13, metadata !111, metadata !DIExpression()), !dbg !96
  call void @llvm.dbg.value(metadata i32 0, metadata !112, metadata !DIExpression()), !dbg !96
  br label %14, !dbg !113

14:                                               ; preds = %69, %12
  %.01 = phi i32 [ 0, %12 ], [ %70, %69 ], !dbg !115
  call void @llvm.dbg.value(metadata i32 %.01, metadata !112, metadata !DIExpression()), !dbg !96
  %15 = icmp slt i32 %.01, %0, !dbg !116
  br i1 %15, label %16, label %71, !dbg !118

16:                                               ; preds = %14
  %17 = sitofp i32 %.01 to double, !dbg !119
  %18 = sext i32 %.01 to i64, !dbg !121
  %19 = getelementptr inbounds double, double* %4, i64 %18, !dbg !121
  store double %17, double* %19, align 8, !dbg !122
  %20 = add nsw i32 %.01, 1, !dbg !123
  %21 = sitofp i32 %20 to double, !dbg !124
  %22 = fdiv double %21, %13, !dbg !125
  %23 = fdiv double %22, 2.000000e+00, !dbg !126
  %24 = sext i32 %.01 to i64, !dbg !127
  %25 = getelementptr inbounds double, double* %6, i64 %24, !dbg !127
  store double %23, double* %25, align 8, !dbg !128
  %26 = add nsw i32 %.01, 1, !dbg !129
  %27 = sitofp i32 %26 to double, !dbg !130
  %28 = fdiv double %27, %13, !dbg !131
  %29 = fdiv double %28, 4.000000e+00, !dbg !132
  %30 = sext i32 %.01 to i64, !dbg !133
  %31 = getelementptr inbounds double, double* %5, i64 %30, !dbg !133
  store double %29, double* %31, align 8, !dbg !134
  %32 = add nsw i32 %.01, 1, !dbg !135
  %33 = sitofp i32 %32 to double, !dbg !136
  %34 = fdiv double %33, %13, !dbg !137
  %35 = fdiv double %34, 6.000000e+00, !dbg !138
  %36 = sext i32 %.01 to i64, !dbg !139
  %37 = getelementptr inbounds double, double* %7, i64 %36, !dbg !139
  store double %35, double* %37, align 8, !dbg !140
  %38 = add nsw i32 %.01, 1, !dbg !141
  %39 = sitofp i32 %38 to double, !dbg !142
  %40 = fdiv double %39, %13, !dbg !143
  %41 = fdiv double %40, 8.000000e+00, !dbg !144
  %42 = sext i32 %.01 to i64, !dbg !145
  %43 = getelementptr inbounds double, double* %10, i64 %42, !dbg !145
  store double %41, double* %43, align 8, !dbg !146
  %44 = add nsw i32 %.01, 1, !dbg !147
  %45 = sitofp i32 %44 to double, !dbg !148
  %46 = fdiv double %45, %13, !dbg !149
  %47 = fdiv double %46, 9.000000e+00, !dbg !150
  %48 = sext i32 %.01 to i64, !dbg !151
  %49 = getelementptr inbounds double, double* %11, i64 %48, !dbg !151
  store double %47, double* %49, align 8, !dbg !152
  %50 = sext i32 %.01 to i64, !dbg !153
  %51 = getelementptr inbounds double, double* %9, i64 %50, !dbg !153
  store double 0.000000e+00, double* %51, align 8, !dbg !154
  %52 = sext i32 %.01 to i64, !dbg !155
  %53 = getelementptr inbounds double, double* %8, i64 %52, !dbg !155
  store double 0.000000e+00, double* %53, align 8, !dbg !156
  call void @llvm.dbg.value(metadata i32 0, metadata !157, metadata !DIExpression()), !dbg !96
  br label %54, !dbg !158

54:                                               ; preds = %66, %16
  %.0 = phi i32 [ 0, %16 ], [ %67, %66 ], !dbg !160
  call void @llvm.dbg.value(metadata i32 %.0, metadata !157, metadata !DIExpression()), !dbg !96
  %55 = icmp slt i32 %.0, %0, !dbg !161
  br i1 %55, label %56, label %68, !dbg !163

56:                                               ; preds = %54
  %57 = mul nsw i32 %.01, %.0, !dbg !164
  %58 = srem i32 %57, %0, !dbg !165
  %59 = sitofp i32 %58 to double, !dbg !166
  %60 = sitofp i32 %0 to double, !dbg !167
  %61 = fdiv double %59, %60, !dbg !168
  %62 = sext i32 %.01 to i64, !dbg !169
  %63 = getelementptr inbounds [400 x double], [400 x double]* %3, i64 %62, !dbg !169
  %64 = sext i32 %.0 to i64, !dbg !169
  %65 = getelementptr inbounds [400 x double], [400 x double]* %63, i64 0, i64 %64, !dbg !169
  store double %61, double* %65, align 8, !dbg !170
  br label %66, !dbg !169

66:                                               ; preds = %56
  %67 = add nsw i32 %.0, 1, !dbg !171
  call void @llvm.dbg.value(metadata i32 %67, metadata !157, metadata !DIExpression()), !dbg !96
  br label %54, !dbg !172, !llvm.loop !173

68:                                               ; preds = %54
  br label %69, !dbg !176

69:                                               ; preds = %68
  %70 = add nsw i32 %.01, 1, !dbg !177
  call void @llvm.dbg.value(metadata i32 %70, metadata !112, metadata !DIExpression()), !dbg !96
  br label %14, !dbg !178, !llvm.loop !179

71:                                               ; preds = %14
  ret void, !dbg !181
}

; Function Attrs: noinline nounwind uwtable
define dso_local i32 @task_job_polybench() #0 !dbg !182 {
  %1 = load i32, i32* @n, align 4, !dbg !183
  %2 = load double, double* @alpha, align 8, !dbg !184
  %3 = load double, double* @beta, align 8, !dbg !185
  call void @llvm.dbg.value(metadata i32 %1, metadata !186, metadata !DIExpression()), !dbg !190
  call void @llvm.dbg.value(metadata double %2, metadata !192, metadata !DIExpression()), !dbg !190
  call void @llvm.dbg.value(metadata double %3, metadata !193, metadata !DIExpression()), !dbg !190
  call void @llvm.dbg.value(metadata [400 x double]* getelementptr inbounds ([400 x [400 x double]], [400 x [400 x double]]* @A, i64 0, i64 0), metadata !194, metadata !DIExpression()), !dbg !190
  call void @llvm.dbg.value(metadata double* getelementptr inbounds ([400 x double], [400 x double]* @u1, i64 0, i64 0), metadata !195, metadata !DIExpression()), !dbg !190
  call void @llvm.dbg.value(metadata double* getelementptr inbounds ([400 x double], [400 x double]* @v1, i64 0, i64 0), metadata !196, metadata !DIExpression()), !dbg !190
  call void @llvm.dbg.value(metadata double* getelementptr inbounds ([400 x double], [400 x double]* @u2, i64 0, i64 0), metadata !197, metadata !DIExpression()), !dbg !190
  call void @llvm.dbg.value(metadata double* getelementptr inbounds ([400 x double], [400 x double]* @v2, i64 0, i64 0), metadata !198, metadata !DIExpression()), !dbg !190
  call void @llvm.dbg.value(metadata double* getelementptr inbounds ([400 x double], [400 x double]* @w, i64 0, i64 0), metadata !199, metadata !DIExpression()), !dbg !190
  call void @llvm.dbg.value(metadata double* getelementptr inbounds ([400 x double], [400 x double]* @x, i64 0, i64 0), metadata !200, metadata !DIExpression()), !dbg !190
  call void @llvm.dbg.value(metadata double* getelementptr inbounds ([400 x double], [400 x double]* @y, i64 0, i64 0), metadata !201, metadata !DIExpression()), !dbg !190
  call void @llvm.dbg.value(metadata double* getelementptr inbounds ([400 x double], [400 x double]* @z, i64 0, i64 0), metadata !202, metadata !DIExpression()), !dbg !190
  call void @llvm.dbg.value(metadata i32 0, metadata !203, metadata !DIExpression()), !dbg !190
  br label %4, !dbg !204

4:                                                ; preds = %36, %0
  %.01 = phi i32 [ 0, %0 ], [ %37, %36 ], !dbg !206
  call void @llvm.dbg.value(metadata i32 %.01, metadata !203, metadata !DIExpression()), !dbg !190
  %5 = icmp slt i32 %.01, 400, !dbg !207
  br i1 %5, label %6, label %38, !dbg !209

6:                                                ; preds = %4
  call void @llvm.dbg.value(metadata i32 0, metadata !210, metadata !DIExpression()), !dbg !190
  br label %7, !dbg !211

7:                                                ; preds = %9, %6
  %.0 = phi i32 [ 0, %6 ], [ %35, %9 ], !dbg !213
  call void @llvm.dbg.value(metadata i32 %.0, metadata !210, metadata !DIExpression()), !dbg !190
  %8 = icmp slt i32 %.0, 400, !dbg !214
  br i1 %8, label %9, label %36, !dbg !216

9:                                                ; preds = %7
  %10 = sext i32 %.01 to i64, !dbg !217
  %11 = getelementptr inbounds [400 x double], [400 x double]* getelementptr inbounds ([400 x [400 x double]], [400 x [400 x double]]* @A, i64 0, i64 0), i64 %10, !dbg !217
  %12 = sext i32 %.0 to i64, !dbg !217
  %13 = getelementptr inbounds [400 x double], [400 x double]* %11, i64 0, i64 %12, !dbg !217
  %14 = load double, double* %13, align 8, !dbg !217
  %15 = sext i32 %.01 to i64, !dbg !218
  %16 = getelementptr inbounds double, double* getelementptr inbounds ([400 x double], [400 x double]* @u1, i64 0, i64 0), i64 %15, !dbg !218
  %17 = load double, double* %16, align 8, !dbg !218
  %18 = sext i32 %.0 to i64, !dbg !219
  %19 = getelementptr inbounds double, double* getelementptr inbounds ([400 x double], [400 x double]* @v1, i64 0, i64 0), i64 %18, !dbg !219
  %20 = load double, double* %19, align 8, !dbg !219
  %21 = fmul double %17, %20, !dbg !220
  %22 = fadd double %14, %21, !dbg !221
  %23 = sext i32 %.01 to i64, !dbg !222
  %24 = getelementptr inbounds double, double* getelementptr inbounds ([400 x double], [400 x double]* @u2, i64 0, i64 0), i64 %23, !dbg !222
  %25 = load double, double* %24, align 8, !dbg !222
  %26 = sext i32 %.0 to i64, !dbg !223
  %27 = getelementptr inbounds double, double* getelementptr inbounds ([400 x double], [400 x double]* @v2, i64 0, i64 0), i64 %26, !dbg !223
  %28 = load double, double* %27, align 8, !dbg !223
  %29 = fmul double %25, %28, !dbg !224
  %30 = fadd double %22, %29, !dbg !225
  %31 = sext i32 %.01 to i64, !dbg !226
  %32 = getelementptr inbounds [400 x double], [400 x double]* getelementptr inbounds ([400 x [400 x double]], [400 x [400 x double]]* @A, i64 0, i64 0), i64 %31, !dbg !226
  %33 = sext i32 %.0 to i64, !dbg !226
  %34 = getelementptr inbounds [400 x double], [400 x double]* %32, i64 0, i64 %33, !dbg !226
  store double %30, double* %34, align 8, !dbg !227
  %35 = add nsw i32 %.0, 1, !dbg !228
  call void @llvm.dbg.value(metadata i32 %35, metadata !210, metadata !DIExpression()), !dbg !190
  br label %7, !dbg !229, !llvm.loop !230

36:                                               ; preds = %7
  %37 = add nsw i32 %.01, 1, !dbg !232
  call void @llvm.dbg.value(metadata i32 %37, metadata !203, metadata !DIExpression()), !dbg !190
  br label %4, !dbg !233, !llvm.loop !234

38:                                               ; preds = %4
  call void @llvm.dbg.value(metadata i32 0, metadata !203, metadata !DIExpression()), !dbg !190
  br label %39, !dbg !236

39:                                               ; preds = %62, %38
  %.12 = phi i32 [ 0, %38 ], [ %63, %62 ], !dbg !238
  call void @llvm.dbg.value(metadata i32 %.12, metadata !203, metadata !DIExpression()), !dbg !190
  %40 = icmp slt i32 %.12, 400, !dbg !239
  br i1 %40, label %41, label %64, !dbg !241

41:                                               ; preds = %39
  call void @llvm.dbg.value(metadata i32 0, metadata !210, metadata !DIExpression()), !dbg !190
  br label %42, !dbg !242

42:                                               ; preds = %44, %41
  %.1 = phi i32 [ 0, %41 ], [ %61, %44 ], !dbg !244
  call void @llvm.dbg.value(metadata i32 %.1, metadata !210, metadata !DIExpression()), !dbg !190
  %43 = icmp slt i32 %.1, 400, !dbg !245
  br i1 %43, label %44, label %62, !dbg !247

44:                                               ; preds = %42
  %45 = sext i32 %.12 to i64, !dbg !248
  %46 = getelementptr inbounds double, double* getelementptr inbounds ([400 x double], [400 x double]* @x, i64 0, i64 0), i64 %45, !dbg !248
  %47 = load double, double* %46, align 8, !dbg !248
  %48 = sext i32 %.1 to i64, !dbg !249
  %49 = getelementptr inbounds [400 x double], [400 x double]* getelementptr inbounds ([400 x [400 x double]], [400 x [400 x double]]* @A, i64 0, i64 0), i64 %48, !dbg !249
  %50 = sext i32 %.12 to i64, !dbg !249
  %51 = getelementptr inbounds [400 x double], [400 x double]* %49, i64 0, i64 %50, !dbg !249
  %52 = load double, double* %51, align 8, !dbg !249
  %53 = fmul double %3, %52, !dbg !250
  %54 = sext i32 %.1 to i64, !dbg !251
  %55 = getelementptr inbounds double, double* getelementptr inbounds ([400 x double], [400 x double]* @y, i64 0, i64 0), i64 %54, !dbg !251
  %56 = load double, double* %55, align 8, !dbg !251
  %57 = fmul double %53, %56, !dbg !252
  %58 = fadd double %47, %57, !dbg !253
  %59 = sext i32 %.12 to i64, !dbg !254
  %60 = getelementptr inbounds double, double* getelementptr inbounds ([400 x double], [400 x double]* @x, i64 0, i64 0), i64 %59, !dbg !254
  store double %58, double* %60, align 8, !dbg !255
  %61 = add nsw i32 %.1, 1, !dbg !256
  call void @llvm.dbg.value(metadata i32 %61, metadata !210, metadata !DIExpression()), !dbg !190
  br label %42, !dbg !257, !llvm.loop !258

62:                                               ; preds = %42
  %63 = add nsw i32 %.12, 1, !dbg !260
  call void @llvm.dbg.value(metadata i32 %63, metadata !203, metadata !DIExpression()), !dbg !190
  br label %39, !dbg !261, !llvm.loop !262

64:                                               ; preds = %39
  call void @llvm.dbg.value(metadata i32 0, metadata !203, metadata !DIExpression()), !dbg !190
  br label %65, !dbg !264

65:                                               ; preds = %67, %64
  %.23 = phi i32 [ 0, %64 ], [ %77, %67 ], !dbg !266
  call void @llvm.dbg.value(metadata i32 %.23, metadata !203, metadata !DIExpression()), !dbg !190
  %66 = icmp slt i32 %.23, 400, !dbg !267
  br i1 %66, label %67, label %78, !dbg !269

67:                                               ; preds = %65
  %68 = sext i32 %.23 to i64, !dbg !270
  %69 = getelementptr inbounds double, double* getelementptr inbounds ([400 x double], [400 x double]* @x, i64 0, i64 0), i64 %68, !dbg !270
  %70 = load double, double* %69, align 8, !dbg !270
  %71 = sext i32 %.23 to i64, !dbg !271
  %72 = getelementptr inbounds double, double* getelementptr inbounds ([400 x double], [400 x double]* @z, i64 0, i64 0), i64 %71, !dbg !271
  %73 = load double, double* %72, align 8, !dbg !271
  %74 = fadd double %70, %73, !dbg !272
  %75 = sext i32 %.23 to i64, !dbg !273
  %76 = getelementptr inbounds double, double* getelementptr inbounds ([400 x double], [400 x double]* @x, i64 0, i64 0), i64 %75, !dbg !273
  store double %74, double* %76, align 8, !dbg !274
  %77 = add nsw i32 %.23, 1, !dbg !275
  call void @llvm.dbg.value(metadata i32 %77, metadata !203, metadata !DIExpression()), !dbg !190
  br label %65, !dbg !276, !llvm.loop !277

78:                                               ; preds = %65
  call void @llvm.dbg.value(metadata i32 0, metadata !203, metadata !DIExpression()), !dbg !190
  br label %79, !dbg !279

79:                                               ; preds = %102, %78
  %.3 = phi i32 [ 0, %78 ], [ %103, %102 ], !dbg !281
  call void @llvm.dbg.value(metadata i32 %.3, metadata !203, metadata !DIExpression()), !dbg !190
  %80 = icmp slt i32 %.3, 400, !dbg !282
  br i1 %80, label %81, label %104, !dbg !284

81:                                               ; preds = %79
  call void @llvm.dbg.value(metadata i32 0, metadata !210, metadata !DIExpression()), !dbg !190
  br label %82, !dbg !285

82:                                               ; preds = %84, %81
  %.2 = phi i32 [ 0, %81 ], [ %101, %84 ], !dbg !287
  call void @llvm.dbg.value(metadata i32 %.2, metadata !210, metadata !DIExpression()), !dbg !190
  %83 = icmp slt i32 %.2, 400, !dbg !288
  br i1 %83, label %84, label %102, !dbg !290

84:                                               ; preds = %82
  %85 = sext i32 %.3 to i64, !dbg !291
  %86 = getelementptr inbounds double, double* getelementptr inbounds ([400 x double], [400 x double]* @w, i64 0, i64 0), i64 %85, !dbg !291
  %87 = load double, double* %86, align 8, !dbg !291
  %88 = sext i32 %.3 to i64, !dbg !292
  %89 = getelementptr inbounds [400 x double], [400 x double]* getelementptr inbounds ([400 x [400 x double]], [400 x [400 x double]]* @A, i64 0, i64 0), i64 %88, !dbg !292
  %90 = sext i32 %.2 to i64, !dbg !292
  %91 = getelementptr inbounds [400 x double], [400 x double]* %89, i64 0, i64 %90, !dbg !292
  %92 = load double, double* %91, align 8, !dbg !292
  %93 = fmul double %2, %92, !dbg !293
  %94 = sext i32 %.2 to i64, !dbg !294
  %95 = getelementptr inbounds double, double* getelementptr inbounds ([400 x double], [400 x double]* @x, i64 0, i64 0), i64 %94, !dbg !294
  %96 = load double, double* %95, align 8, !dbg !294
  %97 = fmul double %93, %96, !dbg !295
  %98 = fadd double %87, %97, !dbg !296
  %99 = sext i32 %.3 to i64, !dbg !297
  %100 = getelementptr inbounds double, double* getelementptr inbounds ([400 x double], [400 x double]* @w, i64 0, i64 0), i64 %99, !dbg !297
  store double %98, double* %100, align 8, !dbg !298
  %101 = add nsw i32 %.2, 1, !dbg !299
  call void @llvm.dbg.value(metadata i32 %101, metadata !210, metadata !DIExpression()), !dbg !190
  br label %82, !dbg !300, !llvm.loop !301

102:                                              ; preds = %82
  %103 = add nsw i32 %.3, 1, !dbg !303
  call void @llvm.dbg.value(metadata i32 %103, metadata !203, metadata !DIExpression()), !dbg !190
  br label %79, !dbg !304, !llvm.loop !305

104:                                              ; preds = %79
  ret i32 0, !dbg !307
}

; Function Attrs: noinline nounwind uwtable
define dso_local i32 @workload_checksum(i32 noundef %0) #0 !dbg !308 {
  call void @llvm.dbg.value(metadata i32 %0, metadata !311, metadata !DIExpression()), !dbg !312
  store i32 -2128831035, i32* @pb_hash, align 4, !dbg !313
  %2 = load i32, i32* @n, align 4, !dbg !314
  call void @print_array(i32 noundef %2, double* noundef getelementptr inbounds ([400 x double], [400 x double]* @w, i64 0, i64 0)), !dbg !315
  %3 = load i32, i32* @pb_hash, align 4, !dbg !316
  ret i32 %3, !dbg !317
}

; Function Attrs: noinline nounwind uwtable
define internal void @print_array(i32 noundef %0, double* noundef %1) #0 !dbg !318 {
  call void @llvm.dbg.value(metadata i32 %0, metadata !321, metadata !DIExpression()), !dbg !322
  call void @llvm.dbg.value(metadata double* %1, metadata !323, metadata !DIExpression()), !dbg !322
  %3 = load %struct._IO_FILE*, %struct._IO_FILE** @stderr, align 8, !dbg !324
  %4 = call i32 (%struct._IO_FILE*, i8*, ...) @pb_fprintf(%struct._IO_FILE* noundef %3, i8* noundef getelementptr inbounds ([23 x i8], [23 x i8]* @.str.2, i64 0, i64 0)), !dbg !324
  %5 = load %struct._IO_FILE*, %struct._IO_FILE** @stderr, align 8, !dbg !325
  %6 = call i32 (%struct._IO_FILE*, i8*, ...) @pb_fprintf(%struct._IO_FILE* noundef %5, i8* noundef getelementptr inbounds ([15 x i8], [15 x i8]* @.str.3, i64 0, i64 0), i8* noundef getelementptr inbounds ([2 x i8], [2 x i8]* @.str.4, i64 0, i64 0)), !dbg !325
  call void @llvm.dbg.value(metadata i32 0, metadata !326, metadata !DIExpression()), !dbg !322
  br label %7, !dbg !327

7:                                                ; preds = %21, %2
  %.0 = phi i32 [ 0, %2 ], [ %22, %21 ], !dbg !329
  call void @llvm.dbg.value(metadata i32 %.0, metadata !326, metadata !DIExpression()), !dbg !322
  %8 = icmp slt i32 %.0, %0, !dbg !330
  br i1 %8, label %9, label %23, !dbg !332

9:                                                ; preds = %7
  %10 = srem i32 %.0, 20, !dbg !333
  %11 = icmp eq i32 %10, 0, !dbg !336
  br i1 %11, label %12, label %15, !dbg !337

12:                                               ; preds = %9
  %13 = load %struct._IO_FILE*, %struct._IO_FILE** @stderr, align 8, !dbg !338
  %14 = call i32 (%struct._IO_FILE*, i8*, ...) @pb_fprintf(%struct._IO_FILE* noundef %13, i8* noundef getelementptr inbounds ([2 x i8], [2 x i8]* @.str.5, i64 0, i64 0)), !dbg !339
  br label %15, !dbg !339

15:                                               ; preds = %12, %9
  %16 = load %struct._IO_FILE*, %struct._IO_FILE** @stderr, align 8, !dbg !340
  %17 = sext i32 %.0 to i64, !dbg !341
  %18 = getelementptr inbounds double, double* %1, i64 %17, !dbg !341
  %19 = load double, double* %18, align 8, !dbg !341
  %20 = call i32 (%struct._IO_FILE*, i8*, ...) @pb_fprintf(%struct._IO_FILE* noundef %16, i8* noundef getelementptr inbounds ([8 x i8], [8 x i8]* @.str.6, i64 0, i64 0), double noundef %19), !dbg !342
  br label %21, !dbg !343

21:                                               ; preds = %15
  %22 = add nsw i32 %.0, 1, !dbg !344
  call void @llvm.dbg.value(metadata i32 %22, metadata !326, metadata !DIExpression()), !dbg !322
  br label %7, !dbg !345, !llvm.loop !346

23:                                               ; preds = %7
  %24 = load %struct._IO_FILE*, %struct._IO_FILE** @stderr, align 8, !dbg !348
  %25 = call i32 (%struct._IO_FILE*, i8*, ...) @pb_fprintf(%struct._IO_FILE* noundef %24, i8* noundef getelementptr inbounds ([17 x i8], [17 x i8]* @.str.7, i64 0, i64 0), i8* noundef getelementptr inbounds ([2 x i8], [2 x i8]* @.str.4, i64 0, i64 0)), !dbg !348
  %26 = load %struct._IO_FILE*, %struct._IO_FILE** @stderr, align 8, !dbg !349
  %27 = call i32 (%struct._IO_FILE*, i8*, ...) @pb_fprintf(%struct._IO_FILE* noundef %26, i8* noundef getelementptr inbounds ([23 x i8], [23 x i8]* @.str.8, i64 0, i64 0)), !dbg !349
  ret void, !dbg !350
}

; Function Attrs: noinline nounwind uwtable
define internal i32 @pb_fprintf(%struct._IO_FILE* noundef %0, i8* noundef %1, ...) #0 !dbg !351 {
  %3 = alloca [768 x i8], align 16
  %4 = alloca [1 x %struct.__va_list_tag], align 16
  call void @llvm.dbg.value(metadata %struct._IO_FILE* %0, metadata !415, metadata !DIExpression()), !dbg !416
  call void @llvm.dbg.value(metadata i8* %1, metadata !417, metadata !DIExpression()), !dbg !416
  call void @llvm.dbg.declare(metadata [768 x i8]* %3, metadata !418, metadata !DIExpression()), !dbg !422
  call void @llvm.dbg.declare(metadata [1 x %struct.__va_list_tag]* %4, metadata !423, metadata !DIExpression()), !dbg !437
  %5 = getelementptr inbounds [1 x %struct.__va_list_tag], [1 x %struct.__va_list_tag]* %4, i64 0, i64 0, !dbg !438
  %6 = bitcast %struct.__va_list_tag* %5 to i8*, !dbg !438
  call void @llvm.va_start(i8* %6), !dbg !438
  %7 = getelementptr inbounds [768 x i8], [768 x i8]* %3, i64 0, i64 0, !dbg !439
  %8 = getelementptr inbounds [1 x %struct.__va_list_tag], [1 x %struct.__va_list_tag]* %4, i64 0, i64 0, !dbg !440
  %9 = call i32 @vsnprintf(i8* noundef %7, i64 noundef 768, i8* noundef %1, %struct.__va_list_tag* noundef %8) #6, !dbg !441
  call void @llvm.dbg.value(metadata i32 %9, metadata !442, metadata !DIExpression()), !dbg !416
  %10 = getelementptr inbounds [1 x %struct.__va_list_tag], [1 x %struct.__va_list_tag]* %4, i64 0, i64 0, !dbg !443
  %11 = bitcast %struct.__va_list_tag* %10 to i8*, !dbg !443
  call void @llvm.va_end(i8* %11), !dbg !443
  %12 = icmp slt i32 %9, 0, !dbg !444
  br i1 %12, label %16, label %13, !dbg !446

13:                                               ; preds = %2
  %14 = zext i32 %9 to i64, !dbg !447
  %15 = icmp uge i64 %14, 768, !dbg !448
  br i1 %15, label %16, label %17, !dbg !449

16:                                               ; preds = %13, %2
  call void @abort() #7, !dbg !450
  unreachable, !dbg !450

17:                                               ; preds = %13
  call void @llvm.dbg.value(metadata i32 0, metadata !451, metadata !DIExpression()), !dbg !453
  br label %18, !dbg !454

18:                                               ; preds = %29, %17
  %.0 = phi i32 [ 0, %17 ], [ %30, %29 ], !dbg !453
  call void @llvm.dbg.value(metadata i32 %.0, metadata !451, metadata !DIExpression()), !dbg !453
  %19 = icmp slt i32 %.0, %9, !dbg !455
  br i1 %19, label %20, label %31, !dbg !457

20:                                               ; preds = %18
  %21 = sext i32 %.0 to i64, !dbg !458
  %22 = getelementptr inbounds [768 x i8], [768 x i8]* %3, i64 0, i64 %21, !dbg !458
  %23 = load i8, i8* %22, align 1, !dbg !458
  %24 = zext i8 %23 to i32, !dbg !460
  %25 = load i32, i32* @pb_hash, align 4, !dbg !461
  %26 = xor i32 %25, %24, !dbg !461
  store i32 %26, i32* @pb_hash, align 4, !dbg !461
  %27 = load i32, i32* @pb_hash, align 4, !dbg !462
  %28 = mul i32 %27, 16777619, !dbg !462
  store i32 %28, i32* @pb_hash, align 4, !dbg !462
  br label %29, !dbg !463

29:                                               ; preds = %20
  %30 = add nsw i32 %.0, 1, !dbg !464
  call void @llvm.dbg.value(metadata i32 %30, metadata !451, metadata !DIExpression()), !dbg !453
  br label %18, !dbg !465, !llvm.loop !466

31:                                               ; preds = %18
  %32 = load i32, i32* @pb_emit, align 4, !dbg !468
  ret i32 %9, !dbg !469
}

; Function Attrs: nofree nosync nounwind willreturn
declare void @llvm.va_start(i8*) #3

; Function Attrs: nounwind
declare i32 @vsnprintf(i8* noundef, i64 noundef, i8* noundef, %struct.__va_list_tag* noundef) #4

; Function Attrs: nofree nosync nounwind willreturn
declare void @llvm.va_end(i8*) #3

; Function Attrs: noreturn nounwind
declare void @abort() #5

; Function Attrs: nofree nosync nounwind readnone speculatable willreturn
declare void @llvm.dbg.value(metadata, metadata, metadata) #1

attributes #0 = { noinline nounwind uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { nofree nosync nounwind readnone speculatable willreturn }
attributes #2 = { argmemonly nofree nounwind willreturn writeonly }
attributes #3 = { nofree nosync nounwind willreturn }
attributes #4 = { nounwind "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #5 = { noreturn nounwind "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #6 = { nounwind }
attributes #7 = { noreturn nounwind }

!llvm.dbg.cu = !{!2}
!llvm.module.flags = !{!60, !61, !62, !63, !64, !65, !66}
!llvm.ident = !{!67}

!0 = !DIGlobalVariableExpression(var: !1, expr: !DIExpression())
!1 = distinct !DIGlobalVariable(name: "n", scope: !2, file: !11, line: 139, type: !59, isLocal: false, isDefinition: true)
!2 = distinct !DICompileUnit(language: DW_LANG_C99, file: !3, producer: "Ubuntu clang version 14.0.0-1ubuntu1.1", isOptimized: false, runtimeVersion: 0, emissionKind: FullDebug, retainedTypes: !4, globals: !8, splitDebugInlining: false, nameTableKind: None)
!3 = !DIFile(filename: "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/affine-bounds-20260929/suite/gemver/source/workload.c", directory: "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/affine-bounds-20260929/suite/gemver/analysis-c", checksumkind: CSK_MD5, checksum: "bbe83b0f1a92e4629170a4942716c66e")
!4 = !{!5, !6, !7}
!5 = !DIBasicType(name: "double", size: 64, encoding: DW_ATE_float)
!6 = !DIBasicType(name: "unsigned int", size: 32, encoding: DW_ATE_unsigned)
!7 = !DIBasicType(name: "unsigned char", size: 8, encoding: DW_ATE_unsigned_char)
!8 = !{!0, !9, !23, !27, !30, !35, !39, !41, !43, !45, !47, !49, !51, !53, !55, !57}
!9 = !DIGlobalVariableExpression(var: !10, expr: !DIExpression())
!10 = distinct !DIGlobalVariable(name: "workload_jobs", scope: !2, file: !11, line: 186, type: !12, isLocal: false, isDefinition: true)
!11 = !DIFile(filename: "source/workload.c", directory: "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/affine-bounds-20260929/suite/gemver", checksumkind: CSK_MD5, checksum: "bbe83b0f1a92e4629170a4942716c66e")
!12 = !DICompositeType(tag: DW_TAG_array_type, baseType: !13, size: 64, elements: !21)
!13 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !14)
!14 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !15, size: 64)
!15 = !DISubroutineType(types: !16)
!16 = !{!17}
!17 = !DIDerivedType(tag: DW_TAG_typedef, name: "uint32_t", file: !18, line: 26, baseType: !19)
!18 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/stdint-uintn.h", directory: "", checksumkind: CSK_MD5, checksum: "2bf2ae53c58c01b1a1b9383b5195125c")
!19 = !DIDerivedType(tag: DW_TAG_typedef, name: "__uint32_t", file: !20, line: 42, baseType: !6)
!20 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/types.h", directory: "", checksumkind: CSK_MD5, checksum: "d108b5f93a74c50510d7d9bc0ab36df9")
!21 = !{!22}
!22 = !DISubrange(count: 1)
!23 = !DIGlobalVariableExpression(var: !24, expr: !DIExpression())
!24 = distinct !DIGlobalVariable(name: "workload_expected", scope: !2, file: !11, line: 190, type: !25, isLocal: false, isDefinition: true)
!25 = !DICompositeType(tag: DW_TAG_array_type, baseType: !26, size: 32, elements: !21)
!26 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !17)
!27 = !DIGlobalVariableExpression(var: !28, expr: !DIExpression())
!28 = distinct !DIGlobalVariable(name: "pb_hash", scope: !2, file: !29, line: 9, type: !17, isLocal: true, isDefinition: true)
!29 = !DIFile(filename: "source/adapter.h", directory: "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/affine-bounds-20260929/suite/gemver", checksumkind: CSK_MD5, checksum: "26a6068928b2092758f244a9d00163d7")
!30 = !DIGlobalVariableExpression(var: !31, expr: !DIExpression())
!31 = distinct !DIGlobalVariable(name: "A", scope: !2, file: !11, line: 34, type: !32, isLocal: false, isDefinition: true, align: 512)
!32 = !DICompositeType(tag: DW_TAG_array_type, baseType: !5, size: 10240000, elements: !33)
!33 = !{!34, !34}
!34 = !DISubrange(count: 400)
!35 = !DIGlobalVariableExpression(var: !36, expr: !DIExpression())
!36 = distinct !DIGlobalVariable(name: "u1", scope: !2, file: !11, line: 35, type: !37, isLocal: false, isDefinition: true, align: 512)
!37 = !DICompositeType(tag: DW_TAG_array_type, baseType: !5, size: 25600, elements: !38)
!38 = !{!34}
!39 = !DIGlobalVariableExpression(var: !40, expr: !DIExpression())
!40 = distinct !DIGlobalVariable(name: "v1", scope: !2, file: !11, line: 36, type: !37, isLocal: false, isDefinition: true, align: 512)
!41 = !DIGlobalVariableExpression(var: !42, expr: !DIExpression())
!42 = distinct !DIGlobalVariable(name: "u2", scope: !2, file: !11, line: 37, type: !37, isLocal: false, isDefinition: true, align: 512)
!43 = !DIGlobalVariableExpression(var: !44, expr: !DIExpression())
!44 = distinct !DIGlobalVariable(name: "v2", scope: !2, file: !11, line: 38, type: !37, isLocal: false, isDefinition: true, align: 512)
!45 = !DIGlobalVariableExpression(var: !46, expr: !DIExpression())
!46 = distinct !DIGlobalVariable(name: "w", scope: !2, file: !11, line: 39, type: !37, isLocal: false, isDefinition: true, align: 512)
!47 = !DIGlobalVariableExpression(var: !48, expr: !DIExpression())
!48 = distinct !DIGlobalVariable(name: "x", scope: !2, file: !11, line: 40, type: !37, isLocal: false, isDefinition: true, align: 512)
!49 = !DIGlobalVariableExpression(var: !50, expr: !DIExpression())
!50 = distinct !DIGlobalVariable(name: "y", scope: !2, file: !11, line: 41, type: !37, isLocal: false, isDefinition: true, align: 512)
!51 = !DIGlobalVariableExpression(var: !52, expr: !DIExpression())
!52 = distinct !DIGlobalVariable(name: "z", scope: !2, file: !11, line: 42, type: !37, isLocal: false, isDefinition: true, align: 512)
!53 = !DIGlobalVariableExpression(var: !54, expr: !DIExpression())
!54 = distinct !DIGlobalVariable(name: "alpha", scope: !2, file: !11, line: 142, type: !5, isLocal: false, isDefinition: true)
!55 = !DIGlobalVariableExpression(var: !56, expr: !DIExpression())
!56 = distinct !DIGlobalVariable(name: "beta", scope: !2, file: !11, line: 143, type: !5, isLocal: false, isDefinition: true)
!57 = !DIGlobalVariableExpression(var: !58, expr: !DIExpression())
!58 = distinct !DIGlobalVariable(name: "pb_emit", scope: !2, file: !29, line: 10, type: !59, isLocal: true, isDefinition: true)
!59 = !DIBasicType(name: "int", size: 32, encoding: DW_ATE_signed)
!60 = !{i32 7, !"Dwarf Version", i32 5}
!61 = !{i32 2, !"Debug Info Version", i32 3}
!62 = !{i32 1, !"wchar_size", i32 4}
!63 = !{i32 7, !"PIC Level", i32 2}
!64 = !{i32 7, !"PIE Level", i32 2}
!65 = !{i32 7, !"uwtable", i32 1}
!66 = !{i32 7, !"frame-pointer", i32 2}
!67 = !{!"Ubuntu clang version 14.0.0-1ubuntu1.1"}
!68 = distinct !DISubprogram(name: "workload_prepare", scope: !11, file: !11, line: 144, type: !69, scopeLine: 144, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !2, retainedNodes: !71)
!69 = !DISubroutineType(types: !70)
!70 = !{null}
!71 = !{}
!72 = !DILocation(line: 144, column: 30, scope: !68)
!73 = distinct !DISubprogram(name: "workload_reset", scope: !11, file: !11, line: 145, type: !74, scopeLine: 145, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !2, retainedNodes: !71)
!74 = !DISubroutineType(types: !75)
!75 = !{null, !6}
!76 = !DILocalVariable(name: "task", arg: 1, scope: !73, file: !11, line: 145, type: !6)
!77 = !DILocation(line: 0, scope: !73)
!78 = !DILocation(line: 147, column: 3, scope: !73)
!79 = !DILocation(line: 148, column: 3, scope: !73)
!80 = !DILocation(line: 149, column: 3, scope: !73)
!81 = !DILocation(line: 150, column: 3, scope: !73)
!82 = !DILocation(line: 151, column: 3, scope: !73)
!83 = !DILocation(line: 152, column: 3, scope: !73)
!84 = !DILocation(line: 153, column: 3, scope: !73)
!85 = !DILocation(line: 154, column: 3, scope: !73)
!86 = !DILocation(line: 155, column: 3, scope: !73)
!87 = !DILocation(line: 156, column: 15, scope: !73)
!88 = !DILocation(line: 156, column: 3, scope: !73)
!89 = !DILocation(line: 166, column: 1, scope: !73)
!90 = distinct !DISubprogram(name: "init_array", scope: !11, file: !11, line: 44, type: !91, scopeLine: 56, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition, unit: !2, retainedNodes: !71)
!91 = !DISubroutineType(types: !92)
!92 = !{null, !59, !93, !93, !94, !93, !93, !93, !93, !93, !93, !93, !93}
!93 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !5, size: 64)
!94 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !37, size: 64)
!95 = !DILocalVariable(name: "n", arg: 1, scope: !90, file: !11, line: 44, type: !59)
!96 = !DILocation(line: 0, scope: !90)
!97 = !DILocalVariable(name: "alpha", arg: 2, scope: !90, file: !11, line: 45, type: !93)
!98 = !DILocalVariable(name: "beta", arg: 3, scope: !90, file: !11, line: 46, type: !93)
!99 = !DILocalVariable(name: "A", arg: 4, scope: !90, file: !11, line: 47, type: !94)
!100 = !DILocalVariable(name: "u1", arg: 5, scope: !90, file: !11, line: 48, type: !93)
!101 = !DILocalVariable(name: "v1", arg: 6, scope: !90, file: !11, line: 49, type: !93)
!102 = !DILocalVariable(name: "u2", arg: 7, scope: !90, file: !11, line: 50, type: !93)
!103 = !DILocalVariable(name: "v2", arg: 8, scope: !90, file: !11, line: 51, type: !93)
!104 = !DILocalVariable(name: "w", arg: 9, scope: !90, file: !11, line: 52, type: !93)
!105 = !DILocalVariable(name: "x", arg: 10, scope: !90, file: !11, line: 53, type: !93)
!106 = !DILocalVariable(name: "y", arg: 11, scope: !90, file: !11, line: 54, type: !93)
!107 = !DILocalVariable(name: "z", arg: 12, scope: !90, file: !11, line: 55, type: !93)
!108 = !DILocation(line: 59, column: 10, scope: !90)
!109 = !DILocation(line: 60, column: 9, scope: !90)
!110 = !DILocation(line: 62, column: 18, scope: !90)
!111 = !DILocalVariable(name: "fn", scope: !90, file: !11, line: 62, type: !5)
!112 = !DILocalVariable(name: "i", scope: !90, file: !11, line: 57, type: !59)
!113 = !DILocation(line: 64, column: 8, scope: !114)
!114 = distinct !DILexicalBlock(scope: !90, file: !11, line: 64, column: 3)
!115 = !DILocation(line: 0, scope: !114)
!116 = !DILocation(line: 64, column: 17, scope: !117)
!117 = distinct !DILexicalBlock(scope: !114, file: !11, line: 64, column: 3)
!118 = !DILocation(line: 64, column: 3, scope: !114)
!119 = !DILocation(line: 66, column: 15, scope: !120)
!120 = distinct !DILexicalBlock(scope: !117, file: !11, line: 65, column: 5)
!121 = !DILocation(line: 66, column: 7, scope: !120)
!122 = !DILocation(line: 66, column: 13, scope: !120)
!123 = !DILocation(line: 67, column: 18, scope: !120)
!124 = !DILocation(line: 67, column: 16, scope: !120)
!125 = !DILocation(line: 67, column: 21, scope: !120)
!126 = !DILocation(line: 67, column: 25, scope: !120)
!127 = !DILocation(line: 67, column: 7, scope: !120)
!128 = !DILocation(line: 67, column: 13, scope: !120)
!129 = !DILocation(line: 68, column: 18, scope: !120)
!130 = !DILocation(line: 68, column: 16, scope: !120)
!131 = !DILocation(line: 68, column: 21, scope: !120)
!132 = !DILocation(line: 68, column: 25, scope: !120)
!133 = !DILocation(line: 68, column: 7, scope: !120)
!134 = !DILocation(line: 68, column: 13, scope: !120)
!135 = !DILocation(line: 69, column: 18, scope: !120)
!136 = !DILocation(line: 69, column: 16, scope: !120)
!137 = !DILocation(line: 69, column: 21, scope: !120)
!138 = !DILocation(line: 69, column: 25, scope: !120)
!139 = !DILocation(line: 69, column: 7, scope: !120)
!140 = !DILocation(line: 69, column: 13, scope: !120)
!141 = !DILocation(line: 70, column: 17, scope: !120)
!142 = !DILocation(line: 70, column: 15, scope: !120)
!143 = !DILocation(line: 70, column: 20, scope: !120)
!144 = !DILocation(line: 70, column: 24, scope: !120)
!145 = !DILocation(line: 70, column: 7, scope: !120)
!146 = !DILocation(line: 70, column: 12, scope: !120)
!147 = !DILocation(line: 71, column: 17, scope: !120)
!148 = !DILocation(line: 71, column: 15, scope: !120)
!149 = !DILocation(line: 71, column: 20, scope: !120)
!150 = !DILocation(line: 71, column: 24, scope: !120)
!151 = !DILocation(line: 71, column: 7, scope: !120)
!152 = !DILocation(line: 71, column: 12, scope: !120)
!153 = !DILocation(line: 72, column: 7, scope: !120)
!154 = !DILocation(line: 72, column: 12, scope: !120)
!155 = !DILocation(line: 73, column: 7, scope: !120)
!156 = !DILocation(line: 73, column: 12, scope: !120)
!157 = !DILocalVariable(name: "j", scope: !90, file: !11, line: 57, type: !59)
!158 = !DILocation(line: 74, column: 12, scope: !159)
!159 = distinct !DILexicalBlock(scope: !120, file: !11, line: 74, column: 7)
!160 = !DILocation(line: 0, scope: !159)
!161 = !DILocation(line: 74, column: 21, scope: !162)
!162 = distinct !DILexicalBlock(scope: !159, file: !11, line: 74, column: 7)
!163 = !DILocation(line: 74, column: 7, scope: !159)
!164 = !DILocation(line: 75, column: 33, scope: !162)
!165 = !DILocation(line: 75, column: 36, scope: !162)
!166 = !DILocation(line: 75, column: 19, scope: !162)
!167 = !DILocation(line: 75, column: 43, scope: !162)
!168 = !DILocation(line: 75, column: 41, scope: !162)
!169 = !DILocation(line: 75, column: 9, scope: !162)
!170 = !DILocation(line: 75, column: 17, scope: !162)
!171 = !DILocation(line: 74, column: 27, scope: !162)
!172 = !DILocation(line: 74, column: 7, scope: !162)
!173 = distinct !{!173, !163, !174, !175}
!174 = !DILocation(line: 75, column: 43, scope: !159)
!175 = !{!"llvm.loop.mustprogress"}
!176 = !DILocation(line: 76, column: 5, scope: !120)
!177 = !DILocation(line: 64, column: 23, scope: !117)
!178 = !DILocation(line: 64, column: 3, scope: !117)
!179 = distinct !{!179, !118, !180, !175}
!180 = !DILocation(line: 76, column: 5, scope: !114)
!181 = !DILocation(line: 77, column: 1, scope: !90)
!182 = distinct !DISubprogram(name: "task_job_polybench", scope: !11, file: !11, line: 167, type: !15, scopeLine: 167, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !2, retainedNodes: !71)
!183 = !DILocation(line: 168, column: 18, scope: !182)
!184 = !DILocation(line: 168, column: 21, scope: !182)
!185 = !DILocation(line: 168, column: 28, scope: !182)
!186 = !DILocalVariable(name: "n", arg: 1, scope: !187, file: !11, line: 102, type: !59)
!187 = distinct !DISubprogram(name: "kernel_gemver", scope: !11, file: !11, line: 102, type: !188, scopeLine: 114, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition, unit: !2, retainedNodes: !71)
!188 = !DISubroutineType(types: !189)
!189 = !{null, !59, !5, !5, !94, !93, !93, !93, !93, !93, !93, !93, !93}
!190 = !DILocation(line: 0, scope: !187, inlinedAt: !191)
!191 = distinct !DILocation(line: 168, column: 3, scope: !182)
!192 = !DILocalVariable(name: "alpha", arg: 2, scope: !187, file: !11, line: 103, type: !5)
!193 = !DILocalVariable(name: "beta", arg: 3, scope: !187, file: !11, line: 104, type: !5)
!194 = !DILocalVariable(name: "A", arg: 4, scope: !187, file: !11, line: 105, type: !94)
!195 = !DILocalVariable(name: "u1", arg: 5, scope: !187, file: !11, line: 106, type: !93)
!196 = !DILocalVariable(name: "v1", arg: 6, scope: !187, file: !11, line: 107, type: !93)
!197 = !DILocalVariable(name: "u2", arg: 7, scope: !187, file: !11, line: 108, type: !93)
!198 = !DILocalVariable(name: "v2", arg: 8, scope: !187, file: !11, line: 109, type: !93)
!199 = !DILocalVariable(name: "w", arg: 9, scope: !187, file: !11, line: 110, type: !93)
!200 = !DILocalVariable(name: "x", arg: 10, scope: !187, file: !11, line: 111, type: !93)
!201 = !DILocalVariable(name: "y", arg: 11, scope: !187, file: !11, line: 112, type: !93)
!202 = !DILocalVariable(name: "z", arg: 12, scope: !187, file: !11, line: 113, type: !93)
!203 = !DILocalVariable(name: "i", scope: !187, file: !11, line: 115, type: !59)
!204 = !DILocation(line: 119, column: 8, scope: !205, inlinedAt: !191)
!205 = distinct !DILexicalBlock(scope: !187, file: !11, line: 119, column: 3)
!206 = !DILocation(line: 0, scope: !205, inlinedAt: !191)
!207 = !DILocation(line: 119, column: 17, scope: !208, inlinedAt: !191)
!208 = distinct !DILexicalBlock(scope: !205, file: !11, line: 119, column: 3)
!209 = !DILocation(line: 119, column: 3, scope: !205, inlinedAt: !191)
!210 = !DILocalVariable(name: "j", scope: !187, file: !11, line: 115, type: !59)
!211 = !DILocation(line: 120, column: 10, scope: !212, inlinedAt: !191)
!212 = distinct !DILexicalBlock(scope: !208, file: !11, line: 120, column: 5)
!213 = !DILocation(line: 0, scope: !212, inlinedAt: !191)
!214 = !DILocation(line: 120, column: 19, scope: !215, inlinedAt: !191)
!215 = distinct !DILexicalBlock(scope: !212, file: !11, line: 120, column: 5)
!216 = !DILocation(line: 120, column: 5, scope: !212, inlinedAt: !191)
!217 = !DILocation(line: 121, column: 17, scope: !215, inlinedAt: !191)
!218 = !DILocation(line: 121, column: 27, scope: !215, inlinedAt: !191)
!219 = !DILocation(line: 121, column: 35, scope: !215, inlinedAt: !191)
!220 = !DILocation(line: 121, column: 33, scope: !215, inlinedAt: !191)
!221 = !DILocation(line: 121, column: 25, scope: !215, inlinedAt: !191)
!222 = !DILocation(line: 121, column: 43, scope: !215, inlinedAt: !191)
!223 = !DILocation(line: 121, column: 51, scope: !215, inlinedAt: !191)
!224 = !DILocation(line: 121, column: 49, scope: !215, inlinedAt: !191)
!225 = !DILocation(line: 121, column: 41, scope: !215, inlinedAt: !191)
!226 = !DILocation(line: 121, column: 7, scope: !215, inlinedAt: !191)
!227 = !DILocation(line: 121, column: 15, scope: !215, inlinedAt: !191)
!228 = !DILocation(line: 120, column: 29, scope: !215, inlinedAt: !191)
!229 = !DILocation(line: 120, column: 5, scope: !215, inlinedAt: !191)
!230 = distinct !{!230, !216, !231, !175}
!231 = !DILocation(line: 121, column: 55, scope: !212, inlinedAt: !191)
!232 = !DILocation(line: 119, column: 27, scope: !208, inlinedAt: !191)
!233 = !DILocation(line: 119, column: 3, scope: !208, inlinedAt: !191)
!234 = distinct !{!234, !209, !235, !175}
!235 = !DILocation(line: 121, column: 55, scope: !205, inlinedAt: !191)
!236 = !DILocation(line: 123, column: 8, scope: !237, inlinedAt: !191)
!237 = distinct !DILexicalBlock(scope: !187, file: !11, line: 123, column: 3)
!238 = !DILocation(line: 0, scope: !237, inlinedAt: !191)
!239 = !DILocation(line: 123, column: 17, scope: !240, inlinedAt: !191)
!240 = distinct !DILexicalBlock(scope: !237, file: !11, line: 123, column: 3)
!241 = !DILocation(line: 123, column: 3, scope: !237, inlinedAt: !191)
!242 = !DILocation(line: 124, column: 10, scope: !243, inlinedAt: !191)
!243 = distinct !DILexicalBlock(scope: !240, file: !11, line: 124, column: 5)
!244 = !DILocation(line: 0, scope: !243, inlinedAt: !191)
!245 = !DILocation(line: 124, column: 19, scope: !246, inlinedAt: !191)
!246 = distinct !DILexicalBlock(scope: !243, file: !11, line: 124, column: 5)
!247 = !DILocation(line: 124, column: 5, scope: !243, inlinedAt: !191)
!248 = !DILocation(line: 125, column: 14, scope: !246, inlinedAt: !191)
!249 = !DILocation(line: 125, column: 28, scope: !246, inlinedAt: !191)
!250 = !DILocation(line: 125, column: 26, scope: !246, inlinedAt: !191)
!251 = !DILocation(line: 125, column: 38, scope: !246, inlinedAt: !191)
!252 = !DILocation(line: 125, column: 36, scope: !246, inlinedAt: !191)
!253 = !DILocation(line: 125, column: 19, scope: !246, inlinedAt: !191)
!254 = !DILocation(line: 125, column: 7, scope: !246, inlinedAt: !191)
!255 = !DILocation(line: 125, column: 12, scope: !246, inlinedAt: !191)
!256 = !DILocation(line: 124, column: 29, scope: !246, inlinedAt: !191)
!257 = !DILocation(line: 124, column: 5, scope: !246, inlinedAt: !191)
!258 = distinct !{!258, !247, !259, !175}
!259 = !DILocation(line: 125, column: 41, scope: !243, inlinedAt: !191)
!260 = !DILocation(line: 123, column: 27, scope: !240, inlinedAt: !191)
!261 = !DILocation(line: 123, column: 3, scope: !240, inlinedAt: !191)
!262 = distinct !{!262, !241, !263, !175}
!263 = !DILocation(line: 125, column: 41, scope: !237, inlinedAt: !191)
!264 = !DILocation(line: 127, column: 8, scope: !265, inlinedAt: !191)
!265 = distinct !DILexicalBlock(scope: !187, file: !11, line: 127, column: 3)
!266 = !DILocation(line: 0, scope: !265, inlinedAt: !191)
!267 = !DILocation(line: 127, column: 17, scope: !268, inlinedAt: !191)
!268 = distinct !DILexicalBlock(scope: !265, file: !11, line: 127, column: 3)
!269 = !DILocation(line: 127, column: 3, scope: !265, inlinedAt: !191)
!270 = !DILocation(line: 128, column: 12, scope: !268, inlinedAt: !191)
!271 = !DILocation(line: 128, column: 19, scope: !268, inlinedAt: !191)
!272 = !DILocation(line: 128, column: 17, scope: !268, inlinedAt: !191)
!273 = !DILocation(line: 128, column: 5, scope: !268, inlinedAt: !191)
!274 = !DILocation(line: 128, column: 10, scope: !268, inlinedAt: !191)
!275 = !DILocation(line: 127, column: 27, scope: !268, inlinedAt: !191)
!276 = !DILocation(line: 127, column: 3, scope: !268, inlinedAt: !191)
!277 = distinct !{!277, !269, !278, !175}
!278 = !DILocation(line: 128, column: 22, scope: !265, inlinedAt: !191)
!279 = !DILocation(line: 130, column: 8, scope: !280, inlinedAt: !191)
!280 = distinct !DILexicalBlock(scope: !187, file: !11, line: 130, column: 3)
!281 = !DILocation(line: 0, scope: !280, inlinedAt: !191)
!282 = !DILocation(line: 130, column: 17, scope: !283, inlinedAt: !191)
!283 = distinct !DILexicalBlock(scope: !280, file: !11, line: 130, column: 3)
!284 = !DILocation(line: 130, column: 3, scope: !280, inlinedAt: !191)
!285 = !DILocation(line: 131, column: 10, scope: !286, inlinedAt: !191)
!286 = distinct !DILexicalBlock(scope: !283, file: !11, line: 131, column: 5)
!287 = !DILocation(line: 0, scope: !286, inlinedAt: !191)
!288 = !DILocation(line: 131, column: 19, scope: !289, inlinedAt: !191)
!289 = distinct !DILexicalBlock(scope: !286, file: !11, line: 131, column: 5)
!290 = !DILocation(line: 131, column: 5, scope: !286, inlinedAt: !191)
!291 = !DILocation(line: 132, column: 14, scope: !289, inlinedAt: !191)
!292 = !DILocation(line: 132, column: 30, scope: !289, inlinedAt: !191)
!293 = !DILocation(line: 132, column: 28, scope: !289, inlinedAt: !191)
!294 = !DILocation(line: 132, column: 40, scope: !289, inlinedAt: !191)
!295 = !DILocation(line: 132, column: 38, scope: !289, inlinedAt: !191)
!296 = !DILocation(line: 132, column: 19, scope: !289, inlinedAt: !191)
!297 = !DILocation(line: 132, column: 7, scope: !289, inlinedAt: !191)
!298 = !DILocation(line: 132, column: 12, scope: !289, inlinedAt: !191)
!299 = !DILocation(line: 131, column: 29, scope: !289, inlinedAt: !191)
!300 = !DILocation(line: 131, column: 5, scope: !289, inlinedAt: !191)
!301 = distinct !{!301, !290, !302, !175}
!302 = !DILocation(line: 132, column: 43, scope: !286, inlinedAt: !191)
!303 = !DILocation(line: 130, column: 27, scope: !283, inlinedAt: !191)
!304 = !DILocation(line: 130, column: 3, scope: !283, inlinedAt: !191)
!305 = distinct !{!305, !284, !306, !175}
!306 = !DILocation(line: 132, column: 43, scope: !280, inlinedAt: !191)
!307 = !DILocation(line: 178, column: 3, scope: !182)
!308 = distinct !DISubprogram(name: "workload_checksum", scope: !11, file: !11, line: 180, type: !309, scopeLine: 180, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !2, retainedNodes: !71)
!309 = !DISubroutineType(types: !310)
!310 = !{!17, !6}
!311 = !DILocalVariable(name: "task", arg: 1, scope: !308, file: !11, line: 180, type: !6)
!312 = !DILocation(line: 0, scope: !308)
!313 = !DILocation(line: 182, column: 11, scope: !308)
!314 = !DILocation(line: 183, column: 15, scope: !308)
!315 = !DILocation(line: 183, column: 3, scope: !308)
!316 = !DILocation(line: 184, column: 10, scope: !308)
!317 = !DILocation(line: 184, column: 3, scope: !308)
!318 = distinct !DISubprogram(name: "print_array", scope: !11, file: !11, line: 83, type: !319, scopeLine: 85, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition, unit: !2, retainedNodes: !71)
!319 = !DISubroutineType(types: !320)
!320 = !{null, !59, !93}
!321 = !DILocalVariable(name: "n", arg: 1, scope: !318, file: !11, line: 83, type: !59)
!322 = !DILocation(line: 0, scope: !318)
!323 = !DILocalVariable(name: "w", arg: 2, scope: !318, file: !11, line: 84, type: !93)
!324 = !DILocation(line: 88, column: 3, scope: !318)
!325 = !DILocation(line: 89, column: 3, scope: !318)
!326 = !DILocalVariable(name: "i", scope: !318, file: !11, line: 86, type: !59)
!327 = !DILocation(line: 90, column: 8, scope: !328)
!328 = distinct !DILexicalBlock(scope: !318, file: !11, line: 90, column: 3)
!329 = !DILocation(line: 0, scope: !328)
!330 = !DILocation(line: 90, column: 17, scope: !331)
!331 = distinct !DILexicalBlock(scope: !328, file: !11, line: 90, column: 3)
!332 = !DILocation(line: 90, column: 3, scope: !328)
!333 = !DILocation(line: 91, column: 11, scope: !334)
!334 = distinct !DILexicalBlock(scope: !335, file: !11, line: 91, column: 9)
!335 = distinct !DILexicalBlock(scope: !331, file: !11, line: 90, column: 27)
!336 = !DILocation(line: 91, column: 16, scope: !334)
!337 = !DILocation(line: 91, column: 9, scope: !335)
!338 = !DILocation(line: 91, column: 31, scope: !334)
!339 = !DILocation(line: 91, column: 22, scope: !334)
!340 = !DILocation(line: 92, column: 14, scope: !335)
!341 = !DILocation(line: 92, column: 59, scope: !335)
!342 = !DILocation(line: 92, column: 5, scope: !335)
!343 = !DILocation(line: 93, column: 3, scope: !335)
!344 = !DILocation(line: 90, column: 23, scope: !331)
!345 = !DILocation(line: 90, column: 3, scope: !331)
!346 = distinct !{!346, !332, !347, !175}
!347 = !DILocation(line: 93, column: 3, scope: !328)
!348 = !DILocation(line: 94, column: 3, scope: !318)
!349 = !DILocation(line: 95, column: 3, scope: !318)
!350 = !DILocation(line: 96, column: 1, scope: !318)
!351 = distinct !DISubprogram(name: "pb_fprintf", scope: !29, file: !29, line: 13, type: !352, scopeLine: 14, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition, unit: !2, retainedNodes: !71)
!352 = !DISubroutineType(types: !353)
!353 = !{!59, !354, !413, null}
!354 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !355, size: 64)
!355 = !DIDerivedType(tag: DW_TAG_typedef, name: "FILE", file: !356, line: 7, baseType: !357)
!356 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/types/FILE.h", directory: "", checksumkind: CSK_MD5, checksum: "571f9fb6223c42439075fdde11a0de5d")
!357 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "_IO_FILE", file: !358, line: 49, size: 1728, elements: !359)
!358 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/types/struct_FILE.h", directory: "", checksumkind: CSK_MD5, checksum: "1bad07471b7974df4ecc1d1c2ca207e6")
!359 = !{!360, !361, !364, !365, !366, !367, !368, !369, !370, !371, !372, !373, !374, !377, !379, !380, !381, !384, !386, !388, !390, !393, !395, !398, !401, !402, !404, !408, !409}
!360 = !DIDerivedType(tag: DW_TAG_member, name: "_flags", scope: !357, file: !358, line: 51, baseType: !59, size: 32)
!361 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_read_ptr", scope: !357, file: !358, line: 54, baseType: !362, size: 64, offset: 64)
!362 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !363, size: 64)
!363 = !DIBasicType(name: "char", size: 8, encoding: DW_ATE_signed_char)
!364 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_read_end", scope: !357, file: !358, line: 55, baseType: !362, size: 64, offset: 128)
!365 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_read_base", scope: !357, file: !358, line: 56, baseType: !362, size: 64, offset: 192)
!366 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_write_base", scope: !357, file: !358, line: 57, baseType: !362, size: 64, offset: 256)
!367 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_write_ptr", scope: !357, file: !358, line: 58, baseType: !362, size: 64, offset: 320)
!368 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_write_end", scope: !357, file: !358, line: 59, baseType: !362, size: 64, offset: 384)
!369 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_buf_base", scope: !357, file: !358, line: 60, baseType: !362, size: 64, offset: 448)
!370 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_buf_end", scope: !357, file: !358, line: 61, baseType: !362, size: 64, offset: 512)
!371 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_save_base", scope: !357, file: !358, line: 64, baseType: !362, size: 64, offset: 576)
!372 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_backup_base", scope: !357, file: !358, line: 65, baseType: !362, size: 64, offset: 640)
!373 = !DIDerivedType(tag: DW_TAG_member, name: "_IO_save_end", scope: !357, file: !358, line: 66, baseType: !362, size: 64, offset: 704)
!374 = !DIDerivedType(tag: DW_TAG_member, name: "_markers", scope: !357, file: !358, line: 68, baseType: !375, size: 64, offset: 768)
!375 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !376, size: 64)
!376 = !DICompositeType(tag: DW_TAG_structure_type, name: "_IO_marker", file: !358, line: 36, flags: DIFlagFwdDecl)
!377 = !DIDerivedType(tag: DW_TAG_member, name: "_chain", scope: !357, file: !358, line: 70, baseType: !378, size: 64, offset: 832)
!378 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !357, size: 64)
!379 = !DIDerivedType(tag: DW_TAG_member, name: "_fileno", scope: !357, file: !358, line: 72, baseType: !59, size: 32, offset: 896)
!380 = !DIDerivedType(tag: DW_TAG_member, name: "_flags2", scope: !357, file: !358, line: 73, baseType: !59, size: 32, offset: 928)
!381 = !DIDerivedType(tag: DW_TAG_member, name: "_old_offset", scope: !357, file: !358, line: 74, baseType: !382, size: 64, offset: 960)
!382 = !DIDerivedType(tag: DW_TAG_typedef, name: "__off_t", file: !20, line: 152, baseType: !383)
!383 = !DIBasicType(name: "long", size: 64, encoding: DW_ATE_signed)
!384 = !DIDerivedType(tag: DW_TAG_member, name: "_cur_column", scope: !357, file: !358, line: 77, baseType: !385, size: 16, offset: 1024)
!385 = !DIBasicType(name: "unsigned short", size: 16, encoding: DW_ATE_unsigned)
!386 = !DIDerivedType(tag: DW_TAG_member, name: "_vtable_offset", scope: !357, file: !358, line: 78, baseType: !387, size: 8, offset: 1040)
!387 = !DIBasicType(name: "signed char", size: 8, encoding: DW_ATE_signed_char)
!388 = !DIDerivedType(tag: DW_TAG_member, name: "_shortbuf", scope: !357, file: !358, line: 79, baseType: !389, size: 8, offset: 1048)
!389 = !DICompositeType(tag: DW_TAG_array_type, baseType: !363, size: 8, elements: !21)
!390 = !DIDerivedType(tag: DW_TAG_member, name: "_lock", scope: !357, file: !358, line: 81, baseType: !391, size: 64, offset: 1088)
!391 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !392, size: 64)
!392 = !DIDerivedType(tag: DW_TAG_typedef, name: "_IO_lock_t", file: !358, line: 43, baseType: null)
!393 = !DIDerivedType(tag: DW_TAG_member, name: "_offset", scope: !357, file: !358, line: 89, baseType: !394, size: 64, offset: 1152)
!394 = !DIDerivedType(tag: DW_TAG_typedef, name: "__off64_t", file: !20, line: 153, baseType: !383)
!395 = !DIDerivedType(tag: DW_TAG_member, name: "_codecvt", scope: !357, file: !358, line: 91, baseType: !396, size: 64, offset: 1216)
!396 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !397, size: 64)
!397 = !DICompositeType(tag: DW_TAG_structure_type, name: "_IO_codecvt", file: !358, line: 37, flags: DIFlagFwdDecl)
!398 = !DIDerivedType(tag: DW_TAG_member, name: "_wide_data", scope: !357, file: !358, line: 92, baseType: !399, size: 64, offset: 1280)
!399 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !400, size: 64)
!400 = !DICompositeType(tag: DW_TAG_structure_type, name: "_IO_wide_data", file: !358, line: 38, flags: DIFlagFwdDecl)
!401 = !DIDerivedType(tag: DW_TAG_member, name: "_freeres_list", scope: !357, file: !358, line: 93, baseType: !378, size: 64, offset: 1344)
!402 = !DIDerivedType(tag: DW_TAG_member, name: "_freeres_buf", scope: !357, file: !358, line: 94, baseType: !403, size: 64, offset: 1408)
!403 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: null, size: 64)
!404 = !DIDerivedType(tag: DW_TAG_member, name: "__pad5", scope: !357, file: !358, line: 95, baseType: !405, size: 64, offset: 1472)
!405 = !DIDerivedType(tag: DW_TAG_typedef, name: "size_t", file: !406, line: 46, baseType: !407)
!406 = !DIFile(filename: "/usr/lib/llvm-14/lib/clang/14.0.0/include/stddef.h", directory: "", checksumkind: CSK_MD5, checksum: "2499dd2361b915724b073282bea3a7bc")
!407 = !DIBasicType(name: "unsigned long", size: 64, encoding: DW_ATE_unsigned)
!408 = !DIDerivedType(tag: DW_TAG_member, name: "_mode", scope: !357, file: !358, line: 96, baseType: !59, size: 32, offset: 1536)
!409 = !DIDerivedType(tag: DW_TAG_member, name: "_unused2", scope: !357, file: !358, line: 98, baseType: !410, size: 160, offset: 1568)
!410 = !DICompositeType(tag: DW_TAG_array_type, baseType: !363, size: 160, elements: !411)
!411 = !{!412}
!412 = !DISubrange(count: 20)
!413 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !414, size: 64)
!414 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !363)
!415 = !DILocalVariable(name: "stream", arg: 1, scope: !351, file: !29, line: 13, type: !354)
!416 = !DILocation(line: 0, scope: !351)
!417 = !DILocalVariable(name: "format", arg: 2, scope: !351, file: !29, line: 13, type: !413)
!418 = !DILocalVariable(name: "buffer", scope: !351, file: !29, line: 15, type: !419)
!419 = !DICompositeType(tag: DW_TAG_array_type, baseType: !363, size: 6144, elements: !420)
!420 = !{!421}
!421 = !DISubrange(count: 768)
!422 = !DILocation(line: 15, column: 10, scope: !351)
!423 = !DILocalVariable(name: "args", scope: !351, file: !29, line: 16, type: !424)
!424 = !DIDerivedType(tag: DW_TAG_typedef, name: "va_list", file: !425, line: 52, baseType: !426)
!425 = !DIFile(filename: "/usr/include/stdio.h", directory: "", checksumkind: CSK_MD5, checksum: "f31eefcc3f15835fc5a4023a625cf609")
!426 = !DIDerivedType(tag: DW_TAG_typedef, name: "__gnuc_va_list", file: !427, line: 32, baseType: !428)
!427 = !DIFile(filename: "/usr/lib/llvm-14/lib/clang/14.0.0/include/stdarg.h", directory: "", checksumkind: CSK_MD5, checksum: "4de3cbd931b589d291e5c39387aecf82")
!428 = !DIDerivedType(tag: DW_TAG_typedef, name: "__builtin_va_list", file: !429, baseType: !430)
!429 = !DIFile(filename: "source/workload.c", directory: "/workspace/experiments-array-support/chaser/.cache/periodic-polybench/affine-bounds-20260929/suite/gemver")
!430 = !DICompositeType(tag: DW_TAG_array_type, baseType: !431, size: 192, elements: !21)
!431 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "__va_list_tag", size: 192, elements: !432)
!432 = !{!433, !434, !435, !436}
!433 = !DIDerivedType(tag: DW_TAG_member, name: "gp_offset", scope: !431, file: !429, line: 16, baseType: !6, size: 32)
!434 = !DIDerivedType(tag: DW_TAG_member, name: "fp_offset", scope: !431, file: !429, line: 16, baseType: !6, size: 32, offset: 32)
!435 = !DIDerivedType(tag: DW_TAG_member, name: "overflow_arg_area", scope: !431, file: !429, line: 16, baseType: !403, size: 64, offset: 64)
!436 = !DIDerivedType(tag: DW_TAG_member, name: "reg_save_area", scope: !431, file: !429, line: 16, baseType: !403, size: 64, offset: 128)
!437 = !DILocation(line: 16, column: 13, scope: !351)
!438 = !DILocation(line: 17, column: 5, scope: !351)
!439 = !DILocation(line: 18, column: 27, scope: !351)
!440 = !DILocation(line: 18, column: 59, scope: !351)
!441 = !DILocation(line: 18, column: 17, scope: !351)
!442 = !DILocalVariable(name: "count", scope: !351, file: !29, line: 18, type: !59)
!443 = !DILocation(line: 19, column: 5, scope: !351)
!444 = !DILocation(line: 20, column: 15, scope: !445)
!445 = distinct !DILexicalBlock(scope: !351, file: !29, line: 20, column: 9)
!446 = !DILocation(line: 20, column: 19, scope: !445)
!447 = !DILocation(line: 20, column: 22, scope: !445)
!448 = !DILocation(line: 20, column: 38, scope: !445)
!449 = !DILocation(line: 20, column: 9, scope: !351)
!450 = !DILocation(line: 20, column: 57, scope: !445)
!451 = !DILocalVariable(name: "i", scope: !452, file: !29, line: 21, type: !59)
!452 = distinct !DILexicalBlock(scope: !351, file: !29, line: 21, column: 5)
!453 = !DILocation(line: 0, scope: !452)
!454 = !DILocation(line: 21, column: 10, scope: !452)
!455 = !DILocation(line: 21, column: 23, scope: !456)
!456 = distinct !DILexicalBlock(scope: !452, file: !29, line: 21, column: 5)
!457 = !DILocation(line: 21, column: 5, scope: !452)
!458 = !DILocation(line: 22, column: 35, scope: !459)
!459 = distinct !DILexicalBlock(scope: !456, file: !29, line: 21, column: 37)
!460 = !DILocation(line: 22, column: 20, scope: !459)
!461 = !DILocation(line: 22, column: 17, scope: !459)
!462 = !DILocation(line: 23, column: 17, scope: !459)
!463 = !DILocation(line: 24, column: 5, scope: !459)
!464 = !DILocation(line: 21, column: 32, scope: !456)
!465 = !DILocation(line: 21, column: 5, scope: !456)
!466 = distinct !{!466, !457, !467, !175}
!467 = !DILocation(line: 24, column: 5, scope: !452)
!468 = !DILocation(line: 29, column: 11, scope: !351)
!469 = !DILocation(line: 31, column: 5, scope: !351)
