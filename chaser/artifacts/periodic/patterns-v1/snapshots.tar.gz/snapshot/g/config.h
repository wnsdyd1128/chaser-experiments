#define TASK_COUNT 2
#define MAX_JOBS 2
#define ARCHITECTURE 0
#define CHASER_CONTRACT_ID "chaser-periodic-measurement-v2"
#define CHASER_PLAN_HASH "e7e4f330390069db44c8e8c1f1249f4782c92d90f9a85cd859ec6ef93ca82dab"
#define CHASER_PERIODS {20, 20}
#define CHASER_JOB_COUNTS {2, 2}
#define CHASER_CORES {0, 1}
