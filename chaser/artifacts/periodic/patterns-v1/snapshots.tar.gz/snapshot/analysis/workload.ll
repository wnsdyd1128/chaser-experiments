; ModuleID = '/workspace/experiments/chaser/.cache/periodic-patterns-v1/source/workload.c'
source_filename = "/workspace/experiments/chaser/.cache/periodic-patterns-v1/source/workload.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

@.str = private unnamed_addr constant [12 x i8] c"ape.analyze\00", section "llvm.metadata"
@.str.1 = private unnamed_addr constant [76 x i8] c"/workspace/experiments/chaser/.cache/periodic-patterns-v1/source/workload.c\00", section "llvm.metadata"
@data_hot = dso_local global [34816 x i8] zeroinitializer, section ".chaser_data.00", align 4096, !dbg !0
@data_phase = dso_local global [34816 x i8] zeroinitializer, section ".chaser_data.01", align 4096, !dbg !24
@workload_jobs = dso_local constant [2 x i32 ()*] [i32 ()* @task_job_hot, i32 ()* @task_job_phase], align 16, !dbg !5
@workload_expected = dso_local constant [2 x i32] [i32 10240, i32 10240], align 4, !dbg !20
@.str.2 = private unnamed_addr constant [11 x i8] c"ape.inline\00", section "llvm.metadata"
@llvm.global.annotations = appending global [4 x { i8*, i8*, i8*, i32, i8* }] [{ i8*, i8*, i8*, i32, i8* } { i8* bitcast (i32 ()* @task_job_hot to i8*), i8* getelementptr inbounds ([12 x i8], [12 x i8]* @.str, i32 0, i32 0), i8* getelementptr inbounds ([76 x i8], [76 x i8]* @.str.1, i32 0, i32 0), i32 22, i8* null }, { i8*, i8*, i8*, i32, i8* } { i8* bitcast (i32 ()* @task_job_phase to i8*), i8* getelementptr inbounds ([12 x i8], [12 x i8]* @.str, i32 0, i32 0), i8* getelementptr inbounds ([76 x i8], [76 x i8]* @.str.1, i32 0, i32 0), i32 43, i8* null }, { i8*, i8*, i8*, i32, i8* } { i8* bitcast (i32 ()* @kernel_hot to i8*), i8* getelementptr inbounds ([11 x i8], [11 x i8]* @.str.2, i32 0, i32 0), i8* getelementptr inbounds ([76 x i8], [76 x i8]* @.str.1, i32 0, i32 0), i32 10, i8* null }, { i8*, i8*, i8*, i32, i8* } { i8* bitcast (i32 ()* @kernel_phase to i8*), i8* getelementptr inbounds ([11 x i8], [11 x i8]* @.str.2, i32 0, i32 0), i8* getelementptr inbounds ([76 x i8], [76 x i8]* @.str.1, i32 0, i32 0), i32 29, i8* null }], section "llvm.metadata"

; Function Attrs: noinline nounwind uwtable
define dso_local i32 @task_job_hot() #0 !dbg !41 {
  %1 = alloca i32, align 4
  %2 = alloca i32, align 4
  call void @llvm.dbg.declare(metadata i32* %1, metadata !43, metadata !DIExpression()), !dbg !44
  store i32 0, i32* %1, align 4, !dbg !44
  call void @llvm.dbg.declare(metadata i32* %2, metadata !45, metadata !DIExpression()), !dbg !48
  store i32 0, i32* %2, align 4, !dbg !48
  br label %3, !dbg !49

3:                                                ; preds = %10, %0
  %4 = load i32, i32* %2, align 4, !dbg !50
  %5 = icmp slt i32 %4, 8, !dbg !52
  br i1 %5, label %6, label %13, !dbg !53

6:                                                ; preds = %3
  %7 = call i32 @kernel_hot(), !dbg !54
  %8 = load i32, i32* %1, align 4, !dbg !55
  %9 = add i32 %8, %7, !dbg !55
  store i32 %9, i32* %1, align 4, !dbg !55
  br label %10, !dbg !56

10:                                               ; preds = %6
  %11 = load i32, i32* %2, align 4, !dbg !57
  %12 = add nsw i32 %11, 1, !dbg !57
  store i32 %12, i32* %2, align 4, !dbg !57
  br label %3, !dbg !58, !llvm.loop !59

13:                                               ; preds = %3
  %14 = load i32, i32* %1, align 4, !dbg !62
  ret i32 %14, !dbg !63
}

; Function Attrs: nofree nosync nounwind readnone speculatable willreturn
declare void @llvm.dbg.declare(metadata, metadata, metadata) #1

; Function Attrs: noinline nounwind uwtable
define internal i32 @kernel_hot() #0 !dbg !64 {
  %1 = alloca i32, align 4
  %2 = alloca i32, align 4
  %3 = alloca i32, align 4
  %4 = alloca i32, align 4
  %5 = alloca i32, align 4
  call void @llvm.dbg.declare(metadata i32* %1, metadata !65, metadata !DIExpression()), !dbg !66
  store i32 0, i32* %1, align 4, !dbg !66
  call void @llvm.dbg.declare(metadata i32* %2, metadata !67, metadata !DIExpression()), !dbg !69
  store i32 0, i32* %2, align 4, !dbg !69
  br label %6, !dbg !70

6:                                                ; preds = %25, %0
  %7 = load i32, i32* %2, align 4, !dbg !71
  %8 = icmp slt i32 %7, 4, !dbg !73
  br i1 %8, label %9, label %28, !dbg !74

9:                                                ; preds = %6
  call void @llvm.dbg.declare(metadata i32* %3, metadata !75, metadata !DIExpression()), !dbg !77
  store i32 0, i32* %3, align 4, !dbg !77
  br label %10, !dbg !78

10:                                               ; preds = %21, %9
  %11 = load i32, i32* %3, align 4, !dbg !79
  %12 = icmp slt i32 %11, 2048, !dbg !81
  br i1 %12, label %13, label %24, !dbg !82

13:                                               ; preds = %10
  %14 = load i32, i32* %3, align 4, !dbg !83
  %15 = sext i32 %14 to i64, !dbg !84
  %16 = getelementptr inbounds [34816 x i8], [34816 x i8]* @data_hot, i64 0, i64 %15, !dbg !84
  %17 = load volatile i8, i8* %16, align 1, !dbg !84
  %18 = zext i8 %17 to i32, !dbg !84
  %19 = load i32, i32* %1, align 4, !dbg !85
  %20 = add i32 %19, %18, !dbg !85
  store i32 %20, i32* %1, align 4, !dbg !85
  br label %21, !dbg !86

21:                                               ; preds = %13
  %22 = load i32, i32* %3, align 4, !dbg !87
  %23 = add nsw i32 %22, 32, !dbg !87
  store i32 %23, i32* %3, align 4, !dbg !87
  br label %10, !dbg !88, !llvm.loop !89

24:                                               ; preds = %10
  br label %25, !dbg !90

25:                                               ; preds = %24
  %26 = load i32, i32* %2, align 4, !dbg !91
  %27 = add nsw i32 %26, 1, !dbg !91
  store i32 %27, i32* %2, align 4, !dbg !91
  br label %6, !dbg !92, !llvm.loop !93

28:                                               ; preds = %6
  call void @llvm.dbg.declare(metadata i32* %4, metadata !95, metadata !DIExpression()), !dbg !97
  store i32 0, i32* %4, align 4, !dbg !97
  br label %29, !dbg !98

29:                                               ; preds = %48, %28
  %30 = load i32, i32* %4, align 4, !dbg !99
  %31 = icmp slt i32 %30, 1, !dbg !101
  br i1 %31, label %32, label %51, !dbg !102

32:                                               ; preds = %29
  call void @llvm.dbg.declare(metadata i32* %5, metadata !103, metadata !DIExpression()), !dbg !105
  store i32 2048, i32* %5, align 4, !dbg !105
  br label %33, !dbg !106

33:                                               ; preds = %44, %32
  %34 = load i32, i32* %5, align 4, !dbg !107
  %35 = icmp slt i32 %34, 34816, !dbg !109
  br i1 %35, label %36, label %47, !dbg !110

36:                                               ; preds = %33
  %37 = load i32, i32* %5, align 4, !dbg !111
  %38 = sext i32 %37 to i64, !dbg !112
  %39 = getelementptr inbounds [34816 x i8], [34816 x i8]* @data_hot, i64 0, i64 %38, !dbg !112
  %40 = load volatile i8, i8* %39, align 1, !dbg !112
  %41 = zext i8 %40 to i32, !dbg !112
  %42 = load i32, i32* %1, align 4, !dbg !113
  %43 = add i32 %42, %41, !dbg !113
  store i32 %43, i32* %1, align 4, !dbg !113
  br label %44, !dbg !114

44:                                               ; preds = %36
  %45 = load i32, i32* %5, align 4, !dbg !115
  %46 = add nsw i32 %45, 32, !dbg !115
  store i32 %46, i32* %5, align 4, !dbg !115
  br label %33, !dbg !116, !llvm.loop !117

47:                                               ; preds = %33
  br label %48, !dbg !118

48:                                               ; preds = %47
  %49 = load i32, i32* %4, align 4, !dbg !119
  %50 = add nsw i32 %49, 1, !dbg !119
  store i32 %50, i32* %4, align 4, !dbg !119
  br label %29, !dbg !120, !llvm.loop !121

51:                                               ; preds = %29
  %52 = load i32, i32* %1, align 4, !dbg !123
  ret i32 %52, !dbg !124
}

; Function Attrs: noinline nounwind uwtable
define dso_local i32 @task_job_phase() #0 !dbg !125 {
  %1 = alloca i32, align 4
  %2 = alloca i32, align 4
  call void @llvm.dbg.declare(metadata i32* %1, metadata !126, metadata !DIExpression()), !dbg !127
  store i32 0, i32* %1, align 4, !dbg !127
  call void @llvm.dbg.declare(metadata i32* %2, metadata !128, metadata !DIExpression()), !dbg !130
  store i32 0, i32* %2, align 4, !dbg !130
  br label %3, !dbg !131

3:                                                ; preds = %10, %0
  %4 = load i32, i32* %2, align 4, !dbg !132
  %5 = icmp slt i32 %4, 1, !dbg !134
  br i1 %5, label %6, label %13, !dbg !135

6:                                                ; preds = %3
  %7 = call i32 @kernel_phase(), !dbg !136
  %8 = load i32, i32* %1, align 4, !dbg !137
  %9 = add i32 %8, %7, !dbg !137
  store i32 %9, i32* %1, align 4, !dbg !137
  br label %10, !dbg !138

10:                                               ; preds = %6
  %11 = load i32, i32* %2, align 4, !dbg !139
  %12 = add nsw i32 %11, 1, !dbg !139
  store i32 %12, i32* %2, align 4, !dbg !139
  br label %3, !dbg !140, !llvm.loop !141

13:                                               ; preds = %3
  %14 = load i32, i32* %1, align 4, !dbg !143
  ret i32 %14, !dbg !144
}

; Function Attrs: noinline nounwind uwtable
define internal i32 @kernel_phase() #0 !dbg !145 {
  %1 = alloca i32, align 4
  %2 = alloca i32, align 4
  %3 = alloca i32, align 4
  %4 = alloca i32, align 4
  %5 = alloca i32, align 4
  %6 = alloca i32, align 4
  %7 = alloca i32, align 4
  call void @llvm.dbg.declare(metadata i32* %1, metadata !146, metadata !DIExpression()), !dbg !147
  store i32 0, i32* %1, align 4, !dbg !147
  call void @llvm.dbg.declare(metadata i32* %2, metadata !148, metadata !DIExpression()), !dbg !150
  store i32 0, i32* %2, align 4, !dbg !150
  br label %8, !dbg !151

8:                                                ; preds = %35, %0
  %9 = load i32, i32* %2, align 4, !dbg !152
  %10 = icmp slt i32 %9, 8, !dbg !154
  br i1 %10, label %11, label %38, !dbg !155

11:                                               ; preds = %8
  call void @llvm.dbg.declare(metadata i32* %3, metadata !156, metadata !DIExpression()), !dbg !158
  store i32 0, i32* %3, align 4, !dbg !158
  br label %12, !dbg !159

12:                                               ; preds = %31, %11
  %13 = load i32, i32* %3, align 4, !dbg !160
  %14 = icmp slt i32 %13, 4, !dbg !162
  br i1 %14, label %15, label %34, !dbg !163

15:                                               ; preds = %12
  call void @llvm.dbg.declare(metadata i32* %4, metadata !164, metadata !DIExpression()), !dbg !166
  store i32 0, i32* %4, align 4, !dbg !166
  br label %16, !dbg !167

16:                                               ; preds = %27, %15
  %17 = load i32, i32* %4, align 4, !dbg !168
  %18 = icmp slt i32 %17, 2048, !dbg !170
  br i1 %18, label %19, label %30, !dbg !171

19:                                               ; preds = %16
  %20 = load i32, i32* %4, align 4, !dbg !172
  %21 = sext i32 %20 to i64, !dbg !173
  %22 = getelementptr inbounds [34816 x i8], [34816 x i8]* @data_phase, i64 0, i64 %21, !dbg !173
  %23 = load volatile i8, i8* %22, align 1, !dbg !173
  %24 = zext i8 %23 to i32, !dbg !173
  %25 = load i32, i32* %1, align 4, !dbg !174
  %26 = add i32 %25, %24, !dbg !174
  store i32 %26, i32* %1, align 4, !dbg !174
  br label %27, !dbg !175

27:                                               ; preds = %19
  %28 = load i32, i32* %4, align 4, !dbg !176
  %29 = add nsw i32 %28, 32, !dbg !176
  store i32 %29, i32* %4, align 4, !dbg !176
  br label %16, !dbg !177, !llvm.loop !178

30:                                               ; preds = %16
  br label %31, !dbg !179

31:                                               ; preds = %30
  %32 = load i32, i32* %3, align 4, !dbg !180
  %33 = add nsw i32 %32, 1, !dbg !180
  store i32 %33, i32* %3, align 4, !dbg !180
  br label %12, !dbg !181, !llvm.loop !182

34:                                               ; preds = %12
  br label %35, !dbg !183

35:                                               ; preds = %34
  %36 = load i32, i32* %2, align 4, !dbg !184
  %37 = add nsw i32 %36, 1, !dbg !184
  store i32 %37, i32* %2, align 4, !dbg !184
  br label %8, !dbg !185, !llvm.loop !186

38:                                               ; preds = %8
  call void @llvm.dbg.declare(metadata i32* %5, metadata !188, metadata !DIExpression()), !dbg !190
  store i32 0, i32* %5, align 4, !dbg !190
  br label %39, !dbg !191

39:                                               ; preds = %66, %38
  %40 = load i32, i32* %5, align 4, !dbg !192
  %41 = icmp slt i32 %40, 8, !dbg !194
  br i1 %41, label %42, label %69, !dbg !195

42:                                               ; preds = %39
  call void @llvm.dbg.declare(metadata i32* %6, metadata !196, metadata !DIExpression()), !dbg !198
  store i32 0, i32* %6, align 4, !dbg !198
  br label %43, !dbg !199

43:                                               ; preds = %62, %42
  %44 = load i32, i32* %6, align 4, !dbg !200
  %45 = icmp slt i32 %44, 1, !dbg !202
  br i1 %45, label %46, label %65, !dbg !203

46:                                               ; preds = %43
  call void @llvm.dbg.declare(metadata i32* %7, metadata !204, metadata !DIExpression()), !dbg !206
  store i32 2048, i32* %7, align 4, !dbg !206
  br label %47, !dbg !207

47:                                               ; preds = %58, %46
  %48 = load i32, i32* %7, align 4, !dbg !208
  %49 = icmp slt i32 %48, 34816, !dbg !210
  br i1 %49, label %50, label %61, !dbg !211

50:                                               ; preds = %47
  %51 = load i32, i32* %7, align 4, !dbg !212
  %52 = sext i32 %51 to i64, !dbg !213
  %53 = getelementptr inbounds [34816 x i8], [34816 x i8]* @data_phase, i64 0, i64 %52, !dbg !213
  %54 = load volatile i8, i8* %53, align 1, !dbg !213
  %55 = zext i8 %54 to i32, !dbg !213
  %56 = load i32, i32* %1, align 4, !dbg !214
  %57 = add i32 %56, %55, !dbg !214
  store i32 %57, i32* %1, align 4, !dbg !214
  br label %58, !dbg !215

58:                                               ; preds = %50
  %59 = load i32, i32* %7, align 4, !dbg !216
  %60 = add nsw i32 %59, 32, !dbg !216
  store i32 %60, i32* %7, align 4, !dbg !216
  br label %47, !dbg !217, !llvm.loop !218

61:                                               ; preds = %47
  br label %62, !dbg !219

62:                                               ; preds = %61
  %63 = load i32, i32* %6, align 4, !dbg !220
  %64 = add nsw i32 %63, 1, !dbg !220
  store i32 %64, i32* %6, align 4, !dbg !220
  br label %43, !dbg !221, !llvm.loop !222

65:                                               ; preds = %43
  br label %66, !dbg !223

66:                                               ; preds = %65
  %67 = load i32, i32* %5, align 4, !dbg !224
  %68 = add nsw i32 %67, 1, !dbg !224
  store i32 %68, i32* %5, align 4, !dbg !224
  br label %39, !dbg !225, !llvm.loop !226

69:                                               ; preds = %39
  %70 = load i32, i32* %1, align 4, !dbg !228
  ret i32 %70, !dbg !229
}

; Function Attrs: noinline nounwind uwtable
define dso_local void @workload_prepare() #0 !dbg !230 {
  %1 = alloca i32, align 4
  %2 = alloca i32, align 4
  call void @llvm.dbg.declare(metadata i32* %1, metadata !233, metadata !DIExpression()), !dbg !235
  store i32 0, i32* %1, align 4, !dbg !235
  br label %3, !dbg !236

3:                                                ; preds = %10, %0
  %4 = load i32, i32* %1, align 4, !dbg !237
  %5 = icmp slt i32 %4, 34816, !dbg !239
  br i1 %5, label %6, label %13, !dbg !240

6:                                                ; preds = %3
  %7 = load i32, i32* %1, align 4, !dbg !241
  %8 = sext i32 %7 to i64, !dbg !242
  %9 = getelementptr inbounds [34816 x i8], [34816 x i8]* @data_hot, i64 0, i64 %8, !dbg !242
  store volatile i8 1, i8* %9, align 1, !dbg !243
  br label %10, !dbg !242

10:                                               ; preds = %6
  %11 = load i32, i32* %1, align 4, !dbg !244
  %12 = add nsw i32 %11, 1, !dbg !244
  store i32 %12, i32* %1, align 4, !dbg !244
  br label %3, !dbg !245, !llvm.loop !246

13:                                               ; preds = %3
  call void @llvm.dbg.declare(metadata i32* %2, metadata !248, metadata !DIExpression()), !dbg !250
  store i32 0, i32* %2, align 4, !dbg !250
  br label %14, !dbg !251

14:                                               ; preds = %21, %13
  %15 = load i32, i32* %2, align 4, !dbg !252
  %16 = icmp slt i32 %15, 34816, !dbg !254
  br i1 %16, label %17, label %24, !dbg !255

17:                                               ; preds = %14
  %18 = load i32, i32* %2, align 4, !dbg !256
  %19 = sext i32 %18 to i64, !dbg !257
  %20 = getelementptr inbounds [34816 x i8], [34816 x i8]* @data_phase, i64 0, i64 %19, !dbg !257
  store volatile i8 1, i8* %20, align 1, !dbg !258
  br label %21, !dbg !257

21:                                               ; preds = %17
  %22 = load i32, i32* %2, align 4, !dbg !259
  %23 = add nsw i32 %22, 1, !dbg !259
  store i32 %23, i32* %2, align 4, !dbg !259
  br label %14, !dbg !260, !llvm.loop !261

24:                                               ; preds = %14
  ret void, !dbg !263
}

attributes #0 = { noinline nounwind uwtable "frame-pointer"="all" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { nofree nosync nounwind readnone speculatable willreturn }

!llvm.dbg.cu = !{!2}
!llvm.module.flags = !{!33, !34, !35, !36, !37, !38, !39}
!llvm.ident = !{!40}

!0 = !DIGlobalVariableExpression(var: !1, expr: !DIExpression())
!1 = distinct !DIGlobalVariable(name: "data_hot", scope: !2, file: !7, line: 9, type: !26, isLocal: false, isDefinition: true, align: 32768)
!2 = distinct !DICompileUnit(language: DW_LANG_C99, file: !3, producer: "Ubuntu clang version 14.0.0-1ubuntu1.1", isOptimized: false, runtimeVersion: 0, emissionKind: FullDebug, globals: !4, splitDebugInlining: false, nameTableKind: None)
!3 = !DIFile(filename: "/workspace/experiments/chaser/.cache/periodic-patterns-v1/source/workload.c", directory: "/workspace/experiments/chaser/.cache/periodic-patterns-v1/analysis", checksumkind: CSK_MD5, checksum: "7bf1a03b21f945707ce76ec36df772ad")
!4 = !{!5, !20, !0, !24}
!5 = !DIGlobalVariableExpression(var: !6, expr: !DIExpression())
!6 = distinct !DIGlobalVariable(name: "workload_jobs", scope: !2, file: !7, line: 53, type: !8, isLocal: false, isDefinition: true)
!7 = !DIFile(filename: "source/workload.c", directory: "/workspace/experiments/chaser/.cache/periodic-patterns-v1", checksumkind: CSK_MD5, checksum: "7bf1a03b21f945707ce76ec36df772ad")
!8 = !DICompositeType(tag: DW_TAG_array_type, baseType: !9, size: 128, elements: !18)
!9 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !10)
!10 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !11, size: 64)
!11 = !DISubroutineType(types: !12)
!12 = !{!13}
!13 = !DIDerivedType(tag: DW_TAG_typedef, name: "uint32_t", file: !14, line: 26, baseType: !15)
!14 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/stdint-uintn.h", directory: "", checksumkind: CSK_MD5, checksum: "2bf2ae53c58c01b1a1b9383b5195125c")
!15 = !DIDerivedType(tag: DW_TAG_typedef, name: "__uint32_t", file: !16, line: 42, baseType: !17)
!16 = !DIFile(filename: "/usr/include/x86_64-linux-gnu/bits/types.h", directory: "", checksumkind: CSK_MD5, checksum: "d108b5f93a74c50510d7d9bc0ab36df9")
!17 = !DIBasicType(name: "unsigned int", size: 32, encoding: DW_ATE_unsigned)
!18 = !{!19}
!19 = !DISubrange(count: 2)
!20 = !DIGlobalVariableExpression(var: !21, expr: !DIExpression())
!21 = distinct !DIGlobalVariable(name: "workload_expected", scope: !2, file: !7, line: 57, type: !22, isLocal: false, isDefinition: true)
!22 = !DICompositeType(tag: DW_TAG_array_type, baseType: !23, size: 64, elements: !18)
!23 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !13)
!24 = !DIGlobalVariableExpression(var: !25, expr: !DIExpression())
!25 = distinct !DIGlobalVariable(name: "data_phase", scope: !2, file: !7, line: 28, type: !26, isLocal: false, isDefinition: true, align: 32768)
!26 = !DICompositeType(tag: DW_TAG_array_type, baseType: !27, size: 278528, elements: !31)
!27 = !DIDerivedType(tag: DW_TAG_volatile_type, baseType: !28)
!28 = !DIDerivedType(tag: DW_TAG_typedef, name: "uint8_t", file: !14, line: 24, baseType: !29)
!29 = !DIDerivedType(tag: DW_TAG_typedef, name: "__uint8_t", file: !16, line: 38, baseType: !30)
!30 = !DIBasicType(name: "unsigned char", size: 8, encoding: DW_ATE_unsigned_char)
!31 = !{!32}
!32 = !DISubrange(count: 34816)
!33 = !{i32 7, !"Dwarf Version", i32 5}
!34 = !{i32 2, !"Debug Info Version", i32 3}
!35 = !{i32 1, !"wchar_size", i32 4}
!36 = !{i32 7, !"PIC Level", i32 2}
!37 = !{i32 7, !"PIE Level", i32 2}
!38 = !{i32 7, !"uwtable", i32 1}
!39 = !{i32 7, !"frame-pointer", i32 2}
!40 = !{!"Ubuntu clang version 14.0.0-1ubuntu1.1"}
!41 = distinct !DISubprogram(name: "task_job_hot", scope: !7, file: !7, line: 22, type: !11, scopeLine: 22, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !2, retainedNodes: !42)
!42 = !{}
!43 = !DILocalVariable(name: "sum", scope: !41, file: !7, line: 23, type: !13)
!44 = !DILocation(line: 23, column: 14, scope: !41)
!45 = !DILocalVariable(name: "s", scope: !46, file: !7, line: 24, type: !47)
!46 = distinct !DILexicalBlock(scope: !41, file: !7, line: 24, column: 5)
!47 = !DIBasicType(name: "int", size: 32, encoding: DW_ATE_signed)
!48 = !DILocation(line: 24, column: 14, scope: !46)
!49 = !DILocation(line: 24, column: 10, scope: !46)
!50 = !DILocation(line: 24, column: 21, scope: !51)
!51 = distinct !DILexicalBlock(scope: !46, file: !7, line: 24, column: 5)
!52 = !DILocation(line: 24, column: 23, scope: !51)
!53 = !DILocation(line: 24, column: 5, scope: !46)
!54 = !DILocation(line: 25, column: 16, scope: !51)
!55 = !DILocation(line: 25, column: 13, scope: !51)
!56 = !DILocation(line: 25, column: 9, scope: !51)
!57 = !DILocation(line: 24, column: 28, scope: !51)
!58 = !DILocation(line: 24, column: 5, scope: !51)
!59 = distinct !{!59, !53, !60, !61}
!60 = !DILocation(line: 25, column: 27, scope: !46)
!61 = !{!"llvm.loop.mustprogress"}
!62 = !DILocation(line: 26, column: 12, scope: !41)
!63 = !DILocation(line: 26, column: 5, scope: !41)
!64 = distinct !DISubprogram(name: "kernel_hot", scope: !7, file: !7, line: 10, type: !11, scopeLine: 10, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition, unit: !2, retainedNodes: !42)
!65 = !DILocalVariable(name: "sum", scope: !64, file: !7, line: 11, type: !13)
!66 = !DILocation(line: 11, column: 14, scope: !64)
!67 = !DILocalVariable(name: "r", scope: !68, file: !7, line: 12, type: !47)
!68 = distinct !DILexicalBlock(scope: !64, file: !7, line: 12, column: 5)
!69 = !DILocation(line: 12, column: 14, scope: !68)
!70 = !DILocation(line: 12, column: 10, scope: !68)
!71 = !DILocation(line: 12, column: 21, scope: !72)
!72 = distinct !DILexicalBlock(scope: !68, file: !7, line: 12, column: 5)
!73 = !DILocation(line: 12, column: 23, scope: !72)
!74 = !DILocation(line: 12, column: 5, scope: !68)
!75 = !DILocalVariable(name: "i", scope: !76, file: !7, line: 13, type: !47)
!76 = distinct !DILexicalBlock(scope: !72, file: !7, line: 13, column: 9)
!77 = !DILocation(line: 13, column: 18, scope: !76)
!78 = !DILocation(line: 13, column: 14, scope: !76)
!79 = !DILocation(line: 13, column: 25, scope: !80)
!80 = distinct !DILexicalBlock(scope: !76, file: !7, line: 13, column: 9)
!81 = !DILocation(line: 13, column: 27, scope: !80)
!82 = !DILocation(line: 13, column: 9, scope: !76)
!83 = !DILocation(line: 14, column: 29, scope: !80)
!84 = !DILocation(line: 14, column: 20, scope: !80)
!85 = !DILocation(line: 14, column: 17, scope: !80)
!86 = !DILocation(line: 14, column: 13, scope: !80)
!87 = !DILocation(line: 13, column: 37, scope: !80)
!88 = !DILocation(line: 13, column: 9, scope: !80)
!89 = distinct !{!89, !82, !90, !61}
!90 = !DILocation(line: 14, column: 30, scope: !76)
!91 = !DILocation(line: 12, column: 28, scope: !72)
!92 = !DILocation(line: 12, column: 5, scope: !72)
!93 = distinct !{!93, !74, !94, !61}
!94 = !DILocation(line: 14, column: 30, scope: !68)
!95 = !DILocalVariable(name: "r", scope: !96, file: !7, line: 15, type: !47)
!96 = distinct !DILexicalBlock(scope: !64, file: !7, line: 15, column: 5)
!97 = !DILocation(line: 15, column: 14, scope: !96)
!98 = !DILocation(line: 15, column: 10, scope: !96)
!99 = !DILocation(line: 15, column: 21, scope: !100)
!100 = distinct !DILexicalBlock(scope: !96, file: !7, line: 15, column: 5)
!101 = !DILocation(line: 15, column: 23, scope: !100)
!102 = !DILocation(line: 15, column: 5, scope: !96)
!103 = !DILocalVariable(name: "i", scope: !104, file: !7, line: 16, type: !47)
!104 = distinct !DILexicalBlock(scope: !100, file: !7, line: 16, column: 9)
!105 = !DILocation(line: 16, column: 18, scope: !104)
!106 = !DILocation(line: 16, column: 14, scope: !104)
!107 = !DILocation(line: 16, column: 28, scope: !108)
!108 = distinct !DILexicalBlock(scope: !104, file: !7, line: 16, column: 9)
!109 = !DILocation(line: 16, column: 30, scope: !108)
!110 = !DILocation(line: 16, column: 9, scope: !104)
!111 = !DILocation(line: 17, column: 29, scope: !108)
!112 = !DILocation(line: 17, column: 20, scope: !108)
!113 = !DILocation(line: 17, column: 17, scope: !108)
!114 = !DILocation(line: 17, column: 13, scope: !108)
!115 = !DILocation(line: 16, column: 41, scope: !108)
!116 = !DILocation(line: 16, column: 9, scope: !108)
!117 = distinct !{!117, !110, !118, !61}
!118 = !DILocation(line: 17, column: 30, scope: !104)
!119 = !DILocation(line: 15, column: 28, scope: !100)
!120 = !DILocation(line: 15, column: 5, scope: !100)
!121 = distinct !{!121, !102, !122, !61}
!122 = !DILocation(line: 17, column: 30, scope: !96)
!123 = !DILocation(line: 18, column: 12, scope: !64)
!124 = !DILocation(line: 18, column: 5, scope: !64)
!125 = distinct !DISubprogram(name: "task_job_phase", scope: !7, file: !7, line: 43, type: !11, scopeLine: 43, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !2, retainedNodes: !42)
!126 = !DILocalVariable(name: "sum", scope: !125, file: !7, line: 44, type: !13)
!127 = !DILocation(line: 44, column: 14, scope: !125)
!128 = !DILocalVariable(name: "s", scope: !129, file: !7, line: 45, type: !47)
!129 = distinct !DILexicalBlock(scope: !125, file: !7, line: 45, column: 5)
!130 = !DILocation(line: 45, column: 14, scope: !129)
!131 = !DILocation(line: 45, column: 10, scope: !129)
!132 = !DILocation(line: 45, column: 21, scope: !133)
!133 = distinct !DILexicalBlock(scope: !129, file: !7, line: 45, column: 5)
!134 = !DILocation(line: 45, column: 23, scope: !133)
!135 = !DILocation(line: 45, column: 5, scope: !129)
!136 = !DILocation(line: 46, column: 16, scope: !133)
!137 = !DILocation(line: 46, column: 13, scope: !133)
!138 = !DILocation(line: 46, column: 9, scope: !133)
!139 = !DILocation(line: 45, column: 28, scope: !133)
!140 = !DILocation(line: 45, column: 5, scope: !133)
!141 = distinct !{!141, !135, !142, !61}
!142 = !DILocation(line: 46, column: 29, scope: !129)
!143 = !DILocation(line: 47, column: 12, scope: !125)
!144 = !DILocation(line: 47, column: 5, scope: !125)
!145 = distinct !DISubprogram(name: "kernel_phase", scope: !7, file: !7, line: 29, type: !11, scopeLine: 29, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition, unit: !2, retainedNodes: !42)
!146 = !DILocalVariable(name: "sum", scope: !145, file: !7, line: 30, type: !13)
!147 = !DILocation(line: 30, column: 14, scope: !145)
!148 = !DILocalVariable(name: "s", scope: !149, file: !7, line: 31, type: !47)
!149 = distinct !DILexicalBlock(scope: !145, file: !7, line: 31, column: 5)
!150 = !DILocation(line: 31, column: 14, scope: !149)
!151 = !DILocation(line: 31, column: 10, scope: !149)
!152 = !DILocation(line: 31, column: 21, scope: !153)
!153 = distinct !DILexicalBlock(scope: !149, file: !7, line: 31, column: 5)
!154 = !DILocation(line: 31, column: 23, scope: !153)
!155 = !DILocation(line: 31, column: 5, scope: !149)
!156 = !DILocalVariable(name: "r", scope: !157, file: !7, line: 32, type: !47)
!157 = distinct !DILexicalBlock(scope: !153, file: !7, line: 32, column: 9)
!158 = !DILocation(line: 32, column: 18, scope: !157)
!159 = !DILocation(line: 32, column: 14, scope: !157)
!160 = !DILocation(line: 32, column: 25, scope: !161)
!161 = distinct !DILexicalBlock(scope: !157, file: !7, line: 32, column: 9)
!162 = !DILocation(line: 32, column: 27, scope: !161)
!163 = !DILocation(line: 32, column: 9, scope: !157)
!164 = !DILocalVariable(name: "i", scope: !165, file: !7, line: 33, type: !47)
!165 = distinct !DILexicalBlock(scope: !161, file: !7, line: 33, column: 13)
!166 = !DILocation(line: 33, column: 22, scope: !165)
!167 = !DILocation(line: 33, column: 18, scope: !165)
!168 = !DILocation(line: 33, column: 29, scope: !169)
!169 = distinct !DILexicalBlock(scope: !165, file: !7, line: 33, column: 13)
!170 = !DILocation(line: 33, column: 31, scope: !169)
!171 = !DILocation(line: 33, column: 13, scope: !165)
!172 = !DILocation(line: 34, column: 35, scope: !169)
!173 = !DILocation(line: 34, column: 24, scope: !169)
!174 = !DILocation(line: 34, column: 21, scope: !169)
!175 = !DILocation(line: 34, column: 17, scope: !169)
!176 = !DILocation(line: 33, column: 41, scope: !169)
!177 = !DILocation(line: 33, column: 13, scope: !169)
!178 = distinct !{!178, !171, !179, !61}
!179 = !DILocation(line: 34, column: 36, scope: !165)
!180 = !DILocation(line: 32, column: 32, scope: !161)
!181 = !DILocation(line: 32, column: 9, scope: !161)
!182 = distinct !{!182, !163, !183, !61}
!183 = !DILocation(line: 34, column: 36, scope: !157)
!184 = !DILocation(line: 31, column: 28, scope: !153)
!185 = !DILocation(line: 31, column: 5, scope: !153)
!186 = distinct !{!186, !155, !187, !61}
!187 = !DILocation(line: 34, column: 36, scope: !149)
!188 = !DILocalVariable(name: "s", scope: !189, file: !7, line: 35, type: !47)
!189 = distinct !DILexicalBlock(scope: !145, file: !7, line: 35, column: 5)
!190 = !DILocation(line: 35, column: 14, scope: !189)
!191 = !DILocation(line: 35, column: 10, scope: !189)
!192 = !DILocation(line: 35, column: 21, scope: !193)
!193 = distinct !DILexicalBlock(scope: !189, file: !7, line: 35, column: 5)
!194 = !DILocation(line: 35, column: 23, scope: !193)
!195 = !DILocation(line: 35, column: 5, scope: !189)
!196 = !DILocalVariable(name: "r", scope: !197, file: !7, line: 36, type: !47)
!197 = distinct !DILexicalBlock(scope: !193, file: !7, line: 36, column: 9)
!198 = !DILocation(line: 36, column: 18, scope: !197)
!199 = !DILocation(line: 36, column: 14, scope: !197)
!200 = !DILocation(line: 36, column: 25, scope: !201)
!201 = distinct !DILexicalBlock(scope: !197, file: !7, line: 36, column: 9)
!202 = !DILocation(line: 36, column: 27, scope: !201)
!203 = !DILocation(line: 36, column: 9, scope: !197)
!204 = !DILocalVariable(name: "i", scope: !205, file: !7, line: 37, type: !47)
!205 = distinct !DILexicalBlock(scope: !201, file: !7, line: 37, column: 13)
!206 = !DILocation(line: 37, column: 22, scope: !205)
!207 = !DILocation(line: 37, column: 18, scope: !205)
!208 = !DILocation(line: 37, column: 32, scope: !209)
!209 = distinct !DILexicalBlock(scope: !205, file: !7, line: 37, column: 13)
!210 = !DILocation(line: 37, column: 34, scope: !209)
!211 = !DILocation(line: 37, column: 13, scope: !205)
!212 = !DILocation(line: 38, column: 35, scope: !209)
!213 = !DILocation(line: 38, column: 24, scope: !209)
!214 = !DILocation(line: 38, column: 21, scope: !209)
!215 = !DILocation(line: 38, column: 17, scope: !209)
!216 = !DILocation(line: 37, column: 45, scope: !209)
!217 = !DILocation(line: 37, column: 13, scope: !209)
!218 = distinct !{!218, !211, !219, !61}
!219 = !DILocation(line: 38, column: 36, scope: !205)
!220 = !DILocation(line: 36, column: 32, scope: !201)
!221 = !DILocation(line: 36, column: 9, scope: !201)
!222 = distinct !{!222, !203, !223, !61}
!223 = !DILocation(line: 38, column: 36, scope: !197)
!224 = !DILocation(line: 35, column: 28, scope: !193)
!225 = !DILocation(line: 35, column: 5, scope: !193)
!226 = distinct !{!226, !195, !227, !61}
!227 = !DILocation(line: 38, column: 36, scope: !189)
!228 = !DILocation(line: 39, column: 12, scope: !145)
!229 = !DILocation(line: 39, column: 5, scope: !145)
!230 = distinct !DISubprogram(name: "workload_prepare", scope: !7, file: !7, line: 49, type: !231, scopeLine: 49, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !2, retainedNodes: !42)
!231 = !DISubroutineType(types: !232)
!232 = !{null}
!233 = !DILocalVariable(name: "i", scope: !234, file: !7, line: 50, type: !47)
!234 = distinct !DILexicalBlock(scope: !230, file: !7, line: 50, column: 5)
!235 = !DILocation(line: 50, column: 14, scope: !234)
!236 = !DILocation(line: 50, column: 10, scope: !234)
!237 = !DILocation(line: 50, column: 21, scope: !238)
!238 = distinct !DILexicalBlock(scope: !234, file: !7, line: 50, column: 5)
!239 = !DILocation(line: 50, column: 23, scope: !238)
!240 = !DILocation(line: 50, column: 5, scope: !234)
!241 = !DILocation(line: 50, column: 46, scope: !238)
!242 = !DILocation(line: 50, column: 37, scope: !238)
!243 = !DILocation(line: 50, column: 49, scope: !238)
!244 = !DILocation(line: 50, column: 32, scope: !238)
!245 = !DILocation(line: 50, column: 5, scope: !238)
!246 = distinct !{!246, !240, !247, !61}
!247 = !DILocation(line: 50, column: 51, scope: !234)
!248 = !DILocalVariable(name: "i", scope: !249, file: !7, line: 51, type: !47)
!249 = distinct !DILexicalBlock(scope: !230, file: !7, line: 51, column: 5)
!250 = !DILocation(line: 51, column: 14, scope: !249)
!251 = !DILocation(line: 51, column: 10, scope: !249)
!252 = !DILocation(line: 51, column: 21, scope: !253)
!253 = distinct !DILexicalBlock(scope: !249, file: !7, line: 51, column: 5)
!254 = !DILocation(line: 51, column: 23, scope: !253)
!255 = !DILocation(line: 51, column: 5, scope: !249)
!256 = !DILocation(line: 51, column: 48, scope: !253)
!257 = !DILocation(line: 51, column: 37, scope: !253)
!258 = !DILocation(line: 51, column: 51, scope: !253)
!259 = !DILocation(line: 51, column: 32, scope: !253)
!260 = !DILocation(line: 51, column: 5, scope: !253)
!261 = distinct !{!261, !255, !262, !61}
!262 = !DILocation(line: 51, column: 53, scope: !249)
!263 = !DILocation(line: 52, column: 1, scope: !230)
