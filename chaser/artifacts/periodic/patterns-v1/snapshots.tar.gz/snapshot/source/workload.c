#include "workload.h"
#ifdef __clang__
#define ANALYZE __attribute__((annotate("ape.analyze")))
#define INLINE __attribute__((annotate("ape.inline")))
#else
#define ANALYZE
#define INLINE
#endif
volatile uint8_t data_hot[34816] __attribute__((aligned(4096), section(".chaser_data.00")));
INLINE static uint32_t kernel_hot(void) {
    uint32_t sum = 0;
    for (int r = 0; r < 4; ++r)
        for (int i = 0; i < 2048; i += 32)
            sum += data_hot[i];
    for (int r = 0; r < 1; ++r)
        for (int i = 2048; i < 34816; i += 32)
            sum += data_hot[i];
    return sum;
}
/** @brief Execute one fixed job without resetting data or cache.
 * @return Load-count checksum, modulo 2^32. */
ANALYZE uint32_t task_job_hot(void) {
    uint32_t sum = 0;
    for (int s = 0; s < 8; ++s)
        sum += kernel_hot();
    return sum;
}
volatile uint8_t data_phase[34816] __attribute__((aligned(4096), section(".chaser_data.01")));
INLINE static uint32_t kernel_phase(void) {
    uint32_t sum = 0;
    for (int s = 0; s < 8; ++s)
        for (int r = 0; r < 4; ++r)
            for (int i = 0; i < 2048; i += 32)
                sum += data_phase[i];
    for (int s = 0; s < 8; ++s)
        for (int r = 0; r < 1; ++r)
            for (int i = 2048; i < 34816; i += 32)
                sum += data_phase[i];
    return sum;
}
/** @brief Execute one fixed job without resetting data or cache.
 * @return Load-count checksum, modulo 2^32. */
ANALYZE uint32_t task_job_phase(void) {
    uint32_t sum = 0;
    for (int s = 0; s < 1; ++s)
        sum += kernel_phase();
    return sum;
}
void workload_prepare(void) {
    for (int i = 0; i < 34816; ++i) data_hot[i] = 1;
    for (int i = 0; i < 34816; ++i) data_phase[i] = 1;
}
uint32_t (*const workload_jobs[])(void) = {
    task_job_hot,
    task_job_phase,
};
const uint32_t workload_expected[] = {
10240U, 10240U
};
