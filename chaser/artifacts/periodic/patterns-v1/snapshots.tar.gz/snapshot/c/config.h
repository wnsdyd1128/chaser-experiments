#define TASK_COUNT 2
#define MAX_JOBS 2
#define ARCHITECTURE 1
#define CHASER_CONTRACT_ID "chaser-periodic-measurement-v2"
#define CHASER_PLAN_HASH "c7b217adab61774961bbbf2c8be72d8be5a2f6ed72e1d2e10b0fc9552d78b6c4"
#define CHASER_PERIODS {20, 20}
#define CHASER_JOB_COUNTS {2, 2}
#define CHASER_CORES {0, 1}
