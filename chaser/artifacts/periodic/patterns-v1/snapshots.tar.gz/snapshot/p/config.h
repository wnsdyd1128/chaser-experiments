#define TASK_COUNT 2
#define MAX_JOBS 2
#define ARCHITECTURE 2
#define CHASER_CONTRACT_ID "chaser-periodic-measurement-v2"
#define CHASER_PLAN_HASH "6544060da806bcad78fdc22789aab478961a46af54ff76fdb342afe0f99551e5"
#define CHASER_PERIODS {20, 20}
#define CHASER_JOB_COUNTS {2, 2}
#define CHASER_CORES {0, 1}
